//line aot_arbace_j2g_model.ae:1
package aot_arbace_j2g_model

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New() *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_model_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_j2g_model_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(A_arbace_j2g_model_A_const_3, A_arbace_j2g_model_A_const_4, A_arbace_j2g_model_A_const_5, A_arbace_j2g_model_A_const_6, A_arbace_j2g_model_A_const_7, A_arbace_j2g_model_A_const_8, A_arbace_j2g_model_A_const_9); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New() *A_arbace_j2g_model_eval1479000008_fn__1479000009_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000008_fn__1479000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_10.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_14), A_arbace_j2g_model_A_const_12.GetRawRoot__O(), A_arbace_j2g_model_A_const_13) }























func A_arbace_j2g_model_jobs_A_New() *A_arbace_j2g_model_jobs_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jobs_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_model_jobs_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_28).Ref(); var tmp1 any; if




	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_15.GetRawRoot__O()).Invoke_O__O(e__1)) {
		tmp1 = jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(e__1))).Ref() } else {
			tmp1 = lang.Numbers_Min_O_J__O(A_arbace_j2g_model_A_const_16.GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :30:1*/ lang.Numbers_Max_J_O__O(1, tmp1) }



func A_arbace_j2g_model_par_mapv_A_New() *A_arbace_j2g_model_par_mapv_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_j2g_model_par_mapv_A) Ctor() {}
//line :34:1
func (t *A_arbace_j2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1479000013__3 any) any { var vec__1479000014__5 any = p__1479000013__3; var order__6 any = lang.RT_Nth_O_I_O__O(vec__1479000014__5, lang.RT_IntCast_J__I(0), nil); var xs__7 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_17.GetRawRoot__O()).Invoke_O__O(xs__2); var cnt__8 int32 = lang.RT_Count_O__I(xs__7); var n__9 any = lang.Numbers_Min_O_J__O(n__0, int64(cnt__8)); var order__10 any; if







	jrt.J2g_Truth(order__6) { order__10 = lang.IFn_Cast(A_arbace_j2g_model_A_const_17.GetRawRoot__O()).Invoke_O__O(order__6) } else { order__10 = lang.IFn_Cast(A_arbace_j2g_model_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(cnt__8).Ref())) }; if
	lang.Numbers_Lte_O_J__Z(n__9, 1) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_18.GetRawRoot__O()).Invoke_O_O__O(f__1, xs__7) } else {
//line :43:1
			var res__11 any = lang.RT_Object_array_O__O1(jrt.Integer_ValueOf_I__Integer(cnt__8).Ref()).Ref(); var next_i__12 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_24); var work__13 any; var tmp1 any = A_arbace_j2g_model_par_mapv_work__1479000017_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__12, xs__7, res__11); var tmp2 *jrt.Class
			var fncls__1 /*line :43:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_work__1479000017_A_fn_class



			if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_j2g_model_par_mapv_work__1479000017_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; work__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :43:1
			var ws__14 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_22.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_model_par_mapv_fn__1479000019_A_New_O(work__13); var tmp6 *jrt.Class
			var fncls__3 /*line :43:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000019_A_fn_class









			if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_j2g_model_par_mapv_fn__1479000019_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; ws__14 = tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(n__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))
			lang.IFn_Cast(A_arbace_j2g_model_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_11.GetRawRoot__O(), ws__14)
			return lang.IFn_Cast(A_arbace_j2g_model_A_const_17.GetRawRoot__O()).Invoke_O__O(res__11) } }
//line :47:1
func A_arbace_j2g_model_par_mapv_work__1479000017_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_j2g_model_par_mapv_work__1479000017_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_work__1479000017_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :47:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000017_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :47:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000017_A) Invoke_O__O(self any) any { for { L2: for { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_20.GetRawRoot__O()); var tmp2 any = t.F_next_i; var k__1 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_j2g_model_A_const_21.GetRawRoot__O())

	if lang.Numbers_Lt_O_J__Z(k__1, int64(t.F_cnt)) { var tmp3 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(k__1)); var tmp4 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_res, jrt.Object_class.ArrayClass()); var tmp5 lang.IFn = lang.IFn_Cast(t.F_f); var tmp6 any = t.F_xs

		lang.RT_Aset_O1_I_O__O(tmp4, lang.RT_IntCast_O__I(i__2), tmp5.Invoke_O__O(lang.RT_Nth_O_I__O(tmp6, lang.RT_IntCast_O__I(i__2))))
		continue L2 } else {
//line :49:1
			return nil } } }; /*line :47:1*/panic("j2g: unreachable") }





func A_arbace_j2g_model_par_mapv_fn__1479000019_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000019_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000019_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000019_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_26.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A_New_O(t.F_work); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; return tmp1.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :53:1
func A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_work; t.F_work = nil; tmp1 = t_; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_j2g_model_has_QMARK__A_New() *A_arbace_j2g_model_has_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_j2g_model_has_QMARK__A) Ctor() {}
//line :59:1
func (t *A_arbace_j2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____3 any = flags__0; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = A_arbace_j2g_model_A_const_29 }; return tmp1.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_O__J(tmp2, f__1))).Ref()) }

func A_arbace_j2g_model_T_A_New() *A_arbace_j2g_model_T_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_T_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_j2g_model_T_A) Ctor() {}
//line :61:1
func (t *A_arbace_j2g_model_T_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_30; var x__1 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()); if lang.IDeref_InstanceOf(x__1) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_j2g_model_translated_QMARK__A_New() *A_arbace_j2g_model_translated_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_33.GetRawRoot__O()).Invoke__O(), n__0) }

func A_arbace_j2g_model_j2g_static_QMARK__A_New() *A_arbace_j2g_model_j2g_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Ctor() {}
//line :65:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(cls__0, Lit_25); if and__1927000168__auto____3 {





	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(base__1, Lit_26); if and__1927000168__auto____4 {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(Lit_27) } else {
//line :71:1
			return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_jrt_class_A_New() *A_arbace_j2g_model_jrt_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_j2g_model_jrt_class_A) Ctor() {}
//line :74:1
func (t *A_arbace_j2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_35; return lang.RT_Get_O_O__O(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()), n__0)
}
func A_arbace_j2g_model_hand_written_QMARK__A_New() *A_arbace_j2g_model_hand_written_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_36.GetRawRoot__O()).Invoke_O__O(n__0); if


	jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_in_world_QMARK__A_New() *A_arbace_j2g_model_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Ctor() {}
//line :84:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z(n__0, Lit_14); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_j2g_model_A_const_36.GetRawRoot__O()).Invoke_O__O(n__0))).Ref() } } }

func A_arbace_j2g_model_translatable_QMARK__A_New() *A_arbace_j2g_model_translatable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0))).Ref()
}
func A_arbace_j2g_model_reflectable_interface_QMARK__A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0)); if




	jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_38.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_49)
		if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_38.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_50); if jrt.J2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_38.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_51); if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_38.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_52); if jrt.J2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			and__1927000168__auto____3 = lang.IFn_Cast(A_arbace_j2g_model_A_const_38.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_53) } } } }
//line :97:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_43.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_54)); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_44.GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_40.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_45.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_44.GetRawRoot__O()).Invoke_O__O(n__0)), A_arbace_j2g_model_A_const_47)); if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_48; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_41.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_44.GetRawRoot__O()).Invoke_O__O(n__0))); if jrt.J2g_Truth(and__1927000168__auto____8) {










			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A_New(); var tmp5 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A_fn_class = fncls__4d; tmp5 = fncls__4d } else { tmp5 = fncls__4 }; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_51; return tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_44.GetRawRoot__O()).Invoke_O__O(n__0))) } else {
//line :97:1
				return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A) Ctor() {}
//line :108:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A) Invoke_O_O__O(self, p1__1479000032_SHARP___1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_49.GetRawRoot__O()).Invoke_O__O(p1__1479000032_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.IFn_Cast(A_arbace_j2g_model_A_const_50.GetRawRoot__O()).Invoke_O__O(p1__1479000032_SHARP___1) } }

func A_arbace_j2g_model_reflected_QMARK__A_New() *A_arbace_j2g_model_reflected_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); if


	jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_info_A_New() *A_arbace_j2g_model_info_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_info_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_j2g_model_info_A) Ctor() {}
//line :115:1
func (t *A_arbace_j2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_44.GetRawRoot__O()).Invoke_O__O(n__0) }
func A_arbace_j2g_model_interface_QMARK__A_New() *A_arbace_j2g_model_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_40.GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_j2g_model_desc_classes_A_New() *A_arbace_j2g_model_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_model_desc_classes_A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z(d__0, nil) { return nil } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_52.GetRawRoot__O()).Invoke_O__O(d__0)) { return nil } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_53.GetRawRoot__O()).Invoke_O__O(d__0)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_57.GetRawRoot__O()).Invoke_O_O__O(d__0, lang.IFn_Cast(A_arbace_j2g_model_A_const_58.GetRawRoot__O()).Invoke_O__O(d__0))) } else {
//line :121:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_55.GetRawRoot__O()).Invoke_O__O(d__0)) { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_model_A_const_59.GetRawRoot__O()).Invoke_O__O(d__0)) } else { if A_arbace_j2g_model_A_const_56 != nil { return nil } else { return nil
			}
			}
		}
	}
	}
}



func A_arbace_j2g_model_method_desc_classes_A_New() *A_arbace_j2g_model_method_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Ctor() {}
//line :131:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var or__1927000174__auto____2 any; if
											jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_60.GetRawRoot__O()).Invoke_O__O(desc__0)) { or__1927000174__auto____2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_61.GetRawRoot__O())).Get_O__O(desc__0) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var vec__1479000040__3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_62.GetRawRoot__O()).Invoke_O__O(desc__0); var ps__4 any = lang.RT_Nth_O_I_O__O(vec__1479000040__3, lang.RT_IntCast_J__I(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O(vec__1479000040__3, lang.RT_IntCast_J__I(1), nil); var v__6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_54.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_model_A_const_64.GetRawRoot__O()).Invoke_O_O__O(r__5, ps__4)))


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_60.GetRawRoot__O()).Invoke_O__O(desc__0)) { jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_61.GetRawRoot__O())).Put_O_O__O(desc__0, v__6) }
//line :132:1
		return v__6 } }





func A_arbace_j2g_model_erased_desc_QMARK__A_New() *A_arbace_j2g_model_erased_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_60.GetRawRoot__O()).Invoke_O__O(d__0); if




	jrt.J2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp1 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A_fn_class
		if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; e__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :143:1
		var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_55.GetRawRoot__O()).Invoke_O__O(e__3)

		if jrt.J2g_Truth(and__1927000168__auto____4) { var n__5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_59.GetRawRoot__O()).Invoke_O__O(e__3); var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_49.GetRawRoot__O()).Invoke_O__O(n__5))

			if jrt.J2g_Truth(and__1927000168__auto____6) {
				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_66.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(n__5); var tmp5 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class = fncls__6d; tmp5 = fncls__6d } else { tmp5 = fncls__6 }; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_67; return tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O())) } else {
//line :147:1
					return and__1927000168__auto____6 } } else {
//line :145:1
						return and__1927000168__auto____4 } } else {
//line :143:1
							return and__1927000168__auto____2 } }
func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :144:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_53.GetRawRoot__O()).Invoke_O__O(d__1)) { d__1 = lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()).Invoke_O__O(d__1); continue L1 } else { return d__1 } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A{}; t.Ctor_O(p0); return t }
//line :148:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :148:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Invoke_O_O__O(self, p1__1479000044_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_38.GetRawRoot__O()).Invoke_O_O__O(t.F_n, p1__1479000044_SHARP___1) }

func A_arbace_j2g_model_desc_in_world_QMARK__A_New() *A_arbace_j2g_model_desc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_49.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_model_A_const_54.GetRawRoot__O()).Invoke_O__O(d__0)) }
func A_arbace_j2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_j2g_model_mdesc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_49.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_model_A_const_68.GetRawRoot__O()).Invoke_O__O(desc__0)) }




func A_arbace_j2g_model_go_name_A_New() *A_arbace_j2g_model_go_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_name_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_j2g_model_go_name_A) Ctor() {}
//line :156:1
func (t *A_arbace_j2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; if




	jrt.J2g_Truth(A_arbace_j2g_model_A_const_31.Get__O()) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_35; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0)) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = A_arbace_j2g_model_A_const_69.Invoke_O__O(jc__3) } } else {
//line :162:1
				or__1927000174__auto____2 = nil } } else {
//line :161:1
					or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						return lang.IFn_Cast(A_arbace_j2g_model_A_const_70.GetRawRoot__O()).Invoke_O__O(n__0) } }
func A_arbace_j2g_model_pkg_A_New() *A_arbace_j2g_model_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pkg_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_j2g_model_pkg_A) Ctor() {}
//line :165:1
func (t *A_arbace_j2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_71.GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_j2g_model_abstract_QMARK__A_New() *A_arbace_j2g_model_abstract_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; return lang.IFn_Cast(A_arbace_j2g_model_A_const_45.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_72.GetRawRoot__O()).Invoke_O__O(n__0)), A_arbace_j2g_model_A_const_73) }
func A_arbace_j2g_model_final_QMARK__A_New() *A_arbace_j2g_model_final_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_j2g_model_final_QMARK__A) Ctor() {}
//line :168:1
func (t *A_arbace_j2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; return lang.IFn_Cast(A_arbace_j2g_model_A_const_45.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_72.GetRawRoot__O()).Invoke_O__O(n__0)), A_arbace_j2g_model_A_const_74) }

func A_arbace_j2g_model_subclasses_A_New() *A_arbace_j2g_model_subclasses_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_subclasses_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_j2g_model_subclasses_A) Ctor() {}
//line :170:1
func (t *A_arbace_j2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_75; return lang.RT_Get_O_O__O(lang.IFn_Cast(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O())).Invoke__O(), n__0)
}
func A_arbace_j2g_model_make_subclass_index_A_New() *A_arbace_j2g_model_make_subclass_index_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Ctor() {}
//line :175:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_19.GetRawRoot__O()).Invoke_O__O(nil); var tmp1 any = A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_New_O_O(cache__2, w__0); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_fn_class; if

	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :177:1
func A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000057_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :177:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000057_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :177:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000057_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(t.F_cache); if
												jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_76.GetRawRoot__O()); var tmp2 any = t.F_cache; var tmp3 any
													lang.IFn_Cast(A_arbace_j2g_model_A_const_84.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_31, t.F_w)); var tmp4 any = A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_New_O(t.F_w); var tmp5 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_fn_class = fncls__8d; tmp5 = fncls__8d } else { tmp5 = fncls__8 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :179:1
		return tmp1.Invoke_O_O__O(tmp2, tmp3) } }
func A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_New_O(p0 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :180:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A) Invoke_O__O(self any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_77.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A_New(); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_82.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_33.GetRawRoot__O()).Invoke__O(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_83.GetRawRoot__O()); var tmp11 *lang.Keyword = A_arbace_j2g_model_A_const_35; var tmp12 any; var t_ any = t.F_w


		t.F_w = nil; tmp12 = t_
//line :181:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp5, tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O__O(tmp11.Invoke_O__O(tmp12)))) }
//line :180:1
	return nil }(); lang.IFn_Cast(A_arbace_j2g_model_A_const_78.GetRawRoot__O()).Invoke__O(); if tmp13 != nil { panic(tmp13) }; return tmp1 }
func A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A_New() *A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A) Ctor() {}
//line :181:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_79; var s__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_72.GetRawRoot__O()).Invoke_O__O(c__2)); if

	jrt.J2g_Truth(s__3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_80.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_81.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var tmp5 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp5 = lang.PersistentHashSet_EMPTY; return tmp2.Invoke_O_O_O_O__O(m__1, s__3, tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()), c__2) } else { return m__1 } }















func A_arbace_j2g_model_leaf_QMARK__A_New() *A_arbace_j2g_model_leaf_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z(n__0, Lit_14) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_86.GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O__O(n__0)) {


		var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_88; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_89; return lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O())), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_90.GetRawRoot__O()).Invoke_O__O(n__0), nil)).Ref())) } else {
//line :204:1
			if A_arbace_j2g_model_A_const_56 != nil { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_91.GetRawRoot__O()).Invoke_O__O(n__0))



				if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_92.GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.J2g_Truth(and__1927000168__auto____3) {
					var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()); var tmp4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_93.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp4 = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_94.GetRawRoot__O()).Invoke_O__O(n__0)) } else { tmp4 = and__1927000168__auto____4 }; return tmp3.Invoke_O__O(tmp4) } else {
//line :208:1
						return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :204:1
							return nil
						}
		}
	}
	}
}




func A_arbace_j2g_model_qualify_A_New() *A_arbace_j2g_model_qualify_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_qualify_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_j2g_model_qualify_A) Ctor() {}
//line :214:1
func (t *A_arbace_j2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z(from__0, nil) }; if tmp1 { return lang.IFn_Cast(A_arbace_j2g_model_A_const_95.GetRawRoot__O()).Invoke_O__O(ident__2) } else { return lang.IFn_Cast(A_arbace_j2g_model_A_const_95.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_96.GetRawRoot__O()).Invoke_O__O(of__1), ident__2)
	} }
func A_arbace_j2g_model_class_sym_A_New() *A_arbace_j2g_model_class_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_sym_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_j2g_model_class_sym_A) Ctor() {}
//line :219:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	return lang.IFn_Cast(A_arbace_j2g_model_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(from__0, lang.IFn_Cast(A_arbace_j2g_model_A_const_98.GetRawRoot__O()).Invoke_O__O(n__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_90.GetRawRoot__O()).Invoke_O__O(n__1), suffix__2)).Ref()) }
//line :219:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	return lang.IFn_Cast(A_arbace_j2g_model_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(from__0, n__1, Lit_2)
}

func A_arbace_j2g_model_jrt_sym_A_New() *A_arbace_j2g_model_jrt_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_j2g_model_jrt_sym_A) Ctor() {}
//line :224:1
func (t *A_arbace_j2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(from__0, A_arbace_j2g_model_A_const_89, ident__1) }






func A_arbace_j2g_model_go_type_A_New() *A_arbace_j2g_model_go_type_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_type_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_j2g_model_go_type_A) Ctor() {}
//line :231:1
func (t *A_arbace_j2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z(d__1, A_arbace_j2g_model_A_const_100) { return A_arbace_j2g_model_A_const_101 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_102.GetRawRoot__O()).Invoke_O__O(d__1)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_102.GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :234:1
			if lang.Util_Equiv_O_O__Z(d__1, Lit_9) { return nil } else { if lang.Util_Equiv_O_O__Z(d__1, Lit_10) { return A_arbace_j2g_model_A_const_103 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_53.GetRawRoot__O()).Invoke_O__O(d__1)) { var e__3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()).Invoke_O__O(d__1)





				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()).Invoke_O__O(e__3)) {
					var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_105.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_A_const_109; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()).Invoke_O_O__O(from__0, lang.IFn_Cast(A_arbace_j2g_model_A_const_111.GetRawRoot__O()).Invoke_O__O(e__3))) } else {
						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_105.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_112; return tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()).Invoke_O_O__O(from__0, Lit_11)) } } else {
//line :234:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_55.GetRawRoot__O()).Invoke_O__O(d__1)) { var n__3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_59.GetRawRoot__O()).Invoke_O__O(d__1)










								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_49.GetRawRoot__O()).Invoke_O__O(n__3))) { return A_arbace_j2g_model_A_const_106 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_86.GetRawRoot__O()).Invoke_O__O(n__3)) {

									return lang.IFn_Cast(A_arbace_j2g_model_A_const_99.GetRawRoot__O()).Invoke_O_O__O(from__0, n__3) } else {
//line :245:1
										if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()).Invoke_O__O(n__3)) {


											var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_105.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_model_A_const_113; return tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_j2g_model_A_const_99.GetRawRoot__O()).Invoke_O_O__O(from__0, n__3)) } else {
//line :245:1
												if A_arbace_j2g_model_A_const_56 != nil {



													return lang.IFn_Cast(A_arbace_j2g_model_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(from__0, n__3, Lit_12) } else {
//line :245:1
														return nil } } } } } else {
//line :234:1
															if A_arbace_j2g_model_A_const_56 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_j2g_model_A_const_108.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_114.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_115, d__1)))))) } else { return nil
															}
														}
						}
			}
			}
		}
	}
}









func A_arbace_j2g_model_pointer_desc_QMARK__A_New() *A_arbace_j2g_model_pointer_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :252:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_53.GetRawRoot__O()).Invoke_O__O(d__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_55.GetRawRoot__O()).Invoke_O__O(d__0)) { var n__2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_59.GetRawRoot__O()).Invoke_O__O(d__0); var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_49.GetRawRoot__O()).Invoke_O__O(n__2)

		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_86.GetRawRoot__O()).Invoke_O__O(n__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_116.GetRawRoot__O()).Invoke_O_O__O(n__2, Lit_14); if jrt.J2g_Truth(and__1927000168__auto____5) {
			return lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()).Invoke_O__O(n__2) } else {
//line :257:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :255:1
					if A_arbace_j2g_model_A_const_56 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
	}
}

func A_arbace_j2g_model_iface_desc_QMARK__A_New() *A_arbace_j2g_model_iface_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Ctor() {}
//line :261:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_117.GetRawRoot__O()).Invoke_O__O(d__0); if


	jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_116.GetRawRoot__O()).Invoke_O_O__O(d__0, A_arbace_j2g_model_A_const_100); if jrt.J2g_Truth(and__1927000168__auto____3) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_118.GetRawRoot__O()).Invoke_O__O(d__0)) } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_model_static_QMARK__A_New() *A_arbace_j2g_model_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_model_static_QMARK__A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0), A_arbace_j2g_model_A_const_119) }
func A_arbace_j2g_model_private_QMARK__A_New() *A_arbace_j2g_model_private_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_j2g_model_private_QMARK__A) Ctor() {}
//line :270:1
func (t *A_arbace_j2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0), A_arbace_j2g_model_A_const_120) }
func A_arbace_j2g_model_abstract_m_QMARK__A_New() *A_arbace_j2g_model_abstract_m_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Ctor() {}
//line :271:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0), A_arbace_j2g_model_A_const_73) }

func A_arbace_j2g_model_methods_of_A_New() *A_arbace_j2g_model_methods_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_methods_of_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_j2g_model_methods_of_A) Ctor() {}
//line :273:1
func (t *A_arbace_j2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_48; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_72.GetRawRoot__O()).Invoke_O__O(n__0)) }
func A_arbace_j2g_model_fields_of_A_New() *A_arbace_j2g_model_fields_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fields_of_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_j2g_model_fields_of_A) Ctor() {}
//line :274:1
func (t *A_arbace_j2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_121; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_72.GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_j2g_model_find_method_A_New() *A_arbace_j2g_model_find_method_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_j2g_model_find_method_A) Ctor() {}
//line :276:1
func (t *A_arbace_j2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_66.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_find_method_fn__1479000077_A_New_O_O(name__1, desc__2); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_model_find_method_fn__1479000077_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_j2g_model_find_method_fn__1479000077_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_model_A_const_123.GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :277:1
func A_arbace_j2g_model_find_method_fn__1479000077_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_find_method_fn__1479000077_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_fn__1479000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :277:1
func (t *A_arbace_j2g_model_find_method_fn__1479000077_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :277:1
func (t *A_arbace_j2g_model_find_method_fn__1479000077_A) Invoke_O_O__O(self, p1__1479000076_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_j2g_model_A_const_122.Invoke_O__O(p1__1479000076_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z(tmp3, A_arbace_j2g_model_A_const_115.Invoke_O__O(p1__1479000076_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1479000076_SHARP___1 } else { return nil } }

func A_arbace_j2g_model_virtual_member_QMARK__A_New() *A_arbace_j2g_model_virtual_member_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_124.GetRawRoot__O()).Invoke_O__O(m__0)); if


	jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_125.GetRawRoot__O()).Invoke_O__O(m__0)); if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_36, A_arbace_j2g_model_A_const_122.Invoke_O__O(m__0)); if jrt.J2g_Truth(and__1927000168__auto____4) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_57, A_arbace_j2g_model_A_const_122.Invoke_O__O(m__0)) } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_model_supertypes_A_New() *A_arbace_j2g_model_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_supertypes_A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_j2g_model_supertypes_A) Ctor() {}
//line :289:1
func (t *A_arbace_j2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_72.GetRawRoot__O()).Invoke_O__O(n__0); return /*line :290:1*/ lang.IFn_Cast(A_arbace_j2g_model_A_const_126.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_127.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_model_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_79.Invoke_O__O(i__2), A_arbace_j2g_model_A_const_51.Invoke_O__O(i__2))) }

func A_arbace_j2g_model_world_supertypes_A_New() *A_arbace_j2g_model_world_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_j2g_model_world_supertypes_A) Ctor() {}
//line :292:1
func (t *A_arbace_j2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	return lang.IFn_Cast(A_arbace_j2g_model_A_const_128.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_49.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_model_A_const_129.GetRawRoot__O()).Invoke_O__O(n__0))
}
func A_arbace_j2g_model_all_supertypes_A_New() *A_arbace_j2g_model_all_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_model_all_supertypes_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	return lang.IFn_Cast(A_arbace_j2g_model_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_128.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_49.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_model_A_const_130.GetRawRoot__O()).Invoke_O__O(n__0)))
}


func A_arbace_j2g_model_hw_method_exists_QMARK__A_New() *A_arbace_j2g_model_hw_method_exists_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :306:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_89; var scan__3 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()); var g__4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_90.GetRawRoot__O()).Invoke_O__O(n__0); var base__5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_131.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_122.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1)); if





	lang.Util_Equiv_O_O__Z(n__0, Lit_14) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_134.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_122.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1))) } else {
//line :312:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_86.GetRawRoot__O()).Invoke_O__O(n__0)) { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_135.GetRawRoot__O()).Invoke_O_O__O(scan__3, g__4), base__5)

				if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					return lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_136.Invoke_O__O(scan__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref()) } } else {
//line :312:1
						if A_arbace_j2g_model_A_const_56 != nil { var ms__6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_132.GetRawRoot__O()).Invoke_O_O__O(scan__3, g__4); var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(ms__6, base__5)





							if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(ms__6, lang.IFn_Cast(A_arbace_j2g_model_A_const_137.GetRawRoot__O()).Invoke_O__O(base__5)); if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								return lang.IFn_Cast(A_arbace_j2g_model_A_const_133.GetRawRoot__O()).Invoke_O_O__O(n__0, base__5) } } } else {
//line :312:1
									return nil } } } }








func A_arbace_j2g_model_j2g_method_QMARK__A_New() *A_arbace_j2g_model_j2g_method_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_method_QMARK__A{}; t.Ctor(); return t }
//line :321:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Ctor() {}
//line :321:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(n__0, Lit_22); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_138).Invoke_O__O(base__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(Lit_23); if jrt.J2g_Truth(and__1927000168__auto____5) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(Lit_24) } else {
//line :328:1
			return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_member_in_world_QMARK__A_New() *A_arbace_j2g_model_member_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Ctor() {}
//line :331:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_139.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1)); if



	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O__O(n__0))
		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return lang.IFn_Cast(A_arbace_j2g_model_A_const_140.GetRawRoot__O()).Invoke_O_O__O(n__0, m__1) } } else {
//line :335:1
			return and__1927000168__auto____3 } }


func A_arbace_j2g_model_declared_vmethods_A_New() *A_arbace_j2g_model_declared_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Ctor() {}
//line :338:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_fn_class; if


	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_123.GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :341:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_New_O(p0 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A{}; t.Ctor_O(p0); return t }
//line :341:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :341:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A) Invoke_O_O__O(self, s__1479000088__1 any) any { var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_New_O_O_O(t.F_n, s__1479000088__1, self); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :341:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :341:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A) Ctor_O_O_O(c__n, c__s__1479000088, c__iter__1479000087 any) { t.F_n = c__n; t.F_s__1479000088 = c__s__1479000088; t.F_iter__1479000087 = c__iter__1479000087 }
//line :341:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A) Invoke_O__O(self any) any { { var s__1479000088__1 any; var t_ any = t.F_s__1479000088; t.F_s__1479000088 = nil; s__1479000088__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1479000088__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000088__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_141.GetRawRoot__O()).Invoke_O__O(s__1479000088__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_142.GetRawRoot__O()).Invoke_O__O(s__1479000088__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1479000090__6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_143.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A_New_O_O_I_O(t.F_n, b__1479000090__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1479000087); return lang.IFn_Cast(A_arbace_j2g_model_A_const_149.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_151.GetRawRoot__O()).Invoke_O__O(b__1479000090__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_152.GetRawRoot__O()).Invoke_O__O(s__1479000088__3))) } else { return lang.IFn_Cast(A_arbace_j2g_model_A_const_149.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_151.GetRawRoot__O()).Invoke_O__O(b__1479000090__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_150.GetRawRoot__O()).Invoke_O__O(s__1479000088__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_144.GetRawRoot__O()).Invoke_O__O(m__4)) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_145.GetRawRoot__O()).Invoke_O_O__O(t.F_n, m__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000087); return lang.IFn_Cast(A_arbace_j2g_model_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_147.GetRawRoot__O()).Invoke_O_O_O__O(m__4, A_arbace_j2g_model_A_const_148, t.F_n), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_153.GetRawRoot__O()).Invoke_O__O(s__1479000088__3))) } else { s__1479000088__1 = lang.IFn_Cast(A_arbace_j2g_model_A_const_153.GetRawRoot__O()).Invoke_O__O(s__1479000088__3); continue L1 } } else { s__1479000088__1 = lang.IFn_Cast(A_arbace_j2g_model_A_const_153.GetRawRoot__O()).Invoke_O__O(s__1479000088__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :341:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :341:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A) Ctor_O_O_I_O(c__n, c__b__1479000090 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1479000090 = c__b__1479000090; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :341:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A) Invoke_O__O(self any) any { { var i__1479000089__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1479000089__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1479000089__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_144.GetRawRoot__O()).Invoke_O__O(m__2)) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_145.GetRawRoot__O()).Invoke_O_O__O(t.F_n, m__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_146.GetRawRoot__O()); var tmp3 any = t.F_b__1479000090; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_model_A_const_147.GetRawRoot__O()).Invoke_O_O_O__O(m__2, A_arbace_j2g_model_A_const_148, t.F_n)); i__1479000089__1 = lang.Numbers_Unchecked_inc_J__J(i__1479000089__1); continue L1 } else { i__1479000089__1 = lang.Numbers_Unchecked_inc_J__J(i__1479000089__1); continue L1 } } else { i__1479000089__1 = lang.Numbers_Unchecked_inc_J__J(i__1479000089__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_model_vmethods_A_New() *A_arbace_j2g_model_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_j2g_model_vmethods_A) Ctor() {}
//line :346:1
func (t *A_arbace_j2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_154; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()); var or__1927000174__auto____3 any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(cache__2), n__0); if




	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_77.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_vmethods_fn__1479000098_A_New(); var tmp4 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000098_A_fn_class
		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_j2g_model_vmethods_fn__1479000098_A_fn_class = fncls__15d; tmp4 = fncls__15d } else { tmp4 = fncls__15 }; r__4 = tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_j2g_model_A_const_156.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_j2g_model_A_const_157.GetRawRoot__O()).Invoke_O__O(n__0))







		lang.IFn_Cast(A_arbace_j2g_model_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O__O(cache__2, A_arbace_j2g_model_A_const_147.GetRawRoot__O(), n__0, r__4)
//line :351:1
		return r__4 } }
func A_arbace_j2g_model_vmethods_fn__1479000098_A_New() *A_arbace_j2g_model_vmethods_fn__1479000098_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000098_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000098_A) Ctor() {}
//line :352:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000098_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z(c__2, Lit_14) { return acc__1 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_77.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), acc__1, lang.IFn_Cast(A_arbace_j2g_model_A_const_155.GetRawRoot__O()).Invoke_O__O(c__2)) } }
//line :355:1
func A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A_New() *A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A) Ctor() {}
//line :355:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_122.Invoke_O__O(m__2), A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)); var tmp1 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(acc__1, k__3); if

	jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_134.GetRawRoot__O(), k__3) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { return lang.IFn_Cast(A_arbace_j2g_model_A_const_147.GetRawRoot__O()).Invoke_O_O_O__O(acc__1, k__3, m__2) } }





func A_arbace_j2g_model_superclass_chain_A_New() *A_arbace_j2g_model_superclass_chain_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_j2g_model_superclass_chain_A) Ctor() {}
//line :363:1
func (t *A_arbace_j2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_158.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_159.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_superclass_chain_fn__1479000104_A_New(); var tmp5 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_model_superclass_chain_fn__1479000104_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_j2g_model_superclass_chain_fn__1479000104_A_fn_class = fncls__16d; tmp5 = fncls__16d } else { tmp5 = fncls__16 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), n__0)) }
//line :364:1
func A_arbace_j2g_model_superclass_chain_fn__1479000104_A_New() *A_arbace_j2g_model_superclass_chain_fn__1479000104_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_fn__1479000104_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000104_A) Ctor() {}
//line :364:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000104_A) Invoke_O_O__O(self, p1__1479000103_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_79; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_72.GetRawRoot__O()).Invoke_O__O(p1__1479000103_SHARP___1)) }

func A_arbace_j2g_model_impl_of_A_New() *A_arbace_j2g_model_impl_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_j2g_model_impl_of_A) Ctor() {}
//line :366:1
func (t *A_arbace_j2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1479000108__1 any) any { var vec__1479000109__3 any = p__1479000108__1; var name__4 any = lang.RT_Nth_O_I_O__O(vec__1479000109__3, lang.RT_IntCast_J__I(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__1479000109__3, lang.RT_IntCast_J__I(1), nil); var k__6 any = vec__1479000109__3; var or__1927000174__auto____7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_66.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_impl_of_fn__1479000112_A_New_O_O_O(name__4, desc__5, n__0); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000112_A_fn_class; _ = k__6; if





	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_j2g_model_impl_of_fn__1479000112_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; or__1927000174__auto____7 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_model_A_const_169.GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var tmp4 any = A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A_New_O_O(name__4, desc__5); var tmp5 *jrt.Class
		var fncls__19 /*line :372:1*/*jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A_fn_class














		if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A_fn_class = fncls__19d; tmp5 = fncls__19d } else { tmp5 = fncls__19 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); cands__8 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_157.GetRawRoot__O()).Invoke_O__O(n__0))
//line :372:1
		var cands__9 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_126.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_impl_of_fn__1479000124_A_New_O(cands__8); var tmp8 *jrt.Class
		var fncls__22 /*line :372:1*/*jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class





















		if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class = fncls__22d; tmp8 = fncls__22d } else { tmp8 = fncls__22 }; cands__9 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), cands__8)
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_150.GetRawRoot__O()).Invoke_O__O(cands__9) } }
//line :372:1
func A_arbace_j2g_model_impl_of_fn__1479000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_impl_of_fn__1479000112_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :372:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000112_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :372:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000112_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_86.GetRawRoot__O()).Invoke_O__O(c__1)); if
											jrt.J2g_Truth(and__1927000168__auto____2) { temp__1927000414__auto____2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_160.GetRawRoot__O()).Invoke_O_O_O__O(c__1, t.F_name, t.F_desc) } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_124.GetRawRoot__O()).Invoke_O__O(m__3))
												if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_161.GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_125.GetRawRoot__O()).Invoke_O__O(m__3))
													if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(c__1, t.F_n)).Ref() } } else {
//line :374:1
				tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

					if lang.Util_Equiv_O_O__Z(c__1, Lit_14) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_162, A_arbace_j2g_model_A_const_165, A_arbace_j2g_model_A_const_148, c__1, A_arbace_j2g_model_A_const_164, m__3)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O__O(c__1)) { var base__4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_131.GetRawRoot__O()).Invoke_O_O__O(t.F_name, t.F_desc); var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_89; var ms__5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_132.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()), lang.IFn_Cast(A_arbace_j2g_model_A_const_90.GetRawRoot__O()).Invoke_O__O(c__1))




						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(ms__5, lang.IFn_Cast(A_arbace_j2g_model_A_const_137.GetRawRoot__O()).Invoke_O__O(base__4))) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_162, A_arbace_j2g_model_A_const_166, A_arbace_j2g_model_A_const_148, c__1, A_arbace_j2g_model_A_const_164, m__3)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(ms__5, base__4)) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_162, A_arbace_j2g_model_A_const_167, A_arbace_j2g_model_A_const_148, c__1, A_arbace_j2g_model_A_const_164, m__3)) } else { if A_arbace_j2g_model_A_const_56 != nil { return nil } else { return nil } } } } else {
//line :376:1
							if A_arbace_j2g_model_A_const_56 != nil { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_162, A_arbace_j2g_model_A_const_168, A_arbace_j2g_model_A_const_148, c__1, A_arbace_j2g_model_A_const_164, m__3)) } else { return nil } } } } else {
//line :374:1
								return nil } } else {
//line :373:1
									return nil } }













func A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :387:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :387:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A) Invoke_O_O__O(self, s__1479000115__1 any) any { var tmp1 any = A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A_New_O_O_O_O(self, t.F_name, t.F_desc, s__1479000115__1); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :387:1
func A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :387:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A) Ctor_O_O_O_O(c__iter__1479000114, c__name, c__desc, c__s__1479000115 any) { t.F_iter__1479000114 = c__iter__1479000114; t.F_name = c__name; t.F_desc = c__desc; t.F_s__1479000115 = c__s__1479000115 }
//line :387:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A) Invoke_O__O(self any) any { { var s__1479000115__1 any; var t_ any = t.F_s__1479000115; t.F_s__1479000115 = nil; s__1479000115__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1479000115__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000115__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_141.GetRawRoot__O()).Invoke_O__O(s__1479000115__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_142.GetRawRoot__O()).Invoke_O__O(s__1479000115__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1479000117__6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_143.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A_New_O_O_O_I_O(t.F_name, b__1479000117__6, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1479000114); return lang.IFn_Cast(A_arbace_j2g_model_A_const_149.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_151.GetRawRoot__O()).Invoke_O__O(b__1479000117__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_152.GetRawRoot__O()).Invoke_O__O(s__1479000115__3))) } else { return lang.IFn_Cast(A_arbace_j2g_model_A_const_149.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_151.GetRawRoot__O()).Invoke_O__O(b__1479000117__6), nil) } } else { var c__4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_150.GetRawRoot__O()).Invoke_O__O(s__1479000115__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_86.GetRawRoot__O()).Invoke_O__O(c__4)) { var m__5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_160.GetRawRoot__O()).Invoke_O_O_O__O(c__4, t.F_name, t.F_desc); var tmp4 any
														var and__1927000168__auto____6 any = m__5

	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_161.GetRawRoot__O()).Invoke_O__O(m__5)); if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_124.GetRawRoot__O()).Invoke_O__O(m__5)); if jrt.J2g_Truth(and__1927000168__auto____8) { tmp4 = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_125.GetRawRoot__O()).Invoke_O__O(m__5)) } else { tmp4 = and__1927000168__auto____8 } } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }
//line :387:1
	if jrt.J2g_Truth(tmp4) { var tmp5 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O__O(c__4))



		if jrt.J2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else {
			var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_136; var tmp7 *lang.Keyword = A_arbace_j2g_model_A_const_89; tmp5 = lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(tmp6.Invoke_O__O(tmp7.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O())), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_90.GetRawRoot__O()).Invoke_O__O(c__4), nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_131.GetRawRoot__O()).Invoke_O_O__O(t.F_name, t.F_desc))).Ref()) }
//line :387:1
		if jrt.J2g_Truth(tmp5) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000114); return lang.IFn_Cast(A_arbace_j2g_model_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_162, A_arbace_j2g_model_A_const_163, A_arbace_j2g_model_A_const_148, c__4, A_arbace_j2g_model_A_const_164, m__5)), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_153.GetRawRoot__O()).Invoke_O__O(s__1479000115__3))) } else { s__1479000115__1 = lang.IFn_Cast(A_arbace_j2g_model_A_const_153.GetRawRoot__O()).Invoke_O__O(s__1479000115__3); continue L1 } } else { s__1479000115__1 = lang.IFn_Cast(A_arbace_j2g_model_A_const_153.GetRawRoot__O()).Invoke_O__O(s__1479000115__3); continue L1 } } else { s__1479000115__1 = lang.IFn_Cast(A_arbace_j2g_model_A_const_153.GetRawRoot__O()).Invoke_O__O(s__1479000115__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :387:1
func A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :387:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A) Ctor_O_O_O_I_O(c__name, c__b__1479000117, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__1479000117 = c__b__1479000117; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :387:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A) Invoke_O__O(self any) any { { var i__1479000116__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1479000116__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1479000116__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_86.GetRawRoot__O()).Invoke_O__O(c__2)) { var m__3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_160.GetRawRoot__O()).Invoke_O_O_O__O(c__2, t.F_name, t.F_desc); var tmp2 any
																var and__1927000168__auto____4 any = m__3

	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_161.GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_124.GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_125.GetRawRoot__O()).Invoke_O__O(m__3)) } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :387:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O__O(c__2))



		if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else {
			var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_136; var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_89; tmp3 = lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O())), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_90.GetRawRoot__O()).Invoke_O__O(c__2), nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_131.GetRawRoot__O()).Invoke_O_O__O(t.F_name, t.F_desc))).Ref()) }
//line :387:1
		if jrt.J2g_Truth(tmp3) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_146.GetRawRoot__O()); var tmp7 any = t.F_b__1479000117; tmp6.Invoke_O_O__O(tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_162, A_arbace_j2g_model_A_const_163, A_arbace_j2g_model_A_const_148, c__2, A_arbace_j2g_model_A_const_164, m__3))); i__1479000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1479000116__1); continue L1 } else { i__1479000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1479000116__1); continue L1 } } else { i__1479000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1479000116__1); continue L1 } } else { i__1479000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1479000116__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_model_impl_of_fn__1479000124_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000124_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000124_A{}; t.Ctor_O(p0); return t }
//line :394:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :394:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_66.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A_New_O(x__1); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_cands) }
//line :394:1
func A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A{}; t.Ctor_O(p0); return t }
//line :394:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :394:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A) Invoke_O_O__O(self, p1__1479000107_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_116.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_148.Invoke_O__O(p1__1479000107_SHARP___1), A_arbace_j2g_model_A_const_148.Invoke_O__O(t.F_x)); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_148.Invoke_O__O(p1__1479000107_SHARP___1), A_arbace_j2g_model_A_const_148.Invoke_O__O(t.F_x)) } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_code_class_QMARK__A_New() *A_arbace_j2g_model_code_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_class_QMARK__A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Ctor() {}
//line :397:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_171; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_172; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1.Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0))))).Ref()
}
func A_arbace_j2g_model_code_iface_QMARK__A_New() *A_arbace_j2g_model_code_iface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_iface_QMARK__A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Ctor() {}
//line :407:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_j2g_model_A_const_173.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_174, n__0))).Ref()
}
func A_arbace_j2g_model_nest_top_A_New() *A_arbace_j2g_model_nest_top_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_nest_top_A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_j2g_model_nest_top_A) Ctor() {}
//line :413:1
func (t *A_arbace_j2g_model_nest_top_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_32); if


	lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__0 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_57.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_A_const_29; return tmp1.Invoke_O_O_O__O(n__0, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_j2g_model_trivial_init_QMARK__A_New() *A_arbace_j2g_model_trivial_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :418:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Ctor() {}
//line :418:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_175; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()); if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(cache__2), n__0)) {
		return lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(cache__2), n__0) } else {
//line :424:1
			var r__3 any

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0))) { jrt.Boolean_Init(); r__3 = jrt.Boolean_TRUE.Ref() } else { if lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0), nil) { jrt.Boolean_Init(); r__3 = jrt.Boolean_TRUE.Ref() } else { if A_arbace_j2g_model_A_const_56 != nil { var d__3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0); var st__4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_177.Invoke_O__O(d__3)); var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_178.Invoke_O__O(st__4))




				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_179.Invoke_O__O(st__4)); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_180.Invoke_O__O(st__4)); if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_181.Invoke_O__O(st__4)); if jrt.J2g_Truth(and__1927000168__auto____8) { var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z(A_arbace_j2g_model_A_const_79.Invoke_O__O(d__3), nil)



					if or__1927000174__auto____9 { r__3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9).Ref() } else { r__3 = lang.IFn_Cast(A_arbace_j2g_model_A_const_176.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_79.Invoke_O__O(d__3)) } } else {
//line :431:1
						r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :426:1
							r__3 = nil
						}
			}
			}






			lang.IFn_Cast(A_arbace_j2g_model_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O__O(cache__2, A_arbace_j2g_model_A_const_147.GetRawRoot__O(), n__0, r__3)
//line :424:1
			return r__3 } }



















func A_arbace_j2g_model_top_class_A_New() *A_arbace_j2g_model_top_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_top_class_A{}; t.Ctor(); return t }
//line :444:1
func (t *A_arbace_j2g_model_top_class_A) Ctor() {}
//line :444:1
func (t *A_arbace_j2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_32); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__0 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_57.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_model_A_const_29; return tmp1.Invoke_O_O_O__O(n__0, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_j2g_model_pure_ctor_QMARK__A_New() *A_arbace_j2g_model_pure_ctor_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :446:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :446:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(c__1); var ab__6 any; if





	jrt.J2g_Truth(d__5) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_182; ab__6 = lang.RT_Get_O_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_177.Invoke_O__O(d__5))), lang.Tuple_Create_O_O__IPersistentVector(Lit_36, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_34.GetRawRoot__O()).Invoke_O__O(c__1); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_j2g_model_A_const_183.GetRawRoot__O()).Invoke_O__O(c__1), lang.IFn_Cast(A_arbace_j2g_model_A_const_183.GetRawRoot__O()).Invoke_O__O(n__0)); if and__1927000168__auto____10 { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(seen__3, lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)))); if jrt.J2g_Truth(and__1927000168__auto____11) { var seen__12 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_12.GetRawRoot__O()).Invoke_O_O__O(seen__3, lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2))); var call__13 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(ab__6); var sup__14 any = A_arbace_j2g_model_A_const_79.Invoke_O__O(d__5); var and__1927000168__auto____15 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_189.Invoke_O__O(ab__6))





		if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_190.Invoke_O__O(ab__6)); if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z(call__13, nil)

			if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A_New_O_O(n__0, seen__12); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A_fn_class
				if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; and__1927000168__auto____18 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), A_arbace_j2g_model_A_const_191.Invoke_O__O(call__13)); if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool = lang.Util_Identical_O_O__Z(A_arbace_j2g_model_A_const_168.Invoke_O__O(call__13), nil)
					if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____19).Ref() } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_185); var or__1927000174__auto____20 any = tmp5.Invoke_O__O(A_arbace_j2g_model_A_const_168.Invoke_O__O(call__13)); if jrt.J2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
						and__1927000168__auto____17 = lang.IFn_Cast(A_arbace_j2g_model_A_const_186.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, A_arbace_j2g_model_A_const_168.Invoke_O__O(call__13), A_arbace_j2g_model_A_const_192.Invoke_O__O(call__13), seen__12) } } } else {
//line :462:1
							and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :459:1
			if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_39.GetRawRoot__O()).Invoke_O__O(call__13)





				if jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(sup__14, Lit_14)).Ref() } }
//line :459:1
				if jrt.J2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A_New_O_O(n__0, seen__12); var tmp8 *jrt.Class
					var fncls__24 /*line :459:1*/*jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A_fn_class






					if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A_fn_class = fncls__24d; tmp8 = fncls__24d } else { tmp8 = fncls__24 }; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_193; and__1927000168__auto____19 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_177.Invoke_O__O(d__5))))
//line :459:1
					if jrt.J2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool = lang.Util_Identical_O_O__Z(A_arbace_j2g_model_A_const_187.Invoke_O__O(ab__6), nil)







						if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____20_2).Ref() } else { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(n__0, A_arbace_j2g_model_A_const_187.Invoke_O__O(ab__6), seen__12) } } else {
//line :459:1
							return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :453:1
								return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A{}; t.Ctor_O_O(p0, p1); return t }
//line :462:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :462:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A) Invoke_O_O__O(self, p1__1479000134_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1479000134_SHARP___1, t.F_seen) }



func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :466:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :466:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A) Invoke_O_O__O(self, p1__1479000135_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1479000135_SHARP___1, t.F_seen) }


func A_arbace_j2g_model_pure_node_QMARK__A_New() *A_arbace_j2g_model_pure_node_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Ctor() {}
//line :469:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1479000147__4_ any = A_arbace_j2g_model_A_const_194.Invoke_O__O(node__1); switch



	lang.Util_Hash_O__I(G__1479000147__4_) >> 3 & 63 { case 1: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_195) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_204.Invoke_O__O(node__1))


















		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_205.Invoke_O__O(node__1)); if jrt.J2g_Truth(and__1927000168__auto____6) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(n__0, A_arbace_j2g_model_A_const_206.Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :473:1
	case 11: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_196) { var tmp1 any = A_arbace_j2g_model_A_const_197; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_194; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z(tmp1, tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_198.Invoke_O__O(node__1)))







		if and__1927000168__auto____5_2 { var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_207; var and__1927000168__auto____6_2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_41.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_198.Invoke_O__O(node__1))); if jrt.J2g_Truth(and__1927000168__auto____6_2) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(n__0, A_arbace_j2g_model_A_const_208.Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() } }
//line :473:1
	case 13: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_199) { var tmp4 any = A_arbace_j2g_model_A_const_200; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z(tmp4, A_arbace_j2g_model_A_const_162.Invoke_O__O(node__1))













		if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z(Lit_39, A_arbace_j2g_model_A_const_148.Invoke_O__O(node__1))
			if and__1927000168__auto____6_4 { or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z(Lit_40, A_arbace_j2g_model_A_const_122.Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(n__0, A_arbace_j2g_model_A_const_148.Invoke_O__O(node__1))

				if and__1927000168__auto____7 { and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z(Lit_41, A_arbace_j2g_model_A_const_122.Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :487:1
			if and__1927000168__auto____6_3 {



				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A_New_O_O(n__0, seen__2); var tmp7 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A_fn_class = fncls__26d; tmp7 = fncls__26d } else { tmp7 = fncls__26 }; return tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), A_arbace_j2g_model_A_const_191.Invoke_O__O(node__1)) } else {
//line :487:1
					return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_3).Ref() } }
//line :473:1
	case 14: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_201) { var and__1927000168__auto____5_4 bool; var tmp8 any; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_202; var or__1927000174__auto____5 any = tmp9.Invoke_O__O(A_arbace_j2g_model_A_const_203.Invoke_O__O(node__1))






		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { var tmp10 *lang.Keyword = A_arbace_j2g_model_A_const_148; tmp8 = tmp10.Invoke_O__O(A_arbace_j2g_model_A_const_203.Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z(n__0, tmp8); if and__1927000168__auto____5_4 { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(n__0, A_arbace_j2g_model_A_const_208.Invoke_O__O(node__1), seen__2) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_4).Ref() } }
//line :473:1
	case 15: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_197) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 19: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_209) { var and__1927000168__auto____5_5 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A_New_O_O(n__0, seen__2); var tmp13 *jrt.Class
		var fncls__27 /*line :473:1*/*jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A_fn_class


		if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A_fn_class = fncls__27d; tmp13 = fncls__27d } else { tmp13 = fncls__27 }; and__1927000168__auto____5_5 = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_j2g_model_A_const_211.Invoke_O__O(node__1)); if jrt.J2g_Truth(and__1927000168__auto____5_5) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(n__0, A_arbace_j2g_model_A_const_187.Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____5_5 } }
//line :473:1
	case 21: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_210) {





		var tmp14 any; var tmp15 *lang.Keyword = A_arbace_j2g_model_A_const_202; var or__1927000174__auto____5_2 any = tmp15.Invoke_O__O(A_arbace_j2g_model_A_const_203.Invoke_O__O(node__1)); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp14 = or__1927000174__auto____5_2 } else { var tmp16 *lang.Keyword = A_arbace_j2g_model_A_const_148; tmp14 = tmp16.Invoke_O__O(A_arbace_j2g_model_A_const_203.Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(n__0, tmp14)).Ref() }
//line :473:1
	case 25: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_212) { var and__1927000168__auto____5_6 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A_New_O_O(n__0, seen__2); var tmp19 *jrt.Class
		var fncls__28 /*line :473:1*/*jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A_fn_class

		if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A_fn_class = fncls__28d; tmp19 = fncls__28d } else { tmp19 = fncls__28 }; and__1927000168__auto____5_6 = tmp17.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), A_arbace_j2g_model_A_const_214.Invoke_O__O(node__1)); if jrt.J2g_Truth(and__1927000168__auto____5_6) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(n__0, A_arbace_j2g_model_A_const_215.Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____5_6 } }
//line :473:1
	case 29: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_213) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 30: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_216) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 34: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_217) {




		var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A_New(); var tmp22 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A_fn_class = fncls__29d; tmp22 = fncls__29d } else { tmp22 = fncls__29 }; return tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), A_arbace_j2g_model_A_const_221.Invoke_O__O(node__1)) }
//line :473:1
	case 39: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_218) { var and__1927000168__auto____5_7 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A_New_O_O(n__0, seen__2); var tmp25 *jrt.Class
		var fncls__30 /*line :473:1*/*jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A_fn_class








		if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A_fn_class = fncls__30d; tmp25 = fncls__30d } else { tmp25 = fncls__30 }; and__1927000168__auto____5_7 = tmp23.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil), A_arbace_j2g_model_A_const_191.Invoke_O__O(node__1)); if jrt.J2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool = lang.Util_Identical_O_O__Z(A_arbace_j2g_model_A_const_219.Invoke_O__O(node__1), nil); if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z(Lit_14, A_arbace_j2g_model_A_const_168.Invoke_O__O(node__1))

			if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z(A_arbace_j2g_model_A_const_168.Invoke_O__O(node__1), n__0)
				if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { and__1927000168__auto____8 = lang.IFn_Cast(A_arbace_j2g_model_A_const_176.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_168.Invoke_O__O(node__1)) }; if jrt.J2g_Truth(and__1927000168__auto____8) {
					return lang.IFn_Cast(A_arbace_j2g_model_A_const_186.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, A_arbace_j2g_model_A_const_168.Invoke_O__O(node__1), A_arbace_j2g_model_A_const_192.Invoke_O__O(node__1), seen__2) } else {
//line :485:1
						return and__1927000168__auto____8 } } } else {
//line :482:1
							return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :473:1
	case 43: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_222) { var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_224); var and__1927000168__auto____5_8 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(tmp26.Invoke_O__O(A_arbace_j2g_model_A_const_225.Invoke_O__O(node__1)))



















		if jrt.J2g_Truth(and__1927000168__auto____5_8) { var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_116.GetRawRoot__O()); var tmp28 any = A_arbace_j2g_model_A_const_226; var and__1927000168__auto____6_6 any = tmp27.Invoke_O_O__O(tmp28, A_arbace_j2g_model_A_const_227.Invoke_O__O(node__1)); if jrt.J2g_Truth(and__1927000168__auto____6_6) { var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A_New_O_O(n__0, seen__2); var tmp31 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A_fn_class = fncls__31d; tmp31 = fncls__31d } else { tmp31 = fncls__31 }; return tmp29.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil), A_arbace_j2g_model_A_const_191.Invoke_O__O(node__1)) } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :473:1
	case 44: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_223) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 46: if any(G__1479000147__4_) == any(A_arbace_j2g_model_A_const_228) {



		var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A_New_O_O(n__0, seen__2); var tmp34 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A_fn_class = fncls__32d; tmp34 = fncls__32d } else { tmp34 = fncls__32 }; return tmp32.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil), A_arbace_j2g_model_A_const_229.Invoke_O__O(node__1)) }
//line :473:1
	default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :475:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :475:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A) Invoke_O_O__O(self, p1__1479000141_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1479000141_SHARP___1, t.F_seen) }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A{}; t.Ctor_O_O(p0, p1); return t }
//line :476:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :476:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A) Invoke_O_O__O(self, p__1479000150__1 any) any { var vec__1479000152__2 any = p__1479000150__1; var ___3 any = lang.RT_Nth_O_I_O__O(vec__1479000152__2, lang.RT_IntCast_J__I(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O(vec__1479000152__2, lang.RT_IntCast_J__I(1), nil); _ = ___3; return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, init__4, t.F_seen) }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A{}; t.Ctor_O_O(p0, p1); return t }
//line :477:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :477:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A) Invoke_O_O__O(self, p1__1479000142_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1479000142_SHARP___1, t.F_seen) }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A_New() *A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A) Ctor() {}
//line :478:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A) Invoke_O_O__O(self, p1__1479000143_SHARP___1 any) any { var tmp1 any = A_arbace_j2g_model_A_const_213; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_j2g_model_A_const_194.Invoke_O__O(p1__1479000143_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_220.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_208.Invoke_O__O(p1__1479000143_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____3) { return lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(lang.RT_LongCast_O__J(A_arbace_j2g_model_A_const_208.Invoke_O__O(p1__1479000143_SHARP___1)))).Ref()) } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A{}; t.Ctor_O_O(p0, p1); return t }
//line :482:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :482:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A) Invoke_O_O__O(self, p1__1479000144_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1479000144_SHARP___1, t.F_seen) }








func A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :491:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :491:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A) Invoke_O_O__O(self, p1__1479000145_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1479000145_SHARP___1, t.F_seen) }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :493:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :493:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A) Invoke_O_O__O(self, p1__1479000146_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1479000146_SHARP___1, t.F_seen) }


func A_arbace_j2g_model_benign_init_QMARK__A_New() *A_arbace_j2g_model_benign_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Ctor() {}
//line :496:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_175; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_31.Get__O()); var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_231, n__0); if








	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_32.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(cache__2), k__3)) {
		return lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(cache__2), k__3) } else {
//line :505:1
			var r__4 any

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_176.GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); r__4 = jrt.Boolean_TRUE.Ref() } else { if lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0), nil) { jrt.Boolean_Init(); r__4 = jrt.Boolean_FALSE.Ref() } else { if A_arbace_j2g_model_A_const_56 != nil { var d__4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_37.GetRawRoot__O()).Invoke_O__O(n__0); var st__5 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_177.Invoke_O__O(d__4)); var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_179.Invoke_O__O(st__5))




				if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_180.Invoke_O__O(st__5)); if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_181.Invoke_O__O(st__5)); if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z(A_arbace_j2g_model_A_const_79.Invoke_O__O(d__4), nil)


					if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9).Ref() } else { and__1927000168__auto____9 = lang.IFn_Cast(A_arbace_j2g_model_A_const_230.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_79.Invoke_O__O(d__4)) }
//line :512:1
					if jrt.J2g_Truth(and__1927000168__auto____9) {



						var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_42.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A_New_O(n__0); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; r__4 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), A_arbace_j2g_model_A_const_178.Invoke_O__O(st__5)) } else {
//line :512:1
							r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :507:1
								r__4 = nil
							}
			}
			}






			lang.IFn_Cast(A_arbace_j2g_model_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O__O(cache__2, A_arbace_j2g_model_A_const_147.GetRawRoot__O(), k__3, r__4)
//line :505:1
			return r__4 } }










func A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A_New_O(p0 any) *A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A{}; t.Ctor_O(p0); return t }
//line :516:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :516:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A) Invoke_O_O__O(self, p1__1479000167_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_188.GetRawRoot__O()); var tmp2 any = t.F_n; var tmp3 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp3 = lang.PersistentHashSet_EMPTY; return tmp1.Invoke_O_O_O__O(tmp2, p1__1479000167_SHARP___1, tmp3.Ref()) }
























































type A_arbace_j2g_model_A struct{ jrt.Object }

var A_arbace_j2g_model_A_const_pool *jrt.RefArray

var A_arbace_j2g_model_A_const_0 *lang.Var

var A_arbace_j2g_model_A_const_1 *lang.Var

var A_arbace_j2g_model_A_const_2 any

var A_arbace_j2g_model_A_const_3 any

var A_arbace_j2g_model_A_const_4 any

var A_arbace_j2g_model_A_const_5 any

var A_arbace_j2g_model_A_const_6 any

var A_arbace_j2g_model_A_const_7 any

var A_arbace_j2g_model_A_const_8 any

var A_arbace_j2g_model_A_const_9 any

var A_arbace_j2g_model_A_const_10 *lang.Var

var A_arbace_j2g_model_A_const_11 *lang.Var

var A_arbace_j2g_model_A_const_12 *lang.Var

var A_arbace_j2g_model_A_const_13 any

var A_arbace_j2g_model_A_const_14 *lang.Var

var A_arbace_j2g_model_A_const_15 *lang.Var

var A_arbace_j2g_model_A_const_16 *lang.Var

var A_arbace_j2g_model_A_const_17 *lang.Var

var A_arbace_j2g_model_A_const_18 *lang.Var

var A_arbace_j2g_model_A_const_19 *lang.Var

var A_arbace_j2g_model_A_const_20 *lang.Var

var A_arbace_j2g_model_A_const_21 *lang.Var

var A_arbace_j2g_model_A_const_22 *lang.Var

var A_arbace_j2g_model_A_const_23 *lang.Var

var A_arbace_j2g_model_A_const_24 any

var A_arbace_j2g_model_A_const_25 *lang.Var

var A_arbace_j2g_model_A_const_26 *lang.Var

var A_arbace_j2g_model_A_const_27 *lang.Var

var A_arbace_j2g_model_A_const_28 *lang.Var

var A_arbace_j2g_model_A_const_29 any

var A_arbace_j2g_model_A_const_30 *lang.Keyword

var A_arbace_j2g_model_A_const_31 *lang.Var

var A_arbace_j2g_model_A_const_32 *lang.Var

var A_arbace_j2g_model_A_const_33 *lang.Var

var A_arbace_j2g_model_A_const_34 *lang.Var

var A_arbace_j2g_model_A_const_35 *lang.Keyword

var A_arbace_j2g_model_A_const_36 *lang.Var

var A_arbace_j2g_model_A_const_37 *lang.Var

var A_arbace_j2g_model_A_const_38 *lang.Var

var A_arbace_j2g_model_A_const_39 *lang.Var

var A_arbace_j2g_model_A_const_40 *lang.Var

var A_arbace_j2g_model_A_const_41 *lang.Var

var A_arbace_j2g_model_A_const_42 *lang.Var

var A_arbace_j2g_model_A_const_43 *lang.Var

var A_arbace_j2g_model_A_const_44 *lang.Var

var A_arbace_j2g_model_A_const_45 *lang.Var

var A_arbace_j2g_model_A_const_46 *lang.Keyword

var A_arbace_j2g_model_A_const_47 any

var A_arbace_j2g_model_A_const_48 *lang.Keyword

var A_arbace_j2g_model_A_const_49 *lang.Var

var A_arbace_j2g_model_A_const_50 *lang.Var

var A_arbace_j2g_model_A_const_51 *lang.Keyword

var A_arbace_j2g_model_A_const_52 *lang.Var

var A_arbace_j2g_model_A_const_53 *lang.Var

var A_arbace_j2g_model_A_const_54 *lang.Var

var A_arbace_j2g_model_A_const_55 *lang.Var

var A_arbace_j2g_model_A_const_56 *lang.Keyword

var A_arbace_j2g_model_A_const_57 *lang.Var

var A_arbace_j2g_model_A_const_58 *lang.Var

var A_arbace_j2g_model_A_const_59 *lang.Var

var A_arbace_j2g_model_A_const_60 *lang.Var

var A_arbace_j2g_model_A_const_61 *lang.Var

var A_arbace_j2g_model_A_const_62 *lang.Var

var A_arbace_j2g_model_A_const_63 *lang.Var

var A_arbace_j2g_model_A_const_64 *lang.Var

var A_arbace_j2g_model_A_const_65 *lang.Var

var A_arbace_j2g_model_A_const_66 *lang.Var

var A_arbace_j2g_model_A_const_67 *lang.Keyword

var A_arbace_j2g_model_A_const_68 *lang.Var

var A_arbace_j2g_model_A_const_69 *lang.Keyword

var A_arbace_j2g_model_A_const_70 *lang.Var

var A_arbace_j2g_model_A_const_71 *lang.Var

var A_arbace_j2g_model_A_const_72 *lang.Var

var A_arbace_j2g_model_A_const_73 any

var A_arbace_j2g_model_A_const_74 any

var A_arbace_j2g_model_A_const_75 *lang.Keyword

var A_arbace_j2g_model_A_const_76 *lang.Var

var A_arbace_j2g_model_A_const_77 *lang.Var

var A_arbace_j2g_model_A_const_78 *lang.Var

var A_arbace_j2g_model_A_const_79 *lang.Keyword

var A_arbace_j2g_model_A_const_80 *lang.Var

var A_arbace_j2g_model_A_const_81 *lang.Var

var A_arbace_j2g_model_A_const_82 *lang.Var

var A_arbace_j2g_model_A_const_83 *lang.Var

var A_arbace_j2g_model_A_const_84 *lang.Var

var A_arbace_j2g_model_A_const_85 *lang.Var

var A_arbace_j2g_model_A_const_86 *lang.Var

var A_arbace_j2g_model_A_const_87 *lang.Var

var A_arbace_j2g_model_A_const_88 *lang.Keyword

var A_arbace_j2g_model_A_const_89 *lang.Keyword

var A_arbace_j2g_model_A_const_90 *lang.Var

var A_arbace_j2g_model_A_const_91 *lang.Var

var A_arbace_j2g_model_A_const_92 *lang.Var

var A_arbace_j2g_model_A_const_93 *lang.Var

var A_arbace_j2g_model_A_const_94 *lang.Var

var A_arbace_j2g_model_A_const_95 *lang.Var

var A_arbace_j2g_model_A_const_96 *lang.Var

var A_arbace_j2g_model_A_const_97 *lang.Var

var A_arbace_j2g_model_A_const_98 *lang.Var

var A_arbace_j2g_model_A_const_99 *lang.Var

var A_arbace_j2g_model_A_const_100 *lang.Keyword

var A_arbace_j2g_model_A_const_101 any

var A_arbace_j2g_model_A_const_102 *lang.Var

var A_arbace_j2g_model_A_const_103 any

var A_arbace_j2g_model_A_const_104 *lang.Var

var A_arbace_j2g_model_A_const_105 *lang.Var

var A_arbace_j2g_model_A_const_106 any

var A_arbace_j2g_model_A_const_107 *lang.Var

var A_arbace_j2g_model_A_const_108 *lang.Var

var A_arbace_j2g_model_A_const_109 any

var A_arbace_j2g_model_A_const_110 *lang.Var

var A_arbace_j2g_model_A_const_111 *lang.Var

var A_arbace_j2g_model_A_const_112 any

var A_arbace_j2g_model_A_const_113 any

var A_arbace_j2g_model_A_const_114 *lang.Var

var A_arbace_j2g_model_A_const_115 *lang.Keyword

var A_arbace_j2g_model_A_const_116 *lang.Var

var A_arbace_j2g_model_A_const_117 *lang.Var

var A_arbace_j2g_model_A_const_118 *lang.Var

var A_arbace_j2g_model_A_const_119 any

var A_arbace_j2g_model_A_const_120 any

var A_arbace_j2g_model_A_const_121 *lang.Keyword

var A_arbace_j2g_model_A_const_122 *lang.Keyword

var A_arbace_j2g_model_A_const_123 *lang.Var

var A_arbace_j2g_model_A_const_124 *lang.Var

var A_arbace_j2g_model_A_const_125 *lang.Var

var A_arbace_j2g_model_A_const_126 *lang.Var

var A_arbace_j2g_model_A_const_127 *lang.Var

var A_arbace_j2g_model_A_const_128 *lang.Var

var A_arbace_j2g_model_A_const_129 *lang.Var

var A_arbace_j2g_model_A_const_130 *lang.Var

var A_arbace_j2g_model_A_const_131 *lang.Var

var A_arbace_j2g_model_A_const_132 *lang.Var

var A_arbace_j2g_model_A_const_133 *lang.Var

var A_arbace_j2g_model_A_const_134 *lang.Var

var A_arbace_j2g_model_A_const_135 *lang.Var

var A_arbace_j2g_model_A_const_136 *lang.Keyword

var A_arbace_j2g_model_A_const_137 *lang.Var

var A_arbace_j2g_model_A_const_138 any

var A_arbace_j2g_model_A_const_139 *lang.Var

var A_arbace_j2g_model_A_const_140 *lang.Var

var A_arbace_j2g_model_A_const_141 *lang.Var

var A_arbace_j2g_model_A_const_142 *lang.Var

var A_arbace_j2g_model_A_const_143 *lang.Var

var A_arbace_j2g_model_A_const_144 *lang.Var

var A_arbace_j2g_model_A_const_145 *lang.Var

var A_arbace_j2g_model_A_const_146 *lang.Var

var A_arbace_j2g_model_A_const_147 *lang.Var

var A_arbace_j2g_model_A_const_148 *lang.Keyword

var A_arbace_j2g_model_A_const_149 *lang.Var

var A_arbace_j2g_model_A_const_150 *lang.Var

var A_arbace_j2g_model_A_const_151 *lang.Var

var A_arbace_j2g_model_A_const_152 *lang.Var

var A_arbace_j2g_model_A_const_153 *lang.Var

var A_arbace_j2g_model_A_const_154 *lang.Keyword

var A_arbace_j2g_model_A_const_155 *lang.Var

var A_arbace_j2g_model_A_const_156 *lang.Var

var A_arbace_j2g_model_A_const_157 *lang.Var

var A_arbace_j2g_model_A_const_158 *lang.Var

var A_arbace_j2g_model_A_const_159 *lang.Var

var A_arbace_j2g_model_A_const_160 *lang.Var

var A_arbace_j2g_model_A_const_161 *lang.Var

var A_arbace_j2g_model_A_const_162 *lang.Keyword

var A_arbace_j2g_model_A_const_163 *lang.Keyword

var A_arbace_j2g_model_A_const_164 *lang.Keyword

var A_arbace_j2g_model_A_const_165 *lang.Keyword

var A_arbace_j2g_model_A_const_166 *lang.Keyword

var A_arbace_j2g_model_A_const_167 *lang.Keyword

var A_arbace_j2g_model_A_const_168 *lang.Keyword

var A_arbace_j2g_model_A_const_169 *lang.Var

var A_arbace_j2g_model_A_const_170 *lang.Var

var A_arbace_j2g_model_A_const_171 *lang.Keyword

var A_arbace_j2g_model_A_const_172 *lang.Keyword

var A_arbace_j2g_model_A_const_173 *lang.Var

var A_arbace_j2g_model_A_const_174 any

var A_arbace_j2g_model_A_const_175 *lang.Keyword

var A_arbace_j2g_model_A_const_176 *lang.Var

var A_arbace_j2g_model_A_const_177 *lang.Keyword

var A_arbace_j2g_model_A_const_178 *lang.Keyword

var A_arbace_j2g_model_A_const_179 *lang.Keyword

var A_arbace_j2g_model_A_const_180 *lang.Keyword

var A_arbace_j2g_model_A_const_181 *lang.Keyword

var A_arbace_j2g_model_A_const_182 *lang.Keyword

var A_arbace_j2g_model_A_const_183 *lang.Var

var A_arbace_j2g_model_A_const_184 *lang.Keyword

var A_arbace_j2g_model_A_const_185 any

var A_arbace_j2g_model_A_const_186 *lang.Var

var A_arbace_j2g_model_A_const_187 *lang.Keyword

var A_arbace_j2g_model_A_const_188 *lang.Var

var A_arbace_j2g_model_A_const_189 *lang.Keyword

var A_arbace_j2g_model_A_const_190 *lang.Keyword

var A_arbace_j2g_model_A_const_191 *lang.Keyword

var A_arbace_j2g_model_A_const_192 *lang.Keyword

var A_arbace_j2g_model_A_const_193 *lang.Keyword

var A_arbace_j2g_model_A_const_194 *lang.Keyword

var A_arbace_j2g_model_A_const_195 *lang.Keyword

var A_arbace_j2g_model_A_const_196 *lang.Keyword

var A_arbace_j2g_model_A_const_197 *lang.Keyword

var A_arbace_j2g_model_A_const_198 *lang.Keyword

var A_arbace_j2g_model_A_const_199 *lang.Keyword

var A_arbace_j2g_model_A_const_200 *lang.Keyword

var A_arbace_j2g_model_A_const_201 *lang.Keyword

var A_arbace_j2g_model_A_const_202 *lang.Keyword

var A_arbace_j2g_model_A_const_203 *lang.Keyword

var A_arbace_j2g_model_A_const_204 *lang.Keyword

var A_arbace_j2g_model_A_const_205 *lang.Keyword

var A_arbace_j2g_model_A_const_206 *lang.Keyword

var A_arbace_j2g_model_A_const_207 *lang.Keyword

var A_arbace_j2g_model_A_const_208 *lang.Keyword

var A_arbace_j2g_model_A_const_209 *lang.Keyword

var A_arbace_j2g_model_A_const_210 *lang.Keyword

var A_arbace_j2g_model_A_const_211 *lang.Keyword

var A_arbace_j2g_model_A_const_212 *lang.Keyword

var A_arbace_j2g_model_A_const_213 *lang.Keyword

var A_arbace_j2g_model_A_const_214 *lang.Keyword

var A_arbace_j2g_model_A_const_215 *lang.Keyword

var A_arbace_j2g_model_A_const_216 *lang.Keyword

var A_arbace_j2g_model_A_const_217 *lang.Keyword

var A_arbace_j2g_model_A_const_218 *lang.Keyword

var A_arbace_j2g_model_A_const_219 *lang.Keyword

var A_arbace_j2g_model_A_const_220 *lang.Var

var A_arbace_j2g_model_A_const_221 *lang.Keyword

var A_arbace_j2g_model_A_const_222 *lang.Keyword

var A_arbace_j2g_model_A_const_223 *lang.Keyword

var A_arbace_j2g_model_A_const_224 any

var A_arbace_j2g_model_A_const_225 *lang.Keyword

var A_arbace_j2g_model_A_const_226 *lang.Keyword

var A_arbace_j2g_model_A_const_227 *lang.Keyword

var A_arbace_j2g_model_A_const_228 *lang.Keyword

var A_arbace_j2g_model_A_const_229 *lang.Keyword

var A_arbace_j2g_model_A_const_230 *lang.Var

var A_arbace_j2g_model_A_const_231 *lang.Keyword

var A_arbace_j2g_model_A_init jrt.ClassInit

func A_arbace_j2g_model_A_Init() { if !A_arbace_j2g_model_A_init.Done() { A_arbace_j2g_model_A_init.Run(A_arbace_j2g_model_A_clinit) } }

func A_arbace_j2g_model_A_clinit() { A_arbace_j2g_model_A_clinit_p0(); A_arbace_j2g_model_A_clinit_p1(); A_arbace_j2g_model_A_clinit_p2(); A_arbace_j2g_model_A_clinit_p3(); A_arbace_j2g_model_A_clinit_p4(); A_arbace_j2g_model_A_clinit_p5(); A_arbace_j2g_model_A_clinit_p6(); A_arbace_j2g_model_A_clinit_p7(); A_arbace_j2g_model_A_clinit_p8(); A_arbace_j2g_model_A_clinit_p9(); A_arbace_j2g_model_A_clinit_p10(); A_arbace_j2g_model_A_clinit_p11(); A_arbace_j2g_model_A_clinit_p12(); A_arbace_j2g_model_A_clinit_p13(); A_arbace_j2g_model_A_clinit_p14(); A_arbace_j2g_model_A_clinit_p15(); A_arbace_j2g_model_A_clinit_p16(); A_arbace_j2g_model_A_clinit_p17(); A_arbace_j2g_model_A_clinit_p18(); A_arbace_j2g_model_A_clinit_p19() }

func A_arbace_j2g_model_A_clinit_p0() { A_arbace_j2g_model_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 330); A_arbace_j2g_model_A_const_0 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[98]); A_arbace_j2g_model_A_const_1 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[99]); A_arbace_j2g_model_A_const_2 = A_arbace_j2g_model_A_const_pool.A[100]; A_arbace_j2g_model_A_const_3 = A_arbace_j2g_model_A_const_pool.A[101]; A_arbace_j2g_model_A_const_4 = A_arbace_j2g_model_A_const_pool.A[102]; A_arbace_j2g_model_A_const_5 = A_arbace_j2g_model_A_const_pool.A[103]; A_arbace_j2g_model_A_const_6 = A_arbace_j2g_model_A_const_pool.A[104]; A_arbace_j2g_model_A_const_7 = A_arbace_j2g_model_A_const_pool.A[105]; A_arbace_j2g_model_A_const_8 = A_arbace_j2g_model_A_const_pool.A[106]; A_arbace_j2g_model_A_const_9 = A_arbace_j2g_model_A_const_pool.A[107]; A_arbace_j2g_model_A_const_10 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[108]); A_arbace_j2g_model_A_const_11 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[109]); A_arbace_j2g_model_A_const_12 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[110]) }

func A_arbace_j2g_model_A_clinit_p1() { A_arbace_j2g_model_A_const_13 = A_arbace_j2g_model_A_const_pool.A[111]; A_arbace_j2g_model_A_const_14 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[112]); A_arbace_j2g_model_A_const_15 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[113]); A_arbace_j2g_model_A_const_16 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[114]); A_arbace_j2g_model_A_const_17 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[115]); A_arbace_j2g_model_A_const_18 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[116]); A_arbace_j2g_model_A_const_19 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[117]); A_arbace_j2g_model_A_const_20 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[118]); A_arbace_j2g_model_A_const_21 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[119]); A_arbace_j2g_model_A_const_22 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[120]); A_arbace_j2g_model_A_const_23 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[121]); A_arbace_j2g_model_A_const_24 = A_arbace_j2g_model_A_const_pool.A[122] }

func A_arbace_j2g_model_A_clinit_p2() { A_arbace_j2g_model_A_const_25 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[123]); A_arbace_j2g_model_A_const_26 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[124]); A_arbace_j2g_model_A_const_27 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[125]); A_arbace_j2g_model_A_const_28 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[126]); A_arbace_j2g_model_A_const_29 = A_arbace_j2g_model_A_const_pool.A[127]; A_arbace_j2g_model_A_const_30 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[128]); A_arbace_j2g_model_A_const_31 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[129]); A_arbace_j2g_model_A_const_32 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[130]); A_arbace_j2g_model_A_const_33 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[131]); A_arbace_j2g_model_A_const_34 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[132]); A_arbace_j2g_model_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[133]); A_arbace_j2g_model_A_const_36 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[134]) }

func A_arbace_j2g_model_A_clinit_p3() { A_arbace_j2g_model_A_const_37 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[135]); A_arbace_j2g_model_A_const_38 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[136]); A_arbace_j2g_model_A_const_39 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[137]); A_arbace_j2g_model_A_const_40 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[138]); A_arbace_j2g_model_A_const_41 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[139]); A_arbace_j2g_model_A_const_42 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[140]); A_arbace_j2g_model_A_const_43 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[141]); A_arbace_j2g_model_A_const_44 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[142]); A_arbace_j2g_model_A_const_45 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[143]); A_arbace_j2g_model_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[144]); A_arbace_j2g_model_A_const_47 = A_arbace_j2g_model_A_const_pool.A[145]; A_arbace_j2g_model_A_const_48 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[146]) }

func A_arbace_j2g_model_A_clinit_p4() { A_arbace_j2g_model_A_const_49 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[147]); A_arbace_j2g_model_A_const_50 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[148]); A_arbace_j2g_model_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[149]); A_arbace_j2g_model_A_const_52 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[150]); A_arbace_j2g_model_A_const_53 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[151]); A_arbace_j2g_model_A_const_54 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[152]); A_arbace_j2g_model_A_const_55 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[153]); A_arbace_j2g_model_A_const_56 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[154]); A_arbace_j2g_model_A_const_57 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[155]); A_arbace_j2g_model_A_const_58 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[156]); A_arbace_j2g_model_A_const_59 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[157]); A_arbace_j2g_model_A_const_60 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[158]) }

func A_arbace_j2g_model_A_clinit_p5() { A_arbace_j2g_model_A_const_61 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[159]); A_arbace_j2g_model_A_const_62 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[160]); A_arbace_j2g_model_A_const_63 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[161]); A_arbace_j2g_model_A_const_64 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[162]); A_arbace_j2g_model_A_const_65 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[163]); A_arbace_j2g_model_A_const_66 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[164]); A_arbace_j2g_model_A_const_67 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[165]); A_arbace_j2g_model_A_const_68 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[166]); A_arbace_j2g_model_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[167]); A_arbace_j2g_model_A_const_70 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[168]); A_arbace_j2g_model_A_const_71 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[169]); A_arbace_j2g_model_A_const_72 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[170]) }

func A_arbace_j2g_model_A_clinit_p6() { A_arbace_j2g_model_A_const_73 = A_arbace_j2g_model_A_const_pool.A[171]; A_arbace_j2g_model_A_const_74 = A_arbace_j2g_model_A_const_pool.A[172]; A_arbace_j2g_model_A_const_75 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[173]); A_arbace_j2g_model_A_const_76 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[174]); A_arbace_j2g_model_A_const_77 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[175]); A_arbace_j2g_model_A_const_78 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[176]); A_arbace_j2g_model_A_const_79 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[177]); A_arbace_j2g_model_A_const_80 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[178]); A_arbace_j2g_model_A_const_81 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[179]); A_arbace_j2g_model_A_const_82 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[180]); A_arbace_j2g_model_A_const_83 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[181]); A_arbace_j2g_model_A_const_84 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[182]) }

func A_arbace_j2g_model_A_clinit_p7() { A_arbace_j2g_model_A_const_85 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[183]); A_arbace_j2g_model_A_const_86 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[184]); A_arbace_j2g_model_A_const_87 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[185]); A_arbace_j2g_model_A_const_88 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[186]); A_arbace_j2g_model_A_const_89 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[187]); A_arbace_j2g_model_A_const_90 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[188]); A_arbace_j2g_model_A_const_91 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[189]); A_arbace_j2g_model_A_const_92 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[190]); A_arbace_j2g_model_A_const_93 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[191]); A_arbace_j2g_model_A_const_94 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[192]); A_arbace_j2g_model_A_const_95 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[193]); A_arbace_j2g_model_A_const_96 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[194]) }

func A_arbace_j2g_model_A_clinit_p8() { A_arbace_j2g_model_A_const_97 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[195]); A_arbace_j2g_model_A_const_98 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[196]); A_arbace_j2g_model_A_const_99 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[197]); A_arbace_j2g_model_A_const_100 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[198]); A_arbace_j2g_model_A_const_101 = A_arbace_j2g_model_A_const_pool.A[199]; A_arbace_j2g_model_A_const_102 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[200]); A_arbace_j2g_model_A_const_103 = A_arbace_j2g_model_A_const_pool.A[201]; A_arbace_j2g_model_A_const_104 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[202]); A_arbace_j2g_model_A_const_105 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[203]); A_arbace_j2g_model_A_const_106 = A_arbace_j2g_model_A_const_pool.A[204]; A_arbace_j2g_model_A_const_107 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[205]); A_arbace_j2g_model_A_const_108 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[206]); A_arbace_j2g_model_A_const_109 = A_arbace_j2g_model_A_const_pool.A[207] }

func A_arbace_j2g_model_A_clinit_p9() { A_arbace_j2g_model_A_const_110 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[208]); A_arbace_j2g_model_A_const_111 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[209]); A_arbace_j2g_model_A_const_112 = A_arbace_j2g_model_A_const_pool.A[210]; A_arbace_j2g_model_A_const_113 = A_arbace_j2g_model_A_const_pool.A[211]; A_arbace_j2g_model_A_const_114 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[212]); A_arbace_j2g_model_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[213]); A_arbace_j2g_model_A_const_116 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[214]); A_arbace_j2g_model_A_const_117 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[215]); A_arbace_j2g_model_A_const_118 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[216]); A_arbace_j2g_model_A_const_119 = A_arbace_j2g_model_A_const_pool.A[217]; A_arbace_j2g_model_A_const_120 = A_arbace_j2g_model_A_const_pool.A[218]; A_arbace_j2g_model_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[219]); A_arbace_j2g_model_A_const_122 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[220]) }

func A_arbace_j2g_model_A_clinit_p10() { A_arbace_j2g_model_A_const_123 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[221]); A_arbace_j2g_model_A_const_124 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[222]); A_arbace_j2g_model_A_const_125 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[223]); A_arbace_j2g_model_A_const_126 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[224]); A_arbace_j2g_model_A_const_127 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[225]); A_arbace_j2g_model_A_const_128 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[226]); A_arbace_j2g_model_A_const_129 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[227]); A_arbace_j2g_model_A_const_130 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[228]); A_arbace_j2g_model_A_const_131 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[229]); A_arbace_j2g_model_A_const_132 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[230]); A_arbace_j2g_model_A_const_133 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[231]); A_arbace_j2g_model_A_const_134 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[232]) }

func A_arbace_j2g_model_A_clinit_p11() { A_arbace_j2g_model_A_const_135 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[233]); A_arbace_j2g_model_A_const_136 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[234]); A_arbace_j2g_model_A_const_137 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[235]); A_arbace_j2g_model_A_const_138 = A_arbace_j2g_model_A_const_pool.A[236]; A_arbace_j2g_model_A_const_139 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[237]); A_arbace_j2g_model_A_const_140 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[238]); A_arbace_j2g_model_A_const_141 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[239]); A_arbace_j2g_model_A_const_142 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[240]); A_arbace_j2g_model_A_const_143 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[241]); A_arbace_j2g_model_A_const_144 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[242]); A_arbace_j2g_model_A_const_145 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[243]); A_arbace_j2g_model_A_const_146 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[244]) }

func A_arbace_j2g_model_A_clinit_p12() { A_arbace_j2g_model_A_const_147 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[245]); A_arbace_j2g_model_A_const_148 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[246]); A_arbace_j2g_model_A_const_149 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[247]); A_arbace_j2g_model_A_const_150 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[248]); A_arbace_j2g_model_A_const_151 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[249]); A_arbace_j2g_model_A_const_152 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[250]); A_arbace_j2g_model_A_const_153 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[251]); A_arbace_j2g_model_A_const_154 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[252]); A_arbace_j2g_model_A_const_155 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[253]); A_arbace_j2g_model_A_const_156 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[254]); A_arbace_j2g_model_A_const_157 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[255]); A_arbace_j2g_model_A_const_158 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[256]) }

func A_arbace_j2g_model_A_clinit_p13() { A_arbace_j2g_model_A_const_159 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[257]); A_arbace_j2g_model_A_const_160 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[258]); A_arbace_j2g_model_A_const_161 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[259]); A_arbace_j2g_model_A_const_162 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[260]); A_arbace_j2g_model_A_const_163 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[261]); A_arbace_j2g_model_A_const_164 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[262]); A_arbace_j2g_model_A_const_165 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[263]); A_arbace_j2g_model_A_const_166 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[264]); A_arbace_j2g_model_A_const_167 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[265]); A_arbace_j2g_model_A_const_168 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[266]); A_arbace_j2g_model_A_const_169 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[267]); A_arbace_j2g_model_A_const_170 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[268]) }

func A_arbace_j2g_model_A_clinit_p14() { A_arbace_j2g_model_A_const_171 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[269]); A_arbace_j2g_model_A_const_172 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[270]); A_arbace_j2g_model_A_const_173 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[271]); A_arbace_j2g_model_A_const_174 = A_arbace_j2g_model_A_const_pool.A[272]; A_arbace_j2g_model_A_const_175 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[273]); A_arbace_j2g_model_A_const_176 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[274]); A_arbace_j2g_model_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[275]); A_arbace_j2g_model_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[276]); A_arbace_j2g_model_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[277]); A_arbace_j2g_model_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[278]); A_arbace_j2g_model_A_const_181 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[279]); A_arbace_j2g_model_A_const_182 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[280]) }

func A_arbace_j2g_model_A_clinit_p15() { A_arbace_j2g_model_A_const_183 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[281]); A_arbace_j2g_model_A_const_184 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[282]); A_arbace_j2g_model_A_const_185 = A_arbace_j2g_model_A_const_pool.A[283]; A_arbace_j2g_model_A_const_186 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[284]); A_arbace_j2g_model_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[285]); A_arbace_j2g_model_A_const_188 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[286]); A_arbace_j2g_model_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[287]); A_arbace_j2g_model_A_const_190 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[288]); A_arbace_j2g_model_A_const_191 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[289]); A_arbace_j2g_model_A_const_192 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[290]); A_arbace_j2g_model_A_const_193 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[291]); A_arbace_j2g_model_A_const_194 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[292]) }

func A_arbace_j2g_model_A_clinit_p16() { A_arbace_j2g_model_A_const_195 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[293]); A_arbace_j2g_model_A_const_196 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[294]); A_arbace_j2g_model_A_const_197 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[295]); A_arbace_j2g_model_A_const_198 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[296]); A_arbace_j2g_model_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[297]); A_arbace_j2g_model_A_const_200 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[298]); A_arbace_j2g_model_A_const_201 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[299]); A_arbace_j2g_model_A_const_202 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[300]); A_arbace_j2g_model_A_const_203 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[301]); A_arbace_j2g_model_A_const_204 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[302]); A_arbace_j2g_model_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[303]); A_arbace_j2g_model_A_const_206 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[304]) }

func A_arbace_j2g_model_A_clinit_p17() { A_arbace_j2g_model_A_const_207 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[305]); A_arbace_j2g_model_A_const_208 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[306]); A_arbace_j2g_model_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[307]); A_arbace_j2g_model_A_const_210 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[308]); A_arbace_j2g_model_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[309]); A_arbace_j2g_model_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[310]); A_arbace_j2g_model_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[311]); A_arbace_j2g_model_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[312]); A_arbace_j2g_model_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[313]); A_arbace_j2g_model_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[314]); A_arbace_j2g_model_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[315]); A_arbace_j2g_model_A_const_218 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[316]) }

func A_arbace_j2g_model_A_clinit_p18() { A_arbace_j2g_model_A_const_219 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[317]); A_arbace_j2g_model_A_const_220 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[318]); A_arbace_j2g_model_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[319]); A_arbace_j2g_model_A_const_222 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[320]); A_arbace_j2g_model_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[321]); A_arbace_j2g_model_A_const_224 = A_arbace_j2g_model_A_const_pool.A[322]; A_arbace_j2g_model_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[323]); A_arbace_j2g_model_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[324]); A_arbace_j2g_model_A_const_227 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[325]); A_arbace_j2g_model_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[326]); A_arbace_j2g_model_A_const_229 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[327]); A_arbace_j2g_model_A_const_230 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[328]) }

func A_arbace_j2g_model_A_clinit_p19() { A_arbace_j2g_model_A_const_231 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[329]) }

func A_arbace_j2g_model_A_New() *A_arbace_j2g_model_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_A) Ctor() {}

func (t *A_arbace_j2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_A_class }

func (t *A_arbace_j2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_A); return ok }

func A_arbace_j2g_model_A_Cast(x any) *A_arbace_j2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_A_class)) }; return v }



type A_arbace_j2g_model_T_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_T_A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_m_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_m_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_all_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_benign_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000168_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_code_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_code_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_declared_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A struct{ j2g_header uint64; F_n, F_s__1479000088, F_iter__1479000087 any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A struct{ j2g_header uint64; F_n, F_b__1479000090 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_erased_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000004_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000004_A_New() *A_arbace_j2g_model_eval1479000004_A { t := &A_arbace_j2g_model_eval1479000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000004_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000004_A_class }

func (t *A_arbace_j2g_model_eval1479000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000004_A); return ok }

func A_arbace_j2g_model_eval1479000004_A_Cast(x any) *A_arbace_j2g_model_eval1479000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000004_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000008_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000008_A_New() *A_arbace_j2g_model_eval1479000008_A { t := &A_arbace_j2g_model_eval1479000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000008_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000008_A_class }

func (t *A_arbace_j2g_model_eval1479000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000008_A); return ok }

func A_arbace_j2g_model_eval1479000008_A_Cast(x any) *A_arbace_j2g_model_eval1479000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000008_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000008_fn__1479000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class *jrt.Class



type A_arbace_j2g_model_fields_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fields_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_final_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_final_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_find_method_A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_fn__1479000077_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_find_method_fn__1479000077_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_model_hand_written_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hand_written_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_hw_method_exists_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_iface_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_iface_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_impl_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000112_A struct{ j2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_j2g_model_impl_of_fn__1479000112_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000124_A struct{ j2g_header uint64; F_cands any }

var A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_model_impl_of_fn__1479000124_fn__1479000125_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A struct{ j2g_header uint64; F_iter__1479000114, F_name, F_desc, F_s__1479000115 any }

var A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A struct{ j2g_header uint64; F_name, F_b__1479000117, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_impl_of_iter__1479000114__1479000118_fn__1479000119_fn__1479000120_A_fn_class *jrt.Class



type A_arbace_j2g_model_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_info_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_info_A_fn_class *jrt.Class



type A_arbace_j2g_model_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_method_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_jobs_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jobs_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_leaf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_leaf_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000057_A struct{ j2g_header uint64; F_cache, F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A struct{ j2g_header uint64; F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A_fn_class *jrt.Class



type A_arbace_j2g_model_mdesc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_member_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_member_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_method_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_method_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_methods_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_methods_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_nest_top_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_nest_top_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_par_mapv_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000019_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000019_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_work__1479000017_A struct{ j2g_header uint64; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

var A_arbace_j2g_model_par_mapv_work__1479000017_A_fn_class *jrt.Class



type A_arbace_j2g_model_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_pointer_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_private_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000136_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000138_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000148_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000151_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000156_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000158_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000160_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000162_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000164_A_fn_class *jrt.Class



type A_arbace_j2g_model_qualify_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_qualify_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflected_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflected_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_subclasses_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_subclasses_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_fn__1479000104_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_fn__1479000104_A_fn_class *jrt.Class



type A_arbace_j2g_model_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_top_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_top_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_translatable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translatable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_translated_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translated_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_trivial_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_trivial_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_virtual_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_virtual_member_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000098_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000098_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A_fn_class *jrt.Class



type A_arbace_j2g_model_world_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_world_supertypes_A_fn_class *jrt.Class
