//line aot_arbace_j2g_model.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New() *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_model_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_model_A_const_1, A_arbace_j2g_model_A_const_2, A_arbace_j2g_model_A_const_3, A_arbace_j2g_model_A_const_4, A_arbace_j2g_model_A_const_5, A_arbace_j2g_model_A_const_6, A_arbace_j2g_model_A_const_7, A_arbace_j2g_model_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New() *A_arbace_j2g_model_eval1479000008_fn__1479000009_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000008_fn__1479000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_model_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_model_A_const_14.GetRawRoot__O(), A_arbace_j2g_model_A_const_15) }
























func A_arbace_j2g_model_jobs_A_New() *A_arbace_j2g_model_jobs_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jobs_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_35).Ref(); var tmp1 any; var tmp2 any; var root_26 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_28 lang.IFn; if




	linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = e__1; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_26, arg_29) }; if jrt.J2g_Truth(tmp2) {
		tmp1 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(e__1))).Ref() } else {
			tmp1 = lang.Numbers_Min_O_J__O_NoInit(A_arbace_j2g_model_A_const_17.GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :31:1*/ lang.Numbers_Max_J_O__O_NoInit(1, tmp1) }



func A_arbace_j2g_model_par_mapv_A_New() *A_arbace_j2g_model_par_mapv_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) Ctor() {}
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1479000013__3 any) any { var vec__1479000014__5 any = p__1479000013__3; var order__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000014__5, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__7 any; var root_30 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_32 lang.IFn; if









	linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = xs__2; if linked_31 == nil { xs__7 = ifn_32.Invoke_O__O(arg_33) } else { xs__7 = linked_31.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_30, arg_33) }; var cnt__8 int32 = /*line :35:1*/lang.RT_Count_O__I_NoInit(xs__7); var n__9 any = lang.Numbers_Min_O_J__O_NoInit(n__0, int64(cnt__8)); var order__10 any; if












	jrt.J2g_Truth(order__6) { var root_34 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = order__6; if linked_35 == nil { order__10 = ifn_36.Invoke_O__O(arg_37) } else { order__10 = linked_35.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_34, arg_37) } } else { var root_38 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var root_42 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref(); if linked_43 == nil { arg_41 = ifn_44.Invoke_O__O(arg_45) } else { arg_41 = linked_43.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_42, arg_45) }; if linked_39 == nil { order__10 = ifn_40.Invoke_O__O(arg_41) } else { order__10 = linked_39.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_38, arg_41) } }; var tmp1 bool; var na_46 any = n__9; var na_47 int64 = 1; if
	jrt.Long_InstanceOf(na_46) { var n0_48 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_49 int64 = na_47; tmp1 = n0_48 <= n1_49 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_46, na_47) }; if tmp1 {
		var root_51 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = f__1; var arg_55 any = xs__7; if linked_52 == nil { return ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { return linked_52.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) } } else {
//line :49:1
			var res__11 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref()).Ref(); var last_i__12 any; var root_56 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_58 lang.IFn


			if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = order__10; if linked_57 == nil { last_i__12 = ifn_58.Invoke_O__O(arg_59) } else { last_i__12 = linked_57.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_56, arg_59) }
//line :49:1
			var ___13 any; var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](res__11, jrt.Object_class.ArrayClass()); var tmp3 int32 = lang.RT_IntCast_O__I_NoInit(last_i__12); var tmp4 any; var root_60 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_62 lang.IFn; _ = ___13



			if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_64 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp5 any = A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(f__1, last_i__12, xs__7); var tmp6 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class = fncls__68d; tmp6 = fncls__68d } else { tmp6 = fncls__68 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_65 == nil { arg_63 = ifn_66.Invoke_O__O(arg_67) } else { arg_63 = linked_65.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_64, arg_67) }; if linked_61 == nil { tmp4 = ifn_62.Invoke_O__O(arg_63) } else { tmp4 = linked_61.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_60, arg_63) }; ___13 = lang.RT_Aset_O1_I_O__O_NoInit(tmp2, tmp3, tmp4)
//line :49:1
			var next_i__14 any; var root_69 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_71 lang.IFn




			if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = A_arbace_j2g_model_A_const_24; if linked_70 == nil { next_i__14 = ifn_71.Invoke_O__O(arg_72) } else { next_i__14 = linked_70.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_69, arg_72) }
//line :49:1
			var work__15 any; var tmp7 any = A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__14, xs__7, res__11); var tmp8 *jrt.Class
			var fncls__83 /*line :49:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class





			if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class = fncls__83d; tmp8 = fncls__83d } else { tmp8 = fncls__83 }; work__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :49:1
			var ws__16 any; var root_84 any = A_arbace_j2g_model_A_const_27.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_86 lang.IFn











			if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var root_88 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = n__9; var arg_92 any; var tmp9 any = A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(work__15); var tmp10 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class = fncls__98d; tmp10 = fncls__98d } else { tmp10 = fncls__98 }; arg_92 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_89 == nil { arg_87 = ifn_90.Invoke_O_O__O(arg_91, arg_92) } else { arg_87 = linked_89.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_88, arg_91, arg_92) }; if linked_85 == nil { ws__16 = ifn_86.Invoke_O__O(arg_87) } else { ws__16 = linked_85.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_84, arg_87) }
			var root_103 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var arg_107 any = ws__16; if linked_104 == nil { ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { linked_104.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_103, arg_106, arg_107) }
			var root_99 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = res__11; if linked_100 == nil { return ifn_101.Invoke_O__O(arg_102) } else { return linked_100.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_99, arg_102) } } }
//line :53:1
func A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000017_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000017_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_f; t.F_f = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var t__2 any = t.F_xs; t.F_xs = nil; tmp3 = t__2; var tmp4 any = tmp3; var tmp5 any; var t__3 any = t.F_last_i; t.F_last_i = nil; tmp5 = t__3; return tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_O__I_NoInit(tmp5))) }

func A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_j2g_model_par_mapv_work__1479000019_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_work__1479000019_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Invoke_O__O(self any) any { for { L2: for { var k__1 any; var root_73 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_75 lang.IFn
											if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = t.F_next_i; var arg_77 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); if linked_74 == nil { k__1 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { k__1 = linked_74.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }
											var tmp1 bool; var na_78 any = k__1; var na_79 int64 = lang.Numbers_Dec_J__J_NoInit(int64(t.F_cnt)); if jrt.Long_InstanceOf(na_78) { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = na_79; tmp1 = n0_80 < n1_81 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_78, na_79) }; if tmp1 { var tmp2 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(k__1)); var tmp3 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_res, jrt.Object_class.ArrayClass()); var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any = t.F_xs

		lang.RT_Aset_O1_I_O__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(i__2), tmp4.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(i__2))))
		continue L2 } else {
//line :57:1
			return nil } } }; /*line :55:1*/panic("j2g: unreachable") }





func A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Invoke_O__O(self any) any { var root_93 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any; var tmp1 any = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(t.F_work); var tmp2 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class = fncls__97d; tmp2 = fncls__97d } else { tmp2 = fncls__97 }; arg_96 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_94 == nil { return ifn_95.Invoke_O__O(arg_96) } else { return linked_94.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_93, arg_96) } }
//line :61:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_work; t.F_work = nil; tmp1 = t_; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_j2g_model_has_QMARK__A_New() *A_arbace_j2g_model_has_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Ctor() {}
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_108 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var tmp1 int64; var na_112 any; var or__1927000174__auto____3 any = flags__0; if jrt.J2g_Truth(or__1927000174__auto____3) { na_112 = or__1927000174__auto____3 } else { na_112 = A_arbace_j2g_model_A_const_31 }; var na_113 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_112); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_113) }; tmp2 = tmp3; if tmp2 { var n0_114 int64 = jrt.NN(jrt.Long_Cast(na_112)).LongValue__J(); var n1_115 int64 = jrt.NN(jrt.Long_Cast(na_113)).LongValue__J(); tmp1 = n0_114 & n1_115 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_112, na_113) }; arg_111 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_109 == nil { return ifn_110.Invoke_O__O(arg_111) } else { return linked_109.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_108, arg_111) } }

func A_arbace_j2g_model_T_A_New() *A_arbace_j2g_model_T_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_T_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_j2g_model_T_A) Ctor() {}
//line :69:1
func (t *A_arbace_j2g_model_T_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_32; var x__1 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if lang.IDeref_InstanceOf(x__1) { var root_117 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = x__1; if linked_118 == nil { return ifn_119.Invoke_O__O(arg_120) } else { return linked_118.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_117, arg_120) } } else { return x__1 } }

func A_arbace_j2g_model_translated_QMARK__A_New() *A_arbace_j2g_model_translated_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_121 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var root_126 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_j2g_model_T_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; if linked_127 == nil { arg_124 = ifn_128.Invoke__O() } else { arg_124 = linked_127.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_126) }; var arg_125 any = n__0; if linked_122 == nil { return ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { return linked_122.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } }

func A_arbace_j2g_model_j2g_static_QMARK__A_New() *A_arbace_j2g_model_j2g_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_31); if and__1927000168__auto____3 {





	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(base__1, Lit_32); if and__1927000168__auto____4 {
		var root_129 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = Lit_33; if linked_130 == nil { return ifn_131.Invoke_O__O(arg_132) } else { return linked_130.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_129, arg_132) } } else {
//line :79:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_jrt_class_A_New() *A_arbace_j2g_model_jrt_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Ctor() {}
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
}
func A_arbace_j2g_model_hand_written_QMARK__A_New() *A_arbace_j2g_model_hand_written_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_133 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_135 lang.IFn; if


	linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = n__0; if linked_134 == nil { and__1927000168__auto____2 = ifn_135.Invoke_O__O(arg_136) } else { and__1927000168__auto____2 = linked_134.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_137 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_141 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = n__0; if linked_142 == nil { arg_140 = ifn_143.Invoke_O__O(arg_144) } else { arg_140 = linked_142.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_141, arg_144) }; if linked_138 == nil { return ifn_139.Invoke_O__O(arg_140) } else { return linked_138.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_137, arg_140) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_in_world_QMARK__A_New() *A_arbace_j2g_model_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_20); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var root_145 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = n__0; if linked_146 == nil { or__1927000174__auto____3 = ifn_147.Invoke_O__O(arg_148) } else { or__1927000174__auto____3 = linked_146.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_145, arg_148) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_149 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = n__0; if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_149, arg_152) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }

func A_arbace_j2g_model_translatable_QMARK__A_New() *A_arbace_j2g_model_translatable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var root_153 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = n__0; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_153, arg_156) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_reflectable_interface_QMARK__A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_157 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_159 lang.IFn; if




	linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_161 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = n__0; if linked_162 == nil { arg_160 = ifn_163.Invoke_O__O(arg_164) } else { arg_160 = linked_162.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_161, arg_164) }; if linked_158 == nil { and__1927000168__auto____2 = ifn_159.Invoke_O__O(arg_160) } else { and__1927000168__auto____2 = linked_158.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_157, arg_160) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_165 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_167 lang.IFn
		if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = n__0; var arg_169 any = Lit_57; if linked_166 == nil { or__1927000174__auto____3 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { or__1927000174__auto____3 = linked_166.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_170 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = n__0; var arg_174 any = Lit_58; if linked_171 == nil { or__1927000174__auto____4 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { or__1927000174__auto____4 = linked_171.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; if jrt.J2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_175 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = n__0; var arg_179 any = Lit_59; if linked_176 == nil { or__1927000174__auto____5 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { or__1927000174__auto____5 = linked_176.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_180 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = n__0; var arg_184 any = Lit_60; if linked_181 == nil { or__1927000174__auto____6 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { or__1927000174__auto____6 = linked_181.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; if jrt.J2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			var root_185 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = n__0; var arg_189 any = Lit_61; if linked_186 == nil { and__1927000168__auto____3 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { and__1927000168__auto____3 = linked_186.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_185, arg_188, arg_189) } } } } }
//line :105:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_190 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_192 lang.IFn


			if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_194 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = n__0; var arg_198 any = Lit_62; if linked_195 == nil { arg_193 = ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { arg_193 = linked_195.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_194, arg_197, arg_198) }; if linked_191 == nil { and__1927000168__auto____4 = ifn_192.Invoke_O__O(arg_193) } else { and__1927000168__auto____4 = linked_191.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_190, arg_193) }
//line :105:1
			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_199 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_201 lang.IFn



				if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_203 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = n__0; if linked_204 == nil { arg_202 = ifn_205.Invoke_O__O(arg_206) } else { arg_202 = linked_204.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_203, arg_206) }; if linked_200 == nil { and__1927000168__auto____5 = ifn_201.Invoke_O__O(arg_202) } else { and__1927000168__auto____5 = linked_200.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_199, arg_202) }
//line :105:1
				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_207 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_209 lang.IFn




					if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = n__0; if linked_208 == nil { and__1927000168__auto____6 = ifn_209.Invoke_O__O(arg_210) } else { and__1927000168__auto____6 = linked_208.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_207, arg_210) }
//line :105:1
					if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_211 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_213 lang.IFn






						if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var root_215 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_220 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = n__0; if linked_221 == nil { tmp2 = ifn_222.Invoke_O__O(arg_223) } else { tmp2 = linked_221.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_220, arg_223) }; arg_218 = tmp1.Invoke_O__O(tmp2); var arg_219 any = A_arbace_j2g_model_A_const_47; if linked_216 == nil { arg_214 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { arg_214 = linked_216.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; if linked_212 == nil { and__1927000168__auto____7 = ifn_213.Invoke_O__O(arg_214) } else { and__1927000168__auto____7 = linked_212.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_211, arg_214) }
//line :105:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_224 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_226 lang.IFn









							if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp4 any; var root_228 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = n__0; if linked_229 == nil { tmp4 = ifn_230.Invoke_O__O(arg_231) } else { tmp4 = linked_229.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_228, arg_231) }; arg_227 = tmp3.Invoke_O__O(tmp4); if linked_225 == nil { and__1927000168__auto____8 = ifn_226.Invoke_O__O(arg_227) } else { and__1927000168__auto____8 = linked_225.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_224, arg_227) }
//line :105:1
							if jrt.J2g_Truth(and__1927000168__auto____8) {










								var root_232 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any; var tmp5 any = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New(); var tmp6 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class = fncls__245d; tmp6 = fncls__245d } else { tmp6 = fncls__245 }; arg_235 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_236 any; var tmp7 *lang.Keyword = A_arbace_j2g_model_A_const_53; var tmp8 any; var root_246 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = n__0; if linked_247 == nil { tmp8 = ifn_248.Invoke_O__O(arg_249) } else { tmp8 = linked_247.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_246, arg_249) }; arg_236 = tmp7.Invoke_O__O(tmp8); if linked_233 == nil { return ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { return linked_233.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_232, arg_235, arg_236) } } else {
//line :105:1
									return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Invoke_O_O__O(self, p1__1479000034_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_237 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = p1__1479000034_SHARP___1; if linked_238 == nil { or__1927000174__auto____2 = ifn_239.Invoke_O__O(arg_240) } else { or__1927000174__auto____2 = linked_238.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_237, arg_240) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_241 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = p1__1479000034_SHARP___1; if linked_242 == nil { return ifn_243.Invoke_O__O(arg_244) } else { return linked_242.(*A_arbace_j2g_model_reflectable_interface_QMARK__A).Invoke_O_O__O(root_241, arg_244) } } }

func A_arbace_j2g_model_reflected_QMARK__A_New() *A_arbace_j2g_model_reflected_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_250 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_252 lang.IFn; if


	linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = n__0; if linked_251 == nil { and__1927000168__auto____2 = ifn_252.Invoke_O__O(arg_253) } else { and__1927000168__auto____2 = linked_251.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_254 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_258 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = n__0; if linked_259 == nil { arg_257 = ifn_260.Invoke_O__O(arg_261) } else { arg_257 = linked_259.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_258, arg_261) }; if linked_255 == nil { return ifn_256.Invoke_O__O(arg_257) } else { return linked_255.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_254, arg_257) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_info_A_New() *A_arbace_j2g_model_info_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_info_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_j2g_model_info_A) Ctor() {}
//line :123:1
func (t *A_arbace_j2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { var root_262 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = n__0; if linked_263 == nil { return ifn_264.Invoke_O__O(arg_265) } else { return linked_263.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_262, arg_265) } }
func A_arbace_j2g_model_interface_QMARK__A_New() *A_arbace_j2g_model_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Ctor() {}
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_266 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = n__0; if linked_267 == nil { return ifn_268.Invoke_O__O(arg_269) } else { return linked_267.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_266, arg_269) } }

func A_arbace_j2g_model_desc_classes_A_New() *A_arbace_j2g_model_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(d__0, nil) { return nil } else { var tmp1 any; var root_270 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_272 lang.IFn
		if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = d__0; if linked_271 == nil { tmp1 = ifn_272.Invoke_O__O(arg_273) } else { tmp1 = linked_271.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_270, arg_273) }
//line :129:1
		if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var root_274 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_276 lang.IFn

			if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = d__0; if linked_275 == nil { tmp2 = ifn_276.Invoke_O__O(arg_277) } else { tmp2 = linked_275.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_274, arg_277) }
//line :129:1
			if jrt.J2g_Truth(tmp2) {

				var root_278 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = d__0; var arg_286 any; var root_287 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = d__0; if linked_288 == nil { arg_286 = ifn_289.Invoke_O__O(arg_290) } else { arg_286 = linked_288.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_287, arg_290) }; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if linked_279 == nil { return ifn_280.Invoke_O__O(arg_281) } else { return linked_279.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_278, arg_281) } } else {
//line :129:1
					var tmp3 any; var root_291 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_293 lang.IFn


					if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = d__0; if linked_292 == nil { tmp3 = ifn_293.Invoke_O__O(arg_294) } else { tmp3 = linked_292.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :129:1
					if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_295 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_297 lang.IFn


						if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = d__0; if linked_296 == nil { tmp4 = ifn_297.Invoke_O__O(arg_298) } else { tmp4 = linked_296.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_295, arg_298) }
//line :129:1
						return lang.Tuple_Create_O__IPersistentVector(tmp4) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil
						}
						}
				}
		}
	}
}



func A_arbace_j2g_model_method_desc_classes_A_New() *A_arbace_j2g_model_method_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_299 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_301 lang.IFn; if
											linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = desc__0; if linked_300 == nil { tmp1 = ifn_301.Invoke_O__O(arg_302) } else { tmp1 = linked_300.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_299, arg_302) }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Get_O__O(desc__0) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var vec__1479000042__3 any; var root_303 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_305 lang.IFn
												if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = desc__0; if linked_304 == nil { vec__1479000042__3 = ifn_305.Invoke_O__O(arg_306) } else { vec__1479000042__3 = linked_304.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_303, arg_306) }
//line :140:1
		var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(1), nil); var v__6 any; var root_307 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_309 lang.IFn

		if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var tmp4 any; var root_316 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = r__5; var arg_320 any = ps__4; if linked_317 == nil { tmp4 = ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { tmp4 = linked_317.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_316, arg_319, arg_320) }; arg_310 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_308 == nil { v__6 = ifn_309.Invoke_O__O(arg_310) } else { v__6 = linked_308.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_307, arg_310) }
		var tmp5 any; var root_321 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = desc__0; if linked_322 == nil { tmp5 = ifn_323.Invoke_O__O(arg_324) } else { tmp5 = linked_322.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(tmp5) { jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Put_O_O__O(desc__0, v__6) }
//line :140:1
		return v__6 } }





func A_arbace_j2g_model_erased_desc_QMARK__A_New() *A_arbace_j2g_model_erased_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_325 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_327 lang.IFn; if




	linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = d__0; if linked_326 == nil { and__1927000168__auto____2 = ifn_327.Invoke_O__O(arg_328) } else { and__1927000168__auto____2 = linked_326.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_325, arg_328) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp1 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class
		if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class = fncls__337d; tmp2 = fncls__337d } else { tmp2 = fncls__337 }; e__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :151:1
		var and__1927000168__auto____4 any; var root_338 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_340 lang.IFn

		if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = e__3; if linked_339 == nil { and__1927000168__auto____4 = ifn_340.Invoke_O__O(arg_341) } else { and__1927000168__auto____4 = linked_339.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var n__5 any; var root_342 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_344 lang.IFn
			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = e__3; if linked_343 == nil { n__5 = ifn_344.Invoke_O__O(arg_345) } else { n__5 = linked_343.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_342, arg_345) }
//line :153:1
			var and__1927000168__auto____6 any; var root_346 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_348 lang.IFn

			if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any; var root_350 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = n__5; if linked_351 == nil { arg_349 = ifn_352.Invoke_O__O(arg_353) } else { arg_349 = linked_351.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_350, arg_353) }; if linked_347 == nil { and__1927000168__auto____6 = ifn_348.Invoke_O__O(arg_349) } else { and__1927000168__auto____6 = linked_347.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
				var root_354 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var tmp3 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(n__5); var tmp4 *jrt.Class; var fncls__364 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class; if fncls__364 == nil { var fncls__364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class = fncls__364d; tmp4 = fncls__364d } else { tmp4 = fncls__364 }; arg_357 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_69; var arg_358 any = tmp5.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } } else {
//line :155:1
					return and__1927000168__auto____6 } } else {
//line :153:1
						return and__1927000168__auto____4 } } else {
//line :151:1
							return and__1927000168__auto____2 } }
func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { var tmp1 any; var root_329 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = d__1; if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_329, arg_332) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_333 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = d__1; if linked_334 == nil { tmp2 = ifn_335.Invoke_O__O(arg_336) } else { tmp2 = linked_334.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_333, arg_336) }; d__1 = tmp2; continue L1 } else { return d__1 } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A{}; t.Ctor_O(p0); return t }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Invoke_O_O__O(self, p1__1479000046_SHARP___1 any) any { var root_359 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = t.F_n; var arg_363 any = p1__1479000046_SHARP___1; if linked_360 == nil { return ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { return linked_360.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_359, arg_362, arg_363) } }

func A_arbace_j2g_model_desc_in_world_QMARK__A_New() *A_arbace_j2g_model_desc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var root_365 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_369 any; var root_370 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = d__0; if linked_371 == nil { arg_369 = ifn_372.Invoke_O__O(arg_373) } else { arg_369 = linked_371.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_370, arg_373) }; if linked_366 == nil { return ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { return linked_366.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_365, arg_368, arg_369) } }
func A_arbace_j2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_j2g_model_mdesc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { var root_374 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_378 any; var root_379 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, A_arbace_j2g_model_method_desc_classes_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = desc__0; if linked_380 == nil { arg_378 = ifn_381.Invoke_O__O(arg_382) } else { arg_378 = linked_380.(*A_arbace_j2g_model_method_desc_classes_A).Invoke_O_O__O(root_379, arg_382) }; if linked_375 == nil { return ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { return linked_375.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_374, arg_377, arg_378) } }




func A_arbace_j2g_model_go_name_A_New() *A_arbace_j2g_model_go_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_name_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; if




	jrt.J2g_Truth(A_arbace_j2g_model_A_const_33.Get__O()) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2; var tmp2 any; var root_383 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_385 lang.IFn
			if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = n__0; if linked_384 == nil { tmp2 = ifn_385.Invoke_O__O(arg_386) } else { tmp2 = linked_384.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_383, arg_386) }; if jrt.J2g_Truth(tmp2) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = A_arbace_j2g_model_A_const_71.Invoke_O__O(jc__3) } } else {
//line :170:1
				or__1927000174__auto____2 = nil } } else {
//line :169:1
					or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						var root_387 any = A_arbace_j2g_model_A_const_72.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = n__0; if linked_388 == nil { return ifn_389.Invoke_O__O(arg_390) } else { return linked_388.(*aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_387, arg_390) } } }
func A_arbace_j2g_model_pkg_A_New() *A_arbace_j2g_model_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pkg_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { var root_391 any = A_arbace_j2g_model_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = n__0; if linked_392 == nil { return ifn_393.Invoke_O__O(arg_394) } else { return linked_392.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_391, arg_394) } }

func A_arbace_j2g_model_abstract_QMARK__A_New() *A_arbace_j2g_model_abstract_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Ctor() {}
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_395 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_400 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, A_arbace_j2g_model_info_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = n__0; if linked_401 == nil { tmp2 = ifn_402.Invoke_O__O(arg_403) } else { tmp2 = linked_401.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_400, arg_403) }; arg_398 = tmp1.Invoke_O__O(tmp2); var arg_399 any = A_arbace_j2g_model_A_const_75; if linked_396 == nil { return ifn_397.Invoke_O_O__O(arg_398, arg_399) } else { return linked_396.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_395, arg_398, arg_399) } }
func A_arbace_j2g_model_final_QMARK__A_New() *A_arbace_j2g_model_final_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_404 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_409 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_j2g_model_info_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = n__0; if linked_410 == nil { tmp2 = ifn_411.Invoke_O__O(arg_412) } else { tmp2 = linked_410.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_409, arg_412) }; arg_407 = tmp1.Invoke_O__O(tmp2); var arg_408 any = A_arbace_j2g_model_A_const_76; if linked_405 == nil { return ifn_406.Invoke_O_O__O(arg_407, arg_408) } else { return linked_405.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_404, arg_407, arg_408) } }

func A_arbace_j2g_model_subclasses_A_New() *A_arbace_j2g_model_subclasses_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_subclasses_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Ctor() {}
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_77; return lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())).Invoke__O(), n__0)
}
func A_arbace_j2g_model_make_subclass_index_A_New() *A_arbace_j2g_model_make_subclass_index_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Ctor() {}
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any; var root_413 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_415 lang.IFn; if
											linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any; if linked_414 == nil { cache__2 = ifn_415.Invoke_O__O(arg_416) } else { cache__2 = linked_414.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_413, arg_416) }; var tmp1 any =
											A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(cache__2, w__0); var tmp2 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class = fncls__474d; tmp2 = fncls__474d } else { tmp2 = fncls__474 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :185:1
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_417 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_419 lang.IFn; if
												linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = t.F_cache; if linked_418 == nil { or__1927000174__auto____1 = ifn_419.Invoke_O__O(arg_420) } else { or__1927000174__auto____1 = linked_418.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var root_421 any = A_arbace_j2g_model_A_const_78.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = t.F_cache; var arg_425 any; var root_465 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_467 lang.IFn
													if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_33, t.F_w); if linked_466 == nil { ifn_467.Invoke_O__O(arg_468) } else { linked_466.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_465, arg_468) }; var tmp1 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(t.F_w); var tmp2 *jrt.Class; var fncls__464 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class; if fncls__464 == nil { var fncls__464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class = fncls__464d; tmp2 = fncls__464d } else { tmp2 = fncls__464 }; arg_425 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :187:1
		if linked_422 == nil { return ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { return linked_422.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } } }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(p0 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var root_426 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var tmp2 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New(); var tmp3 *jrt.Class; var fncls__448 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class; if fncls__448 == nil { var fncls__448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class = fncls__448d; tmp3 = fncls__448d } else { tmp3 = fncls__448 }; arg_429 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_430 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_431 any; var root_449 any = A_arbace_j2g_model_A_const_83.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_451 lang.IFn


		if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_454 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, A_arbace_j2g_model_T_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; if linked_455 == nil { arg_452 = ifn_456.Invoke__O() } else { arg_452 = linked_455.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_454) }; var arg_453 any; var root_457 any = A_arbace_j2g_model_A_const_84.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_37; var tmp5 any; var t_ any = t.F_w; t.F_w = nil; tmp5 = t_; arg_460 = tmp4.Invoke_O__O(tmp5); if linked_458 == nil { arg_453 = ifn_459.Invoke_O__O(arg_460) } else { arg_453 = linked_458.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_457, arg_460) }; if linked_450 == nil { arg_431 = ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { arg_431 = linked_450.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) }
//line :189:1
		if linked_427 == nil { tmp1 = ifn_428.Invoke_O_O_O__O(arg_429, arg_430, arg_431) } else { tmp1 = linked_427.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_426, arg_429, arg_430, arg_431) } }
//line :188:1
	return nil }(); var root_461 any = A_arbace_j2g_model_A_const_85.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; if linked_462 == nil { ifn_463.Invoke__O() } else { linked_462.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_461) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New() *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var s__3 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_432 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_j2g_model_info_A_fn_class); var ifn_434 lang.IFn; if
																		linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = c__2; if linked_433 == nil { tmp2 = ifn_434.Invoke_O__O(arg_435) } else { tmp2 = linked_433.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_432, arg_435) }; s__3 = tmp1.Invoke_O__O(tmp2); if
																		jrt.J2g_Truth(s__3) { var root_436 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = m__1; var arg_440 any = s__3; var arg_441 any; var root_443 any = A_arbace_j2g_model_A_const_82.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var arg_447 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_444 == nil { arg_441 = ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { arg_441 = linked_444.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; var arg_442 any = c__2; if linked_437 == nil { return ifn_438.Invoke_O_O_O_O__O(arg_439, arg_440, arg_441, arg_442) } else { return linked_437.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_436, arg_439, arg_440, arg_441, arg_442) } } else { return m__1 } }















func A_arbace_j2g_model_leaf_QMARK__A_New() *A_arbace_j2g_model_leaf_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Ctor() {}
//line :207:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_20) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_475 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_477 lang.IFn

		if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = n__0; if linked_476 == nil { tmp1 = ifn_477.Invoke_O__O(arg_478) } else { tmp1 = linked_476.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_475, arg_478) }
//line :212:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var root_479 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_481 lang.IFn


			if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = n__0; if linked_480 == nil { tmp2 = ifn_481.Invoke_O__O(arg_482) } else { tmp2 = linked_480.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_479, arg_482) }
//line :212:1
			if jrt.J2g_Truth(tmp2) {


				var root_483 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var root_487 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_90; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_490 any = tmp3.Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_491 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_18); var tmp6 any; var root_492 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, A_arbace_j2g_model_go_name_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = n__0; if linked_493 == nil { tmp6 = ifn_494.Invoke_O__O(arg_495) } else { tmp6 = linked_493.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_492, arg_495) }; arg_491 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_488 == nil { arg_486 = ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { arg_486 = linked_488.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_487, arg_490, arg_491) }; if linked_484 == nil { return ifn_485.Invoke_O__O(arg_486) } else { return linked_484.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_483, arg_486) } } else {
//line :212:1
					if A_arbace_j2g_model_A_const_60 != nil { var and__1927000168__auto____2 any; var root_496 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_498 lang.IFn



						if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any; var root_500 any = A_arbace_j2g_model_A_const_93.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_j2g_model_abstract_QMARK__A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = n__0; if linked_501 == nil { arg_499 = ifn_502.Invoke_O__O(arg_503) } else { arg_499 = linked_501.(*A_arbace_j2g_model_abstract_QMARK__A).Invoke_O_O__O(root_500, arg_503) }; if linked_497 == nil { and__1927000168__auto____2 = ifn_498.Invoke_O__O(arg_499) } else { and__1927000168__auto____2 = linked_497.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_496, arg_499) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_504 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any; var root_508 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, A_arbace_j2g_model_subclasses_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = n__0; if linked_509 == nil { arg_507 = ifn_510.Invoke_O__O(arg_511) } else { arg_507 = linked_509.(*A_arbace_j2g_model_subclasses_A).Invoke_O_O__O(root_508, arg_511) }; if linked_505 == nil { and__1927000168__auto____3 = ifn_506.Invoke_O__O(arg_507) } else { and__1927000168__auto____3 = linked_505.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_504, arg_507) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
							var root_512 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_95.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_516 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var root_520 any = A_arbace_j2g_model_A_const_96.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = n__0; if linked_521 == nil { arg_519 = ifn_522.Invoke_O__O(arg_523) } else { arg_519 = linked_521.(*A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_520, arg_523) }; if linked_517 == nil { arg_515 = ifn_518.Invoke_O__O(arg_519) } else { arg_515 = linked_517.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_516, arg_519) } } else { arg_515 = and__1927000168__auto____4 }; if linked_513 == nil { return ifn_514.Invoke_O__O(arg_515) } else { return linked_513.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_512, arg_515) } } else {
//line :216:1
								return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :212:1
									return nil
								}
				}
		}
	}
}




func A_arbace_j2g_model_qualify_A_New() *A_arbace_j2g_model_qualify_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_qualify_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_j2g_model_qualify_A) Ctor() {}
//line :222:1
func (t *A_arbace_j2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z_NoInit(from__0, nil) }; if tmp1 { var root_524 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = ident__2; if linked_525 == nil { return ifn_526.Invoke_O__O(arg_527) } else { return linked_525.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_524, arg_527) } } else { var root_528 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var root_533 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = of__1; if linked_534 == nil { arg_531 = ifn_535.Invoke_O__O(arg_536) } else { arg_531 = linked_534.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A).Invoke_O_O__O(root_533, arg_536) }; var arg_532 any = ident__2; if linked_529 == nil { return ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { return linked_529.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_528, arg_531, arg_532)
	} } }
func A_arbace_j2g_model_class_sym_A_New() *A_arbace_j2g_model_class_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_sym_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_j2g_model_class_sym_A) Ctor() {}
//line :227:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	var root_537 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_j2g_model_qualify_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = from__0; var arg_541 any; var root_543 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_j2g_model_pkg_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = n__1; if linked_544 == nil { arg_541 = ifn_545.Invoke_O__O(arg_546) } else { arg_541 = linked_544.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_543, arg_546) }; var arg_542 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_547 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_j2g_model_go_name_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = n__1; if linked_548 == nil { tmp2 = ifn_549.Invoke_O__O(arg_550) } else { tmp2 = linked_548.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_547, arg_550) }; arg_542 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, suffix__2)).Ref(); if linked_538 == nil { return ifn_539.Invoke_O_O_O__O(arg_540, arg_541, arg_542) } else { return linked_538.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_537, arg_540, arg_541, arg_542) } }
//line :227:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	var root_551 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = from__0; var arg_555 any = n__1; var arg_556 any = Lit_8; if linked_552 == nil { return ifn_553.Invoke_O_O_O__O(arg_554, arg_555, arg_556) } else { return linked_552.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_551, arg_554, arg_555, arg_556)
	}
}
func A_arbace_j2g_model_jrt_sym_A_New() *A_arbace_j2g_model_jrt_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_j2g_model_jrt_sym_A) Ctor() {}
//line :232:1
func (t *A_arbace_j2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { var root_557 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_j2g_model_qualify_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = from__0; var arg_561 any = A_arbace_j2g_model_A_const_91; var arg_562 any = ident__1; if linked_558 == nil { return ifn_559.Invoke_O_O_O__O(arg_560, arg_561, arg_562) } else { return linked_558.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_557, arg_560, arg_561, arg_562) } }






func A_arbace_j2g_model_go_type_A_New() *A_arbace_j2g_model_go_type_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_type_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_j2g_model_go_type_A) Ctor() {}
//line :239:1
func (t *A_arbace_j2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, A_arbace_j2g_model_A_const_102) { return A_arbace_j2g_model_A_const_103 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()).Invoke_O__O(d__1)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :242:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_15) { return nil } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_16) { return A_arbace_j2g_model_A_const_105 } else { var tmp1 any; var root_563 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_565 lang.IFn




				if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = d__1; if linked_564 == nil { tmp1 = ifn_565.Invoke_O__O(arg_566) } else { tmp1 = linked_564.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_563, arg_566) }
//line :242:1
				if jrt.J2g_Truth(tmp1) { var e__3 any; var root_567 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_569 lang.IFn




					if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = d__1; if linked_568 == nil { e__3 = ifn_569.Invoke_O__O(arg_570) } else { e__3 = linked_568.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_567, arg_570) }
					var tmp2 any; var root_571 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = e__3; if linked_572 == nil { tmp2 = ifn_573.Invoke_O__O(arg_574) } else { tmp2 = linked_572.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_571, arg_574) }; if jrt.J2g_Truth(tmp2) {
						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_113; var tmp5 any; var root_619 any = A_arbace_j2g_model_A_const_114.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = from__0; var arg_623 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_115.GetRawRoot__O()).Invoke_O__O(e__3); if linked_620 == nil { tmp5 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { tmp5 = linked_620.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_A_const_116; var tmp8 any; var root_624 any = A_arbace_j2g_model_A_const_114.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = from__0; var arg_628 any = Lit_17; if linked_625 == nil { tmp8 = ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { tmp8 = linked_625.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } } else {
//line :242:1
								var tmp9 any; var root_575 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_577 lang.IFn








								if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = d__1; if linked_576 == nil { tmp9 = ifn_577.Invoke_O__O(arg_578) } else { tmp9 = linked_576.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_575, arg_578) }
//line :242:1
								if jrt.J2g_Truth(tmp9) { var n__3 any; var root_579 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_581 lang.IFn









									if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = d__1; if linked_580 == nil { n__3 = ifn_581.Invoke_O__O(arg_582) } else { n__3 = linked_580.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_579, arg_582) }
									var tmp10 any; var root_583 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_585 lang.IFn
									if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any; var root_587 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = n__3; if linked_588 == nil { arg_586 = ifn_589.Invoke_O__O(arg_590) } else { arg_586 = linked_588.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_587, arg_590) }; if linked_584 == nil { tmp10 = ifn_585.Invoke_O__O(arg_586) } else { tmp10 = linked_584.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_583, arg_586) }
//line :253:1
									if jrt.J2g_Truth(tmp10) { return A_arbace_j2g_model_A_const_108 } else { var tmp11 any; var root_591 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_593 lang.IFn

										if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = n__3; if linked_592 == nil { tmp11 = ifn_593.Invoke_O__O(arg_594) } else { tmp11 = linked_592.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_591, arg_594) }
//line :253:1
										if jrt.J2g_Truth(tmp11) {

											var root_595 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = from__0; var arg_599 any = n__3; if linked_596 == nil { return ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { return linked_596.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_595, arg_598, arg_599) } } else {
//line :253:1
												var tmp12 any; var root_600 any = A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_602 lang.IFn


												if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = n__3; if linked_601 == nil { tmp12 = ifn_602.Invoke_O__O(arg_603) } else { tmp12 = linked_601.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_600, arg_603) }
//line :253:1
												if jrt.J2g_Truth(tmp12) {


													var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_model_A_const_117; var tmp15 any; var root_629 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = from__0; var arg_633 any = n__3; if linked_630 == nil { tmp15 = ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { tmp15 = linked_630.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_629, arg_632, arg_633) }; return tmp13.Invoke_O_O__O(tmp14, tmp15) } else {
//line :253:1
														if A_arbace_j2g_model_A_const_60 != nil {



															var root_604 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = from__0; var arg_608 any = n__3; var arg_609 any = Lit_18; if linked_605 == nil { return ifn_606.Invoke_O_O_O__O(arg_607, arg_608, arg_609) } else { return linked_605.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_604, arg_607, arg_608, arg_609) } } else {
//line :253:1
																return nil } } } } } else {
//line :242:1
																	if A_arbace_j2g_model_A_const_60 != nil { var tmp16 any; var root_610 any = A_arbace_j2g_model_A_const_110.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_612 lang.IFn















																		if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_111.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); var arg_614 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_112, d__1)); if linked_611 == nil { tmp16 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { tmp16 = linked_611.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }
//line :242:1
																		panic(jrt.Thrown(jrt.Throwable_Cast(tmp16))) } else { return nil
																		}
																}
							}
			}
			}
		}
	}
}









func A_arbace_j2g_model_pointer_desc_QMARK__A_New() *A_arbace_j2g_model_pointer_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :260:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_634 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = d__0; if linked_635 == nil { tmp1 = ifn_636.Invoke_O__O(arg_637) } else { tmp1 = linked_635.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_634, arg_637) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_638 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_640 lang.IFn
		if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = d__0; if linked_639 == nil { tmp2 = ifn_640.Invoke_O__O(arg_641) } else { tmp2 = linked_639.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_638, arg_641) }
//line :263:1
		if jrt.J2g_Truth(tmp2) { var n__2 any; var root_642 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_644 lang.IFn
			if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = d__0; if linked_643 == nil { n__2 = ifn_644.Invoke_O__O(arg_645) } else { n__2 = linked_643.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_642, arg_645) }
//line :263:1
			var and__1927000168__auto____3 any; var root_646 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_648 lang.IFn

			if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = n__2; if linked_647 == nil { and__1927000168__auto____3 = ifn_648.Invoke_O__O(arg_649) } else { and__1927000168__auto____3 = linked_647.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_650 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any; var root_654 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = n__2; if linked_655 == nil { arg_653 = ifn_656.Invoke_O__O(arg_657) } else { arg_653 = linked_655.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_654, arg_657) }; if linked_651 == nil { and__1927000168__auto____4 = ifn_652.Invoke_O__O(arg_653) } else { and__1927000168__auto____4 = linked_651.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_650, arg_653) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_658 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = n__2; var arg_662 any = Lit_20; if linked_659 == nil { and__1927000168__auto____5 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { and__1927000168__auto____5 = linked_659.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_663 any = A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = n__2; if linked_664 == nil { return ifn_665.Invoke_O__O(arg_666) } else { return linked_664.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_663, arg_666) } } else {
//line :265:1
					return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :263:1
						if A_arbace_j2g_model_A_const_60 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
						}
					}
	}
}

func A_arbace_j2g_model_iface_desc_QMARK__A_New() *A_arbace_j2g_model_iface_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_667 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_669 lang.IFn; if


	linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = d__0; if linked_668 == nil { and__1927000168__auto____2 = ifn_669.Invoke_O__O(arg_670) } else { and__1927000168__auto____2 = linked_668.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_671 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = d__0; var arg_675 any = A_arbace_j2g_model_A_const_102; if linked_672 == nil { and__1927000168__auto____3 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { and__1927000168__auto____3 = linked_672.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_676 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any; var root_680 any = A_arbace_j2g_model_A_const_120.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = d__0; if linked_681 == nil { arg_679 = ifn_682.Invoke_O__O(arg_683) } else { arg_679 = linked_681.(*A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_680, arg_683) }; if linked_677 == nil { return ifn_678.Invoke_O__O(arg_679) } else { return linked_677.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_676, arg_679) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_model_static_QMARK__A_New() *A_arbace_j2g_model_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_j2g_model_static_QMARK__A) Ctor() {}
//line :277:1
func (t *A_arbace_j2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_684 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_688 any = A_arbace_j2g_model_A_const_121; if linked_685 == nil { return ifn_686.Invoke_O_O__O(arg_687, arg_688) } else { return linked_685.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_684, arg_687, arg_688) } }
func A_arbace_j2g_model_private_QMARK__A_New() *A_arbace_j2g_model_private_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_j2g_model_private_QMARK__A) Ctor() {}
//line :278:1
func (t *A_arbace_j2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_689 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_693 any = A_arbace_j2g_model_A_const_122; if linked_690 == nil { return ifn_691.Invoke_O_O__O(arg_692, arg_693) } else { return linked_690.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_689, arg_692, arg_693) } }
func A_arbace_j2g_model_abstract_m_QMARK__A_New() *A_arbace_j2g_model_abstract_m_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_694 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_698 any = A_arbace_j2g_model_A_const_75; if linked_695 == nil { return ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { return linked_695.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_694, arg_697, arg_698) } }

func A_arbace_j2g_model_methods_of_A_New() *A_arbace_j2g_model_methods_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_methods_of_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_j2g_model_methods_of_A) Ctor() {}
//line :281:1
func (t *A_arbace_j2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp2 any; var root_699 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, A_arbace_j2g_model_info_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = n__0; if linked_700 == nil { tmp2 = ifn_701.Invoke_O__O(arg_702) } else { tmp2 = linked_700.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_699, arg_702) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_j2g_model_fields_of_A_New() *A_arbace_j2g_model_fields_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fields_of_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_j2g_model_fields_of_A) Ctor() {}
//line :282:1
func (t *A_arbace_j2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_123; var tmp2 any; var root_703 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_j2g_model_info_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = n__0; if linked_704 == nil { tmp2 = ifn_705.Invoke_O__O(arg_706) } else { tmp2 = linked_704.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_703, arg_706) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_find_method_A_New() *A_arbace_j2g_model_find_method_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_j2g_model_find_method_A) Ctor() {}
//line :284:1
func (t *A_arbace_j2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var root_707 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var tmp1 any = A_arbace_j2g_model_find_method_fn__1479000079_A_New_O_O(name__1, desc__2); var tmp2 *jrt.Class; var fncls__712 *jrt.Class = A_arbace_j2g_model_find_method_fn__1479000079_A_fn_class; if fncls__712 == nil { var fncls__712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_model_find_method_fn__1479000079_A_fn_class = fncls__712d; tmp2 = fncls__712d } else { tmp2 = fncls__712 }; arg_710 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_711 any; var root_713 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = n__0; if linked_714 == nil { arg_711 = ifn_715.Invoke_O__O(arg_716) } else { arg_711 = linked_714.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_713, arg_716) }; if linked_708 == nil { return ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { return linked_708.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_707, arg_710, arg_711) } }
//line :285:1
func A_arbace_j2g_model_find_method_fn__1479000079_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_find_method_fn__1479000079_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_fn__1479000079_A{}; t.Ctor_O_O(p0, p1); return t }
//line :285:1
func (t *A_arbace_j2g_model_find_method_fn__1479000079_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :285:1
func (t *A_arbace_j2g_model_find_method_fn__1479000079_A) Invoke_O_O__O(self, p1__1479000078_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_model_A_const_124.Invoke_O__O(p1__1479000078_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_model_A_const_112.Invoke_O__O(p1__1479000078_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1479000078_SHARP___1 } else { return nil } }

func A_arbace_j2g_model_virtual_member_QMARK__A_New() *A_arbace_j2g_model_virtual_member_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Ctor() {}
//line :287:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any; var root_717 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_719 lang.IFn; if


	linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any; var root_721 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = m__0; if linked_722 == nil { arg_720 = ifn_723.Invoke_O__O(arg_724) } else { arg_720 = linked_722.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_721, arg_724) }; if linked_718 == nil { and__1927000168__auto____2 = ifn_719.Invoke_O__O(arg_720) } else { and__1927000168__auto____2 = linked_718.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_717, arg_720) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_725 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var root_729 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = m__0; if linked_730 == nil { arg_728 = ifn_731.Invoke_O__O(arg_732) } else { arg_728 = linked_730.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_729, arg_732) }; if linked_726 == nil { and__1927000168__auto____3 = ifn_727.Invoke_O__O(arg_728) } else { and__1927000168__auto____3 = linked_726.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_725, arg_728) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_733 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = Lit_44; var arg_737 any = A_arbace_j2g_model_A_const_124.Invoke_O__O(m__0); if linked_734 == nil { and__1927000168__auto____4 = ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { and__1927000168__auto____4 = linked_734.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_733, arg_736, arg_737) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_738 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = Lit_68; var arg_742 any = A_arbace_j2g_model_A_const_124.Invoke_O__O(m__0); if linked_739 == nil { return ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { return linked_739.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_738, arg_741, arg_742) } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_model_supertypes_A_New() *A_arbace_j2g_model_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_supertypes_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_model_supertypes_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_743 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, A_arbace_j2g_model_info_A_fn_class); var ifn_745 lang.IFn; if
										linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = n__0; if linked_744 == nil { i__2 = ifn_745.Invoke_O__O(arg_746) } else { i__2 = linked_744.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_743, arg_746) }; var root_747 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var arg_751 any; var root_752 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(i__2); var arg_756 any = A_arbace_j2g_model_A_const_53.Invoke_O__O(i__2); if linked_753 == nil { arg_751 = ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { arg_751 = linked_753.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) }; if linked_748 == nil { return ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { return linked_748.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) } }

func A_arbace_j2g_model_world_supertypes_A_New() *A_arbace_j2g_model_world_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_j2g_model_world_supertypes_A) Ctor() {}
//line :300:1
func (t *A_arbace_j2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	var root_757 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_761 any; var root_762 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_j2g_model_supertypes_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = n__0; if linked_763 == nil { arg_761 = ifn_764.Invoke_O__O(arg_765) } else { arg_761 = linked_763.(*A_arbace_j2g_model_supertypes_A).Invoke_O_O__O(root_762, arg_765) }; if linked_758 == nil { return ifn_759.Invoke_O_O__O(arg_760, arg_761) } else { return linked_758.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_757, arg_760, arg_761)
	} }
func A_arbace_j2g_model_all_supertypes_A_New() *A_arbace_j2g_model_all_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_j2g_model_all_supertypes_A) Ctor() {}
//line :305:1
func (t *A_arbace_j2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	var root_766 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any; var root_770 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_774 any; var root_775 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = n__0; if linked_776 == nil { arg_774 = ifn_777.Invoke_O__O(arg_778) } else { arg_774 = linked_776.(*aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_775, arg_778) }; if linked_771 == nil { arg_769 = ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { arg_769 = linked_771.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) }; if linked_767 == nil { return ifn_768.Invoke_O__O(arg_769) } else { return linked_767.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_766, arg_769)
	}
}

func A_arbace_j2g_model_hw_method_exists_QMARK__A_New() *A_arbace_j2g_model_hw_method_exists_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :314:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_91; var scan__3 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var g__4 any; var root_779 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, A_arbace_j2g_model_go_name_A_fn_class); var ifn_781 lang.IFn; if



	linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = n__0; if linked_780 == nil { g__4 = ifn_781.Invoke_O__O(arg_782) } else { g__4 = linked_780.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_779, arg_782) }; var base__5 any; var root_783 any = /*line :314:1*/A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_785 lang.IFn; if




	linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = A_arbace_j2g_model_A_const_124.Invoke_O__O(m__1); var arg_787 any = A_arbace_j2g_model_A_const_112.Invoke_O__O(m__1); if linked_784 == nil { base__5 = ifn_785.Invoke_O_O__O(arg_786, arg_787) } else { base__5 = linked_784.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_783, arg_786, arg_787) }; if
	lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_20) {
		var root_788 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var arg_792 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_124.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_112.Invoke_O__O(m__1)); if linked_789 == nil { return ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { return linked_789.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_788, arg_791, arg_792) } } else {
//line :320:1
			var tmp2 any; var root_793 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_795 lang.IFn

			if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = n__0; if linked_794 == nil { tmp2 = ifn_795.Invoke_O__O(arg_796) } else { tmp2 = linked_794.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_793, arg_796) }
//line :320:1
			if jrt.J2g_Truth(tmp2) { var or__1927000174__auto____6 any; var root_797 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_799 lang.IFn

				if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any; var root_802 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = scan__3; var arg_806 any = g__4; if linked_803 == nil { arg_800 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { arg_800 = linked_803.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; var arg_801 any = base__5; if linked_798 == nil { or__1927000174__auto____6 = ifn_799.Invoke_O_O__O(arg_800, arg_801) } else { or__1927000174__auto____6 = linked_798.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_797, arg_800, arg_801) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					var root_807 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = A_arbace_j2g_model_A_const_136.Invoke_O__O(scan__3); var arg_811 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref(); if linked_808 == nil { return ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { return linked_808.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_807, arg_810, arg_811) } } } else {
//line :320:1
						if A_arbace_j2g_model_A_const_60 != nil { var ms__6 any; var root_812 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_814 lang.IFn




							if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = scan__3; var arg_816 any = g__4; if linked_813 == nil { ms__6 = ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { ms__6 = linked_813.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_812, arg_815, arg_816) }
//line :320:1
							var or__1927000174__auto____7 any; var root_817 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_819 lang.IFn





							if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = ms__6; var arg_821 any = base__5; if linked_818 == nil { or__1927000174__auto____7 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { or__1927000174__auto____7 = linked_818.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_822 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = ms__6; var arg_826 any; var root_827 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = base__5; if linked_828 == nil { arg_826 = ifn_829.Invoke_O__O(arg_830) } else { arg_826 = linked_828.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_827, arg_830) }; if linked_823 == nil { or__1927000174__auto____8 = ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { or__1927000174__auto____8 = linked_823.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_822, arg_825, arg_826) }; if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								var root_831 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_j2g_model_j2g_method_QMARK__A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = n__0; var arg_835 any = base__5; if linked_832 == nil { return ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { return linked_832.(*A_arbace_j2g_model_j2g_method_QMARK__A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } } } } else {
//line :320:1
									return nil } } } }








func A_arbace_j2g_model_j2g_method_QMARK__A_New() *A_arbace_j2g_model_j2g_method_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_method_QMARK__A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Ctor() {}
//line :329:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_28); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_140).Invoke_O__O(base__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_836 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_838 lang.IFn
		if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = Lit_29; if linked_837 == nil { and__1927000168__auto____5 = ifn_838.Invoke_O__O(arg_839) } else { and__1927000168__auto____5 = linked_837.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_836, arg_839) }
//line :336:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_840 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = Lit_30; if linked_841 == nil { return ifn_842.Invoke_O__O(arg_843) } else { return linked_841.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_840, arg_843) } } else {
//line :336:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_member_in_world_QMARK__A_New() *A_arbace_j2g_model_member_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Ctor() {}
//line :339:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any; var root_844 any = A_arbace_j2g_model_A_const_141.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_846 lang.IFn; if



	linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = A_arbace_j2g_model_A_const_112.Invoke_O__O(m__1); if linked_845 == nil { and__1927000168__auto____3 = ifn_846.Invoke_O__O(arg_847) } else { and__1927000168__auto____3 = linked_845.(*A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_844, arg_847) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_848 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_850 lang.IFn
		if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var root_852 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = n__0; if linked_853 == nil { arg_851 = ifn_854.Invoke_O__O(arg_855) } else { arg_851 = linked_853.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_852, arg_855) }; if linked_849 == nil { or__1927000174__auto____4 = ifn_850.Invoke_O__O(arg_851) } else { or__1927000174__auto____4 = linked_849.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_848, arg_851) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_856 any = A_arbace_j2g_model_A_const_142.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = n__0; var arg_860 any = m__1; if linked_857 == nil { return ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { return linked_857.(*A_arbace_j2g_model_hw_method_exists_QMARK__A).Invoke_O_O_O__O(root_856, arg_859, arg_860) } } } else {
//line :343:1
			return and__1927000168__auto____3 } }


func A_arbace_j2g_model_declared_vmethods_A_New() *A_arbace_j2g_model_declared_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Ctor() {}
//line :346:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__957 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_fn_class; if


	fncls__957 == nil { var fncls__957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_fn_class = fncls__957d; tmp2 = fncls__957d } else { tmp2 = fncls__957 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_958 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = n__0; if linked_959 == nil { tmp4 = ifn_960.Invoke_O__O(arg_961) } else { tmp4 = linked_959.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_958, arg_961) }; return tmp3.Invoke_O__O(tmp4) }
//line :349:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_New_O(p0 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A{}; t.Ctor_O(p0); return t }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A) Invoke_O_O__O(self, s__1479000090__1 any) any { var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_New_O_O_O(t.F_n, s__1479000090__1, self); var tmp2 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_fn_class = fncls__956d; tmp2 = fncls__956d } else { tmp2 = fncls__956 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :349:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A) Ctor_O_O_O(c__n, c__s__1479000090, c__iter__1479000089 any) { t.F_n = c__n; t.F_s__1479000090 = c__s__1479000090; t.F_iter__1479000089 = c__iter__1479000089 }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A) Invoke_O__O(self any) any { { var s__1479000090__1 any; var t_ any = t.F_s__1479000090; t.F_s__1479000090 = nil; s__1479000090__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_861 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__1479000090__1; if linked_862 == nil { temp__1927000414__auto____2 = ifn_863.Invoke_O__O(arg_864) } else { temp__1927000414__auto____2 = linked_862.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_861, arg_864) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000090__3 any = temp__1927000414__auto____2; var tmp1 any; var root_865 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = s__1479000090__3; if linked_866 == nil { tmp1 = ifn_867.Invoke_O__O(arg_868) } else { tmp1 = linked_866.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_869 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = s__1479000090__3; if linked_870 == nil { c__1927001037__auto____4 = ifn_871.Invoke_O__O(arg_872) } else { c__1927001037__auto____4 = linked_870.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_869, arg_872) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000092__6 any; var root_873 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_874 == nil { b__1479000092__6 = ifn_875.Invoke_O__O(arg_876) } else { b__1479000092__6 = linked_874.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_873, arg_876) }; var tmp2 any = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_New_O_O_I_O(t.F_n, b__1479000092__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__897 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_fn_class; if fncls__897 == nil { var fncls__897d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_fn_class = fncls__897d; tmp3 = fncls__897d } else { tmp3 = fncls__897 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_898 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any; var root_903 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = b__1479000092__6; if linked_904 == nil { arg_901 = ifn_905.Invoke_O__O(arg_906) } else { arg_901 = linked_904.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_903, arg_906) }; var arg_902 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000089); var tmp5 any; var root_907 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = s__1479000090__3; if linked_908 == nil { tmp5 = ifn_909.Invoke_O__O(arg_910) } else { tmp5 = linked_908.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_907, arg_910) }; arg_902 = tmp4.Invoke_O__O(tmp5); if linked_899 == nil { return ifn_900.Invoke_O_O__O(arg_901, arg_902) } else { return linked_899.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_898, arg_901, arg_902) } } else { var root_911 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any; var root_916 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = b__1479000092__6; if linked_917 == nil { arg_914 = ifn_918.Invoke_O__O(arg_919) } else { arg_914 = linked_917.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_916, arg_919) }; var arg_915 any; if linked_912 == nil { return ifn_913.Invoke_O_O__O(arg_914, arg_915) } else { return linked_912.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_911, arg_914, arg_915) } } } else { var m__4 any; var root_920 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = s__1479000090__3; if linked_921 == nil { m__4 = ifn_922.Invoke_O__O(arg_923) } else { m__4 = linked_921.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_920, arg_923) }; var tmp6 any; var root_924 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_926 lang.IFn
															if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = m__4; if linked_925 == nil { tmp6 = ifn_926.Invoke_O__O(arg_927) } else { tmp6 = linked_925.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_924, arg_927) }
//line :349:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_928 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_930 lang.IFn

		if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = t.F_n; var arg_932 any = m__4; if linked_929 == nil { tmp7 = ifn_930.Invoke_O_O__O(arg_931, arg_932) } else { tmp7 = linked_929.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_928, arg_931, arg_932) }
//line :349:1
		if jrt.J2g_Truth(tmp7) { var root_933 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any; var root_938 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_940 lang.IFn


			if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = m__4; var arg_942 any = A_arbace_j2g_model_A_const_150; var arg_943 any = t.F_n; if linked_939 == nil { arg_936 = ifn_940.Invoke_O_O_O__O(arg_941, arg_942, arg_943) } else { arg_936 = linked_939.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_938, arg_941, arg_942, arg_943) }
//line :349:1
			var arg_937 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000089); var tmp9 any; var root_944 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = s__1479000090__3; if linked_945 == nil { tmp9 = ifn_946.Invoke_O__O(arg_947) } else { tmp9 = linked_945.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_944, arg_947) }; arg_937 = tmp8.Invoke_O__O(tmp9); if linked_934 == nil { return ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { return linked_934.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) } } else { var tmp10 any; var root_948 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__1479000090__3; if linked_949 == nil { tmp10 = ifn_950.Invoke_O__O(arg_951) } else { tmp10 = linked_949.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_948, arg_951) }; s__1479000090__1 = tmp10; continue L1 } } else { var tmp11 any; var root_952 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = s__1479000090__3; if linked_953 == nil { tmp11 = ifn_954.Invoke_O__O(arg_955) } else { tmp11 = linked_953.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_952, arg_955) }; s__1479000090__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A) Ctor_O_O_I_O(c__n, c__b__1479000092 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1479000092 = c__b__1479000092; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A) Invoke_O__O(self any) any { { var i__1479000091__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000091__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000091__1)); var tmp2 any; var root_877 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_879 lang.IFn
																	if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = m__2; if linked_878 == nil { tmp2 = ifn_879.Invoke_O__O(arg_880) } else { tmp2 = linked_878.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_877, arg_880) }
//line :349:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_881 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_883 lang.IFn

		if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = t.F_n; var arg_885 any = m__2; if linked_882 == nil { tmp3 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { tmp3 = linked_882.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }
//line :349:1
		if jrt.J2g_Truth(tmp3) { var root_886 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = t.F_b__1479000092; var arg_890 any; var root_891 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_893 lang.IFn


			if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = m__2; var arg_895 any = A_arbace_j2g_model_A_const_150; var arg_896 any = t.F_n; if linked_892 == nil { arg_890 = ifn_893.Invoke_O_O_O__O(arg_894, arg_895, arg_896) } else { arg_890 = linked_892.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_891, arg_894, arg_895, arg_896) }
//line :349:1
			if linked_887 == nil { ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { linked_887.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; i__1479000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000091__1); continue L1 } else { i__1479000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000091__1); continue L1 } } else { i__1479000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000091__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_model_vmethods_A_New() *A_arbace_j2g_model_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_j2g_model_vmethods_A) Ctor() {}
//line :354:1
func (t *A_arbace_j2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_156; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var or__1927000174__auto____3 any; var tmp2 any; var root_962 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_964 lang.IFn; if




	linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = cache__2; if linked_963 == nil { tmp2 = ifn_964.Invoke_O__O(arg_965) } else { tmp2 = linked_963.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_962, arg_965) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var root_966 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_968 lang.IFn
		if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var tmp3 any = A_arbace_j2g_model_vmethods_fn__1479000100_A_New(); var tmp4 *jrt.Class; var fncls__999 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000100_A_fn_class; if fncls__999 == nil { var fncls__999d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_model_vmethods_fn__1479000100_A_fn_class = fncls__999d; tmp4 = fncls__999d } else { tmp4 = fncls__999 }; arg_969 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_970 any; var root_1000 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_1002 lang.IFn






		if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; if linked_1001 == nil { arg_970 = ifn_1002.Invoke__O() } else { arg_970 = linked_1001.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_1000) }
//line :360:1
		var arg_971 any; var root_1003 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1005 lang.IFn






		if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = n__0; if linked_1004 == nil { arg_971 = ifn_1005.Invoke_O__O(arg_1006) } else { arg_971 = linked_1004.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1003, arg_1006) }
//line :360:1
		if linked_967 == nil { r__4 = ifn_968.Invoke_O_O_O__O(arg_969, arg_970, arg_971) } else { r__4 = linked_967.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_966, arg_969, arg_970, arg_971)
		}






		var root_1007 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = cache__2; var arg_1011 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var arg_1012 any = n__0; var arg_1013 any = r__4; if linked_1008 == nil { ifn_1009.Invoke_O_O_O_O__O(arg_1010, arg_1011, arg_1012, arg_1013) } else { linked_1008.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1007, arg_1010, arg_1011, arg_1012, arg_1013) }
//line :359:1
		return r__4 } }
func A_arbace_j2g_model_vmethods_fn__1479000100_A_New() *A_arbace_j2g_model_vmethods_fn__1479000100_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000100_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_A) Ctor() {}
//line :360:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(c__2, Lit_20) { return acc__1 } else {

		var root_972 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var tmp1 any = A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_New(); var tmp2 *jrt.Class; var fncls__994 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_fn_class; if fncls__994 == nil { var fncls__994d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_fn_class = fncls__994d; tmp2 = fncls__994d } else { tmp2 = fncls__994 }; arg_975 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_976 any = acc__1; var arg_977 any; var root_995 any = A_arbace_j2g_model_A_const_157.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, A_arbace_j2g_model_declared_vmethods_A_fn_class); var ifn_997 lang.IFn


		if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = c__2; if linked_996 == nil { arg_977 = ifn_997.Invoke_O__O(arg_998) } else { arg_977 = linked_996.(*A_arbace_j2g_model_declared_vmethods_A).Invoke_O_O__O(root_995, arg_998) }
//line :363:1
		if linked_973 == nil { return ifn_974.Invoke_O_O_O__O(arg_975, arg_976, arg_977) } else { return linked_973.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_972, arg_975, arg_976, arg_977) } } }
//line :363:1
func A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_New() *A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A) Ctor() {}
//line :363:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_124.Invoke_O__O(m__2), A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2)); var tmp1 any; var or__1927000174__auto____4 any; var root_978 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_980 lang.IFn; if

	linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = acc__1; var arg_982 any = k__3; if linked_979 == nil { or__1927000174__auto____4 = ifn_980.Invoke_O_O__O(arg_981, arg_982) } else { or__1927000174__auto____4 = linked_979.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_978, arg_981, arg_982) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_983 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var arg_987 any = k__3; if linked_984 == nil { tmp1 = ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { tmp1 = linked_984.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_983, arg_986, arg_987) } }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_988 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = acc__1; var arg_992 any = k__3; var arg_993 any = m__2; if linked_989 == nil { return ifn_990.Invoke_O_O_O__O(arg_991, arg_992, arg_993) } else { return linked_989.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_988, arg_991, arg_992, arg_993) } } }





func A_arbace_j2g_model_java_type_name_A_New() *A_arbace_j2g_model_java_type_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_java_type_name_A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_j2g_model_java_type_name_A) Ctor() {}
//line :371:1
func (t *A_arbace_j2g_model_java_type_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_1014 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = d__0; if linked_1015 == nil { tmp1 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp1 = linked_1015.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1014, arg_1017) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34); var tmp3 any; var root_1018 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any; var root_1022 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = d__0; if linked_1023 == nil { arg_1021 = ifn_1024.Invoke_O__O(arg_1025) } else { arg_1021 = linked_1023.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1022, arg_1025) }; if linked_1019 == nil { tmp3 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp3 = linked_1019.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1018, arg_1021) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref() } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(d__0))) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_161).Invoke_O__O(d__0) } else {
//line :374:1
			if A_arbace_j2g_model_A_const_60 != nil {


				var root_1026 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any; var root_1032 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = d__0; if linked_1033 == nil { arg_1029 = ifn_1034.Invoke_O__O(arg_1035) } else { arg_1029 = linked_1033.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1032, arg_1035) }; var arg_1030 any = Lit_1; var arg_1031 any = Lit_2; if linked_1027 == nil { return ifn_1028.Invoke_O_O_O__O(arg_1029, arg_1030, arg_1031) } else { return linked_1027.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1026, arg_1029, arg_1030, arg_1031) } } else {
//line :374:1
					return nil
				}
		}
	}
}
func A_arbace_j2g_model_abstract_method_error_text_A_New() *A_arbace_j2g_model_abstract_method_error_text_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_method_error_text_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Ctor() {}
//line :379:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Invoke_O_O_O_O__O(self, n__0, owner__1, p__1479000106__2 any) any { var vec__1479000107__4 any = p__1479000106__2; var name__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000107__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000107__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1479000110__7 any; var root_1036 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1038 lang.IFn; if



	linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = desc__6; if linked_1037 == nil { vec__1479000110__7 = ifn_1038.Invoke_O__O(arg_1039) } else { vec__1479000110__7 = linked_1037.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1036, arg_1039) }; var ps__8 any = /*line :379:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1479000110__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000110__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,12,s15:Receiver class ns69: does not define or inherit an implementation of the resolved method s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1040 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1042 lang.IFn; if




	linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = n__0; var arg_1044 any = Lit_1; var arg_1045 any = Lit_2; if linked_1041 == nil { tmp2 = ifn_1042.Invoke_O_O_O__O(arg_1043, arg_1044, arg_1045) } else { tmp2 = linked_1041.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1040, arg_1043, arg_1044, arg_1045) }; var tmp3 any = tmp2; var tmp4 any; var root_1046 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1048 lang.IFn; if
	linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = r__9; if linked_1047 == nil { tmp4 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp4 = linked_1047.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1046, arg_1049) }; var tmp5 any = tmp4; var tmp6 any; var root_1050 any = /*line :384:1*/A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1052 lang.IFn; if
	linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = Lit_3; var arg_1054 any; var root_1055 any = A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var arg_1059 any = ps__8; if linked_1056 == nil { arg_1054 = ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { arg_1054 = linked_1056.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) }; if linked_1051 == nil { tmp6 = ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { tmp6 = linked_1051.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) }; var tmp7 any = tmp6; var tmp8 /*line :384:1*/*jrt.String; if

	jrt.J2g_Truth(owner__1) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil, nil); var tmp10 *jrt.String; var tmp11 any; var root_1060 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = owner__1; if linked_1061 == nil { tmp11 = ifn_1062.Invoke_O__O(arg_1063) } else { tmp11 = linked_1061.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1060, arg_1063) }; if jrt.J2g_Truth(tmp11) { tmp10 = Lit_5 } else { tmp10 = Lit_6 }; var tmp12 any = tmp10.Ref(); var tmp13 any; var root_1064 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = owner__1; var arg_1068 any = Lit_1; var arg_1069 any = Lit_2; if linked_1065 == nil { tmp13 = ifn_1066.Invoke_O_O_O__O(arg_1067, arg_1068, arg_1069) } else { tmp13 = linked_1065.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1064, arg_1067, arg_1068, arg_1069) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13)) } else { tmp8 = nil }; return /*line :384:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, nil, tmp5, nil, name__5, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }



func A_arbace_j2g_model_superclass_chain_A_New() *A_arbace_j2g_model_superclass_chain_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_j2g_model_superclass_chain_A) Ctor() {}
//line :388:1
func (t *A_arbace_j2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1070 any = A_arbace_j2g_model_A_const_165.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var arg_1074 any; var root_1075 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any; var tmp1 any = A_arbace_j2g_model_superclass_chain_fn__1479000115_A_New(); var tmp2 *jrt.Class; var fncls__1084 *jrt.Class = A_arbace_j2g_model_superclass_chain_fn__1479000115_A_fn_class; if fncls__1084 == nil { var fncls__1084d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_model_superclass_chain_fn__1479000115_A_fn_class = fncls__1084d; tmp2 = fncls__1084d } else { tmp2 = fncls__1084 }; arg_1078 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1079 any = n__0; if linked_1076 == nil { arg_1074 = ifn_1077.Invoke_O_O__O(arg_1078, arg_1079) } else { arg_1074 = linked_1076.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1075, arg_1078, arg_1079) }; if linked_1071 == nil { return ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { return linked_1071.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) } }
//line :389:1
func A_arbace_j2g_model_superclass_chain_fn__1479000115_A_New() *A_arbace_j2g_model_superclass_chain_fn__1479000115_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_fn__1479000115_A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000115_A) Ctor() {}
//line :389:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000115_A) Invoke_O_O__O(self, p1__1479000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_1080 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, A_arbace_j2g_model_info_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = p1__1479000114_SHARP___1; if linked_1081 == nil { tmp2 = ifn_1082.Invoke_O__O(arg_1083) } else { tmp2 = linked_1081.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1080, arg_1083) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_impl_of_A_New() *A_arbace_j2g_model_impl_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_j2g_model_impl_of_A) Ctor() {}
//line :391:1
func (t *A_arbace_j2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1479000119__1 any) any { var vec__1479000120__3 any = p__1479000119__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000120__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000120__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__1479000120__3; var or__1927000174__auto____7 any; var root_1085 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1087 lang.IFn; _ = k__6; if





	linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var tmp1 any = A_arbace_j2g_model_impl_of_fn__1479000123_A_New_O_O_O(name__4, desc__5, n__0); var tmp2 *jrt.Class; var fncls__1160 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000123_A_fn_class; if fncls__1160 == nil { var fncls__1160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_model_impl_of_fn__1479000123_A_fn_class = fncls__1160d; tmp2 = fncls__1160d } else { tmp2 = fncls__1160 }; arg_1088 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1089 any; var root_1161 any = A_arbace_j2g_model_A_const_175.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1163 lang.IFn; if












	linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = n__0; if linked_1162 == nil { arg_1089 = ifn_1163.Invoke_O__O(arg_1164) } else { arg_1089 = linked_1162.(*A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1161, arg_1164) }; if /*line :397:1*/ linked_1086 == nil { or__1927000174__auto____7 = ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { or__1927000174__auto____7 = linked_1086.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var tmp3 any = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_New_O_O(name__4, desc__5); var tmp4 *jrt.Class
		var fncls__1347 /*line :397:1*/*jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_fn_class














		if fncls__1347 == nil { var fncls__1347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_fn_class = fncls__1347d; tmp4 = fncls__1347d } else { tmp4 = fncls__1347 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp6 any; var root_1374 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = n__0; if linked_1375 == nil { tmp6 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp6 = linked_1375.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1374, arg_1377) }; cands__8 = tmp5.Invoke_O__O(tmp6)
//line :397:1
		var cands__9 any; var root_1348 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1350 lang.IFn





















		if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var tmp7 any = A_arbace_j2g_model_impl_of_fn__1479000135_A_New_O(cands__8); var tmp8 *jrt.Class; var fncls__1369 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000135_A_fn_class; if fncls__1369 == nil { var fncls__1369d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_model_impl_of_fn__1479000135_A_fn_class = fncls__1369d; tmp8 = fncls__1369d } else { tmp8 = fncls__1369 }; arg_1351 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1352 any = cands__8; if linked_1349 == nil { cands__9 = ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { cands__9 = linked_1349.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) }
		var root_1370 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = cands__9; if linked_1371 == nil { return ifn_1372.Invoke_O__O(arg_1373) } else { return linked_1371.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1370, arg_1373) } } }
//line :397:1
func A_arbace_j2g_model_impl_of_fn__1479000123_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_impl_of_fn__1479000123_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000123_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :397:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000123_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :397:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000123_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var root_1090 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1092 lang.IFn; if
											linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any; var root_1094 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = c__1; if linked_1095 == nil { arg_1093 = ifn_1096.Invoke_O__O(arg_1097) } else { arg_1093 = linked_1095.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1094, arg_1097) }; if linked_1091 == nil { and__1927000168__auto____2 = ifn_1092.Invoke_O__O(arg_1093) } else { and__1927000168__auto____2 = linked_1091.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1090, arg_1093) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1098 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = c__1; var arg_1102 any = t.F_name; var arg_1103 any = t.F_desc; if linked_1099 == nil { temp__1927000414__auto____2 = ifn_1100.Invoke_O_O_O__O(arg_1101, arg_1102, arg_1103) } else { temp__1927000414__auto____2 = linked_1099.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1098, arg_1101, arg_1102, arg_1103) } } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any; var root_1104 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1106 lang.IFn
												if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any; var root_1108 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = m__3; if linked_1109 == nil { arg_1107 = ifn_1110.Invoke_O__O(arg_1111) } else { arg_1107 = linked_1109.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1108, arg_1111) }; if linked_1105 == nil { and__1927000168__auto____4 = ifn_1106.Invoke_O__O(arg_1107) } else { and__1927000168__auto____4 = linked_1105.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1104, arg_1107) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1112 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any; var root_1116 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = m__3; if linked_1117 == nil { arg_1115 = ifn_1118.Invoke_O__O(arg_1119) } else { arg_1115 = linked_1117.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1116, arg_1119) }; if linked_1113 == nil { and__1927000168__auto____5 = ifn_1114.Invoke_O__O(arg_1115) } else { and__1927000168__auto____5 = linked_1113.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1112, arg_1115) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1120 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1122 lang.IFn
													if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any; var root_1124 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = m__3; if linked_1125 == nil { arg_1123 = ifn_1126.Invoke_O__O(arg_1127) } else { arg_1123 = linked_1125.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1124, arg_1127) }; if linked_1121 == nil { or__1927000174__auto____6 = ifn_1122.Invoke_O__O(arg_1123) } else { or__1927000174__auto____6 = linked_1121.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1120, arg_1123) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__1, t.F_n)).Ref() } } else {
//line :399:1
				tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

					if lang.Util_Equiv_O_O__Z_NoInit(c__1, Lit_20) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { var tmp2 any; var root_1128 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1130 lang.IFn

						if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = c__1; if linked_1129 == nil { tmp2 = ifn_1130.Invoke_O__O(arg_1131) } else { tmp2 = linked_1129.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1128, arg_1131) }
//line :401:1
						if jrt.J2g_Truth(tmp2) { var base__4 any; var root_1132 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1134 lang.IFn


							if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = t.F_name; var arg_1136 any = t.F_desc; if linked_1133 == nil { base__4 = ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { base__4 = linked_1133.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) }
//line :401:1
							var ms__5 any; var root_1137 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1139 lang.IFn



							if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1140 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var arg_1141 any; var root_1142 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = c__1; if linked_1143 == nil { arg_1141 = ifn_1144.Invoke_O__O(arg_1145) } else { arg_1141 = linked_1143.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1142, arg_1145) }; if linked_1138 == nil { ms__5 = ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { ms__5 = linked_1138.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) }
							var tmp4 any; var root_1146 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = ms__5; var arg_1150 any; var root_1151 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = base__4; if linked_1152 == nil { arg_1150 = ifn_1153.Invoke_O__O(arg_1154) } else { arg_1150 = linked_1152.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_1151, arg_1154) }; if linked_1147 == nil { tmp4 = ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { tmp4 = linked_1147.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) }; if jrt.J2g_Truth(tmp4) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_172, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { var tmp5 any; var root_1155 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1157 lang.IFn
								if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = ms__5; var arg_1159 any = base__4; if linked_1156 == nil { tmp5 = ifn_1157.Invoke_O_O__O(arg_1158, arg_1159) } else { tmp5 = linked_1156.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1155, arg_1158, arg_1159) }
//line :406:1
								if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil } } } } else {
//line :401:1
									if A_arbace_j2g_model_A_const_60 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_174, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { return nil } } } } else {
//line :399:1
										return nil } } else {
//line :398:1
											return nil } }













func A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A) Invoke_O_O__O(self, s__1479000126__1 any) any { var tmp1 any = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_New_O_O_O_O(self, t.F_name, t.F_desc, s__1479000126__1); var tmp2 *jrt.Class; var fncls__1346 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_fn_class; if fncls__1346 == nil { var fncls__1346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_fn_class = fncls__1346d; tmp2 = fncls__1346d } else { tmp2 = fncls__1346 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :412:1
func A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A) Ctor_O_O_O_O(c__iter__1479000125, c__name, c__desc, c__s__1479000126 any) { t.F_iter__1479000125 = c__iter__1479000125; t.F_name = c__name; t.F_desc = c__desc; t.F_s__1479000126 = c__s__1479000126 }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A) Invoke_O__O(self any) any { { var s__1479000126__1 any; var t_ any = t.F_s__1479000126; t.F_s__1479000126 = nil; s__1479000126__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1165 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = s__1479000126__1; if linked_1166 == nil { temp__1927000414__auto____2 = ifn_1167.Invoke_O__O(arg_1168) } else { temp__1927000414__auto____2 = linked_1166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1165, arg_1168) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000126__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1169 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = s__1479000126__3; if linked_1170 == nil { tmp1 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp1 = linked_1170.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1169, arg_1172) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1173 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = s__1479000126__3; if linked_1174 == nil { c__1927001037__auto____4 = ifn_1175.Invoke_O__O(arg_1176) } else { c__1927001037__auto____4 = linked_1174.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1173, arg_1176) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000128__6 any; var root_1177 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1178 == nil { b__1479000128__6 = ifn_1179.Invoke_O__O(arg_1180) } else { b__1479000128__6 = linked_1178.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1177, arg_1180) }; var tmp2 any = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_New_O_O_O_I_O(t.F_name, b__1479000128__6, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1242 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_fn_class; if fncls__1242 == nil { var fncls__1242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_fn_class = fncls__1242d; tmp3 = fncls__1242d } else { tmp3 = fncls__1242 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1243 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any; var root_1248 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = b__1479000128__6; if linked_1249 == nil { arg_1246 = ifn_1250.Invoke_O__O(arg_1251) } else { arg_1246 = linked_1249.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1248, arg_1251) }; var arg_1247 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000125); var tmp5 any; var root_1252 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = s__1479000126__3; if linked_1253 == nil { tmp5 = ifn_1254.Invoke_O__O(arg_1255) } else { tmp5 = linked_1253.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1252, arg_1255) }; arg_1247 = tmp4.Invoke_O__O(tmp5); if linked_1244 == nil { return ifn_1245.Invoke_O_O__O(arg_1246, arg_1247) } else { return linked_1244.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1243, arg_1246, arg_1247) } } else { var root_1256 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any; var root_1261 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = b__1479000128__6; if linked_1262 == nil { arg_1259 = ifn_1263.Invoke_O__O(arg_1264) } else { arg_1259 = linked_1262.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1261, arg_1264) }; var arg_1260 any; if linked_1257 == nil { return ifn_1258.Invoke_O_O__O(arg_1259, arg_1260) } else { return linked_1257.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1256, arg_1259, arg_1260) } } } else { var c__4 any; var root_1265 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = s__1479000126__3; if linked_1266 == nil { c__4 = ifn_1267.Invoke_O__O(arg_1268) } else { c__4 = linked_1266.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1265, arg_1268) }; var tmp6 any; var root_1269 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1271 lang.IFn
														if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = c__4; if linked_1270 == nil { tmp6 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp6 = linked_1270.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1269, arg_1272) }
//line :412:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_1273 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1275 lang.IFn

		if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = c__4; var arg_1277 any = t.F_name; var arg_1278 any = t.F_desc; if linked_1274 == nil { m__5 = ifn_1275.Invoke_O_O_O__O(arg_1276, arg_1277, arg_1278) } else { m__5 = linked_1274.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1273, arg_1276, arg_1277, arg_1278) }
//line :412:1
		var tmp7 any
		var and__1927000168__auto____6 any = m__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1279 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any; var root_1283 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = m__5; if linked_1284 == nil { arg_1282 = ifn_1285.Invoke_O__O(arg_1286) } else { arg_1282 = linked_1284.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1283, arg_1286) }; if linked_1280 == nil { and__1927000168__auto____7 = ifn_1281.Invoke_O__O(arg_1282) } else { and__1927000168__auto____7 = linked_1280.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1279, arg_1282) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1287 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any; var root_1291 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = m__5; if linked_1292 == nil { arg_1290 = ifn_1293.Invoke_O__O(arg_1294) } else { arg_1290 = linked_1292.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1291, arg_1294) }; if linked_1288 == nil { and__1927000168__auto____8 = ifn_1289.Invoke_O__O(arg_1290) } else { and__1927000168__auto____8 = linked_1288.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1287, arg_1290) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1295 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any; var root_1299 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = m__5; if linked_1300 == nil { arg_1298 = ifn_1301.Invoke_O__O(arg_1302) } else { arg_1298 = linked_1300.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1299, arg_1302) }; if linked_1296 == nil { tmp7 = ifn_1297.Invoke_O__O(arg_1298) } else { tmp7 = linked_1296.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1295, arg_1298) } } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 }
//line :412:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____6 any; var root_1303 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1305 lang.IFn



			if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any; var root_1307 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = c__4; if linked_1308 == nil { arg_1306 = ifn_1309.Invoke_O__O(arg_1310) } else { arg_1306 = linked_1308.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1307, arg_1310) }; if linked_1304 == nil { or__1927000174__auto____6 = ifn_1305.Invoke_O__O(arg_1306) } else { or__1927000174__auto____6 = linked_1304.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1303, arg_1306) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp8 = or__1927000174__auto____6 } else {
				var root_1311 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_136; var tmp10 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1314 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1315 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil); var tmp12 any; var root_1316 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = c__4; if linked_1317 == nil { tmp12 = ifn_1318.Invoke_O__O(arg_1319) } else { tmp12 = linked_1317.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1316, arg_1319) }; var tmp13 any = tmp12; var tmp14 any; var root_1320 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = t.F_name; var arg_1324 any = t.F_desc; if linked_1321 == nil { tmp14 = ifn_1322.Invoke_O_O__O(arg_1323, arg_1324) } else { tmp14 = linked_1321.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1320, arg_1323, arg_1324) }; arg_1315 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, tmp14)).Ref(); if linked_1312 == nil { tmp8 = ifn_1313.Invoke_O_O__O(arg_1314, arg_1315) } else { tmp8 = linked_1312.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1311, arg_1314, arg_1315) } }
//line :412:1
			if jrt.J2g_Truth(tmp8) { var root_1325 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_150, c__4, A_arbace_j2g_model_A_const_171, m__5)); var arg_1329 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1479000125); var tmp16 any; var root_1330 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = s__1479000126__3; if linked_1331 == nil { tmp16 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp16 = linked_1331.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1330, arg_1333) }; arg_1329 = tmp15.Invoke_O__O(tmp16); if linked_1326 == nil { return ifn_1327.Invoke_O_O__O(arg_1328, arg_1329) } else { return linked_1326.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1325, arg_1328, arg_1329) } } else { var tmp17 any; var root_1334 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = s__1479000126__3; if linked_1335 == nil { tmp17 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp17 = linked_1335.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1334, arg_1337) }; s__1479000126__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1338 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = s__1479000126__3; if linked_1339 == nil { tmp18 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp18 = linked_1339.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1338, arg_1341) }; s__1479000126__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1342 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = s__1479000126__3; if linked_1343 == nil { tmp19 = ifn_1344.Invoke_O__O(arg_1345) } else { tmp19 = linked_1343.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1342, arg_1345) }; s__1479000126__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :412:1
func A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A) Ctor_O_O_O_I_O(c__name, c__b__1479000128, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__1479000128 = c__b__1479000128; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A) Invoke_O__O(self any) any { { var i__1479000127__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000127__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000127__1)); var tmp2 any; var root_1181 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1183 lang.IFn
																if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = c__2; if linked_1182 == nil { tmp2 = ifn_1183.Invoke_O__O(arg_1184) } else { tmp2 = linked_1182.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1181, arg_1184) }
//line :412:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_1185 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1187 lang.IFn

		if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = c__2; var arg_1189 any = t.F_name; var arg_1190 any = t.F_desc; if linked_1186 == nil { m__3 = ifn_1187.Invoke_O_O_O__O(arg_1188, arg_1189, arg_1190) } else { m__3 = linked_1186.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1185, arg_1188, arg_1189, arg_1190) }
//line :412:1
		var tmp3 any
		var and__1927000168__auto____4 any = m__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1191 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any; var root_1195 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = m__3; if linked_1196 == nil { arg_1194 = ifn_1197.Invoke_O__O(arg_1198) } else { arg_1194 = linked_1196.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1195, arg_1198) }; if linked_1192 == nil { and__1927000168__auto____5 = ifn_1193.Invoke_O__O(arg_1194) } else { and__1927000168__auto____5 = linked_1192.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1191, arg_1194) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1199 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any; var root_1203 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = m__3; if linked_1204 == nil { arg_1202 = ifn_1205.Invoke_O__O(arg_1206) } else { arg_1202 = linked_1204.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1203, arg_1206) }; if linked_1200 == nil { and__1927000168__auto____6 = ifn_1201.Invoke_O__O(arg_1202) } else { and__1927000168__auto____6 = linked_1200.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1199, arg_1202) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1207 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any; var root_1211 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = m__3; if linked_1212 == nil { arg_1210 = ifn_1213.Invoke_O__O(arg_1214) } else { arg_1210 = linked_1212.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1211, arg_1214) }; if linked_1208 == nil { tmp3 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp3 = linked_1208.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1207, arg_1210) } } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :412:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____4 any; var root_1215 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1217 lang.IFn



			if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any; var root_1219 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = c__2; if linked_1220 == nil { arg_1218 = ifn_1221.Invoke_O__O(arg_1222) } else { arg_1218 = linked_1220.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1219, arg_1222) }; if linked_1216 == nil { or__1927000174__auto____4 = ifn_1217.Invoke_O__O(arg_1218) } else { or__1927000174__auto____4 = linked_1216.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1215, arg_1218) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else {
				var root_1223 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_136; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1226 any = tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1227 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil); var tmp8 any; var root_1228 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = c__2; if linked_1229 == nil { tmp8 = ifn_1230.Invoke_O__O(arg_1231) } else { tmp8 = linked_1229.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1228, arg_1231) }; var tmp9 any = tmp8; var tmp10 any; var root_1232 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = t.F_name; var arg_1236 any = t.F_desc; if linked_1233 == nil { tmp10 = ifn_1234.Invoke_O_O__O(arg_1235, arg_1236) } else { tmp10 = linked_1233.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1232, arg_1235, arg_1236) }; arg_1227 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref(); if linked_1224 == nil { tmp4 = ifn_1225.Invoke_O_O__O(arg_1226, arg_1227) } else { tmp4 = linked_1224.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1223, arg_1226, arg_1227) } }
//line :412:1
			if jrt.J2g_Truth(tmp4) { var root_1237 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = t.F_b__1479000128; var arg_1241 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_150, c__2, A_arbace_j2g_model_A_const_171, m__3)); if linked_1238 == nil { ifn_1239.Invoke_O_O__O(arg_1240, arg_1241) } else { linked_1238.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1237, arg_1240, arg_1241) }; i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } else { i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } } else { i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } } else { i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_model_impl_of_fn__1479000135_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000135_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000135_A{}; t.Ctor_O(p0); return t }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_A) Invoke_O_O__O(self, x__1 any) any { var root_1353 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var tmp1 any = A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_New_O(x__1); var tmp2 *jrt.Class; var fncls__1368 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_fn_class; if fncls__1368 == nil { var fncls__1368d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_fn_class = fncls__1368d; tmp2 = fncls__1368d } else { tmp2 = fncls__1368 }; arg_1356 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1357 any = t.F_cands; if linked_1354 == nil { return ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { return linked_1354.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) } }
//line :419:1
func A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A{}; t.Ctor_O(p0); return t }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A) Invoke_O_O__O(self, p1__1479000118_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1358 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(p1__1479000118_SHARP___1); var arg_1362 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(t.F_x); if linked_1359 == nil { and__1927000168__auto____2 = ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { and__1927000168__auto____2 = linked_1359.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1363 any = A_arbace_j2g_model_A_const_177.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(p1__1479000118_SHARP___1); var arg_1367 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(t.F_x); if linked_1364 == nil { return ifn_1365.Invoke_O_O__O(arg_1366, arg_1367) } else { return linked_1364.(*aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1363, arg_1366, arg_1367) } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_code_class_QMARK__A_New() *A_arbace_j2g_model_code_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_class_QMARK__A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Ctor() {}
//line :422:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_178; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_179; var tmp3 any; var root_1378 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = n__0; if linked_1379 == nil { tmp3 = ifn_1380.Invoke_O__O(arg_1381) } else { tmp3 = linked_1379.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1378, arg_1381) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)))).Ref()
}
func A_arbace_j2g_model_code_iface_QMARK__A_New() *A_arbace_j2g_model_code_iface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_iface_QMARK__A{}; t.Ctor(); return t }
//line :432:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Ctor() {}
//line :432:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1382 any = A_arbace_j2g_model_A_const_180.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = A_arbace_j2g_model_A_const_181; var arg_1386 any = n__0; if linked_1383 == nil { tmp1 = ifn_1384.Invoke_O_O__O(arg_1385, arg_1386) } else { tmp1 = linked_1383.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1382, arg_1385, arg_1386) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_nest_top_A_New() *A_arbace_j2g_model_nest_top_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_nest_top_A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_j2g_model_nest_top_A) Ctor() {}
//line :438:1
func (t *A_arbace_j2g_model_nest_top_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_39); if


	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1387 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = n__0; var arg_1391 any = A_arbace_j2g_model_A_const_31; var arg_1392 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1388 == nil { return ifn_1389.Invoke_O_O_O__O(arg_1390, arg_1391, arg_1392) } else { return linked_1388.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1387, arg_1390, arg_1391, arg_1392) } } }

func A_arbace_j2g_model_trivial_init_QMARK__A_New() *A_arbace_j2g_model_trivial_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Ctor() {}
//line :443:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_182; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var tmp2 any; var root_1393 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1395 lang.IFn; if





	linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any; var root_1398 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = cache__2; if linked_1399 == nil { arg_1396 = ifn_1400.Invoke_O__O(arg_1401) } else { arg_1396 = linked_1399.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1398, arg_1401) }; var arg_1397 any = n__0; if linked_1394 == nil { tmp2 = ifn_1395.Invoke_O_O__O(arg_1396, arg_1397) } else { tmp2 = linked_1394.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1393, arg_1396, arg_1397) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1402 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = cache__2; if linked_1403 == nil { tmp3 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp3 = linked_1403.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1402, arg_1405) }; return lang.RT_Get_O_O__O_NoInit(tmp3, n__0) } else {
//line :449:1
			var r__3 any; var tmp4 any; var root_1406 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1408 lang.IFn


			if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any; var root_1410 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = n__0; if linked_1411 == nil { arg_1409 = ifn_1412.Invoke_O__O(arg_1413) } else { arg_1409 = linked_1411.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1410, arg_1413) }; if linked_1407 == nil { tmp4 = ifn_1408.Invoke_O__O(arg_1409) } else { tmp4 = linked_1407.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1406, arg_1409) }
//line :451:1
			if jrt.J2g_Truth(tmp4) { r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1414 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1416 lang.IFn

				if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = n__0; if linked_1415 == nil { tmp5 = ifn_1416.Invoke_O__O(arg_1417) } else { tmp5 = linked_1415.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1414, arg_1417) }
//line :451:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__3 = jrt.Boolean_TRUE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__3 any; var root_1418 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1420 lang.IFn


					if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = n__0; if linked_1419 == nil { d__3 = ifn_1420.Invoke_O__O(arg_1421) } else { d__3 = linked_1419.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1418, arg_1421) }
//line :451:1
					var st__4 any; var root_1422 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1424 lang.IFn


					if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__3); if linked_1423 == nil { st__4 = ifn_1424.Invoke_O__O(arg_1425) } else { st__4 = linked_1423.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1422, arg_1425) }
//line :451:1
					var and__1927000168__auto____5 any; var root_1426 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1428 lang.IFn




					if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(st__4); if linked_1427 == nil { and__1927000168__auto____5 = ifn_1428.Invoke_O__O(arg_1429) } else { and__1927000168__auto____5 = linked_1427.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1426, arg_1429) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1430 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1432 lang.IFn
						if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = A_arbace_j2g_model_A_const_185.Invoke_O__O(st__4); if linked_1431 == nil { and__1927000168__auto____6 = ifn_1432.Invoke_O__O(arg_1433) } else { and__1927000168__auto____6 = linked_1431.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1430, arg_1433) }
//line :456:1
						if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1434 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1436 lang.IFn

							if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = A_arbace_j2g_model_A_const_186.Invoke_O__O(st__4); if linked_1435 == nil { and__1927000168__auto____7 = ifn_1436.Invoke_O__O(arg_1437) } else { and__1927000168__auto____7 = linked_1435.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1434, arg_1437) }
//line :456:1
							if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1438 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1440 lang.IFn


								if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(st__4); if linked_1439 == nil { and__1927000168__auto____8 = ifn_1440.Invoke_O__O(arg_1441) } else { and__1927000168__auto____8 = linked_1439.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1438, arg_1441) }
//line :456:1
								if jrt.J2g_Truth(and__1927000168__auto____8) { var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3), nil)



									if or__1927000174__auto____9 { r__3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1442 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3); if linked_1443 == nil { r__3 = ifn_1444.Invoke_O__O(arg_1445) } else { r__3 = linked_1443.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1442, arg_1445) } } } else {
//line :456:1
										r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :451:1
											r__3 = nil
										}
				}
			}






			var root_1446 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = cache__2; var arg_1450 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var arg_1451 any = n__0; var arg_1452 any = r__3; if linked_1447 == nil { ifn_1448.Invoke_O_O_O_O__O(arg_1449, arg_1450, arg_1451, arg_1452) } else { linked_1447.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1446, arg_1449, arg_1450, arg_1451, arg_1452) }
//line :449:1
			return r__3 } }

















func A_arbace_j2g_model_go_qualified_name_A_New() *A_arbace_j2g_model_go_qualified_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_qualified_name_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Ctor() {}
//line :467:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_1453 any = A_arbace_j2g_model_A_const_189.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any; var root_1457 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, A_arbace_j2g_model_pkg_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = n__0; if linked_1458 == nil { arg_1456 = ifn_1459.Invoke_O__O(arg_1460) } else { arg_1456 = linked_1458.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_1457, arg_1460) }; if linked_1454 == nil { tmp2 = ifn_1455.Invoke_O__O(arg_1456) } else { tmp2 = linked_1454.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A).Invoke_O_O__O(root_1453, arg_1456) }; var tmp3 any = tmp2; var tmp4 any; var root_1461 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = n__0; if linked_1462 == nil { tmp4 = ifn_1463.Invoke_O__O(arg_1464) } else { tmp4 = linked_1462.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1461, arg_1464) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
}




func A_arbace_j2g_model_start_class_QMARK__A_New() *A_arbace_j2g_model_start_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_class_QMARK__A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Ctor() {}
//line :477:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_1465 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = A_arbace_j2g_model_A_const_190.GetRawRoot__O(); if linked_1466 == nil { and__1927000168__auto____2 = ifn_1467.Invoke_O__O(arg_1468) } else { and__1927000168__auto____2 = linked_1466.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1465, arg_1468) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1469 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = n__0; if linked_1470 == nil { and__1927000168__auto____3 = ifn_1471.Invoke_O__O(arg_1472) } else { and__1927000168__auto____3 = linked_1470.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1469, arg_1472) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1473 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = A_arbace_j2g_model_A_const_190.GetRawRoot__O(); var arg_1477 any; var root_1478 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = n__0; if linked_1479 == nil { arg_1477 = ifn_1480.Invoke_O__O(arg_1481) } else { arg_1477 = linked_1479.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1478, arg_1481) }; if linked_1474 == nil { and__1927000168__auto____4 = ifn_1475.Invoke_O_O__O(arg_1476, arg_1477) } else { and__1927000168__auto____4 = linked_1474.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1473, arg_1476, arg_1477) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1482 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any; var root_1486 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = n__0; if linked_1487 == nil { arg_1485 = ifn_1488.Invoke_O__O(arg_1489) } else { arg_1485 = linked_1487.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1486, arg_1489) }; if linked_1483 == nil { tmp1 = ifn_1484.Invoke_O__O(arg_1485) } else { tmp1 = linked_1483.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1482, arg_1485) } } else {
//line :481:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_j2g_model_start_classes_A_New() *A_arbace_j2g_model_start_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_A{}; t.Ctor(); return t }
//line :484:1
func (t *A_arbace_j2g_model_start_classes_A) Ctor() {}
//line :484:1
func (t *A_arbace_j2g_model_start_classes_A) Invoke_O__O(self any) any { var by_go__1 any; var root_1490 any = A_arbace_j2g_model_A_const_192.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1492 lang.IFn; if


	linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1494 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_New(); var tmp2 *jrt.Class; var fncls__1573 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_fn_class; if fncls__1573 == nil { var fncls__1573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_fn_class = fncls__1573d; tmp2 = fncls__1573d } else { tmp2 = fncls__1573 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp4 any; var root_1574 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, A_arbace_j2g_model_T_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; if linked_1575 == nil { tmp4 = ifn_1576.Invoke__O() } else { tmp4 = linked_1575.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_1574) }; arg_1494 = tmp3.Invoke_O__O(tmp4); if linked_1491 == nil { by_go__1 = ifn_1492.Invoke_O_O__O(arg_1493, arg_1494) } else { by_go__1 = linked_1491.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1490, arg_1493, arg_1494) }; var root_1577 any =
	A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = by_go__1; var arg_1581 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); if linked_1578 == nil { return ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { return linked_1578.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) } }
//line :487:1
func A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_New() *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A) Ctor() {}
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A) Invoke_O_O__O(self, s__1479000147__1 any) any { var tmp1 any = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_New_O_O(self, s__1479000147__1); var tmp2 *jrt.Class; var fncls__1572 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_fn_class; if fncls__1572 == nil { var fncls__1572d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_fn_class = fncls__1572d; tmp2 = fncls__1572d } else { tmp2 = fncls__1572 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :487:1
func A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A{}; t.Ctor_O_O(p0, p1); return t }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A) Ctor_O_O(c__iter__1479000146, c__s__1479000147 any) { t.F_iter__1479000146 = c__iter__1479000146; t.F_s__1479000147 = c__s__1479000147 }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A) Invoke_O__O(self any) any { { var s__1479000147__1 any; var t_ any = t.F_s__1479000147; t.F_s__1479000147 = nil; s__1479000147__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1495 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = s__1479000147__1; if linked_1496 == nil { temp__1927000414__auto____2 = ifn_1497.Invoke_O__O(arg_1498) } else { temp__1927000414__auto____2 = linked_1496.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1495, arg_1498) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000147__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1499 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = s__1479000147__3; if linked_1500 == nil { tmp1 = ifn_1501.Invoke_O__O(arg_1502) } else { tmp1 = linked_1500.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1499, arg_1502) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1503 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = s__1479000147__3; if linked_1504 == nil { c__1927001037__auto____4 = ifn_1505.Invoke_O__O(arg_1506) } else { c__1927001037__auto____4 = linked_1504.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1503, arg_1506) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000149__6 any; var root_1507 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1508 == nil { b__1479000149__6 = ifn_1509.Invoke_O__O(arg_1510) } else { b__1479000149__6 = linked_1508.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1507, arg_1510) }; var tmp2 any = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_New_O_I_O(b__1479000149__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1524 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_fn_class; if fncls__1524 == nil { var fncls__1524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_fn_class = fncls__1524d; tmp3 = fncls__1524d } else { tmp3 = fncls__1524 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1525 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any; var root_1530 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = b__1479000149__6; if linked_1531 == nil { arg_1528 = ifn_1532.Invoke_O__O(arg_1533) } else { arg_1528 = linked_1531.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1530, arg_1533) }; var arg_1529 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000146); var tmp5 any; var root_1534 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = s__1479000147__3; if linked_1535 == nil { tmp5 = ifn_1536.Invoke_O__O(arg_1537) } else { tmp5 = linked_1535.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1534, arg_1537) }; arg_1529 = tmp4.Invoke_O__O(tmp5); if linked_1526 == nil { return ifn_1527.Invoke_O_O__O(arg_1528, arg_1529) } else { return linked_1526.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1525, arg_1528, arg_1529) } } else { var root_1538 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any; var root_1543 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = b__1479000149__6; if linked_1544 == nil { arg_1541 = ifn_1545.Invoke_O__O(arg_1546) } else { arg_1541 = linked_1544.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1543, arg_1546) }; var arg_1542 any; if linked_1539 == nil { return ifn_1540.Invoke_O_O__O(arg_1541, arg_1542) } else { return linked_1539.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1538, arg_1541, arg_1542) } } } else { var n__4 any; var root_1547 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = s__1479000147__3; if linked_1548 == nil { n__4 = ifn_1549.Invoke_O__O(arg_1550) } else { n__4 = linked_1548.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1547, arg_1550) }; var tmp6 any; var root_1551 any = A_arbace_j2g_model_A_const_193.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = n__4; if linked_1552 == nil { tmp6 = ifn_1553.Invoke_O__O(arg_1554) } else { tmp6 = linked_1552.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1551, arg_1554) }; if jrt.J2g_Truth(tmp6) { var root_1555 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any; var tmp7 any; var root_1560 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = n__4; if linked_1561 == nil { tmp7 = ifn_1562.Invoke_O__O(arg_1563) } else { tmp7 = linked_1561.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1560, arg_1563) }; arg_1558 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, n__4); var arg_1559 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000146); var tmp9 any; var root_1564 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = s__1479000147__3; if linked_1565 == nil { tmp9 = ifn_1566.Invoke_O__O(arg_1567) } else { tmp9 = linked_1565.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1564, arg_1567) }; arg_1559 = tmp8.Invoke_O__O(tmp9); if linked_1556 == nil { return ifn_1557.Invoke_O_O__O(arg_1558, arg_1559) } else { return linked_1556.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1555, arg_1558, arg_1559) } } else { var tmp10 any; var root_1568 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = s__1479000147__3; if linked_1569 == nil { tmp10 = ifn_1570.Invoke_O__O(arg_1571) } else { tmp10 = linked_1569.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1568, arg_1571) }; s__1479000147__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :487:1
func A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A) Ctor_O_I_O(c__b__1479000149 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000149 = c__b__1479000149; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A) Invoke_O__O(self any) any { { var i__1479000148__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000148__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000148__1)); var tmp2 any; var root_1511 any = A_arbace_j2g_model_A_const_193.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = n__2; if linked_1512 == nil { tmp2 = ifn_1513.Invoke_O__O(arg_1514) } else { tmp2 = linked_1512.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1511, arg_1514) }; if jrt.J2g_Truth(tmp2) { var root_1515 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = t.F_b__1479000149; var arg_1519 any; var tmp3 any; var root_1520 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = n__2; if linked_1521 == nil { tmp3 = ifn_1522.Invoke_O__O(arg_1523) } else { tmp3 = linked_1521.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1520, arg_1523) }; arg_1519 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, n__2); if linked_1516 == nil { ifn_1517.Invoke_O_O__O(arg_1518, arg_1519) } else { linked_1516.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1515, arg_1518, arg_1519) }; i__1479000148__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000148__1); continue L1 } else { i__1479000148__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000148__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_model_top_class_A_New() *A_arbace_j2g_model_top_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_top_class_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_j2g_model_top_class_A) Ctor() {}
//line :495:1
func (t *A_arbace_j2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_39); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1582 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = n__0; var arg_1586 any = A_arbace_j2g_model_A_const_31; var arg_1587 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1583 == nil { return ifn_1584.Invoke_O_O_O__O(arg_1585, arg_1586, arg_1587) } else { return linked_1583.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1582, arg_1585, arg_1586, arg_1587) } } }

func A_arbace_j2g_model_pure_ctor_QMARK__A_New() *A_arbace_j2g_model_pure_ctor_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :497:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any; var root_1588 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1590 lang.IFn; if




	linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = c__1; if linked_1589 == nil { d__5 = ifn_1590.Invoke_O__O(arg_1591) } else { d__5 = linked_1589.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1588, arg_1591) }; var ab__6 any; if
	jrt.J2g_Truth(d__5) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_196; var tmp2 any; var root_1592 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__5); if linked_1593 == nil { tmp2 = ifn_1594.Invoke_O__O(arg_1595) } else { tmp2 = linked_1593.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1592, arg_1595) }; ab__6 = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), lang.Tuple_Create_O_O__IPersistentVector(Lit_44, A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_1596 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = c__1; if linked_1597 == nil { and__1927000168__auto____9 = ifn_1598.Invoke_O__O(arg_1599) } else { and__1927000168__auto____9 = linked_1597.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1596, arg_1599) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp3 any; var root_1600 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1602 lang.IFn
		if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any = c__1; if linked_1601 == nil { tmp3 = ifn_1602.Invoke_O__O(arg_1603) } else { tmp3 = linked_1601.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1600, arg_1603) }; var tmp4 any = tmp3; var tmp5 any; var root_1604 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = n__0; if linked_1605 == nil { tmp5 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp5 = linked_1605.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1604, arg_1607) }; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)
//line :504:1
		if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_1608 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1610 lang.IFn

			if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any; var root_1612 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = seen__3; var arg_1616 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2)); if linked_1613 == nil { arg_1611 = ifn_1614.Invoke_O_O__O(arg_1615, arg_1616) } else { arg_1611 = linked_1613.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1612, arg_1615, arg_1616) }; if linked_1609 == nil { and__1927000168__auto____11 = ifn_1610.Invoke_O__O(arg_1611) } else { and__1927000168__auto____11 = linked_1609.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1608, arg_1611) }
//line :504:1
			if jrt.J2g_Truth(and__1927000168__auto____11) { var seen__12 any; var root_1617 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1619 lang.IFn


				if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = seen__3; var arg_1621 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2)); if linked_1618 == nil { seen__12 = ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { seen__12 = linked_1618.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1617, arg_1620, arg_1621) }
//line :504:1
				var call__13 any = A_arbace_j2g_model_A_const_198.Invoke_O__O(ab__6); var sup__14 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__5); var and__1927000168__auto____15 any; var root_1622 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1624 lang.IFn





				if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = A_arbace_j2g_model_A_const_199.Invoke_O__O(ab__6); if linked_1623 == nil { and__1927000168__auto____15 = ifn_1624.Invoke_O__O(arg_1625) } else { and__1927000168__auto____15 = linked_1623.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1622, arg_1625) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1626 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1628 lang.IFn
					if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = A_arbace_j2g_model_A_const_200.Invoke_O__O(ab__6); if linked_1627 == nil { and__1927000168__auto____16 = ifn_1628.Invoke_O__O(arg_1629) } else { and__1927000168__auto____16 = linked_1627.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1626, arg_1629) }
//line :510:1
					if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z_NoInit(call__13, nil)

						if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var root_1630 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1632 lang.IFn
							if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any; var tmp6 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_New_O_O(n__0, seen__12); var tmp7 *jrt.Class; var fncls__1641 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_fn_class; if fncls__1641 == nil { var fncls__1641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_fn_class = fncls__1641d; tmp7 = fncls__1641d } else { tmp7 = fncls__1641 }; arg_1633 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1634 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(call__13); if linked_1631 == nil { and__1927000168__auto____18 = ifn_1632.Invoke_O_O__O(arg_1633, arg_1634) } else { and__1927000168__auto____18 = linked_1631.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1630, arg_1633, arg_1634) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_174.Invoke_O__O(call__13), nil)
								if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19).Ref() } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_203); var or__1927000174__auto____20 any = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_174.Invoke_O__O(call__13)); if jrt.J2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
									var root_1642 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = n__0; var arg_1646 any = A_arbace_j2g_model_A_const_174.Invoke_O__O(call__13); var arg_1647 any = A_arbace_j2g_model_A_const_205.Invoke_O__O(call__13); var arg_1648 any = seen__12; if linked_1643 == nil { and__1927000168__auto____17 = ifn_1644.Invoke_O_O_O_O__O(arg_1645, arg_1646, arg_1647, arg_1648) } else { and__1927000168__auto____17 = linked_1643.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1642, arg_1645, arg_1646, arg_1647, arg_1648) } } } } else {
//line :513:1
										and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :510:1
						if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any; var root_1649 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1651 lang.IFn





							if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = call__13; if linked_1650 == nil { or__1927000174__auto____18 = ifn_1651.Invoke_O__O(arg_1652) } else { or__1927000174__auto____18 = linked_1650.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1649, arg_1652) }; if jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z_NoInit(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sup__14, Lit_20)).Ref() } }
//line :510:1
							if jrt.J2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var root_1653 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1655 lang.IFn






								if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any; var tmp9 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_New_O_O(n__0, seen__12); var tmp10 *jrt.Class; var fncls__1664 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_fn_class; if fncls__1664 == nil { var fncls__1664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_fn_class = fncls__1664d; tmp10 = fncls__1664d } else { tmp10 = fncls__1664 }; arg_1656 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1657 any; var tmp11 *lang.Keyword = A_arbace_j2g_model_A_const_206; var tmp12 any; var root_1665 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__5); if linked_1666 == nil { tmp12 = ifn_1667.Invoke_O__O(arg_1668) } else { tmp12 = linked_1666.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1665, arg_1668) }; arg_1657 = tmp11.Invoke_O__O(tmp12); if linked_1654 == nil { and__1927000168__auto____19 = ifn_1655.Invoke_O_O__O(arg_1656, arg_1657) } else { and__1927000168__auto____19 = linked_1654.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1653, arg_1656, arg_1657) }
//line :510:1
								if jrt.J2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_207.Invoke_O__O(ab__6), nil)







									if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20_2).Ref() } else { var root_1669 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = n__0; var arg_1673 any = A_arbace_j2g_model_A_const_207.Invoke_O__O(ab__6); var arg_1674 any = seen__12; if linked_1670 == nil { return ifn_1671.Invoke_O_O_O__O(arg_1672, arg_1673, arg_1674) } else { return linked_1670.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1669, arg_1672, arg_1673, arg_1674) } } } else {
//line :510:1
										return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :504:1
											return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A{}; t.Ctor_O_O(p0, p1); return t }
//line :513:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :513:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A) Invoke_O_O__O(self, p1__1479000158_SHARP___1 any) any { var root_1635 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = t.F_n; var arg_1639 any = p1__1479000158_SHARP___1; var arg_1640 any = t.F_seen; if linked_1636 == nil { return ifn_1637.Invoke_O_O_O__O(arg_1638, arg_1639, arg_1640) } else { return linked_1636.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1635, arg_1638, arg_1639, arg_1640) } }



func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :517:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :517:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A) Invoke_O_O__O(self, p1__1479000159_SHARP___1 any) any { var root_1658 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = t.F_n; var arg_1662 any = p1__1479000159_SHARP___1; var arg_1663 any = t.F_seen; if linked_1659 == nil { return ifn_1660.Invoke_O_O_O__O(arg_1661, arg_1662, arg_1663) } else { return linked_1659.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1658, arg_1661, arg_1662, arg_1663) } }


func A_arbace_j2g_model_pure_node_QMARK__A_New() *A_arbace_j2g_model_pure_node_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Ctor() {}
//line :520:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1479000171__4_ any = A_arbace_j2g_model_A_const_208.Invoke_O__O(node__1); switch



	lang.Util_Hash_O__I_NoInit(G__1479000171__4_) >> 3 & 63 { case 1: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_209) { var and__1927000168__auto____5 any; var root_1676 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1678 lang.IFn


















		if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = A_arbace_j2g_model_A_const_210.Invoke_O__O(node__1); if linked_1677 == nil { and__1927000168__auto____5 = ifn_1678.Invoke_O__O(arg_1679) } else { and__1927000168__auto____5 = linked_1677.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1676, arg_1679) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1680 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = A_arbace_j2g_model_A_const_211.Invoke_O__O(node__1); if linked_1681 == nil { and__1927000168__auto____6 = ifn_1682.Invoke_O__O(arg_1683) } else { and__1927000168__auto____6 = linked_1681.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1680, arg_1683) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1684 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = n__0; var arg_1688 any = A_arbace_j2g_model_A_const_212.Invoke_O__O(node__1); var arg_1689 any = seen__2; if linked_1685 == nil { return ifn_1686.Invoke_O_O_O__O(arg_1687, arg_1688, arg_1689) } else { return linked_1685.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1684, arg_1687, arg_1688, arg_1689) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :524:1
	case 11: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_213) { var tmp1 any = A_arbace_j2g_model_A_const_214; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_208; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_215.Invoke_O__O(node__1)))







		if and__1927000168__auto____5_2 { var and__1927000168__auto____6_2 any; var root_1690 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_216; var arg_1693 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_215.Invoke_O__O(node__1)); if linked_1691 == nil { and__1927000168__auto____6_2 = ifn_1692.Invoke_O__O(arg_1693) } else { and__1927000168__auto____6_2 = linked_1691.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1690, arg_1693) }; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var root_1694 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1694, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any = n__0; var arg_1698 any = A_arbace_j2g_model_A_const_217.Invoke_O__O(node__1); var arg_1699 any = seen__2; if linked_1695 == nil { return ifn_1696.Invoke_O_O_O__O(arg_1697, arg_1698, arg_1699) } else { return linked_1695.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1694, arg_1697, arg_1698, arg_1699) } } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() } }
//line :524:1
	case 13: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_218) { var tmp4 any = A_arbace_j2g_model_A_const_219; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_j2g_model_A_const_169.Invoke_O__O(node__1))













		if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_model_A_const_150.Invoke_O__O(node__1))
			if and__1927000168__auto____6_4 { or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_48, A_arbace_j2g_model_A_const_124.Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, A_arbace_j2g_model_A_const_150.Invoke_O__O(node__1))

				if and__1927000168__auto____7 { and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_49, A_arbace_j2g_model_A_const_124.Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :538:1
			if and__1927000168__auto____6_3 {



				var root_1700 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any; var tmp5 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_New_O_O(n__0, seen__2); var tmp6 *jrt.Class; var fncls__1711 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_fn_class; if fncls__1711 == nil { var fncls__1711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_fn_class = fncls__1711d; tmp6 = fncls__1711d } else { tmp6 = fncls__1711 }; arg_1703 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1704 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(node__1); if linked_1701 == nil { return ifn_1702.Invoke_O_O__O(arg_1703, arg_1704) } else { return linked_1701.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1700, arg_1703, arg_1704) } } else {
//line :538:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_3).Ref() } }
//line :524:1
	case 14: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_220) { var and__1927000168__auto____5_4 bool; var tmp7 any; var tmp8 *lang.Keyword = A_arbace_j2g_model_A_const_221; var or__1927000174__auto____5 any = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1))






		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else { var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_150; tmp7 = tmp9.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp7); if and__1927000168__auto____5_4 { var root_1712 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = n__0; var arg_1716 any = A_arbace_j2g_model_A_const_217.Invoke_O__O(node__1); var arg_1717 any = seen__2; if linked_1713 == nil { return ifn_1714.Invoke_O_O_O__O(arg_1715, arg_1716, arg_1717) } else { return linked_1713.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1712, arg_1715, arg_1716, arg_1717) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_4).Ref() } }
//line :524:1
	case 15: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_214) { return jrt.Boolean_TRUE.Ref() }; case 19: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_223) { var and__1927000168__auto____5_5 any; var root_1718 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1720 lang.IFn


		if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any; var tmp10 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_New_O_O(n__0, seen__2); var tmp11 *jrt.Class; var fncls__1729 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_fn_class; if fncls__1729 == nil { var fncls__1729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_fn_class = fncls__1729d; tmp11 = fncls__1729d } else { tmp11 = fncls__1729 }; arg_1721 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1722 any = A_arbace_j2g_model_A_const_224.Invoke_O__O(node__1); if linked_1719 == nil { and__1927000168__auto____5_5 = ifn_1720.Invoke_O_O__O(arg_1721, arg_1722) } else { and__1927000168__auto____5_5 = linked_1719.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1718, arg_1721, arg_1722) }; if jrt.J2g_Truth(and__1927000168__auto____5_5) { var root_1730 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = n__0; var arg_1734 any = A_arbace_j2g_model_A_const_207.Invoke_O__O(node__1); var arg_1735 any = seen__2; if linked_1731 == nil { return ifn_1732.Invoke_O_O_O__O(arg_1733, arg_1734, arg_1735) } else { return linked_1731.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1730, arg_1733, arg_1734, arg_1735) } } else { return and__1927000168__auto____5_5 } }
//line :524:1
	case 21: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_225) {





		var tmp12 any; var tmp13 *lang.Keyword = A_arbace_j2g_model_A_const_221; var or__1927000174__auto____5_2 any = tmp13.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp12 = or__1927000174__auto____5_2 } else { var tmp14 *lang.Keyword = A_arbace_j2g_model_A_const_150; tmp12 = tmp14.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp12)).Ref() }
//line :524:1
	case 25: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_226) { var and__1927000168__auto____5_6 any; var root_1736 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1738 lang.IFn

		if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any; var tmp15 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_New_O_O(n__0, seen__2); var tmp16 *jrt.Class; var fncls__1747 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_fn_class; if fncls__1747 == nil { var fncls__1747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_fn_class = fncls__1747d; tmp16 = fncls__1747d } else { tmp16 = fncls__1747 }; arg_1739 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_1740 any = A_arbace_j2g_model_A_const_227.Invoke_O__O(node__1); if linked_1737 == nil { and__1927000168__auto____5_6 = ifn_1738.Invoke_O_O__O(arg_1739, arg_1740) } else { and__1927000168__auto____5_6 = linked_1737.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1736, arg_1739, arg_1740) }; if jrt.J2g_Truth(and__1927000168__auto____5_6) { var root_1748 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = n__0; var arg_1752 any = A_arbace_j2g_model_A_const_228.Invoke_O__O(node__1); var arg_1753 any = seen__2; if linked_1749 == nil { return ifn_1750.Invoke_O_O_O__O(arg_1751, arg_1752, arg_1753) } else { return linked_1749.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1748, arg_1751, arg_1752, arg_1753) } } else { return and__1927000168__auto____5_6 } }
//line :524:1
	case 29: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_229) { return jrt.Boolean_TRUE.Ref() }; case 30: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_230) { return jrt.Boolean_TRUE.Ref() }; case 34: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_231) {




		var root_1754 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any; var tmp17 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_New(); var tmp18 *jrt.Class; var fncls__1767 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_fn_class; if fncls__1767 == nil { var fncls__1767d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_fn_class = fncls__1767d; tmp18 = fncls__1767d } else { tmp18 = fncls__1767 }; arg_1757 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1758 any = A_arbace_j2g_model_A_const_233.Invoke_O__O(node__1); if linked_1755 == nil { return ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { return linked_1755.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) } }
//line :524:1
	case 39: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_234) { var and__1927000168__auto____5_7 any; var root_1768 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1770 lang.IFn








		if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any; var tmp19 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_New_O_O(n__0, seen__2); var tmp20 *jrt.Class; var fncls__1779 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_fn_class; if fncls__1779 == nil { var fncls__1779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_fn_class = fncls__1779d; tmp20 = fncls__1779d } else { tmp20 = fncls__1779 }; arg_1771 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_1772 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(node__1); if linked_1769 == nil { and__1927000168__auto____5_7 = ifn_1770.Invoke_O_O__O(arg_1771, arg_1772) } else { and__1927000168__auto____5_7 = linked_1769.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1768, arg_1771, arg_1772) }; if jrt.J2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_235.Invoke_O__O(node__1), nil); if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_20, A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1))

			if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1), n__0)
				if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_1780 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1782 lang.IFn; if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1); if linked_1781 == nil { and__1927000168__auto____8 = ifn_1782.Invoke_O__O(arg_1783) } else { and__1927000168__auto____8 = linked_1781.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1780, arg_1783) } }; if jrt.J2g_Truth(and__1927000168__auto____8) {
					var root_1784 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = n__0; var arg_1788 any = A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1); var arg_1789 any = A_arbace_j2g_model_A_const_205.Invoke_O__O(node__1); var arg_1790 any = seen__2; if linked_1785 == nil { return ifn_1786.Invoke_O_O_O_O__O(arg_1787, arg_1788, arg_1789, arg_1790) } else { return linked_1785.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1784, arg_1787, arg_1788, arg_1789, arg_1790) } } else {
//line :536:1
						return and__1927000168__auto____8 } } } else {
//line :533:1
							return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :524:1
	case 43: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_236) { var and__1927000168__auto____5_8 any; var root_1791 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1793 lang.IFn



















		if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_237); var arg_1794 any = tmp21.Invoke_O__O(A_arbace_j2g_model_A_const_238.Invoke_O__O(node__1)); if linked_1792 == nil { and__1927000168__auto____5_8 = ifn_1793.Invoke_O__O(arg_1794) } else { and__1927000168__auto____5_8 = linked_1792.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1791, arg_1794) }; if jrt.J2g_Truth(and__1927000168__auto____5_8) { var and__1927000168__auto____6_6 any; var root_1795 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = A_arbace_j2g_model_A_const_239; var arg_1799 any = A_arbace_j2g_model_A_const_240.Invoke_O__O(node__1); if linked_1796 == nil { and__1927000168__auto____6_6 = ifn_1797.Invoke_O_O__O(arg_1798, arg_1799) } else { and__1927000168__auto____6_6 = linked_1796.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1795, arg_1798, arg_1799) }; if jrt.J2g_Truth(and__1927000168__auto____6_6) { var root_1800 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any; var tmp22 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_New_O_O(n__0, seen__2); var tmp23 *jrt.Class; var fncls__1811 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_fn_class; if fncls__1811 == nil { var fncls__1811d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_fn_class = fncls__1811d; tmp23 = fncls__1811d } else { tmp23 = fncls__1811 }; arg_1803 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_1804 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(node__1); if linked_1801 == nil { return ifn_1802.Invoke_O_O__O(arg_1803, arg_1804) } else { return linked_1801.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1800, arg_1803, arg_1804) } } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :524:1
	case 44: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_241) { return jrt.Boolean_TRUE.Ref() }; case 46: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_242) {



		var root_1812 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1814 lang.IFn; if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any; var tmp24 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_New_O_O(n__0, seen__2); var tmp25 *jrt.Class; var fncls__1823 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_fn_class; if fncls__1823 == nil { var fncls__1823d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_fn_class = fncls__1823d; tmp25 = fncls__1823d } else { tmp25 = fncls__1823 }; arg_1815 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var arg_1816 any = A_arbace_j2g_model_A_const_243.Invoke_O__O(node__1); if linked_1813 == nil { return ifn_1814.Invoke_O_O__O(arg_1815, arg_1816) } else { return linked_1813.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1812, arg_1815, arg_1816) } }
//line :524:1
	default:}; return jrt.Boolean_FALSE.Ref() }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A{}; t.Ctor_O_O(p0, p1); return t }
//line :526:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :526:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A) Invoke_O_O__O(self, p1__1479000165_SHARP___1 any) any { var root_1741 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = t.F_n; var arg_1745 any = p1__1479000165_SHARP___1; var arg_1746 any = t.F_seen; if linked_1742 == nil { return ifn_1743.Invoke_O_O_O__O(arg_1744, arg_1745, arg_1746) } else { return linked_1742.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1741, arg_1744, arg_1745, arg_1746) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A{}; t.Ctor_O_O(p0, p1); return t }
//line :527:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :527:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A) Invoke_O_O__O(self, p__1479000174__1 any) any { var vec__1479000176__2 any = p__1479000174__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1723 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1725 lang.IFn; _ = ___3; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = t.F_n; var arg_1727 any = init__4; var arg_1728 any = t.F_seen; if linked_1724 == nil { return ifn_1725.Invoke_O_O_O__O(arg_1726, arg_1727, arg_1728) } else { return linked_1724.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1723, arg_1726, arg_1727, arg_1728) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A{}; t.Ctor_O_O(p0, p1); return t }
//line :528:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :528:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A) Invoke_O_O__O(self, p1__1479000166_SHARP___1 any) any { var root_1817 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = t.F_n; var arg_1821 any = p1__1479000166_SHARP___1; var arg_1822 any = t.F_seen; if linked_1818 == nil { return ifn_1819.Invoke_O_O_O__O(arg_1820, arg_1821, arg_1822) } else { return linked_1818.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1817, arg_1820, arg_1821, arg_1822) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_New() *A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A{}; t.Ctor(); return t }
//line :529:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A) Ctor() {}
//line :529:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A) Invoke_O_O__O(self, p1__1479000167_SHARP___1 any) any { var tmp1 any = A_arbace_j2g_model_A_const_229; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_model_A_const_208.Invoke_O__O(p1__1479000167_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_1759 any = A_arbace_j2g_model_A_const_232.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = A_arbace_j2g_model_A_const_217.Invoke_O__O(p1__1479000167_SHARP___1); if linked_1760 == nil { and__1927000168__auto____3 = ifn_1761.Invoke_O__O(arg_1762) } else { and__1927000168__auto____3 = linked_1760.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_1759, arg_1762) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1763 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_j2g_model_A_const_217.Invoke_O__O(p1__1479000167_SHARP___1)))).Ref(); if linked_1764 == nil { return ifn_1765.Invoke_O__O(arg_1766) } else { return linked_1764.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1763, arg_1766) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A{}; t.Ctor_O_O(p0, p1); return t }
//line :533:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :533:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A) Invoke_O_O__O(self, p1__1479000168_SHARP___1 any) any { var root_1773 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = t.F_n; var arg_1777 any = p1__1479000168_SHARP___1; var arg_1778 any = t.F_seen; if linked_1774 == nil { return ifn_1775.Invoke_O_O_O__O(arg_1776, arg_1777, arg_1778) } else { return linked_1774.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1773, arg_1776, arg_1777, arg_1778) } }








func A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A{}; t.Ctor_O_O(p0, p1); return t }
//line :542:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :542:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A) Invoke_O_O__O(self, p1__1479000169_SHARP___1 any) any { var root_1705 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = t.F_n; var arg_1709 any = p1__1479000169_SHARP___1; var arg_1710 any = t.F_seen; if linked_1706 == nil { return ifn_1707.Invoke_O_O_O__O(arg_1708, arg_1709, arg_1710) } else { return linked_1706.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1705, arg_1708, arg_1709, arg_1710) } }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :544:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :544:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A) Invoke_O_O__O(self, p1__1479000170_SHARP___1 any) any { var root_1805 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = t.F_n; var arg_1809 any = p1__1479000170_SHARP___1; var arg_1810 any = t.F_seen; if linked_1806 == nil { return ifn_1807.Invoke_O_O_O__O(arg_1808, arg_1809, arg_1810) } else { return linked_1806.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1805, arg_1808, arg_1809, arg_1810) } }


func A_arbace_j2g_model_benign_init_QMARK__A_New() *A_arbace_j2g_model_benign_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :547:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Ctor() {}
//line :547:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_182; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_245, n__0); var tmp2 any; var root_1824 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1826 lang.IFn; if








	linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any; var root_1829 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = cache__2; if linked_1830 == nil { arg_1827 = ifn_1831.Invoke_O__O(arg_1832) } else { arg_1827 = linked_1830.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1829, arg_1832) }; var arg_1828 any = k__3; if linked_1825 == nil { tmp2 = ifn_1826.Invoke_O_O__O(arg_1827, arg_1828) } else { tmp2 = linked_1825.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1824, arg_1827, arg_1828) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1833 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = cache__2; if linked_1834 == nil { tmp3 = ifn_1835.Invoke_O__O(arg_1836) } else { tmp3 = linked_1834.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1833, arg_1836) }; return lang.RT_Get_O_O__O_NoInit(tmp3, k__3) } else {
//line :556:1
			var r__4 any; var tmp4 any; var root_1837 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1839 lang.IFn


			if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = n__0; if linked_1838 == nil { tmp4 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp4 = linked_1838.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1837, arg_1840) }
//line :558:1
			if jrt.J2g_Truth(tmp4) { r__4 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1841 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1843 lang.IFn

				if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = n__0; if linked_1842 == nil { tmp5 = ifn_1843.Invoke_O__O(arg_1844) } else { tmp5 = linked_1842.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1841, arg_1844) }
//line :558:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__4 = jrt.Boolean_FALSE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__4 any; var root_1845 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1847 lang.IFn


					if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = n__0; if linked_1846 == nil { d__4 = ifn_1847.Invoke_O__O(arg_1848) } else { d__4 = linked_1846.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1845, arg_1848) }
//line :558:1
					var st__5 any; var root_1849 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1851 lang.IFn


					if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__4); if linked_1850 == nil { st__5 = ifn_1851.Invoke_O__O(arg_1852) } else { st__5 = linked_1850.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1849, arg_1852) }
//line :558:1
					var and__1927000168__auto____6 any; var root_1853 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1855 lang.IFn




					if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = A_arbace_j2g_model_A_const_185.Invoke_O__O(st__5); if linked_1854 == nil { and__1927000168__auto____6 = ifn_1855.Invoke_O__O(arg_1856) } else { and__1927000168__auto____6 = linked_1854.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1853, arg_1856) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1857 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1859 lang.IFn
						if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = A_arbace_j2g_model_A_const_186.Invoke_O__O(st__5); if linked_1858 == nil { and__1927000168__auto____7 = ifn_1859.Invoke_O__O(arg_1860) } else { and__1927000168__auto____7 = linked_1858.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1857, arg_1860) }
//line :563:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1861 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1863 lang.IFn

							if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(st__5); if linked_1862 == nil { and__1927000168__auto____8 = ifn_1863.Invoke_O__O(arg_1864) } else { and__1927000168__auto____8 = linked_1862.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1861, arg_1864) }
//line :563:1
							if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4), nil)


								if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1865 any = A_arbace_j2g_model_A_const_244.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, A_arbace_j2g_model_benign_init_QMARK__A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4); if linked_1866 == nil { and__1927000168__auto____9 = ifn_1867.Invoke_O__O(arg_1868) } else { and__1927000168__auto____9 = linked_1866.(*A_arbace_j2g_model_benign_init_QMARK__A).Invoke_O_O__O(root_1865, arg_1868) } }
//line :563:1
								if jrt.J2g_Truth(and__1927000168__auto____9) {



									var root_1869 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any; var tmp6 any = A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_New_O(n__0); var tmp7 *jrt.Class; var fncls__1880 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_fn_class; if fncls__1880 == nil { var fncls__1880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_fn_class = fncls__1880d; tmp7 = fncls__1880d } else { tmp7 = fncls__1880 }; arg_1872 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1873 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(st__5); if linked_1870 == nil { r__4 = ifn_1871.Invoke_O_O__O(arg_1872, arg_1873) } else { r__4 = linked_1870.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1869, arg_1872, arg_1873) } } else {
//line :563:1
										r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :558:1
											r__4 = nil
										}
				}
			}






			var root_1881 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = cache__2; var arg_1885 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var arg_1886 any = k__3; var arg_1887 any = r__4; if linked_1882 == nil { ifn_1883.Invoke_O_O_O_O__O(arg_1884, arg_1885, arg_1886, arg_1887) } else { linked_1882.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1881, arg_1884, arg_1885, arg_1886, arg_1887) }
//line :556:1
			return r__4 } }










func A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_New_O(p0 any) *A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A{}; t.Ctor_O(p0); return t }
//line :567:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :567:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A) Invoke_O_O__O(self, p1__1479000191_SHARP___1 any) any { var root_1874 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = t.F_n; var arg_1878 any = p1__1479000191_SHARP___1; var arg_1879 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1875 == nil { return ifn_1876.Invoke_O_O_O__O(arg_1877, arg_1878, arg_1879) } else { return linked_1875.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1874, arg_1877, arg_1878, arg_1879) } }

































































type A_arbace_j2g_model_A struct{ jrt.Object }

var A_arbace_j2g_model_A_const_pool *jrt.RefArray

var A_arbace_j2g_model_A_const_0 *lang.Var

var A_arbace_j2g_model_A_const_1 any

var A_arbace_j2g_model_A_const_2 any

var A_arbace_j2g_model_A_const_3 any

var A_arbace_j2g_model_A_const_4 any

var A_arbace_j2g_model_A_const_5 any

var A_arbace_j2g_model_A_const_6 any

var A_arbace_j2g_model_A_const_7 any

var A_arbace_j2g_model_A_const_8 any

var A_arbace_j2g_model_A_const_9 *lang.Var

var A_arbace_j2g_model_A_const_10 any

var A_arbace_j2g_model_A_const_11 *lang.Var

var A_arbace_j2g_model_A_const_12 *lang.Var

var A_arbace_j2g_model_A_const_13 *lang.Var

var A_arbace_j2g_model_A_const_14 *lang.Var

var A_arbace_j2g_model_A_const_15 any

var A_arbace_j2g_model_A_const_16 *lang.Var

var A_arbace_j2g_model_A_const_17 *lang.Var

var A_arbace_j2g_model_A_const_18 *lang.Var

var A_arbace_j2g_model_A_const_19 *lang.Var

var A_arbace_j2g_model_A_const_20 *lang.Var

var A_arbace_j2g_model_A_const_21 *lang.Var

var A_arbace_j2g_model_A_const_22 *lang.Var

var A_arbace_j2g_model_A_const_23 *lang.Var

var A_arbace_j2g_model_A_const_24 any

var A_arbace_j2g_model_A_const_25 *lang.Var

var A_arbace_j2g_model_A_const_26 *lang.Var

var A_arbace_j2g_model_A_const_27 *lang.Var

var A_arbace_j2g_model_A_const_28 *lang.Var

var A_arbace_j2g_model_A_const_29 *lang.Var

var A_arbace_j2g_model_A_const_30 *lang.Var

var A_arbace_j2g_model_A_const_31 any

var A_arbace_j2g_model_A_const_32 *lang.Keyword

var A_arbace_j2g_model_A_const_33 *lang.Var

var A_arbace_j2g_model_A_const_34 *lang.Var

var A_arbace_j2g_model_A_const_35 *lang.Var

var A_arbace_j2g_model_A_const_36 *lang.Var

var A_arbace_j2g_model_A_const_37 *lang.Keyword

var A_arbace_j2g_model_A_const_38 *lang.Var

var A_arbace_j2g_model_A_const_39 *lang.Var

var A_arbace_j2g_model_A_const_40 *lang.Var

var A_arbace_j2g_model_A_const_41 *lang.Var

var A_arbace_j2g_model_A_const_42 *lang.Var

var A_arbace_j2g_model_A_const_43 *lang.Var

var A_arbace_j2g_model_A_const_44 *lang.Var

var A_arbace_j2g_model_A_const_45 *lang.Var

var A_arbace_j2g_model_A_const_46 *lang.Keyword

var A_arbace_j2g_model_A_const_47 any

var A_arbace_j2g_model_A_const_48 *lang.Var

var A_arbace_j2g_model_A_const_49 *lang.Keyword

var A_arbace_j2g_model_A_const_50 *lang.Var

var A_arbace_j2g_model_A_const_51 *lang.Var

var A_arbace_j2g_model_A_const_52 *lang.Var

var A_arbace_j2g_model_A_const_53 *lang.Keyword

var A_arbace_j2g_model_A_const_54 *lang.Var

var A_arbace_j2g_model_A_const_55 *lang.Var

var A_arbace_j2g_model_A_const_56 *lang.Var

var A_arbace_j2g_model_A_const_57 *lang.Var

var A_arbace_j2g_model_A_const_58 *lang.Var

var A_arbace_j2g_model_A_const_59 *lang.Var

var A_arbace_j2g_model_A_const_60 *lang.Keyword

var A_arbace_j2g_model_A_const_61 *lang.Var

var A_arbace_j2g_model_A_const_62 *lang.Var

var A_arbace_j2g_model_A_const_63 *lang.Var

var A_arbace_j2g_model_A_const_64 *lang.Var

var A_arbace_j2g_model_A_const_65 *lang.Var

var A_arbace_j2g_model_A_const_66 *lang.Var

var A_arbace_j2g_model_A_const_67 *lang.Var

var A_arbace_j2g_model_A_const_68 *lang.Var

var A_arbace_j2g_model_A_const_69 *lang.Keyword

var A_arbace_j2g_model_A_const_70 *lang.Var

var A_arbace_j2g_model_A_const_71 *lang.Keyword

var A_arbace_j2g_model_A_const_72 *lang.Var

var A_arbace_j2g_model_A_const_73 *lang.Var

var A_arbace_j2g_model_A_const_74 *lang.Var

var A_arbace_j2g_model_A_const_75 any

var A_arbace_j2g_model_A_const_76 any

var A_arbace_j2g_model_A_const_77 *lang.Keyword

var A_arbace_j2g_model_A_const_78 *lang.Var

var A_arbace_j2g_model_A_const_79 *lang.Var

var A_arbace_j2g_model_A_const_80 *lang.Keyword

var A_arbace_j2g_model_A_const_81 *lang.Var

var A_arbace_j2g_model_A_const_82 *lang.Var

var A_arbace_j2g_model_A_const_83 *lang.Var

var A_arbace_j2g_model_A_const_84 *lang.Var

var A_arbace_j2g_model_A_const_85 *lang.Var

var A_arbace_j2g_model_A_const_86 *lang.Var

var A_arbace_j2g_model_A_const_87 *lang.Var

var A_arbace_j2g_model_A_const_88 *lang.Var

var A_arbace_j2g_model_A_const_89 *lang.Var

var A_arbace_j2g_model_A_const_90 *lang.Keyword

var A_arbace_j2g_model_A_const_91 *lang.Keyword

var A_arbace_j2g_model_A_const_92 *lang.Var

var A_arbace_j2g_model_A_const_93 *lang.Var

var A_arbace_j2g_model_A_const_94 *lang.Var

var A_arbace_j2g_model_A_const_95 *lang.Var

var A_arbace_j2g_model_A_const_96 *lang.Var

var A_arbace_j2g_model_A_const_97 *lang.Var

var A_arbace_j2g_model_A_const_98 *lang.Var

var A_arbace_j2g_model_A_const_99 *lang.Var

var A_arbace_j2g_model_A_const_100 *lang.Var

var A_arbace_j2g_model_A_const_101 *lang.Var

var A_arbace_j2g_model_A_const_102 *lang.Keyword

var A_arbace_j2g_model_A_const_103 any

var A_arbace_j2g_model_A_const_104 *lang.Var

var A_arbace_j2g_model_A_const_105 any

var A_arbace_j2g_model_A_const_106 *lang.Var

var A_arbace_j2g_model_A_const_107 *lang.Var

var A_arbace_j2g_model_A_const_108 any

var A_arbace_j2g_model_A_const_109 *lang.Var

var A_arbace_j2g_model_A_const_110 *lang.Var

var A_arbace_j2g_model_A_const_111 *lang.Var

var A_arbace_j2g_model_A_const_112 *lang.Keyword

var A_arbace_j2g_model_A_const_113 any

var A_arbace_j2g_model_A_const_114 *lang.Var

var A_arbace_j2g_model_A_const_115 *lang.Var

var A_arbace_j2g_model_A_const_116 any

var A_arbace_j2g_model_A_const_117 any

var A_arbace_j2g_model_A_const_118 *lang.Var

var A_arbace_j2g_model_A_const_119 *lang.Var

var A_arbace_j2g_model_A_const_120 *lang.Var

var A_arbace_j2g_model_A_const_121 any

var A_arbace_j2g_model_A_const_122 any

var A_arbace_j2g_model_A_const_123 *lang.Keyword

var A_arbace_j2g_model_A_const_124 *lang.Keyword

var A_arbace_j2g_model_A_const_125 *lang.Var

var A_arbace_j2g_model_A_const_126 *lang.Var

var A_arbace_j2g_model_A_const_127 *lang.Var

var A_arbace_j2g_model_A_const_128 *lang.Var

var A_arbace_j2g_model_A_const_129 *lang.Var

var A_arbace_j2g_model_A_const_130 *lang.Var

var A_arbace_j2g_model_A_const_131 *lang.Var

var A_arbace_j2g_model_A_const_132 *lang.Var

var A_arbace_j2g_model_A_const_133 *lang.Var

var A_arbace_j2g_model_A_const_134 *lang.Var

var A_arbace_j2g_model_A_const_135 *lang.Var

var A_arbace_j2g_model_A_const_136 *lang.Keyword

var A_arbace_j2g_model_A_const_137 *lang.Var

var A_arbace_j2g_model_A_const_138 *lang.Var

var A_arbace_j2g_model_A_const_139 *lang.Var

var A_arbace_j2g_model_A_const_140 any

var A_arbace_j2g_model_A_const_141 *lang.Var

var A_arbace_j2g_model_A_const_142 *lang.Var

var A_arbace_j2g_model_A_const_143 *lang.Var

var A_arbace_j2g_model_A_const_144 *lang.Var

var A_arbace_j2g_model_A_const_145 *lang.Var

var A_arbace_j2g_model_A_const_146 *lang.Var

var A_arbace_j2g_model_A_const_147 *lang.Var

var A_arbace_j2g_model_A_const_148 *lang.Var

var A_arbace_j2g_model_A_const_149 *lang.Var

var A_arbace_j2g_model_A_const_150 *lang.Keyword

var A_arbace_j2g_model_A_const_151 *lang.Var

var A_arbace_j2g_model_A_const_152 *lang.Var

var A_arbace_j2g_model_A_const_153 *lang.Var

var A_arbace_j2g_model_A_const_154 *lang.Var

var A_arbace_j2g_model_A_const_155 *lang.Var

var A_arbace_j2g_model_A_const_156 *lang.Keyword

var A_arbace_j2g_model_A_const_157 *lang.Var

var A_arbace_j2g_model_A_const_158 *lang.Var

var A_arbace_j2g_model_A_const_159 *lang.Var

var A_arbace_j2g_model_A_const_160 *lang.Var

var A_arbace_j2g_model_A_const_161 any

var A_arbace_j2g_model_A_const_162 *lang.Var

var A_arbace_j2g_model_A_const_163 *lang.Var

var A_arbace_j2g_model_A_const_164 *lang.Var

var A_arbace_j2g_model_A_const_165 *lang.Var

var A_arbace_j2g_model_A_const_166 *lang.Var

var A_arbace_j2g_model_A_const_167 *lang.Var

var A_arbace_j2g_model_A_const_168 *lang.Var

var A_arbace_j2g_model_A_const_169 *lang.Keyword

var A_arbace_j2g_model_A_const_170 *lang.Keyword

var A_arbace_j2g_model_A_const_171 *lang.Keyword

var A_arbace_j2g_model_A_const_172 *lang.Keyword

var A_arbace_j2g_model_A_const_173 *lang.Keyword

var A_arbace_j2g_model_A_const_174 *lang.Keyword

var A_arbace_j2g_model_A_const_175 *lang.Var

var A_arbace_j2g_model_A_const_176 *lang.Keyword

var A_arbace_j2g_model_A_const_177 *lang.Var

var A_arbace_j2g_model_A_const_178 *lang.Keyword

var A_arbace_j2g_model_A_const_179 *lang.Keyword

var A_arbace_j2g_model_A_const_180 *lang.Var

var A_arbace_j2g_model_A_const_181 any

var A_arbace_j2g_model_A_const_182 *lang.Keyword

var A_arbace_j2g_model_A_const_183 *lang.Keyword

var A_arbace_j2g_model_A_const_184 *lang.Keyword

var A_arbace_j2g_model_A_const_185 *lang.Keyword

var A_arbace_j2g_model_A_const_186 *lang.Keyword

var A_arbace_j2g_model_A_const_187 *lang.Keyword

var A_arbace_j2g_model_A_const_188 *lang.Var

var A_arbace_j2g_model_A_const_189 *lang.Var

var A_arbace_j2g_model_A_const_190 *lang.Var

var A_arbace_j2g_model_A_const_191 *lang.Var

var A_arbace_j2g_model_A_const_192 *lang.Var

var A_arbace_j2g_model_A_const_193 *lang.Var

var A_arbace_j2g_model_A_const_194 *lang.Var

var A_arbace_j2g_model_A_const_195 *lang.Var

var A_arbace_j2g_model_A_const_196 *lang.Keyword

var A_arbace_j2g_model_A_const_197 *lang.Var

var A_arbace_j2g_model_A_const_198 *lang.Keyword

var A_arbace_j2g_model_A_const_199 *lang.Keyword

var A_arbace_j2g_model_A_const_200 *lang.Keyword

var A_arbace_j2g_model_A_const_201 *lang.Var

var A_arbace_j2g_model_A_const_202 *lang.Keyword

var A_arbace_j2g_model_A_const_203 any

var A_arbace_j2g_model_A_const_204 *lang.Var

var A_arbace_j2g_model_A_const_205 *lang.Keyword

var A_arbace_j2g_model_A_const_206 *lang.Keyword

var A_arbace_j2g_model_A_const_207 *lang.Keyword

var A_arbace_j2g_model_A_const_208 *lang.Keyword

var A_arbace_j2g_model_A_const_209 *lang.Keyword

var A_arbace_j2g_model_A_const_210 *lang.Keyword

var A_arbace_j2g_model_A_const_211 *lang.Keyword

var A_arbace_j2g_model_A_const_212 *lang.Keyword

var A_arbace_j2g_model_A_const_213 *lang.Keyword

var A_arbace_j2g_model_A_const_214 *lang.Keyword

var A_arbace_j2g_model_A_const_215 *lang.Keyword

var A_arbace_j2g_model_A_const_216 *lang.Keyword

var A_arbace_j2g_model_A_const_217 *lang.Keyword

var A_arbace_j2g_model_A_const_218 *lang.Keyword

var A_arbace_j2g_model_A_const_219 *lang.Keyword

var A_arbace_j2g_model_A_const_220 *lang.Keyword

var A_arbace_j2g_model_A_const_221 *lang.Keyword

var A_arbace_j2g_model_A_const_222 *lang.Keyword

var A_arbace_j2g_model_A_const_223 *lang.Keyword

var A_arbace_j2g_model_A_const_224 *lang.Keyword

var A_arbace_j2g_model_A_const_225 *lang.Keyword

var A_arbace_j2g_model_A_const_226 *lang.Keyword

var A_arbace_j2g_model_A_const_227 *lang.Keyword

var A_arbace_j2g_model_A_const_228 *lang.Keyword

var A_arbace_j2g_model_A_const_229 *lang.Keyword

var A_arbace_j2g_model_A_const_230 *lang.Keyword

var A_arbace_j2g_model_A_const_231 *lang.Keyword

var A_arbace_j2g_model_A_const_232 *lang.Var

var A_arbace_j2g_model_A_const_233 *lang.Keyword

var A_arbace_j2g_model_A_const_234 *lang.Keyword

var A_arbace_j2g_model_A_const_235 *lang.Keyword

var A_arbace_j2g_model_A_const_236 *lang.Keyword

var A_arbace_j2g_model_A_const_237 any

var A_arbace_j2g_model_A_const_238 *lang.Keyword

var A_arbace_j2g_model_A_const_239 *lang.Keyword

var A_arbace_j2g_model_A_const_240 *lang.Keyword

var A_arbace_j2g_model_A_const_241 *lang.Keyword

var A_arbace_j2g_model_A_const_242 *lang.Keyword

var A_arbace_j2g_model_A_const_243 *lang.Keyword

var A_arbace_j2g_model_A_const_244 *lang.Var

var A_arbace_j2g_model_A_const_245 *lang.Keyword

var A_arbace_j2g_model_A_init jrt.ClassInit

func A_arbace_j2g_model_A_Init() { if !A_arbace_j2g_model_A_init.Done() { A_arbace_j2g_model_A_init.Run(A_arbace_j2g_model_A_clinit) } }

func A_arbace_j2g_model_A_clinit() { A_arbace_j2g_model_A_clinit_p0(); A_arbace_j2g_model_A_clinit_p1(); A_arbace_j2g_model_A_clinit_p2(); A_arbace_j2g_model_A_clinit_p3(); A_arbace_j2g_model_A_clinit_p4(); A_arbace_j2g_model_A_clinit_p5(); A_arbace_j2g_model_A_clinit_p6(); A_arbace_j2g_model_A_clinit_p7(); A_arbace_j2g_model_A_clinit_p8(); A_arbace_j2g_model_A_clinit_p9(); A_arbace_j2g_model_A_clinit_p10(); A_arbace_j2g_model_A_clinit_p11(); A_arbace_j2g_model_A_clinit_p12(); A_arbace_j2g_model_A_clinit_p13(); A_arbace_j2g_model_A_clinit_p14(); A_arbace_j2g_model_A_clinit_p15(); A_arbace_j2g_model_A_clinit_p16(); A_arbace_j2g_model_A_clinit_p17(); A_arbace_j2g_model_A_clinit_p18(); A_arbace_j2g_model_A_clinit_p19(); A_arbace_j2g_model_A_clinit_p20() }

func A_arbace_j2g_model_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 346); A_arbace_j2g_model_A_const_0 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[100]); A_arbace_j2g_model_A_const_1 = A_arbace_j2g_model_A_const_pool.A[101]; A_arbace_j2g_model_A_const_2 = A_arbace_j2g_model_A_const_pool.A[102]; A_arbace_j2g_model_A_const_3 = A_arbace_j2g_model_A_const_pool.A[103]; A_arbace_j2g_model_A_const_4 = A_arbace_j2g_model_A_const_pool.A[104]; A_arbace_j2g_model_A_const_5 = A_arbace_j2g_model_A_const_pool.A[105]; A_arbace_j2g_model_A_const_6 = A_arbace_j2g_model_A_const_pool.A[106]; A_arbace_j2g_model_A_const_7 = A_arbace_j2g_model_A_const_pool.A[107]; A_arbace_j2g_model_A_const_8 = A_arbace_j2g_model_A_const_pool.A[108]; A_arbace_j2g_model_A_const_9 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[109]); A_arbace_j2g_model_A_const_10 = A_arbace_j2g_model_A_const_pool.A[110]; A_arbace_j2g_model_A_const_11 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[111]); A_arbace_j2g_model_A_const_12 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[112]) }

func A_arbace_j2g_model_A_clinit_p1() { A_arbace_j2g_model_A_const_13 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[113]); A_arbace_j2g_model_A_const_14 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[114]); A_arbace_j2g_model_A_const_15 = A_arbace_j2g_model_A_const_pool.A[115]; A_arbace_j2g_model_A_const_16 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[116]); A_arbace_j2g_model_A_const_17 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[117]); A_arbace_j2g_model_A_const_18 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[118]); A_arbace_j2g_model_A_const_19 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[119]); A_arbace_j2g_model_A_const_20 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[120]); A_arbace_j2g_model_A_const_21 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[121]); A_arbace_j2g_model_A_const_22 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[122]); A_arbace_j2g_model_A_const_23 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[123]); A_arbace_j2g_model_A_const_24 = A_arbace_j2g_model_A_const_pool.A[124] }

func A_arbace_j2g_model_A_clinit_p2() { A_arbace_j2g_model_A_const_25 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[125]); A_arbace_j2g_model_A_const_26 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[126]); A_arbace_j2g_model_A_const_27 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[127]); A_arbace_j2g_model_A_const_28 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[128]); A_arbace_j2g_model_A_const_29 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[129]); A_arbace_j2g_model_A_const_30 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[130]); A_arbace_j2g_model_A_const_31 = A_arbace_j2g_model_A_const_pool.A[131]; A_arbace_j2g_model_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[132]); A_arbace_j2g_model_A_const_33 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[133]); A_arbace_j2g_model_A_const_34 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[134]); A_arbace_j2g_model_A_const_35 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[135]); A_arbace_j2g_model_A_const_36 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[136]) }

func A_arbace_j2g_model_A_clinit_p3() { A_arbace_j2g_model_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[137]); A_arbace_j2g_model_A_const_38 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[138]); A_arbace_j2g_model_A_const_39 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[139]); A_arbace_j2g_model_A_const_40 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[140]); A_arbace_j2g_model_A_const_41 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[141]); A_arbace_j2g_model_A_const_42 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[142]); A_arbace_j2g_model_A_const_43 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[143]); A_arbace_j2g_model_A_const_44 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[144]); A_arbace_j2g_model_A_const_45 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[145]); A_arbace_j2g_model_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[146]); A_arbace_j2g_model_A_const_47 = A_arbace_j2g_model_A_const_pool.A[147]; A_arbace_j2g_model_A_const_48 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[148]) }

func A_arbace_j2g_model_A_clinit_p4() { A_arbace_j2g_model_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[149]); A_arbace_j2g_model_A_const_50 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[150]); A_arbace_j2g_model_A_const_51 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[151]); A_arbace_j2g_model_A_const_52 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[152]); A_arbace_j2g_model_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[153]); A_arbace_j2g_model_A_const_54 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[154]); A_arbace_j2g_model_A_const_55 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[155]); A_arbace_j2g_model_A_const_56 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[156]); A_arbace_j2g_model_A_const_57 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[157]); A_arbace_j2g_model_A_const_58 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[158]); A_arbace_j2g_model_A_const_59 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[159]); A_arbace_j2g_model_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[160]) }

func A_arbace_j2g_model_A_clinit_p5() { A_arbace_j2g_model_A_const_61 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[161]); A_arbace_j2g_model_A_const_62 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[162]); A_arbace_j2g_model_A_const_63 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[163]); A_arbace_j2g_model_A_const_64 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[164]); A_arbace_j2g_model_A_const_65 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[165]); A_arbace_j2g_model_A_const_66 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[166]); A_arbace_j2g_model_A_const_67 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[167]); A_arbace_j2g_model_A_const_68 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[168]); A_arbace_j2g_model_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[169]); A_arbace_j2g_model_A_const_70 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[170]); A_arbace_j2g_model_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[171]); A_arbace_j2g_model_A_const_72 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[172]) }

func A_arbace_j2g_model_A_clinit_p6() { A_arbace_j2g_model_A_const_73 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[173]); A_arbace_j2g_model_A_const_74 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[174]); A_arbace_j2g_model_A_const_75 = A_arbace_j2g_model_A_const_pool.A[175]; A_arbace_j2g_model_A_const_76 = A_arbace_j2g_model_A_const_pool.A[176]; A_arbace_j2g_model_A_const_77 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[177]); A_arbace_j2g_model_A_const_78 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[178]); A_arbace_j2g_model_A_const_79 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[179]); A_arbace_j2g_model_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[180]); A_arbace_j2g_model_A_const_81 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[181]); A_arbace_j2g_model_A_const_82 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[182]); A_arbace_j2g_model_A_const_83 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[183]); A_arbace_j2g_model_A_const_84 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[184]) }

func A_arbace_j2g_model_A_clinit_p7() { A_arbace_j2g_model_A_const_85 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[185]); A_arbace_j2g_model_A_const_86 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[186]); A_arbace_j2g_model_A_const_87 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[187]); A_arbace_j2g_model_A_const_88 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[188]); A_arbace_j2g_model_A_const_89 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[189]); A_arbace_j2g_model_A_const_90 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[190]); A_arbace_j2g_model_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[191]); A_arbace_j2g_model_A_const_92 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[192]); A_arbace_j2g_model_A_const_93 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[193]); A_arbace_j2g_model_A_const_94 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[194]); A_arbace_j2g_model_A_const_95 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[195]); A_arbace_j2g_model_A_const_96 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[196]) }

func A_arbace_j2g_model_A_clinit_p8() { A_arbace_j2g_model_A_const_97 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[197]); A_arbace_j2g_model_A_const_98 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[198]); A_arbace_j2g_model_A_const_99 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[199]); A_arbace_j2g_model_A_const_100 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[200]); A_arbace_j2g_model_A_const_101 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[201]); A_arbace_j2g_model_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[202]); A_arbace_j2g_model_A_const_103 = A_arbace_j2g_model_A_const_pool.A[203]; A_arbace_j2g_model_A_const_104 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[204]); A_arbace_j2g_model_A_const_105 = A_arbace_j2g_model_A_const_pool.A[205]; A_arbace_j2g_model_A_const_106 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[206]); A_arbace_j2g_model_A_const_107 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[207]); A_arbace_j2g_model_A_const_108 = A_arbace_j2g_model_A_const_pool.A[208] }

func A_arbace_j2g_model_A_clinit_p9() { A_arbace_j2g_model_A_const_109 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[209]); A_arbace_j2g_model_A_const_110 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[210]); A_arbace_j2g_model_A_const_111 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[211]); A_arbace_j2g_model_A_const_112 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[212]); A_arbace_j2g_model_A_const_113 = A_arbace_j2g_model_A_const_pool.A[213]; A_arbace_j2g_model_A_const_114 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[214]); A_arbace_j2g_model_A_const_115 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[215]); A_arbace_j2g_model_A_const_116 = A_arbace_j2g_model_A_const_pool.A[216]; A_arbace_j2g_model_A_const_117 = A_arbace_j2g_model_A_const_pool.A[217]; A_arbace_j2g_model_A_const_118 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[218]); A_arbace_j2g_model_A_const_119 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[219]); A_arbace_j2g_model_A_const_120 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[220]); A_arbace_j2g_model_A_const_121 = A_arbace_j2g_model_A_const_pool.A[221] }

func A_arbace_j2g_model_A_clinit_p10() { A_arbace_j2g_model_A_const_122 = A_arbace_j2g_model_A_const_pool.A[222]; A_arbace_j2g_model_A_const_123 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[223]); A_arbace_j2g_model_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[224]); A_arbace_j2g_model_A_const_125 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[225]); A_arbace_j2g_model_A_const_126 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[226]); A_arbace_j2g_model_A_const_127 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[227]); A_arbace_j2g_model_A_const_128 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[228]); A_arbace_j2g_model_A_const_129 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[229]); A_arbace_j2g_model_A_const_130 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[230]); A_arbace_j2g_model_A_const_131 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[231]); A_arbace_j2g_model_A_const_132 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[232]); A_arbace_j2g_model_A_const_133 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[233]) }

func A_arbace_j2g_model_A_clinit_p11() { A_arbace_j2g_model_A_const_134 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[234]); A_arbace_j2g_model_A_const_135 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[235]); A_arbace_j2g_model_A_const_136 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[236]); A_arbace_j2g_model_A_const_137 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[237]); A_arbace_j2g_model_A_const_138 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[238]); A_arbace_j2g_model_A_const_139 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[239]); A_arbace_j2g_model_A_const_140 = A_arbace_j2g_model_A_const_pool.A[240]; A_arbace_j2g_model_A_const_141 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[241]); A_arbace_j2g_model_A_const_142 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[242]); A_arbace_j2g_model_A_const_143 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[243]); A_arbace_j2g_model_A_const_144 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[244]); A_arbace_j2g_model_A_const_145 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[245]) }

func A_arbace_j2g_model_A_clinit_p12() { A_arbace_j2g_model_A_const_146 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[246]); A_arbace_j2g_model_A_const_147 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[247]); A_arbace_j2g_model_A_const_148 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[248]); A_arbace_j2g_model_A_const_149 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[249]); A_arbace_j2g_model_A_const_150 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[250]); A_arbace_j2g_model_A_const_151 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[251]); A_arbace_j2g_model_A_const_152 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[252]); A_arbace_j2g_model_A_const_153 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[253]); A_arbace_j2g_model_A_const_154 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[254]); A_arbace_j2g_model_A_const_155 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[255]); A_arbace_j2g_model_A_const_156 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[256]); A_arbace_j2g_model_A_const_157 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[257]) }

func A_arbace_j2g_model_A_clinit_p13() { A_arbace_j2g_model_A_const_158 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[258]); A_arbace_j2g_model_A_const_159 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[259]); A_arbace_j2g_model_A_const_160 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[260]); A_arbace_j2g_model_A_const_161 = A_arbace_j2g_model_A_const_pool.A[261]; A_arbace_j2g_model_A_const_162 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[262]); A_arbace_j2g_model_A_const_163 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[263]); A_arbace_j2g_model_A_const_164 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[264]); A_arbace_j2g_model_A_const_165 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[265]); A_arbace_j2g_model_A_const_166 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[266]); A_arbace_j2g_model_A_const_167 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[267]); A_arbace_j2g_model_A_const_168 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[268]); A_arbace_j2g_model_A_const_169 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[269]) }

func A_arbace_j2g_model_A_clinit_p14() { A_arbace_j2g_model_A_const_170 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[270]); A_arbace_j2g_model_A_const_171 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[271]); A_arbace_j2g_model_A_const_172 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[272]); A_arbace_j2g_model_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[273]); A_arbace_j2g_model_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[274]); A_arbace_j2g_model_A_const_175 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[275]); A_arbace_j2g_model_A_const_176 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[276]); A_arbace_j2g_model_A_const_177 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[277]); A_arbace_j2g_model_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[278]); A_arbace_j2g_model_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[279]); A_arbace_j2g_model_A_const_180 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[280]); A_arbace_j2g_model_A_const_181 = A_arbace_j2g_model_A_const_pool.A[281] }

func A_arbace_j2g_model_A_clinit_p15() { A_arbace_j2g_model_A_const_182 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[282]); A_arbace_j2g_model_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[283]); A_arbace_j2g_model_A_const_184 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[284]); A_arbace_j2g_model_A_const_185 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[285]); A_arbace_j2g_model_A_const_186 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[286]); A_arbace_j2g_model_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[287]); A_arbace_j2g_model_A_const_188 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[288]); A_arbace_j2g_model_A_const_189 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[289]); A_arbace_j2g_model_A_const_190 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[290]); A_arbace_j2g_model_A_const_191 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[291]); A_arbace_j2g_model_A_const_192 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[292]); A_arbace_j2g_model_A_const_193 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[293]) }

func A_arbace_j2g_model_A_clinit_p16() { A_arbace_j2g_model_A_const_194 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[294]); A_arbace_j2g_model_A_const_195 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[295]); A_arbace_j2g_model_A_const_196 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[296]); A_arbace_j2g_model_A_const_197 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[297]); A_arbace_j2g_model_A_const_198 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[298]); A_arbace_j2g_model_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[299]); A_arbace_j2g_model_A_const_200 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[300]); A_arbace_j2g_model_A_const_201 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[301]); A_arbace_j2g_model_A_const_202 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[302]); A_arbace_j2g_model_A_const_203 = A_arbace_j2g_model_A_const_pool.A[303]; A_arbace_j2g_model_A_const_204 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[304]); A_arbace_j2g_model_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[305]) }

func A_arbace_j2g_model_A_clinit_p17() { A_arbace_j2g_model_A_const_206 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[306]); A_arbace_j2g_model_A_const_207 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[307]); A_arbace_j2g_model_A_const_208 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[308]); A_arbace_j2g_model_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[309]); A_arbace_j2g_model_A_const_210 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[310]); A_arbace_j2g_model_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[311]); A_arbace_j2g_model_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[312]); A_arbace_j2g_model_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[313]); A_arbace_j2g_model_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[314]); A_arbace_j2g_model_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[315]); A_arbace_j2g_model_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[316]); A_arbace_j2g_model_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[317]) }

func A_arbace_j2g_model_A_clinit_p18() { A_arbace_j2g_model_A_const_218 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[318]); A_arbace_j2g_model_A_const_219 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[319]); A_arbace_j2g_model_A_const_220 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[320]); A_arbace_j2g_model_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[321]); A_arbace_j2g_model_A_const_222 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[322]); A_arbace_j2g_model_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[323]); A_arbace_j2g_model_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[324]); A_arbace_j2g_model_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[325]); A_arbace_j2g_model_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[326]); A_arbace_j2g_model_A_const_227 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[327]); A_arbace_j2g_model_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[328]); A_arbace_j2g_model_A_const_229 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[329]) }

func A_arbace_j2g_model_A_clinit_p19() { A_arbace_j2g_model_A_const_230 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[330]); A_arbace_j2g_model_A_const_231 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[331]); A_arbace_j2g_model_A_const_232 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[332]); A_arbace_j2g_model_A_const_233 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[333]); A_arbace_j2g_model_A_const_234 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[334]); A_arbace_j2g_model_A_const_235 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[335]); A_arbace_j2g_model_A_const_236 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[336]); A_arbace_j2g_model_A_const_237 = A_arbace_j2g_model_A_const_pool.A[337]; A_arbace_j2g_model_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[338]); A_arbace_j2g_model_A_const_239 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[339]); A_arbace_j2g_model_A_const_240 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[340]); A_arbace_j2g_model_A_const_241 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[341]) }

func A_arbace_j2g_model_A_clinit_p20() { A_arbace_j2g_model_A_const_242 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[342]); A_arbace_j2g_model_A_const_243 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[343]); A_arbace_j2g_model_A_const_244 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[344]); A_arbace_j2g_model_A_const_245 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[345]) }

func A_arbace_j2g_model_A_New() *A_arbace_j2g_model_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_A) Ctor() {}

func (t *A_arbace_j2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_A_class }

func (t *A_arbace_j2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_A); return ok }

func A_arbace_j2g_model_A_Cast(x any) *A_arbace_j2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_A_class)) }; return v }



type A_arbace_j2g_model_T_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_T_A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_m_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_m_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_method_error_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_method_error_text_A_fn_class *jrt.Class



type A_arbace_j2g_model_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_all_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_benign_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_code_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_code_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_declared_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A struct{ j2g_header uint64; F_n, F_s__1479000090, F_iter__1479000089 any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A struct{ j2g_header uint64; F_n, F_b__1479000092 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_erased_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000004_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000004_A_New() *A_arbace_j2g_model_eval1479000004_A { t := &A_arbace_j2g_model_eval1479000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000004_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000004_A_class }

func (t *A_arbace_j2g_model_eval1479000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000004_A); return ok }

func A_arbace_j2g_model_eval1479000004_A_Cast(x any) *A_arbace_j2g_model_eval1479000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000004_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000008_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000008_A_New() *A_arbace_j2g_model_eval1479000008_A { t := &A_arbace_j2g_model_eval1479000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000008_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000008_A_class }

func (t *A_arbace_j2g_model_eval1479000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000008_A); return ok }

func A_arbace_j2g_model_eval1479000008_A_Cast(x any) *A_arbace_j2g_model_eval1479000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000008_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000008_fn__1479000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class *jrt.Class



type A_arbace_j2g_model_fields_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fields_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_final_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_final_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_find_method_A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_fn__1479000079_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_find_method_fn__1479000079_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_qualified_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_qualified_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_model_hand_written_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hand_written_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_hw_method_exists_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_iface_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_iface_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_impl_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000123_A struct{ j2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_j2g_model_impl_of_fn__1479000123_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000135_A struct{ j2g_header uint64; F_cands any }

var A_arbace_j2g_model_impl_of_fn__1479000135_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A struct{ j2g_header uint64; F_iter__1479000125, F_name, F_desc, F_s__1479000126 any }

var A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A struct{ j2g_header uint64; F_name, F_b__1479000128, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_fn_class *jrt.Class



type A_arbace_j2g_model_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_info_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_info_A_fn_class *jrt.Class



type A_arbace_j2g_model_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_method_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_java_type_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_java_type_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_jobs_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jobs_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_leaf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_leaf_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_A struct{ j2g_header uint64; F_cache, F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A struct{ j2g_header uint64; F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class *jrt.Class



type A_arbace_j2g_model_mdesc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_member_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_member_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_method_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_method_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_methods_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_methods_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_nest_top_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_nest_top_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_par_mapv_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000017_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_work__1479000019_A struct{ j2g_header uint64; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

var A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class *jrt.Class



type A_arbace_j2g_model_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_pointer_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_private_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_fn_class *jrt.Class



type A_arbace_j2g_model_qualify_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_qualify_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflected_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflected_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A struct{ j2g_header uint64; F_iter__1479000146, F_s__1479000147 any }

var A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A struct{ j2g_header uint64; F_b__1479000149 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_fn_class *jrt.Class



type A_arbace_j2g_model_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_subclasses_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_subclasses_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_fn__1479000115_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_fn__1479000115_A_fn_class *jrt.Class



type A_arbace_j2g_model_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_top_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_top_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_translatable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translatable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_translated_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translated_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_trivial_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_trivial_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_virtual_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_virtual_member_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000100_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000100_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_fn_class *jrt.Class



type A_arbace_j2g_model_world_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_world_supertypes_A_fn_class *jrt.Class
