//line aot_arbace_j2g_model.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New() *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_model_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_model_A_const_1, A_arbace_j2g_model_A_const_2, A_arbace_j2g_model_A_const_3, A_arbace_j2g_model_A_const_4, A_arbace_j2g_model_A_const_5, A_arbace_j2g_model_A_const_6, A_arbace_j2g_model_A_const_7, A_arbace_j2g_model_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New() *A_arbace_j2g_model_eval1479000008_fn__1479000009_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000008_fn__1479000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_model_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_model_A_const_14.GetRawRoot__O(), A_arbace_j2g_model_A_const_15) }



























func A_arbace_j2g_model_on_run_thread_A_New() *A_arbace_j2g_model_on_run_thread_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_on_run_thread_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_model_on_run_thread_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_model_on_run_thread_A) Invoke_O_O__O(self, f__0 any) any {


	return lang.IFn_Cast(f__0).Invoke__O()
}
func A_arbace_j2g_model_run_fn_A_New() *A_arbace_j2g_model_run_fn_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_run_fn_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_j2g_model_run_fn_A) Ctor() {}
//line :34:1
func (t *A_arbace_j2g_model_run_fn_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.J2g_Truth(A_arbace_j2g_model_A_const_16.Get__O()) { var fnbody__31 any = A_arbace_j2g_model_run_fn_fn__1479000013_A_New_O(f__0); var tmp1 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_j2g_model_run_fn_fn__1479000013_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__31); A_arbace_j2g_model_run_fn_fn__1479000013_A_fn_class = fncls__30d; tmp1 = fncls__30d } else { tmp1 = fncls__30 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__31, tmp1, nil) } else { return f__0 } }
//line :37:1
func A_arbace_j2g_model_run_fn_fn__1479000013_A_New_O(p0 any) *A_arbace_j2g_model_run_fn_fn__1479000013_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_run_fn_fn__1479000013_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_j2g_model_run_fn_fn__1479000013_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :37:1
func (t *A_arbace_j2g_model_run_fn_fn__1479000013_A) Invoke_O__O(self any) any { var root_26 any = A_arbace_j2g_model_A_const_17.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, A_arbace_j2g_model_on_run_thread_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = t.F_f; if linked_27 == nil { return ifn_28.Invoke_O__O(arg_29) } else { return linked_27.(*A_arbace_j2g_model_on_run_thread_A).Invoke_O_O__O(root_26, arg_29) } }









func A_arbace_j2g_model_jobs_A_New() *A_arbace_j2g_model_jobs_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jobs_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_j2g_model_jobs_A) Ctor() {}
//line :47:1
func (t *A_arbace_j2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_53).Ref(); var tmp1 any; var tmp2 any; var root_32 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_34 lang.IFn; if




	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = e__1; if linked_33 == nil { tmp2 = ifn_34.Invoke_O__O(arg_35) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(tmp2) {
		tmp1 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(e__1))).Ref() } else {
			tmp1 = lang.Numbers_Min_O_J__O_NoInit(A_arbace_j2g_model_A_const_19.GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :52:1*/ lang.Numbers_Max_J_O__O_NoInit(1, tmp1) }



func A_arbace_j2g_model_par_mapv_A_New() *A_arbace_j2g_model_par_mapv_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_j2g_model_par_mapv_A) Ctor() {}
//line :56:1
func (t *A_arbace_j2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1479000017__3 any) any { var vec__1479000018__5 any = p__1479000017__3; var order__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000018__5, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__7 any; var root_36 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_38 lang.IFn; if









	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = xs__2; if linked_37 == nil { xs__7 = ifn_38.Invoke_O__O(arg_39) } else { xs__7 = linked_37.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_36, arg_39) }; var cnt__8 int32 = /*line :56:1*/lang.RT_Count_O__I_NoInit(xs__7); var n__9 any = lang.Numbers_Min_O_J__O_NoInit(n__0, int64(cnt__8)); var order__10 any; if












	jrt.J2g_Truth(order__6) { var root_40 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = order__6; if linked_41 == nil { order__10 = ifn_42.Invoke_O__O(arg_43) } else { order__10 = linked_41.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_40, arg_43) } } else { var root_44 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any; var root_48 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref(); if linked_49 == nil { arg_47 = ifn_50.Invoke_O__O(arg_51) } else { arg_47 = linked_49.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_48, arg_51) }; if linked_45 == nil { order__10 = ifn_46.Invoke_O__O(arg_47) } else { order__10 = linked_45.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_44, arg_47) } }; var tmp1 bool; var na_52 any = n__9; var na_53 int64 = 1; if
	jrt.Long_InstanceOf(na_52) { var n0_54 int64 = jrt.NN(jrt.Long_Cast(na_52)).LongValue__J(); var n1_55 int64 = na_53; tmp1 = n0_54 <= n1_55 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_52, na_53) }; if tmp1 {
		var root_57 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; var arg_61 any = xs__7; if linked_58 == nil { return ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { return linked_58.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } } else {
//line :70:1
			var res__11 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref()).Ref(); var last_i__12 any; var root_62 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_64 lang.IFn


			if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = order__10; if linked_63 == nil { last_i__12 = ifn_64.Invoke_O__O(arg_65) } else { last_i__12 = linked_63.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_62, arg_65) }
//line :70:1
			var ___13 any; var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(res__11); var tmp3 int32 = lang.RT_IntCast_O__I_NoInit(last_i__12); var tmp4 any; var root_66 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_68 lang.IFn; _ = ___13



			if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_70 any = A_arbace_j2g_model_A_const_24.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var fnbody__81 any = A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O_O_O(f__1, last_i__12, xs__7); var tmp5 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__81); A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class = fncls__80d; tmp5 = fncls__80d } else { tmp5 = fncls__80 }; arg_73 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp5, nil); if linked_71 == nil { arg_69 = ifn_72.Invoke_O__O(arg_73) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_70, arg_73) }; if linked_67 == nil { tmp4 = ifn_68.Invoke_O__O(arg_69) } else { tmp4 = linked_67.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_66, arg_69) }; ___13 = lang.RT_Aset_O1_I_O__O_NoInit(tmp2, tmp3, tmp4)
//line :70:1
			var next_i__14 any; var root_82 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_84 lang.IFn




			if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = A_arbace_j2g_model_A_const_27; if linked_83 == nil { next_i__14 = ifn_84.Invoke_O__O(arg_85) } else { next_i__14 = linked_83.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_82, arg_85) }
//line :70:1
			var work__15 any; var fnbody__97 any = A_arbace_j2g_model_par_mapv_work__1479000025_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__14, xs__7, res__11); var tmp6 *jrt.Class
			var fncls__96 /*line :70:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_work__1479000025_A_fn_class





			if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__97); A_arbace_j2g_model_par_mapv_work__1479000025_A_fn_class = fncls__96d; tmp6 = fncls__96d } else { tmp6 = fncls__96 }; work__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp6, nil)
//line :70:1
			var ws__16 any; var root_98 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_100 lang.IFn











			if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var root_102 any = A_arbace_j2g_model_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = n__9; var arg_106 any; var fnbody__118 any = A_arbace_j2g_model_par_mapv_fn__1479000027_A_New_O(work__15); var tmp7 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000027_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__118); A_arbace_j2g_model_par_mapv_fn__1479000027_A_fn_class = fncls__117d; tmp7 = fncls__117d } else { tmp7 = fncls__117 }; arg_106 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp7, nil); if linked_103 == nil { arg_101 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }; if linked_99 == nil { ws__16 = ifn_100.Invoke_O__O(arg_101) } else { ws__16 = linked_99.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_98, arg_101) }
			var root_123 any = A_arbace_j2g_model_A_const_32.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var arg_127 any = ws__16; if linked_124 == nil { ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { linked_124.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }
			var root_119 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = res__11; if linked_120 == nil { return ifn_121.Invoke_O__O(arg_122) } else { return linked_120.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_119, arg_122) } } }
//line :74:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :74:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Invoke_O__O(self any) any { var tmp1 any; var root_74 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, A_arbace_j2g_model_run_fn_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var fnbody__79 any = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O_O_O(t.F_f, t.F_last_i, t.F_xs); var tmp2 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__79); A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class = fncls__78d; tmp2 = fncls__78d } else { tmp2 = fncls__78 }; arg_77 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp2, nil); if linked_75 == nil { tmp1 = ifn_76.Invoke_O__O(arg_77) } else { tmp1 = linked_75.(*A_arbace_j2g_model_run_fn_A).Invoke_O_O__O(root_74, arg_77) }; return lang.IFn_Cast(tmp1).Invoke__O() }
//line :74:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :74:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); var tmp2 any = t.F_xs; return tmp1.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(t.F_last_i))) }

func A_arbace_j2g_model_par_mapv_work__1479000025_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_j2g_model_par_mapv_work__1479000025_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_work__1479000025_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :76:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000025_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :76:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000025_A) Invoke_O__O(self any) any { for { L2: for { var k__1 any; var root_86 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_88 lang.IFn
											if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = t.F_next_i; var arg_90 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); if linked_87 == nil { k__1 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { k__1 = linked_87.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_86, arg_89, arg_90) }
											var tmp1 bool; var na_91 any = k__1; var na_92 int64 = lang.Numbers_Dec_J__J_NoInit(int64(t.F_cnt)); if jrt.Long_InstanceOf(na_91) { var n0_93 int64 = jrt.NN(jrt.Long_Cast(na_91)).LongValue__J(); var n1_94 int64 = na_92; tmp1 = n0_93 < n1_94 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_91, na_92) }; if tmp1 { var tmp2 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(k__1)); var tmp3 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_res); var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any = t.F_xs

		lang.RT_Aset_O1_I_O__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(i__2), tmp4.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(i__2))))
		continue L2 } else {
//line :78:1
			return nil } } }; /*line :76:1*/panic("j2g: unreachable") }





func A_arbace_j2g_model_par_mapv_fn__1479000027_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000027_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000027_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :82:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_A) Invoke_O__O(self any) any { var root_107 any = A_arbace_j2g_model_A_const_24.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any; var fnbody__116 any = A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_New_O(t.F_work); var tmp1 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__116); A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_fn_class = fncls__115d; tmp1 = fncls__115d } else { tmp1 = fncls__115 }; arg_110 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp1, nil); if linked_108 == nil { return ifn_109.Invoke_O__O(arg_110) } else { return linked_108.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_107, arg_110) } }
//line :82:1
func A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :82:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A) Invoke_O__O(self any) any { var tmp1 any; var root_111 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_j2g_model_run_fn_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var t_ any = t.F_work; t.F_work = nil; arg_114 = t_; if linked_112 == nil { tmp1 = ifn_113.Invoke_O__O(arg_114) } else { tmp1 = linked_112.(*A_arbace_j2g_model_run_fn_A).Invoke_O_O__O(root_111, arg_114) }; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_j2g_model_has_QMARK__A_New() *A_arbace_j2g_model_has_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_j2g_model_has_QMARK__A) Ctor() {}
//line :88:1
func (t *A_arbace_j2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_128 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any; var tmp1 int64; var na_132 any; var or__1927000174__auto____3 any = flags__0; if jrt.J2g_Truth(or__1927000174__auto____3) { na_132 = or__1927000174__auto____3 } else { na_132 = A_arbace_j2g_model_A_const_34 }; var na_133 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_132); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_133) }; tmp2 = tmp3; if tmp2 { var n0_134 int64 = jrt.NN(jrt.Long_Cast(na_132)).LongValue__J(); var n1_135 int64 = jrt.NN(jrt.Long_Cast(na_133)).LongValue__J(); tmp1 = n0_134 & n1_135 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_132, na_133) }; arg_131 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_129 == nil { return ifn_130.Invoke_O__O(arg_131) } else { return linked_129.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_128, arg_131) } }

func A_arbace_j2g_model_T_A_New() *A_arbace_j2g_model_T_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_T_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_model_T_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_model_T_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_35; var x__1 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()); if lang.IDeref_InstanceOf(x__1) { var root_137 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = x__1; if linked_138 == nil { return ifn_139.Invoke_O__O(arg_140) } else { return linked_138.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_137, arg_140) } } else { return x__1 } }

func A_arbace_j2g_model_translated_QMARK__A_New() *A_arbace_j2g_model_translated_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_141 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var root_146 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_j2g_model_T_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; if linked_147 == nil { arg_144 = ifn_148.Invoke__O() } else { arg_144 = linked_147.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_146) }; var arg_145 any = n__0; if linked_142 == nil { return ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { return linked_142.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_141, arg_144, arg_145) } }

func A_arbace_j2g_model_j2g_static_QMARK__A_New() *A_arbace_j2g_model_j2g_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Ctor() {}
//line :94:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_49); if and__1927000168__auto____3 {





	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(base__1, Lit_50); if and__1927000168__auto____4 {
		var root_149 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = Lit_51; if linked_150 == nil { return ifn_151.Invoke_O__O(arg_152) } else { return linked_150.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_149, arg_152) } } else {
//line :100:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_jrt_class_A_New() *A_arbace_j2g_model_jrt_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_model_jrt_class_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_40; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()), n__0)
}
func A_arbace_j2g_model_hand_written_QMARK__A_New() *A_arbace_j2g_model_hand_written_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Ctor() {}
//line :108:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_153 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_155 lang.IFn; if


	linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = n__0; if linked_154 == nil { and__1927000168__auto____2 = ifn_155.Invoke_O__O(arg_156) } else { and__1927000168__auto____2 = linked_154.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_153, arg_156) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_157 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_161 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = n__0; if linked_162 == nil { arg_160 = ifn_163.Invoke_O__O(arg_164) } else { arg_160 = linked_162.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_161, arg_164) }; if linked_158 == nil { return ifn_159.Invoke_O__O(arg_160) } else { return linked_158.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_157, arg_160) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_in_world_QMARK__A_New() *A_arbace_j2g_model_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var root_165 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = n__0; if linked_166 == nil { or__1927000174__auto____3 = ifn_167.Invoke_O__O(arg_168) } else { or__1927000174__auto____3 = linked_166.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_165, arg_168) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_169 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = n__0; if linked_170 == nil { tmp1 = ifn_171.Invoke_O__O(arg_172) } else { tmp1 = linked_170.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_169, arg_172) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }

func A_arbace_j2g_model_translatable_QMARK__A_New() *A_arbace_j2g_model_translatable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var root_173 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = n__0; if linked_174 == nil { tmp1 = ifn_175.Invoke_O__O(arg_176) } else { tmp1 = linked_174.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_173, arg_176) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_reflectable_interface_QMARK__A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :121:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_177 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_179 lang.IFn; if




	linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var root_181 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = n__0; if linked_182 == nil { arg_180 = ifn_183.Invoke_O__O(arg_184) } else { arg_180 = linked_182.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_181, arg_184) }; if linked_178 == nil { and__1927000168__auto____2 = ifn_179.Invoke_O__O(arg_180) } else { and__1927000168__auto____2 = linked_178.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_185 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_187 lang.IFn
		if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = n__0; var arg_189 any = Lit_75; if linked_186 == nil { or__1927000174__auto____3 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { or__1927000174__auto____3 = linked_186.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_185, arg_188, arg_189) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_190 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = n__0; var arg_194 any = Lit_76; if linked_191 == nil { or__1927000174__auto____4 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { or__1927000174__auto____4 = linked_191.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; if jrt.J2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_195 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = n__0; var arg_199 any = Lit_77; if linked_196 == nil { or__1927000174__auto____5 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { or__1927000174__auto____5 = linked_196.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_200 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = n__0; var arg_204 any = Lit_78; if linked_201 == nil { or__1927000174__auto____6 = ifn_202.Invoke_O_O__O(arg_203, arg_204) } else { or__1927000174__auto____6 = linked_201.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_200, arg_203, arg_204) }; if jrt.J2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			var root_205 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = n__0; var arg_209 any = Lit_79; if linked_206 == nil { and__1927000168__auto____3 = ifn_207.Invoke_O_O__O(arg_208, arg_209) } else { and__1927000168__auto____3 = linked_206.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_205, arg_208, arg_209) } } } } }
//line :126:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_210 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_212 lang.IFn


			if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any; var root_214 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = n__0; var arg_218 any = Lit_80; if linked_215 == nil { arg_213 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { arg_213 = linked_215.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }; if linked_211 == nil { and__1927000168__auto____4 = ifn_212.Invoke_O__O(arg_213) } else { and__1927000168__auto____4 = linked_211.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_210, arg_213) }
//line :126:1
			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_219 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_221 lang.IFn



				if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any; var root_223 any = A_arbace_j2g_model_A_const_46.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = n__0; if linked_224 == nil { arg_222 = ifn_225.Invoke_O__O(arg_226) } else { arg_222 = linked_224.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_223, arg_226) }; if linked_220 == nil { and__1927000168__auto____5 = ifn_221.Invoke_O__O(arg_222) } else { and__1927000168__auto____5 = linked_220.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_219, arg_222) }
//line :126:1
				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_227 any = A_arbace_j2g_model_A_const_47.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_229 lang.IFn




					if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = n__0; if linked_228 == nil { and__1927000168__auto____6 = ifn_229.Invoke_O__O(arg_230) } else { and__1927000168__auto____6 = linked_228.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_227, arg_230) }
//line :126:1
					if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_231 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_233 lang.IFn






						if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var root_235 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp2 any; var root_240 any = A_arbace_j2g_model_A_const_46.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = n__0; if linked_241 == nil { tmp2 = ifn_242.Invoke_O__O(arg_243) } else { tmp2 = linked_241.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_240, arg_243) }; arg_238 = tmp1.Invoke_O__O(tmp2); var arg_239 any = A_arbace_j2g_model_A_const_50; if linked_236 == nil { arg_234 = ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { arg_234 = linked_236.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_235, arg_238, arg_239) }; if linked_232 == nil { and__1927000168__auto____7 = ifn_233.Invoke_O__O(arg_234) } else { and__1927000168__auto____7 = linked_232.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_231, arg_234) }
//line :126:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_244 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_246 lang.IFn









							if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_52; var tmp4 any; var root_248 any = A_arbace_j2g_model_A_const_46.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = n__0; if linked_249 == nil { tmp4 = ifn_250.Invoke_O__O(arg_251) } else { tmp4 = linked_249.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_248, arg_251) }; arg_247 = tmp3.Invoke_O__O(tmp4); if linked_245 == nil { and__1927000168__auto____8 = ifn_246.Invoke_O__O(arg_247) } else { and__1927000168__auto____8 = linked_245.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_244, arg_247) }
//line :126:1
							if jrt.J2g_Truth(and__1927000168__auto____8) {










								var root_252 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any; var fnbody__266 any = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A_New(); var tmp5 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A_fn_class = fncls__265d; tmp5 = fncls__265d } else { tmp5 = fncls__265 }; arg_255 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__266, tmp5, nil); var arg_256 any; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_56; var tmp7 any; var root_267 any = A_arbace_j2g_model_A_const_46.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = n__0; if linked_268 == nil { tmp7 = ifn_269.Invoke_O__O(arg_270) } else { tmp7 = linked_268.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_267, arg_270) }; arg_256 = tmp6.Invoke_O__O(tmp7); if linked_253 == nil { return ifn_254.Invoke_O_O__O(arg_255, arg_256) } else { return linked_253.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_252, arg_255, arg_256) } } else {
//line :126:1
									return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A) Ctor() {}
//line :137:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A) Invoke_O_O__O(self, p1__1479000040_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_257 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = p1__1479000040_SHARP___1; if linked_258 == nil { or__1927000174__auto____2 = ifn_259.Invoke_O__O(arg_260) } else { or__1927000174__auto____2 = linked_258.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_257, arg_260) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_261 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = p1__1479000040_SHARP___1; if linked_262 == nil { return ifn_263.Invoke_O__O(arg_264) } else { return linked_262.(*A_arbace_j2g_model_reflectable_interface_QMARK__A).Invoke_O_O__O(root_261, arg_264) } } }

func A_arbace_j2g_model_reflected_QMARK__A_New() *A_arbace_j2g_model_reflected_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_271 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_273 lang.IFn; if


	linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = n__0; if linked_272 == nil { and__1927000168__auto____2 = ifn_273.Invoke_O__O(arg_274) } else { and__1927000168__auto____2 = linked_272.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_271, arg_274) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_275 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any; var root_279 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = n__0; if linked_280 == nil { arg_278 = ifn_281.Invoke_O__O(arg_282) } else { arg_278 = linked_280.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_279, arg_282) }; if linked_276 == nil { return ifn_277.Invoke_O__O(arg_278) } else { return linked_276.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_275, arg_278) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_info_A_New() *A_arbace_j2g_model_info_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_info_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_model_info_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { var root_283 any = A_arbace_j2g_model_A_const_46.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = n__0; if linked_284 == nil { return ifn_285.Invoke_O__O(arg_286) } else { return linked_284.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_283, arg_286) } }
func A_arbace_j2g_model_interface_QMARK__A_New() *A_arbace_j2g_model_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Ctor() {}
//line :145:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_287 any = A_arbace_j2g_model_A_const_47.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = n__0; if linked_288 == nil { return ifn_289.Invoke_O__O(arg_290) } else { return linked_288.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_287, arg_290) } }

func A_arbace_j2g_model_desc_classes_A_New() *A_arbace_j2g_model_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_model_desc_classes_A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(d__0, nil) { return nil } else { var tmp1 any; var root_291 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_293 lang.IFn
		if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = d__0; if linked_292 == nil { tmp1 = ifn_293.Invoke_O__O(arg_294) } else { tmp1 = linked_292.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :150:1
		if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var root_295 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_297 lang.IFn

			if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = d__0; if linked_296 == nil { tmp2 = ifn_297.Invoke_O__O(arg_298) } else { tmp2 = linked_296.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_295, arg_298) }
//line :150:1
			if jrt.J2g_Truth(tmp2) {

				var root_299 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any; var root_303 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = d__0; var arg_307 any; var root_308 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = d__0; if linked_309 == nil { arg_307 = ifn_310.Invoke_O__O(arg_311) } else { arg_307 = linked_309.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_308, arg_311) }; if linked_304 == nil { arg_302 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { arg_302 = linked_304.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) }; if linked_300 == nil { return ifn_301.Invoke_O__O(arg_302) } else { return linked_300.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_299, arg_302) } } else {
//line :150:1
					var tmp3 any; var root_312 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_314 lang.IFn


					if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = d__0; if linked_313 == nil { tmp3 = ifn_314.Invoke_O__O(arg_315) } else { tmp3 = linked_313.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_312, arg_315) }
//line :150:1
					if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_316 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_318 lang.IFn


						if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = d__0; if linked_317 == nil { tmp4 = ifn_318.Invoke_O__O(arg_319) } else { tmp4 = linked_317.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_316, arg_319) }
//line :150:1
						return lang.Tuple_Create_O__IPersistentVector(tmp4) } else { if A_arbace_j2g_model_A_const_63 != nil { return nil } else { return nil
						}
						}
				}
		}
	}
}



func A_arbace_j2g_model_method_desc_classes_A_New() *A_arbace_j2g_model_method_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Ctor() {}
//line :160:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_320 any = A_arbace_j2g_model_A_const_65.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_322 lang.IFn; if
											linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = desc__0; if linked_321 == nil { tmp1 = ifn_322.Invoke_O__O(arg_323) } else { tmp1 = linked_321.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_320, arg_323) }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_66.GetRawRoot__O())).Get_O__O(desc__0) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var vec__1479000048__3 any; var root_324 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_326 lang.IFn
												if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = desc__0; if linked_325 == nil { vec__1479000048__3 = ifn_326.Invoke_O__O(arg_327) } else { vec__1479000048__3 = linked_325.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_324, arg_327) }
//line :161:1
		var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000048__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000048__3, lang.RT_IntCast_J__I_NoInit(1), nil); var v__6 any; var root_328 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_330 lang.IFn

		if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_68.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var tmp4 any; var root_337 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = r__5; var arg_341 any = ps__4; if linked_338 == nil { tmp4 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { tmp4 = linked_338.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; arg_331 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_329 == nil { v__6 = ifn_330.Invoke_O__O(arg_331) } else { v__6 = linked_329.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_328, arg_331) }
		var tmp5 any; var root_342 any = A_arbace_j2g_model_A_const_65.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = desc__0; if linked_343 == nil { tmp5 = ifn_344.Invoke_O__O(arg_345) } else { tmp5 = linked_343.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_342, arg_345) }; if jrt.J2g_Truth(tmp5) { jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_66.GetRawRoot__O())).Put_O_O__O(desc__0, v__6) }
//line :161:1
		return v__6 } }





func A_arbace_j2g_model_erased_desc_QMARK__A_New() *A_arbace_j2g_model_erased_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_346 any = A_arbace_j2g_model_A_const_65.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_348 lang.IFn; if




	linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = d__0; if linked_347 == nil { and__1927000168__auto____2 = ifn_348.Invoke_O__O(arg_349) } else { and__1927000168__auto____2 = linked_347.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__359 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__358 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A_fn_class
		if fncls__358 == nil { var fncls__358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__359); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A_fn_class = fncls__358d; tmp2 = fncls__358d } else { tmp2 = fncls__358 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__359, tmp2, nil); e__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :172:1
		var and__1927000168__auto____4 any; var root_360 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_362 lang.IFn

		if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = e__3; if linked_361 == nil { and__1927000168__auto____4 = ifn_362.Invoke_O__O(arg_363) } else { and__1927000168__auto____4 = linked_361.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_360, arg_363) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var n__5 any; var root_364 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_366 lang.IFn
			if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = e__3; if linked_365 == nil { n__5 = ifn_366.Invoke_O__O(arg_367) } else { n__5 = linked_365.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_364, arg_367) }
//line :174:1
			var and__1927000168__auto____6 any; var root_368 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_370 lang.IFn

			if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any; var root_372 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = n__5; if linked_373 == nil { arg_371 = ifn_374.Invoke_O__O(arg_375) } else { arg_371 = linked_373.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_372, arg_375) }; if linked_369 == nil { and__1927000168__auto____6 = ifn_370.Invoke_O__O(arg_371) } else { and__1927000168__auto____6 = linked_369.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_368, arg_371) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
				var root_376 any = A_arbace_j2g_model_A_const_71.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any; var fnbody__387 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A_New_O(n__5); var tmp3 *jrt.Class; var fncls__386 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A_fn_class; if fncls__386 == nil { var fncls__386d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__387); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A_fn_class = fncls__386d; tmp3 = fncls__386d } else { tmp3 = fncls__386 }; arg_379 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__387, tmp3, nil); var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_72; var arg_380 any = tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()); if linked_377 == nil { return ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { return linked_377.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) } } else {
//line :176:1
					return and__1927000168__auto____6 } } else {
//line :174:1
						return and__1927000168__auto____4 } } else {
//line :172:1
							return and__1927000168__auto____2 } }
func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A{}; t.Ctor_O(p0); return t }
//line :173:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :173:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { var tmp1 any; var root_350 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = d__1; if linked_351 == nil { tmp1 = ifn_352.Invoke_O__O(arg_353) } else { tmp1 = linked_351.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_350, arg_353) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_354 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = d__1; if linked_355 == nil { tmp2 = ifn_356.Invoke_O__O(arg_357) } else { tmp2 = linked_355.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_354, arg_357) }; d__1 = tmp2; continue L1 } else { return d__1 } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :177:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A) Invoke_O_O__O(self, p1__1479000052_SHARP___1 any) any { var root_381 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = t.F_n; var arg_385 any = p1__1479000052_SHARP___1; if linked_382 == nil { return ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { return linked_382.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_381, arg_384, arg_385) } }

func A_arbace_j2g_model_desc_in_world_QMARK__A_New() *A_arbace_j2g_model_desc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :179:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var root_388 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var arg_392 any; var root_393 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = d__0; if linked_394 == nil { arg_392 = ifn_395.Invoke_O__O(arg_396) } else { arg_392 = linked_394.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_393, arg_396) }; if linked_389 == nil { return ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { return linked_389.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_388, arg_391, arg_392) } }
func A_arbace_j2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_j2g_model_mdesc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :180:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { var root_397 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var arg_401 any; var root_402 any = A_arbace_j2g_model_A_const_73.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_j2g_model_method_desc_classes_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = desc__0; if linked_403 == nil { arg_401 = ifn_404.Invoke_O__O(arg_405) } else { arg_401 = linked_403.(*A_arbace_j2g_model_method_desc_classes_A).Invoke_O_O__O(root_402, arg_405) }; if linked_398 == nil { return ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { return linked_398.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_397, arg_400, arg_401) } }




func A_arbace_j2g_model_go_name_A_New() *A_arbace_j2g_model_go_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_name_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_j2g_model_go_name_A) Ctor() {}
//line :185:1
func (t *A_arbace_j2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; if




	jrt.J2g_Truth(A_arbace_j2g_model_A_const_36.Get__O()) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_40; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2; var tmp2 any; var root_406 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_408 lang.IFn
			if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = n__0; if linked_407 == nil { tmp2 = ifn_408.Invoke_O__O(arg_409) } else { tmp2 = linked_407.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_406, arg_409) }; if jrt.J2g_Truth(tmp2) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = A_arbace_j2g_model_A_const_74.Invoke_O__O(jc__3) } } else {
//line :191:1
				or__1927000174__auto____2 = nil } } else {
//line :190:1
					or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						var root_410 any = A_arbace_j2g_model_A_const_75.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = n__0; if linked_411 == nil { return ifn_412.Invoke_O__O(arg_413) } else { return linked_411.(*aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_410, arg_413) } } }
func A_arbace_j2g_model_pkg_A_New() *A_arbace_j2g_model_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pkg_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_j2g_model_pkg_A) Ctor() {}
//line :194:1
func (t *A_arbace_j2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { var root_414 any = A_arbace_j2g_model_A_const_76.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = n__0; if linked_415 == nil { return ifn_416.Invoke_O__O(arg_417) } else { return linked_415.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_414, arg_417) } }

func A_arbace_j2g_model_abstract_QMARK__A_New() *A_arbace_j2g_model_abstract_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Ctor() {}
//line :196:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_418 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp2 any; var root_423 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, A_arbace_j2g_model_info_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = n__0; if linked_424 == nil { tmp2 = ifn_425.Invoke_O__O(arg_426) } else { tmp2 = linked_424.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_423, arg_426) }; arg_421 = tmp1.Invoke_O__O(tmp2); var arg_422 any = A_arbace_j2g_model_A_const_78; if linked_419 == nil { return ifn_420.Invoke_O_O__O(arg_421, arg_422) } else { return linked_419.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_418, arg_421, arg_422) } }
func A_arbace_j2g_model_final_QMARK__A_New() *A_arbace_j2g_model_final_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_j2g_model_final_QMARK__A) Ctor() {}
//line :197:1
func (t *A_arbace_j2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_427 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp2 any; var root_432 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_j2g_model_info_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = n__0; if linked_433 == nil { tmp2 = ifn_434.Invoke_O__O(arg_435) } else { tmp2 = linked_433.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_432, arg_435) }; arg_430 = tmp1.Invoke_O__O(tmp2); var arg_431 any = A_arbace_j2g_model_A_const_79; if linked_428 == nil { return ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { return linked_428.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_427, arg_430, arg_431) } }

func A_arbace_j2g_model_subclasses_A_New() *A_arbace_j2g_model_subclasses_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_subclasses_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_model_subclasses_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; return lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O())).Invoke__O(), n__0)
}
func A_arbace_j2g_model_make_subclass_index_A_New() *A_arbace_j2g_model_make_subclass_index_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any; var root_436 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_438 lang.IFn; if
											linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; if linked_437 == nil { cache__2 = ifn_438.Invoke_O__O(arg_439) } else { cache__2 = linked_437.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_436, arg_439) }; var fnbody__500 any =
											A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_New_O_O(cache__2, w__0); var tmp1 *jrt.Class; var fncls__499 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_fn_class; if fncls__499 == nil { var fncls__499d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__500); A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_fn_class = fncls__499d; tmp1 = fncls__499d } else { tmp1 = fncls__499 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__500, tmp1, nil) }
//line :206:1
func A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000065_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000065_A{}; t.Ctor_O_O(p0, p1); return t }
//line :206:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000065_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :206:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000065_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_440 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_442 lang.IFn; if
												linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = t.F_cache; if linked_441 == nil { or__1927000174__auto____1 = ifn_442.Invoke_O__O(arg_443) } else { or__1927000174__auto____1 = linked_441.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_440, arg_443) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var root_444 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = t.F_cache; var arg_448 any; var root_490 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_492 lang.IFn
													if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_90.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_36, t.F_w); if linked_491 == nil { ifn_492.Invoke_O__O(arg_493) } else { linked_491.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_490, arg_493) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__489 any = A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_New_O(t.F_w); var tmp2 *jrt.Class; var fncls__488 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_fn_class; if fncls__488 == nil { var fncls__488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__489); A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_fn_class = fncls__488d; tmp2 = fncls__488d } else { tmp2 = fncls__488 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__489, tmp2, nil); arg_448 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :208:1
		if linked_445 == nil { return ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { return linked_445.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_444, arg_447, arg_448) } } }
func A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_New_O(p0 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A{}; t.Ctor_O(p0); return t }
//line :209:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :209:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var root_449 any = A_arbace_j2g_model_A_const_82.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var fnbody__472 any = A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A_New(); var tmp2 *jrt.Class; var fncls__471 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A_fn_class; if fncls__471 == nil { var fncls__471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A_fn_class = fncls__471d; tmp2 = fncls__471d } else { tmp2 = fncls__471 }; arg_452 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__472, tmp2, nil); var arg_453 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_454 any; var root_473 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_475 lang.IFn


		if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any; var root_478 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, A_arbace_j2g_model_T_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; if linked_479 == nil { arg_476 = ifn_480.Invoke__O() } else { arg_476 = linked_479.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_478) }; var arg_477 any; var root_481 any = A_arbace_j2g_model_A_const_87.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_40; var tmp4 any; var t_ any = t.F_w; t.F_w = nil; tmp4 = t_; arg_484 = tmp3.Invoke_O__O(tmp4); if linked_482 == nil { arg_477 = ifn_483.Invoke_O__O(arg_484) } else { arg_477 = linked_482.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_481, arg_484) }; if linked_474 == nil { arg_454 = ifn_475.Invoke_O_O__O(arg_476, arg_477) } else { arg_454 = linked_474.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_473, arg_476, arg_477) }
//line :210:1
		if linked_450 == nil { tmp1 = ifn_451.Invoke_O_O_O__O(arg_452, arg_453, arg_454) } else { tmp1 = linked_450.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_449, arg_452, arg_453, arg_454) } }
//line :209:1
	return nil }(); var root_485 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; if linked_486 == nil { ifn_487.Invoke__O() } else { linked_486.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_485) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }
func A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A_New() *A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A) Ctor() {}
//line :210:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var s__3 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_83; var tmp2 any; var root_455 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, A_arbace_j2g_model_info_A_fn_class); var ifn_457 lang.IFn; if
																		linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = c__2; if linked_456 == nil { tmp2 = ifn_457.Invoke_O__O(arg_458) } else { tmp2 = linked_456.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_455, arg_458) }; s__3 = tmp1.Invoke_O__O(tmp2); if
																		jrt.J2g_Truth(s__3) { var root_459 any = A_arbace_j2g_model_A_const_84.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = m__1; var arg_463 any = s__3; var arg_464 any; var root_466 any = A_arbace_j2g_model_A_const_85.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var arg_470 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_467 == nil { arg_464 = ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { arg_464 = linked_467.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) }; var arg_465 any = c__2; if linked_460 == nil { return ifn_461.Invoke_O_O_O_O__O(arg_462, arg_463, arg_464, arg_465) } else { return linked_460.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_459, arg_462, arg_463, arg_464, arg_465) } } else { return m__1 } }


















































func A_arbace_j2g_model_leaf_QMARK__A_New() *A_arbace_j2g_model_leaf_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Ctor() {}
//line :263:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_501 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_503 lang.IFn

		if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = n__0; if linked_502 == nil { tmp1 = ifn_503.Invoke_O__O(arg_504) } else { tmp1 = linked_502.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_501, arg_504) }
//line :268:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var root_505 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_507 lang.IFn


			if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = n__0; if linked_506 == nil { tmp2 = ifn_507.Invoke_O__O(arg_508) } else { tmp2 = linked_506.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_505, arg_508) }
//line :268:1
			if jrt.J2g_Truth(tmp2) {


				var root_509 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any; var root_513 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_93; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_94; var arg_516 any = tmp3.Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O())); var arg_517 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28); var tmp6 any; var root_518 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, A_arbace_j2g_model_go_name_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = n__0; if linked_519 == nil { tmp6 = ifn_520.Invoke_O__O(arg_521) } else { tmp6 = linked_519.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_518, arg_521) }; arg_517 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_514 == nil { arg_512 = ifn_515.Invoke_O_O__O(arg_516, arg_517) } else { arg_512 = linked_514.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_513, arg_516, arg_517) }; if linked_510 == nil { return ifn_511.Invoke_O__O(arg_512) } else { return linked_510.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_509, arg_512) } } else {
//line :268:1
					if A_arbace_j2g_model_A_const_63 != nil { var and__1927000168__auto____2 any; var root_522 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_524 lang.IFn



						if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any; var root_526 any = A_arbace_j2g_model_A_const_96.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, A_arbace_j2g_model_abstract_QMARK__A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = n__0; if linked_527 == nil { arg_525 = ifn_528.Invoke_O__O(arg_529) } else { arg_525 = linked_527.(*A_arbace_j2g_model_abstract_QMARK__A).Invoke_O_O__O(root_526, arg_529) }; if linked_523 == nil { and__1927000168__auto____2 = ifn_524.Invoke_O__O(arg_525) } else { and__1927000168__auto____2 = linked_523.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_522, arg_525) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_530 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any; var root_534 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, A_arbace_j2g_model_subclasses_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = n__0; if linked_535 == nil { arg_533 = ifn_536.Invoke_O__O(arg_537) } else { arg_533 = linked_535.(*A_arbace_j2g_model_subclasses_A).Invoke_O_O__O(root_534, arg_537) }; if linked_531 == nil { and__1927000168__auto____3 = ifn_532.Invoke_O__O(arg_533) } else { and__1927000168__auto____3 = linked_531.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_530, arg_533) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
							var root_538 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_98.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_542 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any; var root_546 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = n__0; if linked_547 == nil { arg_545 = ifn_548.Invoke_O__O(arg_549) } else { arg_545 = linked_547.(*A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_546, arg_549) }; if linked_543 == nil { arg_541 = ifn_544.Invoke_O__O(arg_545) } else { arg_541 = linked_543.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_542, arg_545) } } else { arg_541 = and__1927000168__auto____4 }; if linked_539 == nil { return ifn_540.Invoke_O__O(arg_541) } else { return linked_539.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_538, arg_541) } } else {
//line :272:1
								return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :268:1
									return nil
								}
				}
		}
	}
}




func A_arbace_j2g_model_qualify_A_New() *A_arbace_j2g_model_qualify_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_qualify_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_j2g_model_qualify_A) Ctor() {}
//line :278:1
func (t *A_arbace_j2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z_NoInit(from__0, nil) }; if tmp1 { var root_550 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = ident__2; if linked_551 == nil { return ifn_552.Invoke_O__O(arg_553) } else { return linked_551.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_550, arg_553) } } else { var root_554 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any; var root_559 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = of__1; if linked_560 == nil { arg_557 = ifn_561.Invoke_O__O(arg_562) } else { arg_557 = linked_560.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A).Invoke_O_O__O(root_559, arg_562) }; var arg_558 any = ident__2; if linked_555 == nil { return ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { return linked_555.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_554, arg_557, arg_558)
	} } }
func A_arbace_j2g_model_class_sym_A_New() *A_arbace_j2g_model_class_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_sym_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_j2g_model_class_sym_A) Ctor() {}
//line :283:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	var root_563 any = A_arbace_j2g_model_A_const_102.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_j2g_model_qualify_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = from__0; var arg_567 any; var root_569 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, A_arbace_j2g_model_pkg_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = n__1; if linked_570 == nil { arg_567 = ifn_571.Invoke_O__O(arg_572) } else { arg_567 = linked_570.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_569, arg_572) }; var arg_568 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_573 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_j2g_model_go_name_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = n__1; if linked_574 == nil { tmp2 = ifn_575.Invoke_O__O(arg_576) } else { tmp2 = linked_574.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_573, arg_576) }; arg_568 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, suffix__2)).Ref(); if linked_564 == nil { return ifn_565.Invoke_O_O_O__O(arg_566, arg_567, arg_568) } else { return linked_564.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_563, arg_566, arg_567, arg_568) } }
//line :283:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	var root_577 any = A_arbace_j2g_model_A_const_104.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = from__0; var arg_581 any = n__1; var arg_582 any = Lit_13; if linked_578 == nil { return ifn_579.Invoke_O_O_O__O(arg_580, arg_581, arg_582) } else { return linked_578.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_577, arg_580, arg_581, arg_582)
	}
}
func A_arbace_j2g_model_jrt_sym_A_New() *A_arbace_j2g_model_jrt_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_j2g_model_jrt_sym_A) Ctor() {}
//line :288:1
func (t *A_arbace_j2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { var root_583 any = A_arbace_j2g_model_A_const_102.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, A_arbace_j2g_model_qualify_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = from__0; var arg_587 any = A_arbace_j2g_model_A_const_94; var arg_588 any = ident__1; if linked_584 == nil { return ifn_585.Invoke_O_O_O__O(arg_586, arg_587, arg_588) } else { return linked_584.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_583, arg_586, arg_587, arg_588) } }






func A_arbace_j2g_model_array_test_A_New() *A_arbace_j2g_model_array_test_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_array_test_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_j2g_model_array_test_A) Ctor() {}
//line :295:1
func (t *A_arbace_j2g_model_array_test_A) Invoke_O_O_O_O_O_O__O(self, from__0, kind__1, x__2, d__3, comp__4 any) any { var e__6 any; var root_589 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_591 lang.IFn; if






	linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = d__3; if linked_590 == nil { e__6 = ifn_591.Invoke_O__O(arg_592) } else { e__6 = linked_590.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_589, arg_592) }; var suffix__7 any; if
	lang.Util_Equiv_O_O__Z_NoInit(kind__1, A_arbace_j2g_model_A_const_105) { suffix__7 = Lit_7 } else { suffix__7 = Lit_8 }; var tmp1 any; var root_593 any =
	A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_595 lang.IFn; if
	linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = e__6; if linked_594 == nil { tmp1 = ifn_595.Invoke_O__O(arg_596) } else { tmp1 = linked_594.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_593, arg_596) }; if /*line :304:1*/ jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp3 any; var root_597 any = A_arbace_j2g_model_A_const_108.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = from__0; var arg_601 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_109.GetRawRoot__O()).Invoke_O__O(e__6), suffix__7)).Ref(); if linked_598 == nil { tmp3 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { tmp3 = linked_598.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }; return tmp2.Invoke_O_O__O(tmp3, x__2) } else {
//line :304:1
			if lang.Util_Equiv_O_O__Z_NoInit(e__6, Lit_9) {

				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp5 any; var root_602 any = A_arbace_j2g_model_A_const_108.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = from__0; var arg_606 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_603 == nil { tmp5 = ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { tmp5 = linked_603.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) }; return tmp4.Invoke_O_O__O(tmp5, x__2) } else {
//line :304:1
					if A_arbace_j2g_model_A_const_63 != nil {


						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp7 any; var root_607 any = A_arbace_j2g_model_A_const_108.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = from__0; var arg_611 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_608 == nil { tmp7 = ifn_609.Invoke_O_O__O(arg_610, arg_611) } else { tmp7 = linked_608.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_607, arg_610, arg_611) }; return tmp6.Invoke_O_O_O__O(tmp7, x__2, comp__4) } else {
//line :304:1
							return nil } } } }




func A_arbace_j2g_model_go_type_A_New() *A_arbace_j2g_model_go_type_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_type_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_model_go_type_A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, A_arbace_j2g_model_A_const_110) { return A_arbace_j2g_model_A_const_111 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_112.GetRawRoot__O()).Invoke_O__O(d__1)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_112.GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :312:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_27) { return nil } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_9) { return A_arbace_j2g_model_A_const_113 } else { var tmp1 any; var root_612 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_614 lang.IFn




				if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = d__1; if linked_613 == nil { tmp1 = ifn_614.Invoke_O__O(arg_615) } else { tmp1 = linked_613.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_612, arg_615) }
//line :312:1
				if jrt.J2g_Truth(tmp1) { var e__3 any; var root_616 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_618 lang.IFn




					if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = d__1; if linked_617 == nil { e__3 = ifn_618.Invoke_O__O(arg_619) } else { e__3 = linked_617.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_616, arg_619) }
					var tmp2 any; var root_620 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = e__3; if linked_621 == nil { tmp2 = ifn_622.Invoke_O__O(arg_623) } else { tmp2 = linked_621.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_620, arg_623) }; if jrt.J2g_Truth(tmp2) {
						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_119; var tmp5 any; var root_668 any = A_arbace_j2g_model_A_const_108.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = from__0; var arg_672 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_109.GetRawRoot__O()).Invoke_O__O(e__3); if linked_669 == nil { tmp5 = ifn_670.Invoke_O_O__O(arg_671, arg_672) } else { tmp5 = linked_669.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_668, arg_671, arg_672) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_A_const_120; var tmp8 any; var root_673 any = A_arbace_j2g_model_A_const_108.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = from__0; var arg_677 any = Lit_11; if linked_674 == nil { tmp8 = ifn_675.Invoke_O_O__O(arg_676, arg_677) } else { tmp8 = linked_674.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_673, arg_676, arg_677) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } } else {
//line :312:1
								var tmp9 any; var root_624 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_626 lang.IFn








								if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = d__1; if linked_625 == nil { tmp9 = ifn_626.Invoke_O__O(arg_627) } else { tmp9 = linked_625.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_624, arg_627) }
//line :312:1
								if jrt.J2g_Truth(tmp9) { var n__3 any; var root_628 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_630 lang.IFn









									if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = d__1; if linked_629 == nil { n__3 = ifn_630.Invoke_O__O(arg_631) } else { n__3 = linked_629.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_628, arg_631) }
									var tmp10 any; var root_632 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_634 lang.IFn
									if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any; var root_636 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = n__3; if linked_637 == nil { arg_635 = ifn_638.Invoke_O__O(arg_639) } else { arg_635 = linked_637.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_636, arg_639) }; if linked_633 == nil { tmp10 = ifn_634.Invoke_O__O(arg_635) } else { tmp10 = linked_633.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_632, arg_635) }
//line :323:1
									if jrt.J2g_Truth(tmp10) { return A_arbace_j2g_model_A_const_114 } else { var tmp11 any; var root_640 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_642 lang.IFn

										if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = n__3; if linked_641 == nil { tmp11 = ifn_642.Invoke_O__O(arg_643) } else { tmp11 = linked_641.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_640, arg_643) }
//line :323:1
										if jrt.J2g_Truth(tmp11) {

											var root_644 any = A_arbace_j2g_model_A_const_104.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = from__0; var arg_648 any = n__3; if linked_645 == nil { return ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { return linked_645.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) } } else {
//line :323:1
												var tmp12 any; var root_649 any = A_arbace_j2g_model_A_const_115.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_651 lang.IFn


												if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = n__3; if linked_650 == nil { tmp12 = ifn_651.Invoke_O__O(arg_652) } else { tmp12 = linked_650.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_649, arg_652) }
//line :323:1
												if jrt.J2g_Truth(tmp12) {


													var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_model_A_const_121; var tmp15 any; var root_678 any = A_arbace_j2g_model_A_const_104.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = from__0; var arg_682 any = n__3; if linked_679 == nil { tmp15 = ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { tmp15 = linked_679.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) }; return tmp13.Invoke_O_O__O(tmp14, tmp15) } else {
//line :323:1
														if A_arbace_j2g_model_A_const_63 != nil {



															var root_653 any = A_arbace_j2g_model_A_const_104.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = from__0; var arg_657 any = n__3; var arg_658 any = Lit_28; if linked_654 == nil { return ifn_655.Invoke_O_O_O__O(arg_656, arg_657, arg_658) } else { return linked_654.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_653, arg_656, arg_657, arg_658) } } else {
//line :323:1
																return nil } } } } } else {
//line :312:1
																	if A_arbace_j2g_model_A_const_63 != nil { var tmp16 any; var root_659 any = A_arbace_j2g_model_A_const_116.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_661 lang.IFn















																		if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_117.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); var arg_663 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_118, d__1)); if linked_660 == nil { tmp16 = ifn_661.Invoke_O_O__O(arg_662, arg_663) } else { tmp16 = linked_660.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_659, arg_662, arg_663) }
//line :312:1
																		panic(jrt.Thrown(jrt.Throwable_Cast(tmp16))) } else { return nil
																		}
																}
							}
			}
			}
		}
	}
}









func A_arbace_j2g_model_pointer_desc_QMARK__A_New() *A_arbace_j2g_model_pointer_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :330:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_683 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = d__0; if linked_684 == nil { tmp1 = ifn_685.Invoke_O__O(arg_686) } else { tmp1 = linked_684.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_683, arg_686) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_687 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_689 lang.IFn
		if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = d__0; if linked_688 == nil { tmp2 = ifn_689.Invoke_O__O(arg_690) } else { tmp2 = linked_688.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_687, arg_690) }
//line :333:1
		if jrt.J2g_Truth(tmp2) { var n__2 any; var root_691 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_693 lang.IFn
			if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = d__0; if linked_692 == nil { n__2 = ifn_693.Invoke_O__O(arg_694) } else { n__2 = linked_692.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_691, arg_694) }
//line :333:1
			var and__1927000168__auto____3 any; var root_695 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_697 lang.IFn

			if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = n__2; if linked_696 == nil { and__1927000168__auto____3 = ifn_697.Invoke_O__O(arg_698) } else { and__1927000168__auto____3 = linked_696.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_695, arg_698) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_699 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var root_703 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = n__2; if linked_704 == nil { arg_702 = ifn_705.Invoke_O__O(arg_706) } else { arg_702 = linked_704.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_703, arg_706) }; if linked_700 == nil { and__1927000168__auto____4 = ifn_701.Invoke_O__O(arg_702) } else { and__1927000168__auto____4 = linked_700.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_699, arg_702) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_707 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = n__2; var arg_711 any = Lit_30; if linked_708 == nil { and__1927000168__auto____5 = ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { and__1927000168__auto____5 = linked_708.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_707, arg_710, arg_711) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_712 any = A_arbace_j2g_model_A_const_115.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = n__2; if linked_713 == nil { return ifn_714.Invoke_O__O(arg_715) } else { return linked_713.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_712, arg_715) } } else {
//line :335:1
					return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :333:1
						if A_arbace_j2g_model_A_const_63 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
						}
					}
	}
}

func A_arbace_j2g_model_iface_desc_QMARK__A_New() *A_arbace_j2g_model_iface_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Ctor() {}
//line :339:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_716 any = A_arbace_j2g_model_A_const_123.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_718 lang.IFn; if


	linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = d__0; if linked_717 == nil { and__1927000168__auto____2 = ifn_718.Invoke_O__O(arg_719) } else { and__1927000168__auto____2 = linked_717.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_716, arg_719) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_720 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = d__0; var arg_724 any = A_arbace_j2g_model_A_const_110; if linked_721 == nil { and__1927000168__auto____3 = ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { and__1927000168__auto____3 = linked_721.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_720, arg_723, arg_724) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_725 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var root_729 any = A_arbace_j2g_model_A_const_124.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = d__0; if linked_730 == nil { arg_728 = ifn_731.Invoke_O__O(arg_732) } else { arg_728 = linked_730.(*A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_729, arg_732) }; if linked_726 == nil { return ifn_727.Invoke_O__O(arg_728) } else { return linked_726.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_725, arg_728) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_model_static_QMARK__A_New() *A_arbace_j2g_model_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_j2g_model_static_QMARK__A) Ctor() {}
//line :347:1
func (t *A_arbace_j2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_733 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = A_arbace_j2g_model_A_const_49.Invoke_O__O(m__0); var arg_737 any = A_arbace_j2g_model_A_const_125; if linked_734 == nil { return ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { return linked_734.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_733, arg_736, arg_737) } }
func A_arbace_j2g_model_private_QMARK__A_New() *A_arbace_j2g_model_private_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_j2g_model_private_QMARK__A) Ctor() {}
//line :348:1
func (t *A_arbace_j2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_738 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = A_arbace_j2g_model_A_const_49.Invoke_O__O(m__0); var arg_742 any = A_arbace_j2g_model_A_const_126; if linked_739 == nil { return ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { return linked_739.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_738, arg_741, arg_742) } }
func A_arbace_j2g_model_abstract_m_QMARK__A_New() *A_arbace_j2g_model_abstract_m_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Ctor() {}
//line :349:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_743 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = A_arbace_j2g_model_A_const_49.Invoke_O__O(m__0); var arg_747 any = A_arbace_j2g_model_A_const_78; if linked_744 == nil { return ifn_745.Invoke_O_O__O(arg_746, arg_747) } else { return linked_744.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_743, arg_746, arg_747) } }

func A_arbace_j2g_model_methods_of_A_New() *A_arbace_j2g_model_methods_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_methods_of_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_j2g_model_methods_of_A) Ctor() {}
//line :351:1
func (t *A_arbace_j2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_52; var tmp2 any; var root_748 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, A_arbace_j2g_model_info_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = n__0; if linked_749 == nil { tmp2 = ifn_750.Invoke_O__O(arg_751) } else { tmp2 = linked_749.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_748, arg_751) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_j2g_model_fields_of_A_New() *A_arbace_j2g_model_fields_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fields_of_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_j2g_model_fields_of_A) Ctor() {}
//line :352:1
func (t *A_arbace_j2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_127; var tmp2 any; var root_752 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, A_arbace_j2g_model_info_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = n__0; if linked_753 == nil { tmp2 = ifn_754.Invoke_O__O(arg_755) } else { tmp2 = linked_753.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_752, arg_755) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_find_method_A_New() *A_arbace_j2g_model_find_method_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_j2g_model_find_method_A) Ctor() {}
//line :354:1
func (t *A_arbace_j2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var root_756 any = A_arbace_j2g_model_A_const_71.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var fnbody__762 any = A_arbace_j2g_model_find_method_fn__1479000086_A_New_O_O(name__1, desc__2); var tmp1 *jrt.Class; var fncls__761 *jrt.Class = A_arbace_j2g_model_find_method_fn__1479000086_A_fn_class; if fncls__761 == nil { var fncls__761d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__762); A_arbace_j2g_model_find_method_fn__1479000086_A_fn_class = fncls__761d; tmp1 = fncls__761d } else { tmp1 = fncls__761 }; arg_759 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__762, tmp1, nil); var arg_760 any; var root_763 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = n__0; if linked_764 == nil { arg_760 = ifn_765.Invoke_O__O(arg_766) } else { arg_760 = linked_764.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_763, arg_766) }; if linked_757 == nil { return ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { return linked_757.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) } }
//line :355:1
func A_arbace_j2g_model_find_method_fn__1479000086_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_find_method_fn__1479000086_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_fn__1479000086_A{}; t.Ctor_O_O(p0, p1); return t }
//line :355:1
func (t *A_arbace_j2g_model_find_method_fn__1479000086_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :355:1
func (t *A_arbace_j2g_model_find_method_fn__1479000086_A) Invoke_O_O__O(self, p1__1479000085_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_model_A_const_128.Invoke_O__O(p1__1479000085_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_model_A_const_118.Invoke_O__O(p1__1479000085_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1479000085_SHARP___1 } else { return nil } }

func A_arbace_j2g_model_virtual_member_QMARK__A_New() *A_arbace_j2g_model_virtual_member_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Ctor() {}
//line :357:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any; var root_767 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_769 lang.IFn; if


	linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any; var root_771 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = m__0; if linked_772 == nil { arg_770 = ifn_773.Invoke_O__O(arg_774) } else { arg_770 = linked_772.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_771, arg_774) }; if linked_768 == nil { and__1927000168__auto____2 = ifn_769.Invoke_O__O(arg_770) } else { and__1927000168__auto____2 = linked_768.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_767, arg_770) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_775 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var root_779 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = m__0; if linked_780 == nil { arg_778 = ifn_781.Invoke_O__O(arg_782) } else { arg_778 = linked_780.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_779, arg_782) }; if linked_776 == nil { and__1927000168__auto____3 = ifn_777.Invoke_O__O(arg_778) } else { and__1927000168__auto____3 = linked_776.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_775, arg_778) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_783 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = Lit_43; var arg_787 any = A_arbace_j2g_model_A_const_128.Invoke_O__O(m__0); if linked_784 == nil { and__1927000168__auto____4 = ifn_785.Invoke_O_O__O(arg_786, arg_787) } else { and__1927000168__auto____4 = linked_784.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_783, arg_786, arg_787) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_788 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = Lit_42; var arg_792 any = A_arbace_j2g_model_A_const_128.Invoke_O__O(m__0); if linked_789 == nil { return ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { return linked_789.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_788, arg_791, arg_792) } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_model_supertypes_A_New() *A_arbace_j2g_model_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_supertypes_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_j2g_model_supertypes_A) Ctor() {}
//line :367:1
func (t *A_arbace_j2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_793 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_j2g_model_info_A_fn_class); var ifn_795 lang.IFn; if
										linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = n__0; if linked_794 == nil { i__2 = ifn_795.Invoke_O__O(arg_796) } else { i__2 = linked_794.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_793, arg_796) }; var root_797 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var arg_801 any; var root_802 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = A_arbace_j2g_model_A_const_83.Invoke_O__O(i__2); var arg_806 any = A_arbace_j2g_model_A_const_56.Invoke_O__O(i__2); if linked_803 == nil { arg_801 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { arg_801 = linked_803.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; if linked_798 == nil { return ifn_799.Invoke_O_O__O(arg_800, arg_801) } else { return linked_798.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_797, arg_800, arg_801) } }

func A_arbace_j2g_model_world_supertypes_A_New() *A_arbace_j2g_model_world_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_j2g_model_world_supertypes_A) Ctor() {}
//line :370:1
func (t *A_arbace_j2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	var root_807 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var arg_811 any; var root_812 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, A_arbace_j2g_model_supertypes_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = n__0; if linked_813 == nil { arg_811 = ifn_814.Invoke_O__O(arg_815) } else { arg_811 = linked_813.(*A_arbace_j2g_model_supertypes_A).Invoke_O_O__O(root_812, arg_815) }; if linked_808 == nil { return ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { return linked_808.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_807, arg_810, arg_811)
	} }
func A_arbace_j2g_model_all_supertypes_A_New() *A_arbace_j2g_model_all_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_j2g_model_all_supertypes_A) Ctor() {}
//line :375:1
func (t *A_arbace_j2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	var root_816 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_820 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var arg_824 any; var root_825 any = A_arbace_j2g_model_A_const_136.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = n__0; if linked_826 == nil { arg_824 = ifn_827.Invoke_O__O(arg_828) } else { arg_824 = linked_826.(*aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_825, arg_828) }; if linked_821 == nil { arg_819 = ifn_822.Invoke_O_O__O(arg_823, arg_824) } else { arg_819 = linked_821.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_820, arg_823, arg_824) }; if linked_817 == nil { return ifn_818.Invoke_O__O(arg_819) } else { return linked_817.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_816, arg_819)
	}
}

func A_arbace_j2g_model_hw_method_exists_QMARK__A_New() *A_arbace_j2g_model_hw_method_exists_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :384:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_94; var scan__3 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()); var g__4 any; var root_829 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_j2g_model_go_name_A_fn_class); var ifn_831 lang.IFn; if



	linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = n__0; if linked_830 == nil { g__4 = ifn_831.Invoke_O__O(arg_832) } else { g__4 = linked_830.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_829, arg_832) }; var base__5 any; var root_833 any = /*line :384:1*/A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_835 lang.IFn; if




	linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = A_arbace_j2g_model_A_const_128.Invoke_O__O(m__1); var arg_837 any = A_arbace_j2g_model_A_const_118.Invoke_O__O(m__1); if linked_834 == nil { base__5 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { base__5 = linked_834.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }; if
	lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30) {
		var root_838 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var arg_842 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_128.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_118.Invoke_O__O(m__1)); if linked_839 == nil { return ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { return linked_839.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_838, arg_841, arg_842) } } else {
//line :390:1
			var tmp2 any; var root_843 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_845 lang.IFn

			if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = n__0; if linked_844 == nil { tmp2 = ifn_845.Invoke_O__O(arg_846) } else { tmp2 = linked_844.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_843, arg_846) }
//line :390:1
			if jrt.J2g_Truth(tmp2) { var or__1927000174__auto____6 any; var root_847 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_849 lang.IFn

				if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any; var root_852 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = scan__3; var arg_856 any = g__4; if linked_853 == nil { arg_850 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { arg_850 = linked_853.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; var arg_851 any = base__5; if linked_848 == nil { or__1927000174__auto____6 = ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { or__1927000174__auto____6 = linked_848.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_847, arg_850, arg_851) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					var root_857 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = A_arbace_j2g_model_A_const_140.Invoke_O__O(scan__3); var arg_861 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref(); if linked_858 == nil { return ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { return linked_858.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_857, arg_860, arg_861) } } } else {
//line :390:1
						if A_arbace_j2g_model_A_const_63 != nil { var ms__6 any; var root_862 any = A_arbace_j2g_model_A_const_141.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_864 lang.IFn




							if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = scan__3; var arg_866 any = g__4; if linked_863 == nil { ms__6 = ifn_864.Invoke_O_O__O(arg_865, arg_866) } else { ms__6 = linked_863.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_862, arg_865, arg_866) }
//line :390:1
							var or__1927000174__auto____7 any; var root_867 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_869 lang.IFn





							if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = ms__6; var arg_871 any = base__5; if linked_868 == nil { or__1927000174__auto____7 = ifn_869.Invoke_O_O__O(arg_870, arg_871) } else { or__1927000174__auto____7 = linked_868.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_867, arg_870, arg_871) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_872 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = ms__6; var arg_876 any; var root_877 any = A_arbace_j2g_model_A_const_142.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = base__5; if linked_878 == nil { arg_876 = ifn_879.Invoke_O__O(arg_880) } else { arg_876 = linked_878.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_877, arg_880) }; if linked_873 == nil { or__1927000174__auto____8 = ifn_874.Invoke_O_O__O(arg_875, arg_876) } else { or__1927000174__auto____8 = linked_873.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_872, arg_875, arg_876) }; if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								var root_881 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, A_arbace_j2g_model_j2g_method_QMARK__A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = n__0; var arg_885 any = base__5; if linked_882 == nil { return ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { return linked_882.(*A_arbace_j2g_model_j2g_method_QMARK__A).Invoke_O_O_O__O(root_881, arg_884, arg_885) } } } } else {
//line :390:1
									return nil } } } }








func A_arbace_j2g_model_j2g_method_QMARK__A_New() *A_arbace_j2g_model_j2g_method_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_method_QMARK__A{}; t.Ctor(); return t }
//line :399:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Ctor() {}
//line :399:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_46); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_144).Invoke_O__O(base__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_886 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_888 lang.IFn
		if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = Lit_47; if linked_887 == nil { and__1927000168__auto____5 = ifn_888.Invoke_O__O(arg_889) } else { and__1927000168__auto____5 = linked_887.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_886, arg_889) }
//line :406:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_890 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = Lit_48; if linked_891 == nil { return ifn_892.Invoke_O__O(arg_893) } else { return linked_891.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_890, arg_893) } } else {
//line :406:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_member_in_world_QMARK__A_New() *A_arbace_j2g_model_member_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Ctor() {}
//line :409:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any; var root_894 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_896 lang.IFn; if



	linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = A_arbace_j2g_model_A_const_118.Invoke_O__O(m__1); if linked_895 == nil { and__1927000168__auto____3 = ifn_896.Invoke_O__O(arg_897) } else { and__1927000168__auto____3 = linked_895.(*A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_894, arg_897) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_898 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_900 lang.IFn
		if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any; var root_902 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = n__0; if linked_903 == nil { arg_901 = ifn_904.Invoke_O__O(arg_905) } else { arg_901 = linked_903.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_902, arg_905) }; if linked_899 == nil { or__1927000174__auto____4 = ifn_900.Invoke_O__O(arg_901) } else { or__1927000174__auto____4 = linked_899.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_898, arg_901) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_906 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = n__0; var arg_910 any = m__1; if linked_907 == nil { return ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { return linked_907.(*A_arbace_j2g_model_hw_method_exists_QMARK__A).Invoke_O_O_O__O(root_906, arg_909, arg_910) } } } else {
//line :413:1
			return and__1927000168__auto____3 } }


func A_arbace_j2g_model_declared_vmethods_A_New() *A_arbace_j2g_model_declared_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Ctor() {}
//line :416:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var fnbody__1010 any = A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_fn_class; if


	fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__1010); A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_fn_class = fncls__1009d; tmp1 = fncls__1009d } else { tmp1 = fncls__1009 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1010, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_1011 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = n__0; if linked_1012 == nil { tmp3 = ifn_1013.Invoke_O__O(arg_1014) } else { tmp3 = linked_1012.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_1011, arg_1014) }; return tmp2.Invoke_O__O(tmp3) }
//line :419:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_New_O(p0 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A{}; t.Ctor_O(p0); return t }
//line :419:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :419:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A) Invoke_O_O__O(self, s__1479000097__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1008 any = A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_New_O_O_O(t.F_n, s__1479000097__1, self); var tmp2 *jrt.Class; var fncls__1007 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_fn_class; if fncls__1007 == nil { var fncls__1007d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__1008); A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_fn_class = fncls__1007d; tmp2 = fncls__1007d } else { tmp2 = fncls__1007 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1008, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :419:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :419:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A) Ctor_O_O_O(c__n, c__s__1479000097, c__iter__1479000096 any) { t.F_n = c__n; t.F_s__1479000097 = c__s__1479000097; t.F_iter__1479000096 = c__iter__1479000096 }
//line :419:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A) Invoke_O__O(self any) any { { var s__1479000097__1 any; var t_ any = t.F_s__1479000097; t.F_s__1479000097 = nil; s__1479000097__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_911 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = s__1479000097__1; if linked_912 == nil { temp__1927000414__auto____2 = ifn_913.Invoke_O__O(arg_914) } else { temp__1927000414__auto____2 = linked_912.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_911, arg_914) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000097__3 any = temp__1927000414__auto____2; var tmp1 any; var root_915 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = s__1479000097__3; if linked_916 == nil { tmp1 = ifn_917.Invoke_O__O(arg_918) } else { tmp1 = linked_916.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_915, arg_918) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_919 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = s__1479000097__3; if linked_920 == nil { c__1927001037__auto____4 = ifn_921.Invoke_O__O(arg_922) } else { c__1927001037__auto____4 = linked_920.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_919, arg_922) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000099__6 any; var root_923 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_924 == nil { b__1479000099__6 = ifn_925.Invoke_O__O(arg_926) } else { b__1479000099__6 = linked_924.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_923, arg_926) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__948 any = A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A_New_O_O_I_O(b__1479000099__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__947 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A_fn_class; if fncls__947 == nil { var fncls__947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__948); A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A_fn_class = fncls__947d; tmp3 = fncls__947d } else { tmp3 = fncls__947 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__948, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_949 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any; var root_954 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = b__1479000099__6; if linked_955 == nil { arg_952 = ifn_956.Invoke_O__O(arg_957) } else { arg_952 = linked_955.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_954, arg_957) }; var arg_953 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000096); var tmp5 any; var root_958 any = A_arbace_j2g_model_A_const_157.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = s__1479000097__3; if linked_959 == nil { tmp5 = ifn_960.Invoke_O__O(arg_961) } else { tmp5 = linked_959.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_958, arg_961) }; arg_953 = tmp4.Invoke_O__O(tmp5); if linked_950 == nil { return ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { return linked_950.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) } } else { var root_962 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any; var root_967 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = b__1479000099__6; if linked_968 == nil { arg_965 = ifn_969.Invoke_O__O(arg_970) } else { arg_965 = linked_968.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_967, arg_970) }; var arg_966 any; if linked_963 == nil { return ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { return linked_963.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_962, arg_965, arg_966) } } } else { var m__4 any; var root_971 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = s__1479000097__3; if linked_972 == nil { m__4 = ifn_973.Invoke_O__O(arg_974) } else { m__4 = linked_972.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_971, arg_974) }; var tmp6 any; var root_975 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_977 lang.IFn
															if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = m__4; if linked_976 == nil { tmp6 = ifn_977.Invoke_O__O(arg_978) } else { tmp6 = linked_976.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_975, arg_978) }
//line :419:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_979 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_981 lang.IFn

		if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = t.F_n; var arg_983 any = m__4; if linked_980 == nil { tmp7 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp7 = linked_980.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }
//line :419:1
		if jrt.J2g_Truth(tmp7) { var root_984 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any; var root_989 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_991 lang.IFn


			if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = m__4; var arg_993 any = A_arbace_j2g_model_A_const_154; var arg_994 any = t.F_n; if linked_990 == nil { arg_987 = ifn_991.Invoke_O_O_O__O(arg_992, arg_993, arg_994) } else { arg_987 = linked_990.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_989, arg_992, arg_993, arg_994) }
//line :419:1
			var arg_988 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000096); var tmp9 any; var root_995 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = s__1479000097__3; if linked_996 == nil { tmp9 = ifn_997.Invoke_O__O(arg_998) } else { tmp9 = linked_996.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_995, arg_998) }; arg_988 = tmp8.Invoke_O__O(tmp9); if linked_985 == nil { return ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { return linked_985.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) } } else { var tmp10 any; var root_999 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = s__1479000097__3; if linked_1000 == nil { tmp10 = ifn_1001.Invoke_O__O(arg_1002) } else { tmp10 = linked_1000.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_999, arg_1002) }; s__1479000097__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1003 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = s__1479000097__3; if linked_1004 == nil { tmp11 = ifn_1005.Invoke_O__O(arg_1006) } else { tmp11 = linked_1004.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1003, arg_1006) }; s__1479000097__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :419:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :419:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A) Ctor_O_O_I_O(c__b__1479000099, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000099 = c__b__1479000099; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :419:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A) Invoke_O__O(self any) any { { var i__1479000098__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000098__1)); var tmp2 any; var root_927 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_929 lang.IFn
																	if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = m__2; if linked_928 == nil { tmp2 = ifn_929.Invoke_O__O(arg_930) } else { tmp2 = linked_928.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_927, arg_930) }
//line :419:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_931 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_933 lang.IFn

		if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = t.F_n; var arg_935 any = m__2; if linked_932 == nil { tmp3 = ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { tmp3 = linked_932.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_931, arg_934, arg_935) }
//line :419:1
		if jrt.J2g_Truth(tmp3) { var root_936 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = t.F_b__1479000099; var arg_940 any; var root_941 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_943 lang.IFn


			if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = m__2; var arg_945 any = A_arbace_j2g_model_A_const_154; var arg_946 any = t.F_n; if linked_942 == nil { arg_940 = ifn_943.Invoke_O_O_O__O(arg_944, arg_945, arg_946) } else { arg_940 = linked_942.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_941, arg_944, arg_945, arg_946) }
//line :419:1
			if linked_937 == nil { ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { linked_937.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }; i__1479000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000098__1); continue L1 } else { i__1479000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000098__1); continue L1 } } else { i__1479000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000098__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_model_vmethods_A_New() *A_arbace_j2g_model_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_A{}; t.Ctor(); return t }
//line :424:1
func (t *A_arbace_j2g_model_vmethods_A) Ctor() {}
//line :424:1
func (t *A_arbace_j2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_160; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()); var or__1927000174__auto____3 any; var tmp2 any; var root_1015 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1017 lang.IFn; if




	linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = cache__2; if linked_1016 == nil { tmp2 = ifn_1017.Invoke_O__O(arg_1018) } else { tmp2 = linked_1016.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1015, arg_1018) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var root_1019 any = A_arbace_j2g_model_A_const_82.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1021 lang.IFn
		if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any; var fnbody__1054 any = A_arbace_j2g_model_vmethods_fn__1479000107_A_New(); var tmp3 *jrt.Class; var fncls__1053 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000107_A_fn_class; if fncls__1053 == nil { var fncls__1053d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_j2g_model_vmethods_fn__1479000107_A_fn_class = fncls__1053d; tmp3 = fncls__1053d } else { tmp3 = fncls__1053 }; arg_1022 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1054, tmp3, nil); var arg_1023 any; var root_1055 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_1057 lang.IFn






		if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; if linked_1056 == nil { arg_1023 = ifn_1057.Invoke__O() } else { arg_1023 = linked_1056.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_1055) }
//line :430:1
		var arg_1024 any; var root_1058 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1060 lang.IFn






		if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = n__0; if linked_1059 == nil { arg_1024 = ifn_1060.Invoke_O__O(arg_1061) } else { arg_1024 = linked_1059.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1058, arg_1061) }
//line :430:1
		if linked_1020 == nil { r__4 = ifn_1021.Invoke_O_O_O__O(arg_1022, arg_1023, arg_1024) } else { r__4 = linked_1020.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1019, arg_1022, arg_1023, arg_1024)
		}






		var root_1062 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = cache__2; var arg_1066 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var arg_1067 any = n__0; var arg_1068 any = r__4; if linked_1063 == nil { ifn_1064.Invoke_O_O_O_O__O(arg_1065, arg_1066, arg_1067, arg_1068) } else { linked_1063.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1062, arg_1065, arg_1066, arg_1067, arg_1068) }
//line :429:1
		return r__4 } }
func A_arbace_j2g_model_vmethods_fn__1479000107_A_New() *A_arbace_j2g_model_vmethods_fn__1479000107_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000107_A{}; t.Ctor(); return t }
//line :430:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000107_A) Ctor() {}
//line :430:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000107_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(c__2, Lit_30) { return acc__1 } else {

		var root_1025 any = A_arbace_j2g_model_A_const_82.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any; var fnbody__1048 any = A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A_New(); var tmp1 *jrt.Class; var fncls__1047 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A_fn_class; if fncls__1047 == nil { var fncls__1047d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A_fn_class = fncls__1047d; tmp1 = fncls__1047d } else { tmp1 = fncls__1047 }; arg_1028 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1048, tmp1, nil); var arg_1029 any = acc__1; var arg_1030 any; var root_1049 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, A_arbace_j2g_model_declared_vmethods_A_fn_class); var ifn_1051 lang.IFn


		if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = c__2; if linked_1050 == nil { arg_1030 = ifn_1051.Invoke_O__O(arg_1052) } else { arg_1030 = linked_1050.(*A_arbace_j2g_model_declared_vmethods_A).Invoke_O_O__O(root_1049, arg_1052) }
//line :433:1
		if linked_1026 == nil { return ifn_1027.Invoke_O_O_O__O(arg_1028, arg_1029, arg_1030) } else { return linked_1026.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1025, arg_1028, arg_1029, arg_1030) } } }
//line :433:1
func A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A_New() *A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A{}; t.Ctor(); return t }
//line :433:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A) Ctor() {}
//line :433:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_128.Invoke_O__O(m__2), A_arbace_j2g_model_A_const_118.Invoke_O__O(m__2)); var tmp1 any; var or__1927000174__auto____4 any; var root_1031 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1033 lang.IFn; if

	linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = acc__1; var arg_1035 any = k__3; if linked_1032 == nil { or__1927000174__auto____4 = ifn_1033.Invoke_O_O__O(arg_1034, arg_1035) } else { or__1927000174__auto____4 = linked_1032.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1031, arg_1034, arg_1035) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_1036 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var arg_1040 any = k__3; if linked_1037 == nil { tmp1 = ifn_1038.Invoke_O_O__O(arg_1039, arg_1040) } else { tmp1 = linked_1037.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1036, arg_1039, arg_1040) } }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_1041 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = acc__1; var arg_1045 any = k__3; var arg_1046 any = m__2; if linked_1042 == nil { return ifn_1043.Invoke_O_O_O__O(arg_1044, arg_1045, arg_1046) } else { return linked_1042.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1041, arg_1044, arg_1045, arg_1046) } } }





func A_arbace_j2g_model_java_type_name_A_New() *A_arbace_j2g_model_java_type_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_java_type_name_A{}; t.Ctor(); return t }
//line :441:1
func (t *A_arbace_j2g_model_java_type_name_A) Ctor() {}
//line :441:1
func (t *A_arbace_j2g_model_java_type_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_1069 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = d__0; if linked_1070 == nil { tmp1 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp1 = linked_1070.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1069, arg_1072) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_52); var tmp3 any; var root_1073 any = A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any; var root_1077 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = d__0; if linked_1078 == nil { arg_1076 = ifn_1079.Invoke_O__O(arg_1080) } else { arg_1076 = linked_1078.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1077, arg_1080) }; if linked_1074 == nil { tmp3 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp3 = linked_1074.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1073, arg_1076) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref() } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(d__0))) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_165).Invoke_O__O(d__0) } else {
//line :444:1
			if A_arbace_j2g_model_A_const_63 != nil {


				var root_1081 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any; var root_1087 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = d__0; if linked_1088 == nil { arg_1084 = ifn_1089.Invoke_O__O(arg_1090) } else { arg_1084 = linked_1088.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1087, arg_1090) }; var arg_1085 any = Lit_1; var arg_1086 any = Lit_2; if linked_1082 == nil { return ifn_1083.Invoke_O_O_O__O(arg_1084, arg_1085, arg_1086) } else { return linked_1082.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1081, arg_1084, arg_1085, arg_1086) } } else {
//line :444:1
					return nil
				}
		}
	}
}
func A_arbace_j2g_model_abstract_method_error_text_A_New() *A_arbace_j2g_model_abstract_method_error_text_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_method_error_text_A{}; t.Ctor(); return t }
//line :449:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Ctor() {}
//line :449:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Invoke_O_O_O_O__O(self, n__0, owner__1, p__1479000113__2 any) any { var vec__1479000114__4 any = p__1479000113__2; var name__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000114__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000114__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1479000117__7 any; var root_1091 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1093 lang.IFn; if



	linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = desc__6; if linked_1092 == nil { vec__1479000117__7 = ifn_1093.Invoke_O__O(arg_1094) } else { vec__1479000117__7 = linked_1092.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1091, arg_1094) }; var ps__8 any = /*line :449:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1479000117__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000117__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,12,s15:Receiver class ns69: does not define or inherit an implementation of the resolved method s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1095 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1097 lang.IFn; if




	linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = n__0; var arg_1099 any = Lit_1; var arg_1100 any = Lit_2; if linked_1096 == nil { tmp2 = ifn_1097.Invoke_O_O_O__O(arg_1098, arg_1099, arg_1100) } else { tmp2 = linked_1096.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1095, arg_1098, arg_1099, arg_1100) }; var tmp3 any = tmp2; var tmp4 any; var root_1101 any = A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1103 lang.IFn; if
	linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = r__9; if linked_1102 == nil { tmp4 = ifn_1103.Invoke_O__O(arg_1104) } else { tmp4 = linked_1102.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1101, arg_1104) }; var tmp5 any = tmp4; var tmp6 any; var root_1105 any = /*line :454:1*/A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1107 lang.IFn; if
	linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = Lit_3; var arg_1109 any; var root_1110 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var arg_1114 any = ps__8; if linked_1111 == nil { arg_1109 = ifn_1112.Invoke_O_O__O(arg_1113, arg_1114) } else { arg_1109 = linked_1111.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1110, arg_1113, arg_1114) }; if linked_1106 == nil { tmp6 = ifn_1107.Invoke_O_O__O(arg_1108, arg_1109) } else { tmp6 = linked_1106.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1105, arg_1108, arg_1109) }; var tmp7 any = tmp6; var tmp8 /*line :454:1*/*jrt.String; if

	jrt.J2g_Truth(owner__1) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil, nil); var tmp10 *jrt.String; var tmp11 any; var root_1115 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = owner__1; if linked_1116 == nil { tmp11 = ifn_1117.Invoke_O__O(arg_1118) } else { tmp11 = linked_1116.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1115, arg_1118) }; if jrt.J2g_Truth(tmp11) { tmp10 = Lit_5 } else { tmp10 = Lit_6 }; var tmp12 any = tmp10.Ref(); var tmp13 any; var root_1119 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = owner__1; var arg_1123 any = Lit_1; var arg_1124 any = Lit_2; if linked_1120 == nil { tmp13 = ifn_1121.Invoke_O_O_O__O(arg_1122, arg_1123, arg_1124) } else { tmp13 = linked_1120.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1119, arg_1122, arg_1123, arg_1124) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13)) } else { tmp8 = nil }; return /*line :454:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, nil, tmp5, nil, name__5, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }



func A_arbace_j2g_model_superclass_chain_A_New() *A_arbace_j2g_model_superclass_chain_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_j2g_model_superclass_chain_A) Ctor() {}
//line :458:1
func (t *A_arbace_j2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1125 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var arg_1129 any; var root_1130 any = A_arbace_j2g_model_A_const_170.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any; var fnbody__1140 any = A_arbace_j2g_model_superclass_chain_fn__1479000122_A_New(); var tmp1 *jrt.Class; var fncls__1139 *jrt.Class = A_arbace_j2g_model_superclass_chain_fn__1479000122_A_fn_class; if fncls__1139 == nil { var fncls__1139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, nil); A_arbace_j2g_model_superclass_chain_fn__1479000122_A_fn_class = fncls__1139d; tmp1 = fncls__1139d } else { tmp1 = fncls__1139 }; arg_1133 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1140, tmp1, nil); var arg_1134 any = n__0; if linked_1131 == nil { arg_1129 = ifn_1132.Invoke_O_O__O(arg_1133, arg_1134) } else { arg_1129 = linked_1131.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1130, arg_1133, arg_1134) }; if linked_1126 == nil { return ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { return linked_1126.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) } }
//line :459:1
func A_arbace_j2g_model_superclass_chain_fn__1479000122_A_New() *A_arbace_j2g_model_superclass_chain_fn__1479000122_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_fn__1479000122_A{}; t.Ctor(); return t }
//line :459:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000122_A) Ctor() {}
//line :459:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000122_A) Invoke_O_O__O(self, p1__1479000121_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_83; var tmp2 any; var root_1135 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, A_arbace_j2g_model_info_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = p1__1479000121_SHARP___1; if linked_1136 == nil { tmp2 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp2 = linked_1136.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1135, arg_1138) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_impl_of_A_New() *A_arbace_j2g_model_impl_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_A{}; t.Ctor(); return t }
//line :461:1
func (t *A_arbace_j2g_model_impl_of_A) Ctor() {}
//line :461:1
func (t *A_arbace_j2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1479000126__1 any) any { var vec__1479000127__3 any = p__1479000126__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000127__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000127__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__1479000127__3; var or__1927000174__auto____7 any; var root_1141 any = A_arbace_j2g_model_A_const_71.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1143 lang.IFn; _ = k__6; if





	linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any; var fnbody__1217 any = A_arbace_j2g_model_impl_of_fn__1479000130_A_New_O_O_O(name__4, desc__5, n__0); var tmp1 *jrt.Class; var fncls__1216 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000130_A_fn_class; if fncls__1216 == nil { var fncls__1216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__1217); A_arbace_j2g_model_impl_of_fn__1479000130_A_fn_class = fncls__1216d; tmp1 = fncls__1216d } else { tmp1 = fncls__1216 }; arg_1144 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1217, tmp1, nil); var arg_1145 any; var root_1218 any = A_arbace_j2g_model_A_const_179.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1220 lang.IFn; if












	linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = n__0; if linked_1219 == nil { arg_1145 = ifn_1220.Invoke_O__O(arg_1221) } else { arg_1145 = linked_1219.(*A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1218, arg_1221) }; if /*line :467:1*/ linked_1142 == nil { or__1927000174__auto____7 = ifn_1143.Invoke_O_O__O(arg_1144, arg_1145) } else { or__1927000174__auto____7 = linked_1142.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1141, arg_1144, arg_1145) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var fnbody__1407 any = A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_New_O_O(name__4, desc__5); var tmp2 *jrt.Class
		var fncls__1406 /*line :467:1*/*jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_fn_class














		if fncls__1406 == nil { var fncls__1406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__1407); A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_fn_class = fncls__1406d; tmp2 = fncls__1406d } else { tmp2 = fncls__1406 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1407, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp4 any; var root_1436 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = n__0; if linked_1437 == nil { tmp4 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp4 = linked_1437.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1436, arg_1439) }; cands__8 = tmp3.Invoke_O__O(tmp4)
//line :467:1
		var cands__9 any; var root_1408 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1410 lang.IFn





















		if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var fnbody__1431 any = A_arbace_j2g_model_impl_of_fn__1479000142_A_New_O(cands__8); var tmp5 *jrt.Class; var fncls__1430 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000142_A_fn_class; if fncls__1430 == nil { var fncls__1430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__1431); A_arbace_j2g_model_impl_of_fn__1479000142_A_fn_class = fncls__1430d; tmp5 = fncls__1430d } else { tmp5 = fncls__1430 }; arg_1411 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1431, tmp5, nil); var arg_1412 any = cands__8; if linked_1409 == nil { cands__9 = ifn_1410.Invoke_O_O__O(arg_1411, arg_1412) } else { cands__9 = linked_1409.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1408, arg_1411, arg_1412) }
		var root_1432 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = cands__9; if linked_1433 == nil { return ifn_1434.Invoke_O__O(arg_1435) } else { return linked_1433.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1432, arg_1435) } } }
//line :467:1
func A_arbace_j2g_model_impl_of_fn__1479000130_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_impl_of_fn__1479000130_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000130_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :467:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000130_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :467:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000130_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var root_1146 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1148 lang.IFn; if
											linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var root_1150 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = c__1; if linked_1151 == nil { arg_1149 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1149 = linked_1151.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1150, arg_1153) }; if linked_1147 == nil { and__1927000168__auto____2 = ifn_1148.Invoke_O__O(arg_1149) } else { and__1927000168__auto____2 = linked_1147.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1146, arg_1149) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1154 any = A_arbace_j2g_model_A_const_171.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = c__1; var arg_1158 any = t.F_name; var arg_1159 any = t.F_desc; if linked_1155 == nil { temp__1927000414__auto____2 = ifn_1156.Invoke_O_O_O__O(arg_1157, arg_1158, arg_1159) } else { temp__1927000414__auto____2 = linked_1155.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1154, arg_1157, arg_1158, arg_1159) } } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any; var root_1160 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1162 lang.IFn
												if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any; var root_1164 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = m__3; if linked_1165 == nil { arg_1163 = ifn_1166.Invoke_O__O(arg_1167) } else { arg_1163 = linked_1165.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1164, arg_1167) }; if linked_1161 == nil { and__1927000168__auto____4 = ifn_1162.Invoke_O__O(arg_1163) } else { and__1927000168__auto____4 = linked_1161.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1160, arg_1163) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1168 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any; var root_1172 any = A_arbace_j2g_model_A_const_172.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = m__3; if linked_1173 == nil { arg_1171 = ifn_1174.Invoke_O__O(arg_1175) } else { arg_1171 = linked_1173.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1172, arg_1175) }; if linked_1169 == nil { and__1927000168__auto____5 = ifn_1170.Invoke_O__O(arg_1171) } else { and__1927000168__auto____5 = linked_1169.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1168, arg_1171) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1176 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1178 lang.IFn
													if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var root_1180 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = m__3; if linked_1181 == nil { arg_1179 = ifn_1182.Invoke_O__O(arg_1183) } else { arg_1179 = linked_1181.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1180, arg_1183) }; if linked_1177 == nil { or__1927000174__auto____6 = ifn_1178.Invoke_O__O(arg_1179) } else { or__1927000174__auto____6 = linked_1177.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1176, arg_1179) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__1, t.F_n)).Ref() } } else {
//line :469:1
				tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

					if lang.Util_Equiv_O_O__Z_NoInit(c__1, Lit_30) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_174, A_arbace_j2g_model_A_const_154, c__1, A_arbace_j2g_model_A_const_175, m__3)) } else { var tmp2 any; var root_1184 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1186 lang.IFn

						if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = c__1; if linked_1185 == nil { tmp2 = ifn_1186.Invoke_O__O(arg_1187) } else { tmp2 = linked_1185.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1184, arg_1187) }
//line :471:1
						if jrt.J2g_Truth(tmp2) { var base__4 any; var root_1188 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1190 lang.IFn


							if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = t.F_name; var arg_1192 any = t.F_desc; if linked_1189 == nil { base__4 = ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { base__4 = linked_1189.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) }
//line :471:1
							var ms__5 any; var root_1193 any = A_arbace_j2g_model_A_const_141.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1195 lang.IFn



							if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_94; var arg_1196 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()); var arg_1197 any; var root_1198 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = c__1; if linked_1199 == nil { arg_1197 = ifn_1200.Invoke_O__O(arg_1201) } else { arg_1197 = linked_1199.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1198, arg_1201) }; if linked_1194 == nil { ms__5 = ifn_1195.Invoke_O_O__O(arg_1196, arg_1197) } else { ms__5 = linked_1194.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1193, arg_1196, arg_1197) }
							var tmp4 any; var root_1202 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = ms__5; var arg_1206 any; var root_1207 any = A_arbace_j2g_model_A_const_142.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = base__4; if linked_1208 == nil { arg_1206 = ifn_1209.Invoke_O__O(arg_1210) } else { arg_1206 = linked_1208.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_1207, arg_1210) }; if linked_1203 == nil { tmp4 = ifn_1204.Invoke_O_O__O(arg_1205, arg_1206) } else { tmp4 = linked_1203.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1202, arg_1205, arg_1206) }; if jrt.J2g_Truth(tmp4) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_154, c__1, A_arbace_j2g_model_A_const_175, m__3)) } else { var tmp5 any; var root_1211 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1213 lang.IFn
								if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = ms__5; var arg_1215 any = base__4; if linked_1212 == nil { tmp5 = ifn_1213.Invoke_O_O__O(arg_1214, arg_1215) } else { tmp5 = linked_1212.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1211, arg_1214, arg_1215) }
//line :476:1
								if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_177, A_arbace_j2g_model_A_const_154, c__1, A_arbace_j2g_model_A_const_175, m__3)) } else { if A_arbace_j2g_model_A_const_63 != nil { return nil } else { return nil } } } } else {
//line :471:1
									if A_arbace_j2g_model_A_const_63 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_178, A_arbace_j2g_model_A_const_154, c__1, A_arbace_j2g_model_A_const_175, m__3)) } else { return nil } } } } else {
//line :469:1
										return nil } } else {
//line :468:1
											return nil } }













func A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A{}; t.Ctor_O_O(p0, p1); return t }
//line :482:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :482:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A) Invoke_O_O__O(self, s__1479000133__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1405 any = A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_New_O_O_O_O(t.F_name, t.F_desc, s__1479000133__1, self); var tmp2 *jrt.Class; var fncls__1404 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_fn_class; if fncls__1404 == nil { var fncls__1404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__1405); A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_fn_class = fncls__1404d; tmp2 = fncls__1404d } else { tmp2 = fncls__1404 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1405, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :482:1
func A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :482:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A) Ctor_O_O_O_O(c__name, c__desc, c__s__1479000133, c__iter__1479000132 any) { t.F_name = c__name; t.F_desc = c__desc; t.F_s__1479000133 = c__s__1479000133; t.F_iter__1479000132 = c__iter__1479000132 }
//line :482:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A) Invoke_O__O(self any) any { { var s__1479000133__1 any; var t_ any = t.F_s__1479000133; t.F_s__1479000133 = nil; s__1479000133__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1222 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = s__1479000133__1; if linked_1223 == nil { temp__1927000414__auto____2 = ifn_1224.Invoke_O__O(arg_1225) } else { temp__1927000414__auto____2 = linked_1223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1222, arg_1225) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1226 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = s__1479000133__3; if linked_1227 == nil { tmp1 = ifn_1228.Invoke_O__O(arg_1229) } else { tmp1 = linked_1227.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1226, arg_1229) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1230 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = s__1479000133__3; if linked_1231 == nil { c__1927001037__auto____4 = ifn_1232.Invoke_O__O(arg_1233) } else { c__1927001037__auto____4 = linked_1231.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1230, arg_1233) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000135__6 any; var root_1234 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1235 == nil { b__1479000135__6 = ifn_1236.Invoke_O__O(arg_1237) } else { b__1479000135__6 = linked_1235.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1234, arg_1237) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1300 any = A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A_New_O_O_O_I_O(b__1479000135__6, t.F_name, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1299 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A_fn_class; if fncls__1299 == nil { var fncls__1299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__1300); A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A_fn_class = fncls__1299d; tmp3 = fncls__1299d } else { tmp3 = fncls__1299 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1300, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1301 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any; var root_1306 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = b__1479000135__6; if linked_1307 == nil { arg_1304 = ifn_1308.Invoke_O__O(arg_1309) } else { arg_1304 = linked_1307.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1306, arg_1309) }; var arg_1305 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000132); var tmp5 any; var root_1310 any = A_arbace_j2g_model_A_const_157.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = s__1479000133__3; if linked_1311 == nil { tmp5 = ifn_1312.Invoke_O__O(arg_1313) } else { tmp5 = linked_1311.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1310, arg_1313) }; arg_1305 = tmp4.Invoke_O__O(tmp5); if linked_1302 == nil { return ifn_1303.Invoke_O_O__O(arg_1304, arg_1305) } else { return linked_1302.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1301, arg_1304, arg_1305) } } else { var root_1314 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any; var root_1319 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = b__1479000135__6; if linked_1320 == nil { arg_1317 = ifn_1321.Invoke_O__O(arg_1322) } else { arg_1317 = linked_1320.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1319, arg_1322) }; var arg_1318 any; if linked_1315 == nil { return ifn_1316.Invoke_O_O__O(arg_1317, arg_1318) } else { return linked_1315.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1314, arg_1317, arg_1318) } } } else { var c__4 any; var root_1323 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = s__1479000133__3; if linked_1324 == nil { c__4 = ifn_1325.Invoke_O__O(arg_1326) } else { c__4 = linked_1324.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1323, arg_1326) }; var tmp6 any; var root_1327 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1329 lang.IFn
														if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = c__4; if linked_1328 == nil { tmp6 = ifn_1329.Invoke_O__O(arg_1330) } else { tmp6 = linked_1328.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1327, arg_1330) }
//line :482:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_1331 any = A_arbace_j2g_model_A_const_171.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1333 lang.IFn

		if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = c__4; var arg_1335 any = t.F_name; var arg_1336 any = t.F_desc; if linked_1332 == nil { m__5 = ifn_1333.Invoke_O_O_O__O(arg_1334, arg_1335, arg_1336) } else { m__5 = linked_1332.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1331, arg_1334, arg_1335, arg_1336) }
//line :482:1
		var tmp7 any
		var and__1927000168__auto____6 any = m__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1337 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any; var root_1341 any = A_arbace_j2g_model_A_const_172.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = m__5; if linked_1342 == nil { arg_1340 = ifn_1343.Invoke_O__O(arg_1344) } else { arg_1340 = linked_1342.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1341, arg_1344) }; if linked_1338 == nil { and__1927000168__auto____7 = ifn_1339.Invoke_O__O(arg_1340) } else { and__1927000168__auto____7 = linked_1338.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1337, arg_1340) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1345 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any; var root_1349 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = m__5; if linked_1350 == nil { arg_1348 = ifn_1351.Invoke_O__O(arg_1352) } else { arg_1348 = linked_1350.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1349, arg_1352) }; if linked_1346 == nil { and__1927000168__auto____8 = ifn_1347.Invoke_O__O(arg_1348) } else { and__1927000168__auto____8 = linked_1346.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1345, arg_1348) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1353 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var root_1357 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = m__5; if linked_1358 == nil { arg_1356 = ifn_1359.Invoke_O__O(arg_1360) } else { arg_1356 = linked_1358.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1357, arg_1360) }; if linked_1354 == nil { tmp7 = ifn_1355.Invoke_O__O(arg_1356) } else { tmp7 = linked_1354.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1353, arg_1356) } } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 }
//line :482:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____6 any; var root_1361 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1363 lang.IFn



			if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any; var root_1365 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = c__4; if linked_1366 == nil { arg_1364 = ifn_1367.Invoke_O__O(arg_1368) } else { arg_1364 = linked_1366.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1365, arg_1368) }; if linked_1362 == nil { or__1927000174__auto____6 = ifn_1363.Invoke_O__O(arg_1364) } else { or__1927000174__auto____6 = linked_1362.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1361, arg_1364) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp8 = or__1927000174__auto____6 } else {
				var root_1369 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_140; var tmp10 *lang.Keyword = A_arbace_j2g_model_A_const_94; var arg_1372 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O())); var arg_1373 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil); var tmp12 any; var root_1374 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = c__4; if linked_1375 == nil { tmp12 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp12 = linked_1375.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1374, arg_1377) }; var tmp13 any = tmp12; var tmp14 any; var root_1378 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = t.F_name; var arg_1382 any = t.F_desc; if linked_1379 == nil { tmp14 = ifn_1380.Invoke_O_O__O(arg_1381, arg_1382) } else { tmp14 = linked_1379.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1378, arg_1381, arg_1382) }; arg_1373 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, tmp14)).Ref(); if linked_1370 == nil { tmp8 = ifn_1371.Invoke_O_O__O(arg_1372, arg_1373) } else { tmp8 = linked_1370.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1369, arg_1372, arg_1373) } }
//line :482:1
			if jrt.J2g_Truth(tmp8) { var root_1383 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_180, A_arbace_j2g_model_A_const_154, c__4, A_arbace_j2g_model_A_const_175, m__5)); var arg_1387 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1479000132); var tmp16 any; var root_1388 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = s__1479000133__3; if linked_1389 == nil { tmp16 = ifn_1390.Invoke_O__O(arg_1391) } else { tmp16 = linked_1389.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1388, arg_1391) }; arg_1387 = tmp15.Invoke_O__O(tmp16); if linked_1384 == nil { return ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { return linked_1384.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) } } else { var tmp17 any; var root_1392 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = s__1479000133__3; if linked_1393 == nil { tmp17 = ifn_1394.Invoke_O__O(arg_1395) } else { tmp17 = linked_1393.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1392, arg_1395) }; s__1479000133__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1396 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = s__1479000133__3; if linked_1397 == nil { tmp18 = ifn_1398.Invoke_O__O(arg_1399) } else { tmp18 = linked_1397.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1396, arg_1399) }; s__1479000133__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1400 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = s__1479000133__3; if linked_1401 == nil { tmp19 = ifn_1402.Invoke_O__O(arg_1403) } else { tmp19 = linked_1401.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1400, arg_1403) }; s__1479000133__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :482:1
func A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :482:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A) Ctor_O_O_O_I_O(c__b__1479000135, c__name, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000135 = c__b__1479000135; t.F_name = c__name; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :482:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A) Invoke_O__O(self any) any { { var i__1479000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000134__1)); var tmp2 any; var root_1238 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1240 lang.IFn
																if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = c__2; if linked_1239 == nil { tmp2 = ifn_1240.Invoke_O__O(arg_1241) } else { tmp2 = linked_1239.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1238, arg_1241) }
//line :482:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_1242 any = A_arbace_j2g_model_A_const_171.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1244 lang.IFn

		if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = c__2; var arg_1246 any = t.F_name; var arg_1247 any = t.F_desc; if linked_1243 == nil { m__3 = ifn_1244.Invoke_O_O_O__O(arg_1245, arg_1246, arg_1247) } else { m__3 = linked_1243.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1242, arg_1245, arg_1246, arg_1247) }
//line :482:1
		var tmp3 any
		var and__1927000168__auto____4 any = m__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1248 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any; var root_1252 any = A_arbace_j2g_model_A_const_172.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = m__3; if linked_1253 == nil { arg_1251 = ifn_1254.Invoke_O__O(arg_1255) } else { arg_1251 = linked_1253.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1252, arg_1255) }; if linked_1249 == nil { and__1927000168__auto____5 = ifn_1250.Invoke_O__O(arg_1251) } else { and__1927000168__auto____5 = linked_1249.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1248, arg_1251) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1256 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any; var root_1260 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = m__3; if linked_1261 == nil { arg_1259 = ifn_1262.Invoke_O__O(arg_1263) } else { arg_1259 = linked_1261.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1260, arg_1263) }; if linked_1257 == nil { and__1927000168__auto____6 = ifn_1258.Invoke_O__O(arg_1259) } else { and__1927000168__auto____6 = linked_1257.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1256, arg_1259) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1264 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any; var root_1268 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = m__3; if linked_1269 == nil { arg_1267 = ifn_1270.Invoke_O__O(arg_1271) } else { arg_1267 = linked_1269.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1268, arg_1271) }; if linked_1265 == nil { tmp3 = ifn_1266.Invoke_O__O(arg_1267) } else { tmp3 = linked_1265.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1264, arg_1267) } } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :482:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____4 any; var root_1272 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1274 lang.IFn



			if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any; var root_1276 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = c__2; if linked_1277 == nil { arg_1275 = ifn_1278.Invoke_O__O(arg_1279) } else { arg_1275 = linked_1277.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1276, arg_1279) }; if linked_1273 == nil { or__1927000174__auto____4 = ifn_1274.Invoke_O__O(arg_1275) } else { or__1927000174__auto____4 = linked_1273.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1272, arg_1275) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else {
				var root_1280 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_140; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_94; var arg_1283 any = tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O())); var arg_1284 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil); var tmp8 any; var root_1285 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = c__2; if linked_1286 == nil { tmp8 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp8 = linked_1286.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1285, arg_1288) }; var tmp9 any = tmp8; var tmp10 any; var root_1289 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = t.F_name; var arg_1293 any = t.F_desc; if linked_1290 == nil { tmp10 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { tmp10 = linked_1290.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; arg_1284 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref(); if linked_1281 == nil { tmp4 = ifn_1282.Invoke_O_O__O(arg_1283, arg_1284) } else { tmp4 = linked_1281.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1280, arg_1283, arg_1284) } }
//line :482:1
			if jrt.J2g_Truth(tmp4) { var root_1294 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = t.F_b__1479000135; var arg_1298 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_180, A_arbace_j2g_model_A_const_154, c__2, A_arbace_j2g_model_A_const_175, m__3)); if linked_1295 == nil { ifn_1296.Invoke_O_O__O(arg_1297, arg_1298) } else { linked_1295.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1294, arg_1297, arg_1298) }; i__1479000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000134__1); continue L1 } else { i__1479000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000134__1); continue L1 } } else { i__1479000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000134__1); continue L1 } } else { i__1479000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000134__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_model_impl_of_fn__1479000142_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000142_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000142_A{}; t.Ctor_O(p0); return t }
//line :489:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000142_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :489:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000142_A) Invoke_O_O__O(self, x__1 any) any { var root_1413 any = A_arbace_j2g_model_A_const_71.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any; var fnbody__1429 any = A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A_New_O(x__1); var tmp1 *jrt.Class; var fncls__1428 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A_fn_class; if fncls__1428 == nil { var fncls__1428d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__1429); A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A_fn_class = fncls__1428d; tmp1 = fncls__1428d } else { tmp1 = fncls__1428 }; arg_1416 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1429, tmp1, nil); var arg_1417 any = t.F_cands; if linked_1414 == nil { return ifn_1415.Invoke_O_O__O(arg_1416, arg_1417) } else { return linked_1414.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1413, arg_1416, arg_1417) } }
//line :489:1
func A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A{}; t.Ctor_O(p0); return t }
//line :489:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :489:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A) Invoke_O_O__O(self, p1__1479000125_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1418 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = A_arbace_j2g_model_A_const_154.Invoke_O__O(p1__1479000125_SHARP___1); var arg_1422 any = A_arbace_j2g_model_A_const_154.Invoke_O__O(t.F_x); if linked_1419 == nil { and__1927000168__auto____2 = ifn_1420.Invoke_O_O__O(arg_1421, arg_1422) } else { and__1927000168__auto____2 = linked_1419.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1418, arg_1421, arg_1422) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1423 any = A_arbace_j2g_model_A_const_181.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = A_arbace_j2g_model_A_const_154.Invoke_O__O(p1__1479000125_SHARP___1); var arg_1427 any = A_arbace_j2g_model_A_const_154.Invoke_O__O(t.F_x); if linked_1424 == nil { return ifn_1425.Invoke_O_O__O(arg_1426, arg_1427) } else { return linked_1424.(*aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1423, arg_1426, arg_1427) } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_code_class_QMARK__A_New() *A_arbace_j2g_model_code_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_class_QMARK__A{}; t.Ctor(); return t }
//line :492:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Ctor() {}
//line :492:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_182; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_183; var tmp3 any; var root_1440 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = n__0; if linked_1441 == nil { tmp3 = ifn_1442.Invoke_O__O(arg_1443) } else { tmp3 = linked_1441.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1440, arg_1443) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)))).Ref()
}
func A_arbace_j2g_model_code_iface_QMARK__A_New() *A_arbace_j2g_model_code_iface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_iface_QMARK__A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Ctor() {}
//line :502:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1444 any = A_arbace_j2g_model_A_const_184.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = A_arbace_j2g_model_A_const_185; var arg_1448 any = n__0; if linked_1445 == nil { tmp1 = ifn_1446.Invoke_O_O__O(arg_1447, arg_1448) } else { tmp1 = linked_1445.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1444, arg_1447, arg_1448) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_nest_top_A_New() *A_arbace_j2g_model_nest_top_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_nest_top_A{}; t.Ctor(); return t }
//line :508:1
func (t *A_arbace_j2g_model_nest_top_A) Ctor() {}
//line :508:1
func (t *A_arbace_j2g_model_nest_top_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_57); if


	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1449 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = n__0; var arg_1453 any = A_arbace_j2g_model_A_const_34; var arg_1454 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1450 == nil { return ifn_1451.Invoke_O_O_O__O(arg_1452, arg_1453, arg_1454) } else { return linked_1450.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1449, arg_1452, arg_1453, arg_1454) } } }



func A_arbace_j2g_model_init_superinterfaces_A_New() *A_arbace_j2g_model_init_superinterfaces_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_j2g_model_init_superinterfaces_A) Ctor() {}
//line :515:1
func (t *A_arbace_j2g_model_init_superinterfaces_A) Invoke_O_O__O(self, n__0 any) any { var d__2 any; var root_1455 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1457 lang.IFn; if




	linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = n__0; if linked_1456 == nil { d__2 = ifn_1457.Invoke_O__O(arg_1458) } else { d__2 = linked_1456.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1455, arg_1458) }; var tmp1 any; var and__1927000168__auto____3 any = d__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1459 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any; var root_1463 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = A_arbace_j2g_model_A_const_49.Invoke_O__O(d__2); var arg_1467 any = A_arbace_j2g_model_A_const_186; if linked_1464 == nil { arg_1462 = ifn_1465.Invoke_O_O__O(arg_1466, arg_1467) } else { arg_1462 = linked_1464.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1463, arg_1466, arg_1467) }; if linked_1460 == nil { tmp1 = ifn_1461.Invoke_O__O(arg_1462) } else { tmp1 = linked_1460.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1459, arg_1462) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var declares_default_QMARK___3 any; var fnbody__1499 any = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_New(); var tmp2 *jrt.Class; var fncls__1498 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_fn_class
		if fncls__1498 == nil { var fncls__1498d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_fn_class = fncls__1498d; tmp2 = fncls__1498d } else { tmp2 = fncls__1498 }; declares_default_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1499, tmp2, nil)
//line :521:1
		var walk__4 any; var fnbody__1523 any = A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A_New_O(declares_default_QMARK___3); var tmp3 *jrt.Class
		var fncls__1522 /*line :521:1*/*jrt.Class = A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A_fn_class




		if fncls__1522 == nil { var fncls__1522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__1523); A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A_fn_class = fncls__1522d; tmp3 = fncls__1522d } else { tmp3 = fncls__1522 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1523, tmp3, nil)



		var root_1524 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any; var root_1528 any = A_arbace_j2g_model_A_const_187.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any; var iter__1927001039__auto____5 any; var fnbody__1613 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_New(); var tmp4 *jrt.Class; var fncls__1612 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_fn_class; if fncls__1612 == nil { var fncls__1612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_fn_class = fncls__1612d; tmp4 = fncls__1612d } else { tmp4 = fncls__1612 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1613, tmp4, nil); arg_1531 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_68.GetRawRoot__O()).Invoke_O_O__O(walk__4, A_arbace_j2g_model_A_const_56.Invoke_O__O(d__2))); if linked_1529 == nil { arg_1527 = ifn_1530.Invoke_O__O(arg_1531) } else { arg_1527 = linked_1529.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1528, arg_1531) }; if linked_1525 == nil { return ifn_1526.Invoke_O__O(arg_1527) } else { return linked_1525.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1524, arg_1527) } } else {
//line :521:1
			return nil } }
func A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_New() *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A{}; t.Ctor(); return t }
//line :522:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A) Ctor() {}
//line :522:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A) Invoke_O_O__O(self, j__1 any) any {
	var root_1468 any = A_arbace_j2g_model_A_const_71.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any; var fnbody__1493 any = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A_New(); var tmp1 *jrt.Class; var fncls__1492 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A_fn_class; if fncls__1492 == nil { var fncls__1492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A_fn_class = fncls__1492d; tmp1 = fncls__1492d } else { tmp1 = fncls__1492 }; arg_1471 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1493, tmp1, nil); var arg_1472 any; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_52; var tmp3 any; var root_1494 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1496 lang.IFn

	if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = j__1; if linked_1495 == nil { tmp3 = ifn_1496.Invoke_O__O(arg_1497) } else { tmp3 = linked_1495.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1494, arg_1497) }; arg_1472 = tmp2.Invoke_O__O(tmp3)
//line :523:1
	if linked_1469 == nil { return ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { return linked_1469.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) } }
//line :523:1
func A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A_New() *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A{}; t.Ctor(); return t }
//line :523:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A) Ctor() {}
//line :523:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A) Invoke_O_O__O(self, p1__1479000150_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1473 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = Lit_42; var arg_1477 any = A_arbace_j2g_model_A_const_128.Invoke_O__O(p1__1479000150_SHARP___1); if linked_1474 == nil { and__1927000168__auto____2 = ifn_1475.Invoke_O_O__O(arg_1476, arg_1477) } else { and__1927000168__auto____2 = linked_1474.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1473, arg_1476, arg_1477) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1478 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = Lit_43; var arg_1482 any = A_arbace_j2g_model_A_const_128.Invoke_O__O(p1__1479000150_SHARP___1); if linked_1479 == nil { and__1927000168__auto____3 = ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { and__1927000168__auto____3 = linked_1479.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
																				var root_1483 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any; var root_1487 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = A_arbace_j2g_model_A_const_49.Invoke_O__O(p1__1479000150_SHARP___1); var arg_1491 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_Or_J_J__J_NoInit(8, 1024), 2)).Ref(); if linked_1488 == nil { arg_1486 = ifn_1489.Invoke_O_O__O(arg_1490, arg_1491) } else { arg_1486 = linked_1488.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1487, arg_1490, arg_1491) }; if linked_1484 == nil { return ifn_1485.Invoke_O__O(arg_1486) } else { return linked_1484.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1483, arg_1486) } } else {
//line :523:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A_New_O(p0 any) *A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A{}; t.Ctor_O(p0); return t }
//line :526:1
func (t *A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A) Ctor_O(c__declares_default_QMARK_ any) { t.F_declares_default_QMARK_ = c__declares_default_QMARK_ }
//line :526:1
func (t *A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A) Invoke_O_O__O(self, j__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1500 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = j__1; if linked_1501 == nil { and__1927000168__auto____2 = ifn_1502.Invoke_O__O(arg_1503) } else { and__1927000168__auto____2 = linked_1501.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1500, arg_1503) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1504 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = j__1; if linked_1505 == nil { tmp1 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp1 = linked_1505.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1504, arg_1507) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_1508 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_68.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_56; var tmp4 any; var root_1518 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = j__1; if linked_1519 == nil { tmp4 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp4 = linked_1519.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1518, arg_1521) }; arg_1511 = tmp2.Invoke_O_O__O(self, tmp3.Invoke_O__O(tmp4)); var arg_1512 any
		if jrt.J2g_Truth(lang.IFn_Cast(t.F_declares_default_QMARK_).Invoke_O__O(j__1)) { arg_1512 = lang.Tuple_Create_O__IPersistentVector(j__1) } else { arg_1512 = nil }
//line :528:1
		if linked_1509 == nil { return ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { return linked_1509.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) } } else {
//line :527:1
			return nil
		}
}
func A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_New() *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A{}; t.Ctor(); return t }
//line :530:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A) Ctor() {}
//line :530:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A) Invoke_O_O__O(self, s__1479000158__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1611 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_New_O_O(self, s__1479000158__1); var tmp2 *jrt.Class; var fncls__1610 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_fn_class; if fncls__1610 == nil { var fncls__1610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__1611); A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_fn_class = fncls__1610d; tmp2 = fncls__1610d } else { tmp2 = fncls__1610 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1611, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :530:1
func A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :530:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A) Ctor_O_O(c__iter__1479000157, c__s__1479000158 any) { t.F_iter__1479000157 = c__iter__1479000157; t.F_s__1479000158 = c__s__1479000158 }
//line :530:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A) Invoke_O__O(self any) any { { var s__1479000158__1 any; var t_ any = t.F_s__1479000158; t.F_s__1479000158 = nil; s__1479000158__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1532 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = s__1479000158__1; if linked_1533 == nil { temp__1927000414__auto____2 = ifn_1534.Invoke_O__O(arg_1535) } else { temp__1927000414__auto____2 = linked_1533.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1532, arg_1535) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000158__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1536 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = s__1479000158__3; if linked_1537 == nil { tmp1 = ifn_1538.Invoke_O__O(arg_1539) } else { tmp1 = linked_1537.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1536, arg_1539) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1540 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = s__1479000158__3; if linked_1541 == nil { c__1927001037__auto____4 = ifn_1542.Invoke_O__O(arg_1543) } else { c__1927001037__auto____4 = linked_1541.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1540, arg_1543) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000160__6 any; var root_1544 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1545 == nil { b__1479000160__6 = ifn_1546.Invoke_O__O(arg_1547) } else { b__1479000160__6 = linked_1545.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1544, arg_1547) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1562 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A_New_O_I_O(b__1479000160__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1561 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A_fn_class; if fncls__1561 == nil { var fncls__1561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__1562); A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A_fn_class = fncls__1561d; tmp3 = fncls__1561d } else { tmp3 = fncls__1561 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1562, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1563 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any; var root_1568 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = b__1479000160__6; if linked_1569 == nil { arg_1566 = ifn_1570.Invoke_O__O(arg_1571) } else { arg_1566 = linked_1569.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1568, arg_1571) }; var arg_1567 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000157); var tmp5 any; var root_1572 any = A_arbace_j2g_model_A_const_157.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = s__1479000158__3; if linked_1573 == nil { tmp5 = ifn_1574.Invoke_O__O(arg_1575) } else { tmp5 = linked_1573.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1572, arg_1575) }; arg_1567 = tmp4.Invoke_O__O(tmp5); if linked_1564 == nil { return ifn_1565.Invoke_O_O__O(arg_1566, arg_1567) } else { return linked_1564.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1563, arg_1566, arg_1567) } } else { var root_1576 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any; var root_1581 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = b__1479000160__6; if linked_1582 == nil { arg_1579 = ifn_1583.Invoke_O__O(arg_1584) } else { arg_1579 = linked_1582.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1581, arg_1584) }; var arg_1580 any; if linked_1577 == nil { return ifn_1578.Invoke_O_O__O(arg_1579, arg_1580) } else { return linked_1577.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1576, arg_1579, arg_1580) } } } else { var j__4 any; var root_1585 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = s__1479000158__3; if linked_1586 == nil { j__4 = ifn_1587.Invoke_O__O(arg_1588) } else { j__4 = linked_1586.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1585, arg_1588) }; var tmp6 any; var root_1589 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1591 lang.IFn
																if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any; var root_1593 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = j__4; if linked_1594 == nil { arg_1592 = ifn_1595.Invoke_O__O(arg_1596) } else { arg_1592 = linked_1594.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1593, arg_1596) }; if linked_1590 == nil { tmp6 = ifn_1591.Invoke_O__O(arg_1592) } else { tmp6 = linked_1590.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1589, arg_1592) }
//line :530:1
	if jrt.J2g_Truth(tmp6) { var root_1597 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = j__4; var arg_1601 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1479000157); var tmp8 any; var root_1602 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = s__1479000158__3; if linked_1603 == nil { tmp8 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp8 = linked_1603.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1602, arg_1605) }; arg_1601 = tmp7.Invoke_O__O(tmp8); if linked_1598 == nil { return ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { return linked_1598.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) } } else { var tmp9 any; var root_1606 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = s__1479000158__3; if linked_1607 == nil { tmp9 = ifn_1608.Invoke_O__O(arg_1609) } else { tmp9 = linked_1607.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1606, arg_1609) }; s__1479000158__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :530:1
func A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :530:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A) Ctor_O_I_O(c__b__1479000160 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000160 = c__b__1479000160; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :530:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A) Invoke_O__O(self any) any { { var i__1479000159__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000159__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000159__1)); var tmp2 any; var root_1548 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1550 lang.IFn
																		if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any; var root_1552 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = j__2; if linked_1553 == nil { arg_1551 = ifn_1554.Invoke_O__O(arg_1555) } else { arg_1551 = linked_1553.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1552, arg_1555) }; if linked_1549 == nil { tmp2 = ifn_1550.Invoke_O__O(arg_1551) } else { tmp2 = linked_1549.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1548, arg_1551) }
//line :530:1
	if jrt.J2g_Truth(tmp2) { var root_1556 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = t.F_b__1479000160; var arg_1560 any = j__2; if linked_1557 == nil { ifn_1558.Invoke_O_O__O(arg_1559, arg_1560) } else { linked_1557.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1556, arg_1559, arg_1560) }; i__1479000159__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000159__1); continue L1 } else { i__1479000159__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000159__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_trivial_init_QMARK__A_New() *A_arbace_j2g_model_trivial_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :534:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Ctor() {}
//line :534:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_189; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()); var tmp2 any; var root_1619 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1621 lang.IFn; if





	linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any; var root_1624 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = cache__2; if linked_1625 == nil { arg_1622 = ifn_1626.Invoke_O__O(arg_1627) } else { arg_1622 = linked_1625.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1624, arg_1627) }; var arg_1623 any = n__0; if linked_1620 == nil { tmp2 = ifn_1621.Invoke_O_O__O(arg_1622, arg_1623) } else { tmp2 = linked_1620.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1619, arg_1622, arg_1623) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1628 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = cache__2; if linked_1629 == nil { tmp3 = ifn_1630.Invoke_O__O(arg_1631) } else { tmp3 = linked_1629.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1628, arg_1631) }; return lang.RT_Get_O_O__O_NoInit(tmp3, n__0) } else {
//line :540:1
			var r__3 any; var tmp4 any; var root_1632 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1634 lang.IFn


			if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any; var root_1636 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = n__0; if linked_1637 == nil { arg_1635 = ifn_1638.Invoke_O__O(arg_1639) } else { arg_1635 = linked_1637.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1636, arg_1639) }; if linked_1633 == nil { tmp4 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp4 = linked_1633.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1632, arg_1635) }
//line :542:1
			if jrt.J2g_Truth(tmp4) { r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1640 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1642 lang.IFn

				if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = n__0; if linked_1641 == nil { tmp5 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp5 = linked_1641.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1640, arg_1643) }
//line :542:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__3 = jrt.Boolean_TRUE.Ref() } else { if A_arbace_j2g_model_A_const_63 != nil { var d__3 any; var root_1644 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1646 lang.IFn


					if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = n__0; if linked_1645 == nil { d__3 = ifn_1646.Invoke_O__O(arg_1647) } else { d__3 = linked_1645.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1644, arg_1647) }
//line :542:1
					var st__4 any; var root_1648 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1650 lang.IFn


					if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = A_arbace_j2g_model_A_const_190.Invoke_O__O(d__3); if linked_1649 == nil { st__4 = ifn_1650.Invoke_O__O(arg_1651) } else { st__4 = linked_1649.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1648, arg_1651) }
//line :542:1
					var and__1927000168__auto____5 any; var root_1652 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1654 lang.IFn




					if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = A_arbace_j2g_model_A_const_191.Invoke_O__O(st__4); if linked_1653 == nil { and__1927000168__auto____5 = ifn_1654.Invoke_O__O(arg_1655) } else { and__1927000168__auto____5 = linked_1653.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1652, arg_1655) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1656 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1658 lang.IFn
						if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = A_arbace_j2g_model_A_const_192.Invoke_O__O(st__4); if linked_1657 == nil { and__1927000168__auto____6 = ifn_1658.Invoke_O__O(arg_1659) } else { and__1927000168__auto____6 = linked_1657.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1656, arg_1659) }
//line :547:1
						if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1660 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1662 lang.IFn

							if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = A_arbace_j2g_model_A_const_193.Invoke_O__O(st__4); if linked_1661 == nil { and__1927000168__auto____7 = ifn_1662.Invoke_O__O(arg_1663) } else { and__1927000168__auto____7 = linked_1661.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1660, arg_1663) }
//line :547:1
							if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1664 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1666 lang.IFn


								if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = A_arbace_j2g_model_A_const_194.Invoke_O__O(st__4); if linked_1665 == nil { and__1927000168__auto____8 = ifn_1666.Invoke_O__O(arg_1667) } else { and__1927000168__auto____8 = linked_1665.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1664, arg_1667) }
//line :547:1
								if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_83.Invoke_O__O(d__3), nil)



									if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1668 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = A_arbace_j2g_model_A_const_83.Invoke_O__O(d__3); if linked_1669 == nil { and__1927000168__auto____9 = ifn_1670.Invoke_O__O(arg_1671) } else { and__1927000168__auto____9 = linked_1669.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1668, arg_1671) } }
//line :547:1
									if jrt.J2g_Truth(and__1927000168__auto____9) {




										var root_1672 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any; var root_1676 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, A_arbace_j2g_model_init_superinterfaces_A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = n__0; if linked_1677 == nil { arg_1675 = ifn_1678.Invoke_O__O(arg_1679) } else { arg_1675 = linked_1677.(*A_arbace_j2g_model_init_superinterfaces_A).Invoke_O_O__O(root_1676, arg_1679) }; if linked_1673 == nil { r__3 = ifn_1674.Invoke_O__O(arg_1675) } else { r__3 = linked_1673.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1672, arg_1675) } } else {
//line :547:1
											r__3 = and__1927000168__auto____9 } } else { r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :542:1
												r__3 = nil
											}
				}
			}







			var root_1680 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = cache__2; var arg_1684 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var arg_1685 any = n__0; var arg_1686 any = r__3; if linked_1681 == nil { ifn_1682.Invoke_O_O_O_O__O(arg_1683, arg_1684, arg_1685, arg_1686) } else { linked_1681.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1680, arg_1683, arg_1684, arg_1685, arg_1686) }
//line :540:1
			return r__3 } }


















func A_arbace_j2g_model_go_qualified_name_A_New() *A_arbace_j2g_model_go_qualified_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_qualified_name_A{}; t.Ctor(); return t }
//line :559:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Ctor() {}
//line :559:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_1687 any = A_arbace_j2g_model_A_const_196.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any; var root_1691 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, A_arbace_j2g_model_pkg_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = n__0; if linked_1692 == nil { arg_1690 = ifn_1693.Invoke_O__O(arg_1694) } else { arg_1690 = linked_1692.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_1691, arg_1694) }; if linked_1688 == nil { tmp2 = ifn_1689.Invoke_O__O(arg_1690) } else { tmp2 = linked_1688.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A).Invoke_O_O__O(root_1687, arg_1690) }; var tmp3 any = tmp2; var tmp4 any; var root_1695 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = n__0; if linked_1696 == nil { tmp4 = ifn_1697.Invoke_O__O(arg_1698) } else { tmp4 = linked_1696.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1695, arg_1698) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
}




func A_arbace_j2g_model_start_class_QMARK__A_New() *A_arbace_j2g_model_start_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_class_QMARK__A{}; t.Ctor(); return t }
//line :569:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Ctor() {}
//line :569:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_1699 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); if linked_1700 == nil { and__1927000168__auto____2 = ifn_1701.Invoke_O__O(arg_1702) } else { and__1927000168__auto____2 = linked_1700.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1699, arg_1702) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1703 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = n__0; if linked_1704 == nil { and__1927000168__auto____3 = ifn_1705.Invoke_O__O(arg_1706) } else { and__1927000168__auto____3 = linked_1704.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1703, arg_1706) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1707 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var arg_1711 any; var root_1712 any = A_arbace_j2g_model_A_const_198.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = n__0; if linked_1713 == nil { arg_1711 = ifn_1714.Invoke_O__O(arg_1715) } else { arg_1711 = linked_1713.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1712, arg_1715) }; if linked_1708 == nil { and__1927000168__auto____4 = ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { and__1927000168__auto____4 = linked_1708.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1716 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any; var root_1720 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = n__0; if linked_1721 == nil { arg_1719 = ifn_1722.Invoke_O__O(arg_1723) } else { arg_1719 = linked_1721.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1720, arg_1723) }; if linked_1717 == nil { tmp1 = ifn_1718.Invoke_O__O(arg_1719) } else { tmp1 = linked_1717.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1716, arg_1719) } } else {
//line :573:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_j2g_model_start_classes_A_New() *A_arbace_j2g_model_start_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_j2g_model_start_classes_A) Ctor() {}
//line :576:1
func (t *A_arbace_j2g_model_start_classes_A) Invoke_O__O(self any) any { var by_go__1 any; var root_1724 any = A_arbace_j2g_model_A_const_199.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1726 lang.IFn; if


	linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1728 any; var iter__1927001039__auto____1 any; var fnbody__1810 any = A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_New(); var tmp1 *jrt.Class; var fncls__1809 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_fn_class; if fncls__1809 == nil { var fncls__1809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, nil); A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_fn_class = fncls__1809d; tmp1 = fncls__1809d } else { tmp1 = fncls__1809 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1810, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp3 any; var root_1811 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, A_arbace_j2g_model_T_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; if linked_1812 == nil { tmp3 = ifn_1813.Invoke__O() } else { tmp3 = linked_1812.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_1811) }; arg_1728 = tmp2.Invoke_O__O(tmp3); if linked_1725 == nil { by_go__1 = ifn_1726.Invoke_O_O__O(arg_1727, arg_1728) } else { by_go__1 = linked_1725.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1724, arg_1727, arg_1728) }; var root_1814 any =
	A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = by_go__1; var arg_1818 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); if linked_1815 == nil { return ifn_1816.Invoke_O_O__O(arg_1817, arg_1818) } else { return linked_1815.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1814, arg_1817, arg_1818) } }
//line :579:1
func A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_New() *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A{}; t.Ctor(); return t }
//line :579:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A) Ctor() {}
//line :579:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A) Invoke_O_O__O(self, s__1479000172__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1808 any = A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_New_O_O(s__1479000172__1, self); var tmp2 *jrt.Class; var fncls__1807 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_fn_class; if fncls__1807 == nil { var fncls__1807d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__1808); A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_fn_class = fncls__1807d; tmp2 = fncls__1807d } else { tmp2 = fncls__1807 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1808, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :579:1
func A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :579:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A) Ctor_O_O(c__s__1479000172, c__iter__1479000171 any) { t.F_s__1479000172 = c__s__1479000172; t.F_iter__1479000171 = c__iter__1479000171 }
//line :579:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A) Invoke_O__O(self any) any { { var s__1479000172__1 any; var t_ any = t.F_s__1479000172; t.F_s__1479000172 = nil; s__1479000172__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1729 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = s__1479000172__1; if linked_1730 == nil { temp__1927000414__auto____2 = ifn_1731.Invoke_O__O(arg_1732) } else { temp__1927000414__auto____2 = linked_1730.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1729, arg_1732) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000172__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1733 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = s__1479000172__3; if linked_1734 == nil { tmp1 = ifn_1735.Invoke_O__O(arg_1736) } else { tmp1 = linked_1734.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1733, arg_1736) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1737 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = s__1479000172__3; if linked_1738 == nil { c__1927001037__auto____4 = ifn_1739.Invoke_O__O(arg_1740) } else { c__1927001037__auto____4 = linked_1738.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1737, arg_1740) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000174__6 any; var root_1741 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1742 == nil { b__1479000174__6 = ifn_1743.Invoke_O__O(arg_1744) } else { b__1479000174__6 = linked_1742.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1741, arg_1744) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1759 any = A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1479000174__6); var tmp3 *jrt.Class; var fncls__1758 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A_fn_class; if fncls__1758 == nil { var fncls__1758d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__1759); A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A_fn_class = fncls__1758d; tmp3 = fncls__1758d } else { tmp3 = fncls__1758 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1759, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1760 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any; var root_1765 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = b__1479000174__6; if linked_1766 == nil { arg_1763 = ifn_1767.Invoke_O__O(arg_1768) } else { arg_1763 = linked_1766.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1765, arg_1768) }; var arg_1764 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000171); var tmp5 any; var root_1769 any = A_arbace_j2g_model_A_const_157.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = s__1479000172__3; if linked_1770 == nil { tmp5 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp5 = linked_1770.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1769, arg_1772) }; arg_1764 = tmp4.Invoke_O__O(tmp5); if linked_1761 == nil { return ifn_1762.Invoke_O_O__O(arg_1763, arg_1764) } else { return linked_1761.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1760, arg_1763, arg_1764) } } else { var root_1773 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any; var root_1778 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = b__1479000174__6; if linked_1779 == nil { arg_1776 = ifn_1780.Invoke_O__O(arg_1781) } else { arg_1776 = linked_1779.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1778, arg_1781) }; var arg_1777 any; if linked_1774 == nil { return ifn_1775.Invoke_O_O__O(arg_1776, arg_1777) } else { return linked_1774.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1773, arg_1776, arg_1777) } } } else { var n__4 any; var root_1782 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = s__1479000172__3; if linked_1783 == nil { n__4 = ifn_1784.Invoke_O__O(arg_1785) } else { n__4 = linked_1783.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1782, arg_1785) }; var tmp6 any; var root_1786 any = A_arbace_j2g_model_A_const_200.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = n__4; if linked_1787 == nil { tmp6 = ifn_1788.Invoke_O__O(arg_1789) } else { tmp6 = linked_1787.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1786, arg_1789) }; if jrt.J2g_Truth(tmp6) { var root_1790 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any; var tmp7 any; var root_1795 any = A_arbace_j2g_model_A_const_198.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = n__4; if linked_1796 == nil { tmp7 = ifn_1797.Invoke_O__O(arg_1798) } else { tmp7 = linked_1796.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1795, arg_1798) }; arg_1793 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, n__4); var arg_1794 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000171); var tmp9 any; var root_1799 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = s__1479000172__3; if linked_1800 == nil { tmp9 = ifn_1801.Invoke_O__O(arg_1802) } else { tmp9 = linked_1800.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1799, arg_1802) }; arg_1794 = tmp8.Invoke_O__O(tmp9); if linked_1791 == nil { return ifn_1792.Invoke_O_O__O(arg_1793, arg_1794) } else { return linked_1791.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1790, arg_1793, arg_1794) } } else { var tmp10 any; var root_1803 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = s__1479000172__3; if linked_1804 == nil { tmp10 = ifn_1805.Invoke_O__O(arg_1806) } else { tmp10 = linked_1804.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1803, arg_1806) }; s__1479000172__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :579:1
func A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :579:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1479000174 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1479000174 = c__b__1479000174 }
//line :579:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A) Invoke_O__O(self any) any { { var i__1479000173__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000173__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000173__1)); var tmp2 any; var root_1745 any = A_arbace_j2g_model_A_const_200.GetRawRoot__O(); var linked_1746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1745, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1747 lang.IFn; if linked_1746 == nil { ifn_1747 = lang.IFn_Cast(root_1745) } else { ifn_1747 = nil }; var arg_1748 any = n__2; if linked_1746 == nil { tmp2 = ifn_1747.Invoke_O__O(arg_1748) } else { tmp2 = linked_1746.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1745, arg_1748) }; if jrt.J2g_Truth(tmp2) { var root_1749 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = t.F_b__1479000174; var arg_1753 any; var tmp3 any; var root_1754 any = A_arbace_j2g_model_A_const_198.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = n__2; if linked_1755 == nil { tmp3 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp3 = linked_1755.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1754, arg_1757) }; arg_1753 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, n__2); if linked_1750 == nil { ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { linked_1750.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) }; i__1479000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000173__1); continue L1 } else { i__1479000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000173__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_model_top_class_A_New() *A_arbace_j2g_model_top_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_top_class_A{}; t.Ctor(); return t }
//line :587:1
func (t *A_arbace_j2g_model_top_class_A) Ctor() {}
//line :587:1
func (t *A_arbace_j2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_57); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1819 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = n__0; var arg_1823 any = A_arbace_j2g_model_A_const_34; var arg_1824 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1820 == nil { return ifn_1821.Invoke_O_O_O__O(arg_1822, arg_1823, arg_1824) } else { return linked_1820.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1819, arg_1822, arg_1823, arg_1824) } } }

func A_arbace_j2g_model_pure_ctor_QMARK__A_New() *A_arbace_j2g_model_pure_ctor_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :589:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :589:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any; var root_1825 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1827 lang.IFn; if




	linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = c__1; if linked_1826 == nil { d__5 = ifn_1827.Invoke_O__O(arg_1828) } else { d__5 = linked_1826.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1825, arg_1828) }; var ab__6 any; if
	jrt.J2g_Truth(d__5) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_203; var tmp2 any; var root_1829 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = A_arbace_j2g_model_A_const_190.Invoke_O__O(d__5); if linked_1830 == nil { tmp2 = ifn_1831.Invoke_O__O(arg_1832) } else { tmp2 = linked_1830.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1829, arg_1832) }; ab__6 = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), lang.Tuple_Create_O_O__IPersistentVector(Lit_43, A_arbace_j2g_model_A_const_118.Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_1833 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = c__1; if linked_1834 == nil { and__1927000168__auto____9 = ifn_1835.Invoke_O__O(arg_1836) } else { and__1927000168__auto____9 = linked_1834.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1833, arg_1836) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp3 any; var root_1837 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1839 lang.IFn
		if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = c__1; if linked_1838 == nil { tmp3 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp3 = linked_1838.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1837, arg_1840) }; var tmp4 any = tmp3; var tmp5 any; var root_1841 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = n__0; if linked_1842 == nil { tmp5 = ifn_1843.Invoke_O__O(arg_1844) } else { tmp5 = linked_1842.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1841, arg_1844) }; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)
//line :596:1
		if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_1845 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1847 lang.IFn

			if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any; var root_1849 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = seen__3; var arg_1853 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_118.Invoke_O__O(m__2)); if linked_1850 == nil { arg_1848 = ifn_1851.Invoke_O_O__O(arg_1852, arg_1853) } else { arg_1848 = linked_1850.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1849, arg_1852, arg_1853) }; if linked_1846 == nil { and__1927000168__auto____11 = ifn_1847.Invoke_O__O(arg_1848) } else { and__1927000168__auto____11 = linked_1846.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1845, arg_1848) }
//line :596:1
			if jrt.J2g_Truth(and__1927000168__auto____11) { var seen__12 any; var root_1854 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1856 lang.IFn


				if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = seen__3; var arg_1858 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_118.Invoke_O__O(m__2)); if linked_1855 == nil { seen__12 = ifn_1856.Invoke_O_O__O(arg_1857, arg_1858) } else { seen__12 = linked_1855.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1854, arg_1857, arg_1858) }
//line :596:1
				var call__13 any = A_arbace_j2g_model_A_const_205.Invoke_O__O(ab__6); var sup__14 any = A_arbace_j2g_model_A_const_83.Invoke_O__O(d__5); var and__1927000168__auto____15 any; var root_1859 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_1860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1859, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1861 lang.IFn





				if linked_1860 == nil { ifn_1861 = lang.IFn_Cast(root_1859) } else { ifn_1861 = nil }; var arg_1862 any = A_arbace_j2g_model_A_const_206.Invoke_O__O(ab__6); if linked_1860 == nil { and__1927000168__auto____15 = ifn_1861.Invoke_O__O(arg_1862) } else { and__1927000168__auto____15 = linked_1860.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1859, arg_1862) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1863 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1865 lang.IFn
					if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = A_arbace_j2g_model_A_const_207.Invoke_O__O(ab__6); if linked_1864 == nil { and__1927000168__auto____16 = ifn_1865.Invoke_O__O(arg_1866) } else { and__1927000168__auto____16 = linked_1864.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1863, arg_1866) }
//line :602:1
					if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z_NoInit(call__13, nil)

						if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var root_1867 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1869 lang.IFn
							if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any; var fnbody__1879 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A_New_O_O(n__0, seen__12); var tmp6 *jrt.Class; var fncls__1878 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A_fn_class; if fncls__1878 == nil { var fncls__1878d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__1879); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A_fn_class = fncls__1878d; tmp6 = fncls__1878d } else { tmp6 = fncls__1878 }; arg_1870 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1879, tmp6, nil); var arg_1871 any = A_arbace_j2g_model_A_const_209.Invoke_O__O(call__13); if linked_1868 == nil { and__1927000168__auto____18 = ifn_1869.Invoke_O_O__O(arg_1870, arg_1871) } else { and__1927000168__auto____18 = linked_1868.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1867, arg_1870, arg_1871) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_178.Invoke_O__O(call__13), nil)
								if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19).Ref() } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_210); var or__1927000174__auto____20 any = tmp7.Invoke_O__O(A_arbace_j2g_model_A_const_178.Invoke_O__O(call__13)); if jrt.J2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
									var root_1880 any = A_arbace_j2g_model_A_const_211.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = n__0; var arg_1884 any = A_arbace_j2g_model_A_const_178.Invoke_O__O(call__13); var arg_1885 any = A_arbace_j2g_model_A_const_212.Invoke_O__O(call__13); var arg_1886 any = seen__12; if linked_1881 == nil { and__1927000168__auto____17 = ifn_1882.Invoke_O_O_O_O__O(arg_1883, arg_1884, arg_1885, arg_1886) } else { and__1927000168__auto____17 = linked_1881.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1880, arg_1883, arg_1884, arg_1885, arg_1886) } } } } else {
//line :605:1
										and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :602:1
						if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any; var root_1887 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1889 lang.IFn





							if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = call__13; if linked_1888 == nil { or__1927000174__auto____18 = ifn_1889.Invoke_O__O(arg_1890) } else { or__1927000174__auto____18 = linked_1888.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1887, arg_1890) }; if jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z_NoInit(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sup__14, Lit_30)).Ref() } }
//line :602:1
							if jrt.J2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var root_1891 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1893 lang.IFn






								if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any; var fnbody__1903 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A_New_O_O(n__0, seen__12); var tmp8 *jrt.Class; var fncls__1902 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A_fn_class; if fncls__1902 == nil { var fncls__1902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__1903); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A_fn_class = fncls__1902d; tmp8 = fncls__1902d } else { tmp8 = fncls__1902 }; arg_1894 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1903, tmp8, nil); var arg_1895 any; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_213; var tmp10 any; var root_1904 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = A_arbace_j2g_model_A_const_190.Invoke_O__O(d__5); if linked_1905 == nil { tmp10 = ifn_1906.Invoke_O__O(arg_1907) } else { tmp10 = linked_1905.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1904, arg_1907) }; arg_1895 = tmp9.Invoke_O__O(tmp10); if linked_1892 == nil { and__1927000168__auto____19 = ifn_1893.Invoke_O_O__O(arg_1894, arg_1895) } else { and__1927000168__auto____19 = linked_1892.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1891, arg_1894, arg_1895) }
//line :602:1
								if jrt.J2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_214.Invoke_O__O(ab__6), nil)







									if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20_2).Ref() } else { var root_1908 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1910 lang.IFn; if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any = n__0; var arg_1912 any = A_arbace_j2g_model_A_const_214.Invoke_O__O(ab__6); var arg_1913 any = seen__12; if linked_1909 == nil { return ifn_1910.Invoke_O_O_O__O(arg_1911, arg_1912, arg_1913) } else { return linked_1909.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1908, arg_1911, arg_1912, arg_1913) } } } else {
//line :602:1
										return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :596:1
											return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A{}; t.Ctor_O_O(p0, p1); return t }
//line :605:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :605:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A) Invoke_O_O__O(self, p1__1479000183_SHARP___1 any) any { var root_1872 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = t.F_n; var arg_1876 any = p1__1479000183_SHARP___1; var arg_1877 any = t.F_seen; if linked_1873 == nil { return ifn_1874.Invoke_O_O_O__O(arg_1875, arg_1876, arg_1877) } else { return linked_1873.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1872, arg_1875, arg_1876, arg_1877) } }



func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A{}; t.Ctor_O_O(p0, p1); return t }
//line :609:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :609:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A) Invoke_O_O__O(self, p1__1479000184_SHARP___1 any) any { var root_1896 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = t.F_n; var arg_1900 any = p1__1479000184_SHARP___1; var arg_1901 any = t.F_seen; if linked_1897 == nil { return ifn_1898.Invoke_O_O_O__O(arg_1899, arg_1900, arg_1901) } else { return linked_1897.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1896, arg_1899, arg_1900, arg_1901) } }


func A_arbace_j2g_model_pure_node_QMARK__A_New() *A_arbace_j2g_model_pure_node_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :612:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Ctor() {}
//line :612:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1479000196__4_ any = A_arbace_j2g_model_A_const_215.Invoke_O__O(node__1); switch



	lang.Util_Hash_O__I_NoInit(G__1479000196__4_) >> 3 & 63 { case 1: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_216) { var and__1927000168__auto____5 any; var root_1915 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1917 lang.IFn


















		if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = A_arbace_j2g_model_A_const_217.Invoke_O__O(node__1); if linked_1916 == nil { and__1927000168__auto____5 = ifn_1917.Invoke_O__O(arg_1918) } else { and__1927000168__auto____5 = linked_1916.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1915, arg_1918) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1919 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = A_arbace_j2g_model_A_const_218.Invoke_O__O(node__1); if linked_1920 == nil { and__1927000168__auto____6 = ifn_1921.Invoke_O__O(arg_1922) } else { and__1927000168__auto____6 = linked_1920.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1919, arg_1922) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1923 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = n__0; var arg_1927 any = A_arbace_j2g_model_A_const_219.Invoke_O__O(node__1); var arg_1928 any = seen__2; if linked_1924 == nil { return ifn_1925.Invoke_O_O_O__O(arg_1926, arg_1927, arg_1928) } else { return linked_1924.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1923, arg_1926, arg_1927, arg_1928) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :616:1
	case 11: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_220) { var tmp1 any = A_arbace_j2g_model_A_const_221; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_215; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)))







		if and__1927000168__auto____5_2 { var and__1927000168__auto____6_2 any; var root_1929 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_223; var arg_1932 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)); if linked_1930 == nil { and__1927000168__auto____6_2 = ifn_1931.Invoke_O__O(arg_1932) } else { and__1927000168__auto____6_2 = linked_1930.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1929, arg_1932) }; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var root_1933 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = n__0; var arg_1937 any = A_arbace_j2g_model_A_const_224.Invoke_O__O(node__1); var arg_1938 any = seen__2; if linked_1934 == nil { return ifn_1935.Invoke_O_O_O__O(arg_1936, arg_1937, arg_1938) } else { return linked_1934.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1933, arg_1936, arg_1937, arg_1938) } } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() } }
//line :616:1
	case 13: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_225) { var tmp4 any = A_arbace_j2g_model_A_const_226; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_j2g_model_A_const_173.Invoke_O__O(node__1))













		if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_65, A_arbace_j2g_model_A_const_154.Invoke_O__O(node__1))
			if and__1927000168__auto____6_4 { or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_66, A_arbace_j2g_model_A_const_128.Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, A_arbace_j2g_model_A_const_154.Invoke_O__O(node__1))

				if and__1927000168__auto____7 { and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_67, A_arbace_j2g_model_A_const_128.Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :630:1
			if and__1927000168__auto____6_3 {



				var root_1939 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any; var fnbody__1951 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A_New_O_O(n__0, seen__2); var tmp5 *jrt.Class; var fncls__1950 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A_fn_class; if fncls__1950 == nil { var fncls__1950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__1951); A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A_fn_class = fncls__1950d; tmp5 = fncls__1950d } else { tmp5 = fncls__1950 }; arg_1942 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1951, tmp5, nil); var arg_1943 any = A_arbace_j2g_model_A_const_209.Invoke_O__O(node__1); if linked_1940 == nil { return ifn_1941.Invoke_O_O__O(arg_1942, arg_1943) } else { return linked_1940.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1939, arg_1942, arg_1943) } } else {
//line :630:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_3).Ref() } }
//line :616:1
	case 14: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_227) { var and__1927000168__auto____5_4 bool; var tmp6 any; var tmp7 *lang.Keyword = A_arbace_j2g_model_A_const_228; var or__1927000174__auto____5 any = tmp7.Invoke_O__O(A_arbace_j2g_model_A_const_229.Invoke_O__O(node__1))






		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp6 = or__1927000174__auto____5 } else { var tmp8 *lang.Keyword = A_arbace_j2g_model_A_const_154; tmp6 = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_229.Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp6); if and__1927000168__auto____5_4 { var root_1952 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = n__0; var arg_1956 any = A_arbace_j2g_model_A_const_224.Invoke_O__O(node__1); var arg_1957 any = seen__2; if linked_1953 == nil { return ifn_1954.Invoke_O_O_O__O(arg_1955, arg_1956, arg_1957) } else { return linked_1953.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1952, arg_1955, arg_1956, arg_1957) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_4).Ref() } }
//line :616:1
	case 15: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_221) { return jrt.Boolean_TRUE.Ref() }; case 19: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_230) { var and__1927000168__auto____5_5 any; var root_1958 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1960 lang.IFn


		if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any; var fnbody__1970 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A_New_O_O(n__0, seen__2); var tmp9 *jrt.Class; var fncls__1969 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A_fn_class; if fncls__1969 == nil { var fncls__1969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__1970); A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A_fn_class = fncls__1969d; tmp9 = fncls__1969d } else { tmp9 = fncls__1969 }; arg_1961 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1970, tmp9, nil); var arg_1962 any = A_arbace_j2g_model_A_const_231.Invoke_O__O(node__1); if linked_1959 == nil { and__1927000168__auto____5_5 = ifn_1960.Invoke_O_O__O(arg_1961, arg_1962) } else { and__1927000168__auto____5_5 = linked_1959.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1958, arg_1961, arg_1962) }; if jrt.J2g_Truth(and__1927000168__auto____5_5) { var root_1971 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any = n__0; var arg_1975 any = A_arbace_j2g_model_A_const_214.Invoke_O__O(node__1); var arg_1976 any = seen__2; if linked_1972 == nil { return ifn_1973.Invoke_O_O_O__O(arg_1974, arg_1975, arg_1976) } else { return linked_1972.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1971, arg_1974, arg_1975, arg_1976) } } else { return and__1927000168__auto____5_5 } }
//line :616:1
	case 21: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_232) {





		var tmp10 any; var tmp11 *lang.Keyword = A_arbace_j2g_model_A_const_228; var or__1927000174__auto____5_2 any = tmp11.Invoke_O__O(A_arbace_j2g_model_A_const_229.Invoke_O__O(node__1)); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp10 = or__1927000174__auto____5_2 } else { var tmp12 *lang.Keyword = A_arbace_j2g_model_A_const_154; tmp10 = tmp12.Invoke_O__O(A_arbace_j2g_model_A_const_229.Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp10)).Ref() }
//line :616:1
	case 25: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_233) { var and__1927000168__auto____5_6 any; var root_1977 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_1978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1977, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1979 lang.IFn

		if linked_1978 == nil { ifn_1979 = lang.IFn_Cast(root_1977) } else { ifn_1979 = nil }; var arg_1980 any; var fnbody__1989 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_New_O_O(n__0, seen__2); var tmp13 *jrt.Class; var fncls__1988 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_fn_class; if fncls__1988 == nil { var fncls__1988d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__1989); A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_fn_class = fncls__1988d; tmp13 = fncls__1988d } else { tmp13 = fncls__1988 }; arg_1980 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1989, tmp13, nil); var arg_1981 any = A_arbace_j2g_model_A_const_234.Invoke_O__O(node__1); if linked_1978 == nil { and__1927000168__auto____5_6 = ifn_1979.Invoke_O_O__O(arg_1980, arg_1981) } else { and__1927000168__auto____5_6 = linked_1978.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1977, arg_1980, arg_1981) }; if jrt.J2g_Truth(and__1927000168__auto____5_6) { var root_1990 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = n__0; var arg_1994 any = A_arbace_j2g_model_A_const_235.Invoke_O__O(node__1); var arg_1995 any = seen__2; if linked_1991 == nil { return ifn_1992.Invoke_O_O_O__O(arg_1993, arg_1994, arg_1995) } else { return linked_1991.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1990, arg_1993, arg_1994, arg_1995) } } else { return and__1927000168__auto____5_6 } }
//line :616:1
	case 29: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_236) { return jrt.Boolean_TRUE.Ref() }; case 30: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_237) { return jrt.Boolean_TRUE.Ref() }; case 34: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_238) {




		var root_1996 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any; var fnbody__2010 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_New(); var tmp14 *jrt.Class; var fncls__2009 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_fn_class; if fncls__2009 == nil { var fncls__2009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_fn_class = fncls__2009d; tmp14 = fncls__2009d } else { tmp14 = fncls__2009 }; arg_1999 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2010, tmp14, nil); var arg_2000 any = A_arbace_j2g_model_A_const_240.Invoke_O__O(node__1); if linked_1997 == nil { return ifn_1998.Invoke_O_O__O(arg_1999, arg_2000) } else { return linked_1997.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1996, arg_1999, arg_2000) } }
//line :616:1
	case 39: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_241) { var and__1927000168__auto____5_7 any; var root_2011 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2013 lang.IFn








		if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any; var fnbody__2023 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A_New_O_O(n__0, seen__2); var tmp15 *jrt.Class; var fncls__2022 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A_fn_class; if fncls__2022 == nil { var fncls__2022d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__2023); A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A_fn_class = fncls__2022d; tmp15 = fncls__2022d } else { tmp15 = fncls__2022 }; arg_2014 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2023, tmp15, nil); var arg_2015 any = A_arbace_j2g_model_A_const_209.Invoke_O__O(node__1); if linked_2012 == nil { and__1927000168__auto____5_7 = ifn_2013.Invoke_O_O__O(arg_2014, arg_2015) } else { and__1927000168__auto____5_7 = linked_2012.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2011, arg_2014, arg_2015) }; if jrt.J2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_242.Invoke_O__O(node__1), nil); if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_30, A_arbace_j2g_model_A_const_178.Invoke_O__O(node__1))

			if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_model_A_const_178.Invoke_O__O(node__1), n__0)
				if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_2024 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = A_arbace_j2g_model_A_const_178.Invoke_O__O(node__1); if linked_2025 == nil { and__1927000168__auto____8 = ifn_2026.Invoke_O__O(arg_2027) } else { and__1927000168__auto____8 = linked_2025.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2024, arg_2027) } }; if jrt.J2g_Truth(and__1927000168__auto____8) {
					var root_2028 any = A_arbace_j2g_model_A_const_211.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = n__0; var arg_2032 any = A_arbace_j2g_model_A_const_178.Invoke_O__O(node__1); var arg_2033 any = A_arbace_j2g_model_A_const_212.Invoke_O__O(node__1); var arg_2034 any = seen__2; if linked_2029 == nil { return ifn_2030.Invoke_O_O_O_O__O(arg_2031, arg_2032, arg_2033, arg_2034) } else { return linked_2029.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_2028, arg_2031, arg_2032, arg_2033, arg_2034) } } else {
//line :628:1
						return and__1927000168__auto____8 } } } else {
//line :625:1
							return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :616:1
	case 43: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_243) { var and__1927000168__auto____5_8 any; var root_2035 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2037 lang.IFn



















		if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_244); var arg_2038 any = tmp16.Invoke_O__O(A_arbace_j2g_model_A_const_245.Invoke_O__O(node__1)); if linked_2036 == nil { and__1927000168__auto____5_8 = ifn_2037.Invoke_O__O(arg_2038) } else { and__1927000168__auto____5_8 = linked_2036.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2035, arg_2038) }; if jrt.J2g_Truth(and__1927000168__auto____5_8) { var and__1927000168__auto____6_6 any; var root_2039 any = A_arbace_j2g_model_A_const_122.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any = A_arbace_j2g_model_A_const_246; var arg_2043 any = A_arbace_j2g_model_A_const_247.Invoke_O__O(node__1); if linked_2040 == nil { and__1927000168__auto____6_6 = ifn_2041.Invoke_O_O__O(arg_2042, arg_2043) } else { and__1927000168__auto____6_6 = linked_2040.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2039, arg_2042, arg_2043) }; if jrt.J2g_Truth(and__1927000168__auto____6_6) { var root_2044 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any; var fnbody__2056 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A_New_O_O(n__0, seen__2); var tmp17 *jrt.Class; var fncls__2055 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A_fn_class; if fncls__2055 == nil { var fncls__2055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__2056); A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A_fn_class = fncls__2055d; tmp17 = fncls__2055d } else { tmp17 = fncls__2055 }; arg_2047 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2056, tmp17, nil); var arg_2048 any = A_arbace_j2g_model_A_const_209.Invoke_O__O(node__1); if linked_2045 == nil { return ifn_2046.Invoke_O_O__O(arg_2047, arg_2048) } else { return linked_2045.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2044, arg_2047, arg_2048) } } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :616:1
	case 44: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_248) { return jrt.Boolean_TRUE.Ref() }; case 46: if any(G__1479000196__4_) == any(A_arbace_j2g_model_A_const_249) {



		var root_2057 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2059 lang.IFn; if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any; var fnbody__2069 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A_New_O_O(n__0, seen__2); var tmp18 *jrt.Class; var fncls__2068 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A_fn_class; if fncls__2068 == nil { var fncls__2068d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__2069); A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A_fn_class = fncls__2068d; tmp18 = fncls__2068d } else { tmp18 = fncls__2068 }; arg_2060 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2069, tmp18, nil); var arg_2061 any = A_arbace_j2g_model_A_const_250.Invoke_O__O(node__1); if linked_2058 == nil { return ifn_2059.Invoke_O_O__O(arg_2060, arg_2061) } else { return linked_2058.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2057, arg_2060, arg_2061) } }
//line :616:1
	default:}; return jrt.Boolean_FALSE.Ref() }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A{}; t.Ctor_O_O(p0, p1); return t }
//line :618:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :618:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A) Invoke_O_O__O(self, p1__1479000190_SHARP___1 any) any { var root_1982 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = t.F_n; var arg_1986 any = p1__1479000190_SHARP___1; var arg_1987 any = t.F_seen; if linked_1983 == nil { return ifn_1984.Invoke_O_O_O__O(arg_1985, arg_1986, arg_1987) } else { return linked_1983.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1982, arg_1985, arg_1986, arg_1987) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A{}; t.Ctor_O_O(p0, p1); return t }
//line :619:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :619:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A) Invoke_O_O__O(self, p__1479000199__1 any) any { var vec__1479000201__2 any = p__1479000199__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000201__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000201__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1963 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1965 lang.IFn; _ = ___3; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = t.F_n; var arg_1967 any = init__4; var arg_1968 any = t.F_seen; if linked_1964 == nil { return ifn_1965.Invoke_O_O_O__O(arg_1966, arg_1967, arg_1968) } else { return linked_1964.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1963, arg_1966, arg_1967, arg_1968) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A{}; t.Ctor_O_O(p0, p1); return t }
//line :620:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :620:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A) Invoke_O_O__O(self, p1__1479000191_SHARP___1 any) any { var root_2062 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = t.F_n; var arg_2066 any = p1__1479000191_SHARP___1; var arg_2067 any = t.F_seen; if linked_2063 == nil { return ifn_2064.Invoke_O_O_O__O(arg_2065, arg_2066, arg_2067) } else { return linked_2063.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2062, arg_2065, arg_2066, arg_2067) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_New() *A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A{}; t.Ctor(); return t }
//line :621:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A) Ctor() {}
//line :621:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A) Invoke_O_O__O(self, p1__1479000192_SHARP___1 any) any { var tmp1 any = A_arbace_j2g_model_A_const_236; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_model_A_const_215.Invoke_O__O(p1__1479000192_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_2001 any = A_arbace_j2g_model_A_const_239.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = A_arbace_j2g_model_A_const_224.Invoke_O__O(p1__1479000192_SHARP___1); if linked_2002 == nil { and__1927000168__auto____3 = ifn_2003.Invoke_O__O(arg_2004) } else { and__1927000168__auto____3 = linked_2002.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_2001, arg_2004) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2005 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2007 lang.IFn; if linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_j2g_model_A_const_224.Invoke_O__O(p1__1479000192_SHARP___1)))).Ref(); if linked_2006 == nil { return ifn_2007.Invoke_O__O(arg_2008) } else { return linked_2006.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2005, arg_2008) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A{}; t.Ctor_O_O(p0, p1); return t }
//line :625:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :625:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A) Invoke_O_O__O(self, p1__1479000193_SHARP___1 any) any { var root_2016 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = t.F_n; var arg_2020 any = p1__1479000193_SHARP___1; var arg_2021 any = t.F_seen; if linked_2017 == nil { return ifn_2018.Invoke_O_O_O__O(arg_2019, arg_2020, arg_2021) } else { return linked_2017.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2016, arg_2019, arg_2020, arg_2021) } }








func A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A{}; t.Ctor_O_O(p0, p1); return t }
//line :634:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :634:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A) Invoke_O_O__O(self, p1__1479000194_SHARP___1 any) any { var root_1944 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = t.F_n; var arg_1948 any = p1__1479000194_SHARP___1; var arg_1949 any = t.F_seen; if linked_1945 == nil { return ifn_1946.Invoke_O_O_O__O(arg_1947, arg_1948, arg_1949) } else { return linked_1945.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1944, arg_1947, arg_1948, arg_1949) } }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A{}; t.Ctor_O_O(p0, p1); return t }
//line :636:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :636:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A) Invoke_O_O__O(self, p1__1479000195_SHARP___1 any) any { var root_2049 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = t.F_n; var arg_2053 any = p1__1479000195_SHARP___1; var arg_2054 any = t.F_seen; if linked_2050 == nil { return ifn_2051.Invoke_O_O_O__O(arg_2052, arg_2053, arg_2054) } else { return linked_2050.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2049, arg_2052, arg_2053, arg_2054) } }


func A_arbace_j2g_model_benign_init_QMARK__A_New() *A_arbace_j2g_model_benign_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :639:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Ctor() {}
//line :639:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_189; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_36.Get__O()); var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_252, n__0); var tmp2 any; var root_2070 any = A_arbace_j2g_model_A_const_37.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2072 lang.IFn; if








	linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any; var root_2075 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = cache__2; if linked_2076 == nil { arg_2073 = ifn_2077.Invoke_O__O(arg_2078) } else { arg_2073 = linked_2076.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2075, arg_2078) }; var arg_2074 any = k__3; if linked_2071 == nil { tmp2 = ifn_2072.Invoke_O_O__O(arg_2073, arg_2074) } else { tmp2 = linked_2071.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2070, arg_2073, arg_2074) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_2079 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = cache__2; if linked_2080 == nil { tmp3 = ifn_2081.Invoke_O__O(arg_2082) } else { tmp3 = linked_2080.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2079, arg_2082) }; return lang.RT_Get_O_O__O_NoInit(tmp3, k__3) } else {
//line :648:1
			var r__4 any; var tmp4 any; var root_2083 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2085 lang.IFn


			if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = n__0; if linked_2084 == nil { tmp4 = ifn_2085.Invoke_O__O(arg_2086) } else { tmp4 = linked_2084.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2083, arg_2086) }
//line :650:1
			if jrt.J2g_Truth(tmp4) { r__4 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_2087 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2089 lang.IFn

				if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = n__0; if linked_2088 == nil { tmp5 = ifn_2089.Invoke_O__O(arg_2090) } else { tmp5 = linked_2088.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2087, arg_2090) }
//line :650:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__4 = jrt.Boolean_FALSE.Ref() } else { if A_arbace_j2g_model_A_const_63 != nil { var d__4 any; var root_2091 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2093 lang.IFn


					if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any = n__0; if linked_2092 == nil { d__4 = ifn_2093.Invoke_O__O(arg_2094) } else { d__4 = linked_2092.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2091, arg_2094) }
//line :650:1
					var st__5 any; var root_2095 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2097 lang.IFn


					if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = A_arbace_j2g_model_A_const_190.Invoke_O__O(d__4); if linked_2096 == nil { st__5 = ifn_2097.Invoke_O__O(arg_2098) } else { st__5 = linked_2096.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2095, arg_2098) }
//line :650:1
					var and__1927000168__auto____6 any; var root_2099 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2101 lang.IFn




					if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = A_arbace_j2g_model_A_const_192.Invoke_O__O(st__5); if linked_2100 == nil { and__1927000168__auto____6 = ifn_2101.Invoke_O__O(arg_2102) } else { and__1927000168__auto____6 = linked_2100.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2099, arg_2102) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2103 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2105 lang.IFn
						if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = A_arbace_j2g_model_A_const_193.Invoke_O__O(st__5); if linked_2104 == nil { and__1927000168__auto____7 = ifn_2105.Invoke_O__O(arg_2106) } else { and__1927000168__auto____7 = linked_2104.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2103, arg_2106) }
//line :655:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_2107 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2109 lang.IFn

							if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = A_arbace_j2g_model_A_const_194.Invoke_O__O(st__5); if linked_2108 == nil { and__1927000168__auto____8 = ifn_2109.Invoke_O__O(arg_2110) } else { and__1927000168__auto____8 = linked_2108.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2107, arg_2110) }
//line :655:1
							if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_83.Invoke_O__O(d__4), nil)


								if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_2111 any = A_arbace_j2g_model_A_const_251.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, A_arbace_j2g_model_benign_init_QMARK__A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = A_arbace_j2g_model_A_const_83.Invoke_O__O(d__4); if linked_2112 == nil { and__1927000168__auto____9 = ifn_2113.Invoke_O__O(arg_2114) } else { and__1927000168__auto____9 = linked_2112.(*A_arbace_j2g_model_benign_init_QMARK__A).Invoke_O_O__O(root_2111, arg_2114) } }
//line :655:1
								if jrt.J2g_Truth(and__1927000168__auto____9) {



									var root_2115 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any; var fnbody__2127 any = A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A_New_O(n__0); var tmp6 *jrt.Class; var fncls__2126 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A_fn_class; if fncls__2126 == nil { var fncls__2126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__2127); A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A_fn_class = fncls__2126d; tmp6 = fncls__2126d } else { tmp6 = fncls__2126 }; arg_2118 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2127, tmp6, nil); var arg_2119 any = A_arbace_j2g_model_A_const_191.Invoke_O__O(st__5); if linked_2116 == nil { r__4 = ifn_2117.Invoke_O_O__O(arg_2118, arg_2119) } else { r__4 = linked_2116.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2115, arg_2118, arg_2119) } } else {
//line :655:1
										r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :650:1
											r__4 = nil
										}
				}
			}






			var root_2128 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = cache__2; var arg_2132 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var arg_2133 any = k__3; var arg_2134 any = r__4; if linked_2129 == nil { ifn_2130.Invoke_O_O_O_O__O(arg_2131, arg_2132, arg_2133, arg_2134) } else { linked_2129.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2128, arg_2131, arg_2132, arg_2133, arg_2134) }
//line :648:1
			return r__4 } }










func A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A_New_O(p0 any) *A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A{}; t.Ctor_O(p0); return t }
//line :659:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :659:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A) Invoke_O_O__O(self, p1__1479000216_SHARP___1 any) any { var root_2120 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = t.F_n; var arg_2124 any = p1__1479000216_SHARP___1; var arg_2125 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_2121 == nil { return ifn_2122.Invoke_O_O_O__O(arg_2123, arg_2124, arg_2125) } else { return linked_2121.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2120, arg_2123, arg_2124, arg_2125) } }



























func A_arbace_j2g_model_fn__1479000224_A_New() *A_arbace_j2g_model_fn__1479000224_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000224_A{}; t.Ctor(); return t }
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_A) Ctor() {}
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__2206 any = A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_New(); var tmp1 *jrt.Class; var fncls__2205 *jrt.Class = A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_fn_class; if fncls__2205 == nil { var fncls__2205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_fn_class = fncls__2205d; tmp1 = fncls__2205d } else { tmp1 = fncls__2205 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2206, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_model_A_const_253.GetRawRoot__O()) }
//line :687:1
func A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_New() *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A{}; t.Ctor(); return t }
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A) Ctor() {}
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A) Invoke_O_O__O(self, s__1479000221__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2204 any = A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_New_O_O(s__1479000221__1, self); var tmp2 *jrt.Class; var fncls__2203 *jrt.Class = A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_fn_class; if fncls__2203 == nil { var fncls__2203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__2204); A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_fn_class = fncls__2203d; tmp2 = fncls__2203d } else { tmp2 = fncls__2203 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2204, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :687:1
func A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A{}; t.Ctor_O_O(p0, p1); return t }
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A) Ctor_O_O(c__s__1479000221, c__iter__1479000220 any) { t.F_s__1479000221 = c__s__1479000221; t.F_iter__1479000220 = c__iter__1479000220 }
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A) Invoke_O__O(self any) any { { var s__1479000221__1 any; var t_ any = t.F_s__1479000221; t.F_s__1479000221 = nil; s__1479000221__1 = t_; for { var temp__1927000414__auto____2 any; var root_2135 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any = s__1479000221__1; if linked_2136 == nil { temp__1927000414__auto____2 = ifn_2137.Invoke_O__O(arg_2138) } else { temp__1927000414__auto____2 = linked_2136.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2135, arg_2138) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000221__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2139 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = s__1479000221__3; if linked_2140 == nil { tmp1 = ifn_2141.Invoke_O__O(arg_2142) } else { tmp1 = linked_2140.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2139, arg_2142) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2143 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = s__1479000221__3; if linked_2144 == nil { c__1927001037__auto____4 = ifn_2145.Invoke_O__O(arg_2146) } else { c__1927001037__auto____4 = linked_2144.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2143, arg_2146) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000223__6 any; var root_2147 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2148 == nil { b__1479000223__6 = ifn_2149.Invoke_O__O(arg_2150) } else { b__1479000223__6 = linked_2148.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2147, arg_2150) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2162 any = A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A_New_O_I_O(b__1479000223__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2161 *jrt.Class = A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A_fn_class; if fncls__2161 == nil { var fncls__2161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2162); A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A_fn_class = fncls__2161d; tmp3 = fncls__2161d } else { tmp3 = fncls__2161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2162, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2163 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any; var root_2168 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2170 lang.IFn; if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = b__1479000223__6; if linked_2169 == nil { arg_2166 = ifn_2170.Invoke_O__O(arg_2171) } else { arg_2166 = linked_2169.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2168, arg_2171) }; var arg_2167 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000220); var tmp5 any; var root_2172 any = A_arbace_j2g_model_A_const_157.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = s__1479000221__3; if linked_2173 == nil { tmp5 = ifn_2174.Invoke_O__O(arg_2175) } else { tmp5 = linked_2173.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2172, arg_2175) }; arg_2167 = tmp4.Invoke_O__O(tmp5); if linked_2164 == nil { return ifn_2165.Invoke_O_O__O(arg_2166, arg_2167) } else { return linked_2164.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2163, arg_2166, arg_2167) } } else { var root_2176 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2178 lang.IFn; if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any; var root_2181 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = b__1479000223__6; if linked_2182 == nil { arg_2179 = ifn_2183.Invoke_O__O(arg_2184) } else { arg_2179 = linked_2182.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2181, arg_2184) }; var arg_2180 any; if linked_2177 == nil { return ifn_2178.Invoke_O_O__O(arg_2179, arg_2180) } else { return linked_2177.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2176, arg_2179, arg_2180) } } } else { var d__4 any; var root_2185 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2187 lang.IFn; if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = s__1479000221__3; if linked_2186 == nil { d__4 = ifn_2187.Invoke_O__O(arg_2188) } else { d__4 = linked_2186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2185, arg_2188) }; var root_2189 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any; var tmp6 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_23, Lit_24, d__4); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp8 any; var root_2194 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2196 lang.IFn
															if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any = Lit_24; var arg_2198 any = d__4; if linked_2195 == nil { tmp8 = ifn_2196.Invoke_O_O__O(arg_2197, arg_2198) } else { tmp8 = linked_2195.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2194, arg_2197, arg_2198) }
//line :687:1
	arg_2192 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(), Lit_26)); var arg_2193 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1479000220); var tmp10 any; var root_2199 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = s__1479000221__3; if linked_2200 == nil { tmp10 = ifn_2201.Invoke_O__O(arg_2202) } else { tmp10 = linked_2200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2199, arg_2202) }; arg_2193 = tmp9.Invoke_O__O(tmp10); if linked_2190 == nil { return ifn_2191.Invoke_O_O__O(arg_2192, arg_2193) } else { return linked_2190.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2189, arg_2192, arg_2193) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :687:1
func A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A) Ctor_O_I_O(c__b__1479000223 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000223 = c__b__1479000223; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :687:1
func (t *A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A) Invoke_O__O(self any) any { { var i__1479000222__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000222__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000222__1)); var root_2151 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any = t.F_b__1479000223; var arg_2155 any; var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_23, Lit_24, d__2); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp4 any; var root_2156 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2158 lang.IFn
																	if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = Lit_24; var arg_2160 any = d__2; if linked_2157 == nil { tmp4 = ifn_2158.Invoke_O_O__O(arg_2159, arg_2160) } else { tmp4 = linked_2157.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2156, arg_2159, arg_2160) }
//line :687:1
	arg_2155 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(), Lit_26)); if linked_2152 == nil { ifn_2153.Invoke_O_O__O(arg_2154, arg_2155) } else { linked_2152.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2151, arg_2154, arg_2155) }; i__1479000222__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000222__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_model_throwable_print_helper_A_New() *A_arbace_j2g_model_throwable_print_helper_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_throwable_print_helper_A{}; t.Ctor(); return t }
//line :690:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Ctor() {}
//line :690:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Invoke_O_O_O_O__O(self, owner__0, name__1, desc__2 any) any { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_model_A_const_254.GetRawRoot__O(), lang.Tuple_Create_O_O_O__IPersistentVector(owner__0, name__1, desc__2)); if




	jrt.J2g_Truth(temp__1927000414__auto____4) { var vec__1479000232__5 any = temp__1927000414__auto____4; var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000232__5, lang.RT_IntCast_J__I_NoInit(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000232__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____8 any; var root_2207 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2209 lang.IFn
		if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = owner__0; if linked_2208 == nil { and__1927000168__auto____8 = ifn_2209.Invoke_O__O(arg_2210) } else { and__1927000168__auto____8 = linked_2208.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2207, arg_2210) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2211 any = A_arbace_j2g_model_A_const_255.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, A_arbace_j2g_model_translatable_QMARK__A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = c__7; if linked_2212 == nil { tmp1 = ifn_2213.Invoke_O__O(arg_2214) } else { tmp1 = linked_2212.(*A_arbace_j2g_model_translatable_QMARK__A).Invoke_O_O__O(root_2211, arg_2214) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return f__6 } else { return nil } } else {
//line :695:1
			return nil } }





























































type A_arbace_j2g_model_A struct{ jrt.Object }

var A_arbace_j2g_model_A_const_pool *jrt.RefArray

var A_arbace_j2g_model_A_const_0 *lang.Var

var A_arbace_j2g_model_A_const_1 any

var A_arbace_j2g_model_A_const_2 any

var A_arbace_j2g_model_A_const_3 any

var A_arbace_j2g_model_A_const_4 any

var A_arbace_j2g_model_A_const_5 any

var A_arbace_j2g_model_A_const_6 any

var A_arbace_j2g_model_A_const_7 any

var A_arbace_j2g_model_A_const_8 any

var A_arbace_j2g_model_A_const_9 *lang.Var

var A_arbace_j2g_model_A_const_10 any

var A_arbace_j2g_model_A_const_11 *lang.Var

var A_arbace_j2g_model_A_const_12 *lang.Var

var A_arbace_j2g_model_A_const_13 *lang.Var

var A_arbace_j2g_model_A_const_14 *lang.Var

var A_arbace_j2g_model_A_const_15 any

var A_arbace_j2g_model_A_const_16 *lang.Var

var A_arbace_j2g_model_A_const_17 *lang.Var

var A_arbace_j2g_model_A_const_18 *lang.Var

var A_arbace_j2g_model_A_const_19 *lang.Var

var A_arbace_j2g_model_A_const_20 *lang.Var

var A_arbace_j2g_model_A_const_21 *lang.Var

var A_arbace_j2g_model_A_const_22 *lang.Var

var A_arbace_j2g_model_A_const_23 *lang.Var

var A_arbace_j2g_model_A_const_24 *lang.Var

var A_arbace_j2g_model_A_const_25 *lang.Var

var A_arbace_j2g_model_A_const_26 *lang.Var

var A_arbace_j2g_model_A_const_27 any

var A_arbace_j2g_model_A_const_28 *lang.Var

var A_arbace_j2g_model_A_const_29 *lang.Var

var A_arbace_j2g_model_A_const_30 *lang.Var

var A_arbace_j2g_model_A_const_31 *lang.Var

var A_arbace_j2g_model_A_const_32 *lang.Var

var A_arbace_j2g_model_A_const_33 *lang.Var

var A_arbace_j2g_model_A_const_34 any

var A_arbace_j2g_model_A_const_35 *lang.Keyword

var A_arbace_j2g_model_A_const_36 *lang.Var

var A_arbace_j2g_model_A_const_37 *lang.Var

var A_arbace_j2g_model_A_const_38 *lang.Var

var A_arbace_j2g_model_A_const_39 *lang.Var

var A_arbace_j2g_model_A_const_40 *lang.Keyword

var A_arbace_j2g_model_A_const_41 *lang.Var

var A_arbace_j2g_model_A_const_42 *lang.Var

var A_arbace_j2g_model_A_const_43 *lang.Var

var A_arbace_j2g_model_A_const_44 *lang.Var

var A_arbace_j2g_model_A_const_45 *lang.Var

var A_arbace_j2g_model_A_const_46 *lang.Var

var A_arbace_j2g_model_A_const_47 *lang.Var

var A_arbace_j2g_model_A_const_48 *lang.Var

var A_arbace_j2g_model_A_const_49 *lang.Keyword

var A_arbace_j2g_model_A_const_50 any

var A_arbace_j2g_model_A_const_51 *lang.Var

var A_arbace_j2g_model_A_const_52 *lang.Keyword

var A_arbace_j2g_model_A_const_53 *lang.Var

var A_arbace_j2g_model_A_const_54 *lang.Var

var A_arbace_j2g_model_A_const_55 *lang.Var

var A_arbace_j2g_model_A_const_56 *lang.Keyword

var A_arbace_j2g_model_A_const_57 *lang.Var

var A_arbace_j2g_model_A_const_58 *lang.Var

var A_arbace_j2g_model_A_const_59 *lang.Var

var A_arbace_j2g_model_A_const_60 *lang.Var

var A_arbace_j2g_model_A_const_61 *lang.Var

var A_arbace_j2g_model_A_const_62 *lang.Var

var A_arbace_j2g_model_A_const_63 *lang.Keyword

var A_arbace_j2g_model_A_const_64 *lang.Var

var A_arbace_j2g_model_A_const_65 *lang.Var

var A_arbace_j2g_model_A_const_66 *lang.Var

var A_arbace_j2g_model_A_const_67 *lang.Var

var A_arbace_j2g_model_A_const_68 *lang.Var

var A_arbace_j2g_model_A_const_69 *lang.Var

var A_arbace_j2g_model_A_const_70 *lang.Var

var A_arbace_j2g_model_A_const_71 *lang.Var

var A_arbace_j2g_model_A_const_72 *lang.Keyword

var A_arbace_j2g_model_A_const_73 *lang.Var

var A_arbace_j2g_model_A_const_74 *lang.Keyword

var A_arbace_j2g_model_A_const_75 *lang.Var

var A_arbace_j2g_model_A_const_76 *lang.Var

var A_arbace_j2g_model_A_const_77 *lang.Var

var A_arbace_j2g_model_A_const_78 any

var A_arbace_j2g_model_A_const_79 any

var A_arbace_j2g_model_A_const_80 *lang.Keyword

var A_arbace_j2g_model_A_const_81 *lang.Var

var A_arbace_j2g_model_A_const_82 *lang.Var

var A_arbace_j2g_model_A_const_83 *lang.Keyword

var A_arbace_j2g_model_A_const_84 *lang.Var

var A_arbace_j2g_model_A_const_85 *lang.Var

var A_arbace_j2g_model_A_const_86 *lang.Var

var A_arbace_j2g_model_A_const_87 *lang.Var

var A_arbace_j2g_model_A_const_88 *lang.Var

var A_arbace_j2g_model_A_const_89 *lang.Var

var A_arbace_j2g_model_A_const_90 *lang.Var

var A_arbace_j2g_model_A_const_91 *lang.Var

var A_arbace_j2g_model_A_const_92 *lang.Var

var A_arbace_j2g_model_A_const_93 *lang.Keyword

var A_arbace_j2g_model_A_const_94 *lang.Keyword

var A_arbace_j2g_model_A_const_95 *lang.Var

var A_arbace_j2g_model_A_const_96 *lang.Var

var A_arbace_j2g_model_A_const_97 *lang.Var

var A_arbace_j2g_model_A_const_98 *lang.Var

var A_arbace_j2g_model_A_const_99 *lang.Var

var A_arbace_j2g_model_A_const_100 *lang.Var

var A_arbace_j2g_model_A_const_101 *lang.Var

var A_arbace_j2g_model_A_const_102 *lang.Var

var A_arbace_j2g_model_A_const_103 *lang.Var

var A_arbace_j2g_model_A_const_104 *lang.Var

var A_arbace_j2g_model_A_const_105 *lang.Keyword

var A_arbace_j2g_model_A_const_106 *lang.Var

var A_arbace_j2g_model_A_const_107 *lang.Var

var A_arbace_j2g_model_A_const_108 *lang.Var

var A_arbace_j2g_model_A_const_109 *lang.Var

var A_arbace_j2g_model_A_const_110 *lang.Keyword

var A_arbace_j2g_model_A_const_111 any

var A_arbace_j2g_model_A_const_112 *lang.Var

var A_arbace_j2g_model_A_const_113 any

var A_arbace_j2g_model_A_const_114 any

var A_arbace_j2g_model_A_const_115 *lang.Var

var A_arbace_j2g_model_A_const_116 *lang.Var

var A_arbace_j2g_model_A_const_117 *lang.Var

var A_arbace_j2g_model_A_const_118 *lang.Keyword

var A_arbace_j2g_model_A_const_119 any

var A_arbace_j2g_model_A_const_120 any

var A_arbace_j2g_model_A_const_121 any

var A_arbace_j2g_model_A_const_122 *lang.Var

var A_arbace_j2g_model_A_const_123 *lang.Var

var A_arbace_j2g_model_A_const_124 *lang.Var

var A_arbace_j2g_model_A_const_125 any

var A_arbace_j2g_model_A_const_126 any

var A_arbace_j2g_model_A_const_127 *lang.Keyword

var A_arbace_j2g_model_A_const_128 *lang.Keyword

var A_arbace_j2g_model_A_const_129 *lang.Var

var A_arbace_j2g_model_A_const_130 *lang.Var

var A_arbace_j2g_model_A_const_131 *lang.Var

var A_arbace_j2g_model_A_const_132 *lang.Var

var A_arbace_j2g_model_A_const_133 *lang.Var

var A_arbace_j2g_model_A_const_134 *lang.Var

var A_arbace_j2g_model_A_const_135 *lang.Var

var A_arbace_j2g_model_A_const_136 *lang.Var

var A_arbace_j2g_model_A_const_137 *lang.Var

var A_arbace_j2g_model_A_const_138 *lang.Var

var A_arbace_j2g_model_A_const_139 *lang.Var

var A_arbace_j2g_model_A_const_140 *lang.Keyword

var A_arbace_j2g_model_A_const_141 *lang.Var

var A_arbace_j2g_model_A_const_142 *lang.Var

var A_arbace_j2g_model_A_const_143 *lang.Var

var A_arbace_j2g_model_A_const_144 any

var A_arbace_j2g_model_A_const_145 *lang.Var

var A_arbace_j2g_model_A_const_146 *lang.Var

var A_arbace_j2g_model_A_const_147 *lang.Var

var A_arbace_j2g_model_A_const_148 *lang.Var

var A_arbace_j2g_model_A_const_149 *lang.Var

var A_arbace_j2g_model_A_const_150 *lang.Var

var A_arbace_j2g_model_A_const_151 *lang.Var

var A_arbace_j2g_model_A_const_152 *lang.Var

var A_arbace_j2g_model_A_const_153 *lang.Var

var A_arbace_j2g_model_A_const_154 *lang.Keyword

var A_arbace_j2g_model_A_const_155 *lang.Var

var A_arbace_j2g_model_A_const_156 *lang.Var

var A_arbace_j2g_model_A_const_157 *lang.Var

var A_arbace_j2g_model_A_const_158 *lang.Var

var A_arbace_j2g_model_A_const_159 *lang.Var

var A_arbace_j2g_model_A_const_160 *lang.Keyword

var A_arbace_j2g_model_A_const_161 *lang.Var

var A_arbace_j2g_model_A_const_162 *lang.Var

var A_arbace_j2g_model_A_const_163 *lang.Var

var A_arbace_j2g_model_A_const_164 *lang.Var

var A_arbace_j2g_model_A_const_165 any

var A_arbace_j2g_model_A_const_166 *lang.Var

var A_arbace_j2g_model_A_const_167 *lang.Var

var A_arbace_j2g_model_A_const_168 *lang.Var

var A_arbace_j2g_model_A_const_169 *lang.Var

var A_arbace_j2g_model_A_const_170 *lang.Var

var A_arbace_j2g_model_A_const_171 *lang.Var

var A_arbace_j2g_model_A_const_172 *lang.Var

var A_arbace_j2g_model_A_const_173 *lang.Keyword

var A_arbace_j2g_model_A_const_174 *lang.Keyword

var A_arbace_j2g_model_A_const_175 *lang.Keyword

var A_arbace_j2g_model_A_const_176 *lang.Keyword

var A_arbace_j2g_model_A_const_177 *lang.Keyword

var A_arbace_j2g_model_A_const_178 *lang.Keyword

var A_arbace_j2g_model_A_const_179 *lang.Var

var A_arbace_j2g_model_A_const_180 *lang.Keyword

var A_arbace_j2g_model_A_const_181 *lang.Var

var A_arbace_j2g_model_A_const_182 *lang.Keyword

var A_arbace_j2g_model_A_const_183 *lang.Keyword

var A_arbace_j2g_model_A_const_184 *lang.Var

var A_arbace_j2g_model_A_const_185 any

var A_arbace_j2g_model_A_const_186 any

var A_arbace_j2g_model_A_const_187 *lang.Var

var A_arbace_j2g_model_A_const_188 *lang.Var

var A_arbace_j2g_model_A_const_189 *lang.Keyword

var A_arbace_j2g_model_A_const_190 *lang.Keyword

var A_arbace_j2g_model_A_const_191 *lang.Keyword

var A_arbace_j2g_model_A_const_192 *lang.Keyword

var A_arbace_j2g_model_A_const_193 *lang.Keyword

var A_arbace_j2g_model_A_const_194 *lang.Keyword

var A_arbace_j2g_model_A_const_195 *lang.Var

var A_arbace_j2g_model_A_const_196 *lang.Var

var A_arbace_j2g_model_A_const_197 *lang.Var

var A_arbace_j2g_model_A_const_198 *lang.Var

var A_arbace_j2g_model_A_const_199 *lang.Var

var A_arbace_j2g_model_A_const_200 *lang.Var

var A_arbace_j2g_model_A_const_201 *lang.Var

var A_arbace_j2g_model_A_const_202 *lang.Var

var A_arbace_j2g_model_A_const_203 *lang.Keyword

var A_arbace_j2g_model_A_const_204 *lang.Var

var A_arbace_j2g_model_A_const_205 *lang.Keyword

var A_arbace_j2g_model_A_const_206 *lang.Keyword

var A_arbace_j2g_model_A_const_207 *lang.Keyword

var A_arbace_j2g_model_A_const_208 *lang.Var

var A_arbace_j2g_model_A_const_209 *lang.Keyword

var A_arbace_j2g_model_A_const_210 any

var A_arbace_j2g_model_A_const_211 *lang.Var

var A_arbace_j2g_model_A_const_212 *lang.Keyword

var A_arbace_j2g_model_A_const_213 *lang.Keyword

var A_arbace_j2g_model_A_const_214 *lang.Keyword

var A_arbace_j2g_model_A_const_215 *lang.Keyword

var A_arbace_j2g_model_A_const_216 *lang.Keyword

var A_arbace_j2g_model_A_const_217 *lang.Keyword

var A_arbace_j2g_model_A_const_218 *lang.Keyword

var A_arbace_j2g_model_A_const_219 *lang.Keyword

var A_arbace_j2g_model_A_const_220 *lang.Keyword

var A_arbace_j2g_model_A_const_221 *lang.Keyword

var A_arbace_j2g_model_A_const_222 *lang.Keyword

var A_arbace_j2g_model_A_const_223 *lang.Keyword

var A_arbace_j2g_model_A_const_224 *lang.Keyword

var A_arbace_j2g_model_A_const_225 *lang.Keyword

var A_arbace_j2g_model_A_const_226 *lang.Keyword

var A_arbace_j2g_model_A_const_227 *lang.Keyword

var A_arbace_j2g_model_A_const_228 *lang.Keyword

var A_arbace_j2g_model_A_const_229 *lang.Keyword

var A_arbace_j2g_model_A_const_230 *lang.Keyword

var A_arbace_j2g_model_A_const_231 *lang.Keyword

var A_arbace_j2g_model_A_const_232 *lang.Keyword

var A_arbace_j2g_model_A_const_233 *lang.Keyword

var A_arbace_j2g_model_A_const_234 *lang.Keyword

var A_arbace_j2g_model_A_const_235 *lang.Keyword

var A_arbace_j2g_model_A_const_236 *lang.Keyword

var A_arbace_j2g_model_A_const_237 *lang.Keyword

var A_arbace_j2g_model_A_const_238 *lang.Keyword

var A_arbace_j2g_model_A_const_239 *lang.Var

var A_arbace_j2g_model_A_const_240 *lang.Keyword

var A_arbace_j2g_model_A_const_241 *lang.Keyword

var A_arbace_j2g_model_A_const_242 *lang.Keyword

var A_arbace_j2g_model_A_const_243 *lang.Keyword

var A_arbace_j2g_model_A_const_244 any

var A_arbace_j2g_model_A_const_245 *lang.Keyword

var A_arbace_j2g_model_A_const_246 *lang.Keyword

var A_arbace_j2g_model_A_const_247 *lang.Keyword

var A_arbace_j2g_model_A_const_248 *lang.Keyword

var A_arbace_j2g_model_A_const_249 *lang.Keyword

var A_arbace_j2g_model_A_const_250 *lang.Keyword

var A_arbace_j2g_model_A_const_251 *lang.Var

var A_arbace_j2g_model_A_const_252 *lang.Keyword

var A_arbace_j2g_model_A_const_253 *lang.Var

var A_arbace_j2g_model_A_const_254 *lang.Var

var A_arbace_j2g_model_A_const_255 *lang.Var

var A_arbace_j2g_model_A_init jrt.ClassInit

func A_arbace_j2g_model_A_Init() { if !A_arbace_j2g_model_A_init.Done() { A_arbace_j2g_model_A_init.Run(A_arbace_j2g_model_A_clinit) } }

func A_arbace_j2g_model_A_clinit() { A_arbace_j2g_model_A_clinit_p0(); A_arbace_j2g_model_A_clinit_p1(); A_arbace_j2g_model_A_clinit_p2(); A_arbace_j2g_model_A_clinit_p3(); A_arbace_j2g_model_A_clinit_p4(); A_arbace_j2g_model_A_clinit_p5(); A_arbace_j2g_model_A_clinit_p6(); A_arbace_j2g_model_A_clinit_p7(); A_arbace_j2g_model_A_clinit_p8(); A_arbace_j2g_model_A_clinit_p9(); A_arbace_j2g_model_A_clinit_p10(); A_arbace_j2g_model_A_clinit_p11(); A_arbace_j2g_model_A_clinit_p12(); A_arbace_j2g_model_A_clinit_p13(); A_arbace_j2g_model_A_clinit_p14(); A_arbace_j2g_model_A_clinit_p15(); A_arbace_j2g_model_A_clinit_p16(); A_arbace_j2g_model_A_clinit_p17(); A_arbace_j2g_model_A_clinit_p18(); A_arbace_j2g_model_A_clinit_p19(); A_arbace_j2g_model_A_clinit_p20(); A_arbace_j2g_model_A_clinit_p21() }

func A_arbace_j2g_model_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 357); A_arbace_j2g_model_A_const_0 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[101]); A_arbace_j2g_model_A_const_1 = A_arbace_j2g_model_A_const_pool.A[102]; A_arbace_j2g_model_A_const_2 = A_arbace_j2g_model_A_const_pool.A[103]; A_arbace_j2g_model_A_const_3 = A_arbace_j2g_model_A_const_pool.A[104]; A_arbace_j2g_model_A_const_4 = A_arbace_j2g_model_A_const_pool.A[105]; A_arbace_j2g_model_A_const_5 = A_arbace_j2g_model_A_const_pool.A[106]; A_arbace_j2g_model_A_const_6 = A_arbace_j2g_model_A_const_pool.A[107]; A_arbace_j2g_model_A_const_7 = A_arbace_j2g_model_A_const_pool.A[108]; A_arbace_j2g_model_A_const_8 = A_arbace_j2g_model_A_const_pool.A[109]; A_arbace_j2g_model_A_const_9 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[110]); A_arbace_j2g_model_A_const_10 = A_arbace_j2g_model_A_const_pool.A[111]; A_arbace_j2g_model_A_const_11 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[112]); A_arbace_j2g_model_A_const_12 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[113]) }

func A_arbace_j2g_model_A_clinit_p1() { A_arbace_j2g_model_A_const_13 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[114]); A_arbace_j2g_model_A_const_14 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[115]); A_arbace_j2g_model_A_const_15 = A_arbace_j2g_model_A_const_pool.A[116]; A_arbace_j2g_model_A_const_16 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[117]); A_arbace_j2g_model_A_const_17 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[118]); A_arbace_j2g_model_A_const_18 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[119]); A_arbace_j2g_model_A_const_19 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[120]); A_arbace_j2g_model_A_const_20 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[121]); A_arbace_j2g_model_A_const_21 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[122]); A_arbace_j2g_model_A_const_22 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[123]); A_arbace_j2g_model_A_const_23 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[124]); A_arbace_j2g_model_A_const_24 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[125]) }

func A_arbace_j2g_model_A_clinit_p2() { A_arbace_j2g_model_A_const_25 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[126]); A_arbace_j2g_model_A_const_26 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[127]); A_arbace_j2g_model_A_const_27 = A_arbace_j2g_model_A_const_pool.A[128]; A_arbace_j2g_model_A_const_28 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[129]); A_arbace_j2g_model_A_const_29 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[130]); A_arbace_j2g_model_A_const_30 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[131]); A_arbace_j2g_model_A_const_31 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[132]); A_arbace_j2g_model_A_const_32 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[133]); A_arbace_j2g_model_A_const_33 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[134]); A_arbace_j2g_model_A_const_34 = A_arbace_j2g_model_A_const_pool.A[135]; A_arbace_j2g_model_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[136]); A_arbace_j2g_model_A_const_36 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[137]) }

func A_arbace_j2g_model_A_clinit_p3() { A_arbace_j2g_model_A_const_37 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[138]); A_arbace_j2g_model_A_const_38 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[139]); A_arbace_j2g_model_A_const_39 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[140]); A_arbace_j2g_model_A_const_40 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[141]); A_arbace_j2g_model_A_const_41 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[142]); A_arbace_j2g_model_A_const_42 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[143]); A_arbace_j2g_model_A_const_43 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[144]); A_arbace_j2g_model_A_const_44 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[145]); A_arbace_j2g_model_A_const_45 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[146]); A_arbace_j2g_model_A_const_46 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[147]); A_arbace_j2g_model_A_const_47 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[148]); A_arbace_j2g_model_A_const_48 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[149]) }

func A_arbace_j2g_model_A_clinit_p4() { A_arbace_j2g_model_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[150]); A_arbace_j2g_model_A_const_50 = A_arbace_j2g_model_A_const_pool.A[151]; A_arbace_j2g_model_A_const_51 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[152]); A_arbace_j2g_model_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[153]); A_arbace_j2g_model_A_const_53 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[154]); A_arbace_j2g_model_A_const_54 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[155]); A_arbace_j2g_model_A_const_55 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[156]); A_arbace_j2g_model_A_const_56 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[157]); A_arbace_j2g_model_A_const_57 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[158]); A_arbace_j2g_model_A_const_58 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[159]); A_arbace_j2g_model_A_const_59 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[160]); A_arbace_j2g_model_A_const_60 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[161]) }

func A_arbace_j2g_model_A_clinit_p5() { A_arbace_j2g_model_A_const_61 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[162]); A_arbace_j2g_model_A_const_62 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[163]); A_arbace_j2g_model_A_const_63 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[164]); A_arbace_j2g_model_A_const_64 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[165]); A_arbace_j2g_model_A_const_65 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[166]); A_arbace_j2g_model_A_const_66 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[167]); A_arbace_j2g_model_A_const_67 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[168]); A_arbace_j2g_model_A_const_68 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[169]); A_arbace_j2g_model_A_const_69 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[170]); A_arbace_j2g_model_A_const_70 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[171]); A_arbace_j2g_model_A_const_71 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[172]); A_arbace_j2g_model_A_const_72 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[173]) }

func A_arbace_j2g_model_A_clinit_p6() { A_arbace_j2g_model_A_const_73 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[174]); A_arbace_j2g_model_A_const_74 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[175]); A_arbace_j2g_model_A_const_75 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[176]); A_arbace_j2g_model_A_const_76 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[177]); A_arbace_j2g_model_A_const_77 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[178]); A_arbace_j2g_model_A_const_78 = A_arbace_j2g_model_A_const_pool.A[179]; A_arbace_j2g_model_A_const_79 = A_arbace_j2g_model_A_const_pool.A[180]; A_arbace_j2g_model_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[181]); A_arbace_j2g_model_A_const_81 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[182]); A_arbace_j2g_model_A_const_82 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[183]); A_arbace_j2g_model_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[184]); A_arbace_j2g_model_A_const_84 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[185]) }

func A_arbace_j2g_model_A_clinit_p7() { A_arbace_j2g_model_A_const_85 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[186]); A_arbace_j2g_model_A_const_86 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[187]); A_arbace_j2g_model_A_const_87 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[188]); A_arbace_j2g_model_A_const_88 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[189]); A_arbace_j2g_model_A_const_89 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[190]); A_arbace_j2g_model_A_const_90 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[191]); A_arbace_j2g_model_A_const_91 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[192]); A_arbace_j2g_model_A_const_92 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[193]); A_arbace_j2g_model_A_const_93 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[194]); A_arbace_j2g_model_A_const_94 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[195]); A_arbace_j2g_model_A_const_95 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[196]); A_arbace_j2g_model_A_const_96 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[197]) }

func A_arbace_j2g_model_A_clinit_p8() { A_arbace_j2g_model_A_const_97 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[198]); A_arbace_j2g_model_A_const_98 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[199]); A_arbace_j2g_model_A_const_99 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[200]); A_arbace_j2g_model_A_const_100 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[201]); A_arbace_j2g_model_A_const_101 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[202]); A_arbace_j2g_model_A_const_102 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[203]); A_arbace_j2g_model_A_const_103 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[204]); A_arbace_j2g_model_A_const_104 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[205]); A_arbace_j2g_model_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[206]); A_arbace_j2g_model_A_const_106 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[207]); A_arbace_j2g_model_A_const_107 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[208]); A_arbace_j2g_model_A_const_108 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[209]) }

func A_arbace_j2g_model_A_clinit_p9() { A_arbace_j2g_model_A_const_109 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[210]); A_arbace_j2g_model_A_const_110 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[211]); A_arbace_j2g_model_A_const_111 = A_arbace_j2g_model_A_const_pool.A[212]; A_arbace_j2g_model_A_const_112 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[213]); A_arbace_j2g_model_A_const_113 = A_arbace_j2g_model_A_const_pool.A[214]; A_arbace_j2g_model_A_const_114 = A_arbace_j2g_model_A_const_pool.A[215]; A_arbace_j2g_model_A_const_115 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[216]); A_arbace_j2g_model_A_const_116 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[217]); A_arbace_j2g_model_A_const_117 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[218]); A_arbace_j2g_model_A_const_118 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[219]); A_arbace_j2g_model_A_const_119 = A_arbace_j2g_model_A_const_pool.A[220]; A_arbace_j2g_model_A_const_120 = A_arbace_j2g_model_A_const_pool.A[221]; A_arbace_j2g_model_A_const_121 = A_arbace_j2g_model_A_const_pool.A[222] }

func A_arbace_j2g_model_A_clinit_p10() { A_arbace_j2g_model_A_const_122 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[223]); A_arbace_j2g_model_A_const_123 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[224]); A_arbace_j2g_model_A_const_124 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[225]); A_arbace_j2g_model_A_const_125 = A_arbace_j2g_model_A_const_pool.A[226]; A_arbace_j2g_model_A_const_126 = A_arbace_j2g_model_A_const_pool.A[227]; A_arbace_j2g_model_A_const_127 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[228]); A_arbace_j2g_model_A_const_128 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[229]); A_arbace_j2g_model_A_const_129 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[230]); A_arbace_j2g_model_A_const_130 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[231]); A_arbace_j2g_model_A_const_131 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[232]); A_arbace_j2g_model_A_const_132 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[233]); A_arbace_j2g_model_A_const_133 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[234]) }

func A_arbace_j2g_model_A_clinit_p11() { A_arbace_j2g_model_A_const_134 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[235]); A_arbace_j2g_model_A_const_135 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[236]); A_arbace_j2g_model_A_const_136 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[237]); A_arbace_j2g_model_A_const_137 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[238]); A_arbace_j2g_model_A_const_138 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[239]); A_arbace_j2g_model_A_const_139 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[240]); A_arbace_j2g_model_A_const_140 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[241]); A_arbace_j2g_model_A_const_141 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[242]); A_arbace_j2g_model_A_const_142 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[243]); A_arbace_j2g_model_A_const_143 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[244]); A_arbace_j2g_model_A_const_144 = A_arbace_j2g_model_A_const_pool.A[245]; A_arbace_j2g_model_A_const_145 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[246]) }

func A_arbace_j2g_model_A_clinit_p12() { A_arbace_j2g_model_A_const_146 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[247]); A_arbace_j2g_model_A_const_147 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[248]); A_arbace_j2g_model_A_const_148 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[249]); A_arbace_j2g_model_A_const_149 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[250]); A_arbace_j2g_model_A_const_150 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[251]); A_arbace_j2g_model_A_const_151 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[252]); A_arbace_j2g_model_A_const_152 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[253]); A_arbace_j2g_model_A_const_153 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[254]); A_arbace_j2g_model_A_const_154 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[255]); A_arbace_j2g_model_A_const_155 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[256]); A_arbace_j2g_model_A_const_156 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[257]); A_arbace_j2g_model_A_const_157 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[258]) }

func A_arbace_j2g_model_A_clinit_p13() { A_arbace_j2g_model_A_const_158 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[259]); A_arbace_j2g_model_A_const_159 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[260]); A_arbace_j2g_model_A_const_160 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[261]); A_arbace_j2g_model_A_const_161 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[262]); A_arbace_j2g_model_A_const_162 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[263]); A_arbace_j2g_model_A_const_163 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[264]); A_arbace_j2g_model_A_const_164 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[265]); A_arbace_j2g_model_A_const_165 = A_arbace_j2g_model_A_const_pool.A[266]; A_arbace_j2g_model_A_const_166 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[267]); A_arbace_j2g_model_A_const_167 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[268]); A_arbace_j2g_model_A_const_168 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[269]); A_arbace_j2g_model_A_const_169 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[270]) }

func A_arbace_j2g_model_A_clinit_p14() { A_arbace_j2g_model_A_const_170 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[271]); A_arbace_j2g_model_A_const_171 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[272]); A_arbace_j2g_model_A_const_172 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[273]); A_arbace_j2g_model_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[274]); A_arbace_j2g_model_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[275]); A_arbace_j2g_model_A_const_175 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[276]); A_arbace_j2g_model_A_const_176 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[277]); A_arbace_j2g_model_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[278]); A_arbace_j2g_model_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[279]); A_arbace_j2g_model_A_const_179 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[280]); A_arbace_j2g_model_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[281]); A_arbace_j2g_model_A_const_181 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[282]) }

func A_arbace_j2g_model_A_clinit_p15() { A_arbace_j2g_model_A_const_182 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[283]); A_arbace_j2g_model_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[284]); A_arbace_j2g_model_A_const_184 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[285]); A_arbace_j2g_model_A_const_185 = A_arbace_j2g_model_A_const_pool.A[286]; A_arbace_j2g_model_A_const_186 = A_arbace_j2g_model_A_const_pool.A[287]; A_arbace_j2g_model_A_const_187 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[288]); A_arbace_j2g_model_A_const_188 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[289]); A_arbace_j2g_model_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[290]); A_arbace_j2g_model_A_const_190 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[291]); A_arbace_j2g_model_A_const_191 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[292]); A_arbace_j2g_model_A_const_192 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[293]); A_arbace_j2g_model_A_const_193 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[294]) }

func A_arbace_j2g_model_A_clinit_p16() { A_arbace_j2g_model_A_const_194 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[295]); A_arbace_j2g_model_A_const_195 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[296]); A_arbace_j2g_model_A_const_196 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[297]); A_arbace_j2g_model_A_const_197 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[298]); A_arbace_j2g_model_A_const_198 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[299]); A_arbace_j2g_model_A_const_199 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[300]); A_arbace_j2g_model_A_const_200 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[301]); A_arbace_j2g_model_A_const_201 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[302]); A_arbace_j2g_model_A_const_202 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[303]); A_arbace_j2g_model_A_const_203 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[304]); A_arbace_j2g_model_A_const_204 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[305]); A_arbace_j2g_model_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[306]) }

func A_arbace_j2g_model_A_clinit_p17() { A_arbace_j2g_model_A_const_206 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[307]); A_arbace_j2g_model_A_const_207 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[308]); A_arbace_j2g_model_A_const_208 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[309]); A_arbace_j2g_model_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[310]); A_arbace_j2g_model_A_const_210 = A_arbace_j2g_model_A_const_pool.A[311]; A_arbace_j2g_model_A_const_211 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[312]); A_arbace_j2g_model_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[313]); A_arbace_j2g_model_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[314]); A_arbace_j2g_model_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[315]); A_arbace_j2g_model_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[316]); A_arbace_j2g_model_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[317]); A_arbace_j2g_model_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[318]) }

func A_arbace_j2g_model_A_clinit_p18() { A_arbace_j2g_model_A_const_218 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[319]); A_arbace_j2g_model_A_const_219 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[320]); A_arbace_j2g_model_A_const_220 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[321]); A_arbace_j2g_model_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[322]); A_arbace_j2g_model_A_const_222 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[323]); A_arbace_j2g_model_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[324]); A_arbace_j2g_model_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[325]); A_arbace_j2g_model_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[326]); A_arbace_j2g_model_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[327]); A_arbace_j2g_model_A_const_227 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[328]); A_arbace_j2g_model_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[329]); A_arbace_j2g_model_A_const_229 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[330]) }

func A_arbace_j2g_model_A_clinit_p19() { A_arbace_j2g_model_A_const_230 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[331]); A_arbace_j2g_model_A_const_231 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[332]); A_arbace_j2g_model_A_const_232 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[333]); A_arbace_j2g_model_A_const_233 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[334]); A_arbace_j2g_model_A_const_234 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[335]); A_arbace_j2g_model_A_const_235 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[336]); A_arbace_j2g_model_A_const_236 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[337]); A_arbace_j2g_model_A_const_237 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[338]); A_arbace_j2g_model_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[339]); A_arbace_j2g_model_A_const_239 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[340]); A_arbace_j2g_model_A_const_240 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[341]); A_arbace_j2g_model_A_const_241 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[342]) }

func A_arbace_j2g_model_A_clinit_p20() { A_arbace_j2g_model_A_const_242 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[343]); A_arbace_j2g_model_A_const_243 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[344]); A_arbace_j2g_model_A_const_244 = A_arbace_j2g_model_A_const_pool.A[345]; A_arbace_j2g_model_A_const_245 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[346]); A_arbace_j2g_model_A_const_246 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[347]); A_arbace_j2g_model_A_const_247 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[348]); A_arbace_j2g_model_A_const_248 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[349]); A_arbace_j2g_model_A_const_249 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[350]); A_arbace_j2g_model_A_const_250 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[351]); A_arbace_j2g_model_A_const_251 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[352]); A_arbace_j2g_model_A_const_252 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[353]); A_arbace_j2g_model_A_const_253 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[354]) }

func A_arbace_j2g_model_A_clinit_p21() { A_arbace_j2g_model_A_const_254 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[355]); A_arbace_j2g_model_A_const_255 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[356]) }

func A_arbace_j2g_model_A_New() *A_arbace_j2g_model_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_A) Ctor() {}

func (t *A_arbace_j2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_A_class }

func (t *A_arbace_j2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_A); return ok }

func A_arbace_j2g_model_A_Cast(x any) *A_arbace_j2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_A_class)) }; return v }



type A_arbace_j2g_model_T_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_T_A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_m_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_m_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_method_error_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_method_error_text_A_fn_class *jrt.Class



type A_arbace_j2g_model_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_all_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_array_test_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_array_test_A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_benign_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_code_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_code_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_declared_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A struct{ j2g_header uint64; F_n, F_s__1479000097, F_iter__1479000096 any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A struct{ j2g_header uint64; F_b__1479000099, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_erased_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000004_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000004_A_New() *A_arbace_j2g_model_eval1479000004_A { t := &A_arbace_j2g_model_eval1479000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000004_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000004_A_class }

func (t *A_arbace_j2g_model_eval1479000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000004_A); return ok }

func A_arbace_j2g_model_eval1479000004_A_Cast(x any) *A_arbace_j2g_model_eval1479000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000004_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000008_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000008_A_New() *A_arbace_j2g_model_eval1479000008_A { t := &A_arbace_j2g_model_eval1479000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000008_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000008_A_class }

func (t *A_arbace_j2g_model_eval1479000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000008_A); return ok }

func A_arbace_j2g_model_eval1479000008_A_Cast(x any) *A_arbace_j2g_model_eval1479000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000008_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000008_fn__1479000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class *jrt.Class



type A_arbace_j2g_model_fields_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fields_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_final_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_final_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_find_method_A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_fn__1479000086_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_find_method_fn__1479000086_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000224_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000224_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A struct{ j2g_header uint64; F_s__1479000221, F_iter__1479000220 any }

var A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A struct{ j2g_header uint64; F_b__1479000223 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_qualified_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_qualified_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_model_hand_written_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hand_written_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_hw_method_exists_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_iface_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_iface_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_impl_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000130_A struct{ j2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_j2g_model_impl_of_fn__1479000130_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000142_A struct{ j2g_header uint64; F_cands any }

var A_arbace_j2g_model_impl_of_fn__1479000142_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A struct{ j2g_header uint64; F_name, F_desc, F_s__1479000133, F_iter__1479000132 any }

var A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A struct{ j2g_header uint64; F_b__1479000135, F_name, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A_fn_class *jrt.Class



type A_arbace_j2g_model_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_info_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_info_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A struct{ j2g_header uint64; F_iter__1479000157, F_s__1479000158 any }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A struct{ j2g_header uint64; F_b__1479000160 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A struct{ j2g_header uint64; F_declares_default_QMARK_ any }

var A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A_fn_class *jrt.Class



type A_arbace_j2g_model_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_method_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_java_type_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_java_type_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_jobs_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jobs_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_leaf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_leaf_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000065_A struct{ j2g_header uint64; F_cache, F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A struct{ j2g_header uint64; F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A_fn_class *jrt.Class



type A_arbace_j2g_model_mdesc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_member_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_member_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_method_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_method_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_methods_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_methods_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_nest_top_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_nest_top_A_fn_class *jrt.Class



type A_arbace_j2g_model_on_run_thread_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_on_run_thread_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_par_mapv_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000027_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000027_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_work__1479000025_A struct{ j2g_header uint64; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

var A_arbace_j2g_model_par_mapv_work__1479000025_A_fn_class *jrt.Class



type A_arbace_j2g_model_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_pointer_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_private_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A_fn_class *jrt.Class



type A_arbace_j2g_model_qualify_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_qualify_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflected_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflected_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_run_fn_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_run_fn_A_fn_class *jrt.Class



type A_arbace_j2g_model_run_fn_fn__1479000013_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_model_run_fn_fn__1479000013_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A struct{ j2g_header uint64; F_s__1479000172, F_iter__1479000171 any }

var A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1479000174 any }

var A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A_fn_class *jrt.Class



type A_arbace_j2g_model_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_subclasses_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_subclasses_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_fn__1479000122_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_fn__1479000122_A_fn_class *jrt.Class



type A_arbace_j2g_model_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_throwable_print_helper_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_throwable_print_helper_A_fn_class *jrt.Class



type A_arbace_j2g_model_top_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_top_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_translatable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translatable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_translated_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translated_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_trivial_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_trivial_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_virtual_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_virtual_member_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000107_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000107_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A_fn_class *jrt.Class



type A_arbace_j2g_model_world_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_world_supertypes_A_fn_class *jrt.Class
