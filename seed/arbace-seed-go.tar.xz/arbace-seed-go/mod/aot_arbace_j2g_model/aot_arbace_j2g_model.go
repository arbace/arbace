//line aot_arbace_j2g_model.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_suid"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New() *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_model_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_11); tmp2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_model_A_const_1, A_arbace_j2g_model_A_const_2, A_arbace_j2g_model_A_const_3, A_arbace_j2g_model_A_const_4, A_arbace_j2g_model_A_const_5, A_arbace_j2g_model_A_const_6, A_arbace_j2g_model_A_const_7, A_arbace_j2g_model_A_const_8, A_arbace_j2g_model_A_const_9); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New() *A_arbace_j2g_model_eval1479000008_fn__1479000009_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000008_fn__1479000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_12.GetRawRoot__O()); var tmp2 any; var root_23 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = A_arbace_j2g_model_A_const_14; if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_23, arg_26) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_model_A_const_15.GetRawRoot__O(), A_arbace_j2g_model_A_const_16) }




























func A_arbace_j2g_model_on_run_thread_A_New() *A_arbace_j2g_model_on_run_thread_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_on_run_thread_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_j2g_model_on_run_thread_A) Ctor() {}
//line :30:1
func (t *A_arbace_j2g_model_on_run_thread_A) Invoke_O_O__O(self, f__0 any) any {


	return lang.IFn_Cast(f__0).Invoke__O()
}
func A_arbace_j2g_model_run_fn_A_New() *A_arbace_j2g_model_run_fn_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_run_fn_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_j2g_model_run_fn_A) Ctor() {}
//line :35:1
func (t *A_arbace_j2g_model_run_fn_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.J2g_Truth(A_arbace_j2g_model_A_const_17.Get__O()) { var fnbody__32 any = A_arbace_j2g_model_run_fn_fn__1479000013_A_New_O(f__0); var tmp1 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_model_run_fn_fn__1479000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__32); A_arbace_j2g_model_run_fn_fn__1479000013_A_fn_class = fncls__31d; tmp1 = fncls__31d } else { tmp1 = fncls__31 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp1, nil) } else { return f__0 } }
//line :38:1
func A_arbace_j2g_model_run_fn_fn__1479000013_A_New_O(p0 any) *A_arbace_j2g_model_run_fn_fn__1479000013_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_run_fn_fn__1479000013_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_j2g_model_run_fn_fn__1479000013_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :38:1
func (t *A_arbace_j2g_model_run_fn_fn__1479000013_A) Invoke_O__O(self any) any { var root_27 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, A_arbace_j2g_model_on_run_thread_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = t.F_f; if linked_28 == nil { return ifn_29.Invoke_O__O(arg_30) } else { return linked_28.(*A_arbace_j2g_model_on_run_thread_A).Invoke_O_O__O(root_27, arg_30) } }









func A_arbace_j2g_model_jobs_A_New() *A_arbace_j2g_model_jobs_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jobs_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_j2g_model_jobs_A) Ctor() {}
//line :48:1
func (t *A_arbace_j2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_71).Ref(); var tmp1 any; var tmp2 any; var root_33 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_35 lang.IFn; if




	linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = e__1; if linked_34 == nil { tmp2 = ifn_35.Invoke_O__O(arg_36) } else { tmp2 = linked_34.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_33, arg_36) }; if jrt.J2g_Truth(tmp2) {
		tmp1 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(e__1))).Ref() } else {
			tmp1 = lang.Numbers_Min_O_J__O_NoInit(A_arbace_j2g_model_A_const_20.GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :53:1*/ lang.Numbers_Max_J_O__O_NoInit(1, tmp1) }



func A_arbace_j2g_model_par_mapv_A_New() *A_arbace_j2g_model_par_mapv_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_j2g_model_par_mapv_A) Ctor() {}
//line :57:1
func (t *A_arbace_j2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1479000017__3 any) any { var vec__1479000018__5 any = p__1479000017__3; var order__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000018__5, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__7 any; var root_37 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_39 lang.IFn; if









	linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = xs__2; if linked_38 == nil { xs__7 = ifn_39.Invoke_O__O(arg_40) } else { xs__7 = linked_38.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_37, arg_40) }; var cnt__8 int32 = /*line :57:1*/lang.RT_Count_O__I_NoInit(xs__7); var n__9 any = lang.Numbers_Min_O_J__O_NoInit(n__0, int64(cnt__8)); var order__10 any; if












	jrt.J2g_Truth(order__6) { var root_41 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = order__6; if linked_42 == nil { order__10 = ifn_43.Invoke_O__O(arg_44) } else { order__10 = linked_42.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_41, arg_44) } } else { var root_45 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any; var root_49 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref(); if linked_50 == nil { arg_48 = ifn_51.Invoke_O__O(arg_52) } else { arg_48 = linked_50.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_49, arg_52) }; if linked_46 == nil { order__10 = ifn_47.Invoke_O__O(arg_48) } else { order__10 = linked_46.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_45, arg_48) } }; var tmp1 bool; var na_53 any = n__9; var na_54 int64 = 1; if
	jrt.Long_InstanceOf(na_53) { var n0_55 int64 = jrt.NN(jrt.Long_Cast(na_53)).LongValue__J(); var n1_56 int64 = na_54; tmp1 = n0_55 <= n1_56 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_53, na_54) }; if tmp1 {
		var root_58 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = f__1; var arg_62 any = xs__7; if linked_59 == nil { return ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { return linked_59.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) } } else {
//line :71:1
			var res__11 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref()).Ref(); var last_i__12 any; var root_63 any = A_arbace_j2g_model_A_const_24.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_65 lang.IFn


			if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = order__10; if linked_64 == nil { last_i__12 = ifn_65.Invoke_O__O(arg_66) } else { last_i__12 = linked_64.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_63, arg_66) }
//line :71:1
			var ___13 any; var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(res__11); var tmp3 int32 = lang.RT_IntCast_O__I_NoInit(last_i__12); var tmp4 any; var root_67 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_69 lang.IFn; _ = ___13



			if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var root_71 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var fnbody__82 any = A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O_O_O(f__1, last_i__12, xs__7); var tmp5 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__82); A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class = fncls__81d; tmp5 = fncls__81d } else { tmp5 = fncls__81 }; arg_74 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp5, nil); if linked_72 == nil { arg_70 = ifn_73.Invoke_O__O(arg_74) } else { arg_70 = linked_72.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_71, arg_74) }; if linked_68 == nil { tmp4 = ifn_69.Invoke_O__O(arg_70) } else { tmp4 = linked_68.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_67, arg_70) }; ___13 = lang.RT_Aset_O1_I_O__O_NoInit(tmp2, tmp3, tmp4)
//line :71:1
			var next_i__14 any; var root_83 any = A_arbace_j2g_model_A_const_27.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_85 lang.IFn




			if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = A_arbace_j2g_model_A_const_28; if linked_84 == nil { next_i__14 = ifn_85.Invoke_O__O(arg_86) } else { next_i__14 = linked_84.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_83, arg_86) }
//line :71:1
			var work__15 any; var fnbody__98 any = A_arbace_j2g_model_par_mapv_work__1479000025_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__14, xs__7, res__11); var tmp6 *jrt.Class
			var fncls__97 /*line :71:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_work__1479000025_A_fn_class





			if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__98); A_arbace_j2g_model_par_mapv_work__1479000025_A_fn_class = fncls__97d; tmp6 = fncls__97d } else { tmp6 = fncls__97 }; work__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp6, nil)
//line :71:1
			var ws__16 any; var root_99 any = A_arbace_j2g_model_A_const_31.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_101 lang.IFn











			if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var root_103 any = A_arbace_j2g_model_A_const_32.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = n__9; var arg_107 any; var fnbody__119 any = A_arbace_j2g_model_par_mapv_fn__1479000027_A_New_O(work__15); var tmp7 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000027_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__119); A_arbace_j2g_model_par_mapv_fn__1479000027_A_fn_class = fncls__118d; tmp7 = fncls__118d } else { tmp7 = fncls__118 }; arg_107 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__119, tmp7, nil); if linked_104 == nil { arg_102 = ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { arg_102 = linked_104.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_103, arg_106, arg_107) }; if linked_100 == nil { ws__16 = ifn_101.Invoke_O__O(arg_102) } else { ws__16 = linked_100.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_99, arg_102) }
			var root_124 any = A_arbace_j2g_model_A_const_33.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var arg_128 any = ws__16; if linked_125 == nil { ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { linked_125.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }
			var root_120 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = res__11; if linked_121 == nil { return ifn_122.Invoke_O__O(arg_123) } else { return linked_121.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_120, arg_123) } } }
//line :75:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :75:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Invoke_O__O(self any) any { var tmp1 any; var root_75 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_j2g_model_run_fn_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any; var fnbody__80 any = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O_O_O(t.F_f, t.F_last_i, t.F_xs); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__80); A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; arg_78 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp2, nil); if linked_76 == nil { tmp1 = ifn_77.Invoke_O__O(arg_78) } else { tmp1 = linked_76.(*A_arbace_j2g_model_run_fn_A).Invoke_O_O__O(root_75, arg_78) }; return lang.IFn_Cast(tmp1).Invoke__O() }
//line :75:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :75:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); var tmp2 any = t.F_xs; return tmp1.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(t.F_last_i))) }

func A_arbace_j2g_model_par_mapv_work__1479000025_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_j2g_model_par_mapv_work__1479000025_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_work__1479000025_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :77:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000025_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :77:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000025_A) Invoke_O__O(self any) any { for { L2: for { var k__1 any; var root_87 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_89 lang.IFn
											if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = t.F_next_i; var arg_91 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); if linked_88 == nil { k__1 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { k__1 = linked_88.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }
											var tmp1 bool; var na_92 any = k__1; var na_93 int64 = lang.Numbers_Dec_J__J_NoInit(int64(t.F_cnt)); if jrt.Long_InstanceOf(na_92) { var n0_94 int64 = jrt.NN(jrt.Long_Cast(na_92)).LongValue__J(); var n1_95 int64 = na_93; tmp1 = n0_94 < n1_95 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_92, na_93) }; if tmp1 { var tmp2 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(k__1)); var tmp3 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_res); var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any = t.F_xs

		lang.RT_Aset_O1_I_O__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(i__2), tmp4.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(i__2))))
		continue L2 } else {
//line :79:1
			return nil } } }; /*line :77:1*/panic("j2g: unreachable") }





func A_arbace_j2g_model_par_mapv_fn__1479000027_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000027_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000027_A{}; t.Ctor_O(p0); return t }
//line :83:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :83:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_A) Invoke_O__O(self any) any { var root_108 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var fnbody__117 any = A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_New_O(t.F_work); var tmp1 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__117); A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_fn_class = fncls__116d; tmp1 = fncls__116d } else { tmp1 = fncls__116 }; arg_111 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__117, tmp1, nil); if linked_109 == nil { return ifn_110.Invoke_O__O(arg_111) } else { return linked_109.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_108, arg_111) } }
//line :83:1
func A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A{}; t.Ctor_O(p0); return t }
//line :83:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :83:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A) Invoke_O__O(self any) any { var tmp1 any; var root_112 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_j2g_model_run_fn_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any; var t_ any = t.F_work; t.F_work = nil; arg_115 = t_; if linked_113 == nil { tmp1 = ifn_114.Invoke_O__O(arg_115) } else { tmp1 = linked_113.(*A_arbace_j2g_model_run_fn_A).Invoke_O_O__O(root_112, arg_115) }; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_j2g_model_has_QMARK__A_New() *A_arbace_j2g_model_has_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_j2g_model_has_QMARK__A) Ctor() {}
//line :89:1
func (t *A_arbace_j2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_129 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var tmp1 int64; var na_133 any; var or__1927000174__auto____3 any = flags__0; if jrt.J2g_Truth(or__1927000174__auto____3) { na_133 = or__1927000174__auto____3 } else { na_133 = A_arbace_j2g_model_A_const_35 }; var na_134 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_133); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_134) }; tmp2 = tmp3; if tmp2 { var n0_135 int64 = jrt.NN(jrt.Long_Cast(na_133)).LongValue__J(); var n1_136 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); tmp1 = n0_135 & n1_136 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_133, na_134) }; arg_132 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_130 == nil { return ifn_131.Invoke_O__O(arg_132) } else { return linked_130.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_129, arg_132) } }

func A_arbace_j2g_model_T_A_New() *A_arbace_j2g_model_T_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_T_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_j2g_model_T_A) Ctor() {}
//line :91:1
func (t *A_arbace_j2g_model_T_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_36; var x__1 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); if lang.IDeref_InstanceOf(x__1) { var root_138 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = x__1; if linked_139 == nil { return ifn_140.Invoke_O__O(arg_141) } else { return linked_139.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_138, arg_141) } } else { return x__1 } }

func A_arbace_j2g_model_translated_QMARK__A_New() *A_arbace_j2g_model_translated_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_142 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_147 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_j2g_model_T_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; if linked_148 == nil { arg_145 = ifn_149.Invoke__O() } else { arg_145 = linked_148.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_147) }; var arg_146 any = n__0; if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } }

















func A_arbace_j2g_model_serial_accessor_bases_A_New() *A_arbace_j2g_model_serial_accessor_bases_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_accessor_bases_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_j2g_model_serial_accessor_bases_A) Ctor() {}
//line :111:1
func (t *A_arbace_j2g_model_serial_accessor_bases_A) Invoke_O_O__O(self, i__0 any) any { var s__2 any; var root_150 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_152 lang.IFn; if


	linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = i__0; var arg_154 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(i__0)).LastIndexOf_String__I(Lit_1)))).Ref(); if linked_151 == nil { s__2 = ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { s__2 = linked_151.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_150, arg_153, arg_154) }; return /*line :111:1*/ lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__2, nil, s__2)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil, Lit_45, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, nil, s__2, nil, s__2, nil)).Ref()) }





func A_arbace_j2g_model_j2g_static_QMARK__A_New() *A_arbace_j2g_model_j2g_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var or__1927000174__auto____3 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_62); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(base__1, Lit_63); if and__1927000168__auto____4 {
		var root_155 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = Lit_64; if linked_156 == nil { or__1927000174__auto____3 = ifn_157.Invoke_O__O(arg_158) } else { or__1927000174__auto____3 = linked_156.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_155, arg_158) } } else {
//line :124:1
			or__1927000174__auto____3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { or__1927000174__auto____3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var and__1927000168__auto____4_2 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_65)

				if and__1927000168__auto____4_2 { var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(base__1, Lit_66); if and__1927000168__auto____5 {
					var root_159 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = Lit_67; if linked_160 == nil { or__1927000174__auto____4 = ifn_161.Invoke_O__O(arg_162) } else { or__1927000174__auto____4 = linked_160.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_159, arg_162) } } else {
//line :126:1
						or__1927000174__auto____4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { or__1927000174__auto____4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }
//line :124:1
				if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_68)



					if and__1927000168__auto____5_2 {
						var tmp1 any; var root_163 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var fnbody__182 any = A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A_New_O(base__1); var tmp2 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__182); A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A_fn_class = fncls__181d; tmp2 = fncls__181d } else { tmp2 = fncls__181 }; arg_166 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__182, tmp2, nil); var arg_167 any; var root_183 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_185 lang.IFn
						if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); if linked_184 == nil { arg_167 = ifn_185.Invoke_O__O(arg_186) } else { arg_167 = linked_184.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_183, arg_186) }
//line :129:1
						if linked_164 == nil { tmp1 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { tmp1 = linked_164.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } else {
//line :128:1
							return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() } } } }
func A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A_New_O(p0 any) *A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :129:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A) Invoke_O_O__O(self, i__1 any) any { var and__1927000168__auto____2 any; var root_168 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = i__1; if linked_169 == nil { and__1927000168__auto____2 = ifn_170.Invoke_O__O(arg_171) } else { and__1927000168__auto____2 = linked_169.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_168, arg_171) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_172 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, t.F_base)); var arg_176 any; var root_177 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_j2g_model_serial_accessor_bases_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = i__1; if linked_178 == nil { arg_176 = ifn_179.Invoke_O__O(arg_180) } else { arg_176 = linked_178.(*A_arbace_j2g_model_serial_accessor_bases_A).Invoke_O_O__O(root_177, arg_180) }; if linked_173 == nil { return ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { return linked_173.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_jrt_class_A_New() *A_arbace_j2g_model_jrt_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_model_jrt_class_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()), n__0)
}
func A_arbace_j2g_model_hand_written_QMARK__A_New() *A_arbace_j2g_model_hand_written_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Ctor() {}
//line :137:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_187 any = A_arbace_j2g_model_A_const_47.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_189 lang.IFn; if


	linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = n__0; if linked_188 == nil { and__1927000168__auto____2 = ifn_189.Invoke_O__O(arg_190) } else { and__1927000168__auto____2 = linked_188.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_187, arg_190) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_191 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any; var root_195 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = n__0; if linked_196 == nil { arg_194 = ifn_197.Invoke_O__O(arg_198) } else { arg_194 = linked_196.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_195, arg_198) }; if linked_192 == nil { return ifn_193.Invoke_O__O(arg_194) } else { return linked_192.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_191, arg_194) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_in_world_QMARK__A_New() *A_arbace_j2g_model_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Ctor() {}
//line :142:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_44); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var root_199 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = n__0; if linked_200 == nil { or__1927000174__auto____3 = ifn_201.Invoke_O__O(arg_202) } else { or__1927000174__auto____3 = linked_200.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_199, arg_202) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_203 any = A_arbace_j2g_model_A_const_47.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = n__0; if linked_204 == nil { tmp1 = ifn_205.Invoke_O__O(arg_206) } else { tmp1 = linked_204.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_203, arg_206) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }

func A_arbace_j2g_model_translatable_QMARK__A_New() *A_arbace_j2g_model_translatable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Ctor() {}
//line :145:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var root_207 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = n__0; if linked_208 == nil { tmp1 = ifn_209.Invoke_O__O(arg_210) } else { tmp1 = linked_208.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_207, arg_210) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_reflectable_interface_QMARK__A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_211 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_213 lang.IFn; if




	linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var root_215 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = n__0; if linked_216 == nil { arg_214 = ifn_217.Invoke_O__O(arg_218) } else { arg_214 = linked_216.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_215, arg_218) }; if linked_212 == nil { and__1927000168__auto____2 = ifn_213.Invoke_O__O(arg_214) } else { and__1927000168__auto____2 = linked_212.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_211, arg_214) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_219 any = A_arbace_j2g_model_A_const_49.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_221 lang.IFn
		if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = n__0; var arg_223 any = Lit_93; if linked_220 == nil { or__1927000174__auto____3 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { or__1927000174__auto____3 = linked_220.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_224 any = A_arbace_j2g_model_A_const_49.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = n__0; var arg_228 any = Lit_94; if linked_225 == nil { or__1927000174__auto____4 = ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { or__1927000174__auto____4 = linked_225.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_224, arg_227, arg_228) }; if jrt.J2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_229 any = A_arbace_j2g_model_A_const_49.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = n__0; var arg_233 any = Lit_95; if linked_230 == nil { or__1927000174__auto____5 = ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { or__1927000174__auto____5 = linked_230.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_229, arg_232, arg_233) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_234 any = A_arbace_j2g_model_A_const_49.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = n__0; var arg_238 any = Lit_96; if linked_235 == nil { or__1927000174__auto____6 = ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { or__1927000174__auto____6 = linked_235.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_234, arg_237, arg_238) }; if jrt.J2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			var root_239 any = A_arbace_j2g_model_A_const_49.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = n__0; var arg_243 any = Lit_97; if linked_240 == nil { and__1927000168__auto____3 = ifn_241.Invoke_O_O__O(arg_242, arg_243) } else { and__1927000168__auto____3 = linked_240.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_239, arg_242, arg_243) } } } } }
//line :155:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_244 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_246 lang.IFn


			if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any; var root_248 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = n__0; var arg_252 any = Lit_98; if linked_249 == nil { arg_247 = ifn_250.Invoke_O_O__O(arg_251, arg_252) } else { arg_247 = linked_249.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_248, arg_251, arg_252) }; if linked_245 == nil { and__1927000168__auto____4 = ifn_246.Invoke_O__O(arg_247) } else { and__1927000168__auto____4 = linked_245.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_244, arg_247) }
//line :155:1
			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_253 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_255 lang.IFn



				if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = n__0; if linked_258 == nil { arg_256 = ifn_259.Invoke_O__O(arg_260) } else { arg_256 = linked_258.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_257, arg_260) }; if linked_254 == nil { and__1927000168__auto____5 = ifn_255.Invoke_O__O(arg_256) } else { and__1927000168__auto____5 = linked_254.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_253, arg_256) }
//line :155:1
				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_261 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_263 lang.IFn




					if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = n__0; if linked_262 == nil { and__1927000168__auto____6 = ifn_263.Invoke_O__O(arg_264) } else { and__1927000168__auto____6 = linked_262.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_261, arg_264) }
//line :155:1
					if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_265 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_267 lang.IFn






						if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any; var root_269 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_55; var tmp2 any; var root_274 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = n__0; if linked_275 == nil { tmp2 = ifn_276.Invoke_O__O(arg_277) } else { tmp2 = linked_275.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_274, arg_277) }; arg_272 = tmp1.Invoke_O__O(tmp2); var arg_273 any = A_arbace_j2g_model_A_const_56; if linked_270 == nil { arg_268 = ifn_271.Invoke_O_O__O(arg_272, arg_273) } else { arg_268 = linked_270.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_269, arg_272, arg_273) }; if linked_266 == nil { and__1927000168__auto____7 = ifn_267.Invoke_O__O(arg_268) } else { and__1927000168__auto____7 = linked_266.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_265, arg_268) }
//line :155:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_278 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_280 lang.IFn









							if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_58; var tmp4 any; var root_282 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = n__0; if linked_283 == nil { tmp4 = ifn_284.Invoke_O__O(arg_285) } else { tmp4 = linked_283.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_282, arg_285) }; arg_281 = tmp3.Invoke_O__O(tmp4); if linked_279 == nil { and__1927000168__auto____8 = ifn_280.Invoke_O__O(arg_281) } else { and__1927000168__auto____8 = linked_279.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_278, arg_281) }
//line :155:1
							if jrt.J2g_Truth(and__1927000168__auto____8) {










								var root_286 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any; var fnbody__300 any = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A_New(); var tmp5 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A_fn_class = fncls__299d; tmp5 = fncls__299d } else { tmp5 = fncls__299 }; arg_289 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__300, tmp5, nil); var arg_290 any; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_62; var tmp7 any; var root_301 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = n__0; if linked_302 == nil { tmp7 = ifn_303.Invoke_O__O(arg_304) } else { tmp7 = linked_302.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_301, arg_304) }; arg_290 = tmp6.Invoke_O__O(tmp7); if linked_287 == nil { return ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { return linked_287.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_286, arg_289, arg_290) } } else {
//line :155:1
									return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A) Ctor() {}
//line :166:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A) Invoke_O_O__O(self, p1__1479000043_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_291 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = p1__1479000043_SHARP___1; if linked_292 == nil { or__1927000174__auto____2 = ifn_293.Invoke_O__O(arg_294) } else { or__1927000174__auto____2 = linked_292.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_291, arg_294) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_295 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = p1__1479000043_SHARP___1; if linked_296 == nil { return ifn_297.Invoke_O__O(arg_298) } else { return linked_296.(*A_arbace_j2g_model_reflectable_interface_QMARK__A).Invoke_O_O__O(root_295, arg_298) } } }

func A_arbace_j2g_model_reflected_QMARK__A_New() *A_arbace_j2g_model_reflected_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Ctor() {}
//line :168:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_305 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_307 lang.IFn; if


	linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = n__0; if linked_306 == nil { and__1927000168__auto____2 = ifn_307.Invoke_O__O(arg_308) } else { and__1927000168__auto____2 = linked_306.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_305, arg_308) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_309 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var root_313 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = n__0; if linked_314 == nil { arg_312 = ifn_315.Invoke_O__O(arg_316) } else { arg_312 = linked_314.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_313, arg_316) }; if linked_310 == nil { return ifn_311.Invoke_O__O(arg_312) } else { return linked_310.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_309, arg_312) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_info_A_New() *A_arbace_j2g_model_info_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_info_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_model_info_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { var root_317 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = n__0; if linked_318 == nil { return ifn_319.Invoke_O__O(arg_320) } else { return linked_318.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_317, arg_320) } }
func A_arbace_j2g_model_interface_QMARK__A_New() *A_arbace_j2g_model_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Ctor() {}
//line :174:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_321 any = A_arbace_j2g_model_A_const_53.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = n__0; if linked_322 == nil { return ifn_323.Invoke_O__O(arg_324) } else { return linked_322.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_321, arg_324) } }

func A_arbace_j2g_model_desc_classes_A_New() *A_arbace_j2g_model_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_model_desc_classes_A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(d__0, nil) { return nil } else { var tmp1 any; var root_325 any = A_arbace_j2g_model_A_const_63.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_327 lang.IFn
		if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = d__0; if linked_326 == nil { tmp1 = ifn_327.Invoke_O__O(arg_328) } else { tmp1 = linked_326.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_325, arg_328) }
//line :179:1
		if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var root_329 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_331 lang.IFn

			if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = d__0; if linked_330 == nil { tmp2 = ifn_331.Invoke_O__O(arg_332) } else { tmp2 = linked_330.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_329, arg_332) }
//line :179:1
			if jrt.J2g_Truth(tmp2) {

				var root_333 any = A_arbace_j2g_model_A_const_65.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_337 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = d__0; var arg_341 any; var root_342 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = d__0; if linked_343 == nil { arg_341 = ifn_344.Invoke_O__O(arg_345) } else { arg_341 = linked_343.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_342, arg_345) }; if linked_338 == nil { arg_336 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { arg_336 = linked_338.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; if linked_334 == nil { return ifn_335.Invoke_O__O(arg_336) } else { return linked_334.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_333, arg_336) } } else {
//line :179:1
					var tmp3 any; var root_346 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_348 lang.IFn


					if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = d__0; if linked_347 == nil { tmp3 = ifn_348.Invoke_O__O(arg_349) } else { tmp3 = linked_347.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_346, arg_349) }
//line :179:1
					if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_350 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_352 lang.IFn


						if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = d__0; if linked_351 == nil { tmp4 = ifn_352.Invoke_O__O(arg_353) } else { tmp4 = linked_351.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_350, arg_353) }
//line :179:1
						return lang.Tuple_Create_O__IPersistentVector(tmp4) } else { if A_arbace_j2g_model_A_const_68 != nil { return nil } else { return nil
						}
						}
				}
		}
	}
}



func A_arbace_j2g_model_method_desc_classes_A_New() *A_arbace_j2g_model_method_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_354 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_356 lang.IFn; if
											linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = desc__0; if linked_355 == nil { tmp1 = ifn_356.Invoke_O__O(arg_357) } else { tmp1 = linked_355.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_354, arg_357) }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____2 = jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_71.GetRawRoot__O()).Get_O__O(desc__0) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var vec__1479000051__3 any; var root_358 any = A_arbace_j2g_model_A_const_72.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_360 lang.IFn
												if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = desc__0; if linked_359 == nil { vec__1479000051__3 = ifn_360.Invoke_O__O(arg_361) } else { vec__1479000051__3 = linked_359.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_358, arg_361) }
//line :190:1
		var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000051__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000051__3, lang.RT_IntCast_J__I_NoInit(1), nil); var v__6 any; var root_362 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_364 lang.IFn

		if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_73.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_A_const_65.GetRawRoot__O(); var tmp4 any; var root_371 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = r__5; var arg_375 any = ps__4; if linked_372 == nil { tmp4 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { tmp4 = linked_372.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; arg_365 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_363 == nil { v__6 = ifn_364.Invoke_O__O(arg_365) } else { v__6 = linked_363.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_362, arg_365) }
		var tmp5 any; var root_376 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = desc__0; if linked_377 == nil { tmp5 = ifn_378.Invoke_O__O(arg_379) } else { tmp5 = linked_377.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_376, arg_379) }; if jrt.J2g_Truth(tmp5) { jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_71.GetRawRoot__O()).Put_O_O__O(desc__0, v__6) }
//line :190:1
		return v__6 } }





func A_arbace_j2g_model_erased_desc_QMARK__A_New() *A_arbace_j2g_model_erased_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Ctor() {}
//line :196:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_380 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_382 lang.IFn; if




	linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = d__0; if linked_381 == nil { and__1927000168__auto____2 = ifn_382.Invoke_O__O(arg_383) } else { and__1927000168__auto____2 = linked_381.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_380, arg_383) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__393 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__392 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A_fn_class
		if fncls__392 == nil { var fncls__392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__393); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A_fn_class = fncls__392d; tmp2 = fncls__392d } else { tmp2 = fncls__392 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__393, tmp2, nil); e__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :201:1
		var and__1927000168__auto____4 any; var root_394 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_396 lang.IFn

		if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = e__3; if linked_395 == nil { and__1927000168__auto____4 = ifn_396.Invoke_O__O(arg_397) } else { and__1927000168__auto____4 = linked_395.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_394, arg_397) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var n__5 any; var root_398 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_400 lang.IFn
			if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = e__3; if linked_399 == nil { n__5 = ifn_400.Invoke_O__O(arg_401) } else { n__5 = linked_399.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_398, arg_401) }
//line :203:1
			var and__1927000168__auto____6 any; var root_402 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_404 lang.IFn

			if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_406 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = n__5; if linked_407 == nil { arg_405 = ifn_408.Invoke_O__O(arg_409) } else { arg_405 = linked_407.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_406, arg_409) }; if linked_403 == nil { and__1927000168__auto____6 = ifn_404.Invoke_O__O(arg_405) } else { and__1927000168__auto____6 = linked_403.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_402, arg_405) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
				var root_410 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var fnbody__421 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A_New_O(n__5); var tmp3 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A_fn_class; if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__421); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A_fn_class = fncls__420d; tmp3 = fncls__420d } else { tmp3 = fncls__420 }; arg_413 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__421, tmp3, nil); var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_76; var arg_414 any = tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); if linked_411 == nil { return ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { return linked_411.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) } } else {
//line :205:1
					return and__1927000168__auto____6 } } else {
//line :203:1
						return and__1927000168__auto____4 } } else {
//line :201:1
							return and__1927000168__auto____2 } }
func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :202:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { var tmp1 any; var root_384 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = d__1; if linked_385 == nil { tmp1 = ifn_386.Invoke_O__O(arg_387) } else { tmp1 = linked_385.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_384, arg_387) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_388 any = A_arbace_j2g_model_A_const_75.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = d__1; if linked_389 == nil { tmp2 = ifn_390.Invoke_O__O(arg_391) } else { tmp2 = linked_389.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_388, arg_391) }; d__1 = tmp2; continue L1 } else { return d__1 } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A{}; t.Ctor_O(p0); return t }
//line :206:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :206:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A) Invoke_O_O__O(self, p1__1479000055_SHARP___1 any) any { var root_415 any = A_arbace_j2g_model_A_const_49.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = t.F_n; var arg_419 any = p1__1479000055_SHARP___1; if linked_416 == nil { return ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { return linked_416.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_415, arg_418, arg_419) } }

func A_arbace_j2g_model_desc_in_world_QMARK__A_New() *A_arbace_j2g_model_desc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :208:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var root_422 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var arg_426 any; var root_427 any = A_arbace_j2g_model_A_const_65.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = d__0; if linked_428 == nil { arg_426 = ifn_429.Invoke_O__O(arg_430) } else { arg_426 = linked_428.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_427, arg_430) }; if linked_423 == nil { return ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { return linked_423.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_422, arg_425, arg_426) } }
func A_arbace_j2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_j2g_model_mdesc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { var root_431 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var arg_435 any; var root_436 any = A_arbace_j2g_model_A_const_77.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_j2g_model_method_desc_classes_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = desc__0; if linked_437 == nil { arg_435 = ifn_438.Invoke_O__O(arg_439) } else { arg_435 = linked_437.(*A_arbace_j2g_model_method_desc_classes_A).Invoke_O_O__O(root_436, arg_439) }; if linked_432 == nil { return ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { return linked_432.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_431, arg_434, arg_435) } }




func A_arbace_j2g_model_go_name_A_New() *A_arbace_j2g_model_go_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_name_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_j2g_model_go_name_A) Ctor() {}
//line :214:1
func (t *A_arbace_j2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; if




	jrt.J2g_Truth(A_arbace_j2g_model_A_const_37.Get__O()) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2; var tmp2 any; var root_440 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_442 lang.IFn
			if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = n__0; if linked_441 == nil { tmp2 = ifn_442.Invoke_O__O(arg_443) } else { tmp2 = linked_441.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_440, arg_443) }; if jrt.J2g_Truth(tmp2) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = A_arbace_j2g_model_A_const_78.Invoke_O__O(jc__3) } } else {
//line :220:1
				or__1927000174__auto____2 = nil } } else {
//line :219:1
					or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						var root_444 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = n__0; if linked_445 == nil { return ifn_446.Invoke_O__O(arg_447) } else { return linked_445.(*aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_444, arg_447) } } }
func A_arbace_j2g_model_pkg_A_New() *A_arbace_j2g_model_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pkg_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_j2g_model_pkg_A) Ctor() {}
//line :223:1
func (t *A_arbace_j2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { var root_448 any = A_arbace_j2g_model_A_const_80.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = n__0; if linked_449 == nil { return ifn_450.Invoke_O__O(arg_451) } else { return linked_449.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_448, arg_451) } }

func A_arbace_j2g_model_abstract_QMARK__A_New() *A_arbace_j2g_model_abstract_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Ctor() {}
//line :225:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_452 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_55; var tmp2 any; var root_457 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, A_arbace_j2g_model_info_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = n__0; if linked_458 == nil { tmp2 = ifn_459.Invoke_O__O(arg_460) } else { tmp2 = linked_458.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_457, arg_460) }; arg_455 = tmp1.Invoke_O__O(tmp2); var arg_456 any = A_arbace_j2g_model_A_const_82; if linked_453 == nil { return ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { return linked_453.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_452, arg_455, arg_456) } }
func A_arbace_j2g_model_final_QMARK__A_New() *A_arbace_j2g_model_final_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_j2g_model_final_QMARK__A) Ctor() {}
//line :226:1
func (t *A_arbace_j2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_461 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_55; var tmp2 any; var root_466 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, A_arbace_j2g_model_info_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = n__0; if linked_467 == nil { tmp2 = ifn_468.Invoke_O__O(arg_469) } else { tmp2 = linked_467.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_466, arg_469) }; arg_464 = tmp1.Invoke_O__O(tmp2); var arg_465 any = A_arbace_j2g_model_A_const_83; if linked_462 == nil { return ifn_463.Invoke_O_O__O(arg_464, arg_465) } else { return linked_462.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_461, arg_464, arg_465) } }

func A_arbace_j2g_model_subclasses_A_New() *A_arbace_j2g_model_subclasses_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_subclasses_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_j2g_model_subclasses_A) Ctor() {}
//line :228:1
func (t *A_arbace_j2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_84; return lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O())).Invoke__O(), n__0)
}
func A_arbace_j2g_model_make_subclass_index_A_New() *A_arbace_j2g_model_make_subclass_index_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Ctor() {}
//line :233:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any; var root_470 any = A_arbace_j2g_model_A_const_27.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_472 lang.IFn; if
											linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; if linked_471 == nil { cache__2 = ifn_472.Invoke_O__O(arg_473) } else { cache__2 = linked_471.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_470, arg_473) }; var fnbody__534 any =
											A_arbace_j2g_model_make_subclass_index_fn__1479000068_A_New_O_O(cache__2, w__0); var tmp1 *jrt.Class; var fncls__533 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000068_A_fn_class; if fncls__533 == nil { var fncls__533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__534); A_arbace_j2g_model_make_subclass_index_fn__1479000068_A_fn_class = fncls__533d; tmp1 = fncls__533d } else { tmp1 = fncls__533 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__534, tmp1, nil) }
//line :235:1
func A_arbace_j2g_model_make_subclass_index_fn__1479000068_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000068_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000068_A{}; t.Ctor_O_O(p0, p1); return t }
//line :235:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000068_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :235:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000068_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_474 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_476 lang.IFn; if
												linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = t.F_cache; if linked_475 == nil { or__1927000174__auto____1 = ifn_476.Invoke_O__O(arg_477) } else { or__1927000174__auto____1 = linked_475.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_474, arg_477) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var root_478 any = A_arbace_j2g_model_A_const_85.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = t.F_cache; var arg_482 any; var root_524 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_526 lang.IFn
													if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_37, t.F_w); if linked_525 == nil { ifn_526.Invoke_O__O(arg_527) } else { linked_525.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_524, arg_527) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__523 any = A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A_New_O(t.F_w); var tmp2 *jrt.Class; var fncls__522 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A_fn_class; if fncls__522 == nil { var fncls__522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__523); A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A_fn_class = fncls__522d; tmp2 = fncls__522d } else { tmp2 = fncls__522 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__523, tmp2, nil); arg_482 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :237:1
		if linked_479 == nil { return ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { return linked_479.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_478, arg_481, arg_482) } } }
func A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A_New_O(p0 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A{}; t.Ctor_O(p0); return t }
//line :238:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :238:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var root_483 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var fnbody__506 any = A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A_New(); var tmp2 *jrt.Class; var fncls__505 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A_fn_class; if fncls__505 == nil { var fncls__505d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A_fn_class = fncls__505d; tmp2 = fncls__505d } else { tmp2 = fncls__505 }; arg_486 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__506, tmp2, nil); var arg_487 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_488 any; var root_507 any = A_arbace_j2g_model_A_const_90.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_509 lang.IFn


		if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any; var root_512 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_j2g_model_T_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; if linked_513 == nil { arg_510 = ifn_514.Invoke__O() } else { arg_510 = linked_513.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_512) }; var arg_511 any; var root_515 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp4 any; var t_ any = t.F_w; t.F_w = nil; tmp4 = t_; arg_518 = tmp3.Invoke_O__O(tmp4); if linked_516 == nil { arg_511 = ifn_517.Invoke_O__O(arg_518) } else { arg_511 = linked_516.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_515, arg_518) }; if linked_508 == nil { arg_488 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { arg_488 = linked_508.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }
//line :239:1
		if linked_484 == nil { tmp1 = ifn_485.Invoke_O_O_O__O(arg_486, arg_487, arg_488) } else { tmp1 = linked_484.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_483, arg_486, arg_487, arg_488) } }
//line :238:1
	return nil }(); var root_519 any = A_arbace_j2g_model_A_const_91.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; if linked_520 == nil { ifn_521.Invoke__O() } else { linked_520.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_519) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }
func A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A_New() *A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A) Ctor() {}
//line :239:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var s__3 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_87; var tmp2 any; var root_489 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, A_arbace_j2g_model_info_A_fn_class); var ifn_491 lang.IFn; if
																		linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = c__2; if linked_490 == nil { tmp2 = ifn_491.Invoke_O__O(arg_492) } else { tmp2 = linked_490.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_489, arg_492) }; s__3 = tmp1.Invoke_O__O(tmp2); if
																		jrt.J2g_Truth(s__3) { var root_493 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = m__1; var arg_497 any = s__3; var arg_498 any; var root_500 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = A_arbace_j2g_model_A_const_15.GetRawRoot__O(); var arg_504 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_501 == nil { arg_498 = ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { arg_498 = linked_501.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_500, arg_503, arg_504) }; var arg_499 any = c__2; if linked_494 == nil { return ifn_495.Invoke_O_O_O_O__O(arg_496, arg_497, arg_498, arg_499) } else { return linked_494.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_493, arg_496, arg_497, arg_498, arg_499) } } else { return m__1 } }












































































































func A_arbace_j2g_model_leaf_QMARK__A_New() *A_arbace_j2g_model_leaf_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Ctor() {}
//line :350:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_44) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_535 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_537 lang.IFn

		if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = n__0; if linked_536 == nil { tmp1 = ifn_537.Invoke_O__O(arg_538) } else { tmp1 = linked_536.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_535, arg_538) }
//line :355:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var root_539 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_541 lang.IFn


			if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = n__0; if linked_540 == nil { tmp2 = ifn_541.Invoke_O__O(arg_542) } else { tmp2 = linked_540.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_539, arg_542) }
//line :355:1
			if jrt.J2g_Truth(tmp2) {


				var root_543 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any; var root_547 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_96; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_97; var arg_550 any = tmp3.Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O())); var arg_551 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_42); var tmp6 any; var root_552 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_j2g_model_go_name_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = n__0; if linked_553 == nil { tmp6 = ifn_554.Invoke_O__O(arg_555) } else { tmp6 = linked_553.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_552, arg_555) }; arg_551 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_548 == nil { arg_546 = ifn_549.Invoke_O_O__O(arg_550, arg_551) } else { arg_546 = linked_548.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_547, arg_550, arg_551) }; if linked_544 == nil { return ifn_545.Invoke_O__O(arg_546) } else { return linked_544.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_543, arg_546) } } else {
//line :355:1
					if A_arbace_j2g_model_A_const_68 != nil { var and__1927000168__auto____2 any; var root_556 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_558 lang.IFn



						if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any; var root_560 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, A_arbace_j2g_model_abstract_QMARK__A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = n__0; if linked_561 == nil { arg_559 = ifn_562.Invoke_O__O(arg_563) } else { arg_559 = linked_561.(*A_arbace_j2g_model_abstract_QMARK__A).Invoke_O_O__O(root_560, arg_563) }; if linked_557 == nil { and__1927000168__auto____2 = ifn_558.Invoke_O__O(arg_559) } else { and__1927000168__auto____2 = linked_557.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_556, arg_559) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_564 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any; var root_568 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_j2g_model_subclasses_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = n__0; if linked_569 == nil { arg_567 = ifn_570.Invoke_O__O(arg_571) } else { arg_567 = linked_569.(*A_arbace_j2g_model_subclasses_A).Invoke_O_O__O(root_568, arg_571) }; if linked_565 == nil { and__1927000168__auto____3 = ifn_566.Invoke_O__O(arg_567) } else { and__1927000168__auto____3 = linked_565.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_564, arg_567) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
							var root_572 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_101.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_576 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any; var root_580 any = A_arbace_j2g_model_A_const_102.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = n__0; if linked_581 == nil { arg_579 = ifn_582.Invoke_O__O(arg_583) } else { arg_579 = linked_581.(*A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_580, arg_583) }; if linked_577 == nil { arg_575 = ifn_578.Invoke_O__O(arg_579) } else { arg_575 = linked_577.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_576, arg_579) } } else { arg_575 = and__1927000168__auto____4 }; if linked_573 == nil { return ifn_574.Invoke_O__O(arg_575) } else { return linked_573.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_572, arg_575) } } else {
//line :359:1
								return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :355:1
									return nil
								}
				}
		}
	}
}




func A_arbace_j2g_model_qualify_A_New() *A_arbace_j2g_model_qualify_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_qualify_A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_j2g_model_qualify_A) Ctor() {}
//line :365:1
func (t *A_arbace_j2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z_NoInit(from__0, nil) }; if tmp1 { var root_584 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = ident__2; if linked_585 == nil { return ifn_586.Invoke_O__O(arg_587) } else { return linked_585.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_584, arg_587) } } else { var root_588 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_593 any = A_arbace_j2g_model_A_const_104.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = of__1; if linked_594 == nil { arg_591 = ifn_595.Invoke_O__O(arg_596) } else { arg_591 = linked_594.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A).Invoke_O_O__O(root_593, arg_596) }; var arg_592 any = ident__2; if linked_589 == nil { return ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { return linked_589.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_588, arg_591, arg_592)
	} } }
func A_arbace_j2g_model_class_sym_A_New() *A_arbace_j2g_model_class_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_sym_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_j2g_model_class_sym_A) Ctor() {}
//line :370:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	var root_597 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, A_arbace_j2g_model_qualify_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = from__0; var arg_601 any; var root_603 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, A_arbace_j2g_model_pkg_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = n__1; if linked_604 == nil { arg_601 = ifn_605.Invoke_O__O(arg_606) } else { arg_601 = linked_604.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_603, arg_606) }; var arg_602 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_607 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, A_arbace_j2g_model_go_name_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = n__1; if linked_608 == nil { tmp2 = ifn_609.Invoke_O__O(arg_610) } else { tmp2 = linked_608.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_607, arg_610) }; arg_602 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, suffix__2)).Ref(); if linked_598 == nil { return ifn_599.Invoke_O_O_O__O(arg_600, arg_601, arg_602) } else { return linked_598.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_597, arg_600, arg_601, arg_602) } }
//line :370:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	var root_611 any = A_arbace_j2g_model_A_const_107.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = from__0; var arg_615 any = n__1; var arg_616 any = Lit_18; if linked_612 == nil { return ifn_613.Invoke_O_O_O__O(arg_614, arg_615, arg_616) } else { return linked_612.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_611, arg_614, arg_615, arg_616)
	}
}
func A_arbace_j2g_model_jrt_sym_A_New() *A_arbace_j2g_model_jrt_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_j2g_model_jrt_sym_A) Ctor() {}
//line :375:1
func (t *A_arbace_j2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { var root_617 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, A_arbace_j2g_model_qualify_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = from__0; var arg_621 any = A_arbace_j2g_model_A_const_97; var arg_622 any = ident__1; if linked_618 == nil { return ifn_619.Invoke_O_O_O__O(arg_620, arg_621, arg_622) } else { return linked_618.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_617, arg_620, arg_621, arg_622) } }






func A_arbace_j2g_model_array_test_A_New() *A_arbace_j2g_model_array_test_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_array_test_A{}; t.Ctor(); return t }
//line :382:1
func (t *A_arbace_j2g_model_array_test_A) Ctor() {}
//line :382:1
func (t *A_arbace_j2g_model_array_test_A) Invoke_O_O_O_O_O_O__O(self, from__0, kind__1, x__2, d__3, comp__4 any) any { var e__6 any; var root_623 any = A_arbace_j2g_model_A_const_75.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_625 lang.IFn; if






	linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = d__3; if linked_624 == nil { e__6 = ifn_625.Invoke_O__O(arg_626) } else { e__6 = linked_624.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_623, arg_626) }; var suffix__7 any; if
	lang.Util_Equiv_O_O__Z_NoInit(kind__1, A_arbace_j2g_model_A_const_108) { suffix__7 = Lit_7 } else { suffix__7 = Lit_8 }; var tmp1 any; var root_627 any =
	A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_629 lang.IFn; if
	linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = e__6; if linked_628 == nil { tmp1 = ifn_629.Invoke_O__O(arg_630) } else { tmp1 = linked_628.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_627, arg_630) }; if /*line :391:1*/ jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()); var tmp3 any; var root_631 any = A_arbace_j2g_model_A_const_111.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = from__0; var arg_635 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_112.GetRawRoot__O()).Invoke_O__O(e__6), suffix__7)).Ref(); if linked_632 == nil { tmp3 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { tmp3 = linked_632.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }; return tmp2.Invoke_O_O__O(tmp3, x__2) } else {
//line :391:1
			if lang.Util_Equiv_O_O__Z_NoInit(e__6, Lit_9) {

				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()); var tmp5 any; var root_636 any = A_arbace_j2g_model_A_const_111.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = from__0; var arg_640 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_637 == nil { tmp5 = ifn_638.Invoke_O_O__O(arg_639, arg_640) } else { tmp5 = linked_637.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_636, arg_639, arg_640) }; return tmp4.Invoke_O_O__O(tmp5, x__2) } else {
//line :391:1
					if A_arbace_j2g_model_A_const_68 != nil {


						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()); var tmp7 any; var root_641 any = A_arbace_j2g_model_A_const_111.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = from__0; var arg_645 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_642 == nil { tmp7 = ifn_643.Invoke_O_O__O(arg_644, arg_645) } else { tmp7 = linked_642.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_641, arg_644, arg_645) }; return tmp6.Invoke_O_O_O__O(tmp7, x__2, comp__4) } else {
//line :391:1
							return nil } } } }




func A_arbace_j2g_model_go_type_A_New() *A_arbace_j2g_model_go_type_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_type_A{}; t.Ctor(); return t }
//line :396:1
func (t *A_arbace_j2g_model_go_type_A) Ctor() {}
//line :396:1
func (t *A_arbace_j2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, A_arbace_j2g_model_A_const_113) { return A_arbace_j2g_model_A_const_114 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_115.GetRawRoot__O()).Invoke_O__O(d__1)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_115.GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :399:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_41) { return nil } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_9) { return A_arbace_j2g_model_A_const_116 } else { var tmp1 any; var root_646 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_648 lang.IFn




				if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = d__1; if linked_647 == nil { tmp1 = ifn_648.Invoke_O__O(arg_649) } else { tmp1 = linked_647.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_646, arg_649) }
//line :399:1
				if jrt.J2g_Truth(tmp1) { var e__3 any; var root_650 any = A_arbace_j2g_model_A_const_75.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_652 lang.IFn




					if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = d__1; if linked_651 == nil { e__3 = ifn_652.Invoke_O__O(arg_653) } else { e__3 = linked_651.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_650, arg_653) }
					var tmp2 any; var root_654 any = A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = e__3; if linked_655 == nil { tmp2 = ifn_656.Invoke_O__O(arg_657) } else { tmp2 = linked_655.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_654, arg_657) }; if jrt.J2g_Truth(tmp2) {
						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_122; var tmp5 any; var root_702 any = A_arbace_j2g_model_A_const_111.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = from__0; var arg_706 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_112.GetRawRoot__O()).Invoke_O__O(e__3); if linked_703 == nil { tmp5 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { tmp5 = linked_703.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_A_const_123; var tmp8 any; var root_707 any = A_arbace_j2g_model_A_const_111.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = from__0; var arg_711 any = Lit_11; if linked_708 == nil { tmp8 = ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { tmp8 = linked_708.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_707, arg_710, arg_711) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } } else {
//line :399:1
								var tmp9 any; var root_658 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_660 lang.IFn








								if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = d__1; if linked_659 == nil { tmp9 = ifn_660.Invoke_O__O(arg_661) } else { tmp9 = linked_659.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_658, arg_661) }
//line :399:1
								if jrt.J2g_Truth(tmp9) { var n__3 any; var root_662 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_664 lang.IFn









									if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = d__1; if linked_663 == nil { n__3 = ifn_664.Invoke_O__O(arg_665) } else { n__3 = linked_663.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_662, arg_665) }
									var tmp10 any; var root_666 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_668 lang.IFn
									if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any; var root_670 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = n__3; if linked_671 == nil { arg_669 = ifn_672.Invoke_O__O(arg_673) } else { arg_669 = linked_671.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_670, arg_673) }; if linked_667 == nil { tmp10 = ifn_668.Invoke_O__O(arg_669) } else { tmp10 = linked_667.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_666, arg_669) }
//line :410:1
									if jrt.J2g_Truth(tmp10) { return A_arbace_j2g_model_A_const_117 } else { var tmp11 any; var root_674 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_676 lang.IFn

										if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = n__3; if linked_675 == nil { tmp11 = ifn_676.Invoke_O__O(arg_677) } else { tmp11 = linked_675.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_674, arg_677) }
//line :410:1
										if jrt.J2g_Truth(tmp11) {

											var root_678 any = A_arbace_j2g_model_A_const_107.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = from__0; var arg_682 any = n__3; if linked_679 == nil { return ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { return linked_679.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) } } else {
//line :410:1
												var tmp12 any; var root_683 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_685 lang.IFn


												if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = n__3; if linked_684 == nil { tmp12 = ifn_685.Invoke_O__O(arg_686) } else { tmp12 = linked_684.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_683, arg_686) }
//line :410:1
												if jrt.J2g_Truth(tmp12) {


													var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_110.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_model_A_const_124; var tmp15 any; var root_712 any = A_arbace_j2g_model_A_const_107.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = from__0; var arg_716 any = n__3; if linked_713 == nil { tmp15 = ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { tmp15 = linked_713.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_712, arg_715, arg_716) }; return tmp13.Invoke_O_O__O(tmp14, tmp15) } else {
//line :410:1
														if A_arbace_j2g_model_A_const_68 != nil {



															var root_687 any = A_arbace_j2g_model_A_const_107.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = from__0; var arg_691 any = n__3; var arg_692 any = Lit_42; if linked_688 == nil { return ifn_689.Invoke_O_O_O__O(arg_690, arg_691, arg_692) } else { return linked_688.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_687, arg_690, arg_691, arg_692) } } else {
//line :410:1
																return nil } } } } } else {
//line :399:1
																	if A_arbace_j2g_model_A_const_68 != nil { var tmp16 any; var root_693 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_695 lang.IFn















																		if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_120.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); var arg_697 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_121, d__1)); if linked_694 == nil { tmp16 = ifn_695.Invoke_O_O__O(arg_696, arg_697) } else { tmp16 = linked_694.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_693, arg_696, arg_697) }
//line :399:1
																		panic(jrt.Thrown(jrt.Throwable_Cast(tmp16))) } else { return nil
																		}
																}
							}
			}
			}
		}
	}
}









func A_arbace_j2g_model_pointer_desc_QMARK__A_New() *A_arbace_j2g_model_pointer_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :417:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :417:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_717 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = d__0; if linked_718 == nil { tmp1 = ifn_719.Invoke_O__O(arg_720) } else { tmp1 = linked_718.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_717, arg_720) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_721 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_723 lang.IFn
		if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = d__0; if linked_722 == nil { tmp2 = ifn_723.Invoke_O__O(arg_724) } else { tmp2 = linked_722.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_721, arg_724) }
//line :420:1
		if jrt.J2g_Truth(tmp2) { var n__2 any; var root_725 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_727 lang.IFn
			if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = d__0; if linked_726 == nil { n__2 = ifn_727.Invoke_O__O(arg_728) } else { n__2 = linked_726.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_725, arg_728) }
//line :420:1
			var and__1927000168__auto____3 any; var root_729 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_731 lang.IFn

			if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = n__2; if linked_730 == nil { and__1927000168__auto____3 = ifn_731.Invoke_O__O(arg_732) } else { and__1927000168__auto____3 = linked_730.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_729, arg_732) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_733 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any; var root_737 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = n__2; if linked_738 == nil { arg_736 = ifn_739.Invoke_O__O(arg_740) } else { arg_736 = linked_738.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_737, arg_740) }; if linked_734 == nil { and__1927000168__auto____4 = ifn_735.Invoke_O__O(arg_736) } else { and__1927000168__auto____4 = linked_734.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_733, arg_736) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_741 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = n__2; var arg_745 any = Lit_44; if linked_742 == nil { and__1927000168__auto____5 = ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { and__1927000168__auto____5 = linked_742.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_741, arg_744, arg_745) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_746 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = n__2; if linked_747 == nil { return ifn_748.Invoke_O__O(arg_749) } else { return linked_747.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_746, arg_749) } } else {
//line :422:1
					return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :420:1
						if A_arbace_j2g_model_A_const_68 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
						}
					}
	}
}

func A_arbace_j2g_model_iface_desc_QMARK__A_New() *A_arbace_j2g_model_iface_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :426:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Ctor() {}
//line :426:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_750 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_752 lang.IFn; if


	linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = d__0; if linked_751 == nil { and__1927000168__auto____2 = ifn_752.Invoke_O__O(arg_753) } else { and__1927000168__auto____2 = linked_751.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_750, arg_753) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_754 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = d__0; var arg_758 any = A_arbace_j2g_model_A_const_113; if linked_755 == nil { and__1927000168__auto____3 = ifn_756.Invoke_O_O__O(arg_757, arg_758) } else { and__1927000168__auto____3 = linked_755.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_754, arg_757, arg_758) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_759 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var root_763 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = d__0; if linked_764 == nil { arg_762 = ifn_765.Invoke_O__O(arg_766) } else { arg_762 = linked_764.(*A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_763, arg_766) }; if linked_760 == nil { return ifn_761.Invoke_O__O(arg_762) } else { return linked_760.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_759, arg_762) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_model_static_QMARK__A_New() *A_arbace_j2g_model_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_j2g_model_static_QMARK__A) Ctor() {}
//line :434:1
func (t *A_arbace_j2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_767 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(m__0); var arg_771 any = A_arbace_j2g_model_A_const_128; if linked_768 == nil { return ifn_769.Invoke_O_O__O(arg_770, arg_771) } else { return linked_768.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_767, arg_770, arg_771) } }
func A_arbace_j2g_model_private_QMARK__A_New() *A_arbace_j2g_model_private_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :435:1
func (t *A_arbace_j2g_model_private_QMARK__A) Ctor() {}
//line :435:1
func (t *A_arbace_j2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_772 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(m__0); var arg_776 any = A_arbace_j2g_model_A_const_129; if linked_773 == nil { return ifn_774.Invoke_O_O__O(arg_775, arg_776) } else { return linked_773.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_772, arg_775, arg_776) } }
func A_arbace_j2g_model_abstract_m_QMARK__A_New() *A_arbace_j2g_model_abstract_m_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Ctor() {}
//line :436:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_777 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(m__0); var arg_781 any = A_arbace_j2g_model_A_const_82; if linked_778 == nil { return ifn_779.Invoke_O_O__O(arg_780, arg_781) } else { return linked_778.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_777, arg_780, arg_781) } }

func A_arbace_j2g_model_methods_of_A_New() *A_arbace_j2g_model_methods_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_methods_of_A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_j2g_model_methods_of_A) Ctor() {}
//line :438:1
func (t *A_arbace_j2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_58; var tmp2 any; var root_782 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, A_arbace_j2g_model_info_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = n__0; if linked_783 == nil { tmp2 = ifn_784.Invoke_O__O(arg_785) } else { tmp2 = linked_783.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_782, arg_785) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_j2g_model_fields_of_A_New() *A_arbace_j2g_model_fields_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fields_of_A{}; t.Ctor(); return t }
//line :439:1
func (t *A_arbace_j2g_model_fields_of_A) Ctor() {}
//line :439:1
func (t *A_arbace_j2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_130; var tmp2 any; var root_786 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, A_arbace_j2g_model_info_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = n__0; if linked_787 == nil { tmp2 = ifn_788.Invoke_O__O(arg_789) } else { tmp2 = linked_787.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_786, arg_789) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_find_method_A_New() *A_arbace_j2g_model_find_method_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_A{}; t.Ctor(); return t }
//line :441:1
func (t *A_arbace_j2g_model_find_method_A) Ctor() {}
//line :441:1
func (t *A_arbace_j2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var root_790 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any; var fnbody__796 any = A_arbace_j2g_model_find_method_fn__1479000089_A_New_O_O(name__1, desc__2); var tmp1 *jrt.Class; var fncls__795 *jrt.Class = A_arbace_j2g_model_find_method_fn__1479000089_A_fn_class; if fncls__795 == nil { var fncls__795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__796); A_arbace_j2g_model_find_method_fn__1479000089_A_fn_class = fncls__795d; tmp1 = fncls__795d } else { tmp1 = fncls__795 }; arg_793 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__796, tmp1, nil); var arg_794 any; var root_797 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = n__0; if linked_798 == nil { arg_794 = ifn_799.Invoke_O__O(arg_800) } else { arg_794 = linked_798.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_797, arg_800) }; if linked_791 == nil { return ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { return linked_791.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) } }
//line :442:1
func A_arbace_j2g_model_find_method_fn__1479000089_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_find_method_fn__1479000089_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_fn__1479000089_A{}; t.Ctor_O_O(p0, p1); return t }
//line :442:1
func (t *A_arbace_j2g_model_find_method_fn__1479000089_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :442:1
func (t *A_arbace_j2g_model_find_method_fn__1479000089_A) Invoke_O_O__O(self, p1__1479000088_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_model_A_const_131.Invoke_O__O(p1__1479000088_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_model_A_const_121.Invoke_O__O(p1__1479000088_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1479000088_SHARP___1 } else { return nil } }

func A_arbace_j2g_model_virtual_member_QMARK__A_New() *A_arbace_j2g_model_virtual_member_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :444:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Ctor() {}
//line :444:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any; var root_801 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_803 lang.IFn; if


	linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any; var root_805 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = m__0; if linked_806 == nil { arg_804 = ifn_807.Invoke_O__O(arg_808) } else { arg_804 = linked_806.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_805, arg_808) }; if linked_802 == nil { and__1927000168__auto____2 = ifn_803.Invoke_O__O(arg_804) } else { and__1927000168__auto____2 = linked_802.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_801, arg_804) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_809 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_813 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = m__0; if linked_814 == nil { arg_812 = ifn_815.Invoke_O__O(arg_816) } else { arg_812 = linked_814.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_813, arg_816) }; if linked_810 == nil { and__1927000168__auto____3 = ifn_811.Invoke_O__O(arg_812) } else { and__1927000168__auto____3 = linked_810.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_809, arg_812) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_817 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = Lit_20; var arg_821 any = A_arbace_j2g_model_A_const_131.Invoke_O__O(m__0); if linked_818 == nil { and__1927000168__auto____4 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { and__1927000168__auto____4 = linked_818.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_822 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = Lit_56; var arg_826 any = A_arbace_j2g_model_A_const_131.Invoke_O__O(m__0); if linked_823 == nil { return ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { return linked_823.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_822, arg_825, arg_826) } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_model_supertypes_A_New() *A_arbace_j2g_model_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_supertypes_A{}; t.Ctor(); return t }
//line :454:1
func (t *A_arbace_j2g_model_supertypes_A) Ctor() {}
//line :454:1
func (t *A_arbace_j2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_827 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_j2g_model_info_A_fn_class); var ifn_829 lang.IFn; if
										linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = n__0; if linked_828 == nil { i__2 = ifn_829.Invoke_O__O(arg_830) } else { i__2 = linked_828.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_827, arg_830) }; var root_831 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = A_arbace_j2g_model_A_const_136.GetRawRoot__O(); var arg_835 any; var root_836 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = A_arbace_j2g_model_A_const_87.Invoke_O__O(i__2); var arg_840 any = A_arbace_j2g_model_A_const_62.Invoke_O__O(i__2); if linked_837 == nil { arg_835 = ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { arg_835 = linked_837.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) }; if linked_832 == nil { return ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { return linked_832.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } }

func A_arbace_j2g_model_world_supertypes_A_New() *A_arbace_j2g_model_world_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :457:1
func (t *A_arbace_j2g_model_world_supertypes_A) Ctor() {}
//line :457:1
func (t *A_arbace_j2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	var root_841 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var arg_845 any; var root_846 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, A_arbace_j2g_model_supertypes_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = n__0; if linked_847 == nil { arg_845 = ifn_848.Invoke_O__O(arg_849) } else { arg_845 = linked_847.(*A_arbace_j2g_model_supertypes_A).Invoke_O_O__O(root_846, arg_849) }; if linked_842 == nil { return ifn_843.Invoke_O_O__O(arg_844, arg_845) } else { return linked_842.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_841, arg_844, arg_845)
	} }
func A_arbace_j2g_model_all_supertypes_A_New() *A_arbace_j2g_model_all_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :462:1
func (t *A_arbace_j2g_model_all_supertypes_A) Ctor() {}
//line :462:1
func (t *A_arbace_j2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	var root_850 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var root_854 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var arg_858 any; var root_859 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = n__0; if linked_860 == nil { arg_858 = ifn_861.Invoke_O__O(arg_862) } else { arg_858 = linked_860.(*aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_859, arg_862) }; if linked_855 == nil { arg_853 = ifn_856.Invoke_O_O__O(arg_857, arg_858) } else { arg_853 = linked_855.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_854, arg_857, arg_858) }; if linked_851 == nil { return ifn_852.Invoke_O__O(arg_853) } else { return linked_851.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_850, arg_853)
	}
}

func A_arbace_j2g_model_hw_method_exists_QMARK__A_New() *A_arbace_j2g_model_hw_method_exists_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :471:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :471:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_97; var scan__3 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); var g__4 any; var root_863 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, A_arbace_j2g_model_go_name_A_fn_class); var ifn_865 lang.IFn; if



	linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = n__0; if linked_864 == nil { g__4 = ifn_865.Invoke_O__O(arg_866) } else { g__4 = linked_864.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_863, arg_866) }; var base__5 any; var root_867 any = /*line :471:1*/A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_869 lang.IFn; if




	linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = A_arbace_j2g_model_A_const_131.Invoke_O__O(m__1); var arg_871 any = A_arbace_j2g_model_A_const_121.Invoke_O__O(m__1); if linked_868 == nil { base__5 = ifn_869.Invoke_O_O__O(arg_870, arg_871) } else { base__5 = linked_868.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_867, arg_870, arg_871) }; if
	lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_44) {
		var root_872 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = A_arbace_j2g_model_A_const_141.GetRawRoot__O(); var arg_876 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_131.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_121.Invoke_O__O(m__1)); if linked_873 == nil { return ifn_874.Invoke_O_O__O(arg_875, arg_876) } else { return linked_873.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_872, arg_875, arg_876) } } else {
//line :477:1
			var tmp2 any; var root_877 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_879 lang.IFn

			if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = n__0; if linked_878 == nil { tmp2 = ifn_879.Invoke_O__O(arg_880) } else { tmp2 = linked_878.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_877, arg_880) }
//line :477:1
			if jrt.J2g_Truth(tmp2) { var or__1927000174__auto____6 any; var root_881 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_883 lang.IFn

				if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_886 any = A_arbace_j2g_model_A_const_142.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = scan__3; var arg_890 any = g__4; if linked_887 == nil { arg_884 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { arg_884 = linked_887.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; var arg_885 any = base__5; if linked_882 == nil { or__1927000174__auto____6 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { or__1927000174__auto____6 = linked_882.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					var root_891 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = A_arbace_j2g_model_A_const_143.Invoke_O__O(scan__3); var arg_895 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref(); if linked_892 == nil { return ifn_893.Invoke_O_O__O(arg_894, arg_895) } else { return linked_892.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_891, arg_894, arg_895) } } } else {
//line :477:1
						if A_arbace_j2g_model_A_const_68 != nil { var ms__6 any; var root_896 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_898 lang.IFn




							if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = scan__3; var arg_900 any = g__4; if linked_897 == nil { ms__6 = ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { ms__6 = linked_897.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) }
//line :477:1
							var or__1927000174__auto____7 any; var root_901 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_903 lang.IFn





							if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = ms__6; var arg_905 any = base__5; if linked_902 == nil { or__1927000174__auto____7 = ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { or__1927000174__auto____7 = linked_902.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_901, arg_904, arg_905) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_906 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = ms__6; var arg_910 any; var root_911 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = base__5; if linked_912 == nil { arg_910 = ifn_913.Invoke_O__O(arg_914) } else { arg_910 = linked_912.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_911, arg_914) }; if linked_907 == nil { or__1927000174__auto____8 = ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { or__1927000174__auto____8 = linked_907.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_906, arg_909, arg_910) }; if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								var root_915 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, A_arbace_j2g_model_j2g_method_QMARK__A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = n__0; var arg_919 any = base__5; if linked_916 == nil { return ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { return linked_916.(*A_arbace_j2g_model_j2g_method_QMARK__A).Invoke_O_O_O__O(root_915, arg_918, arg_919) } } } } else {
//line :477:1
									return nil } } } }








func A_arbace_j2g_model_j2g_method_QMARK__A_New() *A_arbace_j2g_model_j2g_method_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_method_QMARK__A{}; t.Ctor(); return t }
//line :486:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Ctor() {}
//line :486:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_59); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_147).Invoke_O__O(base__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_920 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_922 lang.IFn
		if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = Lit_60; if linked_921 == nil { and__1927000168__auto____5 = ifn_922.Invoke_O__O(arg_923) } else { and__1927000168__auto____5 = linked_921.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_920, arg_923) }
//line :493:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_924 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = Lit_61; if linked_925 == nil { return ifn_926.Invoke_O__O(arg_927) } else { return linked_925.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_924, arg_927) } } else {
//line :493:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_member_in_world_QMARK__A_New() *A_arbace_j2g_model_member_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Ctor() {}
//line :496:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any; var root_928 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_930 lang.IFn; if



	linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = A_arbace_j2g_model_A_const_121.Invoke_O__O(m__1); if linked_929 == nil { and__1927000168__auto____3 = ifn_930.Invoke_O__O(arg_931) } else { and__1927000168__auto____3 = linked_929.(*A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_928, arg_931) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_932 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_934 lang.IFn
		if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any; var root_936 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = n__0; if linked_937 == nil { arg_935 = ifn_938.Invoke_O__O(arg_939) } else { arg_935 = linked_937.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_936, arg_939) }; if linked_933 == nil { or__1927000174__auto____4 = ifn_934.Invoke_O__O(arg_935) } else { or__1927000174__auto____4 = linked_933.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_932, arg_935) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_940 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = n__0; var arg_944 any = m__1; if linked_941 == nil { return ifn_942.Invoke_O_O__O(arg_943, arg_944) } else { return linked_941.(*A_arbace_j2g_model_hw_method_exists_QMARK__A).Invoke_O_O_O__O(root_940, arg_943, arg_944) } } } else {
//line :500:1
			return and__1927000168__auto____3 } }


func A_arbace_j2g_model_declared_vmethods_A_New() *A_arbace_j2g_model_declared_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Ctor() {}
//line :503:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var fnbody__1044 any = A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__1043 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A_fn_class; if


	fncls__1043 == nil { var fncls__1043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__1044); A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A_fn_class = fncls__1043d; tmp1 = fncls__1043d } else { tmp1 = fncls__1043 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1044, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_1045 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = n__0; if linked_1046 == nil { tmp3 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp3 = linked_1046.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_1045, arg_1048) }; return tmp2.Invoke_O__O(tmp3) }
//line :506:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A_New_O(p0 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A{}; t.Ctor_O(p0); return t }
//line :506:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :506:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A) Invoke_O_O__O(self, s__1479000100__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1042 any = A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A_New_O_O_O(t.F_n, s__1479000100__1, self); var tmp2 *jrt.Class; var fncls__1041 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A_fn_class; if fncls__1041 == nil { var fncls__1041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__1042); A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A_fn_class = fncls__1041d; tmp2 = fncls__1041d } else { tmp2 = fncls__1041 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1042, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :506:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :506:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A) Ctor_O_O_O(c__n, c__s__1479000100, c__iter__1479000099 any) { t.F_n = c__n; t.F_s__1479000100 = c__s__1479000100; t.F_iter__1479000099 = c__iter__1479000099 }
//line :506:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A) Invoke_O__O(self any) any { { var s__1479000100__1 any; var t_ any = t.F_s__1479000100; t.F_s__1479000100 = nil; s__1479000100__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_945 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = s__1479000100__1; if linked_946 == nil { temp__1927000414__auto____2 = ifn_947.Invoke_O__O(arg_948) } else { temp__1927000414__auto____2 = linked_946.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_945, arg_948) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_949 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = s__1479000100__3; if linked_950 == nil { tmp1 = ifn_951.Invoke_O__O(arg_952) } else { tmp1 = linked_950.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_949, arg_952) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_953 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = s__1479000100__3; if linked_954 == nil { c__1927001037__auto____4 = ifn_955.Invoke_O__O(arg_956) } else { c__1927001037__auto____4 = linked_954.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_953, arg_956) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000102__6 any; var root_957 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_958 == nil { b__1479000102__6 = ifn_959.Invoke_O__O(arg_960) } else { b__1479000102__6 = linked_958.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_957, arg_960) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__982 any = A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A_New_O_O_I_O(b__1479000102__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__981 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A_fn_class; if fncls__981 == nil { var fncls__981d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__982); A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A_fn_class = fncls__981d; tmp3 = fncls__981d } else { tmp3 = fncls__981 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__982, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_983 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any; var root_988 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = b__1479000102__6; if linked_989 == nil { arg_986 = ifn_990.Invoke_O__O(arg_991) } else { arg_986 = linked_989.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_988, arg_991) }; var arg_987 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000099); var tmp5 any; var root_992 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = s__1479000100__3; if linked_993 == nil { tmp5 = ifn_994.Invoke_O__O(arg_995) } else { tmp5 = linked_993.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_992, arg_995) }; arg_987 = tmp4.Invoke_O__O(tmp5); if linked_984 == nil { return ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { return linked_984.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_983, arg_986, arg_987) } } else { var root_996 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var root_1001 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = b__1479000102__6; if linked_1002 == nil { arg_999 = ifn_1003.Invoke_O__O(arg_1004) } else { arg_999 = linked_1002.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1001, arg_1004) }; var arg_1000 any; if linked_997 == nil { return ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { return linked_997.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) } } } else { var m__4 any; var root_1005 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = s__1479000100__3; if linked_1006 == nil { m__4 = ifn_1007.Invoke_O__O(arg_1008) } else { m__4 = linked_1006.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1005, arg_1008) }; var tmp6 any; var root_1009 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_1011 lang.IFn
															if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = m__4; if linked_1010 == nil { tmp6 = ifn_1011.Invoke_O__O(arg_1012) } else { tmp6 = linked_1010.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_1009, arg_1012) }
//line :506:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_1013 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_1015 lang.IFn

		if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = t.F_n; var arg_1017 any = m__4; if linked_1014 == nil { tmp7 = ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { tmp7 = linked_1014.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) }
//line :506:1
		if jrt.J2g_Truth(tmp7) { var root_1018 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any; var root_1023 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1025 lang.IFn


			if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = m__4; var arg_1027 any = A_arbace_j2g_model_A_const_157; var arg_1028 any = t.F_n; if linked_1024 == nil { arg_1021 = ifn_1025.Invoke_O_O_O__O(arg_1026, arg_1027, arg_1028) } else { arg_1021 = linked_1024.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1023, arg_1026, arg_1027, arg_1028) }
//line :506:1
			var arg_1022 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000099); var tmp9 any; var root_1029 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = s__1479000100__3; if linked_1030 == nil { tmp9 = ifn_1031.Invoke_O__O(arg_1032) } else { tmp9 = linked_1030.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1029, arg_1032) }; arg_1022 = tmp8.Invoke_O__O(tmp9); if linked_1019 == nil { return ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { return linked_1019.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) } } else { var tmp10 any; var root_1033 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = s__1479000100__3; if linked_1034 == nil { tmp10 = ifn_1035.Invoke_O__O(arg_1036) } else { tmp10 = linked_1034.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1033, arg_1036) }; s__1479000100__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1037 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = s__1479000100__3; if linked_1038 == nil { tmp11 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp11 = linked_1038.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1037, arg_1040) }; s__1479000100__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :506:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :506:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A) Ctor_O_O_I_O(c__b__1479000102, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000102 = c__b__1479000102; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :506:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A) Invoke_O__O(self any) any { { var i__1479000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000101__1)); var tmp2 any; var root_961 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_963 lang.IFn
																	if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = m__2; if linked_962 == nil { tmp2 = ifn_963.Invoke_O__O(arg_964) } else { tmp2 = linked_962.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_961, arg_964) }
//line :506:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_965 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_967 lang.IFn

		if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = t.F_n; var arg_969 any = m__2; if linked_966 == nil { tmp3 = ifn_967.Invoke_O_O__O(arg_968, arg_969) } else { tmp3 = linked_966.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_965, arg_968, arg_969) }
//line :506:1
		if jrt.J2g_Truth(tmp3) { var root_970 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = t.F_b__1479000102; var arg_974 any; var root_975 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_977 lang.IFn


			if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = m__2; var arg_979 any = A_arbace_j2g_model_A_const_157; var arg_980 any = t.F_n; if linked_976 == nil { arg_974 = ifn_977.Invoke_O_O_O__O(arg_978, arg_979, arg_980) } else { arg_974 = linked_976.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_975, arg_978, arg_979, arg_980) }
//line :506:1
			if linked_971 == nil { ifn_972.Invoke_O_O__O(arg_973, arg_974) } else { linked_971.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_970, arg_973, arg_974) }; i__1479000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000101__1); continue L1 } else { i__1479000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000101__1); continue L1 } } else { i__1479000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000101__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_model_vmethods_A_New() *A_arbace_j2g_model_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_j2g_model_vmethods_A) Ctor() {}
//line :511:1
func (t *A_arbace_j2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_163; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); var or__1927000174__auto____3 any; var tmp2 any; var root_1049 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1051 lang.IFn; if




	linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = cache__2; if linked_1050 == nil { tmp2 = ifn_1051.Invoke_O__O(arg_1052) } else { tmp2 = linked_1050.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1049, arg_1052) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var root_1053 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1055 lang.IFn
		if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any; var fnbody__1088 any = A_arbace_j2g_model_vmethods_fn__1479000110_A_New(); var tmp3 *jrt.Class; var fncls__1087 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000110_A_fn_class; if fncls__1087 == nil { var fncls__1087d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); A_arbace_j2g_model_vmethods_fn__1479000110_A_fn_class = fncls__1087d; tmp3 = fncls__1087d } else { tmp3 = fncls__1087 }; arg_1056 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1088, tmp3, nil); var arg_1057 any; var root_1089 any = A_arbace_j2g_model_A_const_165.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_1091 lang.IFn






		if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; if linked_1090 == nil { arg_1057 = ifn_1091.Invoke__O() } else { arg_1057 = linked_1090.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_1089) }
//line :517:1
		var arg_1058 any; var root_1092 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1094 lang.IFn






		if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = n__0; if linked_1093 == nil { arg_1058 = ifn_1094.Invoke_O__O(arg_1095) } else { arg_1058 = linked_1093.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1092, arg_1095) }
//line :517:1
		if linked_1054 == nil { r__4 = ifn_1055.Invoke_O_O_O__O(arg_1056, arg_1057, arg_1058) } else { r__4 = linked_1054.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1053, arg_1056, arg_1057, arg_1058)
		}






		var root_1096 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = cache__2; var arg_1100 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var arg_1101 any = n__0; var arg_1102 any = r__4; if linked_1097 == nil { ifn_1098.Invoke_O_O_O_O__O(arg_1099, arg_1100, arg_1101, arg_1102) } else { linked_1097.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1096, arg_1099, arg_1100, arg_1101, arg_1102) }
//line :516:1
		return r__4 } }
func A_arbace_j2g_model_vmethods_fn__1479000110_A_New() *A_arbace_j2g_model_vmethods_fn__1479000110_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000110_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000110_A) Ctor() {}
//line :517:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000110_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(c__2, Lit_44) { return acc__1 } else {

		var root_1059 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any; var fnbody__1082 any = A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A_New(); var tmp1 *jrt.Class; var fncls__1081 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A_fn_class; if fncls__1081 == nil { var fncls__1081d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A_fn_class = fncls__1081d; tmp1 = fncls__1081d } else { tmp1 = fncls__1081 }; arg_1062 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1082, tmp1, nil); var arg_1063 any = acc__1; var arg_1064 any; var root_1083 any = A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, A_arbace_j2g_model_declared_vmethods_A_fn_class); var ifn_1085 lang.IFn


		if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = c__2; if linked_1084 == nil { arg_1064 = ifn_1085.Invoke_O__O(arg_1086) } else { arg_1064 = linked_1084.(*A_arbace_j2g_model_declared_vmethods_A).Invoke_O_O__O(root_1083, arg_1086) }
//line :520:1
		if linked_1060 == nil { return ifn_1061.Invoke_O_O_O__O(arg_1062, arg_1063, arg_1064) } else { return linked_1060.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1059, arg_1062, arg_1063, arg_1064) } } }
//line :520:1
func A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A_New() *A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A) Ctor() {}
//line :520:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_131.Invoke_O__O(m__2), A_arbace_j2g_model_A_const_121.Invoke_O__O(m__2)); var tmp1 any; var or__1927000174__auto____4 any; var root_1065 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1067 lang.IFn; if

	linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = acc__1; var arg_1069 any = k__3; if linked_1066 == nil { or__1927000174__auto____4 = ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { or__1927000174__auto____4 = linked_1066.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_1070 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = A_arbace_j2g_model_A_const_141.GetRawRoot__O(); var arg_1074 any = k__3; if linked_1071 == nil { tmp1 = ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { tmp1 = linked_1071.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) } }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_1075 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = acc__1; var arg_1079 any = k__3; var arg_1080 any = m__2; if linked_1076 == nil { return ifn_1077.Invoke_O_O_O__O(arg_1078, arg_1079, arg_1080) } else { return linked_1076.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1075, arg_1078, arg_1079, arg_1080) } } }





func A_arbace_j2g_model_java_type_name_A_New() *A_arbace_j2g_model_java_type_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_java_type_name_A{}; t.Ctor(); return t }
//line :528:1
func (t *A_arbace_j2g_model_java_type_name_A) Ctor() {}
//line :528:1
func (t *A_arbace_j2g_model_java_type_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_1103 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = d__0; if linked_1104 == nil { tmp1 = ifn_1105.Invoke_O__O(arg_1106) } else { tmp1 = linked_1104.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1103, arg_1106) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_70); var tmp3 any; var root_1107 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any; var root_1111 any = A_arbace_j2g_model_A_const_75.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = d__0; if linked_1112 == nil { arg_1110 = ifn_1113.Invoke_O__O(arg_1114) } else { arg_1110 = linked_1112.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1111, arg_1114) }; if linked_1108 == nil { tmp3 = ifn_1109.Invoke_O__O(arg_1110) } else { tmp3 = linked_1108.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1107, arg_1110) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref() } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(d__0))) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_168).Invoke_O__O(d__0) } else {
//line :531:1
			if A_arbace_j2g_model_A_const_68 != nil {


				var root_1115 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any; var root_1121 any = A_arbace_j2g_model_A_const_69.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = d__0; if linked_1122 == nil { arg_1118 = ifn_1123.Invoke_O__O(arg_1124) } else { arg_1118 = linked_1122.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1121, arg_1124) }; var arg_1119 any = Lit_1; var arg_1120 any = Lit_2; if linked_1116 == nil { return ifn_1117.Invoke_O_O_O__O(arg_1118, arg_1119, arg_1120) } else { return linked_1116.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1115, arg_1118, arg_1119, arg_1120) } } else {
//line :531:1
					return nil
				}
		}
	}
}
func A_arbace_j2g_model_abstract_method_error_text_A_New() *A_arbace_j2g_model_abstract_method_error_text_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_method_error_text_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Ctor() {}
//line :536:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Invoke_O_O_O_O__O(self, n__0, owner__1, p__1479000116__2 any) any { var vec__1479000117__4 any = p__1479000116__2; var name__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000117__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000117__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1479000120__7 any; var root_1125 any = A_arbace_j2g_model_A_const_72.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1127 lang.IFn; if



	linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = desc__6; if linked_1126 == nil { vec__1479000120__7 = ifn_1127.Invoke_O__O(arg_1128) } else { vec__1479000120__7 = linked_1126.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1125, arg_1128) }; var ps__8 any = /*line :536:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1479000120__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000120__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,12,s15:Receiver class ns69: does not define or inherit an implementation of the resolved method s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1129 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1131 lang.IFn; if




	linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = n__0; var arg_1133 any = Lit_1; var arg_1134 any = Lit_2; if linked_1130 == nil { tmp2 = ifn_1131.Invoke_O_O_O__O(arg_1132, arg_1133, arg_1134) } else { tmp2 = linked_1130.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1129, arg_1132, arg_1133, arg_1134) }; var tmp3 any = tmp2; var tmp4 any; var root_1135 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1137 lang.IFn; if
	linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = r__9; if linked_1136 == nil { tmp4 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp4 = linked_1136.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1135, arg_1138) }; var tmp5 any = tmp4; var tmp6 any; var root_1139 any = /*line :541:1*/A_arbace_j2g_model_A_const_170.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1141 lang.IFn; if
	linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = Lit_3; var arg_1143 any; var root_1144 any = A_arbace_j2g_model_A_const_171.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var arg_1148 any = ps__8; if linked_1145 == nil { arg_1143 = ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { arg_1143 = linked_1145.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) }; if linked_1140 == nil { tmp6 = ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { tmp6 = linked_1140.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) }; var tmp7 any = tmp6; var tmp8 /*line :541:1*/*jrt.String; if

	jrt.J2g_Truth(owner__1) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil, nil); var tmp10 *jrt.String; var tmp11 any; var root_1149 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = owner__1; if linked_1150 == nil { tmp11 = ifn_1151.Invoke_O__O(arg_1152) } else { tmp11 = linked_1150.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1149, arg_1152) }; if jrt.J2g_Truth(tmp11) { tmp10 = Lit_5 } else { tmp10 = Lit_6 }; var tmp12 any = tmp10.Ref(); var tmp13 any; var root_1153 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = owner__1; var arg_1157 any = Lit_1; var arg_1158 any = Lit_2; if linked_1154 == nil { tmp13 = ifn_1155.Invoke_O_O_O__O(arg_1156, arg_1157, arg_1158) } else { tmp13 = linked_1154.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1153, arg_1156, arg_1157, arg_1158) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13)) } else { tmp8 = nil }; return /*line :541:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, nil, tmp5, nil, name__5, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }



func A_arbace_j2g_model_superclass_chain_A_New() *A_arbace_j2g_model_superclass_chain_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_j2g_model_superclass_chain_A) Ctor() {}
//line :545:1
func (t *A_arbace_j2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1159 any = A_arbace_j2g_model_A_const_172.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_1163 any; var root_1164 any = A_arbace_j2g_model_A_const_173.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any; var fnbody__1174 any = A_arbace_j2g_model_superclass_chain_fn__1479000125_A_New(); var tmp1 *jrt.Class; var fncls__1173 *jrt.Class = A_arbace_j2g_model_superclass_chain_fn__1479000125_A_fn_class; if fncls__1173 == nil { var fncls__1173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_j2g_model_superclass_chain_fn__1479000125_A_fn_class = fncls__1173d; tmp1 = fncls__1173d } else { tmp1 = fncls__1173 }; arg_1167 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1174, tmp1, nil); var arg_1168 any = n__0; if linked_1165 == nil { arg_1163 = ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { arg_1163 = linked_1165.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) }; if linked_1160 == nil { return ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { return linked_1160.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) } }
//line :546:1
func A_arbace_j2g_model_superclass_chain_fn__1479000125_A_New() *A_arbace_j2g_model_superclass_chain_fn__1479000125_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_fn__1479000125_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000125_A) Ctor() {}
//line :546:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000125_A) Invoke_O_O__O(self, p1__1479000124_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_87; var tmp2 any; var root_1169 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, A_arbace_j2g_model_info_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = p1__1479000124_SHARP___1; if linked_1170 == nil { tmp2 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp2 = linked_1170.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1169, arg_1172) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_impl_of_A_New() *A_arbace_j2g_model_impl_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_A{}; t.Ctor(); return t }
//line :548:1
func (t *A_arbace_j2g_model_impl_of_A) Ctor() {}
//line :548:1
func (t *A_arbace_j2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1479000129__1 any) any { var vec__1479000130__3 any = p__1479000129__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000130__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000130__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__1479000130__3; var or__1927000174__auto____7 any; var root_1175 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1177 lang.IFn; _ = k__6; if





	linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any; var fnbody__1251 any = A_arbace_j2g_model_impl_of_fn__1479000133_A_New_O_O_O(name__4, desc__5, n__0); var tmp1 *jrt.Class; var fncls__1250 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000133_A_fn_class; if fncls__1250 == nil { var fncls__1250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1251); A_arbace_j2g_model_impl_of_fn__1479000133_A_fn_class = fncls__1250d; tmp1 = fncls__1250d } else { tmp1 = fncls__1250 }; arg_1178 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1251, tmp1, nil); var arg_1179 any; var root_1252 any = A_arbace_j2g_model_A_const_182.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1254 lang.IFn; if












	linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = n__0; if linked_1253 == nil { arg_1179 = ifn_1254.Invoke_O__O(arg_1255) } else { arg_1179 = linked_1253.(*A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1252, arg_1255) }; if /*line :554:1*/ linked_1176 == nil { or__1927000174__auto____7 = ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { or__1927000174__auto____7 = linked_1176.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var fnbody__1441 any = A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A_New_O_O(name__4, desc__5); var tmp2 *jrt.Class
		var fncls__1440 /*line :554:1*/*jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A_fn_class














		if fncls__1440 == nil { var fncls__1440d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__1441); A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A_fn_class = fncls__1440d; tmp2 = fncls__1440d } else { tmp2 = fncls__1440 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1441, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp4 any; var root_1470 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = n__0; if linked_1471 == nil { tmp4 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp4 = linked_1471.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1470, arg_1473) }; cands__8 = tmp3.Invoke_O__O(tmp4)
//line :554:1
		var cands__9 any; var root_1442 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1444 lang.IFn





















		if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any; var fnbody__1465 any = A_arbace_j2g_model_impl_of_fn__1479000145_A_New_O(cands__8); var tmp5 *jrt.Class; var fncls__1464 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000145_A_fn_class; if fncls__1464 == nil { var fncls__1464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1465); A_arbace_j2g_model_impl_of_fn__1479000145_A_fn_class = fncls__1464d; tmp5 = fncls__1464d } else { tmp5 = fncls__1464 }; arg_1445 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1465, tmp5, nil); var arg_1446 any = cands__8; if linked_1443 == nil { cands__9 = ifn_1444.Invoke_O_O__O(arg_1445, arg_1446) } else { cands__9 = linked_1443.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1442, arg_1445, arg_1446) }
		var root_1466 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = cands__9; if linked_1467 == nil { return ifn_1468.Invoke_O__O(arg_1469) } else { return linked_1467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1466, arg_1469) } } }
//line :554:1
func A_arbace_j2g_model_impl_of_fn__1479000133_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_impl_of_fn__1479000133_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000133_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :554:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000133_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :554:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000133_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var root_1180 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1182 lang.IFn; if
											linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any; var root_1184 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = c__1; if linked_1185 == nil { arg_1183 = ifn_1186.Invoke_O__O(arg_1187) } else { arg_1183 = linked_1185.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1184, arg_1187) }; if linked_1181 == nil { and__1927000168__auto____2 = ifn_1182.Invoke_O__O(arg_1183) } else { and__1927000168__auto____2 = linked_1181.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1180, arg_1183) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1188 any = A_arbace_j2g_model_A_const_174.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = c__1; var arg_1192 any = t.F_name; var arg_1193 any = t.F_desc; if linked_1189 == nil { temp__1927000414__auto____2 = ifn_1190.Invoke_O_O_O__O(arg_1191, arg_1192, arg_1193) } else { temp__1927000414__auto____2 = linked_1189.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1188, arg_1191, arg_1192, arg_1193) } } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any; var root_1194 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1196 lang.IFn
												if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any; var root_1198 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = m__3; if linked_1199 == nil { arg_1197 = ifn_1200.Invoke_O__O(arg_1201) } else { arg_1197 = linked_1199.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1198, arg_1201) }; if linked_1195 == nil { and__1927000168__auto____4 = ifn_1196.Invoke_O__O(arg_1197) } else { and__1927000168__auto____4 = linked_1195.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1194, arg_1197) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1202 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any; var root_1206 any = A_arbace_j2g_model_A_const_175.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = m__3; if linked_1207 == nil { arg_1205 = ifn_1208.Invoke_O__O(arg_1209) } else { arg_1205 = linked_1207.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1206, arg_1209) }; if linked_1203 == nil { and__1927000168__auto____5 = ifn_1204.Invoke_O__O(arg_1205) } else { and__1927000168__auto____5 = linked_1203.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1202, arg_1205) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1210 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1212 lang.IFn
													if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var root_1214 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = m__3; if linked_1215 == nil { arg_1213 = ifn_1216.Invoke_O__O(arg_1217) } else { arg_1213 = linked_1215.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1214, arg_1217) }; if linked_1211 == nil { or__1927000174__auto____6 = ifn_1212.Invoke_O__O(arg_1213) } else { or__1927000174__auto____6 = linked_1211.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1210, arg_1213) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__1, t.F_n)).Ref() } } else {
//line :556:1
				tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

					if lang.Util_Equiv_O_O__Z_NoInit(c__1, Lit_44) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_177, A_arbace_j2g_model_A_const_157, c__1, A_arbace_j2g_model_A_const_178, m__3)) } else { var tmp2 any; var root_1218 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1220 lang.IFn

						if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = c__1; if linked_1219 == nil { tmp2 = ifn_1220.Invoke_O__O(arg_1221) } else { tmp2 = linked_1219.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1218, arg_1221) }
//line :558:1
						if jrt.J2g_Truth(tmp2) { var base__4 any; var root_1222 any = A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1224 lang.IFn


							if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = t.F_name; var arg_1226 any = t.F_desc; if linked_1223 == nil { base__4 = ifn_1224.Invoke_O_O__O(arg_1225, arg_1226) } else { base__4 = linked_1223.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1222, arg_1225, arg_1226) }
//line :558:1
							var ms__5 any; var root_1227 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1229 lang.IFn



							if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_97; var arg_1230 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); var arg_1231 any; var root_1232 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = c__1; if linked_1233 == nil { arg_1231 = ifn_1234.Invoke_O__O(arg_1235) } else { arg_1231 = linked_1233.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1232, arg_1235) }; if linked_1228 == nil { ms__5 = ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { ms__5 = linked_1228.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) }
							var tmp4 any; var root_1236 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = ms__5; var arg_1240 any; var root_1241 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = base__4; if linked_1242 == nil { arg_1240 = ifn_1243.Invoke_O__O(arg_1244) } else { arg_1240 = linked_1242.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_1241, arg_1244) }; if linked_1237 == nil { tmp4 = ifn_1238.Invoke_O_O__O(arg_1239, arg_1240) } else { tmp4 = linked_1237.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1236, arg_1239, arg_1240) }; if jrt.J2g_Truth(tmp4) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_179, A_arbace_j2g_model_A_const_157, c__1, A_arbace_j2g_model_A_const_178, m__3)) } else { var tmp5 any; var root_1245 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1247 lang.IFn
								if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = ms__5; var arg_1249 any = base__4; if linked_1246 == nil { tmp5 = ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { tmp5 = linked_1246.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) }
//line :563:1
								if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_180, A_arbace_j2g_model_A_const_157, c__1, A_arbace_j2g_model_A_const_178, m__3)) } else { if A_arbace_j2g_model_A_const_68 != nil { return nil } else { return nil } } } } else {
//line :558:1
									if A_arbace_j2g_model_A_const_68 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_181, A_arbace_j2g_model_A_const_157, c__1, A_arbace_j2g_model_A_const_178, m__3)) } else { return nil } } } } else {
//line :556:1
										return nil } } else {
//line :555:1
											return nil } }













func A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :569:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :569:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A) Invoke_O_O__O(self, s__1479000136__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1439 any = A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A_New_O_O_O_O(self, t.F_name, t.F_desc, s__1479000136__1); var tmp2 *jrt.Class; var fncls__1438 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A_fn_class; if fncls__1438 == nil { var fncls__1438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__1439); A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A_fn_class = fncls__1438d; tmp2 = fncls__1438d } else { tmp2 = fncls__1438 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1439, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :569:1
func A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :569:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A) Ctor_O_O_O_O(c__iter__1479000135, c__name, c__desc, c__s__1479000136 any) { t.F_iter__1479000135 = c__iter__1479000135; t.F_name = c__name; t.F_desc = c__desc; t.F_s__1479000136 = c__s__1479000136 }
//line :569:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A) Invoke_O__O(self any) any { { var s__1479000136__1 any; var t_ any = t.F_s__1479000136; t.F_s__1479000136 = nil; s__1479000136__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1256 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = s__1479000136__1; if linked_1257 == nil { temp__1927000414__auto____2 = ifn_1258.Invoke_O__O(arg_1259) } else { temp__1927000414__auto____2 = linked_1257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1256, arg_1259) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000136__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1260 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = s__1479000136__3; if linked_1261 == nil { tmp1 = ifn_1262.Invoke_O__O(arg_1263) } else { tmp1 = linked_1261.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1260, arg_1263) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1264 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = s__1479000136__3; if linked_1265 == nil { c__1927001037__auto____4 = ifn_1266.Invoke_O__O(arg_1267) } else { c__1927001037__auto____4 = linked_1265.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1264, arg_1267) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000138__6 any; var root_1268 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1269 == nil { b__1479000138__6 = ifn_1270.Invoke_O__O(arg_1271) } else { b__1479000138__6 = linked_1269.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1268, arg_1271) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1334 any = A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A_New_O_O_O_I_O(b__1479000138__6, t.F_name, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1333 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A_fn_class; if fncls__1333 == nil { var fncls__1333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__1334); A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A_fn_class = fncls__1333d; tmp3 = fncls__1333d } else { tmp3 = fncls__1333 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1334, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1335 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any; var root_1340 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = b__1479000138__6; if linked_1341 == nil { arg_1338 = ifn_1342.Invoke_O__O(arg_1343) } else { arg_1338 = linked_1341.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1340, arg_1343) }; var arg_1339 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000135); var tmp5 any; var root_1344 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1346 lang.IFn; if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any = s__1479000136__3; if linked_1345 == nil { tmp5 = ifn_1346.Invoke_O__O(arg_1347) } else { tmp5 = linked_1345.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1344, arg_1347) }; arg_1339 = tmp4.Invoke_O__O(tmp5); if linked_1336 == nil { return ifn_1337.Invoke_O_O__O(arg_1338, arg_1339) } else { return linked_1336.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1335, arg_1338, arg_1339) } } else { var root_1348 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var root_1353 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = b__1479000138__6; if linked_1354 == nil { arg_1351 = ifn_1355.Invoke_O__O(arg_1356) } else { arg_1351 = linked_1354.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1353, arg_1356) }; var arg_1352 any; if linked_1349 == nil { return ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { return linked_1349.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) } } } else { var c__4 any; var root_1357 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = s__1479000136__3; if linked_1358 == nil { c__4 = ifn_1359.Invoke_O__O(arg_1360) } else { c__4 = linked_1358.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1357, arg_1360) }; var tmp6 any; var root_1361 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1363 lang.IFn
														if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = c__4; if linked_1362 == nil { tmp6 = ifn_1363.Invoke_O__O(arg_1364) } else { tmp6 = linked_1362.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1361, arg_1364) }
//line :569:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_1365 any = A_arbace_j2g_model_A_const_174.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1367 lang.IFn

		if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = c__4; var arg_1369 any = t.F_name; var arg_1370 any = t.F_desc; if linked_1366 == nil { m__5 = ifn_1367.Invoke_O_O_O__O(arg_1368, arg_1369, arg_1370) } else { m__5 = linked_1366.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1365, arg_1368, arg_1369, arg_1370) }
//line :569:1
		var tmp7 any
		var and__1927000168__auto____6 any = m__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1371 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any; var root_1375 any = A_arbace_j2g_model_A_const_175.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = m__5; if linked_1376 == nil { arg_1374 = ifn_1377.Invoke_O__O(arg_1378) } else { arg_1374 = linked_1376.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1375, arg_1378) }; if linked_1372 == nil { and__1927000168__auto____7 = ifn_1373.Invoke_O__O(arg_1374) } else { and__1927000168__auto____7 = linked_1372.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1371, arg_1374) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1379 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any; var root_1383 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = m__5; if linked_1384 == nil { arg_1382 = ifn_1385.Invoke_O__O(arg_1386) } else { arg_1382 = linked_1384.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1383, arg_1386) }; if linked_1380 == nil { and__1927000168__auto____8 = ifn_1381.Invoke_O__O(arg_1382) } else { and__1927000168__auto____8 = linked_1380.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1379, arg_1382) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1387 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any; var root_1391 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = m__5; if linked_1392 == nil { arg_1390 = ifn_1393.Invoke_O__O(arg_1394) } else { arg_1390 = linked_1392.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1391, arg_1394) }; if linked_1388 == nil { tmp7 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp7 = linked_1388.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1387, arg_1390) } } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 }
//line :569:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____6 any; var root_1395 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1397 lang.IFn



			if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any; var root_1399 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = c__4; if linked_1400 == nil { arg_1398 = ifn_1401.Invoke_O__O(arg_1402) } else { arg_1398 = linked_1400.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1399, arg_1402) }; if linked_1396 == nil { or__1927000174__auto____6 = ifn_1397.Invoke_O__O(arg_1398) } else { or__1927000174__auto____6 = linked_1396.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1395, arg_1398) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp8 = or__1927000174__auto____6 } else {
				var root_1403 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_143; var tmp10 *lang.Keyword = A_arbace_j2g_model_A_const_97; var arg_1406 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O())); var arg_1407 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil); var tmp12 any; var root_1408 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = c__4; if linked_1409 == nil { tmp12 = ifn_1410.Invoke_O__O(arg_1411) } else { tmp12 = linked_1409.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1408, arg_1411) }; var tmp13 any = tmp12; var tmp14 any; var root_1412 any = A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = t.F_name; var arg_1416 any = t.F_desc; if linked_1413 == nil { tmp14 = ifn_1414.Invoke_O_O__O(arg_1415, arg_1416) } else { tmp14 = linked_1413.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1412, arg_1415, arg_1416) }; arg_1407 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, tmp14)).Ref(); if linked_1404 == nil { tmp8 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { tmp8 = linked_1404.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) } }
//line :569:1
			if jrt.J2g_Truth(tmp8) { var root_1417 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_183, A_arbace_j2g_model_A_const_157, c__4, A_arbace_j2g_model_A_const_178, m__5)); var arg_1421 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1479000135); var tmp16 any; var root_1422 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = s__1479000136__3; if linked_1423 == nil { tmp16 = ifn_1424.Invoke_O__O(arg_1425) } else { tmp16 = linked_1423.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1422, arg_1425) }; arg_1421 = tmp15.Invoke_O__O(tmp16); if linked_1418 == nil { return ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { return linked_1418.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) } } else { var tmp17 any; var root_1426 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = s__1479000136__3; if linked_1427 == nil { tmp17 = ifn_1428.Invoke_O__O(arg_1429) } else { tmp17 = linked_1427.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1426, arg_1429) }; s__1479000136__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1430 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = s__1479000136__3; if linked_1431 == nil { tmp18 = ifn_1432.Invoke_O__O(arg_1433) } else { tmp18 = linked_1431.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1430, arg_1433) }; s__1479000136__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1434 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = s__1479000136__3; if linked_1435 == nil { tmp19 = ifn_1436.Invoke_O__O(arg_1437) } else { tmp19 = linked_1435.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1434, arg_1437) }; s__1479000136__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :569:1
func A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :569:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A) Ctor_O_O_O_I_O(c__b__1479000138, c__name, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000138 = c__b__1479000138; t.F_name = c__name; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :569:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A) Invoke_O__O(self any) any { { var i__1479000137__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000137__1)); var tmp2 any; var root_1272 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1274 lang.IFn
																if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = c__2; if linked_1273 == nil { tmp2 = ifn_1274.Invoke_O__O(arg_1275) } else { tmp2 = linked_1273.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1272, arg_1275) }
//line :569:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_1276 any = A_arbace_j2g_model_A_const_174.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1278 lang.IFn

		if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = c__2; var arg_1280 any = t.F_name; var arg_1281 any = t.F_desc; if linked_1277 == nil { m__3 = ifn_1278.Invoke_O_O_O__O(arg_1279, arg_1280, arg_1281) } else { m__3 = linked_1277.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1276, arg_1279, arg_1280, arg_1281) }
//line :569:1
		var tmp3 any
		var and__1927000168__auto____4 any = m__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1282 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var root_1286 any = A_arbace_j2g_model_A_const_175.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any = m__3; if linked_1287 == nil { arg_1285 = ifn_1288.Invoke_O__O(arg_1289) } else { arg_1285 = linked_1287.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1286, arg_1289) }; if linked_1283 == nil { and__1927000168__auto____5 = ifn_1284.Invoke_O__O(arg_1285) } else { and__1927000168__auto____5 = linked_1283.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1282, arg_1285) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1290 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any; var root_1294 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = m__3; if linked_1295 == nil { arg_1293 = ifn_1296.Invoke_O__O(arg_1297) } else { arg_1293 = linked_1295.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1294, arg_1297) }; if linked_1291 == nil { and__1927000168__auto____6 = ifn_1292.Invoke_O__O(arg_1293) } else { and__1927000168__auto____6 = linked_1291.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1290, arg_1293) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1298 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any; var root_1302 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = m__3; if linked_1303 == nil { arg_1301 = ifn_1304.Invoke_O__O(arg_1305) } else { arg_1301 = linked_1303.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1302, arg_1305) }; if linked_1299 == nil { tmp3 = ifn_1300.Invoke_O__O(arg_1301) } else { tmp3 = linked_1299.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1298, arg_1301) } } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :569:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____4 any; var root_1306 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1308 lang.IFn



			if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any; var root_1310 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = c__2; if linked_1311 == nil { arg_1309 = ifn_1312.Invoke_O__O(arg_1313) } else { arg_1309 = linked_1311.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1310, arg_1313) }; if linked_1307 == nil { or__1927000174__auto____4 = ifn_1308.Invoke_O__O(arg_1309) } else { or__1927000174__auto____4 = linked_1307.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1306, arg_1309) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else {
				var root_1314 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_143; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_97; var arg_1317 any = tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O())); var arg_1318 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil); var tmp8 any; var root_1319 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = c__2; if linked_1320 == nil { tmp8 = ifn_1321.Invoke_O__O(arg_1322) } else { tmp8 = linked_1320.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1319, arg_1322) }; var tmp9 any = tmp8; var tmp10 any; var root_1323 any = A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = t.F_name; var arg_1327 any = t.F_desc; if linked_1324 == nil { tmp10 = ifn_1325.Invoke_O_O__O(arg_1326, arg_1327) } else { tmp10 = linked_1324.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1323, arg_1326, arg_1327) }; arg_1318 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref(); if linked_1315 == nil { tmp4 = ifn_1316.Invoke_O_O__O(arg_1317, arg_1318) } else { tmp4 = linked_1315.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1314, arg_1317, arg_1318) } }
//line :569:1
			if jrt.J2g_Truth(tmp4) { var root_1328 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = t.F_b__1479000138; var arg_1332 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_183, A_arbace_j2g_model_A_const_157, c__2, A_arbace_j2g_model_A_const_178, m__3)); if linked_1329 == nil { ifn_1330.Invoke_O_O__O(arg_1331, arg_1332) } else { linked_1329.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1328, arg_1331, arg_1332) }; i__1479000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000137__1); continue L1 } else { i__1479000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000137__1); continue L1 } } else { i__1479000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000137__1); continue L1 } } else { i__1479000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000137__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_model_impl_of_fn__1479000145_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000145_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000145_A{}; t.Ctor_O(p0); return t }
//line :576:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000145_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :576:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000145_A) Invoke_O_O__O(self, x__1 any) any { var root_1447 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any; var fnbody__1463 any = A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A_New_O(x__1); var tmp1 *jrt.Class; var fncls__1462 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A_fn_class; if fncls__1462 == nil { var fncls__1462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__1463); A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A_fn_class = fncls__1462d; tmp1 = fncls__1462d } else { tmp1 = fncls__1462 }; arg_1450 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1463, tmp1, nil); var arg_1451 any = t.F_cands; if linked_1448 == nil { return ifn_1449.Invoke_O_O__O(arg_1450, arg_1451) } else { return linked_1448.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1447, arg_1450, arg_1451) } }
//line :576:1
func A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A{}; t.Ctor_O(p0); return t }
//line :576:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :576:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A) Invoke_O_O__O(self, p1__1479000128_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1452 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = A_arbace_j2g_model_A_const_157.Invoke_O__O(p1__1479000128_SHARP___1); var arg_1456 any = A_arbace_j2g_model_A_const_157.Invoke_O__O(t.F_x); if linked_1453 == nil { and__1927000168__auto____2 = ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { and__1927000168__auto____2 = linked_1453.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1457 any = A_arbace_j2g_model_A_const_184.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = A_arbace_j2g_model_A_const_157.Invoke_O__O(p1__1479000128_SHARP___1); var arg_1461 any = A_arbace_j2g_model_A_const_157.Invoke_O__O(t.F_x); if linked_1458 == nil { return ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { return linked_1458.(*aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_serialization_QMARK__A_New() *A_arbace_j2g_model_serialization_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serialization_QMARK__A{}; t.Ctor(); return t }
//line :579:1
func (t *A_arbace_j2g_model_serialization_QMARK__A) Ctor() {}
//line :579:1
func (t *A_arbace_j2g_model_serialization_QMARK__A) Invoke_O__O(self any) any {




	var tmp1 any; var root_1474 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = Lit_107; if linked_1475 == nil { tmp1 = ifn_1476.Invoke_O__O(arg_1477) } else { tmp1 = linked_1475.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1474, arg_1477) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_serializable_QMARK__A_New() *A_arbace_j2g_model_serializable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serializable_QMARK__A{}; t.Ctor(); return t }
//line :586:1
func (t *A_arbace_j2g_model_serializable_QMARK__A) Ctor() {}
//line :586:1
func (t *A_arbace_j2g_model_serializable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var root_1478 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = A_arbace_j2g_model_A_const_185; var arg_1482 any; var root_1483 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = n__0; if linked_1484 == nil { arg_1482 = ifn_1485.Invoke_O__O(arg_1486) } else { arg_1482 = linked_1484.(*aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1483, arg_1486) }; if linked_1479 == nil { tmp1 = ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { tmp1 = linked_1479.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}










func A_arbace_j2g_model_serial_hook_QMARK__A_New() *A_arbace_j2g_model_serial_hook_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_hook_QMARK__A{}; t.Ctor(); return t }
//line :601:1
func (t *A_arbace_j2g_model_serial_hook_QMARK__A) Ctor() {}
//line :601:1
func (t *A_arbace_j2g_model_serial_hook_QMARK__A) Invoke_O_O__O(self, mm__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_186.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_131.Invoke_O__O(mm__0), A_arbace_j2g_model_A_const_121.Invoke_O__O(mm__0))); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var k__3 any = temp__1927000414__auto____2; var and__1927000168__auto____4 any; var root_1487 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1489 lang.IFn
		if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any; var root_1491 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = mm__0; if linked_1492 == nil { arg_1490 = ifn_1493.Invoke_O__O(arg_1494) } else { arg_1490 = linked_1492.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1491, arg_1494) }; if linked_1488 == nil { and__1927000168__auto____4 = ifn_1489.Invoke_O__O(arg_1490) } else { and__1927000168__auto____4 = linked_1488.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1487, arg_1490) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_j2g_model_A_const_187); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1495 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = mm__0; if linked_1496 == nil { return ifn_1497.Invoke_O__O(arg_1498) } else { return linked_1496.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1495, arg_1498) } } } else { return and__1927000168__auto____4 } } else {
//line :604:1
			return nil } }


func A_arbace_j2g_model_serial_field_QMARK__A_New() *A_arbace_j2g_model_serial_field_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_field_QMARK__A{}; t.Ctor(); return t }
//line :607:1
func (t *A_arbace_j2g_model_serial_field_QMARK__A) Ctor() {}
//line :607:1
func (t *A_arbace_j2g_model_serial_field_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var or__1927000174__auto____2 any; var root_1499 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1501 lang.IFn; if




	linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any; var root_1503 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = f__0; if linked_1504 == nil { arg_1502 = ifn_1505.Invoke_O__O(arg_1506) } else { arg_1502 = linked_1504.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1503, arg_1506) }; if linked_1500 == nil { or__1927000174__auto____2 = ifn_1501.Invoke_O__O(arg_1502) } else { or__1927000174__auto____2 = linked_1500.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1499, arg_1502) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_188); return tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_131.Invoke_O__O(f__0)) } }

func A_arbace_j2g_model_java_pkg_A_New() *A_arbace_j2g_model_java_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_java_pkg_A{}; t.Ctor(); return t }
//line :614:1
func (t *A_arbace_j2g_model_java_pkg_A) Ctor() {}
//line :614:1
func (t *A_arbace_j2g_model_java_pkg_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).LastIndexOf_String__I(Lit_1); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_18 } else { var root_1507 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = n__0; var arg_1511 any = A_arbace_j2g_model_A_const_35; var arg_1512 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1508 == nil { return ifn_1509.Invoke_O_O_O__O(arg_1510, arg_1511, arg_1512) } else { return linked_1508.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1507, arg_1510, arg_1511, arg_1512) } } }

func A_arbace_j2g_model_class_access_A_New() *A_arbace_j2g_model_class_access_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_access_A{}; t.Ctor(); return t }
//line :616:1
func (t *A_arbace_j2g_model_class_access_A) Ctor() {}
//line :616:1
func (t *A_arbace_j2g_model_class_access_A) Invoke_O_O__O(self, n__0 any) any { var d__2 any; var root_1513 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1515 lang.IFn; if


	linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = n__0; if linked_1514 == nil { d__2 = ifn_1515.Invoke_O__O(arg_1516) } else { d__2 = linked_1514.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1513, arg_1516) }; var or__1927000174__auto____3 any; var tmp1 any; var and__1927000168__auto____3 any = d__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1517 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = A_arbace_j2g_model_A_const_189; var arg_1521 any = A_arbace_j2g_model_A_const_190.Invoke_O__O(d__2); if linked_1518 == nil { tmp1 = ifn_1519.Invoke_O_O__O(arg_1520, arg_1521) } else { tmp1 = linked_1518.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1517, arg_1520, arg_1521) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____3 = A_arbace_j2g_model_A_const_191.Invoke_O__O(d__2) } else { var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_55; var tmp3 any; var or__1927000174__auto____3_2 any = d__2; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp3 = or__1927000174__auto____3_2 } else { var root_1522 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, A_arbace_j2g_model_info_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = n__0; if linked_1523 == nil { tmp3 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp3 = linked_1523.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1522, arg_1525) } }; or__1927000174__auto____3 = tmp2.Invoke_O__O(tmp3) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return A_arbace_j2g_model_A_const_35 } }

func A_arbace_j2g_model_ctors_of_A_New() *A_arbace_j2g_model_ctors_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_ctors_of_A{}; t.Ctor(); return t }
//line :622:1
func (t *A_arbace_j2g_model_ctors_of_A) Ctor() {}
//line :622:1
func (t *A_arbace_j2g_model_ctors_of_A) Invoke_O_O__O(self, n__0 any) any { var root_1526 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any; var fnbody__1532 any = A_arbace_j2g_model_ctors_of_fn__1479000157_A_New(); var tmp1 *jrt.Class; var fncls__1531 *jrt.Class = A_arbace_j2g_model_ctors_of_fn__1479000157_A_fn_class; if fncls__1531 == nil { var fncls__1531d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_j2g_model_ctors_of_fn__1479000157_A_fn_class = fncls__1531d; tmp1 = fncls__1531d } else { tmp1 = fncls__1531 }; arg_1529 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1532, tmp1, nil); var arg_1530 any; var root_1533 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = n__0; if linked_1534 == nil { arg_1530 = ifn_1535.Invoke_O__O(arg_1536) } else { arg_1530 = linked_1534.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_1533, arg_1536) }; if linked_1527 == nil { return ifn_1528.Invoke_O_O__O(arg_1529, arg_1530) } else { return linked_1527.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1526, arg_1529, arg_1530) } }
//line :622:1
func A_arbace_j2g_model_ctors_of_fn__1479000157_A_New() *A_arbace_j2g_model_ctors_of_fn__1479000157_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_ctors_of_fn__1479000157_A{}; t.Ctor(); return t }
//line :622:1
func (t *A_arbace_j2g_model_ctors_of_fn__1479000157_A) Ctor() {}
//line :622:1
func (t *A_arbace_j2g_model_ctors_of_fn__1479000157_A) Invoke_O_O__O(self, p1__1479000156_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_20, A_arbace_j2g_model_A_const_131.Invoke_O__O(p1__1479000156_SHARP___1))).Ref() }

func A_arbace_j2g_model_super_ctor_accessible_QMARK__A_New() *A_arbace_j2g_model_super_ctor_accessible_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_super_ctor_accessible_QMARK__A{}; t.Ctor(); return t }
//line :624:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__A) Ctor() {}
//line :624:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__A) Invoke_O_O__O(self, cl__0 any) any { var s__2 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_87; var tmp2 any; var root_1537 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, A_arbace_j2g_model_info_A_fn_class); var ifn_1539 lang.IFn; if




	linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = cl__0; if linked_1538 == nil { tmp2 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp2 = linked_1538.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1537, arg_1540) }; s__2 = tmp1.Invoke_O__O(tmp2); var pp__3 int64 = /*line :624:1*/lang.Numbers_Or_J_J__J_NoInit(1, 4); var top__4 any; var fnbody__1551 any = A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A_New(); var tmp3 *jrt.Class; var fncls__1550 *jrt.Class = A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A_fn_class; if






	fncls__1550 == nil { var fncls__1550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A_fn_class = fncls__1550d; tmp3 = fncls__1550d } else { tmp3 = fncls__1550 }; top__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1551, tmp3, nil); if
	lang.Util_Identical_O_O__Z_NoInit(s__2, nil) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(s__2, Lit_44) { return jrt.Boolean_TRUE.Ref() } else { var tmp4 any; var root_1552 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, A_arbace_j2g_model_java_pkg_A_fn_class); var ifn_1554 lang.IFn


		if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = cl__0; if linked_1553 == nil { tmp4 = ifn_1554.Invoke_O__O(arg_1555) } else { tmp4 = linked_1553.(*A_arbace_j2g_model_java_pkg_A).Invoke_O_O__O(root_1552, arg_1555) }
//line :632:1
		var tmp5 any = tmp4; var tmp6 any; var root_1556 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, A_arbace_j2g_model_java_pkg_A_fn_class); var ifn_1558 lang.IFn


		if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = s__2; if linked_1557 == nil { tmp6 = ifn_1558.Invoke_O__O(arg_1559) } else { tmp6 = linked_1557.(*A_arbace_j2g_model_java_pkg_A).Invoke_O_O__O(root_1556, arg_1559) }
//line :632:1
		if lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6) { var or__1927000174__auto____5 bool; var tmp7 any; var root_1560 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1562 lang.IFn


			if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any; var fnbody__1574 any = A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A_New(); var tmp8 *jrt.Class; var fncls__1573 *jrt.Class = A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A_fn_class; if fncls__1573 == nil { var fncls__1573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, nil); A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A_fn_class = fncls__1573d; tmp8 = fncls__1573d } else { tmp8 = fncls__1573 }; arg_1563 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1574, tmp8, nil); var arg_1564 any; var root_1575 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, A_arbace_j2g_model_ctors_of_A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = s__2; if linked_1576 == nil { arg_1564 = ifn_1577.Invoke_O__O(arg_1578) } else { arg_1564 = linked_1576.(*A_arbace_j2g_model_ctors_of_A).Invoke_O_O__O(root_1575, arg_1578) }; if linked_1561 == nil { tmp7 = ifn_1562.Invoke_O_O__O(arg_1563, arg_1564) } else { tmp7 = linked_1561.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1560, arg_1563, arg_1564) }; or__1927000174__auto____5 = lang.RT_BooleanCast_O__Z_NoInit(tmp7); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else {
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(top__4).Invoke_O__O(cl__0), lang.IFn_Cast(top__4).Invoke_O__O(s__2))).Ref() } } else {
//line :632:1
					if A_arbace_j2g_model_A_const_68 != nil { var and__1927000168__auto____5 any; var root_1579 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1581 lang.IFn




						if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any; var root_1584 any = A_arbace_j2g_model_A_const_196.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, A_arbace_j2g_model_class_access_A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = s__2; if linked_1585 == nil { arg_1582 = ifn_1586.Invoke_O__O(arg_1587) } else { arg_1582 = linked_1585.(*A_arbace_j2g_model_class_access_A).Invoke_O_O__O(root_1584, arg_1587) }; var arg_1583 any = jrt.Long_ValueOf_J__Long_NoInit(pp__3).Ref(); if linked_1580 == nil { and__1927000168__auto____5 = ifn_1581.Invoke_O_O__O(arg_1582, arg_1583) } else { and__1927000168__auto____5 = linked_1580.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1579, arg_1582, arg_1583) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
							var tmp9 any; var root_1588 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any; var fnbody__1599 any = A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A_New_J(pp__3); var tmp10 *jrt.Class; var fncls__1598 *jrt.Class = A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A_fn_class; if fncls__1598 == nil { var fncls__1598d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__1599); A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A_fn_class = fncls__1598d; tmp10 = fncls__1598d } else { tmp10 = fncls__1598 }; arg_1591 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1599, tmp10, nil); var arg_1592 any; var root_1600 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, A_arbace_j2g_model_ctors_of_A_fn_class); var ifn_1602 lang.IFn; if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any = s__2; if linked_1601 == nil { arg_1592 = ifn_1602.Invoke_O__O(arg_1603) } else { arg_1592 = linked_1601.(*A_arbace_j2g_model_ctors_of_A).Invoke_O_O__O(root_1600, arg_1603) }; if linked_1589 == nil { tmp9 = ifn_1590.Invoke_O_O__O(arg_1591, arg_1592) } else { tmp9 = linked_1589.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1588, arg_1591, arg_1592) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp9)).Ref() } else {
//line :637:1
								return and__1927000168__auto____5 } } else {
//line :632:1
									return nil } } } } }
//line :631:1
func A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A_New() *A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A{}; t.Ctor(); return t }
//line :631:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A) Ctor() {}
//line :631:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A) Invoke_O_O__O(self, c__1 any) any { var root_1541 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any; var root_1545 any = A_arbace_j2g_model_A_const_192.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = c__1; var arg_1549 any = A_arbace_j2g_model_A_const_193; if linked_1546 == nil { arg_1544 = ifn_1547.Invoke_O_O__O(arg_1548, arg_1549) } else { arg_1544 = linked_1546.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_1545, arg_1548, arg_1549) }; if linked_1542 == nil { return ifn_1543.Invoke_O__O(arg_1544) } else { return linked_1542.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1541, arg_1544) } }



func A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A_New() *A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A{}; t.Ctor(); return t }
//line :635:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A) Ctor() {}
//line :635:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A) Invoke_O_O__O(self, p1__1479000160_SHARP___1 any) any { var root_1565 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any; var root_1569 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = p1__1479000160_SHARP___1; if linked_1570 == nil { arg_1568 = ifn_1571.Invoke_O__O(arg_1572) } else { arg_1568 = linked_1570.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1569, arg_1572) }; if linked_1566 == nil { return ifn_1567.Invoke_O__O(arg_1568) } else { return linked_1566.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1565, arg_1568) } }


func A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A_New_J(p0 int64) *A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A{}; t.Ctor_J(p0); return t }
//line :638:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A) Ctor_J(c__pp int64) { t.F_pp = c__pp }
//line :638:1
func (t *A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A) Invoke_O_O__O(self, p1__1479000161_SHARP___1 any) any { var root_1593 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(p1__1479000161_SHARP___1); var arg_1597 any = jrt.Long_ValueOf_J__Long_NoInit(t.F_pp).Ref(); if linked_1594 == nil { return ifn_1595.Invoke_O_O__O(arg_1596, arg_1597) } else { return linked_1594.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1593, arg_1596, arg_1597) } }

func A_arbace_j2g_model_serial_chain_super_A_New() *A_arbace_j2g_model_serial_chain_super_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_chain_super_A{}; t.Ctor(); return t }
//line :640:1
func (t *A_arbace_j2g_model_serial_chain_super_A) Ctor() {}
//line :640:1
func (t *A_arbace_j2g_model_serial_chain_super_A) Invoke_O_O__O(self, n__0 any) any { var chain__2 any; var root_1604 any = A_arbace_j2g_model_A_const_182.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1606 lang.IFn; if



	linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = n__0; if linked_1605 == nil { chain__2 = ifn_1606.Invoke_O__O(arg_1607) } else { chain__2 = linked_1605.(*A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1604, arg_1607) }; var sers__3 any; var root_1608 any = /*line :640:1*/A_arbace_j2g_model_A_const_172.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1610 lang.IFn; if




	linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var arg_1612 any = chain__2; if linked_1609 == nil { sers__3 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { sers__3 = linked_1609.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }; var s__4 any; var root_1613 any = /*line :640:1*/A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1615 lang.IFn; if





	linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any; var root_1617 any = A_arbace_j2g_model_A_const_198.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var arg_1621 any = chain__2; if linked_1618 == nil { arg_1616 = ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { arg_1616 = linked_1618.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_1617, arg_1620, arg_1621) }; if linked_1614 == nil { s__4 = ifn_1615.Invoke_O__O(arg_1616) } else { s__4 = linked_1614.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1613, arg_1616) }; var tmp1 any; var root_1622 any =
	A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = A_arbace_j2g_model_A_const_199.GetRawRoot__O(); var arg_1626 any = sers__3; if linked_1623 == nil { tmp1 = ifn_1624.Invoke_O_O__O(arg_1625, arg_1626) } else { tmp1 = linked_1623.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1622, arg_1625, arg_1626) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 bool; var or__1927000174__auto____5 bool = lang.Util_Identical_O_O__Z_NoInit(s__4, nil)
		if or__1927000174__auto____5 { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(s__4, Lit_44) }
//line :648:1
		if tmp2 { return A_arbace_j2g_model_A_const_200 } else { var tmp3 any; var root_1627 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1629 lang.IFn

			if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any; var root_1631 any = A_arbace_j2g_model_A_const_60.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = s__4; if linked_1632 == nil { arg_1630 = ifn_1633.Invoke_O__O(arg_1634) } else { arg_1630 = linked_1632.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_1631, arg_1634) }; if linked_1628 == nil { tmp3 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp3 = linked_1628.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1627, arg_1630) }
//line :648:1
			if jrt.J2g_Truth(tmp3) { return nil } else { if A_arbace_j2g_model_A_const_68 != nil { var k__5 any; var root_1635 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1637 lang.IFn



				if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any; var root_1639 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any; var fnbody__1645 any = A_arbace_j2g_model_serial_chain_super_fn__1479000170_A_New(); var tmp4 *jrt.Class; var fncls__1644 *jrt.Class = A_arbace_j2g_model_serial_chain_super_fn__1479000170_A_fn_class; if fncls__1644 == nil { var fncls__1644d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_j2g_model_serial_chain_super_fn__1479000170_A_fn_class = fncls__1644d; tmp4 = fncls__1644d } else { tmp4 = fncls__1644 }; arg_1642 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1645, tmp4, nil); var arg_1643 any; var root_1646 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, A_arbace_j2g_model_ctors_of_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = s__4; if linked_1647 == nil { arg_1643 = ifn_1648.Invoke_O__O(arg_1649) } else { arg_1643 = linked_1647.(*A_arbace_j2g_model_ctors_of_A).Invoke_O_O__O(root_1646, arg_1649) }; if linked_1640 == nil { arg_1638 = ifn_1641.Invoke_O_O__O(arg_1642, arg_1643) } else { arg_1638 = linked_1640.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1639, arg_1642, arg_1643) }; if linked_1636 == nil { k__5 = ifn_1637.Invoke_O__O(arg_1638) } else { k__5 = linked_1636.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1635, arg_1638) }
//line :648:1
				var fl__6 any; var or__1927000174__auto____6 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(k__5)




				if jrt.J2g_Truth(or__1927000174__auto____6) { fl__6 = or__1927000174__auto____6 } else { fl__6 = A_arbace_j2g_model_A_const_35 }
//line :648:1
				var ok__7 any
				var and__1927000168__auto____7 any = k__5




				if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1650 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any; var root_1654 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = k__5; if linked_1655 == nil { arg_1653 = ifn_1656.Invoke_O__O(arg_1657) } else { arg_1653 = linked_1655.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1654, arg_1657) }; if linked_1651 == nil { and__1927000168__auto____8 = ifn_1652.Invoke_O__O(arg_1653) } else { and__1927000168__auto____8 = linked_1651.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1650, arg_1653) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var or__1927000174__auto____9 any; var root_1658 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1660 lang.IFn
					if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = fl__6; var arg_1662 any = A_arbace_j2g_model_A_const_201; if linked_1659 == nil { or__1927000174__auto____9 = ifn_1660.Invoke_O_O__O(arg_1661, arg_1662) } else { or__1927000174__auto____9 = linked_1659.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1658, arg_1661, arg_1662) }; if jrt.J2g_Truth(or__1927000174__auto____9) { ok__7 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any; var root_1663 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = fl__6; var arg_1667 any = A_arbace_j2g_model_A_const_202; if linked_1664 == nil { or__1927000174__auto____10 = ifn_1665.Invoke_O_O__O(arg_1666, arg_1667) } else { or__1927000174__auto____10 = linked_1664.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1663, arg_1666, arg_1667) }; if jrt.J2g_Truth(or__1927000174__auto____10) { ok__7 = or__1927000174__auto____10 } else {
						var tmp5 any; var root_1668 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, A_arbace_j2g_model_java_pkg_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = s__4; if linked_1669 == nil { tmp5 = ifn_1670.Invoke_O__O(arg_1671) } else { tmp5 = linked_1669.(*A_arbace_j2g_model_java_pkg_A).Invoke_O_O__O(root_1668, arg_1671) }; var tmp6 any = tmp5; var tmp7 any; var root_1672 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, A_arbace_j2g_model_java_pkg_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = n__0; if linked_1673 == nil { tmp7 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp7 = linked_1673.(*A_arbace_j2g_model_java_pkg_A).Invoke_O_O__O(root_1672, arg_1675) }; ok__7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7)).Ref() } } } else {
//line :654:1
							ok__7 = and__1927000168__auto____8 } } else { ok__7 = and__1927000168__auto____7 }
//line :648:1
				var sd__8 any; var root_1676 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1678 lang.IFn








				if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = s__4; if linked_1677 == nil { sd__8 = ifn_1678.Invoke_O__O(arg_1679) } else { sd__8 = linked_1677.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1676, arg_1679) }
				var tmp8 any; var and__1927000168__auto____9 any = ok__7; if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10_2 any; var root_1680 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = sd__8; if linked_1681 == nil { or__1927000174__auto____10_2 = ifn_1682.Invoke_O__O(arg_1683) } else { or__1927000174__auto____10_2 = linked_1681.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1680, arg_1683) }; if jrt.J2g_Truth(or__1927000174__auto____10_2) { tmp8 = or__1927000174__auto____10_2 } else { var root_1684 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = A_arbace_j2g_model_A_const_203.Invoke_O__O(sd__8); if linked_1685 == nil { tmp8 = ifn_1686.Invoke_O__O(arg_1687) } else { tmp8 = linked_1685.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1684, arg_1687) } } } else { tmp8 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp8) { return lang.Tuple_Create_O_O__IPersistentVector(s__4, k__5) } else { return nil } } else {
//line :648:1
					return nil } } } } else {
//line :647:1
						return nil } }




func A_arbace_j2g_model_serial_chain_super_fn__1479000170_A_New() *A_arbace_j2g_model_serial_chain_super_fn__1479000170_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_chain_super_fn__1479000170_A{}; t.Ctor(); return t }
//line :652:1
func (t *A_arbace_j2g_model_serial_chain_super_fn__1479000170_A) Ctor() {}
//line :652:1
func (t *A_arbace_j2g_model_serial_chain_super_fn__1479000170_A) Invoke_O_O__O(self, p1__1479000169_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_106, A_arbace_j2g_model_A_const_121.Invoke_O__O(p1__1479000169_SHARP___1))).Ref() }








func A_arbace_j2g_model_serial_super_A_New() *A_arbace_j2g_model_serial_super_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_super_A{}; t.Ctor(); return t }
//line :661:1
func (t *A_arbace_j2g_model_serial_super_A) Ctor() {}
//line :661:1
func (t *A_arbace_j2g_model_serial_super_A) Invoke_O_O__O(self, n__0 any) any {













	var tmp1 any; var and__1927000168__auto____2 any; var root_1688 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, A_arbace_j2g_model_serialization_QMARK__A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; if linked_1689 == nil { and__1927000168__auto____2 = ifn_1690.Invoke__O() } else { and__1927000168__auto____2 = linked_1689.(*A_arbace_j2g_model_serialization_QMARK__A).Invoke_O__O(root_1688) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1691 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = Lit_107; if linked_1692 == nil { and__1927000168__auto____3 = ifn_1693.Invoke_O__O(arg_1694) } else { and__1927000168__auto____3 = linked_1692.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1691, arg_1694) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1695 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = n__0; if linked_1696 == nil { and__1927000168__auto____4 = ifn_1697.Invoke_O__O(arg_1698) } else { and__1927000168__auto____4 = linked_1696.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1695, arg_1698) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1699 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1701 lang.IFn
		if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any; var root_1703 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = n__0; if linked_1704 == nil { arg_1702 = ifn_1705.Invoke_O__O(arg_1706) } else { arg_1702 = linked_1704.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1703, arg_1706) }; if linked_1700 == nil { and__1927000168__auto____5 = ifn_1701.Invoke_O__O(arg_1702) } else { and__1927000168__auto____5 = linked_1700.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1699, arg_1702) }
//line :675:1
		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1707 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1709 lang.IFn
			if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any; var root_1711 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, A_arbace_j2g_model_abstract_QMARK__A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = n__0; if linked_1712 == nil { arg_1710 = ifn_1713.Invoke_O__O(arg_1714) } else { arg_1710 = linked_1712.(*A_arbace_j2g_model_abstract_QMARK__A).Invoke_O_O__O(root_1711, arg_1714) }; if linked_1708 == nil { and__1927000168__auto____6 = ifn_1709.Invoke_O__O(arg_1710) } else { and__1927000168__auto____6 = linked_1708.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1707, arg_1710) }
//line :675:1
			if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_205; var or__1927000174__auto____7 bool = lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()), nil)

				if or__1927000174__auto____7 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var root_1715 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_205; var arg_1718 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); var arg_1719 any = n__0; if linked_1716 == nil { tmp1 = ifn_1717.Invoke_O_O__O(arg_1718, arg_1719) } else { tmp1 = linked_1716.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1715, arg_1718, arg_1719) } } } else {
//line :675:1
					tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var d__2 any; var root_1720 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1722 lang.IFn


						if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = n__0; if linked_1721 == nil { d__2 = ifn_1722.Invoke_O__O(arg_1723) } else { d__2 = linked_1721.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1720, arg_1723) }
						var tmp4 any; var and__1927000168__auto____3_2 any = d__2; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var and__1927000168__auto____4_2 any; var root_1724 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_206); var arg_1727 any = tmp5.Invoke_O__O(A_arbace_j2g_model_A_const_176.Invoke_O__O(d__2)); if linked_1725 == nil { and__1927000168__auto____4_2 = ifn_1726.Invoke_O__O(arg_1727) } else { and__1927000168__auto____4_2 = linked_1725.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1724, arg_1727) }; if jrt.J2g_Truth(and__1927000168__auto____4_2) { var and__1927000168__auto____5_2 any; var root_1728 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = A_arbace_j2g_model_A_const_207.Invoke_O__O(d__2); if linked_1729 == nil { and__1927000168__auto____5_2 = ifn_1730.Invoke_O__O(arg_1731) } else { and__1927000168__auto____5_2 = linked_1729.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1728, arg_1731) }; if jrt.J2g_Truth(and__1927000168__auto____5_2) { var and__1927000168__auto____6_2 any; var root_1732 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, A_arbace_j2g_model_serializable_QMARK__A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = n__0; if linked_1733 == nil { and__1927000168__auto____6_2 = ifn_1734.Invoke_O__O(arg_1735) } else { and__1927000168__auto____6_2 = linked_1733.(*A_arbace_j2g_model_serializable_QMARK__A).Invoke_O_O__O(root_1732, arg_1735) }; if jrt.J2g_Truth(and__1927000168__auto____6_2) {
							var root_1736 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_208); var arg_1739 any = tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_190.Invoke_O__O(d__2)); if linked_1737 == nil { tmp4 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp4 = linked_1737.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1736, arg_1739) } } else {
//line :679:1
								tmp4 = and__1927000168__auto____6_2 } } else { tmp4 = and__1927000168__auto____5_2 } } else { tmp4 = and__1927000168__auto____4_2 } } else { tmp4 = and__1927000168__auto____3_2 }; if jrt.J2g_Truth(tmp4) {

									var root_1740 any = A_arbace_j2g_model_A_const_209.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, A_arbace_j2g_model_serial_chain_super_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = n__0; if linked_1741 == nil { return ifn_1742.Invoke_O__O(arg_1743) } else { return linked_1741.(*A_arbace_j2g_model_serial_chain_super_A).Invoke_O_O__O(root_1740, arg_1743) } } else {
//line :679:1
										return nil } } else {
//line :675:1
											return nil
										}
}







func A_arbace_j2g_model_default_suid_QMARK__A_New() *A_arbace_j2g_model_default_suid_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_default_suid_QMARK__A{}; t.Ctor(); return t }
//line :685:1
func (t *A_arbace_j2g_model_default_suid_QMARK__A) Ctor() {}
//line :685:1
func (t *A_arbace_j2g_model_default_suid_QMARK__A) Invoke_O__O(self any) any {




	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_24, jrt.System_Getenv_String__String(Lit_25).Ref())).Ref()
}
func A_arbace_j2g_model_serial_uid_A_New() *A_arbace_j2g_model_serial_uid_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_uid_A{}; t.Ctor(); return t }
//line :692:1
func (t *A_arbace_j2g_model_serial_uid_A) Ctor() {}
//line :692:1
func (t *A_arbace_j2g_model_serial_uid_A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 any; var and__1927000168__auto____2 any; var root_1744 any = A_arbace_j2g_model_A_const_210.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, A_arbace_j2g_model_default_suid_QMARK__A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; if linked_1745 == nil { and__1927000168__auto____2 = ifn_1746.Invoke__O() } else { and__1927000168__auto____2 = linked_1745.(*A_arbace_j2g_model_default_suid_QMARK__A).Invoke_O__O(root_1744) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1747 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, A_arbace_j2g_model_serialization_QMARK__A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; if linked_1748 == nil { and__1927000168__auto____3 = ifn_1749.Invoke__O() } else { and__1927000168__auto____3 = linked_1748.(*A_arbace_j2g_model_serialization_QMARK__A).Invoke_O__O(root_1747) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1750 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = n__0; if linked_1751 == nil { and__1927000168__auto____4 = ifn_1752.Invoke_O__O(arg_1753) } else { and__1927000168__auto____4 = linked_1751.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1750, arg_1753) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1754 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, A_arbace_j2g_model_serializable_QMARK__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = n__0; if linked_1755 == nil { tmp1 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp1 = linked_1755.(*A_arbace_j2g_model_serializable_QMARK__A).Invoke_O_O__O(root_1754, arg_1757) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var d__2 any; var root_1758 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1760 lang.IFn
		if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = n__0; if linked_1759 == nil { d__2 = ifn_1760.Invoke_O__O(arg_1761) } else { d__2 = linked_1759.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1758, arg_1761) }
		var tmp2 any; var and__1927000168__auto____3_2 any = d__2; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var and__1927000168__auto____4_2 any; var root_1762 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_211); var arg_1765 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_176.Invoke_O__O(d__2)); if linked_1763 == nil { and__1927000168__auto____4_2 = ifn_1764.Invoke_O__O(arg_1765) } else { and__1927000168__auto____4_2 = linked_1763.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1762, arg_1765) }; if jrt.J2g_Truth(and__1927000168__auto____4_2) { var and__1927000168__auto____5 any; var root_1766 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = A_arbace_j2g_model_A_const_207.Invoke_O__O(d__2); if linked_1767 == nil { and__1927000168__auto____5 = ifn_1768.Invoke_O__O(arg_1769) } else { and__1927000168__auto____5 = linked_1767.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1766, arg_1769) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1770 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any; var root_1774 any = A_arbace_j2g_model_A_const_212.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, A_arbace_j2g_model_code_class_QMARK__A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = n__0; if linked_1775 == nil { arg_1773 = ifn_1776.Invoke_O__O(arg_1777) } else { arg_1773 = linked_1775.(*A_arbace_j2g_model_code_class_QMARK__A).Invoke_O_O__O(root_1774, arg_1777) }; if linked_1771 == nil { and__1927000168__auto____6 = ifn_1772.Invoke_O__O(arg_1773) } else { and__1927000168__auto____6 = linked_1771.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1770, arg_1773) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
			var root_1778 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any; var root_1782 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any; var fnbody__1792 any = A_arbace_j2g_model_serial_uid_fn__1479000176_A_New(); var tmp4 *jrt.Class; var fncls__1791 *jrt.Class = A_arbace_j2g_model_serial_uid_fn__1479000176_A_fn_class; if fncls__1791 == nil { var fncls__1791d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, nil); A_arbace_j2g_model_serial_uid_fn__1479000176_A_fn_class = fncls__1791d; tmp4 = fncls__1791d } else { tmp4 = fncls__1791 }; arg_1785 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1792, tmp4, nil); var arg_1786 any = A_arbace_j2g_model_A_const_130.Invoke_O__O(d__2); if linked_1783 == nil { arg_1781 = ifn_1784.Invoke_O_O__O(arg_1785, arg_1786) } else { arg_1781 = linked_1783.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1782, arg_1785, arg_1786) }; if linked_1779 == nil { tmp2 = ifn_1780.Invoke_O__O(arg_1781) } else { tmp2 = linked_1779.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1778, arg_1781) } } else {
//line :702:1
				tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4_2 } } else { tmp2 = and__1927000168__auto____3_2 }; if jrt.J2g_Truth(tmp2) { var v__3 any; var root_1793 any = A_arbace_j2g_model_A_const_213.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_classes_suid.A_arbace_classes_suid_default_suid_A_fn_class); var ifn_1795 lang.IFn

					if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = n__0; if linked_1794 == nil { v__3 = ifn_1795.Invoke_O__O(arg_1796) } else { v__3 = linked_1794.(*aot_arbace_classes_suid.A_arbace_classes_suid_default_suid_A).Invoke_O_O__O(root_1793, arg_1796) }
//line :702:1
					var temp__1927000414__auto____4 any = jrt.System_Getenv_String__String(Lit_109).Ref()


					if jrt.J2g_Truth(temp__1927000414__auto____4) { var out__5 any = temp__1927000414__auto____4; var lockee__1927000360__auto____6 any = A_arbace_j2g_model_A_const_214.GetRawRoot__O(); var tmp5 *lang.Compiler_AOTFn; var fnbody__1811 any = A_arbace_j2g_model_serial_uid_fn__1479000178_A_New_O_O_O_O(out__5, n__0, v__3, lockee__1927000360__auto____6); var tmp6 *jrt.Class; var fncls__1810 *jrt.Class = A_arbace_j2g_model_serial_uid_fn__1479000178_A_fn_class
						if fncls__1810 == nil { var fncls__1810d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, fnbody__1811); A_arbace_j2g_model_serial_uid_fn__1479000178_A_fn_class = fncls__1810d; tmp6 = fncls__1810d } else { tmp6 = fncls__1810 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1811, tmp6, nil); Up_Compiler_AOTFn_IFn(tmp5).Invoke__O() }
//line :702:1
					return v__3 } else { return nil } } else {
//line :700:1
						return nil
					}
}
func A_arbace_j2g_model_serial_uid_fn__1479000176_A_New() *A_arbace_j2g_model_serial_uid_fn__1479000176_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_uid_fn__1479000176_A{}; t.Ctor(); return t }
//line :703:1
func (t *A_arbace_j2g_model_serial_uid_fn__1479000176_A) Ctor() {}
//line :703:1
func (t *A_arbace_j2g_model_serial_uid_fn__1479000176_A) Invoke_O_O__O(self, p1__1479000175_SHARP___1 any) any { var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_111, A_arbace_j2g_model_A_const_131.Invoke_O__O(p1__1479000175_SHARP___1)); if and__1927000168__auto____2 { var root_1787 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = p1__1479000175_SHARP___1; if linked_1788 == nil { return ifn_1789.Invoke_O__O(arg_1790) } else { return linked_1788.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1787, arg_1790) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }


func A_arbace_j2g_model_serial_uid_fn__1479000178_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_serial_uid_fn__1479000178_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_serial_uid_fn__1479000178_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :706:1
func (t *A_arbace_j2g_model_serial_uid_fn__1479000178_A) Ctor_O_O_O_O(c__out, c__n, c__v, c__lockee__1927000360__auto__ any) { t.F_out = c__out; t.F_n = c__n; t.F_v = c__v; t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__ }
//line :706:1
func (t *A_arbace_j2g_model_serial_uid_fn__1479000178_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____3); var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_215.GetRawRoot__O()); var tmp3 any; var t__2 any = t.F_out; t.F_out = nil; tmp3 = t__2; var tmp4 any = tmp3; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113); var tmp6 any; var root_1804 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var t__3 any = t.F_n; t.F_n = nil; arg_1807 = t__3; var arg_1808 any = Lit_1; var arg_1809 any = Lit_2; if linked_1805 == nil { tmp6 = ifn_1806.Invoke_O_O_O__O(arg_1807, arg_1808, arg_1809) } else { tmp6 = linked_1805.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1804, arg_1807, arg_1808, arg_1809) }; var tmp7 any = tmp6; var tmp8 any; var t__4 any = t.F_v; t.F_v = nil; tmp8 = t__4; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, tmp8, nil)).Ref(), A_arbace_j2g_model_A_const_216, jrt.Boolean_TRUE.Ref()) }
//line :706:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____3); if tmp9 != nil { panic(tmp9) }; return tmp1 }



func A_arbace_j2g_model_foreign_super_accessible_QMARK__A_New() *A_arbace_j2g_model_foreign_super_accessible_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_foreign_super_accessible_QMARK__A{}; t.Ctor(); return t }
//line :710:1
func (t *A_arbace_j2g_model_foreign_super_accessible_QMARK__A) Ctor() {}
//line :710:1
func (t *A_arbace_j2g_model_foreign_super_accessible_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var pp__2 int64 = lang.Numbers_Or_J_J__J_NoInit(1, 4); var and__1927000168__auto____3 any; var root_1812 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1814 lang.IFn; if





	linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any; var root_1817 any = A_arbace_j2g_model_A_const_196.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, A_arbace_j2g_model_class_access_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = n__0; if linked_1818 == nil { arg_1815 = ifn_1819.Invoke_O__O(arg_1820) } else { arg_1815 = linked_1818.(*A_arbace_j2g_model_class_access_A).Invoke_O_O__O(root_1817, arg_1820) }; var arg_1816 any = jrt.Long_ValueOf_J__Long_NoInit(pp__2).Ref(); if linked_1813 == nil { and__1927000168__auto____3 = ifn_1814.Invoke_O_O__O(arg_1815, arg_1816) } else { and__1927000168__auto____3 = linked_1813.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1812, arg_1815, arg_1816) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any; var root_1821 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any; var fnbody__1832 any = A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A_New_J(pp__2); var tmp2 *jrt.Class; var fncls__1831 *jrt.Class = A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A_fn_class; if fncls__1831 == nil { var fncls__1831d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1832); A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A_fn_class = fncls__1831d; tmp2 = fncls__1831d } else { tmp2 = fncls__1831 }; arg_1824 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1832, tmp2, nil); var arg_1825 any; var root_1833 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, A_arbace_j2g_model_ctors_of_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = n__0; if linked_1834 == nil { arg_1825 = ifn_1835.Invoke_O__O(arg_1836) } else { arg_1825 = linked_1834.(*A_arbace_j2g_model_ctors_of_A).Invoke_O_O__O(root_1833, arg_1836) }; if linked_1822 == nil { tmp1 = ifn_1823.Invoke_O_O__O(arg_1824, arg_1825) } else { tmp1 = linked_1822.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1821, arg_1824, arg_1825) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } else { return and__1927000168__auto____3 } }
//line :716:1
func A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A_New_J(p0 int64) *A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A{}; t.Ctor_J(p0); return t }
//line :716:1
func (t *A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A) Ctor_J(c__pp int64) { t.F_pp = c__pp }
//line :716:1
func (t *A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A) Invoke_O_O__O(self, p1__1479000181_SHARP___1 any) any { var root_1826 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(p1__1479000181_SHARP___1); var arg_1830 any = jrt.Long_ValueOf_J__Long_NoInit(t.F_pp).Ref(); if linked_1827 == nil { return ifn_1828.Invoke_O_O__O(arg_1829, arg_1830) } else { return linked_1827.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1826, arg_1829, arg_1830) } }

func A_arbace_j2g_model_code_class_QMARK__A_New() *A_arbace_j2g_model_code_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_class_QMARK__A{}; t.Ctor(); return t }
//line :718:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Ctor() {}
//line :718:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_217; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_218; var tmp3 any; var root_1837 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = n__0; if linked_1838 == nil { tmp3 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp3 = linked_1838.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1837, arg_1840) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)))).Ref()
}
func A_arbace_j2g_model_code_iface_QMARK__A_New() *A_arbace_j2g_model_code_iface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_iface_QMARK__A{}; t.Ctor(); return t }
//line :728:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Ctor() {}
//line :728:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1841 any = A_arbace_j2g_model_A_const_219.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = A_arbace_j2g_model_A_const_220; var arg_1845 any = n__0; if linked_1842 == nil { tmp1 = ifn_1843.Invoke_O_O__O(arg_1844, arg_1845) } else { tmp1 = linked_1842.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1841, arg_1844, arg_1845) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_nest_top_A_New() *A_arbace_j2g_model_nest_top_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_nest_top_A{}; t.Ctor(); return t }
//line :734:1
func (t *A_arbace_j2g_model_nest_top_A) Ctor() {}
//line :734:1
func (t *A_arbace_j2g_model_nest_top_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_75); if


	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1846 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1848 lang.IFn; if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any = n__0; var arg_1850 any = A_arbace_j2g_model_A_const_35; var arg_1851 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1847 == nil { return ifn_1848.Invoke_O_O_O__O(arg_1849, arg_1850, arg_1851) } else { return linked_1847.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1846, arg_1849, arg_1850, arg_1851) } } }



func A_arbace_j2g_model_init_superinterfaces_A_New() *A_arbace_j2g_model_init_superinterfaces_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_A{}; t.Ctor(); return t }
//line :741:1
func (t *A_arbace_j2g_model_init_superinterfaces_A) Ctor() {}
//line :741:1
func (t *A_arbace_j2g_model_init_superinterfaces_A) Invoke_O_O__O(self, n__0 any) any { var d__2 any; var root_1852 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1854 lang.IFn; if




	linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = n__0; if linked_1853 == nil { d__2 = ifn_1854.Invoke_O__O(arg_1855) } else { d__2 = linked_1853.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1852, arg_1855) }; var tmp1 any; var and__1927000168__auto____3 any = d__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1856 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any; var root_1860 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(d__2); var arg_1864 any = A_arbace_j2g_model_A_const_221; if linked_1861 == nil { arg_1859 = ifn_1862.Invoke_O_O__O(arg_1863, arg_1864) } else { arg_1859 = linked_1861.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1860, arg_1863, arg_1864) }; if linked_1857 == nil { tmp1 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp1 = linked_1857.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1856, arg_1859) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var declares_default_QMARK___3 any; var fnbody__1896 any = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A_New(); var tmp2 *jrt.Class; var fncls__1895 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A_fn_class
		if fncls__1895 == nil { var fncls__1895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A_fn_class = fncls__1895d; tmp2 = fncls__1895d } else { tmp2 = fncls__1895 }; declares_default_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1896, tmp2, nil)
//line :747:1
		var walk__4 any; var fnbody__1920 any = A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A_New_O(declares_default_QMARK___3); var tmp3 *jrt.Class
		var fncls__1919 /*line :747:1*/*jrt.Class = A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A_fn_class




		if fncls__1919 == nil { var fncls__1919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__1920); A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A_fn_class = fncls__1919d; tmp3 = fncls__1919d } else { tmp3 = fncls__1919 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1920, tmp3, nil)



		var root_1921 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any; var root_1925 any = A_arbace_j2g_model_A_const_222.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any; var iter__1927001039__auto____5 any; var fnbody__2010 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A_New(); var tmp4 *jrt.Class; var fncls__2009 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A_fn_class; if fncls__2009 == nil { var fncls__2009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A_fn_class = fncls__2009d; tmp4 = fncls__2009d } else { tmp4 = fncls__2009 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2010, tmp4, nil); arg_1928 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_73.GetRawRoot__O()).Invoke_O_O__O(walk__4, A_arbace_j2g_model_A_const_62.Invoke_O__O(d__2))); if linked_1926 == nil { arg_1924 = ifn_1927.Invoke_O__O(arg_1928) } else { arg_1924 = linked_1926.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1925, arg_1928) }; if linked_1922 == nil { return ifn_1923.Invoke_O__O(arg_1924) } else { return linked_1922.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1921, arg_1924) } } else {
//line :747:1
			return nil } }
func A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A_New() *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A{}; t.Ctor(); return t }
//line :748:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A) Ctor() {}
//line :748:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A) Invoke_O_O__O(self, j__1 any) any {
	var root_1865 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any; var fnbody__1890 any = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A_New(); var tmp1 *jrt.Class; var fncls__1889 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A_fn_class; if fncls__1889 == nil { var fncls__1889d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A_fn_class = fncls__1889d; tmp1 = fncls__1889d } else { tmp1 = fncls__1889 }; arg_1868 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1890, tmp1, nil); var arg_1869 any; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_58; var tmp3 any; var root_1891 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1893 lang.IFn

	if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = j__1; if linked_1892 == nil { tmp3 = ifn_1893.Invoke_O__O(arg_1894) } else { tmp3 = linked_1892.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1891, arg_1894) }; arg_1869 = tmp2.Invoke_O__O(tmp3)
//line :749:1
	if linked_1866 == nil { return ifn_1867.Invoke_O_O__O(arg_1868, arg_1869) } else { return linked_1866.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1865, arg_1868, arg_1869) } }
//line :749:1
func A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A_New() *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A{}; t.Ctor(); return t }
//line :749:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A) Ctor() {}
//line :749:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A) Invoke_O_O__O(self, p1__1479000188_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1870 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = Lit_56; var arg_1874 any = A_arbace_j2g_model_A_const_131.Invoke_O__O(p1__1479000188_SHARP___1); if linked_1871 == nil { and__1927000168__auto____2 = ifn_1872.Invoke_O_O__O(arg_1873, arg_1874) } else { and__1927000168__auto____2 = linked_1871.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1870, arg_1873, arg_1874) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1875 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = Lit_20; var arg_1879 any = A_arbace_j2g_model_A_const_131.Invoke_O__O(p1__1479000188_SHARP___1); if linked_1876 == nil { and__1927000168__auto____3 = ifn_1877.Invoke_O_O__O(arg_1878, arg_1879) } else { and__1927000168__auto____3 = linked_1876.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1875, arg_1878, arg_1879) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
																				var root_1880 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any; var root_1884 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any = A_arbace_j2g_model_A_const_55.Invoke_O__O(p1__1479000188_SHARP___1); var arg_1888 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_Or_J_J__J_NoInit(8, 1024), 2)).Ref(); if linked_1885 == nil { arg_1883 = ifn_1886.Invoke_O_O__O(arg_1887, arg_1888) } else { arg_1883 = linked_1885.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1884, arg_1887, arg_1888) }; if linked_1881 == nil { return ifn_1882.Invoke_O__O(arg_1883) } else { return linked_1881.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1880, arg_1883) } } else {
//line :749:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A_New_O(p0 any) *A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A{}; t.Ctor_O(p0); return t }
//line :752:1
func (t *A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A) Ctor_O(c__declares_default_QMARK_ any) { t.F_declares_default_QMARK_ = c__declares_default_QMARK_ }
//line :752:1
func (t *A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A) Invoke_O_O__O(self, j__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1897 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = j__1; if linked_1898 == nil { and__1927000168__auto____2 = ifn_1899.Invoke_O__O(arg_1900) } else { and__1927000168__auto____2 = linked_1898.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1897, arg_1900) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1901 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = j__1; if linked_1902 == nil { tmp1 = ifn_1903.Invoke_O__O(arg_1904) } else { tmp1 = linked_1902.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1901, arg_1904) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_1905 any = A_arbace_j2g_model_A_const_90.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1907 lang.IFn; if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_73.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_62; var tmp4 any; var root_1915 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = j__1; if linked_1916 == nil { tmp4 = ifn_1917.Invoke_O__O(arg_1918) } else { tmp4 = linked_1916.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1915, arg_1918) }; arg_1908 = tmp2.Invoke_O_O__O(self, tmp3.Invoke_O__O(tmp4)); var arg_1909 any
		if jrt.J2g_Truth(lang.IFn_Cast(t.F_declares_default_QMARK_).Invoke_O__O(j__1)) { arg_1909 = lang.Tuple_Create_O__IPersistentVector(j__1) } else { arg_1909 = nil }
//line :754:1
		if linked_1906 == nil { return ifn_1907.Invoke_O_O__O(arg_1908, arg_1909) } else { return linked_1906.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1905, arg_1908, arg_1909) } } else {
//line :753:1
			return nil
		}
}
func A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A_New() *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A{}; t.Ctor(); return t }
//line :756:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A) Ctor() {}
//line :756:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A) Invoke_O_O__O(self, s__1479000196__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2008 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A_New_O_O(s__1479000196__1, self); var tmp2 *jrt.Class; var fncls__2007 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A_fn_class; if fncls__2007 == nil { var fncls__2007d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__2008); A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A_fn_class = fncls__2007d; tmp2 = fncls__2007d } else { tmp2 = fncls__2007 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2008, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :756:1
func A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A{}; t.Ctor_O_O(p0, p1); return t }
//line :756:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A) Ctor_O_O(c__s__1479000196, c__iter__1479000195 any) { t.F_s__1479000196 = c__s__1479000196; t.F_iter__1479000195 = c__iter__1479000195 }
//line :756:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A) Invoke_O__O(self any) any { { var s__1479000196__1 any; var t_ any = t.F_s__1479000196; t.F_s__1479000196 = nil; s__1479000196__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1929 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = s__1479000196__1; if linked_1930 == nil { temp__1927000414__auto____2 = ifn_1931.Invoke_O__O(arg_1932) } else { temp__1927000414__auto____2 = linked_1930.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1929, arg_1932) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000196__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1933 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = s__1479000196__3; if linked_1934 == nil { tmp1 = ifn_1935.Invoke_O__O(arg_1936) } else { tmp1 = linked_1934.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1933, arg_1936) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1937 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = s__1479000196__3; if linked_1938 == nil { c__1927001037__auto____4 = ifn_1939.Invoke_O__O(arg_1940) } else { c__1927001037__auto____4 = linked_1938.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1937, arg_1940) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000198__6 any; var root_1941 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1942 == nil { b__1479000198__6 = ifn_1943.Invoke_O__O(arg_1944) } else { b__1479000198__6 = linked_1942.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1941, arg_1944) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1959 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A_New_O_I_O(b__1479000198__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1958 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A_fn_class; if fncls__1958 == nil { var fncls__1958d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__1959); A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A_fn_class = fncls__1958d; tmp3 = fncls__1958d } else { tmp3 = fncls__1958 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1959, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1960 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any; var root_1965 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1965, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1967 lang.IFn; if linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any = b__1479000198__6; if linked_1966 == nil { arg_1963 = ifn_1967.Invoke_O__O(arg_1968) } else { arg_1963 = linked_1966.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1965, arg_1968) }; var arg_1964 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000195); var tmp5 any; var root_1969 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = s__1479000196__3; if linked_1970 == nil { tmp5 = ifn_1971.Invoke_O__O(arg_1972) } else { tmp5 = linked_1970.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1969, arg_1972) }; arg_1964 = tmp4.Invoke_O__O(tmp5); if linked_1961 == nil { return ifn_1962.Invoke_O_O__O(arg_1963, arg_1964) } else { return linked_1961.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1960, arg_1963, arg_1964) } } else { var root_1973 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1973, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1975 lang.IFn; if linked_1974 == nil { ifn_1975 = lang.IFn_Cast(root_1973) } else { ifn_1975 = nil }; var arg_1976 any; var root_1978 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = b__1479000198__6; if linked_1979 == nil { arg_1976 = ifn_1980.Invoke_O__O(arg_1981) } else { arg_1976 = linked_1979.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1978, arg_1981) }; var arg_1977 any; if linked_1974 == nil { return ifn_1975.Invoke_O_O__O(arg_1976, arg_1977) } else { return linked_1974.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1973, arg_1976, arg_1977) } } } else { var j__4 any; var root_1982 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = s__1479000196__3; if linked_1983 == nil { j__4 = ifn_1984.Invoke_O__O(arg_1985) } else { j__4 = linked_1983.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1982, arg_1985) }; var tmp6 any; var root_1986 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1988 lang.IFn
																if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any; var root_1990 any = A_arbace_j2g_model_A_const_223.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = j__4; if linked_1991 == nil { arg_1989 = ifn_1992.Invoke_O__O(arg_1993) } else { arg_1989 = linked_1991.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1990, arg_1993) }; if linked_1987 == nil { tmp6 = ifn_1988.Invoke_O__O(arg_1989) } else { tmp6 = linked_1987.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1986, arg_1989) }
//line :756:1
	if jrt.J2g_Truth(tmp6) { var root_1994 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = j__4; var arg_1998 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1479000195); var tmp8 any; var root_1999 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = s__1479000196__3; if linked_2000 == nil { tmp8 = ifn_2001.Invoke_O__O(arg_2002) } else { tmp8 = linked_2000.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1999, arg_2002) }; arg_1998 = tmp7.Invoke_O__O(tmp8); if linked_1995 == nil { return ifn_1996.Invoke_O_O__O(arg_1997, arg_1998) } else { return linked_1995.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1994, arg_1997, arg_1998) } } else { var tmp9 any; var root_2003 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2005 lang.IFn; if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = s__1479000196__3; if linked_2004 == nil { tmp9 = ifn_2005.Invoke_O__O(arg_2006) } else { tmp9 = linked_2004.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2003, arg_2006) }; s__1479000196__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :756:1
func A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :756:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A) Ctor_O_I_O(c__b__1479000198 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000198 = c__b__1479000198; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :756:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A) Invoke_O__O(self any) any { { var i__1479000197__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000197__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000197__1)); var tmp2 any; var root_1945 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1947 lang.IFn
																		if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any; var root_1949 any = A_arbace_j2g_model_A_const_223.GetRawRoot__O(); var linked_1950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1949, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1951 lang.IFn; if linked_1950 == nil { ifn_1951 = lang.IFn_Cast(root_1949) } else { ifn_1951 = nil }; var arg_1952 any = j__2; if linked_1950 == nil { arg_1948 = ifn_1951.Invoke_O__O(arg_1952) } else { arg_1948 = linked_1950.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1949, arg_1952) }; if linked_1946 == nil { tmp2 = ifn_1947.Invoke_O__O(arg_1948) } else { tmp2 = linked_1946.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1945, arg_1948) }
//line :756:1
	if jrt.J2g_Truth(tmp2) { var root_1953 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1955 lang.IFn; if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = t.F_b__1479000198; var arg_1957 any = j__2; if linked_1954 == nil { ifn_1955.Invoke_O_O__O(arg_1956, arg_1957) } else { linked_1954.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1953, arg_1956, arg_1957) }; i__1479000197__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000197__1); continue L1 } else { i__1479000197__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000197__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_trivial_init_QMARK__A_New() *A_arbace_j2g_model_trivial_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :760:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Ctor() {}
//line :760:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_224; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); var tmp2 any; var root_2016 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2018 lang.IFn; if





	linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any; var root_2021 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = cache__2; if linked_2022 == nil { arg_2019 = ifn_2023.Invoke_O__O(arg_2024) } else { arg_2019 = linked_2022.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2021, arg_2024) }; var arg_2020 any = n__0; if linked_2017 == nil { tmp2 = ifn_2018.Invoke_O_O__O(arg_2019, arg_2020) } else { tmp2 = linked_2017.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2016, arg_2019, arg_2020) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_2025 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = cache__2; if linked_2026 == nil { tmp3 = ifn_2027.Invoke_O__O(arg_2028) } else { tmp3 = linked_2026.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2025, arg_2028) }; return lang.RT_Get_O_O__O_NoInit(tmp3, n__0) } else {
//line :766:1
			var r__3 any; var tmp4 any; var root_2029 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2031 lang.IFn


			if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any; var root_2033 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = n__0; if linked_2034 == nil { arg_2032 = ifn_2035.Invoke_O__O(arg_2036) } else { arg_2032 = linked_2034.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_2033, arg_2036) }; if linked_2030 == nil { tmp4 = ifn_2031.Invoke_O__O(arg_2032) } else { tmp4 = linked_2030.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2029, arg_2032) }
//line :768:1
			if jrt.J2g_Truth(tmp4) { r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_2037 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2039 lang.IFn

				if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = n__0; if linked_2038 == nil { tmp5 = ifn_2039.Invoke_O__O(arg_2040) } else { tmp5 = linked_2038.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2037, arg_2040) }
//line :768:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__3 = jrt.Boolean_TRUE.Ref() } else { if A_arbace_j2g_model_A_const_68 != nil { var d__3 any; var root_2041 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2043 lang.IFn


					if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = n__0; if linked_2042 == nil { d__3 = ifn_2043.Invoke_O__O(arg_2044) } else { d__3 = linked_2042.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2041, arg_2044) }
//line :768:1
					var st__4 any; var root_2045 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2047 lang.IFn


					if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any = A_arbace_j2g_model_A_const_225.Invoke_O__O(d__3); if linked_2046 == nil { st__4 = ifn_2047.Invoke_O__O(arg_2048) } else { st__4 = linked_2046.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2045, arg_2048) }
//line :768:1
					var and__1927000168__auto____5 any; var root_2049 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2051 lang.IFn




					if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = A_arbace_j2g_model_A_const_226.Invoke_O__O(st__4); if linked_2050 == nil { and__1927000168__auto____5 = ifn_2051.Invoke_O__O(arg_2052) } else { and__1927000168__auto____5 = linked_2050.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2049, arg_2052) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2053 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2055 lang.IFn
						if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = A_arbace_j2g_model_A_const_227.Invoke_O__O(st__4); if linked_2054 == nil { and__1927000168__auto____6 = ifn_2055.Invoke_O__O(arg_2056) } else { and__1927000168__auto____6 = linked_2054.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2053, arg_2056) }
//line :773:1
						if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2057 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2059 lang.IFn

							if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any = A_arbace_j2g_model_A_const_228.Invoke_O__O(st__4); if linked_2058 == nil { and__1927000168__auto____7 = ifn_2059.Invoke_O__O(arg_2060) } else { and__1927000168__auto____7 = linked_2058.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2057, arg_2060) }
//line :773:1
							if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_2061 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2063 lang.IFn


								if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any = A_arbace_j2g_model_A_const_229.Invoke_O__O(st__4); if linked_2062 == nil { and__1927000168__auto____8 = ifn_2063.Invoke_O__O(arg_2064) } else { and__1927000168__auto____8 = linked_2062.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2061, arg_2064) }
//line :773:1
								if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_87.Invoke_O__O(d__3), nil)



									if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_2065 any = A_arbace_j2g_model_A_const_223.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = A_arbace_j2g_model_A_const_87.Invoke_O__O(d__3); if linked_2066 == nil { and__1927000168__auto____9 = ifn_2067.Invoke_O__O(arg_2068) } else { and__1927000168__auto____9 = linked_2066.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2065, arg_2068) } }
//line :773:1
									if jrt.J2g_Truth(and__1927000168__auto____9) {




										var root_2069 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2071 lang.IFn; if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any; var root_2073 any = A_arbace_j2g_model_A_const_230.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, A_arbace_j2g_model_init_superinterfaces_A_fn_class); var ifn_2075 lang.IFn; if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = n__0; if linked_2074 == nil { arg_2072 = ifn_2075.Invoke_O__O(arg_2076) } else { arg_2072 = linked_2074.(*A_arbace_j2g_model_init_superinterfaces_A).Invoke_O_O__O(root_2073, arg_2076) }; if linked_2070 == nil { r__3 = ifn_2071.Invoke_O__O(arg_2072) } else { r__3 = linked_2070.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2069, arg_2072) } } else {
//line :773:1
											r__3 = and__1927000168__auto____9 } } else { r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :768:1
												r__3 = nil
											}
				}
			}







			var root_2077 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_2078 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2077, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2079 lang.IFn; if linked_2078 == nil { ifn_2079 = lang.IFn_Cast(root_2077) } else { ifn_2079 = nil }; var arg_2080 any = cache__2; var arg_2081 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var arg_2082 any = n__0; var arg_2083 any = r__3; if linked_2078 == nil { ifn_2079.Invoke_O_O_O_O__O(arg_2080, arg_2081, arg_2082, arg_2083) } else { linked_2078.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2077, arg_2080, arg_2081, arg_2082, arg_2083) }
//line :766:1
			return r__3 } }


















func A_arbace_j2g_model_go_qualified_name_A_New() *A_arbace_j2g_model_go_qualified_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_qualified_name_A{}; t.Ctor(); return t }
//line :785:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Ctor() {}
//line :785:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_2084 any = A_arbace_j2g_model_A_const_231.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any; var root_2088 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, A_arbace_j2g_model_pkg_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = n__0; if linked_2089 == nil { arg_2087 = ifn_2090.Invoke_O__O(arg_2091) } else { arg_2087 = linked_2089.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_2088, arg_2091) }; if linked_2085 == nil { tmp2 = ifn_2086.Invoke_O__O(arg_2087) } else { tmp2 = linked_2085.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A).Invoke_O_O__O(root_2084, arg_2087) }; var tmp3 any = tmp2; var tmp4 any; var root_2092 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, A_arbace_j2g_model_go_name_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = n__0; if linked_2093 == nil { tmp4 = ifn_2094.Invoke_O__O(arg_2095) } else { tmp4 = linked_2093.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2092, arg_2095) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
}




func A_arbace_j2g_model_start_class_QMARK__A_New() *A_arbace_j2g_model_start_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_class_QMARK__A{}; t.Ctor(); return t }
//line :795:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Ctor() {}
//line :795:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_2096 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = A_arbace_j2g_model_A_const_232.GetRawRoot__O(); if linked_2097 == nil { and__1927000168__auto____2 = ifn_2098.Invoke_O__O(arg_2099) } else { and__1927000168__auto____2 = linked_2097.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2096, arg_2099) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_2100 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_2102 lang.IFn; if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = n__0; if linked_2101 == nil { and__1927000168__auto____3 = ifn_2102.Invoke_O__O(arg_2103) } else { and__1927000168__auto____3 = linked_2101.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_2100, arg_2103) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2104 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = A_arbace_j2g_model_A_const_232.GetRawRoot__O(); var arg_2108 any; var root_2109 any = A_arbace_j2g_model_A_const_233.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_2111 lang.IFn; if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any = n__0; if linked_2110 == nil { arg_2108 = ifn_2111.Invoke_O__O(arg_2112) } else { arg_2108 = linked_2110.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_2109, arg_2112) }; if linked_2105 == nil { and__1927000168__auto____4 = ifn_2106.Invoke_O_O__O(arg_2107, arg_2108) } else { and__1927000168__auto____4 = linked_2105.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2104, arg_2107, arg_2108) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_2113 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any; var root_2117 any = A_arbace_j2g_model_A_const_223.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = n__0; if linked_2118 == nil { arg_2116 = ifn_2119.Invoke_O__O(arg_2120) } else { arg_2116 = linked_2118.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2117, arg_2120) }; if linked_2114 == nil { tmp1 = ifn_2115.Invoke_O__O(arg_2116) } else { tmp1 = linked_2114.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2113, arg_2116) } } else {
//line :799:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_j2g_model_start_classes_A_New() *A_arbace_j2g_model_start_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_A{}; t.Ctor(); return t }
//line :802:1
func (t *A_arbace_j2g_model_start_classes_A) Ctor() {}
//line :802:1
func (t *A_arbace_j2g_model_start_classes_A) Invoke_O__O(self any) any { var by_go__1 any; var root_2121 any = A_arbace_j2g_model_A_const_234.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2123 lang.IFn; if


	linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2125 any; var iter__1927001039__auto____1 any; var fnbody__2207 any = A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A_New(); var tmp1 *jrt.Class; var fncls__2206 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A_fn_class; if fncls__2206 == nil { var fncls__2206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A_fn_class = fncls__2206d; tmp1 = fncls__2206d } else { tmp1 = fncls__2206 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2207, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp3 any; var root_2208 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, A_arbace_j2g_model_T_A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; if linked_2209 == nil { tmp3 = ifn_2210.Invoke__O() } else { tmp3 = linked_2209.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_2208) }; arg_2125 = tmp2.Invoke_O__O(tmp3); if linked_2122 == nil { by_go__1 = ifn_2123.Invoke_O_O__O(arg_2124, arg_2125) } else { by_go__1 = linked_2122.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2121, arg_2124, arg_2125) }; var root_2211 any =
	A_arbace_j2g_model_A_const_236.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = by_go__1; var arg_2215 any = A_arbace_j2g_model_A_const_237.GetRawRoot__O(); if linked_2212 == nil { return ifn_2213.Invoke_O_O__O(arg_2214, arg_2215) } else { return linked_2212.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2211, arg_2214, arg_2215) } }
//line :805:1
func A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A_New() *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A{}; t.Ctor(); return t }
//line :805:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A) Ctor() {}
//line :805:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A) Invoke_O_O__O(self, s__1479000210__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2205 any = A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A_New_O_O(self, s__1479000210__1); var tmp2 *jrt.Class; var fncls__2204 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A_fn_class; if fncls__2204 == nil { var fncls__2204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, fnbody__2205); A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A_fn_class = fncls__2204d; tmp2 = fncls__2204d } else { tmp2 = fncls__2204 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2205, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :805:1
func A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A{}; t.Ctor_O_O(p0, p1); return t }
//line :805:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A) Ctor_O_O(c__iter__1479000209, c__s__1479000210 any) { t.F_iter__1479000209 = c__iter__1479000209; t.F_s__1479000210 = c__s__1479000210 }
//line :805:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A) Invoke_O__O(self any) any { { var s__1479000210__1 any; var t_ any = t.F_s__1479000210; t.F_s__1479000210 = nil; s__1479000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2126 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = s__1479000210__1; if linked_2127 == nil { temp__1927000414__auto____2 = ifn_2128.Invoke_O__O(arg_2129) } else { temp__1927000414__auto____2 = linked_2127.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2126, arg_2129) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2130 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = s__1479000210__3; if linked_2131 == nil { tmp1 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp1 = linked_2131.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2130, arg_2133) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2134 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = s__1479000210__3; if linked_2135 == nil { c__1927001037__auto____4 = ifn_2136.Invoke_O__O(arg_2137) } else { c__1927001037__auto____4 = linked_2135.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2134, arg_2137) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000212__6 any; var root_2138 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2139 == nil { b__1479000212__6 = ifn_2140.Invoke_O__O(arg_2141) } else { b__1479000212__6 = linked_2139.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2138, arg_2141) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2156 any = A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A_New_O_I_O(b__1479000212__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2155 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A_fn_class; if fncls__2155 == nil { var fncls__2155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, fnbody__2156); A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A_fn_class = fncls__2155d; tmp3 = fncls__2155d } else { tmp3 = fncls__2155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2156, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2157 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any; var root_2162 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2164 lang.IFn; if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = b__1479000212__6; if linked_2163 == nil { arg_2160 = ifn_2164.Invoke_O__O(arg_2165) } else { arg_2160 = linked_2163.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2162, arg_2165) }; var arg_2161 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000209); var tmp5 any; var root_2166 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = s__1479000210__3; if linked_2167 == nil { tmp5 = ifn_2168.Invoke_O__O(arg_2169) } else { tmp5 = linked_2167.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2166, arg_2169) }; arg_2161 = tmp4.Invoke_O__O(tmp5); if linked_2158 == nil { return ifn_2159.Invoke_O_O__O(arg_2160, arg_2161) } else { return linked_2158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2157, arg_2160, arg_2161) } } else { var root_2170 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any; var root_2175 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = b__1479000212__6; if linked_2176 == nil { arg_2173 = ifn_2177.Invoke_O__O(arg_2178) } else { arg_2173 = linked_2176.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2175, arg_2178) }; var arg_2174 any; if linked_2171 == nil { return ifn_2172.Invoke_O_O__O(arg_2173, arg_2174) } else { return linked_2171.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2170, arg_2173, arg_2174) } } } else { var n__4 any; var root_2179 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = s__1479000210__3; if linked_2180 == nil { n__4 = ifn_2181.Invoke_O__O(arg_2182) } else { n__4 = linked_2180.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2179, arg_2182) }; var tmp6 any; var root_2183 any = A_arbace_j2g_model_A_const_235.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = n__4; if linked_2184 == nil { tmp6 = ifn_2185.Invoke_O__O(arg_2186) } else { tmp6 = linked_2184.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_2183, arg_2186) }; if jrt.J2g_Truth(tmp6) { var root_2187 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any; var tmp7 any; var root_2192 any = A_arbace_j2g_model_A_const_233.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_2194 lang.IFn; if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any = n__4; if linked_2193 == nil { tmp7 = ifn_2194.Invoke_O__O(arg_2195) } else { tmp7 = linked_2193.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_2192, arg_2195) }; arg_2190 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, n__4); var arg_2191 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000209); var tmp9 any; var root_2196 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2198 lang.IFn; if linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = s__1479000210__3; if linked_2197 == nil { tmp9 = ifn_2198.Invoke_O__O(arg_2199) } else { tmp9 = linked_2197.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2196, arg_2199) }; arg_2191 = tmp8.Invoke_O__O(tmp9); if linked_2188 == nil { return ifn_2189.Invoke_O_O__O(arg_2190, arg_2191) } else { return linked_2188.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2187, arg_2190, arg_2191) } } else { var tmp10 any; var root_2200 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = s__1479000210__3; if linked_2201 == nil { tmp10 = ifn_2202.Invoke_O__O(arg_2203) } else { tmp10 = linked_2201.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2200, arg_2203) }; s__1479000210__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :805:1
func A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :805:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A) Ctor_O_I_O(c__b__1479000212 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000212 = c__b__1479000212; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :805:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A) Invoke_O__O(self any) any { { var i__1479000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000211__1)); var tmp2 any; var root_2142 any = A_arbace_j2g_model_A_const_235.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = n__2; if linked_2143 == nil { tmp2 = ifn_2144.Invoke_O__O(arg_2145) } else { tmp2 = linked_2143.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_2142, arg_2145) }; if jrt.J2g_Truth(tmp2) { var root_2146 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = t.F_b__1479000212; var arg_2150 any; var tmp3 any; var root_2151 any = A_arbace_j2g_model_A_const_233.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any = n__2; if linked_2152 == nil { tmp3 = ifn_2153.Invoke_O__O(arg_2154) } else { tmp3 = linked_2152.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_2151, arg_2154) }; arg_2150 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, n__2); if linked_2147 == nil { ifn_2148.Invoke_O_O__O(arg_2149, arg_2150) } else { linked_2147.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2146, arg_2149, arg_2150) }; i__1479000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000211__1); continue L1 } else { i__1479000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_model_top_class_A_New() *A_arbace_j2g_model_top_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_top_class_A{}; t.Ctor(); return t }
//line :813:1
func (t *A_arbace_j2g_model_top_class_A) Ctor() {}
//line :813:1
func (t *A_arbace_j2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_75); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_2216 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = n__0; var arg_2220 any = A_arbace_j2g_model_A_const_35; var arg_2221 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_2217 == nil { return ifn_2218.Invoke_O_O_O__O(arg_2219, arg_2220, arg_2221) } else { return linked_2217.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2216, arg_2219, arg_2220, arg_2221) } } }

func A_arbace_j2g_model_pure_ctor_QMARK__A_New() *A_arbace_j2g_model_pure_ctor_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :815:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :815:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any; var root_2222 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_2223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2222, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2224 lang.IFn; if




	linked_2223 == nil { ifn_2224 = lang.IFn_Cast(root_2222) } else { ifn_2224 = nil }; var arg_2225 any = c__1; if linked_2223 == nil { d__5 = ifn_2224.Invoke_O__O(arg_2225) } else { d__5 = linked_2223.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2222, arg_2225) }; var ab__6 any; if
	jrt.J2g_Truth(d__5) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_238; var tmp2 any; var root_2226 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = A_arbace_j2g_model_A_const_225.Invoke_O__O(d__5); if linked_2227 == nil { tmp2 = ifn_2228.Invoke_O__O(arg_2229) } else { tmp2 = linked_2227.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2226, arg_2229) }; ab__6 = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), lang.Tuple_Create_O_O__IPersistentVector(Lit_20, A_arbace_j2g_model_A_const_121.Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_2230 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_2232 lang.IFn; if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any = c__1; if linked_2231 == nil { and__1927000168__auto____9 = ifn_2232.Invoke_O__O(arg_2233) } else { and__1927000168__auto____9 = linked_2231.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_2230, arg_2233) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp3 any; var root_2234 any = A_arbace_j2g_model_A_const_239.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, A_arbace_j2g_model_top_class_A_fn_class); var ifn_2236 lang.IFn
		if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any = c__1; if linked_2235 == nil { tmp3 = ifn_2236.Invoke_O__O(arg_2237) } else { tmp3 = linked_2235.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_2234, arg_2237) }; var tmp4 any = tmp3; var tmp5 any; var root_2238 any = A_arbace_j2g_model_A_const_239.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, A_arbace_j2g_model_top_class_A_fn_class); var ifn_2240 lang.IFn; if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any = n__0; if linked_2239 == nil { tmp5 = ifn_2240.Invoke_O__O(arg_2241) } else { tmp5 = linked_2239.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_2238, arg_2241) }; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)
//line :822:1
		if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_2242 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2244 lang.IFn

			if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any; var root_2246 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = seen__3; var arg_2250 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_121.Invoke_O__O(m__2)); if linked_2247 == nil { arg_2245 = ifn_2248.Invoke_O_O__O(arg_2249, arg_2250) } else { arg_2245 = linked_2247.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2246, arg_2249, arg_2250) }; if linked_2243 == nil { and__1927000168__auto____11 = ifn_2244.Invoke_O__O(arg_2245) } else { and__1927000168__auto____11 = linked_2243.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2242, arg_2245) }
//line :822:1
			if jrt.J2g_Truth(and__1927000168__auto____11) { var seen__12 any; var root_2251 any = A_arbace_j2g_model_A_const_15.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2251, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2253 lang.IFn


				if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any = seen__3; var arg_2255 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_121.Invoke_O__O(m__2)); if linked_2252 == nil { seen__12 = ifn_2253.Invoke_O_O__O(arg_2254, arg_2255) } else { seen__12 = linked_2252.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2251, arg_2254, arg_2255) }
//line :822:1
				var call__13 any = A_arbace_j2g_model_A_const_240.Invoke_O__O(ab__6); var sup__14 any = A_arbace_j2g_model_A_const_87.Invoke_O__O(d__5); var and__1927000168__auto____15 any; var root_2256 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2258 lang.IFn





				if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = A_arbace_j2g_model_A_const_241.Invoke_O__O(ab__6); if linked_2257 == nil { and__1927000168__auto____15 = ifn_2258.Invoke_O__O(arg_2259) } else { and__1927000168__auto____15 = linked_2257.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2256, arg_2259) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_2260 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2262 lang.IFn
					if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any = A_arbace_j2g_model_A_const_242.Invoke_O__O(ab__6); if linked_2261 == nil { and__1927000168__auto____16 = ifn_2262.Invoke_O__O(arg_2263) } else { and__1927000168__auto____16 = linked_2261.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2260, arg_2263) }
//line :828:1
					if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z_NoInit(call__13, nil)

						if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var root_2264 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2266 lang.IFn
							if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any; var fnbody__2276 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A_New_O_O(n__0, seen__12); var tmp6 *jrt.Class; var fncls__2275 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A_fn_class; if fncls__2275 == nil { var fncls__2275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__2276); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A_fn_class = fncls__2275d; tmp6 = fncls__2275d } else { tmp6 = fncls__2275 }; arg_2267 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2276, tmp6, nil); var arg_2268 any = A_arbace_j2g_model_A_const_244.Invoke_O__O(call__13); if linked_2265 == nil { and__1927000168__auto____18 = ifn_2266.Invoke_O_O__O(arg_2267, arg_2268) } else { and__1927000168__auto____18 = linked_2265.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2264, arg_2267, arg_2268) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_181.Invoke_O__O(call__13), nil)
								if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19).Ref() } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_245); var or__1927000174__auto____20 any = tmp7.Invoke_O__O(A_arbace_j2g_model_A_const_181.Invoke_O__O(call__13)); if jrt.J2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
									var root_2277 any = A_arbace_j2g_model_A_const_246.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = n__0; var arg_2281 any = A_arbace_j2g_model_A_const_181.Invoke_O__O(call__13); var arg_2282 any = A_arbace_j2g_model_A_const_247.Invoke_O__O(call__13); var arg_2283 any = seen__12; if linked_2278 == nil { and__1927000168__auto____17 = ifn_2279.Invoke_O_O_O_O__O(arg_2280, arg_2281, arg_2282, arg_2283) } else { and__1927000168__auto____17 = linked_2278.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_2277, arg_2280, arg_2281, arg_2282, arg_2283) } } } } else {
//line :831:1
										and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :828:1
						if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any; var root_2284 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2286 lang.IFn





							if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = call__13; if linked_2285 == nil { or__1927000174__auto____18 = ifn_2286.Invoke_O__O(arg_2287) } else { or__1927000174__auto____18 = linked_2285.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2284, arg_2287) }; if jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z_NoInit(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sup__14, Lit_44)).Ref() } }
//line :828:1
							if jrt.J2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var root_2288 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2290 lang.IFn






								if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any; var fnbody__2300 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A_New_O_O(n__0, seen__12); var tmp8 *jrt.Class; var fncls__2299 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A_fn_class; if fncls__2299 == nil { var fncls__2299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__2300); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A_fn_class = fncls__2299d; tmp8 = fncls__2299d } else { tmp8 = fncls__2299 }; arg_2291 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2300, tmp8, nil); var arg_2292 any; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_248; var tmp10 any; var root_2301 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = A_arbace_j2g_model_A_const_225.Invoke_O__O(d__5); if linked_2302 == nil { tmp10 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp10 = linked_2302.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2301, arg_2304) }; arg_2292 = tmp9.Invoke_O__O(tmp10); if linked_2289 == nil { and__1927000168__auto____19 = ifn_2290.Invoke_O_O__O(arg_2291, arg_2292) } else { and__1927000168__auto____19 = linked_2289.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2288, arg_2291, arg_2292) }
//line :828:1
								if jrt.J2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_249.Invoke_O__O(ab__6), nil)







									if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20_2).Ref() } else { var root_2305 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = n__0; var arg_2309 any = A_arbace_j2g_model_A_const_249.Invoke_O__O(ab__6); var arg_2310 any = seen__12; if linked_2306 == nil { return ifn_2307.Invoke_O_O_O__O(arg_2308, arg_2309, arg_2310) } else { return linked_2306.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2305, arg_2308, arg_2309, arg_2310) } } } else {
//line :828:1
										return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :822:1
											return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A{}; t.Ctor_O_O(p0, p1); return t }
//line :831:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :831:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A) Invoke_O_O__O(self, p1__1479000221_SHARP___1 any) any { var root_2269 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2269, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2271 lang.IFn; if linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = t.F_n; var arg_2273 any = p1__1479000221_SHARP___1; var arg_2274 any = t.F_seen; if linked_2270 == nil { return ifn_2271.Invoke_O_O_O__O(arg_2272, arg_2273, arg_2274) } else { return linked_2270.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2269, arg_2272, arg_2273, arg_2274) } }



func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A{}; t.Ctor_O_O(p0, p1); return t }
//line :835:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :835:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A) Invoke_O_O__O(self, p1__1479000222_SHARP___1 any) any { var root_2293 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = t.F_n; var arg_2297 any = p1__1479000222_SHARP___1; var arg_2298 any = t.F_seen; if linked_2294 == nil { return ifn_2295.Invoke_O_O_O__O(arg_2296, arg_2297, arg_2298) } else { return linked_2294.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2293, arg_2296, arg_2297, arg_2298) } }


func A_arbace_j2g_model_pure_node_QMARK__A_New() *A_arbace_j2g_model_pure_node_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :838:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Ctor() {}
//line :838:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1479000234__4_ any = A_arbace_j2g_model_A_const_250.Invoke_O__O(node__1); switch



	lang.Util_Hash_O__I_NoInit(G__1479000234__4_) >> 3 & 63 { case 1: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_251) { var and__1927000168__auto____5 any; var root_2312 any = A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_2314 lang.IFn


















		if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = A_arbace_j2g_model_A_const_252.Invoke_O__O(node__1); if linked_2313 == nil { and__1927000168__auto____5 = ifn_2314.Invoke_O__O(arg_2315) } else { and__1927000168__auto____5 = linked_2313.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_2312, arg_2315) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2316 any = A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = A_arbace_j2g_model_A_const_253.Invoke_O__O(node__1); if linked_2317 == nil { and__1927000168__auto____6 = ifn_2318.Invoke_O__O(arg_2319) } else { and__1927000168__auto____6 = linked_2317.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_2316, arg_2319) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2320 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = n__0; var arg_2324 any = A_arbace_j2g_model_A_const_254.Invoke_O__O(node__1); var arg_2325 any = seen__2; if linked_2321 == nil { return ifn_2322.Invoke_O_O_O__O(arg_2323, arg_2324, arg_2325) } else { return linked_2321.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2320, arg_2323, arg_2324, arg_2325) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :842:1
	case 11: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_255) { var tmp1 any = A_arbace_j2g_model_A_const_256; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_250; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_257.Invoke_O__O(node__1)))







		if and__1927000168__auto____5_2 { var and__1927000168__auto____6_2 any; var root_2326 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_258; var arg_2329 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_257.Invoke_O__O(node__1)); if linked_2327 == nil { and__1927000168__auto____6_2 = ifn_2328.Invoke_O__O(arg_2329) } else { and__1927000168__auto____6_2 = linked_2327.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2326, arg_2329) }; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var root_2330 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2330, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = n__0; var arg_2334 any = A_arbace_j2g_model_A_const_259.Invoke_O__O(node__1); var arg_2335 any = seen__2; if linked_2331 == nil { return ifn_2332.Invoke_O_O_O__O(arg_2333, arg_2334, arg_2335) } else { return linked_2331.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2330, arg_2333, arg_2334, arg_2335) } } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() } }
//line :842:1
	case 13: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_260) { var tmp4 any = A_arbace_j2g_model_A_const_261; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_j2g_model_A_const_176.Invoke_O__O(node__1))













		if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_83, A_arbace_j2g_model_A_const_157.Invoke_O__O(node__1))
			if and__1927000168__auto____6_4 { or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_84, A_arbace_j2g_model_A_const_131.Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, A_arbace_j2g_model_A_const_157.Invoke_O__O(node__1))

				if and__1927000168__auto____7 { and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_85, A_arbace_j2g_model_A_const_131.Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :856:1
			if and__1927000168__auto____6_3 {



				var root_2336 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2338 lang.IFn; if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any; var fnbody__2348 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A_New_O_O(n__0, seen__2); var tmp5 *jrt.Class; var fncls__2347 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A_fn_class; if fncls__2347 == nil { var fncls__2347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__2348); A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A_fn_class = fncls__2347d; tmp5 = fncls__2347d } else { tmp5 = fncls__2347 }; arg_2339 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2348, tmp5, nil); var arg_2340 any = A_arbace_j2g_model_A_const_244.Invoke_O__O(node__1); if linked_2337 == nil { return ifn_2338.Invoke_O_O__O(arg_2339, arg_2340) } else { return linked_2337.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2336, arg_2339, arg_2340) } } else {
//line :856:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_3).Ref() } }
//line :842:1
	case 14: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_262) { var and__1927000168__auto____5_4 bool; var tmp6 any; var tmp7 *lang.Keyword = A_arbace_j2g_model_A_const_263; var or__1927000174__auto____5 any = tmp7.Invoke_O__O(A_arbace_j2g_model_A_const_264.Invoke_O__O(node__1))






		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp6 = or__1927000174__auto____5 } else { var tmp8 *lang.Keyword = A_arbace_j2g_model_A_const_157; tmp6 = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_264.Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp6); if and__1927000168__auto____5_4 { var root_2349 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2349, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2351 lang.IFn; if linked_2350 == nil { ifn_2351 = lang.IFn_Cast(root_2349) } else { ifn_2351 = nil }; var arg_2352 any = n__0; var arg_2353 any = A_arbace_j2g_model_A_const_259.Invoke_O__O(node__1); var arg_2354 any = seen__2; if linked_2350 == nil { return ifn_2351.Invoke_O_O_O__O(arg_2352, arg_2353, arg_2354) } else { return linked_2350.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2349, arg_2352, arg_2353, arg_2354) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_4).Ref() } }
//line :842:1
	case 15: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_256) { return jrt.Boolean_TRUE.Ref() }; case 19: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_265) { var and__1927000168__auto____5_5 any; var root_2355 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2357 lang.IFn


		if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any; var fnbody__2367 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A_New_O_O(n__0, seen__2); var tmp9 *jrt.Class; var fncls__2366 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A_fn_class; if fncls__2366 == nil { var fncls__2366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__2367); A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A_fn_class = fncls__2366d; tmp9 = fncls__2366d } else { tmp9 = fncls__2366 }; arg_2358 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2367, tmp9, nil); var arg_2359 any = A_arbace_j2g_model_A_const_266.Invoke_O__O(node__1); if linked_2356 == nil { and__1927000168__auto____5_5 = ifn_2357.Invoke_O_O__O(arg_2358, arg_2359) } else { and__1927000168__auto____5_5 = linked_2356.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2355, arg_2358, arg_2359) }; if jrt.J2g_Truth(and__1927000168__auto____5_5) { var root_2368 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = n__0; var arg_2372 any = A_arbace_j2g_model_A_const_249.Invoke_O__O(node__1); var arg_2373 any = seen__2; if linked_2369 == nil { return ifn_2370.Invoke_O_O_O__O(arg_2371, arg_2372, arg_2373) } else { return linked_2369.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2368, arg_2371, arg_2372, arg_2373) } } else { return and__1927000168__auto____5_5 } }
//line :842:1
	case 21: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_267) {





		var tmp10 any; var tmp11 *lang.Keyword = A_arbace_j2g_model_A_const_263; var or__1927000174__auto____5_2 any = tmp11.Invoke_O__O(A_arbace_j2g_model_A_const_264.Invoke_O__O(node__1)); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp10 = or__1927000174__auto____5_2 } else { var tmp12 *lang.Keyword = A_arbace_j2g_model_A_const_157; tmp10 = tmp12.Invoke_O__O(A_arbace_j2g_model_A_const_264.Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp10)).Ref() }
//line :842:1
	case 25: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_268) { var and__1927000168__auto____5_6 any; var root_2374 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2376 lang.IFn

		if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any; var fnbody__2386 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A_New_O_O(n__0, seen__2); var tmp13 *jrt.Class; var fncls__2385 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A_fn_class; if fncls__2385 == nil { var fncls__2385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__2386); A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A_fn_class = fncls__2385d; tmp13 = fncls__2385d } else { tmp13 = fncls__2385 }; arg_2377 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2386, tmp13, nil); var arg_2378 any = A_arbace_j2g_model_A_const_269.Invoke_O__O(node__1); if linked_2375 == nil { and__1927000168__auto____5_6 = ifn_2376.Invoke_O_O__O(arg_2377, arg_2378) } else { and__1927000168__auto____5_6 = linked_2375.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2374, arg_2377, arg_2378) }; if jrt.J2g_Truth(and__1927000168__auto____5_6) { var root_2387 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = n__0; var arg_2391 any = A_arbace_j2g_model_A_const_270.Invoke_O__O(node__1); var arg_2392 any = seen__2; if linked_2388 == nil { return ifn_2389.Invoke_O_O_O__O(arg_2390, arg_2391, arg_2392) } else { return linked_2388.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2387, arg_2390, arg_2391, arg_2392) } } else { return and__1927000168__auto____5_6 } }
//line :842:1
	case 29: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_271) { return jrt.Boolean_TRUE.Ref() }; case 30: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_272) { return jrt.Boolean_TRUE.Ref() }; case 34: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_273) {




		var root_2393 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any; var fnbody__2407 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A_New(); var tmp14 *jrt.Class; var fncls__2406 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A_fn_class; if fncls__2406 == nil { var fncls__2406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A_fn_class = fncls__2406d; tmp14 = fncls__2406d } else { tmp14 = fncls__2406 }; arg_2396 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2407, tmp14, nil); var arg_2397 any = A_arbace_j2g_model_A_const_275.Invoke_O__O(node__1); if linked_2394 == nil { return ifn_2395.Invoke_O_O__O(arg_2396, arg_2397) } else { return linked_2394.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2393, arg_2396, arg_2397) } }
//line :842:1
	case 39: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_276) { var and__1927000168__auto____5_7 any; var root_2408 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2408, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2410 lang.IFn








		if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any; var fnbody__2420 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A_New_O_O(n__0, seen__2); var tmp15 *jrt.Class; var fncls__2419 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A_fn_class; if fncls__2419 == nil { var fncls__2419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__2420); A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A_fn_class = fncls__2419d; tmp15 = fncls__2419d } else { tmp15 = fncls__2419 }; arg_2411 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2420, tmp15, nil); var arg_2412 any = A_arbace_j2g_model_A_const_244.Invoke_O__O(node__1); if linked_2409 == nil { and__1927000168__auto____5_7 = ifn_2410.Invoke_O_O__O(arg_2411, arg_2412) } else { and__1927000168__auto____5_7 = linked_2409.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2408, arg_2411, arg_2412) }; if jrt.J2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_277.Invoke_O__O(node__1), nil); if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_44, A_arbace_j2g_model_A_const_181.Invoke_O__O(node__1))

			if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_model_A_const_181.Invoke_O__O(node__1), n__0)
				if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_2421 any = A_arbace_j2g_model_A_const_223.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2423 lang.IFn; if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = A_arbace_j2g_model_A_const_181.Invoke_O__O(node__1); if linked_2422 == nil { and__1927000168__auto____8 = ifn_2423.Invoke_O__O(arg_2424) } else { and__1927000168__auto____8 = linked_2422.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2421, arg_2424) } }; if jrt.J2g_Truth(and__1927000168__auto____8) {
					var root_2425 any = A_arbace_j2g_model_A_const_246.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_2427 lang.IFn; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = n__0; var arg_2429 any = A_arbace_j2g_model_A_const_181.Invoke_O__O(node__1); var arg_2430 any = A_arbace_j2g_model_A_const_247.Invoke_O__O(node__1); var arg_2431 any = seen__2; if linked_2426 == nil { return ifn_2427.Invoke_O_O_O_O__O(arg_2428, arg_2429, arg_2430, arg_2431) } else { return linked_2426.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_2425, arg_2428, arg_2429, arg_2430, arg_2431) } } else {
//line :854:1
						return and__1927000168__auto____8 } } } else {
//line :851:1
							return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :842:1
	case 43: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_278) { var and__1927000168__auto____5_8 any; var root_2432 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2432, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2434 lang.IFn



















		if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_279); var arg_2435 any = tmp16.Invoke_O__O(A_arbace_j2g_model_A_const_280.Invoke_O__O(node__1)); if linked_2433 == nil { and__1927000168__auto____5_8 = ifn_2434.Invoke_O__O(arg_2435) } else { and__1927000168__auto____5_8 = linked_2433.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2432, arg_2435) }; if jrt.J2g_Truth(and__1927000168__auto____5_8) { var and__1927000168__auto____6_6 any; var root_2436 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2436, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2438 lang.IFn; if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = A_arbace_j2g_model_A_const_281; var arg_2440 any = A_arbace_j2g_model_A_const_282.Invoke_O__O(node__1); if linked_2437 == nil { and__1927000168__auto____6_6 = ifn_2438.Invoke_O_O__O(arg_2439, arg_2440) } else { and__1927000168__auto____6_6 = linked_2437.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2436, arg_2439, arg_2440) }; if jrt.J2g_Truth(and__1927000168__auto____6_6) { var root_2441 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any; var fnbody__2453 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A_New_O_O(n__0, seen__2); var tmp17 *jrt.Class; var fncls__2452 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A_fn_class; if fncls__2452 == nil { var fncls__2452d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__2453); A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A_fn_class = fncls__2452d; tmp17 = fncls__2452d } else { tmp17 = fncls__2452 }; arg_2444 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2453, tmp17, nil); var arg_2445 any = A_arbace_j2g_model_A_const_244.Invoke_O__O(node__1); if linked_2442 == nil { return ifn_2443.Invoke_O_O__O(arg_2444, arg_2445) } else { return linked_2442.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2441, arg_2444, arg_2445) } } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :842:1
	case 44: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_283) { return jrt.Boolean_TRUE.Ref() }; case 46: if any(G__1479000234__4_) == any(A_arbace_j2g_model_A_const_284) {



		var root_2454 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2456 lang.IFn; if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any; var fnbody__2466 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A_New_O_O(n__0, seen__2); var tmp18 *jrt.Class; var fncls__2465 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A_fn_class; if fncls__2465 == nil { var fncls__2465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__2466); A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A_fn_class = fncls__2465d; tmp18 = fncls__2465d } else { tmp18 = fncls__2465 }; arg_2457 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2466, tmp18, nil); var arg_2458 any = A_arbace_j2g_model_A_const_285.Invoke_O__O(node__1); if linked_2455 == nil { return ifn_2456.Invoke_O_O__O(arg_2457, arg_2458) } else { return linked_2455.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2454, arg_2457, arg_2458) } }
//line :842:1
	default:}; return jrt.Boolean_FALSE.Ref() }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A{}; t.Ctor_O_O(p0, p1); return t }
//line :844:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :844:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A) Invoke_O_O__O(self, p1__1479000228_SHARP___1 any) any { var root_2379 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2381 lang.IFn; if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = t.F_n; var arg_2383 any = p1__1479000228_SHARP___1; var arg_2384 any = t.F_seen; if linked_2380 == nil { return ifn_2381.Invoke_O_O_O__O(arg_2382, arg_2383, arg_2384) } else { return linked_2380.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2379, arg_2382, arg_2383, arg_2384) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A{}; t.Ctor_O_O(p0, p1); return t }
//line :845:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :845:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A) Invoke_O_O__O(self, p__1479000237__1 any) any { var vec__1479000239__2 any = p__1479000237__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000239__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000239__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2360 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2362 lang.IFn; _ = ___3; if linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any = t.F_n; var arg_2364 any = init__4; var arg_2365 any = t.F_seen; if linked_2361 == nil { return ifn_2362.Invoke_O_O_O__O(arg_2363, arg_2364, arg_2365) } else { return linked_2361.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2360, arg_2363, arg_2364, arg_2365) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :846:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :846:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A) Invoke_O_O__O(self, p1__1479000229_SHARP___1 any) any { var root_2459 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2461 lang.IFn; if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any = t.F_n; var arg_2463 any = p1__1479000229_SHARP___1; var arg_2464 any = t.F_seen; if linked_2460 == nil { return ifn_2461.Invoke_O_O_O__O(arg_2462, arg_2463, arg_2464) } else { return linked_2460.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2459, arg_2462, arg_2463, arg_2464) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A_New() *A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A{}; t.Ctor(); return t }
//line :847:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A) Ctor() {}
//line :847:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A) Invoke_O_O__O(self, p1__1479000230_SHARP___1 any) any { var tmp1 any = A_arbace_j2g_model_A_const_271; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_model_A_const_250.Invoke_O__O(p1__1479000230_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_2398 any = A_arbace_j2g_model_A_const_274.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2398, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_2400 lang.IFn; if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = A_arbace_j2g_model_A_const_259.Invoke_O__O(p1__1479000230_SHARP___1); if linked_2399 == nil { and__1927000168__auto____3 = ifn_2400.Invoke_O__O(arg_2401) } else { and__1927000168__auto____3 = linked_2399.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_2398, arg_2401) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2402 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_j2g_model_A_const_259.Invoke_O__O(p1__1479000230_SHARP___1)))).Ref(); if linked_2403 == nil { return ifn_2404.Invoke_O__O(arg_2405) } else { return linked_2403.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2402, arg_2405) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A{}; t.Ctor_O_O(p0, p1); return t }
//line :851:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :851:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A) Invoke_O_O__O(self, p1__1479000231_SHARP___1 any) any { var root_2413 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2413, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2415 lang.IFn; if linked_2414 == nil { ifn_2415 = lang.IFn_Cast(root_2413) } else { ifn_2415 = nil }; var arg_2416 any = t.F_n; var arg_2417 any = p1__1479000231_SHARP___1; var arg_2418 any = t.F_seen; if linked_2414 == nil { return ifn_2415.Invoke_O_O_O__O(arg_2416, arg_2417, arg_2418) } else { return linked_2414.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2413, arg_2416, arg_2417, arg_2418) } }








func A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A{}; t.Ctor_O_O(p0, p1); return t }
//line :860:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :860:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A) Invoke_O_O__O(self, p1__1479000232_SHARP___1 any) any { var root_2341 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2343 lang.IFn; if linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any = t.F_n; var arg_2345 any = p1__1479000232_SHARP___1; var arg_2346 any = t.F_seen; if linked_2342 == nil { return ifn_2343.Invoke_O_O_O__O(arg_2344, arg_2345, arg_2346) } else { return linked_2342.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2341, arg_2344, arg_2345, arg_2346) } }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A{}; t.Ctor_O_O(p0, p1); return t }
//line :862:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :862:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A) Invoke_O_O__O(self, p1__1479000233_SHARP___1 any) any { var root_2446 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2448 lang.IFn; if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = t.F_n; var arg_2450 any = p1__1479000233_SHARP___1; var arg_2451 any = t.F_seen; if linked_2447 == nil { return ifn_2448.Invoke_O_O_O__O(arg_2449, arg_2450, arg_2451) } else { return linked_2447.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2446, arg_2449, arg_2450, arg_2451) } }


func A_arbace_j2g_model_benign_init_QMARK__A_New() *A_arbace_j2g_model_benign_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :865:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Ctor() {}
//line :865:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_224; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_37.Get__O()); var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_287, n__0); var tmp2 any; var root_2467 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2469 lang.IFn; if








	linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any; var root_2472 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = cache__2; if linked_2473 == nil { arg_2470 = ifn_2474.Invoke_O__O(arg_2475) } else { arg_2470 = linked_2473.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2472, arg_2475) }; var arg_2471 any = k__3; if linked_2468 == nil { tmp2 = ifn_2469.Invoke_O_O__O(arg_2470, arg_2471) } else { tmp2 = linked_2468.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2467, arg_2470, arg_2471) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_2476 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = cache__2; if linked_2477 == nil { tmp3 = ifn_2478.Invoke_O__O(arg_2479) } else { tmp3 = linked_2477.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2476, arg_2479) }; return lang.RT_Get_O_O__O_NoInit(tmp3, k__3) } else {
//line :874:1
			var r__4 any; var tmp4 any; var root_2480 any = A_arbace_j2g_model_A_const_223.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2482 lang.IFn


			if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = n__0; if linked_2481 == nil { tmp4 = ifn_2482.Invoke_O__O(arg_2483) } else { tmp4 = linked_2481.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2480, arg_2483) }
//line :876:1
			if jrt.J2g_Truth(tmp4) { r__4 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_2484 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2486 lang.IFn

				if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = n__0; if linked_2485 == nil { tmp5 = ifn_2486.Invoke_O__O(arg_2487) } else { tmp5 = linked_2485.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2484, arg_2487) }
//line :876:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__4 = jrt.Boolean_FALSE.Ref() } else { if A_arbace_j2g_model_A_const_68 != nil { var d__4 any; var root_2488 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2488, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2490 lang.IFn


					if linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = n__0; if linked_2489 == nil { d__4 = ifn_2490.Invoke_O__O(arg_2491) } else { d__4 = linked_2489.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2488, arg_2491) }
//line :876:1
					var st__5 any; var root_2492 any = A_arbace_j2g_model_A_const_13.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2494 lang.IFn


					if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = A_arbace_j2g_model_A_const_225.Invoke_O__O(d__4); if linked_2493 == nil { st__5 = ifn_2494.Invoke_O__O(arg_2495) } else { st__5 = linked_2493.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2492, arg_2495) }
//line :876:1
					var and__1927000168__auto____6 any; var root_2496 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_2497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2496, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2498 lang.IFn




					if linked_2497 == nil { ifn_2498 = lang.IFn_Cast(root_2496) } else { ifn_2498 = nil }; var arg_2499 any = A_arbace_j2g_model_A_const_227.Invoke_O__O(st__5); if linked_2497 == nil { and__1927000168__auto____6 = ifn_2498.Invoke_O__O(arg_2499) } else { and__1927000168__auto____6 = linked_2497.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2496, arg_2499) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2500 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2500, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2502 lang.IFn
						if linked_2501 == nil { ifn_2502 = lang.IFn_Cast(root_2500) } else { ifn_2502 = nil }; var arg_2503 any = A_arbace_j2g_model_A_const_228.Invoke_O__O(st__5); if linked_2501 == nil { and__1927000168__auto____7 = ifn_2502.Invoke_O__O(arg_2503) } else { and__1927000168__auto____7 = linked_2501.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2500, arg_2503) }
//line :881:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_2504 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2506 lang.IFn

							if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = A_arbace_j2g_model_A_const_229.Invoke_O__O(st__5); if linked_2505 == nil { and__1927000168__auto____8 = ifn_2506.Invoke_O__O(arg_2507) } else { and__1927000168__auto____8 = linked_2505.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2504, arg_2507) }
//line :881:1
							if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_87.Invoke_O__O(d__4), nil)


								if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_2508 any = A_arbace_j2g_model_A_const_286.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2508, A_arbace_j2g_model_benign_init_QMARK__A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = A_arbace_j2g_model_A_const_87.Invoke_O__O(d__4); if linked_2509 == nil { and__1927000168__auto____9 = ifn_2510.Invoke_O__O(arg_2511) } else { and__1927000168__auto____9 = linked_2509.(*A_arbace_j2g_model_benign_init_QMARK__A).Invoke_O_O__O(root_2508, arg_2511) } }
//line :881:1
								if jrt.J2g_Truth(and__1927000168__auto____9) {



									var root_2512 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2512, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2514 lang.IFn; if linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any; var fnbody__2524 any = A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A_New_O(n__0); var tmp6 *jrt.Class; var fncls__2523 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A_fn_class; if fncls__2523 == nil { var fncls__2523d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__2524); A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A_fn_class = fncls__2523d; tmp6 = fncls__2523d } else { tmp6 = fncls__2523 }; arg_2515 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2524, tmp6, nil); var arg_2516 any = A_arbace_j2g_model_A_const_226.Invoke_O__O(st__5); if linked_2513 == nil { r__4 = ifn_2514.Invoke_O_O__O(arg_2515, arg_2516) } else { r__4 = linked_2513.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2512, arg_2515, arg_2516) } } else {
//line :881:1
										r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :876:1
											r__4 = nil
										}
				}
			}






			var root_2525 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any = cache__2; var arg_2529 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var arg_2530 any = k__3; var arg_2531 any = r__4; if linked_2526 == nil { ifn_2527.Invoke_O_O_O_O__O(arg_2528, arg_2529, arg_2530, arg_2531) } else { linked_2526.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2525, arg_2528, arg_2529, arg_2530, arg_2531) }
//line :874:1
			return r__4 } }










func A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A_New_O(p0 any) *A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A{}; t.Ctor_O(p0); return t }
//line :885:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :885:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A) Invoke_O_O__O(self, p1__1479000254_SHARP___1 any) any { var root_2517 any = A_arbace_j2g_model_A_const_243.GetRawRoot__O(); var linked_2518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2517, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2519 lang.IFn; if linked_2518 == nil { ifn_2519 = lang.IFn_Cast(root_2517) } else { ifn_2519 = nil }; var arg_2520 any = t.F_n; var arg_2521 any = p1__1479000254_SHARP___1; var arg_2522 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_2518 == nil { return ifn_2519.Invoke_O_O_O__O(arg_2520, arg_2521, arg_2522) } else { return linked_2518.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2517, arg_2520, arg_2521, arg_2522) } }
























func A_arbace_j2g_model_class_loader_resource_target_A_New() *A_arbace_j2g_model_class_loader_resource_target_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_loader_resource_target_A{}; t.Ctor(); return t }
//line :910:1
func (t *A_arbace_j2g_model_class_loader_resource_target_A) Ctor() {}
//line :910:1
func (t *A_arbace_j2g_model_class_loader_resource_target_A) Invoke_O_O_O__O(self, nme__0, desc__1 any) any {




	var tmp1 any; var root_2532 any = A_arbace_j2g_model_A_const_49.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2532, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any = nme__0; var arg_2536 any = Lit_15; if linked_2533 == nil { tmp1 = ifn_2534.Invoke_O_O__O(arg_2535, arg_2536) } else { tmp1 = linked_2533.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2532, arg_2535, arg_2536) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp3 any; var root_2537 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_2538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2537, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2539 lang.IFn
		if linked_2538 == nil { ifn_2539 = lang.IFn_Cast(root_2537) } else { ifn_2539 = nil }; var arg_2540 any = nme__0; var arg_2541 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(Lit_15)).Ref(); if linked_2538 == nil { tmp3 = ifn_2539.Invoke_O_O__O(arg_2540, arg_2541) } else { tmp3 = linked_2538.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2537, arg_2540, arg_2541) }
//line :915:1
		return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(), desc__1) } else { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil); var tmp5 any; var root_2542 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_2543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2542, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2544 lang.IFn

			if linked_2543 == nil { ifn_2544 = lang.IFn_Cast(root_2542) } else { ifn_2544 = nil }; var arg_2545 any = desc__1; var arg_2546 any = A_arbace_j2g_model_A_const_288; if linked_2543 == nil { tmp5 = ifn_2544.Invoke_O_O__O(arg_2545, arg_2546) } else { tmp5 = linked_2543.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2542, arg_2545, arg_2546) }
//line :915:1
			return lang.Tuple_Create_O_O__IPersistentVector(nme__0, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref())
		}
}

func A_arbace_j2g_model_class_loader_resource_ready_QMARK__A_New() *A_arbace_j2g_model_class_loader_resource_ready_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_loader_resource_ready_QMARK__A{}; t.Ctor(); return t }
//line :919:1
func (t *A_arbace_j2g_model_class_loader_resource_ready_QMARK__A) Ctor() {}
//line :919:1
func (t *A_arbace_j2g_model_class_loader_resource_ready_QMARK__A) Invoke_O_O_O__O(self, nme__0, desc__1 any) any { var vec__1479000260__3 any; var root_2547 any = A_arbace_j2g_model_A_const_289.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, A_arbace_j2g_model_class_loader_resource_target_A_fn_class); var ifn_2549 lang.IFn; if



	linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any = nme__0; var arg_2551 any = desc__1; if linked_2548 == nil { vec__1479000260__3 = ifn_2549.Invoke_O_O__O(arg_2550, arg_2551) } else { vec__1479000260__3 = linked_2548.(*A_arbace_j2g_model_class_loader_resource_target_A).Invoke_O_O_O__O(root_2547, arg_2550, arg_2551) }; var n__4 any = /*line :919:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1479000260__3, lang.RT_IntCast_J__I_NoInit(0), nil); var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000260__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_2552 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2554 lang.IFn; if




	linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any; var fnbody__2558 any = A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A_New_O_O(n__4, d__5); var tmp2 *jrt.Class; var fncls__2557 *jrt.Class = A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A_fn_class; if fncls__2557 == nil { var fncls__2557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__2558); A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A_fn_class = fncls__2557d; tmp2 = fncls__2557d } else { tmp2 = fncls__2557 }; arg_2555 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2558, tmp2, nil); var arg_2556 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_58; var tmp4 any; var root_2559 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = Lit_14; if linked_2560 == nil { tmp4 = ifn_2561.Invoke_O__O(arg_2562) } else { tmp4 = linked_2560.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2559, arg_2562) }; arg_2556 = tmp3.Invoke_O__O(tmp4); if linked_2553 == nil { tmp1 = ifn_2554.Invoke_O_O__O(arg_2555, arg_2556) } else { tmp1 = linked_2553.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2552, arg_2555, arg_2556) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
//line :924:1
func A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A{}; t.Ctor_O_O(p0, p1); return t }
//line :924:1
func (t *A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A) Ctor_O_O(c__n, c__d any) { t.F_n = c__n; t.F_d = c__d }
//line :924:1
func (t *A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A) Invoke_O_O__O(self, p1__1479000259_SHARP___1 any) any { var tmp1 any = t.F_n; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_model_A_const_131.Invoke_O__O(p1__1479000259_SHARP___1)); if and__1927000168__auto____2 { var tmp2 any = t.F_d; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_model_A_const_121.Invoke_O__O(p1__1479000259_SHARP___1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }






















func A_arbace_j2g_model_fn__1479000270_A_New() *A_arbace_j2g_model_fn__1479000270_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000270_A{}; t.Ctor(); return t }
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_A) Ctor() {}
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__2624 any = A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A_New(); var tmp1 *jrt.Class; var fncls__2623 *jrt.Class = A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A_fn_class; if fncls__2623 == nil { var fncls__2623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A_fn_class = fncls__2623d; tmp1 = fncls__2623d } else { tmp1 = fncls__2623 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2624, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_model_A_const_290.GetRawRoot__O()) }
//line :947:1
func A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A_New() *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A{}; t.Ctor(); return t }
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A) Ctor() {}
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A) Invoke_O_O__O(self, s__1479000267__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2622 any = A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A_New_O_O(s__1479000267__1, self); var tmp2 *jrt.Class; var fncls__2621 *jrt.Class = A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A_fn_class; if fncls__2621 == nil { var fncls__2621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__2622); A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A_fn_class = fncls__2621d; tmp2 = fncls__2621d } else { tmp2 = fncls__2621 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2622, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :947:1
func A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A{}; t.Ctor_O_O(p0, p1); return t }
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A) Ctor_O_O(c__s__1479000267, c__iter__1479000266 any) { t.F_s__1479000267 = c__s__1479000267; t.F_iter__1479000266 = c__iter__1479000266 }
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A) Invoke_O__O(self any) any { { var s__1479000267__1 any; var t_ any = t.F_s__1479000267; t.F_s__1479000267 = nil; s__1479000267__1 = t_; for { var temp__1927000414__auto____2 any; var root_2563 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any = s__1479000267__1; if linked_2564 == nil { temp__1927000414__auto____2 = ifn_2565.Invoke_O__O(arg_2566) } else { temp__1927000414__auto____2 = linked_2564.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2563, arg_2566) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000267__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2567 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2567, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2569 lang.IFn; if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any = s__1479000267__3; if linked_2568 == nil { tmp1 = ifn_2569.Invoke_O__O(arg_2570) } else { tmp1 = linked_2568.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2567, arg_2570) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2571 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2573 lang.IFn; if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = s__1479000267__3; if linked_2572 == nil { c__1927001037__auto____4 = ifn_2573.Invoke_O__O(arg_2574) } else { c__1927001037__auto____4 = linked_2572.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2571, arg_2574) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000269__6 any; var root_2575 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_2576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2575, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2577 lang.IFn; if linked_2576 == nil { ifn_2577 = lang.IFn_Cast(root_2575) } else { ifn_2577 = nil }; var arg_2578 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2576 == nil { b__1479000269__6 = ifn_2577.Invoke_O__O(arg_2578) } else { b__1479000269__6 = linked_2576.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2575, arg_2578) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2585 any = A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A_New_O_I_O(b__1479000269__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2584 *jrt.Class = A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A_fn_class; if fncls__2584 == nil { var fncls__2584d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__2585); A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A_fn_class = fncls__2584d; tmp3 = fncls__2584d } else { tmp3 = fncls__2584 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2585, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2586 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any; var root_2591 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_2592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2591, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2593 lang.IFn; if linked_2592 == nil { ifn_2593 = lang.IFn_Cast(root_2591) } else { ifn_2593 = nil }; var arg_2594 any = b__1479000269__6; if linked_2592 == nil { arg_2589 = ifn_2593.Invoke_O__O(arg_2594) } else { arg_2589 = linked_2592.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2591, arg_2594) }; var arg_2590 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000266); var tmp5 any; var root_2595 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = s__1479000267__3; if linked_2596 == nil { tmp5 = ifn_2597.Invoke_O__O(arg_2598) } else { tmp5 = linked_2596.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2595, arg_2598) }; arg_2590 = tmp4.Invoke_O__O(tmp5); if linked_2587 == nil { return ifn_2588.Invoke_O_O__O(arg_2589, arg_2590) } else { return linked_2587.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2586, arg_2589, arg_2590) } } else { var root_2599 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2601 lang.IFn; if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any; var root_2604 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2606 lang.IFn; if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = b__1479000269__6; if linked_2605 == nil { arg_2602 = ifn_2606.Invoke_O__O(arg_2607) } else { arg_2602 = linked_2605.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2604, arg_2607) }; var arg_2603 any; if linked_2600 == nil { return ifn_2601.Invoke_O_O__O(arg_2602, arg_2603) } else { return linked_2600.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2599, arg_2602, arg_2603) } } } else { var vec__1479000278__4 any; var root_2608 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = s__1479000267__3; if linked_2609 == nil { vec__1479000278__4 = ifn_2610.Invoke_O__O(arg_2611) } else { vec__1479000278__4 = linked_2609.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2608, arg_2611) }; var nme__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000278__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000278__4, lang.RT_IntCast_J__I_NoInit(1), nil); var f__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000278__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_2612 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(Lit_32, nme__5, desc__6), lang.Tuple_Create_O_O__IPersistentVector(f__7, Lit_14)); var arg_2616 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1479000266); var tmp7 any; var root_2617 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2619 lang.IFn; if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any = s__1479000267__3; if linked_2618 == nil { tmp7 = ifn_2619.Invoke_O__O(arg_2620) } else { tmp7 = linked_2618.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2617, arg_2620) }; arg_2616 = tmp6.Invoke_O__O(tmp7); if linked_2613 == nil { return ifn_2614.Invoke_O_O__O(arg_2615, arg_2616) } else { return linked_2613.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2612, arg_2615, arg_2616) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :947:1
func A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A) Ctor_O_I_O(c__b__1479000269 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000269 = c__b__1479000269; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :947:1
func (t *A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A) Invoke_O__O(self any) any { { var i__1479000268__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000268__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1479000274__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000268__1)); var nme__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000274__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000274__2, lang.RT_IntCast_J__I_NoInit(1), nil); var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000274__2, lang.RT_IntCast_J__I_NoInit(2), nil); var root_2579 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_2580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2579, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2581 lang.IFn; if linked_2580 == nil { ifn_2581 = lang.IFn_Cast(root_2579) } else { ifn_2581 = nil }; var arg_2582 any = t.F_b__1479000269; var arg_2583 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(Lit_32, nme__3, desc__4), lang.Tuple_Create_O_O__IPersistentVector(f__5, Lit_14)); if linked_2580 == nil { ifn_2581.Invoke_O_O__O(arg_2582, arg_2583) } else { linked_2580.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2579, arg_2582, arg_2583) }; i__1479000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000268__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_model_fn__1479000288_A_New() *A_arbace_j2g_model_fn__1479000288_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000288_A{}; t.Ctor(); return t }
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_A) Ctor() {}
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__2696 any = A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A_New(); var tmp1 *jrt.Class; var fncls__2695 *jrt.Class = A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A_fn_class; if fncls__2695 == nil { var fncls__2695d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A_fn_class = fncls__2695d; tmp1 = fncls__2695d } else { tmp1 = fncls__2695 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2696, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_model_A_const_291.GetRawRoot__O()) }
//line :949:1
func A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A_New() *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A{}; t.Ctor(); return t }
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A) Ctor() {}
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A) Invoke_O_O__O(self, s__1479000285__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2694 any = A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A_New_O_O(s__1479000285__1, self); var tmp2 *jrt.Class; var fncls__2693 *jrt.Class = A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A_fn_class; if fncls__2693 == nil { var fncls__2693d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__2694); A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A_fn_class = fncls__2693d; tmp2 = fncls__2693d } else { tmp2 = fncls__2693 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2694, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :949:1
func A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A{}; t.Ctor_O_O(p0, p1); return t }
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A) Ctor_O_O(c__s__1479000285, c__iter__1479000284 any) { t.F_s__1479000285 = c__s__1479000285; t.F_iter__1479000284 = c__iter__1479000284 }
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A) Invoke_O__O(self any) any { { var s__1479000285__1 any; var t_ any = t.F_s__1479000285; t.F_s__1479000285 = nil; s__1479000285__1 = t_; for { var temp__1927000414__auto____2 any; var root_2625 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = s__1479000285__1; if linked_2626 == nil { temp__1927000414__auto____2 = ifn_2627.Invoke_O__O(arg_2628) } else { temp__1927000414__auto____2 = linked_2626.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2625, arg_2628) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000285__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2629 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = s__1479000285__3; if linked_2630 == nil { tmp1 = ifn_2631.Invoke_O__O(arg_2632) } else { tmp1 = linked_2630.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2629, arg_2632) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2633 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = s__1479000285__3; if linked_2634 == nil { c__1927001037__auto____4 = ifn_2635.Invoke_O__O(arg_2636) } else { c__1927001037__auto____4 = linked_2634.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2633, arg_2636) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000287__6 any; var root_2637 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2638 == nil { b__1479000287__6 = ifn_2639.Invoke_O__O(arg_2640) } else { b__1479000287__6 = linked_2638.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2637, arg_2640) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2652 any = A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A_New_O_I_O(b__1479000287__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2651 *jrt.Class = A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A_fn_class; if fncls__2651 == nil { var fncls__2651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__2652); A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A_fn_class = fncls__2651d; tmp3 = fncls__2651d } else { tmp3 = fncls__2651 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2652, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2653 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any; var root_2658 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2660 lang.IFn; if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any = b__1479000287__6; if linked_2659 == nil { arg_2656 = ifn_2660.Invoke_O__O(arg_2661) } else { arg_2656 = linked_2659.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2658, arg_2661) }; var arg_2657 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000284); var tmp5 any; var root_2662 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = s__1479000285__3; if linked_2663 == nil { tmp5 = ifn_2664.Invoke_O__O(arg_2665) } else { tmp5 = linked_2663.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2662, arg_2665) }; arg_2657 = tmp4.Invoke_O__O(tmp5); if linked_2654 == nil { return ifn_2655.Invoke_O_O__O(arg_2656, arg_2657) } else { return linked_2654.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2653, arg_2656, arg_2657) } } else { var root_2666 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_2667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2666, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2668 lang.IFn; if linked_2667 == nil { ifn_2668 = lang.IFn_Cast(root_2666) } else { ifn_2668 = nil }; var arg_2669 any; var root_2671 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_2672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2671, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2673 lang.IFn; if linked_2672 == nil { ifn_2673 = lang.IFn_Cast(root_2671) } else { ifn_2673 = nil }; var arg_2674 any = b__1479000287__6; if linked_2672 == nil { arg_2669 = ifn_2673.Invoke_O__O(arg_2674) } else { arg_2669 = linked_2672.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2671, arg_2674) }; var arg_2670 any; if linked_2667 == nil { return ifn_2668.Invoke_O_O__O(arg_2669, arg_2670) } else { return linked_2667.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2666, arg_2669, arg_2670) } } } else { var d__4 any; var root_2675 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_2676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2675, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2677 lang.IFn; if linked_2676 == nil { ifn_2677 = lang.IFn_Cast(root_2675) } else { ifn_2677 = nil }; var arg_2678 any = s__1479000285__3; if linked_2676 == nil { d__4 = ifn_2677.Invoke_O__O(arg_2678) } else { d__4 = linked_2676.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2675, arg_2678) }; var root_2679 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2681 lang.IFn; if linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any; var tmp6 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_36, Lit_37, d__4); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_38, nil); var tmp8 any; var root_2684 any = A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2686 lang.IFn
															if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = Lit_37; var arg_2688 any = d__4; if linked_2685 == nil { tmp8 = ifn_2686.Invoke_O_O__O(arg_2687, arg_2688) } else { tmp8 = linked_2685.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2684, arg_2687, arg_2688) }
//line :949:1
	arg_2682 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(), Lit_39)); var arg_2683 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1479000284); var tmp10 any; var root_2689 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2689, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2691 lang.IFn; if linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any = s__1479000285__3; if linked_2690 == nil { tmp10 = ifn_2691.Invoke_O__O(arg_2692) } else { tmp10 = linked_2690.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2689, arg_2692) }; arg_2683 = tmp9.Invoke_O__O(tmp10); if linked_2680 == nil { return ifn_2681.Invoke_O_O__O(arg_2682, arg_2683) } else { return linked_2680.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2679, arg_2682, arg_2683) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :949:1
func A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A) Ctor_O_I_O(c__b__1479000287 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000287 = c__b__1479000287; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :949:1
func (t *A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A) Invoke_O__O(self any) any { { var i__1479000286__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000286__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000286__1)); var root_2641 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2643 lang.IFn; if linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = t.F_b__1479000287; var arg_2645 any; var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_36, Lit_37, d__2); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_38, nil); var tmp4 any; var root_2646 any = A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2648 lang.IFn
																	if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = Lit_37; var arg_2650 any = d__2; if linked_2647 == nil { tmp4 = ifn_2648.Invoke_O_O__O(arg_2649, arg_2650) } else { tmp4 = linked_2647.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2646, arg_2649, arg_2650) }
//line :949:1
	arg_2645 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(), Lit_39)); if linked_2642 == nil { ifn_2643.Invoke_O_O__O(arg_2644, arg_2645) } else { linked_2642.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2641, arg_2644, arg_2645) }; i__1479000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000286__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_model_throwable_print_helper_A_New() *A_arbace_j2g_model_throwable_print_helper_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_throwable_print_helper_A{}; t.Ctor(); return t }
//line :952:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Ctor() {}
//line :952:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Invoke_O_O_O_O__O(self, owner__0, name__1, desc__2 any) any { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_model_A_const_292.GetRawRoot__O(), lang.Tuple_Create_O_O_O__IPersistentVector(owner__0, name__1, desc__2)); if




	jrt.J2g_Truth(temp__1927000414__auto____4) { var vec__1479000296__5 any = temp__1927000414__auto____4; var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000296__5, lang.RT_IntCast_J__I_NoInit(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000296__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____8 any; var root_2697 any = A_arbace_j2g_model_A_const_95.GetRawRoot__O(); var linked_2698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2697, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2699 lang.IFn
		if linked_2698 == nil { ifn_2699 = lang.IFn_Cast(root_2697) } else { ifn_2699 = nil }; var arg_2700 any = owner__0; if linked_2698 == nil { and__1927000168__auto____8 = ifn_2699.Invoke_O__O(arg_2700) } else { and__1927000168__auto____8 = linked_2698.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2697, arg_2700) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_2701 any = A_arbace_j2g_model_A_const_293.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2701, A_arbace_j2g_model_translatable_QMARK__A_fn_class); var ifn_2703 lang.IFn; if linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = c__7; if linked_2702 == nil { and__1927000168__auto____9 = ifn_2703.Invoke_O__O(arg_2704) } else { and__1927000168__auto____9 = linked_2702.(*A_arbace_j2g_model_translatable_QMARK__A).Invoke_O_O__O(root_2701, arg_2704) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_2705 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_2706 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2705, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2707 lang.IFn
			if linked_2706 == nil { ifn_2707 = lang.IFn_Cast(root_2705) } else { ifn_2707 = nil }; var arg_2708 any = owner__0; var arg_2709 any = Lit_32; if linked_2706 == nil { or__1927000174__auto____10 = ifn_2707.Invoke_O_O__O(arg_2708, arg_2709) } else { or__1927000174__auto____10 = linked_2706.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2705, arg_2708, arg_2709) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var root_2710 any = A_arbace_j2g_model_A_const_294.GetRawRoot__O(); var linked_2711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2710, A_arbace_j2g_model_class_loader_resource_ready_QMARK__A_fn_class); var ifn_2712 lang.IFn; if linked_2711 == nil { ifn_2712 = lang.IFn_Cast(root_2710) } else { ifn_2712 = nil }; var arg_2713 any = name__1; var arg_2714 any = desc__2; if linked_2711 == nil { tmp1 = ifn_2712.Invoke_O_O__O(arg_2713, arg_2714) } else { tmp1 = linked_2711.(*A_arbace_j2g_model_class_loader_resource_ready_QMARK__A).Invoke_O_O_O__O(root_2710, arg_2713, arg_2714) } } } else {
//line :958:1
				tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return f__6 } else { return nil } } else {
//line :957:1
					return nil } }






















































type A_arbace_j2g_model_A struct{ jrt.Object }

var A_arbace_j2g_model_A_const_pool *jrt.RefArray

var A_arbace_j2g_model_A_const_0 *lang.Var

var A_arbace_j2g_model_A_const_1 any

var A_arbace_j2g_model_A_const_2 any

var A_arbace_j2g_model_A_const_3 any

var A_arbace_j2g_model_A_const_4 any

var A_arbace_j2g_model_A_const_5 any

var A_arbace_j2g_model_A_const_6 any

var A_arbace_j2g_model_A_const_7 any

var A_arbace_j2g_model_A_const_8 any

var A_arbace_j2g_model_A_const_9 any

var A_arbace_j2g_model_A_const_10 *lang.Var

var A_arbace_j2g_model_A_const_11 any

var A_arbace_j2g_model_A_const_12 *lang.Var

var A_arbace_j2g_model_A_const_13 *lang.Var

var A_arbace_j2g_model_A_const_14 *lang.Var

var A_arbace_j2g_model_A_const_15 *lang.Var

var A_arbace_j2g_model_A_const_16 any

var A_arbace_j2g_model_A_const_17 *lang.Var

var A_arbace_j2g_model_A_const_18 *lang.Var

var A_arbace_j2g_model_A_const_19 *lang.Var

var A_arbace_j2g_model_A_const_20 *lang.Var

var A_arbace_j2g_model_A_const_21 *lang.Var

var A_arbace_j2g_model_A_const_22 *lang.Var

var A_arbace_j2g_model_A_const_23 *lang.Var

var A_arbace_j2g_model_A_const_24 *lang.Var

var A_arbace_j2g_model_A_const_25 *lang.Var

var A_arbace_j2g_model_A_const_26 *lang.Var

var A_arbace_j2g_model_A_const_27 *lang.Var

var A_arbace_j2g_model_A_const_28 any

var A_arbace_j2g_model_A_const_29 *lang.Var

var A_arbace_j2g_model_A_const_30 *lang.Var

var A_arbace_j2g_model_A_const_31 *lang.Var

var A_arbace_j2g_model_A_const_32 *lang.Var

var A_arbace_j2g_model_A_const_33 *lang.Var

var A_arbace_j2g_model_A_const_34 *lang.Var

var A_arbace_j2g_model_A_const_35 any

var A_arbace_j2g_model_A_const_36 *lang.Keyword

var A_arbace_j2g_model_A_const_37 *lang.Var

var A_arbace_j2g_model_A_const_38 *lang.Var

var A_arbace_j2g_model_A_const_39 *lang.Var

var A_arbace_j2g_model_A_const_40 *lang.Var

var A_arbace_j2g_model_A_const_41 *lang.Var

var A_arbace_j2g_model_A_const_42 *lang.Var

var A_arbace_j2g_model_A_const_43 *lang.Var

var A_arbace_j2g_model_A_const_44 *lang.Var

var A_arbace_j2g_model_A_const_45 *lang.Var

var A_arbace_j2g_model_A_const_46 *lang.Keyword

var A_arbace_j2g_model_A_const_47 *lang.Var

var A_arbace_j2g_model_A_const_48 *lang.Var

var A_arbace_j2g_model_A_const_49 *lang.Var

var A_arbace_j2g_model_A_const_50 *lang.Var

var A_arbace_j2g_model_A_const_51 *lang.Var

var A_arbace_j2g_model_A_const_52 *lang.Var

var A_arbace_j2g_model_A_const_53 *lang.Var

var A_arbace_j2g_model_A_const_54 *lang.Var

var A_arbace_j2g_model_A_const_55 *lang.Keyword

var A_arbace_j2g_model_A_const_56 any

var A_arbace_j2g_model_A_const_57 *lang.Var

var A_arbace_j2g_model_A_const_58 *lang.Keyword

var A_arbace_j2g_model_A_const_59 *lang.Var

var A_arbace_j2g_model_A_const_60 *lang.Var

var A_arbace_j2g_model_A_const_61 *lang.Var

var A_arbace_j2g_model_A_const_62 *lang.Keyword

var A_arbace_j2g_model_A_const_63 *lang.Var

var A_arbace_j2g_model_A_const_64 *lang.Var

var A_arbace_j2g_model_A_const_65 *lang.Var

var A_arbace_j2g_model_A_const_66 *lang.Var

var A_arbace_j2g_model_A_const_67 *lang.Var

var A_arbace_j2g_model_A_const_68 *lang.Keyword

var A_arbace_j2g_model_A_const_69 *lang.Var

var A_arbace_j2g_model_A_const_70 *lang.Var

var A_arbace_j2g_model_A_const_71 *lang.Var

var A_arbace_j2g_model_A_const_72 *lang.Var

var A_arbace_j2g_model_A_const_73 *lang.Var

var A_arbace_j2g_model_A_const_74 *lang.Var

var A_arbace_j2g_model_A_const_75 *lang.Var

var A_arbace_j2g_model_A_const_76 *lang.Keyword

var A_arbace_j2g_model_A_const_77 *lang.Var

var A_arbace_j2g_model_A_const_78 *lang.Keyword

var A_arbace_j2g_model_A_const_79 *lang.Var

var A_arbace_j2g_model_A_const_80 *lang.Var

var A_arbace_j2g_model_A_const_81 *lang.Var

var A_arbace_j2g_model_A_const_82 any

var A_arbace_j2g_model_A_const_83 any

var A_arbace_j2g_model_A_const_84 *lang.Keyword

var A_arbace_j2g_model_A_const_85 *lang.Var

var A_arbace_j2g_model_A_const_86 *lang.Var

var A_arbace_j2g_model_A_const_87 *lang.Keyword

var A_arbace_j2g_model_A_const_88 *lang.Var

var A_arbace_j2g_model_A_const_89 *lang.Var

var A_arbace_j2g_model_A_const_90 *lang.Var

var A_arbace_j2g_model_A_const_91 *lang.Var

var A_arbace_j2g_model_A_const_92 *lang.Var

var A_arbace_j2g_model_A_const_93 *lang.Var

var A_arbace_j2g_model_A_const_94 *lang.Var

var A_arbace_j2g_model_A_const_95 *lang.Var

var A_arbace_j2g_model_A_const_96 *lang.Keyword

var A_arbace_j2g_model_A_const_97 *lang.Keyword

var A_arbace_j2g_model_A_const_98 *lang.Var

var A_arbace_j2g_model_A_const_99 *lang.Var

var A_arbace_j2g_model_A_const_100 *lang.Var

var A_arbace_j2g_model_A_const_101 *lang.Var

var A_arbace_j2g_model_A_const_102 *lang.Var

var A_arbace_j2g_model_A_const_103 *lang.Var

var A_arbace_j2g_model_A_const_104 *lang.Var

var A_arbace_j2g_model_A_const_105 *lang.Var

var A_arbace_j2g_model_A_const_106 *lang.Var

var A_arbace_j2g_model_A_const_107 *lang.Var

var A_arbace_j2g_model_A_const_108 *lang.Keyword

var A_arbace_j2g_model_A_const_109 *lang.Var

var A_arbace_j2g_model_A_const_110 *lang.Var

var A_arbace_j2g_model_A_const_111 *lang.Var

var A_arbace_j2g_model_A_const_112 *lang.Var

var A_arbace_j2g_model_A_const_113 *lang.Keyword

var A_arbace_j2g_model_A_const_114 any

var A_arbace_j2g_model_A_const_115 *lang.Var

var A_arbace_j2g_model_A_const_116 any

var A_arbace_j2g_model_A_const_117 any

var A_arbace_j2g_model_A_const_118 *lang.Var

var A_arbace_j2g_model_A_const_119 *lang.Var

var A_arbace_j2g_model_A_const_120 *lang.Var

var A_arbace_j2g_model_A_const_121 *lang.Keyword

var A_arbace_j2g_model_A_const_122 any

var A_arbace_j2g_model_A_const_123 any

var A_arbace_j2g_model_A_const_124 any

var A_arbace_j2g_model_A_const_125 *lang.Var

var A_arbace_j2g_model_A_const_126 *lang.Var

var A_arbace_j2g_model_A_const_127 *lang.Var

var A_arbace_j2g_model_A_const_128 any

var A_arbace_j2g_model_A_const_129 any

var A_arbace_j2g_model_A_const_130 *lang.Keyword

var A_arbace_j2g_model_A_const_131 *lang.Keyword

var A_arbace_j2g_model_A_const_132 *lang.Var

var A_arbace_j2g_model_A_const_133 *lang.Var

var A_arbace_j2g_model_A_const_134 *lang.Var

var A_arbace_j2g_model_A_const_135 *lang.Var

var A_arbace_j2g_model_A_const_136 *lang.Var

var A_arbace_j2g_model_A_const_137 *lang.Var

var A_arbace_j2g_model_A_const_138 *lang.Var

var A_arbace_j2g_model_A_const_139 *lang.Var

var A_arbace_j2g_model_A_const_140 *lang.Var

var A_arbace_j2g_model_A_const_141 *lang.Var

var A_arbace_j2g_model_A_const_142 *lang.Var

var A_arbace_j2g_model_A_const_143 *lang.Keyword

var A_arbace_j2g_model_A_const_144 *lang.Var

var A_arbace_j2g_model_A_const_145 *lang.Var

var A_arbace_j2g_model_A_const_146 *lang.Var

var A_arbace_j2g_model_A_const_147 any

var A_arbace_j2g_model_A_const_148 *lang.Var

var A_arbace_j2g_model_A_const_149 *lang.Var

var A_arbace_j2g_model_A_const_150 *lang.Var

var A_arbace_j2g_model_A_const_151 *lang.Var

var A_arbace_j2g_model_A_const_152 *lang.Var

var A_arbace_j2g_model_A_const_153 *lang.Var

var A_arbace_j2g_model_A_const_154 *lang.Var

var A_arbace_j2g_model_A_const_155 *lang.Var

var A_arbace_j2g_model_A_const_156 *lang.Var

var A_arbace_j2g_model_A_const_157 *lang.Keyword

var A_arbace_j2g_model_A_const_158 *lang.Var

var A_arbace_j2g_model_A_const_159 *lang.Var

var A_arbace_j2g_model_A_const_160 *lang.Var

var A_arbace_j2g_model_A_const_161 *lang.Var

var A_arbace_j2g_model_A_const_162 *lang.Var

var A_arbace_j2g_model_A_const_163 *lang.Keyword

var A_arbace_j2g_model_A_const_164 *lang.Var

var A_arbace_j2g_model_A_const_165 *lang.Var

var A_arbace_j2g_model_A_const_166 *lang.Var

var A_arbace_j2g_model_A_const_167 *lang.Var

var A_arbace_j2g_model_A_const_168 any

var A_arbace_j2g_model_A_const_169 *lang.Var

var A_arbace_j2g_model_A_const_170 *lang.Var

var A_arbace_j2g_model_A_const_171 *lang.Var

var A_arbace_j2g_model_A_const_172 *lang.Var

var A_arbace_j2g_model_A_const_173 *lang.Var

var A_arbace_j2g_model_A_const_174 *lang.Var

var A_arbace_j2g_model_A_const_175 *lang.Var

var A_arbace_j2g_model_A_const_176 *lang.Keyword

var A_arbace_j2g_model_A_const_177 *lang.Keyword

var A_arbace_j2g_model_A_const_178 *lang.Keyword

var A_arbace_j2g_model_A_const_179 *lang.Keyword

var A_arbace_j2g_model_A_const_180 *lang.Keyword

var A_arbace_j2g_model_A_const_181 *lang.Keyword

var A_arbace_j2g_model_A_const_182 *lang.Var

var A_arbace_j2g_model_A_const_183 *lang.Keyword

var A_arbace_j2g_model_A_const_184 *lang.Var

var A_arbace_j2g_model_A_const_185 any

var A_arbace_j2g_model_A_const_186 *lang.Var

var A_arbace_j2g_model_A_const_187 *lang.Keyword

var A_arbace_j2g_model_A_const_188 any

var A_arbace_j2g_model_A_const_189 *lang.Keyword

var A_arbace_j2g_model_A_const_190 *lang.Keyword

var A_arbace_j2g_model_A_const_191 *lang.Keyword

var A_arbace_j2g_model_A_const_192 *lang.Var

var A_arbace_j2g_model_A_const_193 any

var A_arbace_j2g_model_A_const_194 *lang.Var

var A_arbace_j2g_model_A_const_195 *lang.Var

var A_arbace_j2g_model_A_const_196 *lang.Var

var A_arbace_j2g_model_A_const_197 *lang.Var

var A_arbace_j2g_model_A_const_198 *lang.Var

var A_arbace_j2g_model_A_const_199 *lang.Var

var A_arbace_j2g_model_A_const_200 any

var A_arbace_j2g_model_A_const_201 any

var A_arbace_j2g_model_A_const_202 any

var A_arbace_j2g_model_A_const_203 *lang.Keyword

var A_arbace_j2g_model_A_const_204 *lang.Var

var A_arbace_j2g_model_A_const_205 *lang.Keyword

var A_arbace_j2g_model_A_const_206 any

var A_arbace_j2g_model_A_const_207 *lang.Keyword

var A_arbace_j2g_model_A_const_208 any

var A_arbace_j2g_model_A_const_209 *lang.Var

var A_arbace_j2g_model_A_const_210 *lang.Var

var A_arbace_j2g_model_A_const_211 any

var A_arbace_j2g_model_A_const_212 *lang.Var

var A_arbace_j2g_model_A_const_213 *lang.Var

var A_arbace_j2g_model_A_const_214 *lang.Var

var A_arbace_j2g_model_A_const_215 *lang.Var

var A_arbace_j2g_model_A_const_216 *lang.Keyword

var A_arbace_j2g_model_A_const_217 *lang.Keyword

var A_arbace_j2g_model_A_const_218 *lang.Keyword

var A_arbace_j2g_model_A_const_219 *lang.Var

var A_arbace_j2g_model_A_const_220 any

var A_arbace_j2g_model_A_const_221 any

var A_arbace_j2g_model_A_const_222 *lang.Var

var A_arbace_j2g_model_A_const_223 *lang.Var

var A_arbace_j2g_model_A_const_224 *lang.Keyword

var A_arbace_j2g_model_A_const_225 *lang.Keyword

var A_arbace_j2g_model_A_const_226 *lang.Keyword

var A_arbace_j2g_model_A_const_227 *lang.Keyword

var A_arbace_j2g_model_A_const_228 *lang.Keyword

var A_arbace_j2g_model_A_const_229 *lang.Keyword

var A_arbace_j2g_model_A_const_230 *lang.Var

var A_arbace_j2g_model_A_const_231 *lang.Var

var A_arbace_j2g_model_A_const_232 *lang.Var

var A_arbace_j2g_model_A_const_233 *lang.Var

var A_arbace_j2g_model_A_const_234 *lang.Var

var A_arbace_j2g_model_A_const_235 *lang.Var

var A_arbace_j2g_model_A_const_236 *lang.Var

var A_arbace_j2g_model_A_const_237 *lang.Var

var A_arbace_j2g_model_A_const_238 *lang.Keyword

var A_arbace_j2g_model_A_const_239 *lang.Var

var A_arbace_j2g_model_A_const_240 *lang.Keyword

var A_arbace_j2g_model_A_const_241 *lang.Keyword

var A_arbace_j2g_model_A_const_242 *lang.Keyword

var A_arbace_j2g_model_A_const_243 *lang.Var

var A_arbace_j2g_model_A_const_244 *lang.Keyword

var A_arbace_j2g_model_A_const_245 any

var A_arbace_j2g_model_A_const_246 *lang.Var

var A_arbace_j2g_model_A_const_247 *lang.Keyword

var A_arbace_j2g_model_A_const_248 *lang.Keyword

var A_arbace_j2g_model_A_const_249 *lang.Keyword

var A_arbace_j2g_model_A_const_250 *lang.Keyword

var A_arbace_j2g_model_A_const_251 *lang.Keyword

var A_arbace_j2g_model_A_const_252 *lang.Keyword

var A_arbace_j2g_model_A_const_253 *lang.Keyword

var A_arbace_j2g_model_A_const_254 *lang.Keyword

var A_arbace_j2g_model_A_const_255 *lang.Keyword

var A_arbace_j2g_model_A_const_256 *lang.Keyword

var A_arbace_j2g_model_A_const_257 *lang.Keyword

var A_arbace_j2g_model_A_const_258 *lang.Keyword

var A_arbace_j2g_model_A_const_259 *lang.Keyword

var A_arbace_j2g_model_A_const_260 *lang.Keyword

var A_arbace_j2g_model_A_const_261 *lang.Keyword

var A_arbace_j2g_model_A_const_262 *lang.Keyword

var A_arbace_j2g_model_A_const_263 *lang.Keyword

var A_arbace_j2g_model_A_const_264 *lang.Keyword

var A_arbace_j2g_model_A_const_265 *lang.Keyword

var A_arbace_j2g_model_A_const_266 *lang.Keyword

var A_arbace_j2g_model_A_const_267 *lang.Keyword

var A_arbace_j2g_model_A_const_268 *lang.Keyword

var A_arbace_j2g_model_A_const_269 *lang.Keyword

var A_arbace_j2g_model_A_const_270 *lang.Keyword

var A_arbace_j2g_model_A_const_271 *lang.Keyword

var A_arbace_j2g_model_A_const_272 *lang.Keyword

var A_arbace_j2g_model_A_const_273 *lang.Keyword

var A_arbace_j2g_model_A_const_274 *lang.Var

var A_arbace_j2g_model_A_const_275 *lang.Keyword

var A_arbace_j2g_model_A_const_276 *lang.Keyword

var A_arbace_j2g_model_A_const_277 *lang.Keyword

var A_arbace_j2g_model_A_const_278 *lang.Keyword

var A_arbace_j2g_model_A_const_279 any

var A_arbace_j2g_model_A_const_280 *lang.Keyword

var A_arbace_j2g_model_A_const_281 *lang.Keyword

var A_arbace_j2g_model_A_const_282 *lang.Keyword

var A_arbace_j2g_model_A_const_283 *lang.Keyword

var A_arbace_j2g_model_A_const_284 *lang.Keyword

var A_arbace_j2g_model_A_const_285 *lang.Keyword

var A_arbace_j2g_model_A_const_286 *lang.Var

var A_arbace_j2g_model_A_const_287 *lang.Keyword

var A_arbace_j2g_model_A_const_288 any

var A_arbace_j2g_model_A_const_289 *lang.Var

var A_arbace_j2g_model_A_const_290 *lang.Var

var A_arbace_j2g_model_A_const_291 *lang.Var

var A_arbace_j2g_model_A_const_292 *lang.Var

var A_arbace_j2g_model_A_const_293 *lang.Var

var A_arbace_j2g_model_A_const_294 *lang.Var

var A_arbace_j2g_model_A_init jrt.ClassInit

func A_arbace_j2g_model_A_Init() { if !A_arbace_j2g_model_A_init.Done() { A_arbace_j2g_model_A_init.Run(A_arbace_j2g_model_A_clinit) } }

func A_arbace_j2g_model_A_clinit() { A_arbace_j2g_model_A_clinit_p0(); A_arbace_j2g_model_A_clinit_p1(); A_arbace_j2g_model_A_clinit_p2(); A_arbace_j2g_model_A_clinit_p3(); A_arbace_j2g_model_A_clinit_p4(); A_arbace_j2g_model_A_clinit_p5(); A_arbace_j2g_model_A_clinit_p6(); A_arbace_j2g_model_A_clinit_p7(); A_arbace_j2g_model_A_clinit_p8(); A_arbace_j2g_model_A_clinit_p9(); A_arbace_j2g_model_A_clinit_p10(); A_arbace_j2g_model_A_clinit_p11(); A_arbace_j2g_model_A_clinit_p12(); A_arbace_j2g_model_A_clinit_p13(); A_arbace_j2g_model_A_clinit_p14(); A_arbace_j2g_model_A_clinit_p15(); A_arbace_j2g_model_A_clinit_p16(); A_arbace_j2g_model_A_clinit_p17(); A_arbace_j2g_model_A_clinit_p18(); A_arbace_j2g_model_A_clinit_p19(); A_arbace_j2g_model_A_clinit_p20(); A_arbace_j2g_model_A_clinit_p21(); A_arbace_j2g_model_A_clinit_p22(); A_arbace_j2g_model_A_clinit_p23(); A_arbace_j2g_model_A_clinit_p24() }

func A_arbace_j2g_model_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 409); A_arbace_j2g_model_A_const_0 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[114]); A_arbace_j2g_model_A_const_1 = A_arbace_j2g_model_A_const_pool.A[115]; A_arbace_j2g_model_A_const_2 = A_arbace_j2g_model_A_const_pool.A[116]; A_arbace_j2g_model_A_const_3 = A_arbace_j2g_model_A_const_pool.A[117]; A_arbace_j2g_model_A_const_4 = A_arbace_j2g_model_A_const_pool.A[118]; A_arbace_j2g_model_A_const_5 = A_arbace_j2g_model_A_const_pool.A[119]; A_arbace_j2g_model_A_const_6 = A_arbace_j2g_model_A_const_pool.A[120]; A_arbace_j2g_model_A_const_7 = A_arbace_j2g_model_A_const_pool.A[121]; A_arbace_j2g_model_A_const_8 = A_arbace_j2g_model_A_const_pool.A[122]; A_arbace_j2g_model_A_const_9 = A_arbace_j2g_model_A_const_pool.A[123]; A_arbace_j2g_model_A_const_10 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[124]); A_arbace_j2g_model_A_const_11 = A_arbace_j2g_model_A_const_pool.A[125]; A_arbace_j2g_model_A_const_12 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[126]) }

func A_arbace_j2g_model_A_clinit_p1() { A_arbace_j2g_model_A_const_13 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[127]); A_arbace_j2g_model_A_const_14 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[128]); A_arbace_j2g_model_A_const_15 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[129]); A_arbace_j2g_model_A_const_16 = A_arbace_j2g_model_A_const_pool.A[130]; A_arbace_j2g_model_A_const_17 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[131]); A_arbace_j2g_model_A_const_18 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[132]); A_arbace_j2g_model_A_const_19 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[133]); A_arbace_j2g_model_A_const_20 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[134]); A_arbace_j2g_model_A_const_21 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[135]); A_arbace_j2g_model_A_const_22 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[136]); A_arbace_j2g_model_A_const_23 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[137]); A_arbace_j2g_model_A_const_24 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[138]) }

func A_arbace_j2g_model_A_clinit_p2() { A_arbace_j2g_model_A_const_25 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[139]); A_arbace_j2g_model_A_const_26 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[140]); A_arbace_j2g_model_A_const_27 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[141]); A_arbace_j2g_model_A_const_28 = A_arbace_j2g_model_A_const_pool.A[142]; A_arbace_j2g_model_A_const_29 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[143]); A_arbace_j2g_model_A_const_30 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[144]); A_arbace_j2g_model_A_const_31 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[145]); A_arbace_j2g_model_A_const_32 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[146]); A_arbace_j2g_model_A_const_33 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[147]); A_arbace_j2g_model_A_const_34 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[148]); A_arbace_j2g_model_A_const_35 = A_arbace_j2g_model_A_const_pool.A[149]; A_arbace_j2g_model_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[150]) }

func A_arbace_j2g_model_A_clinit_p3() { A_arbace_j2g_model_A_const_37 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[151]); A_arbace_j2g_model_A_const_38 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[152]); A_arbace_j2g_model_A_const_39 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[153]); A_arbace_j2g_model_A_const_40 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[154]); A_arbace_j2g_model_A_const_41 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[155]); A_arbace_j2g_model_A_const_42 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[156]); A_arbace_j2g_model_A_const_43 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[157]); A_arbace_j2g_model_A_const_44 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[158]); A_arbace_j2g_model_A_const_45 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[159]); A_arbace_j2g_model_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[160]); A_arbace_j2g_model_A_const_47 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[161]); A_arbace_j2g_model_A_const_48 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[162]) }

func A_arbace_j2g_model_A_clinit_p4() { A_arbace_j2g_model_A_const_49 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[163]); A_arbace_j2g_model_A_const_50 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[164]); A_arbace_j2g_model_A_const_51 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[165]); A_arbace_j2g_model_A_const_52 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[166]); A_arbace_j2g_model_A_const_53 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[167]); A_arbace_j2g_model_A_const_54 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[168]); A_arbace_j2g_model_A_const_55 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[169]); A_arbace_j2g_model_A_const_56 = A_arbace_j2g_model_A_const_pool.A[170]; A_arbace_j2g_model_A_const_57 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[171]); A_arbace_j2g_model_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[172]); A_arbace_j2g_model_A_const_59 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[173]); A_arbace_j2g_model_A_const_60 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[174]) }

func A_arbace_j2g_model_A_clinit_p5() { A_arbace_j2g_model_A_const_61 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[175]); A_arbace_j2g_model_A_const_62 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[176]); A_arbace_j2g_model_A_const_63 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[177]); A_arbace_j2g_model_A_const_64 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[178]); A_arbace_j2g_model_A_const_65 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[179]); A_arbace_j2g_model_A_const_66 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[180]); A_arbace_j2g_model_A_const_67 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[181]); A_arbace_j2g_model_A_const_68 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[182]); A_arbace_j2g_model_A_const_69 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[183]); A_arbace_j2g_model_A_const_70 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[184]); A_arbace_j2g_model_A_const_71 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[185]); A_arbace_j2g_model_A_const_72 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[186]) }

func A_arbace_j2g_model_A_clinit_p6() { A_arbace_j2g_model_A_const_73 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[187]); A_arbace_j2g_model_A_const_74 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[188]); A_arbace_j2g_model_A_const_75 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[189]); A_arbace_j2g_model_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[190]); A_arbace_j2g_model_A_const_77 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[191]); A_arbace_j2g_model_A_const_78 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[192]); A_arbace_j2g_model_A_const_79 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[193]); A_arbace_j2g_model_A_const_80 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[194]); A_arbace_j2g_model_A_const_81 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[195]); A_arbace_j2g_model_A_const_82 = A_arbace_j2g_model_A_const_pool.A[196]; A_arbace_j2g_model_A_const_83 = A_arbace_j2g_model_A_const_pool.A[197]; A_arbace_j2g_model_A_const_84 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[198]) }

func A_arbace_j2g_model_A_clinit_p7() { A_arbace_j2g_model_A_const_85 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[199]); A_arbace_j2g_model_A_const_86 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[200]); A_arbace_j2g_model_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[201]); A_arbace_j2g_model_A_const_88 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[202]); A_arbace_j2g_model_A_const_89 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[203]); A_arbace_j2g_model_A_const_90 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[204]); A_arbace_j2g_model_A_const_91 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[205]); A_arbace_j2g_model_A_const_92 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[206]); A_arbace_j2g_model_A_const_93 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[207]); A_arbace_j2g_model_A_const_94 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[208]); A_arbace_j2g_model_A_const_95 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[209]); A_arbace_j2g_model_A_const_96 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[210]) }

func A_arbace_j2g_model_A_clinit_p8() { A_arbace_j2g_model_A_const_97 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[211]); A_arbace_j2g_model_A_const_98 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[212]); A_arbace_j2g_model_A_const_99 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[213]); A_arbace_j2g_model_A_const_100 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[214]); A_arbace_j2g_model_A_const_101 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[215]); A_arbace_j2g_model_A_const_102 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[216]); A_arbace_j2g_model_A_const_103 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[217]); A_arbace_j2g_model_A_const_104 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[218]); A_arbace_j2g_model_A_const_105 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[219]); A_arbace_j2g_model_A_const_106 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[220]); A_arbace_j2g_model_A_const_107 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[221]); A_arbace_j2g_model_A_const_108 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[222]) }

func A_arbace_j2g_model_A_clinit_p9() { A_arbace_j2g_model_A_const_109 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[223]); A_arbace_j2g_model_A_const_110 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[224]); A_arbace_j2g_model_A_const_111 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[225]); A_arbace_j2g_model_A_const_112 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[226]); A_arbace_j2g_model_A_const_113 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[227]); A_arbace_j2g_model_A_const_114 = A_arbace_j2g_model_A_const_pool.A[228]; A_arbace_j2g_model_A_const_115 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[229]); A_arbace_j2g_model_A_const_116 = A_arbace_j2g_model_A_const_pool.A[230]; A_arbace_j2g_model_A_const_117 = A_arbace_j2g_model_A_const_pool.A[231]; A_arbace_j2g_model_A_const_118 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[232]); A_arbace_j2g_model_A_const_119 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[233]); A_arbace_j2g_model_A_const_120 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[234]) }

func A_arbace_j2g_model_A_clinit_p10() { A_arbace_j2g_model_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[235]); A_arbace_j2g_model_A_const_122 = A_arbace_j2g_model_A_const_pool.A[236]; A_arbace_j2g_model_A_const_123 = A_arbace_j2g_model_A_const_pool.A[237]; A_arbace_j2g_model_A_const_124 = A_arbace_j2g_model_A_const_pool.A[238]; A_arbace_j2g_model_A_const_125 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[239]); A_arbace_j2g_model_A_const_126 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[240]); A_arbace_j2g_model_A_const_127 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[241]); A_arbace_j2g_model_A_const_128 = A_arbace_j2g_model_A_const_pool.A[242]; A_arbace_j2g_model_A_const_129 = A_arbace_j2g_model_A_const_pool.A[243]; A_arbace_j2g_model_A_const_130 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[244]); A_arbace_j2g_model_A_const_131 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[245]); A_arbace_j2g_model_A_const_132 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[246]); A_arbace_j2g_model_A_const_133 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[247]) }

func A_arbace_j2g_model_A_clinit_p11() { A_arbace_j2g_model_A_const_134 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[248]); A_arbace_j2g_model_A_const_135 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[249]); A_arbace_j2g_model_A_const_136 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[250]); A_arbace_j2g_model_A_const_137 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[251]); A_arbace_j2g_model_A_const_138 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[252]); A_arbace_j2g_model_A_const_139 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[253]); A_arbace_j2g_model_A_const_140 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[254]); A_arbace_j2g_model_A_const_141 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[255]); A_arbace_j2g_model_A_const_142 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[256]); A_arbace_j2g_model_A_const_143 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[257]); A_arbace_j2g_model_A_const_144 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[258]); A_arbace_j2g_model_A_const_145 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[259]) }

func A_arbace_j2g_model_A_clinit_p12() { A_arbace_j2g_model_A_const_146 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[260]); A_arbace_j2g_model_A_const_147 = A_arbace_j2g_model_A_const_pool.A[261]; A_arbace_j2g_model_A_const_148 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[262]); A_arbace_j2g_model_A_const_149 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[263]); A_arbace_j2g_model_A_const_150 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[264]); A_arbace_j2g_model_A_const_151 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[265]); A_arbace_j2g_model_A_const_152 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[266]); A_arbace_j2g_model_A_const_153 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[267]); A_arbace_j2g_model_A_const_154 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[268]); A_arbace_j2g_model_A_const_155 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[269]); A_arbace_j2g_model_A_const_156 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[270]); A_arbace_j2g_model_A_const_157 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[271]) }

func A_arbace_j2g_model_A_clinit_p13() { A_arbace_j2g_model_A_const_158 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[272]); A_arbace_j2g_model_A_const_159 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[273]); A_arbace_j2g_model_A_const_160 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[274]); A_arbace_j2g_model_A_const_161 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[275]); A_arbace_j2g_model_A_const_162 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[276]); A_arbace_j2g_model_A_const_163 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[277]); A_arbace_j2g_model_A_const_164 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[278]); A_arbace_j2g_model_A_const_165 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[279]); A_arbace_j2g_model_A_const_166 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[280]); A_arbace_j2g_model_A_const_167 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[281]); A_arbace_j2g_model_A_const_168 = A_arbace_j2g_model_A_const_pool.A[282]; A_arbace_j2g_model_A_const_169 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[283]) }

func A_arbace_j2g_model_A_clinit_p14() { A_arbace_j2g_model_A_const_170 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[284]); A_arbace_j2g_model_A_const_171 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[285]); A_arbace_j2g_model_A_const_172 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[286]); A_arbace_j2g_model_A_const_173 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[287]); A_arbace_j2g_model_A_const_174 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[288]); A_arbace_j2g_model_A_const_175 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[289]); A_arbace_j2g_model_A_const_176 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[290]); A_arbace_j2g_model_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[291]); A_arbace_j2g_model_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[292]); A_arbace_j2g_model_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[293]); A_arbace_j2g_model_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[294]); A_arbace_j2g_model_A_const_181 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[295]) }

func A_arbace_j2g_model_A_clinit_p15() { A_arbace_j2g_model_A_const_182 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[296]); A_arbace_j2g_model_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[297]); A_arbace_j2g_model_A_const_184 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[298]); A_arbace_j2g_model_A_const_185 = A_arbace_j2g_model_A_const_pool.A[299]; A_arbace_j2g_model_A_const_186 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[300]); A_arbace_j2g_model_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[301]); A_arbace_j2g_model_A_const_188 = A_arbace_j2g_model_A_const_pool.A[302]; A_arbace_j2g_model_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[303]); A_arbace_j2g_model_A_const_190 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[304]); A_arbace_j2g_model_A_const_191 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[305]); A_arbace_j2g_model_A_const_192 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[306]); A_arbace_j2g_model_A_const_193 = A_arbace_j2g_model_A_const_pool.A[307] }

func A_arbace_j2g_model_A_clinit_p16() { A_arbace_j2g_model_A_const_194 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[308]); A_arbace_j2g_model_A_const_195 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[309]); A_arbace_j2g_model_A_const_196 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[310]); A_arbace_j2g_model_A_const_197 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[311]); A_arbace_j2g_model_A_const_198 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[312]); A_arbace_j2g_model_A_const_199 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[313]); A_arbace_j2g_model_A_const_200 = A_arbace_j2g_model_A_const_pool.A[314]; A_arbace_j2g_model_A_const_201 = A_arbace_j2g_model_A_const_pool.A[315]; A_arbace_j2g_model_A_const_202 = A_arbace_j2g_model_A_const_pool.A[316]; A_arbace_j2g_model_A_const_203 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[317]); A_arbace_j2g_model_A_const_204 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[318]); A_arbace_j2g_model_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[319]); A_arbace_j2g_model_A_const_206 = A_arbace_j2g_model_A_const_pool.A[320] }

func A_arbace_j2g_model_A_clinit_p17() { A_arbace_j2g_model_A_const_207 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[321]); A_arbace_j2g_model_A_const_208 = A_arbace_j2g_model_A_const_pool.A[322]; A_arbace_j2g_model_A_const_209 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[323]); A_arbace_j2g_model_A_const_210 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[324]); A_arbace_j2g_model_A_const_211 = A_arbace_j2g_model_A_const_pool.A[325]; A_arbace_j2g_model_A_const_212 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[326]); A_arbace_j2g_model_A_const_213 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[327]); A_arbace_j2g_model_A_const_214 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[328]); A_arbace_j2g_model_A_const_215 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[329]); A_arbace_j2g_model_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[330]); A_arbace_j2g_model_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[331]); A_arbace_j2g_model_A_const_218 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[332]) }

func A_arbace_j2g_model_A_clinit_p18() { A_arbace_j2g_model_A_const_219 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[333]); A_arbace_j2g_model_A_const_220 = A_arbace_j2g_model_A_const_pool.A[334]; A_arbace_j2g_model_A_const_221 = A_arbace_j2g_model_A_const_pool.A[335]; A_arbace_j2g_model_A_const_222 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[336]); A_arbace_j2g_model_A_const_223 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[337]); A_arbace_j2g_model_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[338]); A_arbace_j2g_model_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[339]); A_arbace_j2g_model_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[340]); A_arbace_j2g_model_A_const_227 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[341]); A_arbace_j2g_model_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[342]); A_arbace_j2g_model_A_const_229 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[343]); A_arbace_j2g_model_A_const_230 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[344]) }

func A_arbace_j2g_model_A_clinit_p19() { A_arbace_j2g_model_A_const_231 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[345]); A_arbace_j2g_model_A_const_232 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[346]); A_arbace_j2g_model_A_const_233 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[347]); A_arbace_j2g_model_A_const_234 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[348]); A_arbace_j2g_model_A_const_235 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[349]); A_arbace_j2g_model_A_const_236 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[350]); A_arbace_j2g_model_A_const_237 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[351]); A_arbace_j2g_model_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[352]); A_arbace_j2g_model_A_const_239 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[353]); A_arbace_j2g_model_A_const_240 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[354]); A_arbace_j2g_model_A_const_241 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[355]); A_arbace_j2g_model_A_const_242 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[356]) }

func A_arbace_j2g_model_A_clinit_p20() { A_arbace_j2g_model_A_const_243 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[357]); A_arbace_j2g_model_A_const_244 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[358]); A_arbace_j2g_model_A_const_245 = A_arbace_j2g_model_A_const_pool.A[359]; A_arbace_j2g_model_A_const_246 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[360]); A_arbace_j2g_model_A_const_247 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[361]); A_arbace_j2g_model_A_const_248 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[362]); A_arbace_j2g_model_A_const_249 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[363]); A_arbace_j2g_model_A_const_250 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[364]); A_arbace_j2g_model_A_const_251 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[365]); A_arbace_j2g_model_A_const_252 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[366]); A_arbace_j2g_model_A_const_253 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[367]); A_arbace_j2g_model_A_const_254 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[368]) }

func A_arbace_j2g_model_A_clinit_p21() { A_arbace_j2g_model_A_const_255 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[369]); A_arbace_j2g_model_A_const_256 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[370]); A_arbace_j2g_model_A_const_257 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[371]); A_arbace_j2g_model_A_const_258 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[372]); A_arbace_j2g_model_A_const_259 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[373]); A_arbace_j2g_model_A_const_260 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[374]); A_arbace_j2g_model_A_const_261 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[375]); A_arbace_j2g_model_A_const_262 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[376]); A_arbace_j2g_model_A_const_263 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[377]); A_arbace_j2g_model_A_const_264 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[378]); A_arbace_j2g_model_A_const_265 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[379]); A_arbace_j2g_model_A_const_266 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[380]) }

func A_arbace_j2g_model_A_clinit_p22() { A_arbace_j2g_model_A_const_267 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[381]); A_arbace_j2g_model_A_const_268 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[382]); A_arbace_j2g_model_A_const_269 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[383]); A_arbace_j2g_model_A_const_270 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[384]); A_arbace_j2g_model_A_const_271 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[385]); A_arbace_j2g_model_A_const_272 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[386]); A_arbace_j2g_model_A_const_273 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[387]); A_arbace_j2g_model_A_const_274 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[388]); A_arbace_j2g_model_A_const_275 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[389]); A_arbace_j2g_model_A_const_276 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[390]); A_arbace_j2g_model_A_const_277 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[391]); A_arbace_j2g_model_A_const_278 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[392]) }

func A_arbace_j2g_model_A_clinit_p23() { A_arbace_j2g_model_A_const_279 = A_arbace_j2g_model_A_const_pool.A[393]; A_arbace_j2g_model_A_const_280 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[394]); A_arbace_j2g_model_A_const_281 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[395]); A_arbace_j2g_model_A_const_282 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[396]); A_arbace_j2g_model_A_const_283 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[397]); A_arbace_j2g_model_A_const_284 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[398]); A_arbace_j2g_model_A_const_285 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[399]); A_arbace_j2g_model_A_const_286 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[400]); A_arbace_j2g_model_A_const_287 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[401]); A_arbace_j2g_model_A_const_288 = A_arbace_j2g_model_A_const_pool.A[402]; A_arbace_j2g_model_A_const_289 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[403]); A_arbace_j2g_model_A_const_290 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[404]) }

func A_arbace_j2g_model_A_clinit_p24() { A_arbace_j2g_model_A_const_291 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[405]); A_arbace_j2g_model_A_const_292 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[406]); A_arbace_j2g_model_A_const_293 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[407]); A_arbace_j2g_model_A_const_294 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[408]) }

func A_arbace_j2g_model_A_New() *A_arbace_j2g_model_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_A) Ctor() {}

func (t *A_arbace_j2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_A_class }

func (t *A_arbace_j2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_A); return ok }

func A_arbace_j2g_model_A_Cast(x any) *A_arbace_j2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_A_class)) }; return v }



type A_arbace_j2g_model_T_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_T_A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_m_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_m_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_method_error_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_method_error_text_A_fn_class *jrt.Class



type A_arbace_j2g_model_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_all_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_array_test_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_array_test_A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_benign_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000255_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_access_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_access_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_loader_resource_ready_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_loader_resource_ready_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A struct{ j2g_header uint64; F_n, F_d any }

var A_arbace_j2g_model_class_loader_resource_ready_QMARK__fn__1479000263_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_loader_resource_target_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_loader_resource_target_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_code_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_code_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_ctors_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_ctors_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_ctors_of_fn__1479000157_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_ctors_of_fn__1479000157_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_declared_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A struct{ j2g_header uint64; F_n, F_s__1479000100, F_iter__1479000099 any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A struct{ j2g_header uint64; F_b__1479000102, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000099__1479000103_fn__1479000104_fn__1479000105_A_fn_class *jrt.Class



type A_arbace_j2g_model_default_suid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_default_suid_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_erased_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000056_A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000058_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000004_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000004_A_New() *A_arbace_j2g_model_eval1479000004_A { t := &A_arbace_j2g_model_eval1479000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000004_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000004_A_class }

func (t *A_arbace_j2g_model_eval1479000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000004_A); return ok }

func A_arbace_j2g_model_eval1479000004_A_Cast(x any) *A_arbace_j2g_model_eval1479000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000004_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000008_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000008_A_New() *A_arbace_j2g_model_eval1479000008_A { t := &A_arbace_j2g_model_eval1479000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000008_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000008_A_class }

func (t *A_arbace_j2g_model_eval1479000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000008_A); return ok }

func A_arbace_j2g_model_eval1479000008_A_Cast(x any) *A_arbace_j2g_model_eval1479000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000008_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000008_fn__1479000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class *jrt.Class



type A_arbace_j2g_model_fields_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fields_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_final_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_final_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_find_method_A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_fn__1479000089_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_find_method_fn__1479000089_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000270_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000270_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A struct{ j2g_header uint64; F_s__1479000267, F_iter__1479000266 any }

var A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A struct{ j2g_header uint64; F_b__1479000269 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_fn__1479000270_iter__1479000266__1479000271_fn__1479000272_fn__1479000273_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000288_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000288_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A struct{ j2g_header uint64; F_s__1479000285, F_iter__1479000284 any }

var A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A struct{ j2g_header uint64; F_b__1479000287 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_fn__1479000288_iter__1479000284__1479000289_fn__1479000290_fn__1479000291_A_fn_class *jrt.Class



type A_arbace_j2g_model_foreign_super_accessible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_foreign_super_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A struct{ j2g_header uint64; F_pp int64 }

var A_arbace_j2g_model_foreign_super_accessible_QMARK__fn__1479000182_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_qualified_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_qualified_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_model_hand_written_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hand_written_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_hw_method_exists_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_iface_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_iface_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_impl_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000133_A struct{ j2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_j2g_model_impl_of_fn__1479000133_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000145_A struct{ j2g_header uint64; F_cands any }

var A_arbace_j2g_model_impl_of_fn__1479000145_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_model_impl_of_fn__1479000145_fn__1479000146_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A struct{ j2g_header uint64; F_iter__1479000135, F_name, F_desc, F_s__1479000136 any }

var A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A struct{ j2g_header uint64; F_b__1479000138, F_name, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_impl_of_iter__1479000135__1479000139_fn__1479000140_fn__1479000141_A_fn_class *jrt.Class



type A_arbace_j2g_model_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_info_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_info_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000189_fn__1479000190_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A struct{ j2g_header uint64; F_s__1479000196, F_iter__1479000195 any }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A struct{ j2g_header uint64; F_b__1479000198 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000195__1479000199_fn__1479000200_fn__1479000201_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A struct{ j2g_header uint64; F_declares_default_QMARK_ any }

var A_arbace_j2g_model_init_superinterfaces_walk__1479000193_A_fn_class *jrt.Class



type A_arbace_j2g_model_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_method_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_model_j2g_static_QMARK__fn__1479000036_A_fn_class *jrt.Class



type A_arbace_j2g_model_java_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_java_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_java_type_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_java_type_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_jobs_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jobs_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_leaf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_leaf_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000068_A struct{ j2g_header uint64; F_cache, F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000068_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A struct{ j2g_header uint64; F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_fn__1479000068_fn__1479000069_fn__1479000070_A_fn_class *jrt.Class



type A_arbace_j2g_model_mdesc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_member_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_member_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_method_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_method_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_methods_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_methods_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_nest_top_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_nest_top_A_fn_class *jrt.Class



type A_arbace_j2g_model_on_run_thread_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_on_run_thread_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_par_mapv_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000027_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000027_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_work__1479000025_A struct{ j2g_header uint64; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

var A_arbace_j2g_model_par_mapv_work__1479000025_A_fn_class *jrt.Class



type A_arbace_j2g_model_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_pointer_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_private_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000223_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000225_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000235_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000238_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000243_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000245_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000247_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000249_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000251_A_fn_class *jrt.Class



type A_arbace_j2g_model_qualify_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_qualify_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000044_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflected_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflected_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_run_fn_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_run_fn_A_fn_class *jrt.Class



type A_arbace_j2g_model_run_fn_fn__1479000013_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_model_run_fn_fn__1479000013_A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_accessor_bases_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_accessor_bases_A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_chain_super_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_chain_super_A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_chain_super_fn__1479000170_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_chain_super_fn__1479000170_A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_field_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_field_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_hook_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_hook_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_super_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_super_A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_uid_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_uid_A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_uid_fn__1479000176_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serial_uid_fn__1479000176_A_fn_class *jrt.Class



type A_arbace_j2g_model_serial_uid_fn__1479000178_A struct{ j2g_header uint64; F_out, F_n, F_v, F_lockee__1927000360__auto__ any }

var A_arbace_j2g_model_serial_uid_fn__1479000178_A_fn_class *jrt.Class



type A_arbace_j2g_model_serializable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serializable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_serialization_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_serialization_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A struct{ j2g_header uint64; F_iter__1479000209, F_s__1479000210 any }

var A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A struct{ j2g_header uint64; F_b__1479000212 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_start_classes_iter__1479000209__1479000213_fn__1479000214_fn__1479000215_A_fn_class *jrt.Class



type A_arbace_j2g_model_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_subclasses_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_subclasses_A_fn_class *jrt.Class



type A_arbace_j2g_model_super_ctor_accessible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_super_ctor_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000164_A_fn_class *jrt.Class



type A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A struct{ j2g_header uint64; F_pp int64 }

var A_arbace_j2g_model_super_ctor_accessible_QMARK__fn__1479000166_A_fn_class *jrt.Class



type A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_super_ctor_accessible_QMARK__top__1479000162_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_fn__1479000125_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_fn__1479000125_A_fn_class *jrt.Class



type A_arbace_j2g_model_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_throwable_print_helper_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_throwable_print_helper_A_fn_class *jrt.Class



type A_arbace_j2g_model_top_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_top_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_translatable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translatable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_translated_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translated_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_trivial_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_trivial_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_virtual_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_virtual_member_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000110_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000110_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000110_fn__1479000111_A_fn_class *jrt.Class



type A_arbace_j2g_model_world_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_world_supertypes_A_fn_class *jrt.Class
