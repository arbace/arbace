//line j2g_classes.ae:1
package aot_arbace_j2g_model

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_model_T_A_class, Name: "arbace.j2g.model$T", Modifiers: 25, Simple: "T", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_T_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_abstract_QMARK__A_class, Name: "arbace.j2g.model$abstract_QMARK_", Modifiers: 25, Simple: "abstract_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_abstract_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_abstract_m_QMARK__A_class, Name: "arbace.j2g.model$abstract_m_QMARK_", Modifiers: 25, Simple: "abstract_m_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_abstract_m_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_abstract_method_error_text_A_class, Name: "arbace.j2g.model$abstract_method_error_text", Modifiers: 25, Simple: "abstract_method_error_text", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_abstract_method_error_text_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_all_supertypes_A_class, Name: "arbace.j2g.model$all_supertypes", Modifiers: 25, Simple: "all_supertypes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_array_test_A_class, Name: "arbace.j2g.model$array_test", Modifiers: 25, Simple: "array_test", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_benign_init_QMARK__A_class, Name: "arbace.j2g.model$benign_init_QMARK_", Modifiers: 25, Simple: "benign_init_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_benign_init_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A_class, Name: "arbace.j2g.model$benign_init_QMARK_$fn__1479000217", Modifiers: 25, Simple: "fn__1479000217", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_benign_init_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_class_sym_A_class, Name: "arbace.j2g.model$class_sym", Modifiers: 25, Simple: "class_sym", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_code_class_QMARK__A_class, Name: "arbace.j2g.model$code_class_QMARK_", Modifiers: 25, Simple: "code_class_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_code_class_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_code_iface_QMARK__A_class, Name: "arbace.j2g.model$code_iface_QMARK_", Modifiers: 25, Simple: "code_iface_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_code_iface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_A_class, Name: "arbace.j2g.model$declared_vmethods", Modifiers: 25, Simple: "declared_vmethods", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_class, Name: "arbace.j2g.model$declared_vmethods$iter__1479000096__1479000100", Modifiers: 25, Simple: "iter__1479000096__1479000100", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_declared_vmethods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_class, Name: "arbace.j2g.model$declared_vmethods$iter__1479000096__1479000100$fn__1479000101", Modifiers: 25, Simple: "fn__1479000101", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A_class, Name: "arbace.j2g.model$declared_vmethods$iter__1479000096__1479000100$fn__1479000101$fn__1479000102", Modifiers: 25, Simple: "fn__1479000102", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_desc_classes_A_class, Name: "arbace.j2g.model$desc_classes", Modifiers: 25, Simple: "desc_classes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_desc_classes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_desc_in_world_QMARK__A_class, Name: "arbace.j2g.model$desc_in_world_QMARK_", Modifiers: 25, Simple: "desc_in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_desc_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_erased_desc_QMARK__A_class, Name: "arbace.j2g.model$erased_desc_QMARK_", Modifiers: 25, Simple: "erased_desc_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_erased_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A_class, Name: "arbace.j2g.model$erased_desc_QMARK_$fn__1479000053", Modifiers: 25, Simple: "fn__1479000053", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_erased_desc_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A_class, Name: "arbace.j2g.model$erased_desc_QMARK_$fn__1479000055", Modifiers: 25, Simple: "fn__1479000055", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_erased_desc_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_class, Name: "arbace.j2g.model$eval1479000004$loading__1927001464__auto____1479000005", Modifiers: 25, Simple: "loading__1927001464__auto____1479000005", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_eval1479000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_eval1479000008_fn__1479000009_A_class, Name: "arbace.j2g.model$eval1479000008$fn__1479000009", Modifiers: 25, Simple: "fn__1479000009", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000008_fn__1479000009_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_eval1479000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_fields_of_A_class, Name: "arbace.j2g.model$fields_of", Modifiers: 25, Simple: "fields_of", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_final_QMARK__A_class, Name: "arbace.j2g.model$final_QMARK_", Modifiers: 25, Simple: "final_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_find_method_A_class, Name: "arbace.j2g.model$find_method", Modifiers: 25, Simple: "find_method", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_find_method_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_find_method_fn__1479000086_A_class, Name: "arbace.j2g.model$find_method$fn__1479000086", Modifiers: 25, Simple: "fn__1479000086", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_find_method_fn__1479000086_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_find_method_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_fn__1479000224_A_class, Name: "arbace.j2g.model$fn__1479000224", Modifiers: 25, Simple: "fn__1479000224", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_fn__1479000224_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_class, Name: "arbace.j2g.model$fn__1479000224$iter__1479000220__1479000225", Modifiers: 25, Simple: "iter__1479000220__1479000225", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_fn__1479000224_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_class, Name: "arbace.j2g.model$fn__1479000224$iter__1479000220__1479000225$fn__1479000226", Modifiers: 25, Simple: "fn__1479000226", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A_class, Name: "arbace.j2g.model$fn__1479000224$iter__1479000220__1479000225$fn__1479000226$fn__1479000227", Modifiers: 25, Simple: "fn__1479000227", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_go_name_A_class, Name: "arbace.j2g.model$go_name", Modifiers: 25, Simple: "go_name", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_go_qualified_name_A_class, Name: "arbace.j2g.model$go_qualified_name", Modifiers: 25, Simple: "go_qualified_name", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_go_qualified_name_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_go_type_A_class, Name: "arbace.j2g.model$go_type", Modifiers: 25, Simple: "go_type", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_hand_written_QMARK__A_class, Name: "arbace.j2g.model$hand_written_QMARK_", Modifiers: 25, Simple: "hand_written_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_has_QMARK__A_class, Name: "arbace.j2g.model$has_QMARK_", Modifiers: 25, Simple: "has_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_has_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_hw_method_exists_QMARK__A_class, Name: "arbace.j2g.model$hw_method_exists_QMARK_", Modifiers: 25, Simple: "hw_method_exists_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_hw_method_exists_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_iface_desc_QMARK__A_class, Name: "arbace.j2g.model$iface_desc_QMARK_", Modifiers: 25, Simple: "iface_desc_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_iface_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_A_class, Name: "arbace.j2g.model$impl_of", Modifiers: 25, Simple: "impl_of", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_fn__1479000130_A_class, Name: "arbace.j2g.model$impl_of$fn__1479000130", Modifiers: 25, Simple: "fn__1479000130", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_fn__1479000130_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_fn__1479000142_A_class, Name: "arbace.j2g.model$impl_of$fn__1479000142", Modifiers: 25, Simple: "fn__1479000142", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_fn__1479000142_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A_class, Name: "arbace.j2g.model$impl_of$fn__1479000142$fn__1479000143", Modifiers: 25, Simple: "fn__1479000143", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_fn__1479000142_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_class, Name: "arbace.j2g.model$impl_of$iter__1479000132__1479000136", Modifiers: 25, Simple: "iter__1479000132__1479000136", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_class, Name: "arbace.j2g.model$impl_of$iter__1479000132__1479000136$fn__1479000137", Modifiers: 25, Simple: "fn__1479000137", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A_class, Name: "arbace.j2g.model$impl_of$iter__1479000132__1479000136$fn__1479000137$fn__1479000138", Modifiers: 25, Simple: "fn__1479000138", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_in_world_QMARK__A_class, Name: "arbace.j2g.model$in_world_QMARK_", Modifiers: 25, Simple: "in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_info_A_class, Name: "arbace.j2g.model$info", Modifiers: 25, Simple: "info", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_info_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_init_superinterfaces_A_class, Name: "arbace.j2g.model$init_superinterfaces", Modifiers: 25, Simple: "init_superinterfaces", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_init_superinterfaces_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_class, Name: "arbace.j2g.model$init_superinterfaces$declares_default_QMARK___1479000151", Modifiers: 25, Simple: "declares_default_QMARK___1479000151", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_init_superinterfaces_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A_class, Name: "arbace.j2g.model$init_superinterfaces$declares_default_QMARK___1479000151$fn__1479000152", Modifiers: 25, Simple: "fn__1479000152", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_class, Name: "arbace.j2g.model$init_superinterfaces$iter__1479000157__1479000161", Modifiers: 25, Simple: "iter__1479000157__1479000161", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_init_superinterfaces_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_class, Name: "arbace.j2g.model$init_superinterfaces$iter__1479000157__1479000161$fn__1479000162", Modifiers: 25, Simple: "fn__1479000162", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A_class, Name: "arbace.j2g.model$init_superinterfaces$iter__1479000157__1479000161$fn__1479000162$fn__1479000163", Modifiers: 25, Simple: "fn__1479000163", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A_class, Name: "arbace.j2g.model$init_superinterfaces$walk__1479000155", Modifiers: 25, Simple: "walk__1479000155", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_init_superinterfaces_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_interface_QMARK__A_class, Name: "arbace.j2g.model$interface_QMARK_", Modifiers: 25, Simple: "interface_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_j2g_method_QMARK__A_class, Name: "arbace.j2g.model$j2g_method_QMARK_", Modifiers: 25, Simple: "j2g_method_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_j2g_method_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_j2g_static_QMARK__A_class, Name: "arbace.j2g.model$j2g_static_QMARK_", Modifiers: 25, Simple: "j2g_static_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_j2g_static_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_java_type_name_A_class, Name: "arbace.j2g.model$java_type_name", Modifiers: 25, Simple: "java_type_name", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_jobs_A_class, Name: "arbace.j2g.model$jobs", Modifiers: 25, Simple: "jobs", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_jrt_class_A_class, Name: "arbace.j2g.model$jrt_class", Modifiers: 25, Simple: "jrt_class", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_jrt_class_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_jrt_sym_A_class, Name: "arbace.j2g.model$jrt_sym", Modifiers: 25, Simple: "jrt_sym", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_jrt_sym_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_leaf_QMARK__A_class, Name: "arbace.j2g.model$leaf_QMARK_", Modifiers: 25, Simple: "leaf_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_A_class, Name: "arbace.j2g.model$make_subclass_index", Modifiers: 25, Simple: "make_subclass_index", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_class, Name: "arbace.j2g.model$make_subclass_index$fn__1479000065", Modifiers: 25, Simple: "fn__1479000065", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_fn__1479000065_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_make_subclass_index_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_class, Name: "arbace.j2g.model$make_subclass_index$fn__1479000065$fn__1479000066", Modifiers: 25, Simple: "fn__1479000066", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A_class, Name: "arbace.j2g.model$make_subclass_index$fn__1479000065$fn__1479000066$fn__1479000067", Modifiers: 25, Simple: "fn__1479000067", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_mdesc_in_world_QMARK__A_class, Name: "arbace.j2g.model$mdesc_in_world_QMARK_", Modifiers: 25, Simple: "mdesc_in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_member_in_world_QMARK__A_class, Name: "arbace.j2g.model$member_in_world_QMARK_", Modifiers: 25, Simple: "member_in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_member_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_method_desc_classes_A_class, Name: "arbace.j2g.model$method_desc_classes", Modifiers: 25, Simple: "method_desc_classes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_method_desc_classes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_methods_of_A_class, Name: "arbace.j2g.model$methods_of", Modifiers: 25, Simple: "methods_of", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_nest_top_A_class, Name: "arbace.j2g.model$nest_top", Modifiers: 25, Simple: "nest_top", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_nest_top_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_on_run_thread_A_class, Name: "arbace.j2g.model$on_run_thread", Modifiers: 25, Simple: "on_run_thread", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_on_run_thread_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_A_class, Name: "arbace.j2g.model$par_mapv", Modifiers: 25, Simple: "par_mapv", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_fn__1479000021_A_class, Name: "arbace.j2g.model$par_mapv$fn__1479000021", Modifiers: 25, Simple: "fn__1479000021", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_fn__1479000021_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_class, Name: "arbace.j2g.model$par_mapv$fn__1479000021$fn__1479000022", Modifiers: 25, Simple: "fn__1479000022", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_fn__1479000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_fn__1479000027_A_class, Name: "arbace.j2g.model$par_mapv$fn__1479000027", Modifiers: 25, Simple: "fn__1479000027", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_fn__1479000027_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_class, Name: "arbace.j2g.model$par_mapv$fn__1479000027$fn__1479000028", Modifiers: 25, Simple: "fn__1479000028", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_fn__1479000027_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_work__1479000025_A_class, Name: "arbace.j2g.model$par_mapv$work__1479000025", Modifiers: 25, Simple: "work__1479000025", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_work__1479000025_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pkg_A_class, Name: "arbace.j2g.model$pkg", Modifiers: 25, Simple: "pkg", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pointer_desc_QMARK__A_class, Name: "arbace.j2g.model$pointer_desc_QMARK_", Modifiers: 25, Simple: "pointer_desc_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_private_QMARK__A_class, Name: "arbace.j2g.model$private_QMARK_", Modifiers: 25, Simple: "private_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_ctor_QMARK__A_class, Name: "arbace.j2g.model$pure_ctor_QMARK_", Modifiers: 25, Simple: "pure_ctor_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_ctor_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A_class, Name: "arbace.j2g.model$pure_ctor_QMARK_$fn__1479000185", Modifiers: 25, Simple: "fn__1479000185", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_ctor_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A_class, Name: "arbace.j2g.model$pure_ctor_QMARK_$fn__1479000187", Modifiers: 25, Simple: "fn__1479000187", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_ctor_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__A_class, Name: "arbace.j2g.model$pure_node_QMARK_", Modifiers: 25, Simple: "pure_node_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000197", Modifiers: 25, Simple: "fn__1479000197", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000200", Modifiers: 25, Simple: "fn__1479000200", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000205", Modifiers: 25, Simple: "fn__1479000205", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000207", Modifiers: 25, Simple: "fn__1479000207", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000209", Modifiers: 25, Simple: "fn__1479000209", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000211", Modifiers: 25, Simple: "fn__1479000211", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000213", Modifiers: 25, Simple: "fn__1479000213", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_qualify_A_class, Name: "arbace.j2g.model$qualify", Modifiers: 25, Simple: "qualify", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_qualify_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_reflectable_interface_QMARK__A_class, Name: "arbace.j2g.model$reflectable_interface_QMARK_", Modifiers: 25, Simple: "reflectable_interface_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_reflectable_interface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A_class, Name: "arbace.j2g.model$reflectable_interface_QMARK_$fn__1479000041", Modifiers: 25, Simple: "fn__1479000041", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_reflectable_interface_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_reflected_QMARK__A_class, Name: "arbace.j2g.model$reflected_QMARK_", Modifiers: 25, Simple: "reflected_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_run_fn_A_class, Name: "arbace.j2g.model$run_fn", Modifiers: 25, Simple: "run_fn", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_run_fn_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_run_fn_fn__1479000013_A_class, Name: "arbace.j2g.model$run_fn$fn__1479000013", Modifiers: 25, Simple: "fn__1479000013", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_run_fn_fn__1479000013_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_run_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_class_QMARK__A_class, Name: "arbace.j2g.model$start_class_QMARK_", Modifiers: 25, Simple: "start_class_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_class_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_A_class, Name: "arbace.j2g.model$start_classes", Modifiers: 25, Simple: "start_classes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_class, Name: "arbace.j2g.model$start_classes$iter__1479000171__1479000175", Modifiers: 25, Simple: "iter__1479000171__1479000175", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_start_classes_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_class, Name: "arbace.j2g.model$start_classes$iter__1479000171__1479000175$fn__1479000176", Modifiers: 25, Simple: "fn__1479000176", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A_class, Name: "arbace.j2g.model$start_classes$iter__1479000171__1479000175$fn__1479000176$fn__1479000177", Modifiers: 25, Simple: "fn__1479000177", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_static_QMARK__A_class, Name: "arbace.j2g.model$static_QMARK_", Modifiers: 25, Simple: "static_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_subclasses_A_class, Name: "arbace.j2g.model$subclasses", Modifiers: 25, Simple: "subclasses", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_subclasses_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_superclass_chain_A_class, Name: "arbace.j2g.model$superclass_chain", Modifiers: 25, Simple: "superclass_chain", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_superclass_chain_fn__1479000122_A_class, Name: "arbace.j2g.model$superclass_chain$fn__1479000122", Modifiers: 25, Simple: "fn__1479000122", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_fn__1479000122_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_superclass_chain_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_supertypes_A_class, Name: "arbace.j2g.model$supertypes", Modifiers: 25, Simple: "supertypes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_supertypes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_throwable_print_helper_A_class, Name: "arbace.j2g.model$throwable_print_helper", Modifiers: 25, Simple: "throwable_print_helper", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_throwable_print_helper_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_top_class_A_class, Name: "arbace.j2g.model$top_class", Modifiers: 25, Simple: "top_class", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_top_class_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_translatable_QMARK__A_class, Name: "arbace.j2g.model$translatable_QMARK_", Modifiers: 25, Simple: "translatable_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_translatable_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_translated_QMARK__A_class, Name: "arbace.j2g.model$translated_QMARK_", Modifiers: 25, Simple: "translated_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_trivial_init_QMARK__A_class, Name: "arbace.j2g.model$trivial_init_QMARK_", Modifiers: 25, Simple: "trivial_init_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_virtual_member_QMARK__A_class, Name: "arbace.j2g.model$virtual_member_QMARK_", Modifiers: 25, Simple: "virtual_member_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_virtual_member_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_vmethods_A_class, Name: "arbace.j2g.model$vmethods", Modifiers: 25, Simple: "vmethods", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_vmethods_fn__1479000107_A_class, Name: "arbace.j2g.model$vmethods$fn__1479000107", Modifiers: 25, Simple: "fn__1479000107", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_fn__1479000107_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_vmethods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A_class, Name: "arbace.j2g.model$vmethods$fn__1479000107$fn__1479000108", Modifiers: 25, Simple: "fn__1479000108", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_vmethods_fn__1479000107_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_world_supertypes_A_class, Name: "arbace.j2g.model$world_supertypes", Modifiers: 25, Simple: "world_supertypes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_world_supertypes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_model_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model_A_New()}; return nil }

var A_arbace_j2g_model_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_model_A_new}

var A_arbace_j2g_model_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_A"})

func init() { i := A_arbace_j2g_model_A_class.Info(); i.IsInstance = A_arbace_j2g_model_A_InstanceOf; i.Init = A_arbace_j2g_model_A_Init; i.Table = A_arbace_j2g_model_A_members }

var A_arbace_j2g_model_T_A_class *jrt.Class

var A_arbace_j2g_model_abstract_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_abstract_m_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_abstract_method_error_text_A_class *jrt.Class

var A_arbace_j2g_model_all_supertypes_A_class *jrt.Class

var A_arbace_j2g_model_array_test_A_class *jrt.Class

var A_arbace_j2g_model_benign_init_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000217_A_class *jrt.Class

var A_arbace_j2g_model_class_sym_A_class *jrt.Class

var A_arbace_j2g_model_code_class_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_code_iface_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_iter__1479000096__1479000100_fn__1479000101_fn__1479000102_A_class *jrt.Class

var A_arbace_j2g_model_desc_classes_A_class *jrt.Class

var A_arbace_j2g_model_desc_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_erased_desc_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000053_A_class *jrt.Class

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000055_A_class *jrt.Class

func A_arbace_j2g_model_eval1479000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model_eval1479000004_A_New()}; return nil }

var A_arbace_j2g_model_eval1479000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_model_eval1479000004_A_new}

var A_arbace_j2g_model_eval1479000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model$eval1479000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_model_A_class, Simple: "eval1479000004", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000004_A"})

func init() { i := A_arbace_j2g_model_eval1479000004_A_class.Info(); i.IsInstance = A_arbace_j2g_model_eval1479000004_A_InstanceOf; i.Table = A_arbace_j2g_model_eval1479000004_A_members }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_class *jrt.Class

func A_arbace_j2g_model_eval1479000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model_eval1479000008_A_New()}; return nil }

var A_arbace_j2g_model_eval1479000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_model_eval1479000008_A_new}

var A_arbace_j2g_model_eval1479000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model$eval1479000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_model_A_class, Simple: "eval1479000008", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000008_A"})

func init() { i := A_arbace_j2g_model_eval1479000008_A_class.Info(); i.IsInstance = A_arbace_j2g_model_eval1479000008_A_InstanceOf; i.Table = A_arbace_j2g_model_eval1479000008_A_members }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_class *jrt.Class

var A_arbace_j2g_model_fields_of_A_class *jrt.Class

var A_arbace_j2g_model_final_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_find_method_A_class *jrt.Class

var A_arbace_j2g_model_find_method_fn__1479000086_A_class *jrt.Class

var A_arbace_j2g_model_fn__1479000224_A_class *jrt.Class

var A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_A_class *jrt.Class

var A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_A_class *jrt.Class

var A_arbace_j2g_model_fn__1479000224_iter__1479000220__1479000225_fn__1479000226_fn__1479000227_A_class *jrt.Class

var A_arbace_j2g_model_go_name_A_class *jrt.Class

var A_arbace_j2g_model_go_qualified_name_A_class *jrt.Class

var A_arbace_j2g_model_go_type_A_class *jrt.Class

var A_arbace_j2g_model_hand_written_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_has_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_hw_method_exists_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_iface_desc_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_impl_of_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_fn__1479000130_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_fn__1479000142_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_fn__1479000142_fn__1479000143_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_iter__1479000132__1479000136_fn__1479000137_fn__1479000138_A_class *jrt.Class

var A_arbace_j2g_model_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_info_A_class *jrt.Class

var A_arbace_j2g_model_init_superinterfaces_A_class *jrt.Class

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_A_class *jrt.Class

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000151_fn__1479000152_A_class *jrt.Class

var A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_A_class *jrt.Class

var A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_A_class *jrt.Class

var A_arbace_j2g_model_init_superinterfaces_iter__1479000157__1479000161_fn__1479000162_fn__1479000163_A_class *jrt.Class

var A_arbace_j2g_model_init_superinterfaces_walk__1479000155_A_class *jrt.Class

var A_arbace_j2g_model_interface_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_j2g_method_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_j2g_static_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_java_type_name_A_class *jrt.Class

var A_arbace_j2g_model_jobs_A_class *jrt.Class

var A_arbace_j2g_model_jrt_class_A_class *jrt.Class

var A_arbace_j2g_model_jrt_sym_A_class *jrt.Class

var A_arbace_j2g_model_leaf_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_fn__1479000065_A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_fn__1479000065_fn__1479000066_fn__1479000067_A_class *jrt.Class

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_member_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_method_desc_classes_A_class *jrt.Class

var A_arbace_j2g_model_methods_of_A_class *jrt.Class

var A_arbace_j2g_model_nest_top_A_class *jrt.Class

var A_arbace_j2g_model_on_run_thread_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_fn__1479000021_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_fn__1479000027_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_fn__1479000027_fn__1479000028_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_work__1479000025_A_class *jrt.Class

var A_arbace_j2g_model_pkg_A_class *jrt.Class

var A_arbace_j2g_model_pointer_desc_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_private_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_pure_ctor_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000185_A_class *jrt.Class

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000187_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000197_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000200_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000209_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000211_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000213_A_class *jrt.Class

var A_arbace_j2g_model_qualify_A_class *jrt.Class

var A_arbace_j2g_model_reflectable_interface_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000041_A_class *jrt.Class

var A_arbace_j2g_model_reflected_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_run_fn_A_class *jrt.Class

var A_arbace_j2g_model_run_fn_fn__1479000013_A_class *jrt.Class

var A_arbace_j2g_model_start_class_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_start_classes_A_class *jrt.Class

var A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_A_class *jrt.Class

var A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_A_class *jrt.Class

var A_arbace_j2g_model_start_classes_iter__1479000171__1479000175_fn__1479000176_fn__1479000177_A_class *jrt.Class

var A_arbace_j2g_model_static_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_subclasses_A_class *jrt.Class

var A_arbace_j2g_model_superclass_chain_A_class *jrt.Class

var A_arbace_j2g_model_superclass_chain_fn__1479000122_A_class *jrt.Class

var A_arbace_j2g_model_supertypes_A_class *jrt.Class

var A_arbace_j2g_model_throwable_print_helper_A_class *jrt.Class

var A_arbace_j2g_model_top_class_A_class *jrt.Class

var A_arbace_j2g_model_translatable_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_translated_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_trivial_init_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_virtual_member_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_vmethods_A_class *jrt.Class

var A_arbace_j2g_model_vmethods_fn__1479000107_A_class *jrt.Class

var A_arbace_j2g_model_vmethods_fn__1479000107_fn__1479000108_A_class *jrt.Class

var A_arbace_j2g_model_world_supertypes_A_class *jrt.Class

func A_arbace_j2g_model__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_model__init_A_Load__O()}; return nil }

func A_arbace_j2g_model__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model__init_A_New()}; return nil }

var A_arbace_j2g_model__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_model__init_A_invoke, New: A_arbace_j2g_model__init_A_new}

var A_arbace_j2g_model__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model__init_A", Source: "model.ae"})

func init() { i := A_arbace_j2g_model__init_A_class.Info(); i.IsInstance = A_arbace_j2g_model__init_A_InstanceOf; i.Init = A_arbace_j2g_model__init_A_Init; i.Table = A_arbace_j2g_model__init_A_members }
