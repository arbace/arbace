//line j2g_classes.ae:1
package aot_arbace_j2g_model

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_model_T_A_class, Name: "arbace.j2g.model$T", Modifiers: 25, Simple: "T", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_T_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_abstract_QMARK__A_class, Name: "arbace.j2g.model$abstract_QMARK_", Modifiers: 25, Simple: "abstract_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_abstract_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_abstract_m_QMARK__A_class, Name: "arbace.j2g.model$abstract_m_QMARK_", Modifiers: 25, Simple: "abstract_m_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_abstract_m_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_abstract_method_error_text_A_class, Name: "arbace.j2g.model$abstract_method_error_text", Modifiers: 25, Simple: "abstract_method_error_text", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_abstract_method_error_text_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_all_supertypes_A_class, Name: "arbace.j2g.model$all_supertypes", Modifiers: 25, Simple: "all_supertypes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_benign_init_QMARK__A_class, Name: "arbace.j2g.model$benign_init_QMARK_", Modifiers: 25, Simple: "benign_init_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_benign_init_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_benign_init_QMARK__fn__1479000190_A_class, Name: "arbace.j2g.model$benign_init_QMARK_$fn__1479000190", Modifiers: 25, Simple: "fn__1479000190", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_benign_init_QMARK__fn__1479000190_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_benign_init_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_class_sym_A_class, Name: "arbace.j2g.model$class_sym", Modifiers: 25, Simple: "class_sym", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_code_class_QMARK__A_class, Name: "arbace.j2g.model$code_class_QMARK_", Modifiers: 25, Simple: "code_class_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_code_class_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_code_iface_QMARK__A_class, Name: "arbace.j2g.model$code_iface_QMARK_", Modifiers: 25, Simple: "code_iface_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_code_iface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_A_class, Name: "arbace.j2g.model$declared_vmethods", Modifiers: 25, Simple: "declared_vmethods", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_class, Name: "arbace.j2g.model$declared_vmethods$iter__1479000087__1479000091", Modifiers: 25, Simple: "iter__1479000087__1479000091", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_declared_vmethods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_class, Name: "arbace.j2g.model$declared_vmethods$iter__1479000087__1479000091$fn__1479000092", Modifiers: 25, Simple: "fn__1479000092", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A_class, Name: "arbace.j2g.model$declared_vmethods$iter__1479000087__1479000091$fn__1479000092$fn__1479000093", Modifiers: 25, Simple: "fn__1479000093", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_desc_classes_A_class, Name: "arbace.j2g.model$desc_classes", Modifiers: 25, Simple: "desc_classes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_desc_classes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_desc_in_world_QMARK__A_class, Name: "arbace.j2g.model$desc_in_world_QMARK_", Modifiers: 25, Simple: "desc_in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_desc_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_erased_desc_QMARK__A_class, Name: "arbace.j2g.model$erased_desc_QMARK_", Modifiers: 25, Simple: "erased_desc_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_erased_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A_class, Name: "arbace.j2g.model$erased_desc_QMARK_$fn__1479000045", Modifiers: 25, Simple: "fn__1479000045", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_erased_desc_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_class, Name: "arbace.j2g.model$erased_desc_QMARK_$fn__1479000047", Modifiers: 25, Simple: "fn__1479000047", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_erased_desc_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_class, Name: "arbace.j2g.model$eval1479000004$loading__1927001464__auto____1479000005", Modifiers: 25, Simple: "loading__1927001464__auto____1479000005", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_eval1479000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_eval1479000008_fn__1479000009_A_class, Name: "arbace.j2g.model$eval1479000008$fn__1479000009", Modifiers: 25, Simple: "fn__1479000009", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000008_fn__1479000009_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_eval1479000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_fields_of_A_class, Name: "arbace.j2g.model$fields_of", Modifiers: 25, Simple: "fields_of", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_fields_of_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_final_QMARK__A_class, Name: "arbace.j2g.model$final_QMARK_", Modifiers: 25, Simple: "final_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_find_method_A_class, Name: "arbace.j2g.model$find_method", Modifiers: 25, Simple: "find_method", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_find_method_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_find_method_fn__1479000077_A_class, Name: "arbace.j2g.model$find_method$fn__1479000077", Modifiers: 25, Simple: "fn__1479000077", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_find_method_fn__1479000077_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_find_method_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_go_name_A_class, Name: "arbace.j2g.model$go_name", Modifiers: 25, Simple: "go_name", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_go_qualified_name_A_class, Name: "arbace.j2g.model$go_qualified_name", Modifiers: 25, Simple: "go_qualified_name", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_go_qualified_name_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_go_type_A_class, Name: "arbace.j2g.model$go_type", Modifiers: 25, Simple: "go_type", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_hand_written_QMARK__A_class, Name: "arbace.j2g.model$hand_written_QMARK_", Modifiers: 25, Simple: "hand_written_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_has_QMARK__A_class, Name: "arbace.j2g.model$has_QMARK_", Modifiers: 25, Simple: "has_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_has_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_hw_method_exists_QMARK__A_class, Name: "arbace.j2g.model$hw_method_exists_QMARK_", Modifiers: 25, Simple: "hw_method_exists_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_hw_method_exists_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_iface_desc_QMARK__A_class, Name: "arbace.j2g.model$iface_desc_QMARK_", Modifiers: 25, Simple: "iface_desc_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_iface_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_A_class, Name: "arbace.j2g.model$impl_of", Modifiers: 25, Simple: "impl_of", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_fn__1479000121_A_class, Name: "arbace.j2g.model$impl_of$fn__1479000121", Modifiers: 25, Simple: "fn__1479000121", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_fn__1479000121_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_fn__1479000133_A_class, Name: "arbace.j2g.model$impl_of$fn__1479000133", Modifiers: 25, Simple: "fn__1479000133", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_fn__1479000133_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_fn__1479000133_fn__1479000134_A_class, Name: "arbace.j2g.model$impl_of$fn__1479000133$fn__1479000134", Modifiers: 25, Simple: "fn__1479000134", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_fn__1479000133_fn__1479000134_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_fn__1479000133_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_A_class, Name: "arbace.j2g.model$impl_of$iter__1479000123__1479000127", Modifiers: 25, Simple: "iter__1479000123__1479000127", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_fn__1479000128_A_class, Name: "arbace.j2g.model$impl_of$iter__1479000123__1479000127$fn__1479000128", Modifiers: 25, Simple: "fn__1479000128", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_fn__1479000128_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_fn__1479000128_fn__1479000129_A_class, Name: "arbace.j2g.model$impl_of$iter__1479000123__1479000127$fn__1479000128$fn__1479000129", Modifiers: 25, Simple: "fn__1479000129", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_fn__1479000128_fn__1479000129_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_fn__1479000128_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_in_world_QMARK__A_class, Name: "arbace.j2g.model$in_world_QMARK_", Modifiers: 25, Simple: "in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_info_A_class, Name: "arbace.j2g.model$info", Modifiers: 25, Simple: "info", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_info_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_interface_QMARK__A_class, Name: "arbace.j2g.model$interface_QMARK_", Modifiers: 25, Simple: "interface_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_j2g_method_QMARK__A_class, Name: "arbace.j2g.model$j2g_method_QMARK_", Modifiers: 25, Simple: "j2g_method_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_j2g_method_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_j2g_static_QMARK__A_class, Name: "arbace.j2g.model$j2g_static_QMARK_", Modifiers: 25, Simple: "j2g_static_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_j2g_static_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_java_type_name_A_class, Name: "arbace.j2g.model$java_type_name", Modifiers: 25, Simple: "java_type_name", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_jobs_A_class, Name: "arbace.j2g.model$jobs", Modifiers: 25, Simple: "jobs", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_jrt_class_A_class, Name: "arbace.j2g.model$jrt_class", Modifiers: 25, Simple: "jrt_class", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_jrt_class_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_jrt_sym_A_class, Name: "arbace.j2g.model$jrt_sym", Modifiers: 25, Simple: "jrt_sym", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_jrt_sym_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_leaf_QMARK__A_class, Name: "arbace.j2g.model$leaf_QMARK_", Modifiers: 25, Simple: "leaf_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_A_class, Name: "arbace.j2g.model$make_subclass_index", Modifiers: 25, Simple: "make_subclass_index", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_class, Name: "arbace.j2g.model$make_subclass_index$fn__1479000057", Modifiers: 25, Simple: "fn__1479000057", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_fn__1479000057_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_make_subclass_index_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_class, Name: "arbace.j2g.model$make_subclass_index$fn__1479000057$fn__1479000058", Modifiers: 25, Simple: "fn__1479000058", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A_class, Name: "arbace.j2g.model$make_subclass_index$fn__1479000057$fn__1479000058$fn__1479000059", Modifiers: 25, Simple: "fn__1479000059", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_mdesc_in_world_QMARK__A_class, Name: "arbace.j2g.model$mdesc_in_world_QMARK_", Modifiers: 25, Simple: "mdesc_in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_member_in_world_QMARK__A_class, Name: "arbace.j2g.model$member_in_world_QMARK_", Modifiers: 25, Simple: "member_in_world_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_member_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_method_desc_classes_A_class, Name: "arbace.j2g.model$method_desc_classes", Modifiers: 25, Simple: "method_desc_classes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_method_desc_classes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_methods_of_A_class, Name: "arbace.j2g.model$methods_of", Modifiers: 25, Simple: "methods_of", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_nest_top_A_class, Name: "arbace.j2g.model$nest_top", Modifiers: 25, Simple: "nest_top", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_nest_top_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_A_class, Name: "arbace.j2g.model$par_mapv", Modifiers: 25, Simple: "par_mapv", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_fn__1479000019_A_class, Name: "arbace.j2g.model$par_mapv$fn__1479000019", Modifiers: 25, Simple: "fn__1479000019", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_fn__1479000019_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A_class, Name: "arbace.j2g.model$par_mapv$fn__1479000019$fn__1479000020", Modifiers: 25, Simple: "fn__1479000020", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_fn__1479000019_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_par_mapv_work__1479000017_A_class, Name: "arbace.j2g.model$par_mapv$work__1479000017", Modifiers: 25, Simple: "work__1479000017", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_par_mapv_work__1479000017_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_par_mapv_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pkg_A_class, Name: "arbace.j2g.model$pkg", Modifiers: 25, Simple: "pkg", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pointer_desc_QMARK__A_class, Name: "arbace.j2g.model$pointer_desc_QMARK_", Modifiers: 25, Simple: "pointer_desc_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_private_QMARK__A_class, Name: "arbace.j2g.model$private_QMARK_", Modifiers: 25, Simple: "private_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_ctor_QMARK__A_class, Name: "arbace.j2g.model$pure_ctor_QMARK_", Modifiers: 25, Simple: "pure_ctor_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_ctor_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000158_A_class, Name: "arbace.j2g.model$pure_ctor_QMARK_$fn__1479000158", Modifiers: 25, Simple: "fn__1479000158", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000158_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_ctor_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_class, Name: "arbace.j2g.model$pure_ctor_QMARK_$fn__1479000160", Modifiers: 25, Simple: "fn__1479000160", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_ctor_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__A_class, Name: "arbace.j2g.model$pure_node_QMARK_", Modifiers: 25, Simple: "pure_node_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000170_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000170", Modifiers: 25, Simple: "fn__1479000170", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000170_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000173", Modifiers: 25, Simple: "fn__1479000173", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000178_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000178", Modifiers: 25, Simple: "fn__1479000178", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000178_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000180", Modifiers: 25, Simple: "fn__1479000180", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000182", Modifiers: 25, Simple: "fn__1479000182", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000184", Modifiers: 25, Simple: "fn__1479000184", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_class, Name: "arbace.j2g.model$pure_node_QMARK_$fn__1479000186", Modifiers: 25, Simple: "fn__1479000186", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_qualify_A_class, Name: "arbace.j2g.model$qualify", Modifiers: 25, Simple: "qualify", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_qualify_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_reflectable_interface_QMARK__A_class, Name: "arbace.j2g.model$reflectable_interface_QMARK_", Modifiers: 25, Simple: "reflectable_interface_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_reflectable_interface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A_class, Name: "arbace.j2g.model$reflectable_interface_QMARK_$fn__1479000033", Modifiers: 25, Simple: "fn__1479000033", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_reflectable_interface_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_reflected_QMARK__A_class, Name: "arbace.j2g.model$reflected_QMARK_", Modifiers: 25, Simple: "reflected_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_class_QMARK__A_class, Name: "arbace.j2g.model$start_class_QMARK_", Modifiers: 25, Simple: "start_class_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_class_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_A_class, Name: "arbace.j2g.model$start_classes", Modifiers: 25, Simple: "start_classes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_A_class, Name: "arbace.j2g.model$start_classes$iter__1479000144__1479000148", Modifiers: 25, Simple: "iter__1479000144__1479000148", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_start_classes_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_fn__1479000149_A_class, Name: "arbace.j2g.model$start_classes$iter__1479000144__1479000148$fn__1479000149", Modifiers: 25, Simple: "fn__1479000149", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_fn__1479000149_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_fn__1479000149_fn__1479000150_A_class, Name: "arbace.j2g.model$start_classes$iter__1479000144__1479000148$fn__1479000149$fn__1479000150", Modifiers: 25, Simple: "fn__1479000150", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_fn__1479000149_fn__1479000150_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_fn__1479000149_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_static_QMARK__A_class, Name: "arbace.j2g.model$static_QMARK_", Modifiers: 25, Simple: "static_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_subclasses_A_class, Name: "arbace.j2g.model$subclasses", Modifiers: 25, Simple: "subclasses", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_subclasses_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_superclass_chain_A_class, Name: "arbace.j2g.model$superclass_chain", Modifiers: 25, Simple: "superclass_chain", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_superclass_chain_fn__1479000113_A_class, Name: "arbace.j2g.model$superclass_chain$fn__1479000113", Modifiers: 25, Simple: "fn__1479000113", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_fn__1479000113_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_superclass_chain_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_supertypes_A_class, Name: "arbace.j2g.model$supertypes", Modifiers: 25, Simple: "supertypes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_supertypes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_top_class_A_class, Name: "arbace.j2g.model$top_class", Modifiers: 25, Simple: "top_class", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_top_class_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_translatable_QMARK__A_class, Name: "arbace.j2g.model$translatable_QMARK_", Modifiers: 25, Simple: "translatable_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_translatable_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_translated_QMARK__A_class, Name: "arbace.j2g.model$translated_QMARK_", Modifiers: 25, Simple: "translated_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_trivial_init_QMARK__A_class, Name: "arbace.j2g.model$trivial_init_QMARK_", Modifiers: 25, Simple: "trivial_init_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_virtual_member_QMARK__A_class, Name: "arbace.j2g.model$virtual_member_QMARK_", Modifiers: 25, Simple: "virtual_member_QMARK_", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_virtual_member_QMARK__A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_vmethods_A_class, Name: "arbace.j2g.model$vmethods", Modifiers: 25, Simple: "vmethods", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_vmethods_fn__1479000098_A_class, Name: "arbace.j2g.model$vmethods$fn__1479000098", Modifiers: 25, Simple: "fn__1479000098", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_fn__1479000098_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_vmethods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A_class, Name: "arbace.j2g.model$vmethods$fn__1479000098$fn__1479000099", Modifiers: 25, Simple: "fn__1479000099", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_vmethods_fn__1479000098_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_model_world_supertypes_A_class, Name: "arbace.j2g.model$world_supertypes", Modifiers: 25, Simple: "world_supertypes", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_world_supertypes_A", Source: "model.ae", Declaring: &A_arbace_j2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_model_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model_A_New()}; return nil }

var A_arbace_j2g_model_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_model_A_new}

var A_arbace_j2g_model_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_A"})

func init() { i := A_arbace_j2g_model_A_class.Info(); i.IsInstance = A_arbace_j2g_model_A_InstanceOf; i.Init = A_arbace_j2g_model_A_Init; i.Table = A_arbace_j2g_model_A_members }

var A_arbace_j2g_model_T_A_class *jrt.Class

var A_arbace_j2g_model_abstract_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_abstract_m_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_abstract_method_error_text_A_class *jrt.Class

var A_arbace_j2g_model_all_supertypes_A_class *jrt.Class

var A_arbace_j2g_model_benign_init_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000190_A_class *jrt.Class

var A_arbace_j2g_model_class_sym_A_class *jrt.Class

var A_arbace_j2g_model_code_class_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_code_iface_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_A_class *jrt.Class

var A_arbace_j2g_model_declared_vmethods_iter__1479000087__1479000091_fn__1479000092_fn__1479000093_A_class *jrt.Class

var A_arbace_j2g_model_desc_classes_A_class *jrt.Class

var A_arbace_j2g_model_desc_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_erased_desc_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000045_A_class *jrt.Class

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_class *jrt.Class

func A_arbace_j2g_model_eval1479000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model_eval1479000004_A_New()}; return nil }

var A_arbace_j2g_model_eval1479000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_model_eval1479000004_A_new}

var A_arbace_j2g_model_eval1479000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model$eval1479000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_model_A_class, Simple: "eval1479000004", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000004_A"})

func init() { i := A_arbace_j2g_model_eval1479000004_A_class.Info(); i.IsInstance = A_arbace_j2g_model_eval1479000004_A_InstanceOf; i.Table = A_arbace_j2g_model_eval1479000004_A_members }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_class *jrt.Class

func A_arbace_j2g_model_eval1479000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model_eval1479000008_A_New()}; return nil }

var A_arbace_j2g_model_eval1479000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_model_eval1479000008_A_new}

var A_arbace_j2g_model_eval1479000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model$eval1479000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_model_A_class, Simple: "eval1479000008", Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model_eval1479000008_A"})

func init() { i := A_arbace_j2g_model_eval1479000008_A_class.Info(); i.IsInstance = A_arbace_j2g_model_eval1479000008_A_InstanceOf; i.Table = A_arbace_j2g_model_eval1479000008_A_members }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_class *jrt.Class

var A_arbace_j2g_model_fields_of_A_class *jrt.Class

var A_arbace_j2g_model_final_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_find_method_A_class *jrt.Class

var A_arbace_j2g_model_find_method_fn__1479000077_A_class *jrt.Class

var A_arbace_j2g_model_go_name_A_class *jrt.Class

var A_arbace_j2g_model_go_qualified_name_A_class *jrt.Class

var A_arbace_j2g_model_go_type_A_class *jrt.Class

var A_arbace_j2g_model_hand_written_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_has_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_hw_method_exists_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_iface_desc_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_impl_of_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_fn__1479000121_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_fn__1479000133_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_fn__1479000133_fn__1479000134_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_fn__1479000128_A_class *jrt.Class

var A_arbace_j2g_model_impl_of_iter__1479000123__1479000127_fn__1479000128_fn__1479000129_A_class *jrt.Class

var A_arbace_j2g_model_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_info_A_class *jrt.Class

var A_arbace_j2g_model_interface_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_j2g_method_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_j2g_static_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_java_type_name_A_class *jrt.Class

var A_arbace_j2g_model_jobs_A_class *jrt.Class

var A_arbace_j2g_model_jrt_class_A_class *jrt.Class

var A_arbace_j2g_model_jrt_sym_A_class *jrt.Class

var A_arbace_j2g_model_leaf_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_fn__1479000057_A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_A_class *jrt.Class

var A_arbace_j2g_model_make_subclass_index_fn__1479000057_fn__1479000058_fn__1479000059_A_class *jrt.Class

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_member_in_world_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_method_desc_classes_A_class *jrt.Class

var A_arbace_j2g_model_methods_of_A_class *jrt.Class

var A_arbace_j2g_model_nest_top_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_fn__1479000019_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_fn__1479000019_fn__1479000020_A_class *jrt.Class

var A_arbace_j2g_model_par_mapv_work__1479000017_A_class *jrt.Class

var A_arbace_j2g_model_pkg_A_class *jrt.Class

var A_arbace_j2g_model_pointer_desc_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_private_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_pure_ctor_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000158_A_class *jrt.Class

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000170_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000178_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_class *jrt.Class

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_class *jrt.Class

var A_arbace_j2g_model_qualify_A_class *jrt.Class

var A_arbace_j2g_model_reflectable_interface_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000033_A_class *jrt.Class

var A_arbace_j2g_model_reflected_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_start_class_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_start_classes_A_class *jrt.Class

var A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_A_class *jrt.Class

var A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_fn__1479000149_A_class *jrt.Class

var A_arbace_j2g_model_start_classes_iter__1479000144__1479000148_fn__1479000149_fn__1479000150_A_class *jrt.Class

var A_arbace_j2g_model_static_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_subclasses_A_class *jrt.Class

var A_arbace_j2g_model_superclass_chain_A_class *jrt.Class

var A_arbace_j2g_model_superclass_chain_fn__1479000113_A_class *jrt.Class

var A_arbace_j2g_model_supertypes_A_class *jrt.Class

var A_arbace_j2g_model_top_class_A_class *jrt.Class

var A_arbace_j2g_model_translatable_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_translated_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_trivial_init_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_virtual_member_QMARK__A_class *jrt.Class

var A_arbace_j2g_model_vmethods_A_class *jrt.Class

var A_arbace_j2g_model_vmethods_fn__1479000098_A_class *jrt.Class

var A_arbace_j2g_model_vmethods_fn__1479000098_fn__1479000099_A_class *jrt.Class

var A_arbace_j2g_model_world_supertypes_A_class *jrt.Class

func A_arbace_j2g_model__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_model__init_A_Load__O()}; return nil }

func A_arbace_j2g_model__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_model__init_A_New()}; return nil }

var A_arbace_j2g_model__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_model__init_A_invoke, New: A_arbace_j2g_model__init_A_new}

var A_arbace_j2g_model__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.model__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_model.A_arbace_j2g_model__init_A", Source: "model.ae"})

func init() { i := A_arbace_j2g_model__init_A_class.Info(); i.IsInstance = A_arbace_j2g_model__init_A_InstanceOf; i.Init = A_arbace_j2g_model__init_A_Init; i.Table = A_arbace_j2g_model__init_A_members }
