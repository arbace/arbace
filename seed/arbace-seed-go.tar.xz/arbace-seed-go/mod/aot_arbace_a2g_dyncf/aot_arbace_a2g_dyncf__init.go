//line aot_arbace_a2g_dyncf__init.ae:1
package aot_arbace_a2g_dyncf

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_dyncf__init_A_Unit0__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_dyncf__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf__init_A_const_1) }
//line :1:1
func A_arbace_a2g_dyncf__init_A_Unit1__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_dyncf__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_dyncf__init_A_Unit2__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A_Init(); tmp2 = A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_dyncf__init_A_Unit3__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_dyncf__init_A_const_1)).Equals_O__Z(A_arbace_a2g_dyncf__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A_Init(); tmp2 = A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_dyncf__init_A_Load__O() any { A_arbace_a2g_dyncf__init_A_Init(); A_arbace_a2g_dyncf__init_A_Unit0__O(); A_arbace_a2g_dyncf__init_A_Unit1__O(); A_arbace_a2g_dyncf__init_A_Unit2__O(); A_arbace_a2g_dyncf__init_A_Unit3__O(); A_arbace_a2g_dyncf__init_A_Unit4__O(); A_arbace_a2g_dyncf__init_A_Unit5__O(); A_arbace_a2g_dyncf__init_A_Unit6__O(); A_arbace_a2g_dyncf__init_A_Unit7__O(); A_arbace_a2g_dyncf__init_A_Unit8__O(); A_arbace_a2g_dyncf__init_A_Unit9__O(); A_arbace_a2g_dyncf__init_A_Unit10__O(); A_arbace_a2g_dyncf__init_A_Unit11__O(); A_arbace_a2g_dyncf__init_A_Unit12__O(); A_arbace_a2g_dyncf__init_A_Unit13__O(); A_arbace_a2g_dyncf__init_A_Unit14__O(); return nil }













func A_arbace_a2g_dyncf__init_A_Unit4__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); jrt.NN(A_arbace_a2g_dyncf__init_A_const_4).BindRoot_O__V(Lit_428); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_5)); return A_arbace_a2g_dyncf__init_A_const_4.Ref() }

func A_arbace_a2g_dyncf__init_A_Unit5__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_6; var tmp2 any = A_arbace_a2g_dyncf_enabled_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_enabled_QMARK__A_Init(); tmp3 = A_arbace_a2g_dyncf_enabled_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_7)); return A_arbace_a2g_dyncf__init_A_const_6.Ref() }




func A_arbace_a2g_dyncf__init_A_Unit6__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_8; var tmp2 any = A_arbace_a2g_dyncf_tag_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_tag_A_Init(); tmp3 = A_arbace_a2g_dyncf_tag_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_9)); return A_arbace_a2g_dyncf__init_A_const_8.Ref() }

func A_arbace_a2g_dyncf__init_A_Unit7__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_10; var tmp2 any = A_arbace_a2g_dyncf_native_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_native_name_A_Init(); tmp3 = A_arbace_a2g_dyncf_native_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_11)); return A_arbace_a2g_dyncf__init_A_const_10.Ref() }










func A_arbace_a2g_dyncf__init_A_Unit8__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_12; var tmp2 any = A_arbace_a2g_dyncf_sub_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_sub_name_A_Init(); tmp3 = A_arbace_a2g_dyncf_sub_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_13)); return A_arbace_a2g_dyncf__init_A_const_12.Ref() }

func A_arbace_a2g_dyncf__init_A_Unit9__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_14; var tmp2 any = A_arbace_a2g_dyncf_from_object_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_from_object_A_Init(); tmp3 = A_arbace_a2g_dyncf_from_object_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_15)); return A_arbace_a2g_dyncf__init_A_const_14.Ref() }







func A_arbace_a2g_dyncf__init_A_Unit10__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_16; var tmp2 any = A_arbace_a2g_dyncf_sub_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_sub_forms_A_Init(); tmp3 = A_arbace_a2g_dyncf_sub_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_17)); return A_arbace_a2g_dyncf__init_A_const_16.Ref() }



















































func A_arbace_a2g_dyncf__init_A_Unit11__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_18; var tmp2 any = A_arbace_a2g_dyncf_subs_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_subs_forms_A_Init(); tmp3 = A_arbace_a2g_dyncf_subs_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_19)); return A_arbace_a2g_dyncf__init_A_const_18.Ref() }


















func A_arbace_a2g_dyncf__init_A_Unit12__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(120, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_20; var tmp2 any = A_arbace_a2g_dyncf_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_forms_A_Init(); tmp3 = A_arbace_a2g_dyncf_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_21)); return A_arbace_a2g_dyncf__init_A_const_20.Ref() }


















































































































































































































func A_arbace_a2g_dyncf__init_A_Unit13__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(331, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_22; var tmp2 any = A_arbace_a2g_dyncf_strip_anns_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_strip_anns_A_Init(); tmp3 = A_arbace_a2g_dyncf_strip_anns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_23)); return A_arbace_a2g_dyncf__init_A_const_22.Ref() }


func A_arbace_a2g_dyncf__init_A_Unit14__O() any { A_arbace_a2g_dyncf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(334, 1); var tmp1 *lang.Var = A_arbace_a2g_dyncf__init_A_const_24; var tmp2 any = A_arbace_a2g_dyncf_generics_text_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyncf_generics_text_A_Init(); tmp3 = A_arbace_a2g_dyncf_generics_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyncf__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyncf__init_A_const_25)); return A_arbace_a2g_dyncf__init_A_const_24.Ref() }



type A_arbace_a2g_dyncf__init_A struct{ jrt.Object }

var A_arbace_a2g_dyncf__init_A_const_0 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_1 any

var A_arbace_a2g_dyncf__init_A_const_2 any

var A_arbace_a2g_dyncf__init_A_const_3 any

var A_arbace_a2g_dyncf__init_A_const_4 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_5 any

var A_arbace_a2g_dyncf__init_A_const_6 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_7 any

var A_arbace_a2g_dyncf__init_A_const_8 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_9 any

var A_arbace_a2g_dyncf__init_A_const_10 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_11 any

var A_arbace_a2g_dyncf__init_A_const_12 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_13 any

var A_arbace_a2g_dyncf__init_A_const_14 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_15 any

var A_arbace_a2g_dyncf__init_A_const_16 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_17 any

var A_arbace_a2g_dyncf__init_A_const_18 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_19 any

var A_arbace_a2g_dyncf__init_A_const_20 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_21 any

var A_arbace_a2g_dyncf__init_A_const_22 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_23 any

var A_arbace_a2g_dyncf__init_A_const_24 *lang.Var

var A_arbace_a2g_dyncf__init_A_const_25 any

var A_arbace_a2g_dyncf__init_A_init jrt.ClassInit

func A_arbace_a2g_dyncf__init_A_Init() { if !A_arbace_a2g_dyncf__init_A_init.Done() { A_arbace_a2g_dyncf__init_A_init.Run(A_arbace_a2g_dyncf__init_A_clinit) } }

func A_arbace_a2g_dyncf__init_A_clinit() { A_arbace_a2g_dyncf__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_409); A_arbace_a2g_dyncf__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27))); A_arbace_a2g_dyncf__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_a2g_dyncf__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_dyncf__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_25, Lit_30); A_arbace_a2g_dyncf__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_25, Lit_412); A_arbace_a2g_dyncf__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_414, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_25, Lit_32); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_415).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_dyncf__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_416).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_417).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_25, Lit_166); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_415).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_dyncf__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_418).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_25, Lit_46); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_415).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_dyncf__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_419).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_25, Lit_99); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_415).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_dyncf__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_420, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_25, Lit_124); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_415).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_dyncf__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_419).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_421, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_25, Lit_130); A_arbace_a2g_dyncf__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_422).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_423, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(101).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_25, Lit_424); A_arbace_a2g_dyncf__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_422).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_425, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(120).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_25, Lit_304); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_415).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_dyncf__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(331).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)); A_arbace_a2g_dyncf__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_25, Lit_426); A_arbace_a2g_dyncf__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_413).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_422).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_427, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Integer_ValueOf_I__Integer(334).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_410).Ref(), Lit_411)) }

func A_arbace_a2g_dyncf__init_A_New() *A_arbace_a2g_dyncf__init_A { A_arbace_a2g_dyncf__init_A_Init(); t := &A_arbace_a2g_dyncf__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_dyncf__init_A) Ctor() {}

func (t *A_arbace_a2g_dyncf__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_dyncf__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_dyncf__init_A_class }

func (t *A_arbace_a2g_dyncf__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_dyncf__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_dyncf__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_dyncf__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_dyncf__init_A); return ok }

func A_arbace_a2g_dyncf__init_A_Cast(x any) *A_arbace_a2g_dyncf__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_dyncf__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_dyncf__init_A_class)) }; return v }
