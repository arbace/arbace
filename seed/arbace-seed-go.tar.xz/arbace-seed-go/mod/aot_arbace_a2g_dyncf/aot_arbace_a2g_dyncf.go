//line aot_arbace_a2g_dyncf.ae:1
package aot_arbace_a2g_dyncf

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A_New() *A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_3, A_arbace_a2g_dyncf_A_const_4, A_arbace_a2g_dyncf_A_const_5, A_arbace_a2g_dyncf_A_const_6, A_arbace_a2g_dyncf_A_const_7, A_arbace_a2g_dyncf_A_const_8, A_arbace_a2g_dyncf_A_const_9, A_arbace_a2g_dyncf_A_const_10, A_arbace_a2g_dyncf_A_const_11); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A_New() *A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_16), A_arbace_a2g_dyncf_A_const_14.GetRawRoot__O(), A_arbace_a2g_dyncf_A_const_15) }



















func A_arbace_a2g_dyncf_enabled_QMARK__A_New() *A_arbace_a2g_dyncf_enabled_QMARK__A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_enabled_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_a2g_dyncf_enabled_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_a2g_dyncf_enabled_QMARK__A) Invoke_O__O(self any) any {


	return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_18.GetRawRoot__O())
}
func A_arbace_a2g_dyncf_tag_A_New() *A_arbace_a2g_dyncf_tag_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_tag_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_a2g_dyncf_tag_A) Ctor() {}
//line :26:1
func (t *A_arbace_a2g_dyncf_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(sym__0, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_dyncf_A_const_20, type__1))) }

func A_arbace_a2g_dyncf_native_name_A_New() *A_arbace_a2g_dyncf_native_name_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_native_name_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_a2g_dyncf_native_name_A) Ctor() {}
//line :28:1
func (t *A_arbace_a2g_dyncf_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_56, nil, Lit_57), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_18.GetRawRoot__O()), nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_23.GetRawRoot__O()).Invoke_O_O__O(mname__0, desc__1), nil)).Ref())
}








func A_arbace_a2g_dyncf_sub_name_A_New() *A_arbace_a2g_dyncf_sub_name_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_name_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_a2g_dyncf_sub_name_A) Ctor() {}
//line :39:1
func (t *A_arbace_a2g_dyncf_sub_name_A) Invoke_O_O__O(self, n__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_77, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(n__0))).Ref() }

func A_arbace_a2g_dyncf_from_object_A_New() *A_arbace_a2g_dyncf_from_object_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_from_object_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_a2g_dyncf_from_object_A) Ctor() {}
//line :41:1
func (t *A_arbace_a2g_dyncf_from_object_A) Invoke_O_O_O__O(self, d__0, x__1 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_24.GetRawRoot__O()).Invoke_O__O(d__0)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_dyncf_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_dyncf_A_const_30; return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_29, d__0), tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_31.GetRawRoot__O()).Invoke_O__O(d__0))).Ref()), x__1)) } else { if lang.Util_Equiv_O_O__Z(d__0, Lit_29) { return x__1 } else { if A_arbace_a2g_dyncf_A_const_26 != nil {


		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_dyncf_A_const_32; var tmp7 any = A_arbace_a2g_dyncf_A_const_33; return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp7, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_29, d__0)), x__1) } else {
//line :44:1
			return nil
		}
	}
	}
}
func A_arbace_a2g_dyncf_sub_forms_A_New() *A_arbace_a2g_dyncf_sub_forms_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_a2g_dyncf_sub_forms_A) Ctor() {}
//line :49:1
func (t *A_arbace_a2g_dyncf_sub_forms_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_dyncf_A_const_36; var recv__3 any = tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(g__2));




	lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_39, A_arbace_a2g_dyncf_A_const_40)); var tmp3 any; tmp42 := /*line :49:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_dyncf_A_const_41; var tmp6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref()); var tmp7 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_47, A_arbace_a2g_dyncf_A_const_48), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_49, A_arbace_a2g_dyncf_A_const_50)), A_arbace_a2g_dyncf_A_const_45); var tmp8 any; var tmp9 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_42.GetRawRoot__O()).Invoke_O__O(n__0)






		if jrt.A2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { tmp9 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_43.GetRawRoot__O()).Invoke_O__O(n__0) }; if jrt.A2g_Truth(tmp9) { tmp8 = A_arbace_a2g_dyncf_A_const_44 } else {

			tmp8 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_51.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_29, n__0, Lit_60)) }
//line :49:1
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_dyncf_A_const_52; var tmp12 any = A_arbace_a2g_dyncf_A_const_56; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp14 any = A_arbace_a2g_dyncf_A_const_57; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp16 any = A_arbace_a2g_dyncf_A_const_58; var tmp17 any = tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp10.Invoke_O_O_O_O_O__O(tmp11, lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O_O_O__O(tmp16, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(g__2), A_arbace_a2g_dyncf_A_const_59, A_arbace_a2g_dyncf_A_const_60))), A_arbace_a2g_dyncf_A_const_53, A_arbace_a2g_dyncf_A_const_54, A_arbace_a2g_dyncf_A_const_55)); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp19 any = A_arbace_a2g_dyncf_A_const_61; var tmp20 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref()), A_arbace_a2g_dyncf_A_const_63); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()); var tmp22 any = A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(); var tmp23 any = A_arbace_a2g_dyncf_A_const_64; var tmp24 any = A_arbace_a2g_dyncf_A_const_65; var tmp25 any; var iter__1927001039__auto____6 any; var tmp26 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A_New_O_O(recv__3, n__0); var tmp27 *jrt.Class
		var fncls__5 /*line :49:1*/*jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A_fn_class
















		if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A_fn_class = fncls__5d; tmp27 = fncls__5d } else { tmp27 = fncls__5 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var tmp28 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp29 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_42.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp29 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_104.GetRawRoot__O()).Invoke_O__O(n__0) } else { var tmp30 *lang.Keyword = A_arbace_a2g_dyncf_A_const_105; tmp29 = tmp30.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_106.GetRawRoot__O()).Invoke_O__O(n__0)) }; tmp25 = tmp28.Invoke_O__O(tmp29)
//line :49:1
		var tmp31 any = tmp18.Invoke_O_O_O__O(tmp19, tmp20, tmp21.Invoke_O_O_O_O__O(tmp22, tmp23, tmp24, tmp25)); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp33 any = A_arbace_a2g_dyncf_A_const_107; var tmp34 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref()), A_arbace_a2g_dyncf_A_const_108); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()); var tmp36 any = A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(); var tmp37 any = A_arbace_a2g_dyncf_A_const_109; var tmp38 any = A_arbace_a2g_dyncf_A_const_110; var tmp39 any; var iter__1927001039__auto____6_2 any; var tmp40 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A_New_O_O(recv__3, n__0); var tmp41 *jrt.Class
		var fncls__12 /*line :49:1*/*jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A_fn_class
































		if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A_fn_class = fncls__12d; tmp41 = fncls__12d } else { tmp41 = fncls__12 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); tmp39 = lang.IFn_Cast(iter__1927001039__auto____6_2).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_139.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_140.GetRawRoot__O()).Invoke_O__O(n__0)))
//line :49:1
		tmp3 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp17, tmp31, tmp32.Invoke_O_O_O__O(tmp33, tmp34, tmp35.Invoke_O_O_O_O__O(tmp36, tmp37, tmp38, tmp39))) }; return nil }();




	lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_35.GetRawRoot__O()).Invoke__O(); if /*line :49:1*/ tmp42 != nil { panic(tmp42) }; return tmp3 }
















func A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :66:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A) Invoke_O_O__O(self, s__1117000018__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A_New_O_O_O_O(t.F_recv, self, t.F_n, s__1117000018__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A) Ctor_O_O_O_O(c__recv, c__iter__1117000017, c__n, c__s__1117000018 any) { t.F_recv = c__recv; t.F_iter__1117000017 = c__iter__1117000017; t.F_n = c__n; t.F_s__1117000018 = c__s__1117000018 }
//line :66:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A) Invoke_O__O(self any) any { { var s__1117000018__1 any; var t_ any = t.F_s__1117000018; t.F_s__1117000018 = nil; s__1117000018__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000018__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000018__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000018__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000018__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000020__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A_New_O_O_O_I_O(b__1117000020__6, t.F_recv, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000017); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000020__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000018__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000020__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000018__3); var tmp4 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(Lit_46, A_arbace_a2g_dyncf_A_const_70.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_77.GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp4 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_72.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____6 } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :66:1
	if jrt.A2g_Truth(tmp4) { var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_42.GetRawRoot__O()).Invoke_O__O(t.F_n))

		if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else {
			var tmp6 *lang.Keyword = A_arbace_a2g_dyncf_A_const_80; tmp5 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_73.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_78.GetRawRoot__O()).Invoke_O_O__O(tmp6.Invoke_O__O(A_arbace_a2g_dyncf_A_const_81.Get__O()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(t.F_n)), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_79.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__4))) }
//line :66:1
		if jrt.A2g_Truth(tmp5) { var real__5 any



			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_42.GetRawRoot__O()).Invoke_O__O(t.F_n)) { real__5 = A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__4) } else { real__5 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t.F_n, mm__4) }
//line :66:1
			var vec__1117000033__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_76.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__4)); var ps__7 any = lang.RT_Nth_O_I_O__O(vec__1117000033__6, lang.RT_IntCast_J__I(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O(vec__1117000033__6, lang.RT_IntCast_J__I(1), nil); var vec__1117000036__9 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_76.GetRawRoot__O()).Invoke_O__O(real__5); var rps__10 any = lang.RT_Nth_O_I_O__O(vec__1117000036__9, lang.RT_IntCast_J__I(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O(vec__1117000036__9, lang.RT_IntCast_J__I(1), nil); _ = ___8; _ = ___11; if lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(ps__7)), int64(lang.RT_Count_O__I(rps__10))) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__4); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_dyncf_A_const_83; var tmp11 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_84, A_arbace_a2g_dyncf_A_const_85), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_86, A_arbace_a2g_dyncf_A_const_87)); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp13 any = A_arbace_a2g_dyncf_A_const_88; var tmp14 any = A_arbace_a2g_dyncf_A_const_89; var tmp15 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_90, t.F_recv, A_arbace_a2g_dyncf_A_const_91)); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()); var tmp17 any = A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(); var tmp18 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_79.GetRawRoot__O()).Invoke_O__O(real__5))).Ref()); var tmp19 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(t.F_n))).Ref()), A_arbace_a2g_dyncf_A_const_94); var tmp20 any = A_arbace_a2g_dyncf_A_const_92; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_93.GetRawRoot__O()); var tmp22 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A_New(); var tmp23 *jrt.Class
				var fncls__3 /*line :66:1*/*jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A_fn_class












				if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A_fn_class = fncls__3d; tmp23 = fncls__3d } else { tmp23 = fncls__3 }
//line :66:1
				var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__1117000017); return tmp7.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp11, tmp12.Invoke_O_O_O__O(tmp13, tmp15, tmp16.Invoke_O_O_O_O_O__O(tmp17, tmp18, tmp19, tmp20, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), ps__7))))), tmp24.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000018__3))) } else { s__1117000018__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000018__3); continue L1 } } else { s__1117000018__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000018__3); continue L1 } } else { s__1117000018__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000018__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :66:1
func A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :66:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A) Ctor_O_O_O_I_O(c__b__1117000020, c__recv, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1117000020 = c__b__1117000020; t.F_recv = c__recv; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A) Invoke_O__O(self any) any { { var i__1117000019__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000019__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000019__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(Lit_46, A_arbace_a2g_dyncf_A_const_70.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_77.GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp2 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_72.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :66:1
	if jrt.A2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_42.GetRawRoot__O()).Invoke_O__O(t.F_n))

		if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var tmp4 *lang.Keyword = A_arbace_a2g_dyncf_A_const_80; tmp3 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_73.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_78.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O__O(A_arbace_a2g_dyncf_A_const_81.Get__O()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(t.F_n)), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_79.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__2))) }
//line :66:1
		if jrt.A2g_Truth(tmp3) { var real__3 any



			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_42.GetRawRoot__O()).Invoke_O__O(t.F_n)) { real__3 = A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__2) } else { real__3 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t.F_n, mm__2) }
//line :66:1
			var vec__1117000024__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_76.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__2)); var ps__5 any = lang.RT_Nth_O_I_O__O(vec__1117000024__4, lang.RT_IntCast_J__I(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O(vec__1117000024__4, lang.RT_IntCast_J__I(1), nil); var vec__1117000027__7 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_76.GetRawRoot__O()).Invoke_O__O(real__3); var rps__8 any = lang.RT_Nth_O_I_O__O(vec__1117000027__7, lang.RT_IntCast_J__I(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O(vec__1117000027__7, lang.RT_IntCast_J__I(1), nil); _ = ___6; _ = ___9; if lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(ps__5)), int64(lang.RT_Count_O__I(rps__8))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp6 any = t.F_b__1117000020; var tmp7 any = A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__2); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_dyncf_A_const_83; var tmp10 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_84, A_arbace_a2g_dyncf_A_const_85), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_86, A_arbace_a2g_dyncf_A_const_87)); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_dyncf_A_const_88; var tmp13 any = A_arbace_a2g_dyncf_A_const_89; var tmp14 any = lang.Tuple_Create_O_O__IPersistentVector(tmp13, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_90, t.F_recv, A_arbace_a2g_dyncf_A_const_91)); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()); var tmp16 any = A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(); var tmp17 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_79.GetRawRoot__O()).Invoke_O__O(real__3))).Ref()); var tmp18 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(t.F_n))).Ref()), A_arbace_a2g_dyncf_A_const_94); var tmp19 any = A_arbace_a2g_dyncf_A_const_92; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_93.GetRawRoot__O()); var tmp21 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A_New(); var tmp22 *jrt.Class
				var fncls__1 /*line :66:1*/*jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A_fn_class












				if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A_fn_class = fncls__1d; tmp22 = fncls__1d } else { tmp22 = fncls__1 }
//line :66:1
				tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp14, tmp15.Invoke_O_O_O_O_O__O(tmp16, tmp17, tmp18, tmp19, tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), ps__5)))))); i__1117000019__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000019__1); continue L1 } else { i__1117000019__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000019__1); continue L1 } } else { i__1117000019__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000019__1); continue L1 } } else { i__1117000019__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000019__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }












func A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A_New() *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A) Ctor() {}
//line :79:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_95.GetRawRoot__O()).Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_96, A_arbace_a2g_dyncf_A_const_97, i__1)) }
//line :79:1
func A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A_New() *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A) Ctor() {}
//line :79:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_95.GetRawRoot__O()).Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_96, A_arbace_a2g_dyncf_A_const_97, i__1)) }


func A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :82:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :82:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A) Invoke_O_O__O(self, s__1117000044__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A_New_O_O_O_O(t.F_recv, t.F_n, s__1117000044__1, self); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :82:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A) Ctor_O_O_O_O(c__recv, c__n, c__s__1117000044, c__iter__1117000043 any) { t.F_recv = c__recv; t.F_n = c__n; t.F_s__1117000044 = c__s__1117000044; t.F_iter__1117000043 = c__iter__1117000043 }
//line :82:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A) Invoke_O__O(self any) any { { var s__1117000044__1 any; var t_ any = t.F_s__1117000044; t.F_s__1117000044 = nil; s__1117000044__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000044__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000044__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000044__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000044__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000046__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A_New_O_O_O_I_O(t.F_recv, b__1117000046__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000043); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000046__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000044__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000046__6), nil) } } else { var vec__1117000063__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000044__3); var vec__1117000066__5 any = lang.RT_Nth_O_I_O__O(vec__1117000063__4, lang.RT_IntCast_J__I(0), nil); var name__6 any = lang.RT_Nth_O_I_O__O(vec__1117000066__5, lang.RT_IntCast_J__I(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O(vec__1117000066__5, lang.RT_IntCast_J__I(1), nil); var k__8 any = vec__1117000066__5; var ___9 any = lang.RT_Nth_O_I_O__O(vec__1117000063__4, lang.RT_IntCast_J__I(1), nil); _ = ___9; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_72.GetRawRoot__O()).Invoke_O__O(desc__7)) { var impl__10 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_111.GetRawRoot__O()).Invoke_O_O__O(t.F_n, k__8); var base__11 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_23.GetRawRoot__O()).Invoke_O_O__O(name__6, desc__7); var vec__1117000069__12 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_76.GetRawRoot__O()).Invoke_O__O(desc__7); var ps__13 any = lang.RT_Nth_O_I_O__O(vec__1117000069__12, lang.RT_IntCast_J__I(0), nil); var r__14 any = lang.RT_Nth_O_I_O__O(vec__1117000069__12, lang.RT_IntCast_J__I(1), nil); var pn__15 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_93.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A_New(); var tmp6 *jrt.Class
														var fncls__10 /*line :82:1*/*jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A_fn_class




	if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A_fn_class = fncls__10d; tmp6 = fncls__10d } else { tmp6 = fncls__10 }; pn__15 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ps__13)
//line :82:1
	var call__16 any; var G__1117000074__16_ any = A_arbace_a2g_dyncf_A_const_112.Invoke_O__O(impl__10)





L2: switch { default: switch lang.Util_Hash_O__I(G__1117000074__16_) >> 4 & 3 { case 0: if any(G__1117000074__16_) == any(A_arbace_a2g_dyncf_A_const_113) {

	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_51.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_dyncf_A_const_29; call__16 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), tmp7.Invoke_O_O_O__O(tmp8, A_arbace_a2g_dyncf_A_const_120.Invoke_O__O(impl__10), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref()), A_arbace_a2g_dyncf_A_const_119, pn__15)
//line :88:1
	break L2 }; case 1: if any(G__1117000074__16_) == any(A_arbace_a2g_dyncf_A_const_114) {
		call__16 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref()), A_arbace_a2g_dyncf_A_const_121, A_arbace_a2g_dyncf_A_const_122, pn__15)
//line :88:1
		break L2 }; case 2: if any(G__1117000074__16_) == any(A_arbace_a2g_dyncf_A_const_115) {
			call__16 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref()), A_arbace_a2g_dyncf_A_const_121, A_arbace_a2g_dyncf_A_const_122, pn__15)
//line :88:1
			break L2 }; case 3: if any(G__1117000074__16_) == any(A_arbace_a2g_dyncf_A_const_116) {


				call__16 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(t.F_n))).Ref()), A_arbace_a2g_dyncf_A_const_123), pn__15)
//line :88:1
				break L2 }; default:}; call__16 = nil}
//line :82:1
	if jrt.A2g_Truth(call__16) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()); var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__6, desc__7)).Ref(); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_dyncf_A_const_124; var tmp13 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_126, A_arbace_a2g_dyncf_A_const_127), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_128, A_arbace_a2g_dyncf_A_const_129)), A_arbace_a2g_dyncf_A_const_138); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp15 any = A_arbace_a2g_dyncf_A_const_130; var tmp16 any = A_arbace_a2g_dyncf_A_const_131; var tmp17 any = lang.Tuple_Create_O_O__IPersistentVector(tmp16, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_132, t.F_recv, A_arbace_a2g_dyncf_A_const_133)); var tmp18 any














		if lang.Util_Equiv_O_O__Z(Lit_75, r__14) {
			tmp18 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_134, call__16, A_arbace_a2g_dyncf_A_const_135) } else {
				var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp20 any = A_arbace_a2g_dyncf_A_const_136; tmp18 = tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_137, call__16)) }
//line :82:1
		var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1117000043); return tmp9.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp17, tmp18))), tmp21.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000044__3))) } else { s__1117000044__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000044__3); continue L1 } } else { s__1117000044__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000044__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :82:1
func A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :82:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A) Ctor_O_O_O_I_O(c__recv, c__b__1117000046, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_b__1117000046 = c__b__1117000046; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :82:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A) Invoke_O__O(self any) any { { var i__1117000045__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1117000050__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000045__1)); var vec__1117000053__3 any = lang.RT_Nth_O_I_O__O(vec__1117000050__2, lang.RT_IntCast_J__I(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O(vec__1117000053__3, lang.RT_IntCast_J__I(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__1117000053__3, lang.RT_IntCast_J__I(1), nil); var k__6 any = vec__1117000053__3; var ___7 any = lang.RT_Nth_O_I_O__O(vec__1117000050__2, lang.RT_IntCast_J__I(1), nil); _ = ___7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_72.GetRawRoot__O()).Invoke_O__O(desc__5)) { var impl__8 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_111.GetRawRoot__O()).Invoke_O_O__O(t.F_n, k__6); var base__9 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_23.GetRawRoot__O()).Invoke_O_O__O(name__4, desc__5); var vec__1117000056__10 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_76.GetRawRoot__O()).Invoke_O__O(desc__5); var ps__11 any = lang.RT_Nth_O_I_O__O(vec__1117000056__10, lang.RT_IntCast_J__I(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O(vec__1117000056__10, lang.RT_IntCast_J__I(1), nil); var pn__13 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_93.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A_New(); var tmp4 *jrt.Class
																var fncls__7 /*line :82:1*/*jrt.Class = A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A_fn_class




	if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; pn__13 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ps__11)
//line :82:1
	var call__14 any; var G__1117000061__14_ any = A_arbace_a2g_dyncf_A_const_112.Invoke_O__O(impl__8)





L2: switch { default: switch lang.Util_Hash_O__I(G__1117000061__14_) >> 4 & 3 { case 0: if any(G__1117000061__14_) == any(A_arbace_a2g_dyncf_A_const_113) {

	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_51.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_dyncf_A_const_29; call__14 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), tmp5.Invoke_O_O_O__O(tmp6, A_arbace_a2g_dyncf_A_const_120.Invoke_O__O(impl__8), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref()), A_arbace_a2g_dyncf_A_const_119, pn__13)
//line :88:1
	break L2 }; case 1: if any(G__1117000061__14_) == any(A_arbace_a2g_dyncf_A_const_114) {
		call__14 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref()), A_arbace_a2g_dyncf_A_const_121, A_arbace_a2g_dyncf_A_const_122, pn__13)
//line :88:1
		break L2 }; case 2: if any(G__1117000061__14_) == any(A_arbace_a2g_dyncf_A_const_115) {
			call__14 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref()), A_arbace_a2g_dyncf_A_const_121, A_arbace_a2g_dyncf_A_const_122, pn__13)
//line :88:1
			break L2 }; case 3: if any(G__1117000061__14_) == any(A_arbace_a2g_dyncf_A_const_116) {


				call__14 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__9)).Ref()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_22.GetRawRoot__O()).Invoke_O__O(t.F_n))).Ref()), A_arbace_a2g_dyncf_A_const_123), pn__13)
//line :88:1
				break L2 }; default:}; call__14 = nil}
//line :82:1
	if jrt.A2g_Truth(call__14) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp8 any = t.F_b__1117000046; var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, name__4, desc__5)).Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_dyncf_A_const_124; var tmp12 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_126, A_arbace_a2g_dyncf_A_const_127), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_128, A_arbace_a2g_dyncf_A_const_129)), A_arbace_a2g_dyncf_A_const_125); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp14 any = A_arbace_a2g_dyncf_A_const_130; var tmp15 any = A_arbace_a2g_dyncf_A_const_131; var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_132, t.F_recv, A_arbace_a2g_dyncf_A_const_133)); var tmp17 any














		if lang.Util_Equiv_O_O__Z(Lit_75, r__12) {
			tmp17 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_134, call__14, A_arbace_a2g_dyncf_A_const_135) } else {
				var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp19 any = A_arbace_a2g_dyncf_A_const_136; tmp17 = tmp18.Invoke_O_O__O(tmp19, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_137, call__14)) }
//line :82:1
		tmp7.Invoke_O_O__O(tmp8, lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp16, tmp17)))); i__1117000045__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000045__1); continue L1 } else { i__1117000045__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000045__1); continue L1 } } else { i__1117000045__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000045__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A_New() *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A) Ctor() {}
//line :87:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_95.GetRawRoot__O()).Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_117, A_arbace_a2g_dyncf_A_const_118, i__1)) }
//line :87:1
func A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A_New() *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A) Ctor() {}
//line :87:1
func (t *A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_95.GetRawRoot__O()).Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_117, A_arbace_a2g_dyncf_A_const_118, i__1)) }













func A_arbace_a2g_dyncf_subs_forms_A_New() *A_arbace_a2g_dyncf_subs_forms_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_subs_forms_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_a2g_dyncf_subs_forms_A) Ctor() {}
//line :101:1
func (t *A_arbace_a2g_dyncf_subs_forms_A) Invoke_O_O__O(self, T__0_ any) any { var cs__2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_141.GetRawRoot__O()).Invoke_O__O(T__0_); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_142.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_144.GetRawRoot__O(), cs__2); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_dyncf_A_const_145; var tmp5 any = A_arbace_a2g_dyncf_A_const_146; var tmp6 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_150, A_arbace_a2g_dyncf_A_const_151)); var tmp7 any = A_arbace_a2g_dyncf_A_const_147; var tmp8 any = A_arbace_a2g_dyncf_A_const_148; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_62.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O(); var tmp11 any = A_arbace_a2g_dyncf_A_const_152; var tmp12 any = A_arbace_a2g_dyncf_A_const_153; var tmp13 any; var iter__1927001039__auto____3 any; var tmp14 any = A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A_New(); var tmp15 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A_fn_class; if












	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A_fn_class = fncls__15d; tmp15 = fncls__15d } else { tmp15 = fncls__15 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); tmp13 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(cs__2); return /*line :105:1*/ tmp1.Invoke_O_O__O(tmp2, lang.Tuple_Create_O__IPersistentVector(tmp3.Invoke_O_O_O_O_O_O_O_O__O(tmp4, tmp5, Lit_78, tmp6, tmp7, tmp8, tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, tmp12, tmp13), A_arbace_a2g_dyncf_A_const_149))) }








func A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A_New() *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A) Ctor() {}
//line :114:1
func (t *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A) Invoke_O_O__O(self, s__1117000079__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A_New_O_O(s__1117000079__1, self); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A) Ctor_O_O(c__s__1117000079, c__iter__1117000078 any) { t.F_s__1117000079 = c__s__1117000079; t.F_iter__1117000078 = c__iter__1117000078 }
//line :114:1
func (t *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A) Invoke_O__O(self any) any { { var s__1117000079__1 any; var t_ any = t.F_s__1117000079; t.F_s__1117000079 = nil; s__1117000079__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000079__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000079__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000079__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000079__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000081__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A_New_O_I_O(b__1117000081__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000078); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000081__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000079__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000081__6), nil) } } else { var p__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000079__3); var g__5 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_34.GetRawRoot__O()).Invoke_O__O(p__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_dyncf_A_const_154; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_dyncf_A_const_155; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1117000078); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_51.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_29, p__4, Lit_82)), tmp6.Invoke_O_O_O_O__O(tmp7, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__5)).Ref()))), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000079__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :114:1
func A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A) Ctor_O_I_O(c__b__1117000081 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1117000081 = c__b__1117000081; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A) Invoke_O__O(self any) any { { var i__1117000080__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000080__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000080__1)); var g__3 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_34.GetRawRoot__O()).Invoke_O__O(p__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp3 any = t.F_b__1117000081; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_dyncf_A_const_154; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_dyncf_A_const_155; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_51.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_dyncf_A_const_29, p__2, Lit_82)), tmp6.Invoke_O_O_O_O__O(tmp7, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref())))); i__1117000080__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000080__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_dyncf_forms_A_New() *A_arbace_a2g_dyncf_forms_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_forms_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_a2g_dyncf_forms_A) Ctor() {}
//line :120:1
func (t *A_arbace_a2g_dyncf_forms_A) Invoke_O_O__O(self, T__0_ any) any {


	var tmp1 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_161, Lit_1); var tmp2 any = A_arbace_a2g_dyncf_A_const_157; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_dyncf_A_const_162; var tmp5 any = tmp3.Invoke_O_O_O_O__O(tmp4, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_2, Lit_3), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_166, A_arbace_a2g_dyncf_A_const_167), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_168, A_arbace_a2g_dyncf_A_const_169), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_170, A_arbace_a2g_dyncf_A_const_171), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_172, A_arbace_a2g_dyncf_A_const_173), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_174, A_arbace_a2g_dyncf_A_const_175), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_176, A_arbace_a2g_dyncf_A_const_177)), A_arbace_a2g_dyncf_A_const_165), A_arbace_a2g_dyncf_A_const_164); var tmp6 any = A_arbace_a2g_dyncf_A_const_158; var tmp7 any = A_arbace_a2g_dyncf_A_const_159; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_dyncf_A_const_178; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_dyncf_A_const_185; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp13 any = A_arbace_a2g_dyncf_A_const_190; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp15 any = A_arbace_a2g_dyncf_A_const_200; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp17 any = A_arbace_a2g_dyncf_A_const_211; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp19 any = A_arbace_a2g_dyncf_A_const_219; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp21 any = A_arbace_a2g_dyncf_A_const_223; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp23 any = A_arbace_a2g_dyncf_A_const_229; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp25 any = A_arbace_a2g_dyncf_A_const_234; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp27 any = A_arbace_a2g_dyncf_A_const_248; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp29 any = A_arbace_a2g_dyncf_A_const_258; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_25.GetRawRoot__O()); var tmp31 any = A_arbace_a2g_dyncf_A_const_270; return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_156.GetRawRoot__O()).Invoke_O__O(T__0_), lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp5, tmp6, tmp7, tmp8.Invoke_O_O_O_O__O(tmp9, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_4, Lit_5), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_181, A_arbace_a2g_dyncf_A_const_182), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_183, A_arbace_a2g_dyncf_A_const_184)), A_arbace_a2g_dyncf_A_const_180), A_arbace_a2g_dyncf_A_const_179), tmp10.Invoke_O_O_O_O__O(tmp11, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_6, Lit_7), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_188, A_arbace_a2g_dyncf_A_const_189)), A_arbace_a2g_dyncf_A_const_187), A_arbace_a2g_dyncf_A_const_186), tmp12.Invoke_O_O_O_O__O(tmp13, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_8, Lit_9), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_192, A_arbace_a2g_dyncf_A_const_193), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_194, A_arbace_a2g_dyncf_A_const_195), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_196, A_arbace_a2g_dyncf_A_const_197), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_198, A_arbace_a2g_dyncf_A_const_199)), A_arbace_a2g_dyncf_A_const_191), tmp14.Invoke_O_O_O_O__O(tmp15, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_10, Lit_11), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_203, A_arbace_a2g_dyncf_A_const_204), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_205, A_arbace_a2g_dyncf_A_const_206), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_207, A_arbace_a2g_dyncf_A_const_208), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_209, A_arbace_a2g_dyncf_A_const_210)), A_arbace_a2g_dyncf_A_const_202), A_arbace_a2g_dyncf_A_const_201), tmp16.Invoke_O_O_O_O__O(tmp17, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_12, Lit_13), lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_213, A_arbace_a2g_dyncf_A_const_214), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_215, A_arbace_a2g_dyncf_A_const_216), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_217, A_arbace_a2g_dyncf_A_const_218)), A_arbace_a2g_dyncf_A_const_212), tmp18.Invoke_O_O_O_O__O(tmp19, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_14, Lit_15), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_221, A_arbace_a2g_dyncf_A_const_222)), A_arbace_a2g_dyncf_A_const_220), tmp20.Invoke_O_O_O_O__O(tmp21, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_16, Lit_17), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_225, A_arbace_a2g_dyncf_A_const_226), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_227, A_arbace_a2g_dyncf_A_const_228)), A_arbace_a2g_dyncf_A_const_224), tmp22.Invoke_O_O_O_O__O(tmp23, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_18, Lit_19), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_232, A_arbace_a2g_dyncf_A_const_233)), A_arbace_a2g_dyncf_A_const_231), A_arbace_a2g_dyncf_A_const_230), tmp24.Invoke_O_O_O_O__O(tmp25, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_20, Lit_21), lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_236, A_arbace_a2g_dyncf_A_const_237), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_238, A_arbace_a2g_dyncf_A_const_239), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_240, A_arbace_a2g_dyncf_A_const_241), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_242, A_arbace_a2g_dyncf_A_const_243), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_244, A_arbace_a2g_dyncf_A_const_245), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_246, A_arbace_a2g_dyncf_A_const_247)), A_arbace_a2g_dyncf_A_const_235), tmp26.Invoke_O_O_O_O__O(tmp27, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_22, Lit_23), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_250, A_arbace_a2g_dyncf_A_const_251), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_252, A_arbace_a2g_dyncf_A_const_253), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_254, A_arbace_a2g_dyncf_A_const_255), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_256, A_arbace_a2g_dyncf_A_const_257)), A_arbace_a2g_dyncf_A_const_249), tmp28.Invoke_O_O_O_O__O(tmp29, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_24, Lit_25), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_260, A_arbace_a2g_dyncf_A_const_261), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_262, A_arbace_a2g_dyncf_A_const_263), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_264, A_arbace_a2g_dyncf_A_const_265), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_266, A_arbace_a2g_dyncf_A_const_267), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_268, A_arbace_a2g_dyncf_A_const_269)), A_arbace_a2g_dyncf_A_const_259), tmp30.Invoke_O_O_O_O__O(tmp31, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_163.GetRawRoot__O()).Invoke_O_O__O(Lit_26, Lit_27), lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_272, A_arbace_a2g_dyncf_A_const_273), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_274, A_arbace_a2g_dyncf_A_const_275), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_276, A_arbace_a2g_dyncf_A_const_277), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_278, A_arbace_a2g_dyncf_A_const_279), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_280, A_arbace_a2g_dyncf_A_const_281), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_282, A_arbace_a2g_dyncf_A_const_283), lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_284, A_arbace_a2g_dyncf_A_const_285))), A_arbace_a2g_dyncf_A_const_271), A_arbace_a2g_dyncf_A_const_160)))
}














































































































































































































func A_arbace_a2g_dyncf_strip_anns_A_New() *A_arbace_a2g_dyncf_strip_anns_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_strip_anns_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_a2g_dyncf_strip_anns_A) Ctor() {}
//line :331:1
func (t *A_arbace_a2g_dyncf_strip_anns_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_286.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), x__0) }
//line :332:1
func A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A_New() *A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A) Ctor() {}
//line :332:1
func (t *A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A) Invoke_O_O__O(self, y__1 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_287.GetRawRoot__O()).Invoke_O__O(y__1); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = A_arbace_a2g_dyncf_A_const_288.Invoke_O__O(y__1) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_289.GetRawRoot__O()).Invoke_O_O__O(y__1, A_arbace_a2g_dyncf_A_const_288) } else { return y__1 } }

func A_arbace_a2g_dyncf_generics_text_A_New() *A_arbace_a2g_dyncf_generics_text_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_a2g_dyncf_generics_text_A) Ctor() {}
//line :334:1
func (t *A_arbace_a2g_dyncf_generics_text_A) Invoke_O_O__O(self, T__0_ any) any { var extendable__2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_290.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_142.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_315.GetRawRoot__O(), A_arbace_a2g_dyncf_A_const_316)); var entries__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A_New_O(extendable__2); var tmp2 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A_fn_class; if






	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A_fn_class = fncls__33d; tmp2 = fncls__33d } else { tmp2 = fncls__33 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); entries__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_317.GetRawRoot__O()).Invoke_O__O(T__0_)); var tmp3 lang.IFn =




















	lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_37.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_38.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_dyncf_A_const_318; var tmp6 any = A_arbace_a2g_dyncf_A_const_319; var tmp7 any = A_arbace_a2g_dyncf_A_const_320; var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; tmp3.Invoke_O__O(tmp4.Invoke_O_O_O_O_O_O__O(tmp5, nil, tmp6, nil, tmp7, tmp8.Ref())); var tmp9 any; tmp15 := /*line :334:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




























		{ var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, Lit_32, nil, Lit_33); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_314.GetRawRoot__O()); var tmp12 any; var iter__1927001039__auto____10 any; var tmp13 any = A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A_New(); var tmp14 *jrt.Class
			var fncls__36 /*line :363:1*/*jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A_fn_class

			if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A_fn_class = fncls__36d; tmp14 = fncls__36d } else { tmp14 = fncls__36 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); tmp12 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(entries__3)
//line :363:1
			tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, nil, tmp11.Invoke_O_O__O(Lit_34, tmp12), nil)).Ref() }
//line :334:1
		return nil }();



























	lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_35.GetRawRoot__O()).Invoke__O(); if /*line :334:1*/ tmp15 != nil { panic(tmp15) }; return tmp9 }






func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A_New_O(p0 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A{}; t.Ctor_O(p0); return t }
//line :341:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A) Ctor_O(c__extendable any) { t.F_extendable = c__extendable }
//line :341:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A) Invoke_O_O__O(self, s__1117000094__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A_New_O_O_O(t.F_extendable, s__1117000094__1, self); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :341:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :341:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A) Ctor_O_O_O(c__extendable, c__s__1117000094, c__iter__1117000093 any) { t.F_extendable = c__extendable; t.F_s__1117000094 = c__s__1117000094; t.F_iter__1117000093 = c__iter__1117000093 }
//line :341:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A) Invoke_O__O(self any) any { { var s__1117000094__1 any; var t_ any = t.F_s__1117000094; t.F_s__1117000094 = nil; s__1117000094__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000094__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000094__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000094__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000094__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000096__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A_New_O_I_O_O(t.F_extendable, size__1927001038__auto____5, c__1927001037__auto____4, b__1117000096__6); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000093); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000096__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000094__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000096__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000094__3); var d__5 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_106.GetRawRoot__O()).Invoke_O__O(n__4); var tmp4 any
															var and__1927000168__auto____6 any = d__5


	if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_311); var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_a2g_dyncf_A_const_298.Invoke_O__O(d__5))); if jrt.A2g_Truth(and__1927000168__auto____7) { var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_291.GetRawRoot__O()).Invoke_O__O(n__4)
		if jrt.A2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { tmp4 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__4) } } else {
//line :345:1
			tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }
//line :341:1
	if jrt.A2g_Truth(tmp4) { var g__6 any; var tmp6 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A_New_O(n__4); var tmp7 *jrt.Class
		var fncls__25 /*line :341:1*/*jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A_fn_class





		if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A_fn_class = fncls__25d; tmp7 = fncls__25d } else { tmp7 = fncls__25 }; g__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :341:1
		if jrt.A2g_Truth(g__6) { var generic_QMARK___7 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_299.Invoke_O__O(g__6)); var supers__8 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_300.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_301.GetRawRoot__O(), A_arbace_a2g_dyncf_A_const_302.Invoke_O__O(g__6))); var abstract_QMARK___9 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_291.GetRawRoot__O()).Invoke_O__O(n__4))









			if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp8 any; var or__1927000174__auto____10 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(d__5); if jrt.A2g_Truth(or__1927000174__auto____10) { tmp8 = or__1927000174__auto____10 } else { tmp8 = A_arbace_a2g_dyncf_A_const_295 }; abstract_QMARK___9 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.Numbers_And_O_J__J(tmp8, 1024))).Ref() } else { abstract_QMARK___9 = and__1927000168__auto____9 }
//line :341:1
			var tmp9 any
			var or__1927000174__auto____10_2 any = generic_QMARK___7









			if jrt.A2g_Truth(or__1927000174__auto____10_2) { tmp9 = or__1927000174__auto____10_2 } else { var or__1927000174__auto____11 any = abstract_QMARK___9; if jrt.A2g_Truth(or__1927000174__auto____11) { tmp9 = or__1927000174__auto____11 } else { tmp9 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_296.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_303.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O(), A_arbace_a2g_dyncf_A_const_304), supers__8) } }
//line :341:1
			if jrt.A2g_Truth(tmp9) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_305.GetRawRoot__O()); var tmp12 any; var tmp13 any = A_arbace_a2g_dyncf_A_const_299; var G__1117000126__10_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_299.Invoke_O__O(g__6)), A_arbace_a2g_dyncf_A_const_302, supers__8)); var G__1117000126__11_ any












				if jrt.A2g_Truth(abstract_QMARK___9) {
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_306.GetRawRoot__O()); var tmp15 any = A_arbace_a2g_dyncf_A_const_307; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()); var tmp17 any; var iter__1927001039__auto____11 any; var tmp18 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A_New(); var tmp19 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A_fn_class = fncls__28d; tmp19 = fncls__28d } else { tmp19 = fncls__28 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); tmp17 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_a2g_dyncf_A_const_105.Invoke_O__O(d__5)); G__1117000126__11_ = tmp14.Invoke_O_O_O__O(G__1117000126__10_, tmp15, tmp16.Invoke_O__O(tmp17)) } else {
//line :354:1
						G__1117000126__11_ = G__1117000126__10_ }; if jrt.A2g_Truth(generic_QMARK___7) {




							var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_306.GetRawRoot__O()); var tmp21 any = A_arbace_a2g_dyncf_A_const_105; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()); var tmp23 any; var iter__1927001039__auto____12 any; var tmp24 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A_New(); var tmp25 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A_fn_class = fncls__31d; tmp25 = fncls__31d } else { tmp25 = fncls__31 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); tmp23 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_a2g_dyncf_A_const_105.Invoke_O__O(g__6)); tmp12 = tmp20.Invoke_O_O_O__O(G__1117000126__11_, tmp21, tmp22.Invoke_O__O(tmp23)) } else {
//line :354:1
								tmp12 = G__1117000126__11_ }
//line :341:1
				var tmp26 lang.IFn = lang.IFn_Cast(t.F_iter__1117000093); return tmp10.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp11.Invoke_O__O(tmp12)), tmp26.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000094__3))) } else { s__1117000094__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000094__3); continue L1 } } else { s__1117000094__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000094__3); continue L1 } } else { s__1117000094__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000094__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :341:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :341:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A) Ctor_O_I_O_O(c__extendable any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1117000096 any) { t.F_extendable = c__extendable; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1117000096 = c__b__1117000096 }
//line :341:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A) Invoke_O__O(self any) any { { var i__1117000095__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000095__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000095__1)); var d__3 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_106.GetRawRoot__O()).Invoke_O__O(n__2); var tmp2 any
																	var and__1927000168__auto____4 any = d__3


	if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_297); var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_a2g_dyncf_A_const_298.Invoke_O__O(d__3))); if jrt.A2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_291.GetRawRoot__O()).Invoke_O__O(n__2)
		if jrt.A2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = lang.IFn_Cast(t.F_extendable).Invoke_O__O(n__2) } } else {
//line :345:1
			tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }
//line :341:1
	if jrt.A2g_Truth(tmp2) { var g__4 any; var tmp4 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A_New_O(n__2); var tmp5 *jrt.Class
		var fncls__17 /*line :341:1*/*jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A_fn_class





		if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A_fn_class = fncls__17d; tmp5 = fncls__17d } else { tmp5 = fncls__17 }; g__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :341:1
		if jrt.A2g_Truth(g__4) { var generic_QMARK___5 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_299.Invoke_O__O(g__4)); var supers__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_300.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_301.GetRawRoot__O(), A_arbace_a2g_dyncf_A_const_302.Invoke_O__O(g__4))); var abstract_QMARK___7 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_291.GetRawRoot__O()).Invoke_O__O(n__2))









			if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp6 any; var or__1927000174__auto____8 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(d__3); if jrt.A2g_Truth(or__1927000174__auto____8) { tmp6 = or__1927000174__auto____8 } else { tmp6 = A_arbace_a2g_dyncf_A_const_295 }; abstract_QMARK___7 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.Numbers_And_O_J__J(tmp6, 1024))).Ref() } else { abstract_QMARK___7 = and__1927000168__auto____7 }
//line :341:1
			var tmp7 any
			var or__1927000174__auto____8_2 any = generic_QMARK___5









			if jrt.A2g_Truth(or__1927000174__auto____8_2) { tmp7 = or__1927000174__auto____8_2 } else { var or__1927000174__auto____9 any = abstract_QMARK___7; if jrt.A2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_296.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_303.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O(), A_arbace_a2g_dyncf_A_const_304), supers__6) } }
//line :341:1
			if jrt.A2g_Truth(tmp7) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp9 any = t.F_b__1117000096; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_305.GetRawRoot__O()); var tmp11 any; var tmp12 any = A_arbace_a2g_dyncf_A_const_299; var G__1117000102__8_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyncf_A_const_299.Invoke_O__O(g__4)), A_arbace_a2g_dyncf_A_const_302, supers__6)); var G__1117000102__9_ any












				if jrt.A2g_Truth(abstract_QMARK___7) {
					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_306.GetRawRoot__O()); var tmp14 any = A_arbace_a2g_dyncf_A_const_307; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()); var tmp16 any; var iter__1927001039__auto____9 any; var tmp17 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A_New(); var tmp18 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A_fn_class = fncls__20d; tmp18 = fncls__20d } else { tmp18 = fncls__20 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_a2g_dyncf_A_const_105.Invoke_O__O(d__3)); G__1117000102__9_ = tmp13.Invoke_O_O_O__O(G__1117000102__8_, tmp14, tmp15.Invoke_O__O(tmp16)) } else {
//line :354:1
						G__1117000102__9_ = G__1117000102__8_ }; if jrt.A2g_Truth(generic_QMARK___5) {




							var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_306.GetRawRoot__O()); var tmp20 any = A_arbace_a2g_dyncf_A_const_105; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_293.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____10 any; var tmp23 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A_New(); var tmp24 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A_fn_class = fncls__23d; tmp24 = fncls__23d } else { tmp24 = fncls__23 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_a2g_dyncf_A_const_105.Invoke_O__O(g__4)); tmp11 = tmp19.Invoke_O_O_O__O(G__1117000102__9_, tmp20, tmp21.Invoke_O__O(tmp22)) } else {
//line :354:1
								tmp11 = G__1117000102__9_ }
//line :341:1
				tmp8.Invoke_O_O__O(tmp9, lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp10.Invoke_O__O(tmp11))); i__1117000095__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000095__1); continue L1 } else { i__1117000095__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000095__1); continue L1 } } else { i__1117000095__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000095__1); continue L1 } } else { i__1117000095__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000095__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A_New_O(p0 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :347:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_a2g_dyncf_A_const_292; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :347:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A_New_O(p0 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :347:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = A_arbace_a2g_dyncf_A_const_292; var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A_New() *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A) Ctor() {}
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A) Invoke_O_O__O(self, s__1117000104__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A_New_O_O(self, s__1117000104__1); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :355:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A{}; t.Ctor_O_O(p0, p1); return t }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A) Ctor_O_O(c__iter__1117000103, c__s__1117000104 any) { t.F_iter__1117000103 = c__iter__1117000103; t.F_s__1117000104 = c__s__1117000104 }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A) Invoke_O__O(self any) any { { var s__1117000104__1 any; var t_ any = t.F_s__1117000104; t.F_s__1117000104 = nil; s__1117000104__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000104__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000104__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000104__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000104__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000106__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A_New_O_I_O(b__1117000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000103); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000106__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000104__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000106__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000104__3); if lang.Util_Equiv_O_O__Z(Lit_46, A_arbace_a2g_dyncf_A_const_70.Invoke_O__O(mm__4)) { var tmp4 any; var or__1927000174__auto____5 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__4)

	if jrt.A2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = A_arbace_a2g_dyncf_A_const_295 }
//line :355:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp4, 4098)) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1117000103); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__4), A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000104__3))) } else { s__1117000104__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000104__3); continue L1 } } else { s__1117000104__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000104__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :355:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A) Ctor_O_I_O(c__b__1117000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1117000106 = c__b__1117000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A) Invoke_O__O(self any) any { { var i__1117000105__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000105__1)); if lang.Util_Equiv_O_O__Z(Lit_46, A_arbace_a2g_dyncf_A_const_70.Invoke_O__O(mm__2)) { var tmp2 any; var or__1927000174__auto____3 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__2)

	if jrt.A2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = A_arbace_a2g_dyncf_A_const_295 }
//line :355:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp2, 4098)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp4 any = t.F_b__1117000106; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__2), A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__2))); i__1117000105__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000105__1); continue L1 } else { i__1117000105__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000105__1); continue L1 } } else { i__1117000105__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000105__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
//line :355:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A_New() *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A) Ctor() {}
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A) Invoke_O_O__O(self, s__1117000128__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A_New_O_O(self, s__1117000128__1); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :355:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A{}; t.Ctor_O_O(p0, p1); return t }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A) Ctor_O_O(c__iter__1117000127, c__s__1117000128 any) { t.F_iter__1117000127 = c__iter__1117000127; t.F_s__1117000128 = c__s__1117000128 }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A) Invoke_O__O(self any) any { { var s__1117000128__1 any; var t_ any = t.F_s__1117000128; t.F_s__1117000128 = nil; s__1117000128__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000128__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000128__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000128__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000128__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000130__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A_New_O_I_O(b__1117000130__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000127); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000130__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000128__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000130__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000128__3); if lang.Util_Equiv_O_O__Z(Lit_46, A_arbace_a2g_dyncf_A_const_70.Invoke_O__O(mm__4)) { var tmp4 any; var or__1927000174__auto____5 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__4)

	if jrt.A2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = A_arbace_a2g_dyncf_A_const_295 }
//line :355:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp4, 4098)) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1117000127); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__4), A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000128__3))) } else { s__1117000128__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000128__3); continue L1 } } else { s__1117000128__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000128__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :355:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A) Ctor_O_I_O(c__b__1117000130 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1117000130 = c__b__1117000130; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :355:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A) Invoke_O__O(self any) any { { var i__1117000129__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000129__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000129__1)); if lang.Util_Equiv_O_O__Z(Lit_46, A_arbace_a2g_dyncf_A_const_70.Invoke_O__O(mm__2)) { var tmp2 any; var or__1927000174__auto____3 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__2)

	if jrt.A2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = A_arbace_a2g_dyncf_A_const_295 }
//line :355:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp2, 4098)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp4 any = t.F_b__1117000130; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_dyncf_A_const_74.Invoke_O__O(mm__2), A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__2))); i__1117000129__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000129__1); continue L1 } else { i__1117000129__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000129__1); continue L1 } } else { i__1117000129__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000129__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A_New() *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A) Ctor() {}
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A) Invoke_O_O__O(self, s__1117000114__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A_New_O_O(self, s__1117000114__1); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :359:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A) Ctor_O_O(c__iter__1117000113, c__s__1117000114 any) { t.F_iter__1117000113 = c__iter__1117000113; t.F_s__1117000114 = c__s__1117000114 }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A) Invoke_O__O(self any) any { { var s__1117000114__1 any; var t_ any = t.F_s__1117000114; t.F_s__1117000114 = nil; s__1117000114__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000114__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000114__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000114__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000114__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000116__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A_New_O_I_O(b__1117000116__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000113); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000116__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000114__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000116__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000114__3); var tmp4 any; var or__1927000174__auto____5 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__4)
																						if jrt.A2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = A_arbace_a2g_dyncf_A_const_295 }
//line :359:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp4, 4098)) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1117000113); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_308.GetRawRoot__O()).Invoke_O_O__O(mm__4, A_arbace_a2g_dyncf_A_const_310), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000114__3))) } else { s__1117000114__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000114__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :359:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A) Ctor_O_I_O(c__b__1117000116 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1117000116 = c__b__1117000116; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A) Invoke_O__O(self any) any { { var i__1117000115__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000115__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000115__1)); var tmp2 any; var or__1927000174__auto____3 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__2)
																								if jrt.A2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = A_arbace_a2g_dyncf_A_const_295 }
//line :359:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp2, 4098)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp4 any = t.F_b__1117000116; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_308.GetRawRoot__O()).Invoke_O_O__O(mm__2, A_arbace_a2g_dyncf_A_const_309)); i__1117000115__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000115__1); continue L1 } else { i__1117000115__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000115__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
//line :359:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A_New() *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A) Ctor() {}
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A) Invoke_O_O__O(self, s__1117000138__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A_New_O_O(self, s__1117000138__1); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :359:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A) Ctor_O_O(c__iter__1117000137, c__s__1117000138 any) { t.F_iter__1117000137 = c__iter__1117000137; t.F_s__1117000138 = c__s__1117000138 }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A) Invoke_O__O(self any) any { { var s__1117000138__1 any; var t_ any = t.F_s__1117000138; t.F_s__1117000138 = nil; s__1117000138__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000138__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000138__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000138__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000138__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000140__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1117000140__6); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000137); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000140__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000138__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000140__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000138__3); var tmp4 any; var or__1927000174__auto____5 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__4)
																				if jrt.A2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = A_arbace_a2g_dyncf_A_const_295 }
//line :359:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp4, 4098)) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1117000137); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_308.GetRawRoot__O()).Invoke_O_O__O(mm__4, A_arbace_a2g_dyncf_A_const_313), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000138__3))) } else { s__1117000138__1 = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000138__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :359:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1117000140 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1117000140 = c__b__1117000140 }
//line :359:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A) Invoke_O__O(self any) any { { var i__1117000139__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000139__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000139__1)); var tmp2 any; var or__1927000174__auto____3 any = A_arbace_a2g_dyncf_A_const_294.Invoke_O__O(mm__2)
																						if jrt.A2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = A_arbace_a2g_dyncf_A_const_295 }
//line :359:1
	if lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp2, 4098)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp4 any = t.F_b__1117000140; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_308.GetRawRoot__O()).Invoke_O_O__O(mm__2, A_arbace_a2g_dyncf_A_const_312)); i__1117000139__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000139__1); continue L1 } else { i__1117000139__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000139__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A_New() *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A) Ctor() {}
//line :365:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A) Invoke_O_O__O(self, s__1117000150__1 any) any { var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A_New_O_O(self, s__1117000150__1); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :365:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A_New_O_O(p0, p1 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :365:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A) Ctor_O_O(c__iter__1117000149, c__s__1117000150 any) { t.F_iter__1117000149 = c__iter__1117000149; t.F_s__1117000150 = c__s__1117000150 }
//line :365:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A) Invoke_O__O(self any) any { { var s__1117000150__1 any; var t_ any = t.F_s__1117000150; t.F_s__1117000150 = nil; s__1117000150__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_66.GetRawRoot__O()).Invoke_O__O(s__1117000150__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1117000150__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1117000150__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1117000150__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1117000152__6 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A_New_O_I_O(b__1117000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1117000149); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000152__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_102.GetRawRoot__O()).Invoke_O__O(s__1117000150__3))) } else { return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_101.GetRawRoot__O()).Invoke_O__O(b__1117000152__6), nil) } } else { var vec__1117000160__4 any = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_99.GetRawRoot__O()).Invoke_O__O(s__1117000150__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1117000160__4, lang.RT_IntCast_J__I(0), nil); var g__6 any = lang.RT_Nth_O_I_O__O(vec__1117000160__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1117000149); return lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_100.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_321.GetRawRoot__O()).Invoke_O__O(n__5), nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_321.GetRawRoot__O()).Invoke_O__O(g__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_103.GetRawRoot__O()).Invoke_O__O(s__1117000150__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :365:1
func A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A) Ctor_O_I_O(c__b__1117000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1117000152 = c__b__1117000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A) Invoke_O__O(self any) any { { var i__1117000151__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1117000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1117000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1117000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1117000156__2, lang.RT_IntCast_J__I(0), nil); var g__4 any = lang.RT_Nth_O_I_O__O(vec__1117000156__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_82.GetRawRoot__O()); var tmp3 any = t.F_b__1117000152; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_321.GetRawRoot__O()).Invoke_O__O(n__3), nil, lang.IFn_Cast(A_arbace_a2g_dyncf_A_const_321.GetRawRoot__O()).Invoke_O__O(g__4))).Ref()); i__1117000151__1 = lang.Numbers_Unchecked_inc_J__J(i__1117000151__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }









































































































type A_arbace_a2g_dyncf_A struct{ jrt.Object }

var A_arbace_a2g_dyncf_A_const_pool *jrt.RefArray

var A_arbace_a2g_dyncf_A_const_0 *lang.Var

var A_arbace_a2g_dyncf_A_const_1 *lang.Var

var A_arbace_a2g_dyncf_A_const_2 any

var A_arbace_a2g_dyncf_A_const_3 any

var A_arbace_a2g_dyncf_A_const_4 any

var A_arbace_a2g_dyncf_A_const_5 any

var A_arbace_a2g_dyncf_A_const_6 any

var A_arbace_a2g_dyncf_A_const_7 any

var A_arbace_a2g_dyncf_A_const_8 any

var A_arbace_a2g_dyncf_A_const_9 any

var A_arbace_a2g_dyncf_A_const_10 any

var A_arbace_a2g_dyncf_A_const_11 any

var A_arbace_a2g_dyncf_A_const_12 *lang.Var

var A_arbace_a2g_dyncf_A_const_13 *lang.Var

var A_arbace_a2g_dyncf_A_const_14 *lang.Var

var A_arbace_a2g_dyncf_A_const_15 any

var A_arbace_a2g_dyncf_A_const_16 *lang.Var

var A_arbace_a2g_dyncf_A_const_17 *lang.Var

var A_arbace_a2g_dyncf_A_const_18 *lang.Var

var A_arbace_a2g_dyncf_A_const_19 *lang.Var

var A_arbace_a2g_dyncf_A_const_20 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_21 *lang.Var

var A_arbace_a2g_dyncf_A_const_22 *lang.Var

var A_arbace_a2g_dyncf_A_const_23 *lang.Var

var A_arbace_a2g_dyncf_A_const_24 *lang.Var

var A_arbace_a2g_dyncf_A_const_25 *lang.Var

var A_arbace_a2g_dyncf_A_const_26 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_27 any

var A_arbace_a2g_dyncf_A_const_28 *lang.Var

var A_arbace_a2g_dyncf_A_const_29 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_30 any

var A_arbace_a2g_dyncf_A_const_31 *lang.Var

var A_arbace_a2g_dyncf_A_const_32 any

var A_arbace_a2g_dyncf_A_const_33 any

var A_arbace_a2g_dyncf_A_const_34 *lang.Var

var A_arbace_a2g_dyncf_A_const_35 *lang.Var

var A_arbace_a2g_dyncf_A_const_36 any

var A_arbace_a2g_dyncf_A_const_37 *lang.Var

var A_arbace_a2g_dyncf_A_const_38 *lang.Var

var A_arbace_a2g_dyncf_A_const_39 *lang.Var

var A_arbace_a2g_dyncf_A_const_40 any

var A_arbace_a2g_dyncf_A_const_41 any

var A_arbace_a2g_dyncf_A_const_42 *lang.Var

var A_arbace_a2g_dyncf_A_const_43 *lang.Var

var A_arbace_a2g_dyncf_A_const_44 any

var A_arbace_a2g_dyncf_A_const_45 any

var A_arbace_a2g_dyncf_A_const_46 *lang.Var

var A_arbace_a2g_dyncf_A_const_47 any

var A_arbace_a2g_dyncf_A_const_48 any

var A_arbace_a2g_dyncf_A_const_49 any

var A_arbace_a2g_dyncf_A_const_50 any

var A_arbace_a2g_dyncf_A_const_51 *lang.Var

var A_arbace_a2g_dyncf_A_const_52 any

var A_arbace_a2g_dyncf_A_const_53 any

var A_arbace_a2g_dyncf_A_const_54 any

var A_arbace_a2g_dyncf_A_const_55 any

var A_arbace_a2g_dyncf_A_const_56 any

var A_arbace_a2g_dyncf_A_const_57 any

var A_arbace_a2g_dyncf_A_const_58 any

var A_arbace_a2g_dyncf_A_const_59 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_60 any

var A_arbace_a2g_dyncf_A_const_61 any

var A_arbace_a2g_dyncf_A_const_62 *lang.Var

var A_arbace_a2g_dyncf_A_const_63 any

var A_arbace_a2g_dyncf_A_const_64 any

var A_arbace_a2g_dyncf_A_const_65 any

var A_arbace_a2g_dyncf_A_const_66 *lang.Var

var A_arbace_a2g_dyncf_A_const_67 *lang.Var

var A_arbace_a2g_dyncf_A_const_68 *lang.Var

var A_arbace_a2g_dyncf_A_const_69 *lang.Var

var A_arbace_a2g_dyncf_A_const_70 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_71 *lang.Var

var A_arbace_a2g_dyncf_A_const_72 *lang.Var

var A_arbace_a2g_dyncf_A_const_73 *lang.Var

var A_arbace_a2g_dyncf_A_const_74 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_75 *lang.Var

var A_arbace_a2g_dyncf_A_const_76 *lang.Var

var A_arbace_a2g_dyncf_A_const_77 *lang.Var

var A_arbace_a2g_dyncf_A_const_78 *lang.Var

var A_arbace_a2g_dyncf_A_const_79 *lang.Var

var A_arbace_a2g_dyncf_A_const_80 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_81 *lang.Var

var A_arbace_a2g_dyncf_A_const_82 *lang.Var

var A_arbace_a2g_dyncf_A_const_83 any

var A_arbace_a2g_dyncf_A_const_84 any

var A_arbace_a2g_dyncf_A_const_85 any

var A_arbace_a2g_dyncf_A_const_86 any

var A_arbace_a2g_dyncf_A_const_87 any

var A_arbace_a2g_dyncf_A_const_88 any

var A_arbace_a2g_dyncf_A_const_89 any

var A_arbace_a2g_dyncf_A_const_90 any

var A_arbace_a2g_dyncf_A_const_91 any

var A_arbace_a2g_dyncf_A_const_92 any

var A_arbace_a2g_dyncf_A_const_93 *lang.Var

var A_arbace_a2g_dyncf_A_const_94 any

var A_arbace_a2g_dyncf_A_const_95 *lang.Var

var A_arbace_a2g_dyncf_A_const_96 any

var A_arbace_a2g_dyncf_A_const_97 any

var A_arbace_a2g_dyncf_A_const_98 *lang.Var

var A_arbace_a2g_dyncf_A_const_99 *lang.Var

var A_arbace_a2g_dyncf_A_const_100 *lang.Var

var A_arbace_a2g_dyncf_A_const_101 *lang.Var

var A_arbace_a2g_dyncf_A_const_102 *lang.Var

var A_arbace_a2g_dyncf_A_const_103 *lang.Var

var A_arbace_a2g_dyncf_A_const_104 *lang.Var

var A_arbace_a2g_dyncf_A_const_105 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_106 *lang.Var

var A_arbace_a2g_dyncf_A_const_107 any

var A_arbace_a2g_dyncf_A_const_108 any

var A_arbace_a2g_dyncf_A_const_109 any

var A_arbace_a2g_dyncf_A_const_110 any

var A_arbace_a2g_dyncf_A_const_111 *lang.Var

var A_arbace_a2g_dyncf_A_const_112 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_113 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_114 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_115 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_116 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_117 any

var A_arbace_a2g_dyncf_A_const_118 any

var A_arbace_a2g_dyncf_A_const_119 any

var A_arbace_a2g_dyncf_A_const_120 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_121 any

var A_arbace_a2g_dyncf_A_const_122 any

var A_arbace_a2g_dyncf_A_const_123 any

var A_arbace_a2g_dyncf_A_const_124 any

var A_arbace_a2g_dyncf_A_const_125 any

var A_arbace_a2g_dyncf_A_const_126 any

var A_arbace_a2g_dyncf_A_const_127 any

var A_arbace_a2g_dyncf_A_const_128 any

var A_arbace_a2g_dyncf_A_const_129 any

var A_arbace_a2g_dyncf_A_const_130 any

var A_arbace_a2g_dyncf_A_const_131 any

var A_arbace_a2g_dyncf_A_const_132 any

var A_arbace_a2g_dyncf_A_const_133 any

var A_arbace_a2g_dyncf_A_const_134 any

var A_arbace_a2g_dyncf_A_const_135 any

var A_arbace_a2g_dyncf_A_const_136 any

var A_arbace_a2g_dyncf_A_const_137 any

var A_arbace_a2g_dyncf_A_const_138 any

var A_arbace_a2g_dyncf_A_const_139 *lang.Var

var A_arbace_a2g_dyncf_A_const_140 *lang.Var

var A_arbace_a2g_dyncf_A_const_141 *lang.Var

var A_arbace_a2g_dyncf_A_const_142 *lang.Var

var A_arbace_a2g_dyncf_A_const_143 *lang.Var

var A_arbace_a2g_dyncf_A_const_144 *lang.Var

var A_arbace_a2g_dyncf_A_const_145 any

var A_arbace_a2g_dyncf_A_const_146 any

var A_arbace_a2g_dyncf_A_const_147 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_148 any

var A_arbace_a2g_dyncf_A_const_149 any

var A_arbace_a2g_dyncf_A_const_150 any

var A_arbace_a2g_dyncf_A_const_151 any

var A_arbace_a2g_dyncf_A_const_152 any

var A_arbace_a2g_dyncf_A_const_153 any

var A_arbace_a2g_dyncf_A_const_154 any

var A_arbace_a2g_dyncf_A_const_155 any

var A_arbace_a2g_dyncf_A_const_156 *lang.Var

var A_arbace_a2g_dyncf_A_const_157 any

var A_arbace_a2g_dyncf_A_const_158 any

var A_arbace_a2g_dyncf_A_const_159 any

var A_arbace_a2g_dyncf_A_const_160 any

var A_arbace_a2g_dyncf_A_const_161 any

var A_arbace_a2g_dyncf_A_const_162 any

var A_arbace_a2g_dyncf_A_const_163 *lang.Var

var A_arbace_a2g_dyncf_A_const_164 any

var A_arbace_a2g_dyncf_A_const_165 any

var A_arbace_a2g_dyncf_A_const_166 any

var A_arbace_a2g_dyncf_A_const_167 any

var A_arbace_a2g_dyncf_A_const_168 any

var A_arbace_a2g_dyncf_A_const_169 any

var A_arbace_a2g_dyncf_A_const_170 any

var A_arbace_a2g_dyncf_A_const_171 any

var A_arbace_a2g_dyncf_A_const_172 any

var A_arbace_a2g_dyncf_A_const_173 any

var A_arbace_a2g_dyncf_A_const_174 any

var A_arbace_a2g_dyncf_A_const_175 any

var A_arbace_a2g_dyncf_A_const_176 any

var A_arbace_a2g_dyncf_A_const_177 any

var A_arbace_a2g_dyncf_A_const_178 any

var A_arbace_a2g_dyncf_A_const_179 any

var A_arbace_a2g_dyncf_A_const_180 any

var A_arbace_a2g_dyncf_A_const_181 any

var A_arbace_a2g_dyncf_A_const_182 any

var A_arbace_a2g_dyncf_A_const_183 any

var A_arbace_a2g_dyncf_A_const_184 any

var A_arbace_a2g_dyncf_A_const_185 any

var A_arbace_a2g_dyncf_A_const_186 any

var A_arbace_a2g_dyncf_A_const_187 any

var A_arbace_a2g_dyncf_A_const_188 any

var A_arbace_a2g_dyncf_A_const_189 any

var A_arbace_a2g_dyncf_A_const_190 any

var A_arbace_a2g_dyncf_A_const_191 any

var A_arbace_a2g_dyncf_A_const_192 any

var A_arbace_a2g_dyncf_A_const_193 any

var A_arbace_a2g_dyncf_A_const_194 any

var A_arbace_a2g_dyncf_A_const_195 any

var A_arbace_a2g_dyncf_A_const_196 any

var A_arbace_a2g_dyncf_A_const_197 any

var A_arbace_a2g_dyncf_A_const_198 any

var A_arbace_a2g_dyncf_A_const_199 any

var A_arbace_a2g_dyncf_A_const_200 any

var A_arbace_a2g_dyncf_A_const_201 any

var A_arbace_a2g_dyncf_A_const_202 any

var A_arbace_a2g_dyncf_A_const_203 any

var A_arbace_a2g_dyncf_A_const_204 any

var A_arbace_a2g_dyncf_A_const_205 any

var A_arbace_a2g_dyncf_A_const_206 any

var A_arbace_a2g_dyncf_A_const_207 any

var A_arbace_a2g_dyncf_A_const_208 any

var A_arbace_a2g_dyncf_A_const_209 any

var A_arbace_a2g_dyncf_A_const_210 any

var A_arbace_a2g_dyncf_A_const_211 any

var A_arbace_a2g_dyncf_A_const_212 any

var A_arbace_a2g_dyncf_A_const_213 any

var A_arbace_a2g_dyncf_A_const_214 any

var A_arbace_a2g_dyncf_A_const_215 any

var A_arbace_a2g_dyncf_A_const_216 any

var A_arbace_a2g_dyncf_A_const_217 any

var A_arbace_a2g_dyncf_A_const_218 any

var A_arbace_a2g_dyncf_A_const_219 any

var A_arbace_a2g_dyncf_A_const_220 any

var A_arbace_a2g_dyncf_A_const_221 any

var A_arbace_a2g_dyncf_A_const_222 any

var A_arbace_a2g_dyncf_A_const_223 any

var A_arbace_a2g_dyncf_A_const_224 any

var A_arbace_a2g_dyncf_A_const_225 any

var A_arbace_a2g_dyncf_A_const_226 any

var A_arbace_a2g_dyncf_A_const_227 any

var A_arbace_a2g_dyncf_A_const_228 any

var A_arbace_a2g_dyncf_A_const_229 any

var A_arbace_a2g_dyncf_A_const_230 any

var A_arbace_a2g_dyncf_A_const_231 any

var A_arbace_a2g_dyncf_A_const_232 any

var A_arbace_a2g_dyncf_A_const_233 any

var A_arbace_a2g_dyncf_A_const_234 any

var A_arbace_a2g_dyncf_A_const_235 any

var A_arbace_a2g_dyncf_A_const_236 any

var A_arbace_a2g_dyncf_A_const_237 any

var A_arbace_a2g_dyncf_A_const_238 any

var A_arbace_a2g_dyncf_A_const_239 any

var A_arbace_a2g_dyncf_A_const_240 any

var A_arbace_a2g_dyncf_A_const_241 any

var A_arbace_a2g_dyncf_A_const_242 any

var A_arbace_a2g_dyncf_A_const_243 any

var A_arbace_a2g_dyncf_A_const_244 any

var A_arbace_a2g_dyncf_A_const_245 any

var A_arbace_a2g_dyncf_A_const_246 any

var A_arbace_a2g_dyncf_A_const_247 any

var A_arbace_a2g_dyncf_A_const_248 any

var A_arbace_a2g_dyncf_A_const_249 any

var A_arbace_a2g_dyncf_A_const_250 any

var A_arbace_a2g_dyncf_A_const_251 any

var A_arbace_a2g_dyncf_A_const_252 any

var A_arbace_a2g_dyncf_A_const_253 any

var A_arbace_a2g_dyncf_A_const_254 any

var A_arbace_a2g_dyncf_A_const_255 any

var A_arbace_a2g_dyncf_A_const_256 any

var A_arbace_a2g_dyncf_A_const_257 any

var A_arbace_a2g_dyncf_A_const_258 any

var A_arbace_a2g_dyncf_A_const_259 any

var A_arbace_a2g_dyncf_A_const_260 any

var A_arbace_a2g_dyncf_A_const_261 any

var A_arbace_a2g_dyncf_A_const_262 any

var A_arbace_a2g_dyncf_A_const_263 any

var A_arbace_a2g_dyncf_A_const_264 any

var A_arbace_a2g_dyncf_A_const_265 any

var A_arbace_a2g_dyncf_A_const_266 any

var A_arbace_a2g_dyncf_A_const_267 any

var A_arbace_a2g_dyncf_A_const_268 any

var A_arbace_a2g_dyncf_A_const_269 any

var A_arbace_a2g_dyncf_A_const_270 any

var A_arbace_a2g_dyncf_A_const_271 any

var A_arbace_a2g_dyncf_A_const_272 any

var A_arbace_a2g_dyncf_A_const_273 any

var A_arbace_a2g_dyncf_A_const_274 any

var A_arbace_a2g_dyncf_A_const_275 any

var A_arbace_a2g_dyncf_A_const_276 any

var A_arbace_a2g_dyncf_A_const_277 any

var A_arbace_a2g_dyncf_A_const_278 any

var A_arbace_a2g_dyncf_A_const_279 any

var A_arbace_a2g_dyncf_A_const_280 any

var A_arbace_a2g_dyncf_A_const_281 any

var A_arbace_a2g_dyncf_A_const_282 any

var A_arbace_a2g_dyncf_A_const_283 any

var A_arbace_a2g_dyncf_A_const_284 any

var A_arbace_a2g_dyncf_A_const_285 any

var A_arbace_a2g_dyncf_A_const_286 *lang.Var

var A_arbace_a2g_dyncf_A_const_287 *lang.Var

var A_arbace_a2g_dyncf_A_const_288 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_289 *lang.Var

var A_arbace_a2g_dyncf_A_const_290 *lang.Var

var A_arbace_a2g_dyncf_A_const_291 *lang.Var

var A_arbace_a2g_dyncf_A_const_292 *lang.Var

var A_arbace_a2g_dyncf_A_const_293 *lang.Var

var A_arbace_a2g_dyncf_A_const_294 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_295 any

var A_arbace_a2g_dyncf_A_const_296 *lang.Var

var A_arbace_a2g_dyncf_A_const_297 any

var A_arbace_a2g_dyncf_A_const_298 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_299 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_300 *lang.Var

var A_arbace_a2g_dyncf_A_const_301 *lang.Var

var A_arbace_a2g_dyncf_A_const_302 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_303 *lang.Var

var A_arbace_a2g_dyncf_A_const_304 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_305 *lang.Var

var A_arbace_a2g_dyncf_A_const_306 *lang.Var

var A_arbace_a2g_dyncf_A_const_307 *lang.Keyword

var A_arbace_a2g_dyncf_A_const_308 *lang.Var

var A_arbace_a2g_dyncf_A_const_309 any

var A_arbace_a2g_dyncf_A_const_310 any

var A_arbace_a2g_dyncf_A_const_311 any

var A_arbace_a2g_dyncf_A_const_312 any

var A_arbace_a2g_dyncf_A_const_313 any

var A_arbace_a2g_dyncf_A_const_314 *lang.Var

var A_arbace_a2g_dyncf_A_const_315 *lang.Var

var A_arbace_a2g_dyncf_A_const_316 any

var A_arbace_a2g_dyncf_A_const_317 *lang.Var

var A_arbace_a2g_dyncf_A_const_318 *lang.Var

var A_arbace_a2g_dyncf_A_const_319 *lang.Var

var A_arbace_a2g_dyncf_A_const_320 *lang.Var

var A_arbace_a2g_dyncf_A_const_321 *lang.Var

var A_arbace_a2g_dyncf_A_init jrt.ClassInit

func A_arbace_a2g_dyncf_A_Init() { if !A_arbace_a2g_dyncf_A_init.Done() { A_arbace_a2g_dyncf_A_init.Run(A_arbace_a2g_dyncf_A_clinit) } }

func A_arbace_a2g_dyncf_A_clinit() { A_arbace_a2g_dyncf_A_clinit_p0(); A_arbace_a2g_dyncf_A_clinit_p1(); A_arbace_a2g_dyncf_A_clinit_p2(); A_arbace_a2g_dyncf_A_clinit_p3(); A_arbace_a2g_dyncf_A_clinit_p4(); A_arbace_a2g_dyncf_A_clinit_p5(); A_arbace_a2g_dyncf_A_clinit_p6(); A_arbace_a2g_dyncf_A_clinit_p7(); A_arbace_a2g_dyncf_A_clinit_p8(); A_arbace_a2g_dyncf_A_clinit_p9(); A_arbace_a2g_dyncf_A_clinit_p10(); A_arbace_a2g_dyncf_A_clinit_p11(); A_arbace_a2g_dyncf_A_clinit_p12(); A_arbace_a2g_dyncf_A_clinit_p13(); A_arbace_a2g_dyncf_A_clinit_p14(); A_arbace_a2g_dyncf_A_clinit_p15(); A_arbace_a2g_dyncf_A_clinit_p16(); A_arbace_a2g_dyncf_A_clinit_p17(); A_arbace_a2g_dyncf_A_clinit_p18(); A_arbace_a2g_dyncf_A_clinit_p19(); A_arbace_a2g_dyncf_A_clinit_p20(); A_arbace_a2g_dyncf_A_clinit_p21(); A_arbace_a2g_dyncf_A_clinit_p22() }

func A_arbace_a2g_dyncf_A_clinit_p0() { A_arbace_a2g_dyncf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 551); A_arbace_a2g_dyncf_A_const_0 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[229]); A_arbace_a2g_dyncf_A_const_1 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[230]); A_arbace_a2g_dyncf_A_const_2 = A_arbace_a2g_dyncf_A_const_pool.A[231]; A_arbace_a2g_dyncf_A_const_3 = A_arbace_a2g_dyncf_A_const_pool.A[232]; A_arbace_a2g_dyncf_A_const_4 = A_arbace_a2g_dyncf_A_const_pool.A[233]; A_arbace_a2g_dyncf_A_const_5 = A_arbace_a2g_dyncf_A_const_pool.A[234]; A_arbace_a2g_dyncf_A_const_6 = A_arbace_a2g_dyncf_A_const_pool.A[235]; A_arbace_a2g_dyncf_A_const_7 = A_arbace_a2g_dyncf_A_const_pool.A[236]; A_arbace_a2g_dyncf_A_const_8 = A_arbace_a2g_dyncf_A_const_pool.A[237]; A_arbace_a2g_dyncf_A_const_9 = A_arbace_a2g_dyncf_A_const_pool.A[238]; A_arbace_a2g_dyncf_A_const_10 = A_arbace_a2g_dyncf_A_const_pool.A[239]; A_arbace_a2g_dyncf_A_const_11 = A_arbace_a2g_dyncf_A_const_pool.A[240]; A_arbace_a2g_dyncf_A_const_12 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[241]); A_arbace_a2g_dyncf_A_const_13 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[242]) }

func A_arbace_a2g_dyncf_A_clinit_p1() { A_arbace_a2g_dyncf_A_const_14 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[243]); A_arbace_a2g_dyncf_A_const_15 = A_arbace_a2g_dyncf_A_const_pool.A[244]; A_arbace_a2g_dyncf_A_const_16 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[245]); A_arbace_a2g_dyncf_A_const_17 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[246]); A_arbace_a2g_dyncf_A_const_18 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[247]); A_arbace_a2g_dyncf_A_const_19 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[248]); A_arbace_a2g_dyncf_A_const_20 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[249]); A_arbace_a2g_dyncf_A_const_21 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[250]); A_arbace_a2g_dyncf_A_const_22 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[251]); A_arbace_a2g_dyncf_A_const_23 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[252]); A_arbace_a2g_dyncf_A_const_24 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[253]); A_arbace_a2g_dyncf_A_const_25 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[254]) }

func A_arbace_a2g_dyncf_A_clinit_p2() { A_arbace_a2g_dyncf_A_const_26 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[255]); A_arbace_a2g_dyncf_A_const_27 = A_arbace_a2g_dyncf_A_const_pool.A[256]; A_arbace_a2g_dyncf_A_const_28 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[257]); A_arbace_a2g_dyncf_A_const_29 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[258]); A_arbace_a2g_dyncf_A_const_30 = A_arbace_a2g_dyncf_A_const_pool.A[259]; A_arbace_a2g_dyncf_A_const_31 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[260]); A_arbace_a2g_dyncf_A_const_32 = A_arbace_a2g_dyncf_A_const_pool.A[261]; A_arbace_a2g_dyncf_A_const_33 = A_arbace_a2g_dyncf_A_const_pool.A[262]; A_arbace_a2g_dyncf_A_const_34 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[263]); A_arbace_a2g_dyncf_A_const_35 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[264]); A_arbace_a2g_dyncf_A_const_36 = A_arbace_a2g_dyncf_A_const_pool.A[265]; A_arbace_a2g_dyncf_A_const_37 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[266]); A_arbace_a2g_dyncf_A_const_38 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[267]) }

func A_arbace_a2g_dyncf_A_clinit_p3() { A_arbace_a2g_dyncf_A_const_39 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[268]); A_arbace_a2g_dyncf_A_const_40 = A_arbace_a2g_dyncf_A_const_pool.A[269]; A_arbace_a2g_dyncf_A_const_41 = A_arbace_a2g_dyncf_A_const_pool.A[270]; A_arbace_a2g_dyncf_A_const_42 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[271]); A_arbace_a2g_dyncf_A_const_43 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[272]); A_arbace_a2g_dyncf_A_const_44 = A_arbace_a2g_dyncf_A_const_pool.A[273]; A_arbace_a2g_dyncf_A_const_45 = A_arbace_a2g_dyncf_A_const_pool.A[274]; A_arbace_a2g_dyncf_A_const_46 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[275]); A_arbace_a2g_dyncf_A_const_47 = A_arbace_a2g_dyncf_A_const_pool.A[276]; A_arbace_a2g_dyncf_A_const_48 = A_arbace_a2g_dyncf_A_const_pool.A[277]; A_arbace_a2g_dyncf_A_const_49 = A_arbace_a2g_dyncf_A_const_pool.A[278]; A_arbace_a2g_dyncf_A_const_50 = A_arbace_a2g_dyncf_A_const_pool.A[279]; A_arbace_a2g_dyncf_A_const_51 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[280]); A_arbace_a2g_dyncf_A_const_52 = A_arbace_a2g_dyncf_A_const_pool.A[281] }

func A_arbace_a2g_dyncf_A_clinit_p4() { A_arbace_a2g_dyncf_A_const_53 = A_arbace_a2g_dyncf_A_const_pool.A[282]; A_arbace_a2g_dyncf_A_const_54 = A_arbace_a2g_dyncf_A_const_pool.A[283]; A_arbace_a2g_dyncf_A_const_55 = A_arbace_a2g_dyncf_A_const_pool.A[284]; A_arbace_a2g_dyncf_A_const_56 = A_arbace_a2g_dyncf_A_const_pool.A[285]; A_arbace_a2g_dyncf_A_const_57 = A_arbace_a2g_dyncf_A_const_pool.A[286]; A_arbace_a2g_dyncf_A_const_58 = A_arbace_a2g_dyncf_A_const_pool.A[287]; A_arbace_a2g_dyncf_A_const_59 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[288]); A_arbace_a2g_dyncf_A_const_60 = A_arbace_a2g_dyncf_A_const_pool.A[289]; A_arbace_a2g_dyncf_A_const_61 = A_arbace_a2g_dyncf_A_const_pool.A[290]; A_arbace_a2g_dyncf_A_const_62 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[291]); A_arbace_a2g_dyncf_A_const_63 = A_arbace_a2g_dyncf_A_const_pool.A[292]; A_arbace_a2g_dyncf_A_const_64 = A_arbace_a2g_dyncf_A_const_pool.A[293]; A_arbace_a2g_dyncf_A_const_65 = A_arbace_a2g_dyncf_A_const_pool.A[294]; A_arbace_a2g_dyncf_A_const_66 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[295]) }

func A_arbace_a2g_dyncf_A_clinit_p5() { A_arbace_a2g_dyncf_A_const_67 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[296]); A_arbace_a2g_dyncf_A_const_68 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[297]); A_arbace_a2g_dyncf_A_const_69 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[298]); A_arbace_a2g_dyncf_A_const_70 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[299]); A_arbace_a2g_dyncf_A_const_71 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[300]); A_arbace_a2g_dyncf_A_const_72 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[301]); A_arbace_a2g_dyncf_A_const_73 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[302]); A_arbace_a2g_dyncf_A_const_74 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[303]); A_arbace_a2g_dyncf_A_const_75 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[304]); A_arbace_a2g_dyncf_A_const_76 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[305]); A_arbace_a2g_dyncf_A_const_77 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[306]); A_arbace_a2g_dyncf_A_const_78 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[307]) }

func A_arbace_a2g_dyncf_A_clinit_p6() { A_arbace_a2g_dyncf_A_const_79 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[308]); A_arbace_a2g_dyncf_A_const_80 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[309]); A_arbace_a2g_dyncf_A_const_81 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[310]); A_arbace_a2g_dyncf_A_const_82 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[311]); A_arbace_a2g_dyncf_A_const_83 = A_arbace_a2g_dyncf_A_const_pool.A[312]; A_arbace_a2g_dyncf_A_const_84 = A_arbace_a2g_dyncf_A_const_pool.A[313]; A_arbace_a2g_dyncf_A_const_85 = A_arbace_a2g_dyncf_A_const_pool.A[314]; A_arbace_a2g_dyncf_A_const_86 = A_arbace_a2g_dyncf_A_const_pool.A[315]; A_arbace_a2g_dyncf_A_const_87 = A_arbace_a2g_dyncf_A_const_pool.A[316]; A_arbace_a2g_dyncf_A_const_88 = A_arbace_a2g_dyncf_A_const_pool.A[317]; A_arbace_a2g_dyncf_A_const_89 = A_arbace_a2g_dyncf_A_const_pool.A[318]; A_arbace_a2g_dyncf_A_const_90 = A_arbace_a2g_dyncf_A_const_pool.A[319]; A_arbace_a2g_dyncf_A_const_91 = A_arbace_a2g_dyncf_A_const_pool.A[320]; A_arbace_a2g_dyncf_A_const_92 = A_arbace_a2g_dyncf_A_const_pool.A[321] }

func A_arbace_a2g_dyncf_A_clinit_p7() { A_arbace_a2g_dyncf_A_const_93 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[322]); A_arbace_a2g_dyncf_A_const_94 = A_arbace_a2g_dyncf_A_const_pool.A[323]; A_arbace_a2g_dyncf_A_const_95 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[324]); A_arbace_a2g_dyncf_A_const_96 = A_arbace_a2g_dyncf_A_const_pool.A[325]; A_arbace_a2g_dyncf_A_const_97 = A_arbace_a2g_dyncf_A_const_pool.A[326]; A_arbace_a2g_dyncf_A_const_98 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[327]); A_arbace_a2g_dyncf_A_const_99 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[328]); A_arbace_a2g_dyncf_A_const_100 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[329]); A_arbace_a2g_dyncf_A_const_101 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[330]); A_arbace_a2g_dyncf_A_const_102 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[331]); A_arbace_a2g_dyncf_A_const_103 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[332]); A_arbace_a2g_dyncf_A_const_104 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[333]) }

func A_arbace_a2g_dyncf_A_clinit_p8() { A_arbace_a2g_dyncf_A_const_105 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[334]); A_arbace_a2g_dyncf_A_const_106 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[335]); A_arbace_a2g_dyncf_A_const_107 = A_arbace_a2g_dyncf_A_const_pool.A[336]; A_arbace_a2g_dyncf_A_const_108 = A_arbace_a2g_dyncf_A_const_pool.A[337]; A_arbace_a2g_dyncf_A_const_109 = A_arbace_a2g_dyncf_A_const_pool.A[338]; A_arbace_a2g_dyncf_A_const_110 = A_arbace_a2g_dyncf_A_const_pool.A[339]; A_arbace_a2g_dyncf_A_const_111 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[340]); A_arbace_a2g_dyncf_A_const_112 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[341]); A_arbace_a2g_dyncf_A_const_113 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[342]); A_arbace_a2g_dyncf_A_const_114 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[343]); A_arbace_a2g_dyncf_A_const_115 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[344]); A_arbace_a2g_dyncf_A_const_116 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[345]); A_arbace_a2g_dyncf_A_const_117 = A_arbace_a2g_dyncf_A_const_pool.A[346] }

func A_arbace_a2g_dyncf_A_clinit_p9() { A_arbace_a2g_dyncf_A_const_118 = A_arbace_a2g_dyncf_A_const_pool.A[347]; A_arbace_a2g_dyncf_A_const_119 = A_arbace_a2g_dyncf_A_const_pool.A[348]; A_arbace_a2g_dyncf_A_const_120 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[349]); A_arbace_a2g_dyncf_A_const_121 = A_arbace_a2g_dyncf_A_const_pool.A[350]; A_arbace_a2g_dyncf_A_const_122 = A_arbace_a2g_dyncf_A_const_pool.A[351]; A_arbace_a2g_dyncf_A_const_123 = A_arbace_a2g_dyncf_A_const_pool.A[352]; A_arbace_a2g_dyncf_A_const_124 = A_arbace_a2g_dyncf_A_const_pool.A[353]; A_arbace_a2g_dyncf_A_const_125 = A_arbace_a2g_dyncf_A_const_pool.A[354]; A_arbace_a2g_dyncf_A_const_126 = A_arbace_a2g_dyncf_A_const_pool.A[355]; A_arbace_a2g_dyncf_A_const_127 = A_arbace_a2g_dyncf_A_const_pool.A[356]; A_arbace_a2g_dyncf_A_const_128 = A_arbace_a2g_dyncf_A_const_pool.A[357]; A_arbace_a2g_dyncf_A_const_129 = A_arbace_a2g_dyncf_A_const_pool.A[358]; A_arbace_a2g_dyncf_A_const_130 = A_arbace_a2g_dyncf_A_const_pool.A[359]; A_arbace_a2g_dyncf_A_const_131 = A_arbace_a2g_dyncf_A_const_pool.A[360]; A_arbace_a2g_dyncf_A_const_132 = A_arbace_a2g_dyncf_A_const_pool.A[361] }

func A_arbace_a2g_dyncf_A_clinit_p10() { A_arbace_a2g_dyncf_A_const_133 = A_arbace_a2g_dyncf_A_const_pool.A[362]; A_arbace_a2g_dyncf_A_const_134 = A_arbace_a2g_dyncf_A_const_pool.A[363]; A_arbace_a2g_dyncf_A_const_135 = A_arbace_a2g_dyncf_A_const_pool.A[364]; A_arbace_a2g_dyncf_A_const_136 = A_arbace_a2g_dyncf_A_const_pool.A[365]; A_arbace_a2g_dyncf_A_const_137 = A_arbace_a2g_dyncf_A_const_pool.A[366]; A_arbace_a2g_dyncf_A_const_138 = A_arbace_a2g_dyncf_A_const_pool.A[367]; A_arbace_a2g_dyncf_A_const_139 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[368]); A_arbace_a2g_dyncf_A_const_140 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[369]); A_arbace_a2g_dyncf_A_const_141 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[370]); A_arbace_a2g_dyncf_A_const_142 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[371]); A_arbace_a2g_dyncf_A_const_143 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[372]); A_arbace_a2g_dyncf_A_const_144 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[373]); A_arbace_a2g_dyncf_A_const_145 = A_arbace_a2g_dyncf_A_const_pool.A[374]; A_arbace_a2g_dyncf_A_const_146 = A_arbace_a2g_dyncf_A_const_pool.A[375] }

func A_arbace_a2g_dyncf_A_clinit_p11() { A_arbace_a2g_dyncf_A_const_147 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[376]); A_arbace_a2g_dyncf_A_const_148 = A_arbace_a2g_dyncf_A_const_pool.A[377]; A_arbace_a2g_dyncf_A_const_149 = A_arbace_a2g_dyncf_A_const_pool.A[378]; A_arbace_a2g_dyncf_A_const_150 = A_arbace_a2g_dyncf_A_const_pool.A[379]; A_arbace_a2g_dyncf_A_const_151 = A_arbace_a2g_dyncf_A_const_pool.A[380]; A_arbace_a2g_dyncf_A_const_152 = A_arbace_a2g_dyncf_A_const_pool.A[381]; A_arbace_a2g_dyncf_A_const_153 = A_arbace_a2g_dyncf_A_const_pool.A[382]; A_arbace_a2g_dyncf_A_const_154 = A_arbace_a2g_dyncf_A_const_pool.A[383]; A_arbace_a2g_dyncf_A_const_155 = A_arbace_a2g_dyncf_A_const_pool.A[384]; A_arbace_a2g_dyncf_A_const_156 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[385]); A_arbace_a2g_dyncf_A_const_157 = A_arbace_a2g_dyncf_A_const_pool.A[386]; A_arbace_a2g_dyncf_A_const_158 = A_arbace_a2g_dyncf_A_const_pool.A[387]; A_arbace_a2g_dyncf_A_const_159 = A_arbace_a2g_dyncf_A_const_pool.A[388]; A_arbace_a2g_dyncf_A_const_160 = A_arbace_a2g_dyncf_A_const_pool.A[389]; A_arbace_a2g_dyncf_A_const_161 = A_arbace_a2g_dyncf_A_const_pool.A[390] }

func A_arbace_a2g_dyncf_A_clinit_p12() { A_arbace_a2g_dyncf_A_const_162 = A_arbace_a2g_dyncf_A_const_pool.A[391]; A_arbace_a2g_dyncf_A_const_163 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[392]); A_arbace_a2g_dyncf_A_const_164 = A_arbace_a2g_dyncf_A_const_pool.A[393]; A_arbace_a2g_dyncf_A_const_165 = A_arbace_a2g_dyncf_A_const_pool.A[394]; A_arbace_a2g_dyncf_A_const_166 = A_arbace_a2g_dyncf_A_const_pool.A[395]; A_arbace_a2g_dyncf_A_const_167 = A_arbace_a2g_dyncf_A_const_pool.A[396]; A_arbace_a2g_dyncf_A_const_168 = A_arbace_a2g_dyncf_A_const_pool.A[397]; A_arbace_a2g_dyncf_A_const_169 = A_arbace_a2g_dyncf_A_const_pool.A[398]; A_arbace_a2g_dyncf_A_const_170 = A_arbace_a2g_dyncf_A_const_pool.A[399]; A_arbace_a2g_dyncf_A_const_171 = A_arbace_a2g_dyncf_A_const_pool.A[400]; A_arbace_a2g_dyncf_A_const_172 = A_arbace_a2g_dyncf_A_const_pool.A[401]; A_arbace_a2g_dyncf_A_const_173 = A_arbace_a2g_dyncf_A_const_pool.A[402]; A_arbace_a2g_dyncf_A_const_174 = A_arbace_a2g_dyncf_A_const_pool.A[403]; A_arbace_a2g_dyncf_A_const_175 = A_arbace_a2g_dyncf_A_const_pool.A[404]; A_arbace_a2g_dyncf_A_const_176 = A_arbace_a2g_dyncf_A_const_pool.A[405] }

func A_arbace_a2g_dyncf_A_clinit_p13() { A_arbace_a2g_dyncf_A_const_177 = A_arbace_a2g_dyncf_A_const_pool.A[406]; A_arbace_a2g_dyncf_A_const_178 = A_arbace_a2g_dyncf_A_const_pool.A[407]; A_arbace_a2g_dyncf_A_const_179 = A_arbace_a2g_dyncf_A_const_pool.A[408]; A_arbace_a2g_dyncf_A_const_180 = A_arbace_a2g_dyncf_A_const_pool.A[409]; A_arbace_a2g_dyncf_A_const_181 = A_arbace_a2g_dyncf_A_const_pool.A[410]; A_arbace_a2g_dyncf_A_const_182 = A_arbace_a2g_dyncf_A_const_pool.A[411]; A_arbace_a2g_dyncf_A_const_183 = A_arbace_a2g_dyncf_A_const_pool.A[412]; A_arbace_a2g_dyncf_A_const_184 = A_arbace_a2g_dyncf_A_const_pool.A[413]; A_arbace_a2g_dyncf_A_const_185 = A_arbace_a2g_dyncf_A_const_pool.A[414]; A_arbace_a2g_dyncf_A_const_186 = A_arbace_a2g_dyncf_A_const_pool.A[415]; A_arbace_a2g_dyncf_A_const_187 = A_arbace_a2g_dyncf_A_const_pool.A[416]; A_arbace_a2g_dyncf_A_const_188 = A_arbace_a2g_dyncf_A_const_pool.A[417]; A_arbace_a2g_dyncf_A_const_189 = A_arbace_a2g_dyncf_A_const_pool.A[418]; A_arbace_a2g_dyncf_A_const_190 = A_arbace_a2g_dyncf_A_const_pool.A[419]; A_arbace_a2g_dyncf_A_const_191 = A_arbace_a2g_dyncf_A_const_pool.A[420]; A_arbace_a2g_dyncf_A_const_192 = A_arbace_a2g_dyncf_A_const_pool.A[421] }

func A_arbace_a2g_dyncf_A_clinit_p14() { A_arbace_a2g_dyncf_A_const_193 = A_arbace_a2g_dyncf_A_const_pool.A[422]; A_arbace_a2g_dyncf_A_const_194 = A_arbace_a2g_dyncf_A_const_pool.A[423]; A_arbace_a2g_dyncf_A_const_195 = A_arbace_a2g_dyncf_A_const_pool.A[424]; A_arbace_a2g_dyncf_A_const_196 = A_arbace_a2g_dyncf_A_const_pool.A[425]; A_arbace_a2g_dyncf_A_const_197 = A_arbace_a2g_dyncf_A_const_pool.A[426]; A_arbace_a2g_dyncf_A_const_198 = A_arbace_a2g_dyncf_A_const_pool.A[427]; A_arbace_a2g_dyncf_A_const_199 = A_arbace_a2g_dyncf_A_const_pool.A[428]; A_arbace_a2g_dyncf_A_const_200 = A_arbace_a2g_dyncf_A_const_pool.A[429]; A_arbace_a2g_dyncf_A_const_201 = A_arbace_a2g_dyncf_A_const_pool.A[430]; A_arbace_a2g_dyncf_A_const_202 = A_arbace_a2g_dyncf_A_const_pool.A[431]; A_arbace_a2g_dyncf_A_const_203 = A_arbace_a2g_dyncf_A_const_pool.A[432]; A_arbace_a2g_dyncf_A_const_204 = A_arbace_a2g_dyncf_A_const_pool.A[433]; A_arbace_a2g_dyncf_A_const_205 = A_arbace_a2g_dyncf_A_const_pool.A[434]; A_arbace_a2g_dyncf_A_const_206 = A_arbace_a2g_dyncf_A_const_pool.A[435]; A_arbace_a2g_dyncf_A_const_207 = A_arbace_a2g_dyncf_A_const_pool.A[436]; A_arbace_a2g_dyncf_A_const_208 = A_arbace_a2g_dyncf_A_const_pool.A[437] }

func A_arbace_a2g_dyncf_A_clinit_p15() { A_arbace_a2g_dyncf_A_const_209 = A_arbace_a2g_dyncf_A_const_pool.A[438]; A_arbace_a2g_dyncf_A_const_210 = A_arbace_a2g_dyncf_A_const_pool.A[439]; A_arbace_a2g_dyncf_A_const_211 = A_arbace_a2g_dyncf_A_const_pool.A[440]; A_arbace_a2g_dyncf_A_const_212 = A_arbace_a2g_dyncf_A_const_pool.A[441]; A_arbace_a2g_dyncf_A_const_213 = A_arbace_a2g_dyncf_A_const_pool.A[442]; A_arbace_a2g_dyncf_A_const_214 = A_arbace_a2g_dyncf_A_const_pool.A[443]; A_arbace_a2g_dyncf_A_const_215 = A_arbace_a2g_dyncf_A_const_pool.A[444]; A_arbace_a2g_dyncf_A_const_216 = A_arbace_a2g_dyncf_A_const_pool.A[445]; A_arbace_a2g_dyncf_A_const_217 = A_arbace_a2g_dyncf_A_const_pool.A[446]; A_arbace_a2g_dyncf_A_const_218 = A_arbace_a2g_dyncf_A_const_pool.A[447]; A_arbace_a2g_dyncf_A_const_219 = A_arbace_a2g_dyncf_A_const_pool.A[448]; A_arbace_a2g_dyncf_A_const_220 = A_arbace_a2g_dyncf_A_const_pool.A[449]; A_arbace_a2g_dyncf_A_const_221 = A_arbace_a2g_dyncf_A_const_pool.A[450]; A_arbace_a2g_dyncf_A_const_222 = A_arbace_a2g_dyncf_A_const_pool.A[451]; A_arbace_a2g_dyncf_A_const_223 = A_arbace_a2g_dyncf_A_const_pool.A[452]; A_arbace_a2g_dyncf_A_const_224 = A_arbace_a2g_dyncf_A_const_pool.A[453] }

func A_arbace_a2g_dyncf_A_clinit_p16() { A_arbace_a2g_dyncf_A_const_225 = A_arbace_a2g_dyncf_A_const_pool.A[454]; A_arbace_a2g_dyncf_A_const_226 = A_arbace_a2g_dyncf_A_const_pool.A[455]; A_arbace_a2g_dyncf_A_const_227 = A_arbace_a2g_dyncf_A_const_pool.A[456]; A_arbace_a2g_dyncf_A_const_228 = A_arbace_a2g_dyncf_A_const_pool.A[457]; A_arbace_a2g_dyncf_A_const_229 = A_arbace_a2g_dyncf_A_const_pool.A[458]; A_arbace_a2g_dyncf_A_const_230 = A_arbace_a2g_dyncf_A_const_pool.A[459]; A_arbace_a2g_dyncf_A_const_231 = A_arbace_a2g_dyncf_A_const_pool.A[460]; A_arbace_a2g_dyncf_A_const_232 = A_arbace_a2g_dyncf_A_const_pool.A[461]; A_arbace_a2g_dyncf_A_const_233 = A_arbace_a2g_dyncf_A_const_pool.A[462]; A_arbace_a2g_dyncf_A_const_234 = A_arbace_a2g_dyncf_A_const_pool.A[463]; A_arbace_a2g_dyncf_A_const_235 = A_arbace_a2g_dyncf_A_const_pool.A[464]; A_arbace_a2g_dyncf_A_const_236 = A_arbace_a2g_dyncf_A_const_pool.A[465]; A_arbace_a2g_dyncf_A_const_237 = A_arbace_a2g_dyncf_A_const_pool.A[466]; A_arbace_a2g_dyncf_A_const_238 = A_arbace_a2g_dyncf_A_const_pool.A[467]; A_arbace_a2g_dyncf_A_const_239 = A_arbace_a2g_dyncf_A_const_pool.A[468]; A_arbace_a2g_dyncf_A_const_240 = A_arbace_a2g_dyncf_A_const_pool.A[469] }

func A_arbace_a2g_dyncf_A_clinit_p17() { A_arbace_a2g_dyncf_A_const_241 = A_arbace_a2g_dyncf_A_const_pool.A[470]; A_arbace_a2g_dyncf_A_const_242 = A_arbace_a2g_dyncf_A_const_pool.A[471]; A_arbace_a2g_dyncf_A_const_243 = A_arbace_a2g_dyncf_A_const_pool.A[472]; A_arbace_a2g_dyncf_A_const_244 = A_arbace_a2g_dyncf_A_const_pool.A[473]; A_arbace_a2g_dyncf_A_const_245 = A_arbace_a2g_dyncf_A_const_pool.A[474]; A_arbace_a2g_dyncf_A_const_246 = A_arbace_a2g_dyncf_A_const_pool.A[475]; A_arbace_a2g_dyncf_A_const_247 = A_arbace_a2g_dyncf_A_const_pool.A[476]; A_arbace_a2g_dyncf_A_const_248 = A_arbace_a2g_dyncf_A_const_pool.A[477]; A_arbace_a2g_dyncf_A_const_249 = A_arbace_a2g_dyncf_A_const_pool.A[478]; A_arbace_a2g_dyncf_A_const_250 = A_arbace_a2g_dyncf_A_const_pool.A[479]; A_arbace_a2g_dyncf_A_const_251 = A_arbace_a2g_dyncf_A_const_pool.A[480]; A_arbace_a2g_dyncf_A_const_252 = A_arbace_a2g_dyncf_A_const_pool.A[481]; A_arbace_a2g_dyncf_A_const_253 = A_arbace_a2g_dyncf_A_const_pool.A[482]; A_arbace_a2g_dyncf_A_const_254 = A_arbace_a2g_dyncf_A_const_pool.A[483]; A_arbace_a2g_dyncf_A_const_255 = A_arbace_a2g_dyncf_A_const_pool.A[484]; A_arbace_a2g_dyncf_A_const_256 = A_arbace_a2g_dyncf_A_const_pool.A[485] }

func A_arbace_a2g_dyncf_A_clinit_p18() { A_arbace_a2g_dyncf_A_const_257 = A_arbace_a2g_dyncf_A_const_pool.A[486]; A_arbace_a2g_dyncf_A_const_258 = A_arbace_a2g_dyncf_A_const_pool.A[487]; A_arbace_a2g_dyncf_A_const_259 = A_arbace_a2g_dyncf_A_const_pool.A[488]; A_arbace_a2g_dyncf_A_const_260 = A_arbace_a2g_dyncf_A_const_pool.A[489]; A_arbace_a2g_dyncf_A_const_261 = A_arbace_a2g_dyncf_A_const_pool.A[490]; A_arbace_a2g_dyncf_A_const_262 = A_arbace_a2g_dyncf_A_const_pool.A[491]; A_arbace_a2g_dyncf_A_const_263 = A_arbace_a2g_dyncf_A_const_pool.A[492]; A_arbace_a2g_dyncf_A_const_264 = A_arbace_a2g_dyncf_A_const_pool.A[493]; A_arbace_a2g_dyncf_A_const_265 = A_arbace_a2g_dyncf_A_const_pool.A[494]; A_arbace_a2g_dyncf_A_const_266 = A_arbace_a2g_dyncf_A_const_pool.A[495]; A_arbace_a2g_dyncf_A_const_267 = A_arbace_a2g_dyncf_A_const_pool.A[496]; A_arbace_a2g_dyncf_A_const_268 = A_arbace_a2g_dyncf_A_const_pool.A[497]; A_arbace_a2g_dyncf_A_const_269 = A_arbace_a2g_dyncf_A_const_pool.A[498]; A_arbace_a2g_dyncf_A_const_270 = A_arbace_a2g_dyncf_A_const_pool.A[499]; A_arbace_a2g_dyncf_A_const_271 = A_arbace_a2g_dyncf_A_const_pool.A[500]; A_arbace_a2g_dyncf_A_const_272 = A_arbace_a2g_dyncf_A_const_pool.A[501] }

func A_arbace_a2g_dyncf_A_clinit_p19() { A_arbace_a2g_dyncf_A_const_273 = A_arbace_a2g_dyncf_A_const_pool.A[502]; A_arbace_a2g_dyncf_A_const_274 = A_arbace_a2g_dyncf_A_const_pool.A[503]; A_arbace_a2g_dyncf_A_const_275 = A_arbace_a2g_dyncf_A_const_pool.A[504]; A_arbace_a2g_dyncf_A_const_276 = A_arbace_a2g_dyncf_A_const_pool.A[505]; A_arbace_a2g_dyncf_A_const_277 = A_arbace_a2g_dyncf_A_const_pool.A[506]; A_arbace_a2g_dyncf_A_const_278 = A_arbace_a2g_dyncf_A_const_pool.A[507]; A_arbace_a2g_dyncf_A_const_279 = A_arbace_a2g_dyncf_A_const_pool.A[508]; A_arbace_a2g_dyncf_A_const_280 = A_arbace_a2g_dyncf_A_const_pool.A[509]; A_arbace_a2g_dyncf_A_const_281 = A_arbace_a2g_dyncf_A_const_pool.A[510]; A_arbace_a2g_dyncf_A_const_282 = A_arbace_a2g_dyncf_A_const_pool.A[511]; A_arbace_a2g_dyncf_A_const_283 = A_arbace_a2g_dyncf_A_const_pool.A[512]; A_arbace_a2g_dyncf_A_const_284 = A_arbace_a2g_dyncf_A_const_pool.A[513]; A_arbace_a2g_dyncf_A_const_285 = A_arbace_a2g_dyncf_A_const_pool.A[514]; A_arbace_a2g_dyncf_A_const_286 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[515]); A_arbace_a2g_dyncf_A_const_287 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[516]) }

func A_arbace_a2g_dyncf_A_clinit_p20() { A_arbace_a2g_dyncf_A_const_288 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[517]); A_arbace_a2g_dyncf_A_const_289 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[518]); A_arbace_a2g_dyncf_A_const_290 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[519]); A_arbace_a2g_dyncf_A_const_291 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[520]); A_arbace_a2g_dyncf_A_const_292 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[521]); A_arbace_a2g_dyncf_A_const_293 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[522]); A_arbace_a2g_dyncf_A_const_294 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[523]); A_arbace_a2g_dyncf_A_const_295 = A_arbace_a2g_dyncf_A_const_pool.A[524]; A_arbace_a2g_dyncf_A_const_296 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[525]); A_arbace_a2g_dyncf_A_const_297 = A_arbace_a2g_dyncf_A_const_pool.A[526]; A_arbace_a2g_dyncf_A_const_298 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[527]); A_arbace_a2g_dyncf_A_const_299 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[528]) }

func A_arbace_a2g_dyncf_A_clinit_p21() { A_arbace_a2g_dyncf_A_const_300 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[529]); A_arbace_a2g_dyncf_A_const_301 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[530]); A_arbace_a2g_dyncf_A_const_302 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[531]); A_arbace_a2g_dyncf_A_const_303 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[532]); A_arbace_a2g_dyncf_A_const_304 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[533]); A_arbace_a2g_dyncf_A_const_305 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[534]); A_arbace_a2g_dyncf_A_const_306 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[535]); A_arbace_a2g_dyncf_A_const_307 = lang.Keyword_Cast(A_arbace_a2g_dyncf_A_const_pool.A[536]); A_arbace_a2g_dyncf_A_const_308 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[537]); A_arbace_a2g_dyncf_A_const_309 = A_arbace_a2g_dyncf_A_const_pool.A[538]; A_arbace_a2g_dyncf_A_const_310 = A_arbace_a2g_dyncf_A_const_pool.A[539]; A_arbace_a2g_dyncf_A_const_311 = A_arbace_a2g_dyncf_A_const_pool.A[540]; A_arbace_a2g_dyncf_A_const_312 = A_arbace_a2g_dyncf_A_const_pool.A[541] }

func A_arbace_a2g_dyncf_A_clinit_p22() { A_arbace_a2g_dyncf_A_const_313 = A_arbace_a2g_dyncf_A_const_pool.A[542]; A_arbace_a2g_dyncf_A_const_314 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[543]); A_arbace_a2g_dyncf_A_const_315 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[544]); A_arbace_a2g_dyncf_A_const_316 = A_arbace_a2g_dyncf_A_const_pool.A[545]; A_arbace_a2g_dyncf_A_const_317 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[546]); A_arbace_a2g_dyncf_A_const_318 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[547]); A_arbace_a2g_dyncf_A_const_319 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[548]); A_arbace_a2g_dyncf_A_const_320 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[549]); A_arbace_a2g_dyncf_A_const_321 = lang.Var_Cast(A_arbace_a2g_dyncf_A_const_pool.A[550]) }

func A_arbace_a2g_dyncf_A_New() *A_arbace_a2g_dyncf_A { A_arbace_a2g_dyncf_A_Init(); t := &A_arbace_a2g_dyncf_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_dyncf_A) Ctor() {}

func (t *A_arbace_a2g_dyncf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_dyncf_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_dyncf_A_class }

func (t *A_arbace_a2g_dyncf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_dyncf_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_dyncf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_dyncf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_dyncf_A); return ok }

func A_arbace_a2g_dyncf_A_Cast(x any) *A_arbace_a2g_dyncf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_dyncf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_dyncf_A_class)) }; return v }



type A_arbace_a2g_dyncf_enabled_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_eval1117000004_A struct{ jrt.Object }

func A_arbace_a2g_dyncf_eval1117000004_A_New() *A_arbace_a2g_dyncf_eval1117000004_A { t := &A_arbace_a2g_dyncf_eval1117000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_dyncf_eval1117000004_A) Ctor() {}

func (t *A_arbace_a2g_dyncf_eval1117000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_dyncf_eval1117000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_dyncf_eval1117000004_A_class }

func (t *A_arbace_a2g_dyncf_eval1117000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_dyncf_eval1117000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_dyncf_eval1117000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_dyncf_eval1117000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_dyncf_eval1117000004_A); return ok }

func A_arbace_a2g_dyncf_eval1117000004_A_Cast(x any) *A_arbace_a2g_dyncf_eval1117000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_dyncf_eval1117000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_dyncf_eval1117000004_A_class)) }; return v }



type A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_eval1117000004_loading__1927001464__auto____1117000005_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_eval1117000008_A struct{ jrt.Object }

func A_arbace_a2g_dyncf_eval1117000008_A_New() *A_arbace_a2g_dyncf_eval1117000008_A { t := &A_arbace_a2g_dyncf_eval1117000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_dyncf_eval1117000008_A) Ctor() {}

func (t *A_arbace_a2g_dyncf_eval1117000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_dyncf_eval1117000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_dyncf_eval1117000008_A_class }

func (t *A_arbace_a2g_dyncf_eval1117000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_dyncf_eval1117000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_dyncf_eval1117000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_dyncf_eval1117000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_dyncf_eval1117000008_A); return ok }

func A_arbace_a2g_dyncf_eval1117000008_A_Cast(x any) *A_arbace_a2g_dyncf_eval1117000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_dyncf_eval1117000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_dyncf_eval1117000008_A_class)) }; return v }



type A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_eval1117000008_fn__1117000009_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_forms_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_from_object_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_from_object_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_generics_text_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A struct{ a2g_header uint64; F_extendable any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A struct{ a2g_header uint64; F_extendable, F_s__1117000094, F_iter__1117000093 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A struct{ a2g_header uint64; F_extendable any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1117000096 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_fn__1117000100_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A struct{ a2g_header uint64; F_iter__1117000103, F_s__1117000104 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A struct{ a2g_header uint64; F_b__1117000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000103__1117000107_fn__1117000108_fn__1117000109_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A struct{ a2g_header uint64; F_iter__1117000113, F_s__1117000114 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A struct{ a2g_header uint64; F_b__1117000116 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000099_iter__1117000113__1117000117_fn__1117000118_fn__1117000119_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_fn__1117000124_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A struct{ a2g_header uint64; F_iter__1117000127, F_s__1117000128 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A struct{ a2g_header uint64; F_b__1117000130 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000127__1117000131_fn__1117000132_fn__1117000133_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A struct{ a2g_header uint64; F_iter__1117000137, F_s__1117000138 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1117000140 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000093__1117000097_fn__1117000098_iter__1117000137__1117000141_fn__1117000142_fn__1117000143_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A struct{ a2g_header uint64; F_iter__1117000149, F_s__1117000150 any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A struct{ a2g_header uint64; F_b__1117000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_dyncf_generics_text_iter__1117000149__1117000153_fn__1117000154_fn__1117000155_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_native_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_native_name_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_strip_anns_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_strip_anns_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_strip_anns_fn__1117000090_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_sub_forms_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A struct{ a2g_header uint64; F_recv, F_n any }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A struct{ a2g_header uint64; F_recv, F_iter__1117000017, F_n, F_s__1117000018 any }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A struct{ a2g_header uint64; F_b__1117000020, F_recv, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000023_fn__1117000030_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000017__1117000021_fn__1117000022_fn__1117000039_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A struct{ a2g_header uint64; F_recv, F_n any }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A struct{ a2g_header uint64; F_recv, F_n, F_s__1117000044, F_iter__1117000043 any }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A struct{ a2g_header uint64; F_recv, F_b__1117000046, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000049_fn__1117000059_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_sub_forms_iter__1117000043__1117000047_fn__1117000048_fn__1117000072_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_sub_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_sub_name_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_subs_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_subs_forms_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A struct{ a2g_header uint64; F_s__1117000079, F_iter__1117000078 any }

var A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A struct{ a2g_header uint64; F_b__1117000081 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_dyncf_subs_forms_iter__1117000078__1117000082_fn__1117000083_fn__1117000084_A_fn_class *jrt.Class



type A_arbace_a2g_dyncf_tag_A struct{ a2g_header uint64 }

var A_arbace_a2g_dyncf_tag_A_fn_class *jrt.Class
