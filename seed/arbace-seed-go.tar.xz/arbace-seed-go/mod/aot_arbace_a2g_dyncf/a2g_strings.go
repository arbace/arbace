//line a2g_strings.ae:1
package aot_arbace_a2g_dyncf

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.walk")

var Lit_7 *jrt.String = jrt.Intern("walk")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_9 *jrt.String = jrt.Intern("t")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_11 *jrt.String = jrt.Intern("a")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_13 *jrt.String = jrt.Intern("m")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_15 *jrt.String = jrt.Intern("nm")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.code")

var Lit_17 *jrt.String = jrt.Intern("c")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.dyn")

var Lit_19 *jrt.String = jrt.Intern("dyn")

var Lit_20 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_21 *jrt.String = jrt.Intern("jrt")

var Lit_22 *jrt.String = jrt.Intern("commute")

var Lit_23 *jrt.String = jrt.Intern("deref")

var Lit_24 *jrt.String = jrt.Intern("conj")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.dyncf")

var Lit_26 *jrt.String = jrt.Intern("doc")

var Lit_27 *jrt.String = jrt.Intern("The natives of Compiler$CFGo (arbace/lang/Compiler.ae), the Go build's host of the class\n  forms at the REPL (doc/go/CLASSFORMS-REPL.md), in arbace/lang's a2g_cf.go: classes made at run\n  time for interpreted classes, over Dyn (A2G-SPEC §5.12, arbace.a2g.dyn): a class extending\n  Object or another interpreted class, implementing interfaces of the world (Dyn's slots) and\n  interfaces made at run time (the class's methods by key); an interface; a Clojure fn's class\n  (objects CF$FnObj). Member tables carry the classes' methods, constructors and fields, with\n  their modifiers, for reflection.")

var Lit_28 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_29 *jrt.String = jrt.Intern("translated?")

var Lit_30 *jrt.String = jrt.Intern("api-class")

var Lit_31 *jrt.String = jrt.Intern("with-meta")

var Lit_32 *jrt.String = jrt.Intern("tag")

var Lit_33 *jrt.String = jrt.Intern("symbol")

var Lit_34 *jrt.String = jrt.Intern("go-name")

var Lit_35 *jrt.String = jrt.Intern("method-base")

var Lit_36 *jrt.String = jrt.Intern("prim?")

var Lit_37 *jrt.String = jrt.Intern("list")

var Lit_38 *jrt.String = jrt.Intern("else")

var Lit_39 *jrt.String = jrt.Intern("assert")

var Lit_40 *jrt.String = jrt.Intern("go-type")

var Lit_41 *jrt.String = jrt.Intern("lang")

var Lit_42 *jrt.String = jrt.Intern("dynUnbox")

var Lit_43 *jrt.String = jrt.Intern("prim-desc->name")

var Lit_44 *jrt.String = jrt.Intern("inst")

var Lit_45 *jrt.String = jrt.Intern("As")

var Lit_46 *jrt.String = jrt.Intern("sub-name")

var Lit_47 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_48 *jrt.String = jrt.Intern("*")

var Lit_49 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_50 *jrt.String = jrt.Intern("hash-map")

var Lit_51 *jrt.String = jrt.Intern("*f*")

var Lit_52 *jrt.String = jrt.Intern("pkg")

var Lit_53 *jrt.String = jrt.Intern("go")

var Lit_54 *jrt.String = jrt.Intern("func")

var Lit_55 *jrt.String = jrt.Intern("hand-written?")

var Lit_56 *jrt.String = jrt.Intern("trivial-init?")

var Lit_57 *jrt.String = jrt.Intern("do")

var Lit_58 *jrt.String = jrt.Intern("line")

var Lit_59 *jrt.String = jrt.Intern("column")

var Lit_60 *jrt.String = jrt.Intern("any")

var Lit_61 *jrt.String = jrt.Intern("dc")

var Lit_62 *jrt.String = jrt.Intern("DynClass")

var Lit_63 *jrt.String = jrt.Intern("f")

var Lit_64 *jrt.String = jrt.Intern("slice")

var Lit_65 *jrt.String = jrt.Intern("class-sym")

var Lit_66 *jrt.String = jrt.Intern("let")

var Lit_67 *jrt.String = jrt.Intern("set!")

var Lit_68 *jrt.String = jrt.Intern(".-Self")

var Lit_69 *jrt.String = jrt.Intern(".MarkDynamic")

var Lit_70 *jrt.String = jrt.Intern("addr")

var Lit_71 *jrt.String = jrt.Intern("lit")

var Lit_72 *jrt.String = jrt.Intern("dynCore")

var Lit_73 *jrt.String = jrt.Intern("D")

var Lit_74 *jrt.String = jrt.Intern("F")

var Lit_75 *jrt.String = jrt.Intern("var")

var Lit_76 *jrt.String = jrt.Intern("apply")

var Lit_77 *jrt.String = jrt.Intern("map")

var Lit_78 *jrt.String = jrt.Intern("string")

var Lit_79 *jrt.String = jrt.Intern("seq")

var Lit_80 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_81 *jrt.String = jrt.Intern("chunk-first")

var Lit_82 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_83 *jrt.String = jrt.Intern("name")

var Lit_84 *jrt.String = jrt.Intern("not")

var Lit_85 *jrt.String = jrt.Intern("mdesc-in-world?")

var Lit_86 *jrt.String = jrt.Intern("contains?")

var Lit_87 *jrt.String = jrt.Intern("desc")

var Lit_88 *jrt.String = jrt.Intern("ctor-real-desc")

var Lit_89 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_90 *jrt.String = jrt.Intern("private?")

var Lit_91 *jrt.String = jrt.Intern("struct-methods")

var Lit_92 *jrt.String = jrt.Intern("ctor-base")

var Lit_93 *jrt.String = jrt.Intern("*w*")

var Lit_94 *jrt.String = jrt.Intern("chunk-append")

var Lit_95 *jrt.String = jrt.Intern("fn")

var Lit_96 *jrt.String = jrt.Intern("o")

var Lit_97 *jrt.String = jrt.Intern("args")

var Lit_98 *jrt.String = jrt.Intern("map-indexed")

var Lit_99 *jrt.String = jrt.Intern("from-object")

var Lit_100 *jrt.String = jrt.Intern("aget")

var Lit_101 *jrt.String = jrt.Intern("chunk-cons")

var Lit_102 *jrt.String = jrt.Intern("first")

var Lit_103 *jrt.String = jrt.Intern("cons")

var Lit_104 *jrt.String = jrt.Intern("chunk")

var Lit_105 *jrt.String = jrt.Intern("chunk-rest")

var Lit_106 *jrt.String = jrt.Intern("rest")

var Lit_107 *jrt.String = jrt.Intern("methods-of")

var Lit_108 *jrt.String = jrt.Intern("methods")

var Lit_109 *jrt.String = jrt.Intern("decl")

var Lit_110 *jrt.String = jrt.Intern("impl-of")

var Lit_111 *jrt.String = jrt.Intern("kind")

var Lit_112 *jrt.String = jrt.Intern("default")

var Lit_113 *jrt.String = jrt.Intern("jrt-impl")

var Lit_114 *jrt.String = jrt.Intern("class")

var Lit_115 *jrt.String = jrt.Intern("promoted")

var Lit_116 *jrt.String = jrt.Intern("owner")

var Lit_117 *jrt.String = jrt.Intern("return")

var Lit_118 *jrt.String = jrt.Intern("Box")

var Lit_119 *jrt.String = jrt.Intern("sort-by")

var Lit_120 *jrt.String = jrt.Intern("vmethods")

var Lit_121 *jrt.String = jrt.Intern("proxy-classes")

var Lit_122 *jrt.String = jrt.Intern("concat")

var Lit_123 *jrt.String = jrt.Intern("mapcat")

var Lit_124 *jrt.String = jrt.Intern("sub-forms")

var Lit_125 *jrt.String = jrt.Intern("cfSubFor")

var Lit_126 *jrt.String = jrt.Intern("results")

var Lit_127 *jrt.String = jrt.Intern("Class")

var Lit_128 *jrt.String = jrt.Intern("switch")

var Lit_129 *jrt.String = jrt.Intern("case")

var Lit_130 *jrt.String = jrt.Intern("subs-forms")

var Lit_131 *jrt.String = jrt.Intern("cfIsInstance")

var Lit_132 *jrt.String = jrt.Intern("cfIsInstance: whether x's class is c or a subclass of c (an interpreted class's objects: Dyn,\nor CF$FnObj, whose getClass is their class).\n")

var Lit_133 *jrt.String = jrt.Intern("x")

var Lit_134 *jrt.String = jrt.Intern("bool")

var Lit_135 *jrt.String = jrt.Intern("when")

var Lit_136 *jrt.String = jrt.Intern("==")

var Lit_137 *jrt.String = jrt.Intern("values")

var Lit_138 *jrt.String = jrt.Intern("_")

var Lit_139 *jrt.String = jrt.Intern("ok")

var Lit_140 *jrt.String = jrt.Intern("Object_I")

var Lit_141 *jrt.String = jrt.Intern("k")

var Lit_142 *jrt.String = jrt.Intern("GetClass")

var Lit_143 *jrt.String = jrt.Intern("while")

var Lit_144 *jrt.String = jrt.Intern("!=")

var Lit_145 *jrt.String = jrt.Intern(".-Super")

var Lit_146 *jrt.String = jrt.Intern(".Info")

var Lit_147 *jrt.String = jrt.Intern("cfNews")

var Lit_148 *jrt.String = jrt.Intern("cfNews: the allocation of the interpreted classes whose objects are DynSub_C (under dynMu).\n")

var Lit_149 *jrt.String = jrt.Intern("make")

var Lit_150 *jrt.String = jrt.Intern("cfInterpreted")

var Lit_151 *jrt.String = jrt.Intern("cfInterpreted: whether c is an interpreted class (made by Compiler$CFGo).\n")

var Lit_152 *jrt.String = jrt.Intern(".Lock")

var Lit_153 *jrt.String = jrt.Intern("dynMu")

var Lit_154 *jrt.String = jrt.Intern("dynClasses")

var Lit_155 *jrt.String = jrt.Intern(".Unlock")

var Lit_156 *jrt.String = jrt.Intern("and")

var Lit_157 *jrt.String = jrt.Intern(".-CF")

var Lit_158 *jrt.String = jrt.Intern("cfGoValue")

var Lit_159 *jrt.String = jrt.Intern("cfGoValue: a field's value (an object) in the member tables' convention: a primitive as its Go\nvalue.\n")

var Lit_160 *jrt.String = jrt.Intern("ftype")

var Lit_161 *jrt.String = jrt.Intern("v")

var Lit_162 *jrt.String = jrt.Intern(".IsPrimitive__Z")

var Lit_163 *jrt.String = jrt.Intern("Unbox")

var Lit_164 *jrt.String = jrt.Intern("a2g")

var Lit_165 *jrt.String = jrt.Intern("comment")

var Lit_166 *jrt.String = jrt.Intern("native-name")

var Lit_167 *jrt.String = jrt.Intern("ifs")

var Lit_168 *jrt.String = jrt.Intern("dynClassList")

var Lit_169 *jrt.String = jrt.Intern("interfaces")

var Lit_170 *jrt.String = jrt.Intern("info")

var Lit_171 *jrt.String = jrt.Intern("ClassInfo")

var Lit_172 *jrt.String = jrt.Intern("Name")

var Lit_173 *jrt.String = jrt.Intern(".String")

var Lit_174 *jrt.String = jrt.Intern("NN")

var Lit_175 *jrt.String = jrt.Intern("Modifiers")

var Lit_176 *jrt.String = jrt.Intern("bit-or")

var Lit_177 *jrt.String = jrt.Intern("flags")

var Lit_178 *jrt.String = jrt.Intern("AccInterface")

var Lit_179 *jrt.String = jrt.Intern("AccAbstract")

var Lit_180 *jrt.String = jrt.Intern("Kind")

var Lit_181 *jrt.String = jrt.Intern("KindInterface")

var Lit_182 *jrt.String = jrt.Intern("Interfaces")

var Lit_183 *jrt.String = jrt.Intern("Go")

var Lit_184 *jrt.String = jrt.Intern("arbace/lang.Dyn (class form interface)")

var Lit_185 *jrt.String = jrt.Intern("DefineDynamic")

var Lit_186 *jrt.String = jrt.Intern(".-IsInstance")

var Lit_187 *jrt.String = jrt.Intern("d")

var Lit_188 *jrt.String = jrt.Intern("dynObject")

var Lit_189 *jrt.String = jrt.Intern(".DynImplements")

var Lit_190 *jrt.String = jrt.Intern("super")

var Lit_191 *jrt.String = jrt.Intern("Object_class")

var Lit_192 *jrt.String = jrt.Intern("KindClass")

var Lit_193 *jrt.String = jrt.Intern("Super")

var Lit_194 *jrt.String = jrt.Intern("arbace/lang.Compiler_CF_FnObj (class form fn)")

var Lit_195 *jrt.String = jrt.Intern("base")

var Lit_196 *jrt.String = jrt.Intern("nw")

var Lit_197 *jrt.String = jrt.Intern("bslots")

var Lit_198 *jrt.String = jrt.Intern("bown")

var Lit_199 *jrt.String = jrt.Intern("dynSubFor")

var Lit_200 *jrt.String = jrt.Intern("panic")

var Lit_201 *jrt.String = jrt.Intern("Thrown")

var Lit_202 *jrt.String = jrt.Intern("UnsupportedOperationException_New_String")

var Lit_203 *jrt.String = jrt.Intern("Str")

var Lit_204 *jrt.String = jrt.Intern("+")

var Lit_205 *jrt.String = jrt.Intern("a class extending ")

var Lit_206 *jrt.String = jrt.Intern(".-Name")

var Lit_207 *jrt.String = jrt.Intern(" is not in the Go build")

var Lit_208 *jrt.String = jrt.Intern("slots")

var Lit_209 *jrt.String = jrt.Intern("arbace/lang.Dyn (class form)")

var Lit_210 *jrt.String = jrt.Intern("Slots")

var Lit_211 *jrt.String = jrt.Intern("IFn")

var Lit_212 *jrt.String = jrt.Intern("len")

var Lit_213 *jrt.String = jrt.Intern("SlotMap")

var Lit_214 *jrt.String = jrt.Intern("Own")

var Lit_215 *jrt.String = jrt.Intern("Ifaces")

var Lit_216 *jrt.String = jrt.Intern("ByKey")

var Lit_217 *jrt.String = jrt.Intern("CF")

var Lit_218 *jrt.String = jrt.Intern("klass")

var Lit_219 *jrt.String = jrt.Intern(".-SlotMap")

var Lit_220 *jrt.String = jrt.Intern("dynSlots")

var Lit_221 *jrt.String = jrt.Intern(".-Slots")

var Lit_222 *jrt.String = jrt.Intern("range")

var Lit_223 *jrt.String = jrt.Intern("i")

var Lit_224 *jrt.String = jrt.Intern("dynAddInterface")

var Lit_225 *jrt.String = jrt.Intern("s")

var Lit_226 *jrt.String = jrt.Intern(".-Interfaces")

var Lit_227 *jrt.String = jrt.Intern(".-Cls")

var Lit_228 *jrt.String = jrt.Intern("aset")

var Lit_229 *jrt.String = jrt.Intern("String")

var Lit_230 *jrt.String = jrt.Intern("RefArray")

var Lit_231 *jrt.String = jrt.Intern("int32")

var Lit_232 *jrt.String = jrt.Intern("dynClassOf")

var Lit_233 *jrt.String = jrt.Intern(".-A")

var Lit_234 *jrt.String = jrt.Intern("newDyn")

var Lit_235 *jrt.String = jrt.Intern("or")

var Lit_236 *jrt.String = jrt.Intern("ctors")

var Lit_237 *jrt.String = jrt.Intern("constructor ")

var Lit_238 *jrt.String = jrt.Intern("supers")

var Lit_239 *jrt.String = jrt.Intern("key")

var Lit_240 *jrt.String = jrt.Intern("super call of ")

var Lit_241 *jrt.String = jrt.Intern(".")

var Lit_242 *jrt.String = jrt.Intern(".-Declaring")

var Lit_243 *jrt.String = jrt.Intern("outer")

var Lit_244 *jrt.String = jrt.Intern("simple")

var Lit_245 *jrt.String = jrt.Intern(".-Simple")

var Lit_246 *jrt.String = jrt.Intern(".-Methods")

var Lit_247 *jrt.String = jrt.Intern(".-Ctors")

var Lit_248 *jrt.String = jrt.Intern(".-Fields")

var Lit_249 *jrt.String = jrt.Intern("ClearReflectionCaches")

var Lit_250 *jrt.String = jrt.Intern(".-Kind")

var Lit_251 *jrt.String = jrt.Intern("KindEnum")

var Lit_252 *jrt.String = jrt.Intern(".-Enum")

var Lit_253 *jrt.String = jrt.Intern(".Invoke__O")

var Lit_254 *jrt.String = jrt.Intern(".DynClassOf")

var Lit_255 *jrt.String = jrt.Intern("ps")

var Lit_256 *jrt.String = jrt.Intern("params")

var Lit_257 *jrt.String = jrt.Intern("bit-and")

var Lit_258 *jrt.String = jrt.Intern("AccStatic")

var Lit_259 *jrt.String = jrt.Intern("append")

var Lit_260 *jrt.String = jrt.Intern("MethodInfo")

var Lit_261 *jrt.String = jrt.Intern("Params")

var Lit_262 *jrt.String = jrt.Intern("Return")

var Lit_263 *jrt.String = jrt.Intern("ret")

var Lit_264 *jrt.String = jrt.Intern("Invoke")

var Lit_265 *jrt.String = jrt.Intern("this")

var Lit_266 *jrt.String = jrt.Intern("dynConvert")

var Lit_267 *jrt.String = jrt.Intern("dynCall")

var Lit_268 *jrt.String = jrt.Intern("impl")

var Lit_269 *jrt.String = jrt.Intern("(")

var Lit_270 *jrt.String = jrt.Intern("p")

var Lit_271 *jrt.String = jrt.Intern(".Descriptor")

var Lit_272 *jrt.String = jrt.Intern(")")

var Lit_273 *jrt.String = jrt.Intern(".-ByKey")

var Lit_274 *jrt.String = jrt.Intern("dynOf")

var Lit_275 *jrt.String = jrt.Intern("dynAbstract")

var Lit_276 *jrt.String = jrt.Intern("'")

var Lit_277 *jrt.String = jrt.Intern("' of ")

var Lit_278 *jrt.String = jrt.Intern("CtorInfo")

var Lit_279 *jrt.String = jrt.Intern("New")

var Lit_280 *jrt.String = jrt.Intern("FieldInfo")

var Lit_281 *jrt.String = jrt.Intern("Type")

var Lit_282 *jrt.String = jrt.Intern("Get")

var Lit_283 *jrt.String = jrt.Intern(".DynFields")

var Lit_284 *jrt.String = jrt.Intern("Set")

var Lit_285 *jrt.String = jrt.Intern(".-Init")

var Lit_286 *jrt.String = jrt.Intern("init")

var Lit_287 *jrt.String = jrt.Intern("store")

var Lit_288 *jrt.String = jrt.Intern("postwalk")

var Lit_289 *jrt.String = jrt.Intern("map?")

var Lit_290 *jrt.String = jrt.Intern("anns")

var Lit_291 *jrt.String = jrt.Intern("dissoc")

var Lit_292 *jrt.String = jrt.Intern("set")

var Lit_293 *jrt.String = jrt.Intern("interface?")

var Lit_294 *jrt.String = jrt.Intern("class-generics")

var Lit_295 *jrt.String = jrt.Intern("vec")

var Lit_296 *jrt.String = jrt.Intern("some")

var Lit_297 *jrt.String = jrt.Intern("anon")

var Lit_298 *jrt.String = jrt.Intern("local")

var Lit_299 *jrt.String = jrt.Intern("nesting")

var Lit_300 *jrt.String = jrt.Intern("tparams")

var Lit_301 *jrt.String = jrt.Intern("remove")

var Lit_302 *jrt.String = jrt.Intern("nil?")

var Lit_303 *jrt.String = jrt.Intern("comp")

var Lit_304 *jrt.String = jrt.Intern("strip-anns")

var Lit_305 *jrt.String = jrt.Intern("assoc")

var Lit_306 *jrt.String = jrt.Intern("select-keys")

var Lit_307 *jrt.String = jrt.Intern("bounds")

var Lit_308 *jrt.String = jrt.Intern("join")

var Lit_309 *jrt.String = jrt.Intern("sub-supers")

var Lit_310 *jrt.String = jrt.Intern("arbace/lang/AFunction")

var Lit_311 *jrt.String = jrt.Intern("arbace/lang/RestFn")

var Lit_312 *jrt.String = jrt.Intern("sort")

var Lit_313 *jrt.String = jrt.Intern("*print-length*")

var Lit_314 *jrt.String = jrt.Intern("*print-level*")

var Lit_315 *jrt.String = jrt.Intern("*print-meta*")

var Lit_316 *jrt.String = jrt.Intern("pr-str")

var Lit_317 *jrt.String = jrt.Intern("arbace.a2g.dyncf$enabled_QMARK_")

var Lit_318 *jrt.String = jrt.Intern("arbace.a2g.dyncf$eval1117000004$loading__1927001464__auto____1117000005")

var Lit_319 *jrt.String = jrt.Intern("arbace.a2g.dyncf$eval1117000008$fn__1117000009")

var Lit_320 *jrt.String = jrt.Intern("arbace.a2g.dyncf$forms")

var Lit_321 *jrt.String = jrt.Intern("---- the class forms at the REPL: Compiler$CFGo's natives (doc/go/CLASSFORMS-REPL.md)")

var Lit_322 *jrt.String = jrt.Intern("defineClass")

var Lit_323 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Class;[Ljava/lang/Class;IILjava/lang/Object;)Ljava/lang/Class;")

var Lit_324 *jrt.String = jrt.Intern("alloc")

var Lit_325 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_326 *jrt.String = jrt.Intern("canExtend")

var Lit_327 *jrt.String = jrt.Intern("(Ljava/lang/Class;)Z")

var Lit_328 *jrt.String = jrt.Intern("superCtor")

var Lit_329 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V")

var Lit_330 *jrt.String = jrt.Intern("superCall")

var Lit_331 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_332 *jrt.String = jrt.Intern("setOuter")

var Lit_333 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V")

var Lit_334 *jrt.String = jrt.Intern("clearMembers")

var Lit_335 *jrt.String = jrt.Intern("(Ljava/lang/Class;)V")

var Lit_336 *jrt.String = jrt.Intern("setEnum")

var Lit_337 *jrt.String = jrt.Intern("(Ljava/lang/Class;Larbace/lang/IFn;)V")

var Lit_338 *jrt.String = jrt.Intern("klassOf")

var Lit_339 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_340 *jrt.String = jrt.Intern("setMethod")

var Lit_341 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;ILarbace/lang/IFn;)V")

var Lit_342 *jrt.String = jrt.Intern("addCtor")

var Lit_343 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Class;ILarbace/lang/IFn;)V")

var Lit_344 *jrt.String = jrt.Intern("addField")

var Lit_345 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;II)V")

var Lit_346 *jrt.String = jrt.Intern("addStatic")

var Lit_347 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;I[Ljava/lang/Object;ILarbace/lang/IFn;)V")

var Lit_348 *jrt.String = jrt.Intern("arbace.a2g.dyncf$from_object")

var Lit_349 *jrt.String = jrt.Intern("jrt/Prim_")

var Lit_350 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_351 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text")

var Lit_352 *jrt.String = jrt.Intern(";; Written by a2g --program (arbace.a2g.dyncf/generics-text): the generic signatures of the\n")

var Lit_353 *jrt.String = jrt.Intern(";; classes of the world, for the class forms' analysis (doc/go/CLASSFORMS-REPL.md).\n{")

var Lit_354 *jrt.String = jrt.Intern("}\n")

var Lit_355 *jrt.String = jrt.Intern("\n ")

var Lit_356 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097")

var Lit_357 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098")

var Lit_358 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099")

var Lit_359 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$fn__1117000100")

var Lit_360 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000103__1117000107")

var Lit_361 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000103__1117000107$fn__1117000108")

var Lit_362 *jrt.String = jrt.Intern("<init>")

var Lit_363 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000103__1117000107$fn__1117000108$fn__1117000109")

var Lit_364 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000113__1117000117")

var Lit_365 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000113__1117000117$fn__1117000118")

var Lit_366 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000113__1117000117$fn__1117000118$fn__1117000119")

var Lit_367 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000124")

var Lit_368 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000127__1117000131")

var Lit_369 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000127__1117000131$fn__1117000132")

var Lit_370 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000127__1117000131$fn__1117000132$fn__1117000133")

var Lit_371 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000137__1117000141")

var Lit_372 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000137__1117000141$fn__1117000142")

var Lit_373 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000137__1117000141$fn__1117000142$fn__1117000143")

var Lit_374 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000149__1117000153")

var Lit_375 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000149__1117000153$fn__1117000154")

var Lit_376 *jrt.String = jrt.Intern(" ")

var Lit_377 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000149__1117000153$fn__1117000154$fn__1117000155")

var Lit_378 *jrt.String = jrt.Intern("arbace.a2g.dyncf$native_name")

var Lit_379 *jrt.String = jrt.Intern("_native")

var Lit_380 *jrt.String = jrt.Intern("arbace.a2g.dyncf$strip_anns")

var Lit_381 *jrt.String = jrt.Intern("arbace.a2g.dyncf$strip_anns$fn__1117000090")

var Lit_382 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms")

var Lit_383 *jrt.String = jrt.Intern("dynCfNew_")

var Lit_384 *jrt.String = jrt.Intern("_Init")

var Lit_385 *jrt.String = jrt.Intern("dynCfCtors_")

var Lit_386 *jrt.String = jrt.Intern("dynCfSupers_")

var Lit_387 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021")

var Lit_388 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022")

var Lit_389 *jrt.String = jrt.Intern(".-")

var Lit_390 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022$fn__1117000023")

var Lit_391 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022$fn__1117000023$fn__1117000030")

var Lit_392 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022$fn__1117000039")

var Lit_393 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047")

var Lit_394 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048")

var Lit_395 *jrt.String = jrt.Intern(".Impl_")

var Lit_396 *jrt.String = jrt.Intern("V")

var Lit_397 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048$fn__1117000049")

var Lit_398 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048$fn__1117000049$fn__1117000059")

var Lit_399 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048$fn__1117000072")

var Lit_400 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_name")

var Lit_401 *jrt.String = jrt.Intern("DynSub_")

var Lit_402 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms")

var Lit_403 *jrt.String = jrt.Intern("cfSubFor: the allocation, constructors and implementations of superclass c of the world\n(nil: c has no DynSub type).\n")

var Lit_404 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms$iter__1117000078__1117000082")

var Lit_405 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms$iter__1117000078__1117000082$fn__1117000083")

var Lit_406 *jrt.String = jrt.Intern("_class")

var Lit_407 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms$iter__1117000078__1117000082$fn__1117000083$fn__1117000084")

var Lit_408 *jrt.String = jrt.Intern("arbace.a2g.dyncf$tag")

var Lit_409 *jrt.String = jrt.Intern("in-ns")

var Lit_410 *jrt.String = jrt.Intern("file")

var Lit_411 *jrt.String = jrt.Intern("arbace/a2g/dyncf.ae")

var Lit_412 *jrt.String = jrt.Intern("enabled?")

var Lit_413 *jrt.String = jrt.Intern("arglists")

var Lit_414 *jrt.String = jrt.Intern("Is the class forms' host in this world (translated)?")

var Lit_415 *jrt.String = jrt.Intern("private")

var Lit_416 *jrt.String = jrt.Intern("sym")

var Lit_417 *jrt.String = jrt.Intern("type")

var Lit_418 *jrt.String = jrt.Intern("mname")

var Lit_419 *jrt.String = jrt.Intern("n")

var Lit_420 *jrt.String = jrt.Intern("The Java object x (an interpreter's argument) as the Go value of descriptor d.")

var Lit_421 *jrt.String = jrt.Intern("dynCfNew_G, dynCfCtors_G, dynCfSupers_G of class n.")

var Lit_422 *jrt.String = jrt.Intern("T")

var Lit_423 *jrt.String = jrt.Intern("The forms of the superclasses of the world, and cfSubFor (nil when c has none).")

var Lit_424 *jrt.String = jrt.Intern("forms")

var Lit_425 *jrt.String = jrt.Intern("The forms of a2g_cf.go (package arbace/lang).")

var Lit_426 *jrt.String = jrt.Intern("generics-text")

var Lit_427 *jrt.String = jrt.Intern("The generic view (class-generics) of the classes of T that are generic or have generic\n  supertypes, as text read by arbace.classes.go/generics: {internal-name {:tparams [sym]\n  :supers [tnode] :methods [...]}}, methods only for generic classes (the others' come from\n  reflection).")

var Lit_428 *jrt.String = jrt.Intern("arbace/lang/Compiler$CFGo")
