//line a2g_strings.ae:1
package aot_arbace_a2g_dyncf

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn11,arbace.walkyn4,walkyn20,arbace.classes.typesyn1,tyn22,arbace.classes.analyzeyn1,ayn16,arbace.a2g.modelyn1,myn16,arbace.a2g.namesyn2,nmyn15,arbace.a2g.codeyn1,cyn14,arbace.a2g.dynyn3,dynyn14,arbace.a2g.jrtyn3,jrtkn3,dockn3,tagkn4,elseyn6,assertkn4,langyn8,dynUnboxyn4,instys3,jrt2,Asyn1,*kn3,pkgys2,go4,funcyn2,dokn4,linekn6,columnyn3,anyyn2,dcyn8,DynClassyn1,fyn5,sliceyn3,letyn4,set!yn6,.-Selfyn12,.MarkDynamicyn4,addryn3,litkn7,dynCoreyn7,dynCorekn1,Dkn1,Fys2,go3,varyn3,mapyn6,stringyn4,funckn4,namekn4,desckn3,jrtyn2,fnyn1,oyn4,argsyn4,agetkn7,methodskn4,kindkn7,defaultkn8,jrt-implkn5,classkn8,promotedkn5,owneryn6,returnys3,jrt3,Boxyn8,cfSubForkn7,resultsys3,jrt5,Classyn6,switchyn4,caseyn12,cfIsInstanceyn4,boolyn4,whenyn2,==yn1,xyn6,valuesyn1,_yn2,okys3,jrt8,Object_Iyn3,notyn1,kys3,jrt8,GetClassyn5,whileyn2,!=yn7,.-Superyn5,.Infoyn4,makeyn13,cfInterpretedyn5,.Lockyn5,dynMuyn10,dynClassesyn7,.Unlockyn3,andyn4,.-CFyn9,cfGoValueyn15,.IsPrimitive__Zyn5,ftypeyn1,vys3,jrt5,Unboxys3,a2g7,commentyn3,ifsyn12,dynClassListyn10,interfacesyn4,kindyn4,infoys3,jrt9,ClassInfokn4,Nameyn7,.Stringys3,jrt2,NNyn4,namekn9,Modifiersyn6,bit-oryn5,flagsys3,jrt12,AccInterfaceys3,jrt11,AccAbstractkn4,Kindys3,jrt13,KindInterfacekn10,Interfaceskn2,Goys3,jrt13,DefineDynamicyn12,.-IsInstanceyn1,dyn9,dynObjectyn14,.DynImplementsyn5,superys3,jrt12,Object_classys3,jrt9,KindClasskn5,Superyn4,baseyn2,nwyn6,bslotsyn4,bownyn9,dynSubForyn5,panicys3,jrt6,Thrownys3,jrt40,UnsupportedOperationException_New_Stringys3,jrt3,Stryn1,+yn6,.-Nameyn5,slotskn5,Slotsyn3,IFnyn3,lenkn7,SlotMapkn3,Ownkn6,Ifaceskn5,ByKeykn2,CFyn5,klassyn9,.-SlotMapyn8,dynSlotsyn7,.-Slotsyn5,rangeyn1,iyn15,dynAddInterfaceyn1,syn12,.-Interfacesyn5,.-Clsyn4,asetyn6,cfNewsys3,jrt6,Stringys3,jrt8,RefArrayyn5,int32yn10,dynClassOfyn3,.-Ayn6,newDynyn2,oryn5,ctorsyn4,descyn6,supersyn3,keyyn11,.-Declaringyn5,outeryn6,simpleyn8,.-Simpleyn9,.-Methodsyn7,.-Ctorsyn8,.-Fieldsys3,jrt21,ClearReflectionCachesyn6,.-Kindys3,jrt8,KindEnumyn6,.-Enumyn10,.Invoke__Oyn11,.DynClassOfyn2,psyn6,paramsyn7,bit-andys3,jrt9,AccStaticyn6,appendys3,jrt10,MethodInfokn6,Paramskn6,Returnyn3,retkn6,Invokeyn10,dynConvertyn7,dynCallyn4,implyn1,pyn11,.Descriptoryn7,.-ByKeyyn5,dynOfyn4,thisyn11,dynAbstractys3,jrt8,CtorInfokn3,Newys3,jrt9,FieldInfokn4,Typekn3,Getys11,arbace.core5,derefyn10,.DynFieldskn3,Setyn6,.-Inityn4,inityn5,storekn4,annskn5,flagskn4,anonkn5,localkn7,nestingkn7,tparamskn6,superskn4,argskn5,ctorskn6,paramskn6,boundsv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.a2g.dyncfm2,R20,s596,The natives of Compiler$CFGo (arbace/lang/Compiler.ae), the Go build's host of the class\n  forms at the REPL (doc/go/CLASSFORMS-REPL.md), in arbace/lang's a2g_cf.go: classes made at run\n  time for interpreted classes, over Dyn (A2G-SPEC §5.12, arbace.a2g.dyn): a class extending\n  Object or another interpreted class, implementing interfaces of the world (Dyn's slots) and\n  interfaces made at run time (the class's methods by key); an interface; a Clojure fn's class\n  (objects CF$FnObj). Member tables carry the classes' methods, constructors and fields, with\n  their modifiers, for reflection.v11,arbace.core13,*loaded-libs*v16,arbace.a2g.model11,translated?v16,arbace.a2g.dyncf9,api-classv11,arbace.core9,with-metaR21,v11,arbace.core6,symbolv16,arbace.a2g.model7,go-namev16,arbace.a2g.names11,method-basev20,arbace.classes.types5,prim?v11,arbace.core4,listR22,R23,v16,arbace.a2g.model7,go-typeR24,R25,v20,arbace.classes.types15,prim-desc->nameR26,R27,v16,arbace.a2g.dyncf8,sub-namev11,arbace.core19,pop-thread-bindingsR28,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv15,arbace.a2g.code3,*f*m2,R29,R24,R30,v16,arbace.a2g.model13,hand-written?v16,arbace.a2g.model13,trivial-init?ML1,R31,m4,R32,i57,R33,i17,m2,R21,R34,v16,arbace.a2g.dyncf3,tagR35,ML2,R28,R36,m4,R32,i55,R33,i74,R37,ML2,R38,R34,m4,R32,i55,R33,i97,v16,arbace.a2g.model9,class-symR39,ML3,R40,ML2,R41,R7,m4,R32,i60,R33,i27,R7,m4,R32,i60,R33,i21,ML2,R42,R7,m4,R32,i62,R33,i21,R7,R7,R43,R44,R45,ML6,R44,R46,R47,R35,R48,R37,m4,R32,i59,R33,i73,R49,v11,arbace.core5,applyML3,R50,R51,ML2,R52,V2,R34,ML2,R38,R34,m4,R32,i64,R33,i82,m4,R32,i64,R33,i71,m4,R32,i64,R33,i59,R44,ML3,R50,R51,ML2,R52,V2,R34,ML2,R38,R34,m4,R32,i65,R33,i55,m4,R32,i65,R33,i44,m4,R32,i65,R33,i32,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferR53,v11,arbace.core3,notv16,arbace.a2g.model15,mdesc-in-world?v11,arbace.core9,contains?R54,v22,arbace.classes.analyze14,ctor-real-descv20,arbace.classes.types17,parse-method-descv16,arbace.a2g.model8,private?v14,arbace.a2g.jrt14,struct-methodsv16,arbace.a2g.names9,ctor-baseR55,v16,arbace.a2g.model3,*w*v11,arbace.core12,chunk-appendR56,R57,R34,R58,ML2,R38,R34,m4,R32,i75,R33,i61,R39,R7,R23,R57,R7,v11,arbace.core11,map-indexedR7,v16,arbace.a2g.dyncf11,from-objectR59,R58,v11,arbace.core10,chunk-consv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv16,arbace.a2g.model10,methods-ofR60,v22,arbace.classes.analyze4,declR49,ML3,R50,R51,ML3,R52,V2,R34,ML2,R38,R34,m4,R32,i80,R33,i83,V1,R34,m4,R32,i80,R33,i72,m4,R32,i80,R33,i60,R44,ML3,R50,R51,ML3,R52,V2,R34,ML2,R38,R34,m4,R32,i81,R33,i55,V1,R34,m4,R32,i81,R33,i44,m4,R32,i81,R33,i32,v16,arbace.a2g.model7,impl-ofR61,R62,R63,R64,R65,R59,R58,R7,R66,R7,R7,R7,R56,m2,R21,R34,R57,R34,R58,ML2,R38,R34,m4,R32,i95,R33,i72,R39,R7,R23,R57,R31,ML2,R67,nm4,R32,i98,R33,i54,R67,R68,m2,R21,R34,v11,arbace.core7,sort-byv16,arbace.a2g.model8,vmethodsv14,arbace.a2g.dyn13,proxy-classesv11,arbace.core6,concatv11,arbace.core6,mapcatv16,arbace.a2g.dyncf9,sub-formsR30,R69,R70,V3,ML3,R52,V2,ML2,R28,R36,m4,R32,i111,R33,i32,ML2,R38,R34,m4,R32,i111,R33,i45,V1,R34,m4,R32,i111,R33,i25,ML3,R50,R51,ML2,R52,V2,R34,ML2,R38,R34,m4,R32,i111,R33,i88,m4,R32,i111,R33,i77,m4,R32,i111,R33,i65,ML3,R50,R51,ML3,R52,V2,R34,ML2,R38,R34,m4,R32,i112,R33,i48,V1,R34,m4,R32,i112,R33,i37,m4,R32,i112,R33,i25,ML4,R67,nnnm4,R32,i118,R33,i15,R15,ML2,R28,R71,m4,R32,i110,R33,i24,R72,R15,R73,R67,v16,arbace.a2g.dyncf10,subs-formsML8,R30,R74,s139,cfIsInstance: whether x's class is c or a subclass of c (an interpreted class's objects: Dyn,\nor CF$FnObj, whose getClass is their class).\nMV2,Myn1,cm2,R21,ML2,R28,R71,m4,R32,i129,R33,i21,Myn1,xm2,R21,R34,m2,R21,R75,ML3,R76,ML3,R77,R78,nm4,R32,i130,R33,i13,ML2,R67,Fm4,R32,i130,R33,i24,m4,R32,i130,R33,i7,ML3,R39,V2,ML3,R79,R80,R81,m4,R32,i131,R33,i13,ML3,R23,R82,R78,m4,R32,i131,R33,i27,ML3,R76,ML2,R83,R81,m4,R32,i132,R33,i15,ML2,R67,Fm4,R32,i132,R33,i24,m4,R32,i132,R33,i9,m4,R32,i131,R33,i7,ML3,R39,V2,R84,ML2,R85,R78,m4,R32,i133,R33,i15,ML4,R86,ML3,R87,R84,nm4,R32,i134,R33,i16,ML3,R76,ML3,R77,R84,R15,m4,R32,i135,R33,i17,ML2,R67,Tm4,R32,i135,R33,i26,m4,R32,i135,R33,i11,ML3,R40,R84,ML2,R88,ML2,R89,R84,m4,R32,i136,R33,i28,m4,R32,i136,R33,i19,m4,R32,i136,R33,i11,m4,R32,i134,R33,i9,m4,R32,i133,R33,i7,Fm4,R32,i126,R33,i5,ML3,R49,Myn6,cfNewsm4,R21,ML3,R50,ML2,R28,R71,m4,R32,i194,R33,i25,ML3,R52,V2,ML2,R28,R36,m4,R32,i194,R33,i46,ML2,R38,R34,m4,R32,i194,R33,i59,V1,R34,m4,R32,i194,R33,i39,m4,R32,i194,R33,i20,R20,s92,cfNews: the allocation of the interpreted classes whose objects are DynSub_C (under dynMu).\nML2,R90,ML3,R50,ML2,R28,R71,m4,R32,i196,R33,i25,ML3,R52,V2,ML2,R28,R36,m4,R32,i196,R33,i46,ML2,R38,R34,m4,R32,i196,R33,i59,V1,R34,m4,R32,i196,R33,i39,m4,R32,i196,R33,i20,m4,R32,i196,R33,i14,m4,R32,i194,R33,i5,ML6,R30,R91,s74,cfInterpreted: whether c is an interpreted class (made by Compiler$CFGo).\nMV1,Myn1,cm2,R21,ML2,R28,R71,m4,R32,i198,R33,i21,m2,R21,R75,ML2,R92,R93,m4,R32,i199,R33,i7,ML4,R39,V2,ML3,R79,R35,R81,m4,R32,i200,R33,i13,ML3,R59,R94,R15,m4,R32,i200,R33,i28,ML2,R95,R93,m4,R32,i201,R33,i9,ML3,R96,R81,ML3,R87,ML2,R97,R35,m4,R32,i202,R33,i21,nm4,R32,i202,R33,i17,m4,R32,i202,R33,i9,m4,R32,i200,R33,i7,m4,R32,i197,R33,i5,ML6,R30,R98,s102,cfGoValue: a field's value (an object) in the member tables' convention: a primitive as its Go\nvalue.\nMV2,Myn5,ftypem2,R21,ML2,R28,R71,m4,R32,i321,R33,i20,Myn1,vm2,R21,R34,m2,R21,R34,ML3,R76,ML3,R96,ML2,R99,R100,m4,R32,i322,R33,i18,ML3,R87,R101,nm4,R32,i322,R33,i42,m4,R32,i322,R33,i13,ML3,R39,V2,ML3,R79,R78,R81,m4,R32,i323,R33,i15,ML3,R102,R100,R101,m4,R32,i323,R33,i29,ML3,R76,R81,ML2,R67,R78,m4,R32,i324,R33,i20,m4,R32,i324,R33,i11,m4,R32,i323,R33,i9,m4,R32,i322,R33,i7,R101,m4,R32,i318,R33,i5,R103,R30,v16,arbace.a2g.dyncf11,native-nameML6,R39,V2,R104,ML2,R105,R106,m4,R32,i142,R33,i21,ML3,R76,ML3,R77,R107,l1,m4,R32,i143,R33,i19,ML4,R39,V4,R108,ML2,R43,ML12,R44,R109,R110,ML2,R111,ML2,R112,R113,m4,R32,i144,R33,i66,m4,R32,i144,R33,i57,R114,ML4,R115,R116,R117,R118,m4,R32,i145,R33,i48,R119,R120,R121,R104,R122,s38,arbace/lang.Dyn (class form interface)m4,R32,i144,R33,i32,m4,R32,i144,R33,i26,R15,ML2,R123,R108,m4,R32,i148,R33,i23,ML3,R40,ML2,R124,R108,m4,R32,i149,R33,i23,ML3,R56,MV1,Myn1,xm2,R21,R34,m2,R21,R75,ML3,R39,V2,ML3,R79,R125,R81,m4,R32,i151,R33,i31,ML3,R23,R126,R78,m4,R32,i151,R33,i45,ML3,R96,R81,ML3,R127,R125,R15,m4,R32,i152,R33,i35,m4,R32,i152,R33,i27,m4,R32,i151,R33,i25,m4,R32,i150,R33,i23,m4,R32,i149,R33,i17,ML2,R67,R15,m4,R32,i153,R33,i17,m4,R32,i144,R33,i15,m4,R32,i143,R33,i13,ML3,R76,ML3,R77,R128,nm4,R32,i154,R33,i19,ML3,R40,R128,R129,m4,R32,i154,R33,i34,m4,R32,i154,R33,i13,ML3,R76,ML3,R77,R107,l2,m4,R32,i155,R33,i19,ML4,R39,V4,R108,ML2,R43,ML14,R44,R109,R110,ML2,R111,ML2,R112,R113,m4,R32,i156,R33,i66,m4,R32,i156,R33,i57,R114,R116,R119,R130,R131,R128,R121,R104,R122,s45,arbace/lang.Compiler_CF_FnObj (class form fn)m4,R32,i156,R33,i32,m4,R32,i156,R33,i26,R15,ML2,R123,R108,m4,R32,i159,R33,i23,ML3,R40,ML2,R124,R108,m4,R32,i160,R33,i23,ML3,R56,MV1,Myn1,xm2,R21,R34,m2,R21,R75,ML3,R74,R15,R78,m4,R32,i160,R33,i62,m4,R32,i160,R33,i43,m4,R32,i160,R33,i17,ML2,R67,R15,m4,R32,i161,R33,i17,m4,R32,i156,R33,i15,m4,R32,i155,R33,i13,ML4,R39,V2,R132,R128,ML3,R86,ML2,R91,R132,m4,R32,i164,R33,i22,ML3,R40,R132,ML2,R88,ML2,R89,R132,m4,R32,i164,R33,i63,m4,R32,i164,R33,i54,m4,R32,i164,R33,i43,m4,R32,i164,R33,i15,ML4,R39,V4,ML4,R79,R133,R80,R80,m4,R32,i165,R33,i21,ML2,R69,R132,m4,R32,i165,R33,i37,ML4,R79,R134,R80,R135,m4,R32,i166,R33,i21,ML2,R136,R132,m4,R32,i166,R33,i44,ML3,R76,ML3,R96,ML3,R87,R132,R129,m4,R32,i167,R33,i28,ML3,R77,R133,nm4,R32,i167,R33,i55,m4,R32,i167,R33,i23,ML2,R137,ML2,R138,ML2,R139,ML2,R140,ML4,R141,s18,a class extending ML2,R142,ML2,R89,R132,m4,R32,i169,R33,i81,m4,R32,i169,R33,i73,s23, is not in the Go buildm4,R32,i169,R33,i49,m4,R32,i169,R33,i40,m4,R32,i168,R33,i38,m4,R32,i168,R33,i26,m4,R32,i168,R33,i19,m4,R32,i167,R33,i17,ML6,R39,V6,R143,R134,R108,ML2,R43,ML14,R44,R109,R110,ML2,R111,ML2,R112,R113,m4,R32,i171,R33,i64,m4,R32,i171,R33,i55,R114,R116,R119,R130,R131,R128,R121,R104,R122,s28,arbace/lang.Dyn (class form)m4,R32,i171,R33,i30,m4,R32,i171,R33,i24,R35,ML2,R43,ML14,R44,R36,R144,ML3,R90,ML2,R38,R145,m4,R32,i174,R33,i55,ML2,R146,R143,m4,R32,i174,R33,i67,m4,R32,i174,R33,i49,R147,R143,R148,R135,R149,ML2,R90,ML3,R50,ML2,R28,R71,m4,R32,i175,R33,i52,R75,m4,R32,i175,R33,i47,m4,R32,i175,R33,i41,R150,ML2,R90,ML3,R50,R51,R145,m4,R32,i175,R33,i86,m4,R32,i175,R33,i80,R151,R152,m4,R32,i174,R33,i28,m4,R32,i174,R33,i22,ML4,R76,ML3,R77,R133,nm4,R32,i177,R33,i21,ML3,R40,ML2,R153,R35,m4,R32,i178,R33,i23,R154,m4,R32,i178,R33,i17,ML3,R40,ML2,R155,R35,m4,R32,i179,R33,i23,ML3,R90,ML2,R38,R145,m4,R32,i179,R33,i42,ML2,R146,R154,m4,R32,i179,R33,i54,m4,R32,i179,R33,i36,m4,R32,i179,R33,i17,m4,R32,i177,R33,i15,ML3,R156,V3,R80,R157,R104,ML3,R158,R35,R157,m4,R32,i180,R33,i32,m4,R32,i180,R33,i15,ML3,R39,V2,R159,R128,ML4,R86,ML3,R87,R159,nm4,R32,i183,R33,i24,ML3,R156,V3,R80,R157,ML2,R160,ML2,R89,R159,m4,R32,i184,R33,i45,m4,R32,i184,R33,i31,ML3,R158,R35,R157,m4,R32,i184,R33,i57,m4,R32,i184,R33,i19,ML3,R40,R159,ML2,R88,ML2,R89,R159,m4,R32,i185,R33,i36,m4,R32,i185,R33,i27,m4,R32,i185,R33,i19,m4,R32,i183,R33,i17,m4,R32,i182,R33,i15,ML9,R39,V2,R15,ML2,R123,R108,m4,R32,i186,R33,i23,ML3,R40,ML2,R161,R35,m4,R32,i187,R33,i23,R15,m4,R32,i187,R33,i17,ML3,R40,ML2,R124,R108,m4,R32,i188,R33,i23,ML3,R56,MV1,Myn1,xm2,R21,R34,m2,R21,R75,ML3,R74,R15,R78,m4,R32,i188,R33,i62,m4,R32,i188,R33,i43,m4,R32,i188,R33,i17,ML2,R92,R93,m4,R32,i189,R33,i17,ML4,R162,R94,R15,R35,m4,R32,i190,R33,i17,ML3,R76,ML3,R87,R133,nm4,R32,i191,R33,i23,ML4,R162,R163,R15,R133,m4,R32,i191,R33,i35,m4,R32,i191,R33,i17,ML2,R95,R93,m4,R32,i192,R33,i17,R15,m4,R32,i186,R33,i15,m4,R32,i170,R33,i13,m4,R32,i165,R33,i15,m4,R32,i163,R33,i13,m4,R32,i142,R33,i11,m2,R21,ML2,R28,R71,m4,R32,i141,R33,i19,R113,ML2,R28,R164,m4,R32,i139,R33,i34,R128,ML2,R28,R71,m4,R32,i139,R33,i63,R106,ML2,R28,R165,m4,R32,i139,R33,i96,R116,R166,R107,R166,R152,R34,R30,ML4,R39,V2,R35,ML2,R167,R15,m4,R32,i205,R33,i20,ML2,R92,R93,m4,R32,i206,R33,i13,ML5,R39,V2,R133,ML3,R59,R163,R15,m4,R32,i207,R33,i22,ML2,R95,R93,m4,R32,i208,R33,i15,ML3,R76,ML3,R87,R133,nm4,R32,i209,R33,i21,ML2,R67,ML3,R133,R35,ML2,R168,R79,m4,R32,i209,R33,i48,m4,R32,i209,R33,i41,m4,R32,i209,R33,i33,m4,R32,i209,R33,i15,ML3,R169,R35,ML2,R168,R79,m4,R32,i210,R33,i26,m4,R32,i210,R33,i15,m4,R32,i207,R33,i13,m4,R32,i205,R33,i11,m2,R21,R34,R15,ML2,R28,R71,m4,R32,i204,R33,i31,R79,ML2,R28,R165,m4,R32,i204,R33,i60,R30,ML3,R39,V2,ML4,R79,R133,R80,R80,m4,R32,i213,R33,i17,ML2,R69,R15,m4,R32,i213,R33,i33,ML3,R170,ML3,R77,R15,R129,m4,R32,i214,R33,i17,ML3,R87,R133,nm4,R32,i214,R33,i41,m4,R32,i214,R33,i13,m4,R32,i213,R33,i11,m2,R21,R75,R15,ML2,R28,R71,m4,R32,i212,R33,i31,R30,ML4,R39,V4,ML4,R79,R80,R171,R80,m4,R32,i217,R33,i17,ML2,R69,R15,m4,R32,i217,R33,i36,R37,ML3,R59,R171,ML2,R111,ML2,R112,R172,m4,R32,i218,R33,i40,m4,R32,i218,R33,i31,m4,R32,i218,R33,i19,ML3,R76,ML3,R77,R37,nm4,R32,i219,R33,i19,ML2,R137,ML2,R138,ML2,R139,ML2,R140,ML5,R141,s12,constructor ML2,R142,ML2,R89,R15,m4,R32,i221,R33,i71,m4,R32,i221,R33,i63,ML2,R111,R172,m4,R32,i221,R33,i82,s23, is not in the Go buildm4,R32,i221,R33,i45,m4,R32,i221,R33,i36,m4,R32,i220,R33,i34,m4,R32,i220,R33,i22,m4,R32,i220,R33,i15,m4,R32,i219,R33,i13,ML3,R37,R57,ML2,R168,R58,m4,R32,i222,R33,i18,m4,R32,i222,R33,i13,m4,R32,i217,R33,i11,R57,R34,R15,ML2,R28,R71,m4,R32,i216,R33,i34,R172,ML2,R28,R164,m4,R32,i216,R33,i61,R58,ML2,R28,R165,m4,R32,i216,R33,i89,R30,ML4,R39,V4,ML4,R79,R80,R80,R173,m4,R32,i225,R33,i17,ML2,R69,R15,m4,R32,i225,R33,i37,R37,ML3,R59,R173,ML2,R111,ML2,R112,R174,m4,R32,i226,R33,i41,m4,R32,i226,R33,i32,m4,R32,i226,R33,i19,ML3,R76,ML3,R77,R37,nm4,R32,i227,R33,i19,ML2,R137,ML2,R138,ML2,R139,ML2,R140,ML6,R141,s14,super call of ML2,R142,ML2,R89,R15,m4,R32,i229,R33,i73,m4,R32,i229,R33,i65,s1,.ML2,R111,R174,m4,R32,i229,R33,i88,s23, is not in the Go buildm4,R32,i229,R33,i45,m4,R32,i229,R33,i36,m4,R32,i228,R33,i34,m4,R32,i228,R33,i22,m4,R32,i228,R33,i15,m4,R32,i227,R33,i13,ML3,R37,R57,ML2,R168,R58,m4,R32,i230,R33,i18,m4,R32,i230,R33,i13,m4,R32,i225,R33,i11,m2,R21,R34,R57,R34,R15,ML2,R28,R71,m4,R32,i224,R33,i45,R174,ML2,R28,R164,m4,R32,i224,R33,i71,R58,ML2,R28,R165,m4,R32,i224,R33,i99,R30,ML4,R39,V2,R108,ML2,R89,R15,m4,R32,i233,R33,i22,ML3,R40,ML2,R175,R108,m4,R32,i234,R33,i19,R176,m4,R32,i234,R33,i13,ML3,R76,ML3,R87,R177,nm4,R32,i235,R33,i19,ML3,R40,ML2,R178,R108,m4,R32,i235,R33,i41,ML2,R111,R177,m4,R32,i235,R33,i57,m4,R32,i235,R33,i35,m4,R32,i235,R33,i13,m4,R32,i233,R33,i11,R15,ML2,R28,R71,m4,R32,i232,R33,i20,R176,ML2,R28,R71,m4,R32,i232,R33,i48,R177,ML2,R28,R164,m4,R32,i232,R33,i77,R30,ML6,R39,V2,R108,ML2,R89,R15,m4,R32,i241,R33,i22,ML3,R40,ML2,R179,R108,m4,R32,i242,R33,i19,nm4,R32,i242,R33,i13,ML3,R40,ML2,R180,R108,m4,R32,i243,R33,i19,nm4,R32,i243,R33,i13,ML3,R40,ML2,R181,R108,m4,R32,i244,R33,i19,nm4,R32,i244,R33,i13,ML1,R182,m4,R32,i245,R33,i13,m4,R32,i241,R33,i11,R15,ML2,R28,R71,m4,R32,i240,R33,i20,R30,ML4,R39,V2,R108,ML2,R89,R15,m4,R32,i248,R33,i22,ML3,R40,ML2,R183,R108,m4,R32,i249,R33,i19,R184,m4,R32,i249,R33,i13,ML3,R40,ML2,R185,R108,m4,R32,i250,R33,i19,ML3,R56,MV0,m2,R21,ML2,R28,R165,m4,R32,i250,R33,i44,ML3,R23,ML2,R28,R165,m4,R32,i250,R33,i73,ML2,R186,R79,m4,R32,i250,R33,i90,m4,R32,i250,R33,i65,m4,R32,i250,R33,i33,m4,R32,i250,R33,i13,m4,R32,i248,R33,i11,R15,ML2,R28,R71,m4,R32,i247,R33,i20,R79,R145,R30,ML4,R39,V2,ML3,R79,R125,R81,m4,R32,i253,R33,i17,ML3,R23,R126,R57,m4,R32,i253,R33,i31,ML3,R76,ML2,R83,R81,m4,R32,i254,R33,i19,ML2,R67,nm4,R32,i254,R33,i28,m4,R32,i254,R33,i13,ML2,R97,ML2,R187,R125,m4,R32,i255,R33,i19,m4,R32,i255,R33,i13,m4,R32,i253,R33,i11,m2,R21,R34,R57,R34,R30,ML4,R39,V4,R108,ML2,R89,R15,m4,R32,i259,R33,i22,R188,ML2,R105,R189,m4,R32,i260,R33,i20,ML4,R76,ML3,R87,ML3,R190,R116,R191,m4,R32,i261,R33,i23,l0,m4,R32,i261,R33,i19,ML3,R40,ML2,R179,R108,m4,R32,i262,R33,i21,ML3,R192,ML2,R179,R108,m4,R32,i263,R33,i29,ML12,R44,R193,R110,ML2,R111,ML2,R112,R113,m4,R32,i264,R33,i64,m4,R32,i264,R33,i55,R194,R188,R195,R196,R114,R116,R197,ML3,R56,MV2,Myn4,thism2,R21,R34,Myn4,argsm2,R21,ML2,R38,R34,m4,R32,i265,R33,i69,m2,R21,R34,ML3,R198,R196,ML4,R199,R200,nR58,m4,R32,i266,R33,i60,m4,R32,i266,R33,i44,m4,R32,i265,R33,i42,m4,R32,i264,R33,i29,m4,R32,i263,R33,i21,m4,R32,i262,R33,i15,ML1,R67,m4,R32,i267,R33,i15,m4,R32,i261,R33,i13,ML7,R39,V2,R174,ML3,R141,ML2,R111,ML2,R112,R113,m4,R32,i268,R33,i35,m4,R32,i268,R33,i26,s1,(m4,R32,i268,R33,i23,ML3,R156,V3,R80,R201,R188,ML3,R40,R174,ML3,R141,R174,ML2,R202,R201,m4,R32,i269,R33,i48,m4,R32,i269,R33,i41,m4,R32,i269,R33,i31,m4,R32,i269,R33,i15,ML3,R40,R174,ML4,R141,R174,s1,)ML2,R202,ML2,R112,R196,m4,R32,i270,R33,i49,m4,R32,i270,R33,i36,m4,R32,i270,R33,i25,m4,R32,i270,R33,i15,ML2,R92,R93,m4,R32,i272,R33,i15,ML4,R39,V2,ML3,R79,R35,R81,m4,R32,i273,R33,i21,ML3,R59,R94,R15,m4,R32,i273,R33,i36,ML2,R95,R93,m4,R32,i274,R33,i17,ML4,R76,ML3,R96,R81,ML3,R87,R200,nm4,R32,i275,R33,i31,m4,R32,i275,R33,i23,ML3,R39,V2,ML3,R79,R157,R81,m4,R32,i276,R33,i25,ML3,R59,ML2,R153,R35,m4,R32,i276,R33,i45,R174,m4,R32,i276,R33,i39,ML3,R76,R81,ML4,R162,ML2,R155,R35,m4,R32,i277,R33,i36,R157,R200,m4,R32,i277,R33,i30,m4,R32,i277,R33,i21,m4,R32,i276,R33,i19,ML4,R162,ML2,R203,R35,m4,R32,i278,R33,i25,R174,R200,m4,R32,i278,R33,i19,m4,R32,i275,R33,i17,m4,R32,i273,R33,i15,ML3,R40,ML2,R179,R108,m4,R32,i279,R33,i21,ML3,R192,ML2,R179,R108,m4,R32,i280,R33,i29,ML12,R44,R193,R110,ML2,R111,R113,m4,R32,i281,R33,i55,R194,R188,R195,R196,R114,R116,R197,ML3,R56,MV2,Myn4,thism2,R21,R34,Myn4,argsm2,R21,ML2,R38,R34,m4,R32,i282,R33,i69,m2,R21,R34,ML5,R39,V4,R125,ML2,R204,R205,m4,R32,i284,R33,i52,R37,ML3,R59,ML2,R203,ML2,R187,R125,m4,R32,i285,R33,i67,m4,R32,i285,R33,i58,R174,m4,R32,i285,R33,i52,ML3,R76,ML3,R77,R37,nm4,R32,i286,R33,i52,ML3,R40,R37,R200,m4,R32,i286,R33,i63,m4,R32,i286,R33,i46,ML3,R76,ML3,R77,R37,nm4,R32,i287,R33,i52,ML2,R137,ML3,R206,R125,ML5,R141,s1,'ML2,R111,R113,m4,R32,i288,R33,i77,s5,' of ML2,R142,ML2,R89,R15,m4,R32,i288,R33,i108,m4,R32,i288,R33,i100,m4,R32,i288,R33,i70,m4,R32,i288,R33,i55,m4,R32,i288,R33,i48,m4,R32,i287,R33,i46,ML3,R198,R196,ML4,R199,R37,R125,R58,m4,R32,i289,R33,i62,m4,R32,i289,R33,i46,m4,R32,i284,R33,i44,m4,R32,i282,R33,i42,m4,R32,i281,R33,i29,m4,R32,i280,R33,i21,m4,R32,i279,R33,i15,m4,R32,i268,R33,i13,m4,R32,i259,R33,i11,R15,ML2,R28,R71,m4,R32,i257,R33,i20,R113,ML2,R28,R164,m4,R32,i257,R33,i47,R189,ML2,R28,R165,m4,R32,i257,R33,i77,R196,ML2,R28,R71,m4,R32,i257,R33,i106,R116,R166,R200,R145,R30,ML3,R39,V2,R108,ML2,R89,R15,m4,R32,i292,R33,i22,ML3,R40,ML2,R180,R108,m4,R32,i293,R33,i19,ML3,R192,ML2,R180,R108,m4,R32,i294,R33,i27,ML8,R44,R207,R194,ML2,R105,R189,m4,R32,i295,R33,i53,R114,R116,R208,ML3,R56,MV1,Myn4,argsm2,R21,ML2,R38,R34,m4,R32,i296,R33,i54,m2,R21,R34,ML4,R199,R200,nR58,m4,R32,i296,R33,i73,m4,R32,i296,R33,i37,m4,R32,i295,R33,i27,m4,R32,i294,R33,i19,m4,R32,i293,R33,i13,m4,R32,i292,R33,i11,R15,ML2,R28,R71,m4,R32,i291,R33,i20,R189,ML2,R28,R165,m4,R32,i291,R33,i49,R116,R166,R200,R145,R30,ML3,R39,V4,R108,ML2,R89,R15,m4,R32,i299,R33,i22,R84,R157,ML3,R40,ML2,R181,R108,m4,R32,i301,R33,i19,ML3,R192,ML2,R181,R108,m4,R32,i302,R33,i27,ML12,R44,R209,R110,ML2,R111,ML2,R112,R113,m4,R32,i303,R33,i61,m4,R32,i303,R33,i52,R210,R100,R114,R116,R211,ML3,R56,MV1,Myn1,om2,R21,R34,m2,R21,R34,ML3,R98,R100,ML3,R59,ML2,R212,ML2,R213,ML2,R204,R57,m4,R32,i304,R33,i109,m4,R32,i304,R33,i97,m4,R32,i304,R33,i78,R84,m4,R32,i304,R33,i72,m4,R32,i304,R33,i55,m4,R32,i304,R33,i37,R214,ML3,R56,V2,Myn1,om2,R21,R34,Myn1,vm2,R21,R34,ML4,R162,ML2,R212,ML2,R213,ML2,R204,R57,m4,R32,i305,R33,i94,m4,R32,i305,R33,i82,m4,R32,i305,R33,i63,R84,ML2,R68,R101,m4,R32,i305,R33,i108,m4,R32,i305,R33,i57,m4,R32,i305,R33,i37,m4,R32,i303,R33,i27,m4,R32,i302,R33,i19,m4,R32,i301,R33,i13,m4,R32,i299,R33,i11,R15,ML2,R28,R71,m4,R32,i298,R33,i20,R113,ML2,R28,R164,m4,R32,i298,R33,i47,R100,ML2,R28,R71,m4,R32,i298,R33,i76,R116,R166,R157,R166,R30,ML4,R39,V4,R108,ML2,R89,R15,m4,R32,i309,R33,i22,R84,R157,ML3,R76,ML3,R77,ML2,R215,R108,m4,R32,i311,R33,i23,nm4,R32,i311,R33,i19,ML3,R40,ML2,R215,R108,m4,R32,i312,R33,i21,ML3,R56,V0,ML2,R186,R216,m4,R32,i312,R33,i42,m4,R32,i312,R33,i35,m4,R32,i312,R33,i15,m4,R32,i311,R33,i13,ML3,R40,ML2,R181,R108,m4,R32,i313,R33,i19,ML3,R192,ML2,R181,R108,m4,R32,i314,R33,i27,ML12,R44,R209,R110,ML2,R111,ML2,R112,R113,m4,R32,i315,R33,i61,m4,R32,i315,R33,i52,R210,R100,R114,R116,R211,ML4,R56,MV1,Myn1,om2,R21,R34,m2,R21,R34,ML2,R186,R216,m4,R32,i316,R33,i55,ML3,R98,R100,ML3,R59,ML2,R168,R217,m4,R32,i316,R33,i96,R84,m4,R32,i316,R33,i90,m4,R32,i316,R33,i73,m4,R32,i316,R33,i37,R214,ML4,R56,V2,Myn1,om2,R21,R34,Myn1,vm2,R21,R34,ML2,R186,R216,m4,R32,i317,R33,i57,ML4,R162,ML2,R168,R217,m4,R32,i317,R33,i81,R84,ML2,R68,R101,m4,R32,i317,R33,i95,m4,R32,i317,R33,i75,m4,R32,i317,R33,i37,m4,R32,i315,R33,i27,m4,R32,i314,R33,i19,m4,R32,i313,R33,i13,m4,R32,i309,R33,i11,R15,ML2,R28,R71,m4,R32,i307,R33,i20,R113,ML2,R28,R164,m4,R32,i307,R33,i47,R100,ML2,R28,R71,m4,R32,i307,R33,i76,R116,R166,R217,ML2,R28,R165,m4,R32,i308,R33,i24,R157,R166,R216,R145,v11,arbace.walk8,postwalkv11,arbace.core4,map?R218,v11,arbace.core6,dissocv11,arbace.core3,setv16,arbace.a2g.model10,interface?v22,arbace.classes.analyze14,class-genericsv11,arbace.core3,vecR219,l0,v11,arbace.core4,someS2,R220,R221,R222,R223,v11,arbace.core6,removev11,arbace.core4,nil?R224,v11,arbace.core4,compR225,v16,arbace.a2g.dyncf10,strip-annsv11,arbace.core5,assocR226,v11,arbace.core11,select-keysV5,R53,R54,R219,R227,R228,V5,R53,R54,R219,R227,R228,S2,R220,R221,V5,R53,R54,R219,R227,R228,V5,R53,R54,R219,R227,R228,v13,arbace.string4,joinv14,arbace.a2g.dyn10,sub-supersV2,s21,arbace/lang/AFunctions18,arbace/lang/RestFnv11,arbace.core4,sortv11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core12,*print-meta*v11,arbace.core6,pr-str")

var Lit_1 *jrt.String = jrt.Intern("---- the class forms at the REPL: Compiler$CFGo's natives (doc/go/CLASSFORMS-REPL.md)")

var Lit_2 *jrt.String = jrt.Intern("defineClass")

var Lit_3 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Class;[Ljava/lang/Class;IILjava/lang/Object;)Ljava/lang/Class;")

var Lit_4 *jrt.String = jrt.Intern("alloc")

var Lit_5 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_6 *jrt.String = jrt.Intern("canExtend")

var Lit_7 *jrt.String = jrt.Intern("(Ljava/lang/Class;)Z")

var Lit_8 *jrt.String = jrt.Intern("superCtor")

var Lit_9 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V")

var Lit_10 *jrt.String = jrt.Intern("superCall")

var Lit_11 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_12 *jrt.String = jrt.Intern("setOuter")

var Lit_13 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V")

var Lit_14 *jrt.String = jrt.Intern("clearMembers")

var Lit_15 *jrt.String = jrt.Intern("(Ljava/lang/Class;)V")

var Lit_16 *jrt.String = jrt.Intern("setEnum")

var Lit_17 *jrt.String = jrt.Intern("(Ljava/lang/Class;Larbace/lang/IFn;)V")

var Lit_18 *jrt.String = jrt.Intern("klassOf")

var Lit_19 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_20 *jrt.String = jrt.Intern("setMethod")

var Lit_21 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;ILarbace/lang/IFn;)V")

var Lit_22 *jrt.String = jrt.Intern("addCtor")

var Lit_23 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Class;ILarbace/lang/IFn;)V")

var Lit_24 *jrt.String = jrt.Intern("addField")

var Lit_25 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;II)V")

var Lit_26 *jrt.String = jrt.Intern("addStatic")

var Lit_27 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;I[Ljava/lang/Object;ILarbace/lang/IFn;)V")

var Lit_28 *jrt.String = jrt.Intern("jrt/Prim_")

var Lit_29 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_30 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097")

var Lit_31 *jrt.String = jrt.Intern(";; Written by a2g --program (arbace.a2g.dyncf/generics-text): the generic signatures of the\n")

var Lit_32 *jrt.String = jrt.Intern(";; classes of the world, for the class forms' analysis (doc/go/CLASSFORMS-REPL.md).\n{")

var Lit_33 *jrt.String = jrt.Intern("}\n")

var Lit_34 *jrt.String = jrt.Intern("\n ")

var Lit_35 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000149__1117000153")

var Lit_36 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099")

var Lit_38 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000124")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000127__1117000131")

var Lit_40 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000137__1117000141")

var Lit_41 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$fn__1117000100")

var Lit_42 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000103__1117000107")

var Lit_43 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000113__1117000117")

var Lit_44 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000103__1117000107$fn__1117000108")

var Lit_45 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000103__1117000107$fn__1117000108$fn__1117000109")

var Lit_46 *jrt.String = jrt.Intern("<init>")

var Lit_47 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000113__1117000117$fn__1117000118")

var Lit_48 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$fn__1117000099$iter__1117000113__1117000117$fn__1117000118$fn__1117000119")

var Lit_49 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000127__1117000131$fn__1117000132")

var Lit_50 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000127__1117000131$fn__1117000132$fn__1117000133")

var Lit_51 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000137__1117000141$fn__1117000142")

var Lit_52 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000093__1117000097$fn__1117000098$iter__1117000137__1117000141$fn__1117000142$fn__1117000143")

var Lit_53 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000149__1117000153$fn__1117000154")

var Lit_54 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text$iter__1117000149__1117000153$fn__1117000154$fn__1117000155")

var Lit_55 *jrt.String = jrt.Intern(" ")

var Lit_56 *jrt.String = jrt.Intern("_")

var Lit_57 *jrt.String = jrt.Intern("_native")

var Lit_58 *jrt.String = jrt.Intern("arbace.a2g.dyncf$strip_anns$fn__1117000090")

var Lit_59 *jrt.String = jrt.Intern("dynCfNew_")

var Lit_60 *jrt.String = jrt.Intern("_Init")

var Lit_61 *jrt.String = jrt.Intern("dynCfCtors_")

var Lit_62 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021")

var Lit_63 *jrt.String = jrt.Intern("dynCfSupers_")

var Lit_64 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047")

var Lit_65 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022")

var Lit_66 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022$fn__1117000023")

var Lit_67 *jrt.String = jrt.Intern(".")

var Lit_68 *jrt.String = jrt.Intern(".-")

var Lit_69 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022$fn__1117000039")

var Lit_70 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000017__1117000021$fn__1117000022$fn__1117000023$fn__1117000030")

var Lit_71 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048")

var Lit_72 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048$fn__1117000049")

var Lit_73 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048$fn__1117000072")

var Lit_74 *jrt.String = jrt.Intern(".Impl_")

var Lit_75 *jrt.String = jrt.Intern("V")

var Lit_76 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms$iter__1117000043__1117000047$fn__1117000048$fn__1117000049$fn__1117000059")

var Lit_77 *jrt.String = jrt.Intern("DynSub_")

var Lit_78 *jrt.String = jrt.Intern("cfSubFor: the allocation, constructors and implementations of superclass c of the world\n(nil: c has no DynSub type).\n")

var Lit_79 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms$iter__1117000078__1117000082")

var Lit_80 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms$iter__1117000078__1117000082$fn__1117000083")

var Lit_81 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms$iter__1117000078__1117000082$fn__1117000083$fn__1117000084")

var Lit_82 *jrt.String = jrt.Intern("_class")

var Lit_83 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn8,arglistskn7,privateyn3,symyn4,typeyn5,mnameyn4,descyn1,nyn1,dyn1,xyn1,Tv11,arbace.core5,in-nsMyn16,arbace.a2g.dyncfm2,R0,s596,The natives of Compiler$CFGo (arbace/lang/Compiler.ae), the Go build's host of the class\n  forms at the REPL (doc/go/CLASSFORMS-REPL.md), in arbace/lang's a2g_cf.go: classes made at run\n  time for interpreted classes, over Dyn (A2G-SPEC §5.12, arbace.a2g.dyn): a class extending\n  Object or another interpreted class, implementing interfaces of the world (Dyn's slots) and\n  interfaces made at run time (the class's methods by key); an interface; a Clojure fn's class\n  (objects CF$FnObj). Member tables carry the classes' methods, constructors and fields, with\n  their modifiers, for reflection.m2,R0,s596,The natives of Compiler$CFGo (arbace/lang/Compiler.ae), the Go build's host of the class\n  forms at the REPL (doc/go/CLASSFORMS-REPL.md), in arbace/lang's a2g_cf.go: classes made at run\n  time for interpreted classes, over Dyn (A2G-SPEC §5.12, arbace.a2g.dyn): a class extending\n  Object or another interpreted class, implementing interfaces of the world (Dyn's slots) and\n  interfaces made at run time (the class's methods by key); an interface; a Clojure fn's class\n  (objects CF$FnObj). Member tables carry the classes' methods, constructors and fields, with\n  their modifiers, for reflection.R1,v16,arbace.a2g.dyncf9,api-classm6,R2,i19,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf8,enabled?m10,R5,L1,V0,R0,s52,Is the class forms' host in this world (translated)?R2,i21,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf3,tagm10,R6,TR5,L1,V2,R7,R8,R2,i26,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf11,native-namem10,R6,TR5,L1,V2,R9,R10,R2,i28,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf8,sub-namem10,R6,TR5,L1,V1,R11,R2,i39,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf11,from-objectm12,R6,TR5,L1,V2,R12,R13,R0,s78,The Java object x (an interpreter's argument) as the Go value of descriptor d.R2,i41,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf9,sub-formsm12,R6,TR5,L1,V1,R11,R0,s51,dynCfNew_G, dynCfCtors_G, dynCfSupers_G of class n.R2,i49,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf10,subs-formsm10,R5,L1,V1,R14,R0,s79,The forms of the superclasses of the world, and cfSubFor (nil when c has none).R2,i101,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf5,formsm10,R5,L1,V1,R14,R0,s45,The forms of a2g_cf.go (package arbace/lang).R2,i120,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf10,strip-annsm10,R6,TR5,L1,V1,R13,R2,i331,R3,i1,R4,s19,arbace/a2g/dyncf.aev16,arbace.a2g.dyncf13,generics-textm10,R5,L1,V1,R14,R0,s282,The generic view (class-generics) of the classes of T that are generic or have generic\n  supertypes, as text read by arbace.classes.go/generics: {internal-name {:tparams [sym]\n  :supers [tnode] :methods [...]}}, methods only for generic classes (the others' come from\n  reflection).R2,i334,R3,i1,R4,s19,arbace/a2g/dyncf.ae")

var Lit_84 *jrt.String = jrt.Intern("arbace.a2g.dyncf$eval1117000004$loading__1927001464__auto____1117000005")

var Lit_85 *jrt.String = jrt.Intern("arbace.a2g.dyncf$eval1117000008$fn__1117000009")

var Lit_86 *jrt.String = jrt.Intern("arbace/lang/Compiler$CFGo")

var Lit_87 *jrt.String = jrt.Intern("arbace.a2g.dyncf$enabled_QMARK_")

var Lit_88 *jrt.String = jrt.Intern("arbace.a2g.dyncf$tag")

var Lit_89 *jrt.String = jrt.Intern("arbace.a2g.dyncf$native_name")

var Lit_90 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_name")

var Lit_91 *jrt.String = jrt.Intern("arbace.a2g.dyncf$from_object")

var Lit_92 *jrt.String = jrt.Intern("arbace.a2g.dyncf$sub_forms")

var Lit_93 *jrt.String = jrt.Intern("arbace.a2g.dyncf$subs_forms")

var Lit_94 *jrt.String = jrt.Intern("arbace.a2g.dyncf$forms")

var Lit_95 *jrt.String = jrt.Intern("arbace.a2g.dyncf$strip_anns")

var Lit_96 *jrt.String = jrt.Intern("arbace.a2g.dyncf$generics_text")
