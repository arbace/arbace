//line j2g_classes.ae:1
package aot_arbace_c2j_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c2j_check_check_A_class, Name: "arbace.c2j.check$check", Modifiers: 25, Simple: "check", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000019_A_class, Name: "arbace.c2j.check$check$fn__908000019", Modifiers: 25, Simple: "fn__908000019", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000019_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000037_A_class, Name: "arbace.c2j.check$check$fn__908000037", Modifiers: 25, Simple: "fn__908000037", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000037_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000039_A_class, Name: "arbace.c2j.check$check$fn__908000039", Modifiers: 25, Simple: "fn__908000039", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000039_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000041_A_class, Name: "arbace.c2j.check$check$fn__908000041", Modifiers: 25, Simple: "fn__908000041", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000041_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_class, Name: "arbace.c2j.check$check$fn__908000041$iter__908000042__908000046", Modifiers: 25, Simple: "iter__908000042__908000046", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_fn__908000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_class, Name: "arbace.c2j.check$check$fn__908000041$iter__908000042__908000046$fn__908000047", Modifiers: 25, Simple: "fn__908000047", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_class, Name: "arbace.c2j.check$check$fn__908000041$iter__908000042__908000046$fn__908000047$fn__908000048", Modifiers: 25, Simple: "fn__908000048", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_class, Name: "arbace.c2j.check$check$fn__908000041$lap__908000054", Modifiers: 25, Simple: "lap__908000054", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000041_lap__908000054_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_fn__908000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_class, Name: "arbace.c2j.check$check$fn__908000041$try_BANG___908000052", Modifiers: 25, Simple: "try_BANG___908000052", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_fn__908000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_iter__908000021__908000027_A_class, Name: "arbace.c2j.check$check$iter__908000021__908000027", Modifiers: 25, Simple: "iter__908000021__908000027", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_iter__908000021__908000027_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_class, Name: "arbace.c2j.check$check$iter__908000021__908000027$fn__908000028", Modifiers: 25, Simple: "fn__908000028", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_iter__908000021__908000027_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_class, Name: "arbace.c2j.check$check$iter__908000021__908000027$fn__908000028$iter__908000023__908000029", Modifiers: 25, Simple: "iter__908000023__908000029", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_class, Name: "arbace.c2j.check$check$iter__908000021__908000027$fn__908000028$iter__908000023__908000029$fn__908000030", Modifiers: 25, Simple: "fn__908000030", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_class, Name: "arbace.c2j.check$check$iter__908000021__908000027$fn__908000028$iter__908000023__908000029$fn__908000030$fn__908000031", Modifiers: 25, Simple: "fn__908000031", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_class, Name: "arbace.c2j.check$eval908000004$loading__1927001464__auto____908000005", Modifiers: 25, Simple: "loading__1927001464__auto____908000005", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_eval908000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_eval908000008_fn__908000009_A_class, Name: "arbace.c2j.check$eval908000008$fn__908000009", Modifiers: 25, Simple: "fn__908000009", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_eval908000008_fn__908000009_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_eval908000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_read_all_A_class, Name: "arbace.c2j.check$read_all", Modifiers: 25, Simple: "read_all", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_read_all_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_read_all_fn__908000013_A_class, Name: "arbace.c2j.check$read_all$fn__908000013", Modifiers: 25, Simple: "fn__908000013", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_read_all_fn__908000013_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2j_check_read_all_fn__908000015_A_class, Name: "arbace.c2j.check$read_all$fn__908000015", Modifiers: 25, Simple: "fn__908000015", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_read_all_fn__908000015_A", Source: "check.ae", Declaring: &A_arbace_c2j_check_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c2j_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2j_check_A_New()}; return nil }

var A_arbace_c2j_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2j_check_A_new}

var A_arbace_c2j_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2j.check", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_A"})

func init() { i := A_arbace_c2j_check_A_class.Info(); i.IsInstance = A_arbace_c2j_check_A_InstanceOf; i.Init = A_arbace_c2j_check_A_Init; i.Table = A_arbace_c2j_check_A_members }

var A_arbace_c2j_check_check_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000019_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000037_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000039_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000041_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_class *jrt.Class

var A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_class *jrt.Class

var A_arbace_c2j_check_check_iter__908000021__908000027_A_class *jrt.Class

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_class *jrt.Class

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_class *jrt.Class

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_class *jrt.Class

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_class *jrt.Class

func A_arbace_c2j_check_eval908000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2j_check_eval908000004_A_New()}; return nil }

var A_arbace_c2j_check_eval908000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2j_check_eval908000004_A_new}

var A_arbace_c2j_check_eval908000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2j.check$eval908000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2j_check_A_class, Simple: "eval908000004", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_eval908000004_A"})

func init() { i := A_arbace_c2j_check_eval908000004_A_class.Info(); i.IsInstance = A_arbace_c2j_check_eval908000004_A_InstanceOf; i.Table = A_arbace_c2j_check_eval908000004_A_members }

var A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_class *jrt.Class

func A_arbace_c2j_check_eval908000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2j_check_eval908000008_A_New()}; return nil }

var A_arbace_c2j_check_eval908000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2j_check_eval908000008_A_new}

var A_arbace_c2j_check_eval908000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2j.check$eval908000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2j_check_A_class, Simple: "eval908000008", Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check_eval908000008_A"})

func init() { i := A_arbace_c2j_check_eval908000008_A_class.Info(); i.IsInstance = A_arbace_c2j_check_eval908000008_A_InstanceOf; i.Table = A_arbace_c2j_check_eval908000008_A_members }

var A_arbace_c2j_check_eval908000008_fn__908000009_A_class *jrt.Class

var A_arbace_c2j_check_read_all_A_class *jrt.Class

var A_arbace_c2j_check_read_all_fn__908000013_A_class *jrt.Class

var A_arbace_c2j_check_read_all_fn__908000015_A_class *jrt.Class

func A_arbace_c2j_check__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2j_check__init_A_Load__O()}; return nil }

func A_arbace_c2j_check__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2j_check__init_A_New()}; return nil }

var A_arbace_c2j_check__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2j_check__init_A_invoke, New: A_arbace_c2j_check__init_A_new}

var A_arbace_c2j_check__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2j.check__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2j_check.A_arbace_c2j_check__init_A", Source: "check.ae"})

func init() { i := A_arbace_c2j_check__init_A_class.Info(); i.IsInstance = A_arbace_c2j_check__init_A_InstanceOf; i.Init = A_arbace_c2j_check__init_A_Init; i.Table = A_arbace_c2j_check__init_A_members }
