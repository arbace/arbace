//line aot_arbace_c2j_check.ae:1
package aot_arbace_c2j_check

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_parse"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_New() *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_check_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_c2j_check_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_c2j_check_A_const_1, A_arbace_c2j_check_A_const_2, A_arbace_c2j_check_A_const_3, A_arbace_c2j_check_A_const_4, A_arbace_c2j_check_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_check_eval908000008_fn__908000009_A_New() *A_arbace_c2j_check_eval908000008_fn__908000009_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000008_fn__908000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_8.GetRawRoot__O()); var tmp2 any; var root_13 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_c2j_check_A_const_10; if linked_14 == nil { tmp2 = ifn_15.Invoke_O__O(arg_16) } else { tmp2 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c2j_check_A_const_11.GetRawRoot__O(), A_arbace_c2j_check_A_const_12) }











func A_arbace_c2j_check_read_all_A_New() *A_arbace_c2j_check_read_all_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Ctor() {}
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_c2j_check_A_const_13.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_60 any = A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_24, jrt.Boolean_FALSE.Ref()); if linked_61 == nil { ifn_62.Invoke_O__O(arg_63) } else { linked_61.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_60, arg_63) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_48 any = A_arbace_c2j_check_A_const_14.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any; var root_43 any = A_arbace_c2j_check_A_const_15.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any; var tmp2 any = A_arbace_c2j_check_read_all_fn__908000013_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000013_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_c2j_check_read_all_fn__908000013_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; arg_46 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_47 any; var root_39 any = A_arbace_c2j_check_A_const_18.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var tmp4 any = A_arbace_c2j_check_read_all_fn__908000015_A_New_O(r__2); var tmp5 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000015_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_c2j_check_read_all_fn__908000015_A_fn_class = fncls__38d; tmp5 = fncls__38d } else { tmp5 = fncls__38 }; arg_42 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_40 == nil { arg_47 = ifn_41.Invoke_O__O(arg_42) } else { arg_47 = linked_40.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O__O(root_39, arg_42) }; if linked_44 == nil { arg_51 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { arg_51 = linked_44.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; if linked_49 == nil { tmp1 = ifn_50.Invoke_O__O(arg_51) } else { tmp1 = linked_49.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_48, arg_51) } }
//line :15:1
		return nil }(); var root_52 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; if linked_53 == nil { ifn_54.Invoke__O() } else { linked_53.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_52) }
//line :13:1
		if tmp6 != nil { panic(tmp6) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :13:1*/ tmp7 != nil { panic(tmp7) }; return tmp1 }


func A_arbace_c2j_check_read_all_fn__908000013_A_New() *A_arbace_c2j_check_read_all_fn__908000013_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000013_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Ctor() {}
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Invoke_O_O__O(self, p1__908000012_SHARP___1 any) any { var root_27 any = A_arbace_c2j_check_A_const_16.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = A_arbace_c2j_check_A_const_17; var arg_31 any = p1__908000012_SHARP___1; if linked_28 == nil { return ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { return linked_28.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_27, arg_30, arg_31) } }
//line :16:1
func A_arbace_c2j_check_read_all_fn__908000015_A_New_O(p0 any) *A_arbace_c2j_check_read_all_fn__908000015_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000015_A{}; t.Ctor_O(p0); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Invoke_O__O(self any) any { var root_33 any = A_arbace_c2j_check_A_const_19.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = A_arbace_c2j_check_A_const_20; var arg_37 any = t.F_r; if linked_34 == nil { return ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { return linked_34.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) } }

func A_arbace_c2j_check_check_A_New() *A_arbace_c2j_check_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_c2j_check_check_A) Ctor() {}
//line :18:1
func (t *A_arbace_c2j_check_check_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var root_83 any = A_arbace_c2j_check_A_const_25.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_85 lang.IFn; if


	linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any; var root_78 any = A_arbace_c2j_check_A_const_26.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var tmp1 any = A_arbace_c2j_check_check_fn__908000019_A_New(); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_c2j_check_check_fn__908000019_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_c2j_check_check_fn__908000019_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; arg_81 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_82 any; var root_74 any = A_arbace_c2j_check_A_const_28.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var root_69 any = A_arbace_c2j_check_A_const_29.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_69, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = dir__0; var arg_73 any = Lit_2; if linked_70 == nil { arg_77 = ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { arg_77 = linked_70.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_69, arg_72, arg_73) }; if linked_75 == nil { arg_82 = ifn_76.Invoke_O__O(arg_77) } else { arg_82 = linked_75.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_74, arg_77) }; if linked_79 == nil { arg_86 = ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { arg_86 = linked_79.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_78, arg_81, arg_82) }; if linked_84 == nil { files__2 = ifn_85.Invoke_O__O(arg_86) } else { files__2 = linked_84.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_83, arg_86) }; var forms__3 any; var iter__1927001039__auto____3 any; var tmp3 any = /*line :18:1*/A_arbace_c2j_check_check_iter__908000021__908000027_A_New(); var tmp4 *jrt.Class; var fncls__204 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class; if



	fncls__204 == nil { var fncls__204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class = fncls__204d; tmp4 = fncls__204d } else { tmp4 = fncls__204 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); forms__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); var ns__4 any; var root_205 any = /*line :18:1*/A_arbace_c2j_check_A_const_45.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_207 lang.IFn; if







	linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = A_arbace_c2j_check_A_const_46; if linked_206 == nil { ns__4 = ifn_207.Invoke_O__O(arg_208) } else { ns__4 = linked_206.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_205, arg_208) }; var root_541 any =
	A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_74, ns__4); if linked_542 == nil { ifn_543.Invoke_O__O(arg_544) } else { linked_542.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_541, arg_544) }; var tmp5 any = A_arbace_c2j_check_check_fn__908000037_A_New(); var tmp6 *jrt.Class; var fncls__535 *jrt.Class = A_arbace_c2j_check_check_fn__908000037_A_fn_class; if fncls__535 == nil { var fncls__535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_c2j_check_check_fn__908000037_A_fn_class = fncls__535d; tmp6 = fncls__535d } else { tmp6 = fncls__535 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var root_584 any =

	A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_check_A_const_75; var tmp9 any; var root_545 any = A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_546 == nil { tmp9 = ifn_547.Invoke_O__O(arg_548) } else { tmp9 = linked_546.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_545, arg_548) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_c2j_check_A_const_58; var tmp12 any = A_arbace_c2j_check_A_const_57; var tmp13 any; var root_549 any = A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_551 lang.IFn; if
	linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = lang.PersistentVector_EMPTY.Ref(); if linked_550 == nil { tmp13 = ifn_551.Invoke_O__O(arg_552) } else { tmp13 = linked_550.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_549, arg_552) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_c2j_check_A_const_76; var tmp16 any; var root_553 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_555 lang.IFn; if
	linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_554 == nil { tmp16 = ifn_555.Invoke_O__O(arg_556) } else { tmp16 = linked_554.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_553, arg_556) }; var tmp17 any = tmp16; var tmp18 any = A_arbace_c2j_check_A_const_77; var tmp19 any; var root_557 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_559 lang.IFn; if
	linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_558 == nil { tmp19 = ifn_559.Invoke_O__O(arg_560) } else { tmp19 = linked_558.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_557, arg_560) }; var tmp20 any = tmp19; var tmp21 any = A_arbace_c2j_check_A_const_78; var tmp22 any; var root_561 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_563 lang.IFn; if

	linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_562 == nil { tmp22 = ifn_563.Invoke_O__O(arg_564) } else { tmp22 = linked_562.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_561, arg_564) }; var tmp23 any = tmp22; var tmp24 any = A_arbace_c2j_check_A_const_79; var tmp25 any; var root_565 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_567 lang.IFn; if

	linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_566 == nil { tmp25 = ifn_567.Invoke_O__O(arg_568) } else { tmp25 = linked_566.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_565, arg_568) }; var tmp26 any = tmp25; var tmp27 any = A_arbace_c2j_check_A_const_80; var tmp28 any; var root_569 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_571 lang.IFn; if


	linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_570 == nil { tmp28 = ifn_571.Invoke_O__O(arg_572) } else { tmp28 = linked_570.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_569, arg_572) }; var tmp29 any = tmp28; var tmp30 any = A_arbace_c2j_check_A_const_81; var tmp31 any; var root_573 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_575 lang.IFn; if


	linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_574 == nil { tmp31 = ifn_575.Invoke_O__O(arg_576) } else { tmp31 = linked_574.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_573, arg_576) }; arg_587 = /*line :29:1*/tmp7.Invoke_O_O_O_O__O(tmp8, tmp10, tmp11, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp23, tmp24, tmp26, tmp27, tmp29, tmp30, tmp31))); if linked_585 == nil { ifn_586.Invoke_O__O(arg_587) } else { linked_585.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_584, arg_587) }; var tmp32 any; tmp38 := /*line :18:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














		{ var root_520 any = A_arbace_c2j_check_A_const_47.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_with_redefs_fn_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var tmp33 any = A_arbace_c2j_check_A_const_48; var tmp34 any = A_arbace_c2j_check_check_fn__908000039_A_New(); var tmp35 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_c2j_check_check_fn__908000039_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_c2j_check_check_fn__908000039_A_fn_class = fncls__209d; tmp35 = fncls__209d } else { tmp35 = fncls__209 }; arg_523 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil))); var arg_524 any; var tmp36 any = A_arbace_c2j_check_check_fn__908000041_A_New_O_O(ns__4, forms__3); var tmp37 *jrt.Class; var fncls__519 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_A_fn_class; if fncls__519 == nil { var fncls__519d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_c2j_check_check_fn__908000041_A_fn_class = fncls__519d; tmp37 = fncls__519d } else { tmp37 = fncls__519 }; arg_524 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); if linked_521 == nil { tmp32 = ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { tmp32 = linked_521.(*aot_arbace_core.A_arbace_core_with_redefs_fn_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) } }
//line :18:1
		return nil }(); var root_525 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_527 lang.IFn; if










	linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; if linked_526 == nil { ifn_527.Invoke__O() } else { linked_526.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_525) }; if /*line :18:1*/ tmp38 != nil { panic(tmp38) }; return tmp32 }


func A_arbace_c2j_check_check_fn__908000019_A_New() *A_arbace_c2j_check_check_fn__908000019_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000019_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Ctor() {}
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Invoke_O_O__O(self, p1__908000018_SHARP___1 any) any { var tmp1 any; var root_64 any = A_arbace_c2j_check_A_const_27.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = p1__908000018_SHARP___1; if linked_65 == nil { tmp1 = ifn_66.Invoke_O__O(arg_67) } else { tmp1 = linked_65.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_64, arg_67) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(tmp1)).EndsWith_String__Z(Lit_7)).Ref() }
func A_arbace_c2j_check_check_iter__908000021__908000027_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Invoke_O_O__O(self, s__908000022__1 any) any { var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(self, s__908000022__1); var tmp2 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class = fncls__203d; tmp2 = fncls__203d } else { tmp2 = fncls__203 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Ctor_O_O(c__iter__908000021, c__s__908000022 any) { t.F_iter__908000021 = c__iter__908000021; t.F_s__908000022 = c__s__908000022 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Invoke_O__O(self any) any { { var s__908000022__1 any; var t_ any = t.F_s__908000022; t.F_s__908000022 = nil; s__908000022__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_87 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__908000022__1; if linked_88 == nil { temp__1927000414__auto____2 = ifn_89.Invoke_O__O(arg_90) } else { temp__1927000414__auto____2 = linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_91 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = xs__1927001018__auto____3; if linked_92 == nil { f__4 = ifn_93.Invoke_O__O(arg_94) } else { f__4 = linked_92.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_91, arg_94) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New(); var tmp2 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class = fncls__181d; tmp2 = fncls__181d } else { tmp2 = fncls__181 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_186 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_182 any = A_arbace_c2j_check_A_const_43.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_c2j_check_read_all_A_fn_class); var ifn_184 lang.IFn
													if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = f__4; if linked_183 == nil { tmp4 = ifn_184.Invoke_O__O(arg_185) } else { tmp4 = linked_183.(*A_arbace_c2j_check_read_all_A).Invoke_O_O__O(root_182, arg_185) }
//line :22:1
	arg_189 = tmp3.Invoke_O__O(tmp4); if linked_187 == nil { fs__1927001036__auto____6 = ifn_188.Invoke_O__O(arg_189) } else { fs__1927001036__auto____6 = linked_187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_186, arg_189) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_194 any = A_arbace_c2j_check_A_const_44.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = fs__1927001036__auto____6; var arg_198 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__908000021); var tmp6 any; var root_190 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__908000022__1; if linked_191 == nil { tmp6 = ifn_192.Invoke_O__O(arg_193) } else { tmp6 = linked_191.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_190, arg_193) }; arg_198 = tmp5.Invoke_O__O(tmp6); if linked_195 == nil { return ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { return linked_195.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_194, arg_197, arg_198) } } else { var tmp7 any; var root_199 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__908000022__1; if linked_200 == nil { tmp7 = ifn_201.Invoke_O__O(arg_202) } else { tmp7 = linked_200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_199, arg_202) }; s__908000022__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Invoke_O_O__O(self, s__908000024__1 any) any { var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(self, s__908000024__1); var tmp2 *jrt.Class; var fncls__180 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class; if fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class = fncls__180d; tmp2 = fncls__180d } else { tmp2 = fncls__180 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Ctor_O_O(c__iter__908000023, c__s__908000024 any) { t.F_iter__908000023 = c__iter__908000023; t.F_s__908000024 = c__s__908000024 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Invoke_O__O(self any) any { { var s__908000024__1 any; var t_ any = t.F_s__908000024; t.F_s__908000024 = nil; s__908000024__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_95 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = s__908000024__1; if linked_96 == nil { temp__1927000414__auto____2 = ifn_97.Invoke_O__O(arg_98) } else { temp__1927000414__auto____2 = linked_96.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_95, arg_98) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000024__3 any = temp__1927000414__auto____2; var tmp1 any; var root_99 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = s__908000024__3; if linked_100 == nil { tmp1 = ifn_101.Invoke_O__O(arg_102) } else { tmp1 = linked_100.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_99, arg_102) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_103 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = s__908000024__3; if linked_104 == nil { c__1927001037__auto____4 = ifn_105.Invoke_O__O(arg_106) } else { c__1927001037__auto____4 = linked_104.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_103, arg_106) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000026__6 any; var root_107 any = A_arbace_c2j_check_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_108 == nil { b__908000026__6 = ifn_109.Invoke_O__O(arg_110) } else { b__908000026__6 = linked_108.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_107, arg_110) }; var tmp2 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(size__1927001038__auto____5, b__908000026__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_137 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_129 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = b__908000026__6; if linked_130 == nil { arg_140 = ifn_131.Invoke_O__O(arg_132) } else { arg_140 = linked_130.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_129, arg_132) }; var arg_141 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); var tmp5 any; var root_133 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = s__908000024__3; if linked_134 == nil { tmp5 = ifn_135.Invoke_O__O(arg_136) } else { tmp5 = linked_134.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_133, arg_136) }; arg_141 = tmp4.Invoke_O__O(tmp5); if linked_138 == nil { return ifn_139.Invoke_O_O__O(arg_140, arg_141) } else { return linked_138.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_137, arg_140, arg_141) } } else { var root_146 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_142 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = b__908000026__6; if linked_143 == nil { arg_149 = ifn_144.Invoke_O__O(arg_145) } else { arg_149 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_142, arg_145) }; var arg_150 any; if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } } else { var fm__4 any; var root_151 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__908000024__3; if linked_152 == nil { fm__4 = ifn_153.Invoke_O__O(arg_154) } else { fm__4 = linked_152.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_151, arg_154) }; var tmp6 any; var and__1927000168__auto____5 any; var root_155 any = A_arbace_c2j_check_A_const_35.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_157 lang.IFn

	if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = fm__4; if linked_156 == nil { and__1927000168__auto____5 = ifn_157.Invoke_O__O(arg_158) } else { and__1927000168__auto____5 = linked_156.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_155, arg_158) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 any = A_arbace_c2j_check_A_const_36; var tmp8 any; var root_159 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = fm__4; if linked_160 == nil { tmp8 = ifn_161.Invoke_O__O(arg_162) } else { tmp8 = linked_160.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_159, arg_162) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp6 = and__1927000168__auto____5 }
//line :22:1
	if jrt.J2g_Truth(tmp6) { var root_171 any = A_arbace_c2j_check_A_const_42.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var root_163 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_165 lang.IFn


		if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = fm__4; if linked_164 == nil { arg_174 = ifn_165.Invoke_O__O(arg_166) } else { arg_174 = linked_164.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_163, arg_166) }
//line :22:1
		var arg_175 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); var tmp10 any; var root_167 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = s__908000024__3; if linked_168 == nil { tmp10 = ifn_169.Invoke_O__O(arg_170) } else { tmp10 = linked_168.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_167, arg_170) }; arg_175 = tmp9.Invoke_O__O(tmp10); if linked_172 == nil { return ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { return linked_172.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) } } else { var tmp11 any; var root_176 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__908000024__3; if linked_177 == nil { tmp11 = ifn_178.Invoke_O__O(arg_179) } else { tmp11 = linked_177.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_176, arg_179) }; s__908000024__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__908000026, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__908000026 = c__b__908000026; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Invoke_O__O(self any) any { { var i__908000025__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000025__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000025__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_111 any = A_arbace_c2j_check_A_const_35.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_113 lang.IFn

	if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = fm__2; if linked_112 == nil { and__1927000168__auto____3 = ifn_113.Invoke_O__O(arg_114) } else { and__1927000168__auto____3 = linked_112.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_c2j_check_A_const_36; var tmp4 any; var root_115 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = fm__2; if linked_116 == nil { tmp4 = ifn_117.Invoke_O__O(arg_118) } else { tmp4 = linked_116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_115, arg_118) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :22:1
	if jrt.J2g_Truth(tmp2) { var root_123 any = A_arbace_c2j_check_A_const_37.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = t.F_b__908000026; var arg_127 any; var root_119 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_121 lang.IFn


		if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = fm__2; if linked_120 == nil { arg_127 = ifn_121.Invoke_O__O(arg_122) } else { arg_127 = linked_120.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_119, arg_122) }
//line :22:1
		if linked_124 == nil { ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { linked_124.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } else { i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_check_check_fn__908000037_A_New() *A_arbace_c2j_check_check_fn__908000037_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000037_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Ctor() {}
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										tmp1 = lang.IFn_Cast(A_arbace_c2j_check_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_73)
//line :27:1
	return nil }(); var root_532 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; if linked_533 == nil { ifn_534.Invoke__O() } else { linked_533.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_532) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_c2j_check_check_fn__908000039_A_New() *A_arbace_c2j_check_check_fn__908000039_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000039_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Ctor() {}
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Invoke_O_O_O__O(self, ___1, node__2 any) any { return node__2 }
//line :33:1
func A_arbace_c2j_check_check_fn__908000041_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_fn__908000041_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Ctor_O_O(c__ns, c__forms any) { t.F_ns = c__ns; t.F_forms = c__forms }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Invoke_O__O(self any) any { var names__1 any; var root_289 any = A_arbace_c2j_check_A_const_49.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_291 lang.IFn; if
										linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(t.F_ns); var tmp2 *jrt.Class; var fncls__288 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class; if fncls__288 == nil { var fncls__288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class = fncls__288d; tmp2 = fncls__288d } else { tmp2 = fncls__288 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_292 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(t.F_forms); if linked_290 == nil { names__1 = ifn_291.Invoke_O__O(arg_292) } else { names__1 = linked_290.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_289, arg_292) }; var order__2 any; var root_293 any = /*line :33:1*/A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_295 lang.IFn; if
										linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var tmp3 *lang.Keyword = A_arbace_c2j_check_A_const_57; var arg_296 any = tmp3.Invoke_O__O(A_arbace_c2j_check_A_const_58.Get__O()); if linked_294 == nil { order__2 = ifn_295.Invoke_O__O(arg_296) } else { order__2 = linked_294.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_293, arg_296) }; var fails__3 any; var root_297 any = /*line :33:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_299 lang.IFn; if



	linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = lang.PersistentVector_EMPTY.Ref(); if linked_298 == nil { fails__3 = ifn_299.Invoke_O__O(arg_300) } else { fails__3 = linked_298.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_297, arg_300) }; var try_BANG___4 any; var tmp4 any = /*line :33:1*/A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(fails__3); var tmp5 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class; if




	fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class = fncls__314d; tmp5 = fncls__314d } else { tmp5 = fncls__314 }; try_BANG___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var t__5 any; var root_319 any = /*line :33:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_321 lang.IFn; if








	linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref(); if linked_320 == nil { t__5 = ifn_321.Invoke_O__O(arg_322) } else { t__5 = linked_320.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_319, arg_322) }; var lap__6 any; var tmp6 any = /*line :33:1*/A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(t__5); var tmp7 *jrt.Class; var fncls__344 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class; if









	fncls__344 == nil { var fncls__344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class = fncls__344d; tmp7 = fncls__344d } else { tmp7 = fncls__344 }; lap__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil);
	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_11); var seq_908000056__7 any; var root_359 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_361 lang.IFn; if











	linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = order__2; if linked_360 == nil { seq_908000056__7 = ifn_361.Invoke_O__O(arg_362) } else { seq_908000056__7 = linked_360.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_359, arg_362) }; var chunk_908000057__8 any; var count_908000058__9 int64 = 0; var i_908000059__10 int64 = 0; L1:
//line :33:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000059__10, count_908000058__9) { var n__11 any = lang.Indexed_Cast(chunk_908000057__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000059__10)); var tmp8 any; var root_367 any = A_arbace_c2j_check_A_const_63.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var tmp9 *lang.Keyword = A_arbace_c2j_check_A_const_64; var tmp10 any; var root_363 any = A_arbace_c2j_check_A_const_65.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = n__11; if linked_364 == nil { tmp10 = ifn_365.Invoke_O__O(arg_366) } else { tmp10 = linked_364.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_363, arg_366) }; arg_370 = tmp9.Invoke_O__O(tmp10); if linked_368 == nil { tmp8 = ifn_369.Invoke_O__O(arg_370) } else { tmp8 = linked_368.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_367, arg_370) }; if jrt.J2g_Truth(tmp8) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__11, A_arbace_c2j_check_A_const_67.GetRawRoot__O()); seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } else { seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } } else { var temp__1927000414__auto____11 any; var root_371 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = seq_908000056__7; if linked_372 == nil { temp__1927000414__auto____11 = ifn_373.Invoke_O__O(arg_374) } else { temp__1927000414__auto____11 = linked_372.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_908000056__12 any = temp__1927000414__auto____11; var tmp11 any; var root_375 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = seq_908000056__12; if linked_376 == nil { tmp11 = ifn_377.Invoke_O__O(arg_378) } else { tmp11 = linked_376.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_375, arg_378) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_379 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = seq_908000056__12; if linked_380 == nil { c__1927000678__auto____13 = ifn_381.Invoke_O__O(arg_382) } else { c__1927000678__auto____13 = linked_380.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_379, arg_382) }; var tmp12 any; var root_475 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = seq_908000056__12; if linked_476 == nil { tmp12 = ifn_477.Invoke_O__O(arg_478) } else { tmp12 = linked_476.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_475, arg_478) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__13 any; var root_383 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = seq_908000056__12; if linked_384 == nil { n__13 = ifn_385.Invoke_O__O(arg_386) } else { n__13 = linked_384.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_383, arg_386) }; var tmp13 any; var root_391 any = A_arbace_c2j_check_A_const_63.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any; var tmp14 *lang.Keyword = A_arbace_c2j_check_A_const_64; var tmp15 any; var root_387 any = A_arbace_c2j_check_A_const_65.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = n__13; if linked_388 == nil { tmp15 = ifn_389.Invoke_O__O(arg_390) } else { tmp15 = linked_388.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_387, arg_390) }; arg_394 = tmp14.Invoke_O__O(tmp15); if linked_392 == nil { tmp13 = ifn_393.Invoke_O__O(arg_394) } else { tmp13 = linked_392.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_391, arg_394) }; if jrt.J2g_Truth(tmp13) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__13, A_arbace_c2j_check_A_const_67.GetRawRoot__O()); var tmp16 any; var root_479 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_908000056__12; if linked_480 == nil { tmp16 = ifn_481.Invoke_O__O(arg_482) } else { tmp16 = linked_480.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_479, arg_482) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp16, nil, 0, 0; continue L1 } else { var tmp17 any; var root_483 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = seq_908000056__12; if linked_484 == nil { tmp17 = ifn_485.Invoke_O__O(arg_486) } else { tmp17 = linked_484.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_483, arg_486) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp17, nil, 0, 0; continue L1 } } } }
//line :33:1
		break L1 };












	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_13); var seq_908000060__7 any; var root_395 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_397 lang.IFn; if













	linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = order__2; if linked_396 == nil { seq_908000060__7 = ifn_397.Invoke_O__O(arg_398) } else { seq_908000060__7 = linked_396.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_395, arg_398) }; var chunk_908000061__8 any; var count_908000062__9 int64 = 0; var i_908000063__10 int64 = 0; L2:
//line :33:1
	for {













		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000063__10, count_908000062__9) { var n__11_2 any = lang.Indexed_Cast(chunk_908000061__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000063__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__11_2, A_arbace_c2j_check_A_const_69.GetRawRoot__O()); seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = seq_908000060__7, chunk_908000061__8, count_908000062__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000063__10); continue L2 } else { var temp__1927000414__auto____11_2 any; var root_399 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = seq_908000060__7; if linked_400 == nil { temp__1927000414__auto____11_2 = ifn_401.Invoke_O__O(arg_402) } else { temp__1927000414__auto____11_2 = linked_400.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_399, arg_402) }; if jrt.J2g_Truth(temp__1927000414__auto____11_2) { var seq_908000060__12 any = temp__1927000414__auto____11_2; var tmp18 any; var root_403 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = seq_908000060__12; if linked_404 == nil { tmp18 = ifn_405.Invoke_O__O(arg_406) } else { tmp18 = linked_404.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_403, arg_406) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____13_2 any; var root_407 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = seq_908000060__12; if linked_408 == nil { c__1927000678__auto____13_2 = ifn_409.Invoke_O__O(arg_410) } else { c__1927000678__auto____13_2 = linked_408.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_407, arg_410) }; var tmp19 any; var root_487 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = seq_908000060__12; if linked_488 == nil { tmp19 = ifn_489.Invoke_O__O(arg_490) } else { tmp19 = linked_488.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_487, arg_490) }; seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = tmp19, c__1927000678__auto____13_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var n__13_2 any; var root_411 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = seq_908000060__12; if linked_412 == nil { n__13_2 = ifn_413.Invoke_O__O(arg_414) } else { n__13_2 = linked_412.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_411, arg_414) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__13_2, A_arbace_c2j_check_A_const_69.GetRawRoot__O()); var tmp20 any; var root_491 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = seq_908000060__12; if linked_492 == nil { tmp20 = ifn_493.Invoke_O__O(arg_494) } else { tmp20 = linked_492.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_491, arg_494) }; seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = tmp20, nil, 0, 0; continue L2 } } }
//line :33:1
		break L2 };














	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_14); var seq_908000064__7 any; var root_415 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_417 lang.IFn; if















	linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_c2j_check_A_const_66.Invoke_O__O(order__2); if linked_416 == nil { seq_908000064__7 = ifn_417.Invoke_O__O(arg_418) } else { seq_908000064__7 = linked_416.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_415, arg_418) }; var chunk_908000065__8 any; var count_908000066__9 int64 = 0; var i_908000067__10 int64 = 0; L3:
//line :33:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000067__10, count_908000066__9) { var n__11_3 any = lang.Indexed_Cast(chunk_908000065__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000067__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__11_3, A_arbace_c2j_check_A_const_70.GetRawRoot__O()); seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = seq_908000064__7, chunk_908000065__8, count_908000066__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000067__10); continue L3 } else { var temp__1927000414__auto____11_3 any; var root_419 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = seq_908000064__7; if linked_420 == nil { temp__1927000414__auto____11_3 = ifn_421.Invoke_O__O(arg_422) } else { temp__1927000414__auto____11_3 = linked_420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_419, arg_422) }; if jrt.J2g_Truth(temp__1927000414__auto____11_3) { var seq_908000064__12 any = temp__1927000414__auto____11_3; var tmp21 any; var root_423 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = seq_908000064__12; if linked_424 == nil { tmp21 = ifn_425.Invoke_O__O(arg_426) } else { tmp21 = linked_424.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_423, arg_426) }; if jrt.J2g_Truth(tmp21) { var c__1927000678__auto____13_3 any; var root_427 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = seq_908000064__12; if linked_428 == nil { c__1927000678__auto____13_3 = ifn_429.Invoke_O__O(arg_430) } else { c__1927000678__auto____13_3 = linked_428.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_427, arg_430) }; var tmp22 any; var root_495 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = seq_908000064__12; if linked_496 == nil { tmp22 = ifn_497.Invoke_O__O(arg_498) } else { tmp22 = linked_496.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_495, arg_498) }; seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = tmp22, c__1927000678__auto____13_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var n__13_3 any; var root_431 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = seq_908000064__12; if linked_432 == nil { n__13_3 = ifn_433.Invoke_O__O(arg_434) } else { n__13_3 = linked_432.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_431, arg_434) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__13_3, A_arbace_c2j_check_A_const_70.GetRawRoot__O()); var tmp23 any; var root_499 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = seq_908000064__12; if linked_500 == nil { tmp23 = ifn_501.Invoke_O__O(arg_502) } else { tmp23 = linked_500.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_499, arg_502) }; seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = tmp23, nil, 0, 0; continue L3 } } }
//line :33:1
		break L3 };
















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_15); var seq_908000068__7 any; var root_435 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_437 lang.IFn; if

















	linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = order__2; if linked_436 == nil { seq_908000068__7 = ifn_437.Invoke_O__O(arg_438) } else { seq_908000068__7 = linked_436.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_435, arg_438) }; var chunk_908000069__8 any; var count_908000070__9 int64 = 0; var i_908000071__10 int64 = 0; L4:
//line :33:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000071__10, count_908000070__9) { var n__11_4 any = lang.Indexed_Cast(chunk_908000069__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000071__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__11_4, A_arbace_c2j_check_A_const_71); seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = seq_908000068__7, chunk_908000069__8, count_908000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000071__10); continue L4 } else { var temp__1927000414__auto____11_4 any; var root_439 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = seq_908000068__7; if linked_440 == nil { temp__1927000414__auto____11_4 = ifn_441.Invoke_O__O(arg_442) } else { temp__1927000414__auto____11_4 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }; if jrt.J2g_Truth(temp__1927000414__auto____11_4) { var seq_908000068__12 any = temp__1927000414__auto____11_4; var tmp24 any; var root_443 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_908000068__12; if linked_444 == nil { tmp24 = ifn_445.Invoke_O__O(arg_446) } else { tmp24 = linked_444.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____13_4 any; var root_447 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_908000068__12; if linked_448 == nil { c__1927000678__auto____13_4 = ifn_449.Invoke_O__O(arg_450) } else { c__1927000678__auto____13_4 = linked_448.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_447, arg_450) }; var tmp25 any; var root_503 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_908000068__12; if linked_504 == nil { tmp25 = ifn_505.Invoke_O__O(arg_506) } else { tmp25 = linked_504.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_503, arg_506) }; seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = tmp25, c__1927000678__auto____13_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var n__13_4 any; var root_451 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = seq_908000068__12; if linked_452 == nil { n__13_4 = ifn_453.Invoke_O__O(arg_454) } else { n__13_4 = linked_452.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_451, arg_454) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__13_4, A_arbace_c2j_check_A_const_71); var tmp26 any; var root_507 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_908000068__12; if linked_508 == nil { tmp26 = ifn_509.Invoke_O__O(arg_510) } else { tmp26 = linked_508.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_507, arg_510) }; seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = tmp26, nil, 0, 0; continue L4 } } }
//line :33:1
		break L4 }; var seq_908000072__7 any; var root_455 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_457 lang.IFn; if


















	linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = order__2; if linked_456 == nil { seq_908000072__7 = ifn_457.Invoke_O__O(arg_458) } else { seq_908000072__7 = linked_456.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_455, arg_458) }; var chunk_908000073__8 any; var count_908000074__9 int64 = 0; var i_908000075__10 int64 = 0; L5:
//line :33:1
	for {


















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000075__10, count_908000074__9) { var n__11_5 any = lang.Indexed_Cast(chunk_908000073__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000075__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__11_5, A_arbace_c2j_check_A_const_72.GetRawRoot__O()); seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = seq_908000072__7, chunk_908000073__8, count_908000074__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000075__10); continue L5 } else { var temp__1927000414__auto____11_5 any; var root_459 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = seq_908000072__7; if linked_460 == nil { temp__1927000414__auto____11_5 = ifn_461.Invoke_O__O(arg_462) } else { temp__1927000414__auto____11_5 = linked_460.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_459, arg_462) }; if jrt.J2g_Truth(temp__1927000414__auto____11_5) { var seq_908000072__12 any = temp__1927000414__auto____11_5; var tmp27 any; var root_463 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = seq_908000072__12; if linked_464 == nil { tmp27 = ifn_465.Invoke_O__O(arg_466) } else { tmp27 = linked_464.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_463, arg_466) }; if jrt.J2g_Truth(tmp27) { var c__1927000678__auto____13_5 any; var root_467 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = seq_908000072__12; if linked_468 == nil { c__1927000678__auto____13_5 = ifn_469.Invoke_O__O(arg_470) } else { c__1927000678__auto____13_5 = linked_468.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_467, arg_470) }; var tmp28 any; var root_511 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_908000072__12; if linked_512 == nil { tmp28 = ifn_513.Invoke_O__O(arg_514) } else { tmp28 = linked_512.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_511, arg_514) }; seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = tmp28, c__1927000678__auto____13_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var n__13_5 any; var root_471 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq_908000072__12; if linked_472 == nil { n__13_5 = ifn_473.Invoke_O__O(arg_474) } else { n__13_5 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__13_5, A_arbace_c2j_check_A_const_72.GetRawRoot__O()); var tmp29 any; var root_515 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = seq_908000072__12; if linked_516 == nil { tmp29 = ifn_517.Invoke_O__O(arg_518) } else { tmp29 = linked_516.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_515, arg_518) }; seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = tmp29, nil, 0, 0; continue L5 } } }
//line :33:1
		break L5 };



















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_17); var tmp30 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()); var tmp31 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__1)).Ref(); var tmp32 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(order__2)).Ref(); var tmp33 any; var root_345 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_347 lang.IFn; if
	linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = fails__3; if linked_346 == nil { tmp33 = ifn_347.Invoke_O__O(arg_348) } else { tmp33 = linked_346.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_345, arg_348) }; /*line :54:1*/tmp30.Invoke_O_O_O_O_O_O_O__O(Lit_18, tmp31, Lit_19, tmp32, Lit_20, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp33)).Ref(), Lit_21); var root_315 any = /*line :34:1*/A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = fails__3; if linked_316 == nil { return ifn_317.Invoke_O__O(arg_318) } else { return linked_316.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_315, arg_318) } }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A{}; t.Ctor_O(p0); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Invoke_O_O__O(self, s__908000043__1 any) any { var tmp1 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(t.F_ns, self, s__908000043__1); var tmp2 *jrt.Class; var fncls__287 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class; if fncls__287 == nil { var fncls__287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class = fncls__287d; tmp2 = fncls__287d } else { tmp2 = fncls__287 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Ctor_O_O_O(c__ns, c__iter__908000042, c__s__908000043 any) { t.F_ns = c__ns; t.F_iter__908000042 = c__iter__908000042; t.F_s__908000043 = c__s__908000043 }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Invoke_O__O(self any) any { { var s__908000043__1 any; var t_ any = t.F_s__908000043; t.F_s__908000043 = nil; s__908000043__1 = t_; for { var temp__1927000414__auto____2 any; var root_210 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = s__908000043__1; if linked_211 == nil { temp__1927000414__auto____2 = ifn_212.Invoke_O__O(arg_213) } else { temp__1927000414__auto____2 = linked_211.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_210, arg_213) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000043__3 any = temp__1927000414__auto____2; var tmp1 any; var root_214 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = s__908000043__3; if linked_215 == nil { tmp1 = ifn_216.Invoke_O__O(arg_217) } else { tmp1 = linked_215.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_218 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = s__908000043__3; if linked_219 == nil { c__1927001037__auto____4 = ifn_220.Invoke_O__O(arg_221) } else { c__1927001037__auto____4 = linked_219.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_218, arg_221) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000045__6 any; var root_222 any = A_arbace_c2j_check_A_const_34.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_223 == nil { b__908000045__6 = ifn_224.Invoke_O__O(arg_225) } else { b__908000045__6 = linked_223.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_222, arg_225) }; var tmp2 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(t.F_ns, b__908000045__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class = fncls__241d; tmp3 = fncls__241d } else { tmp3 = fncls__241 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_250 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any; var root_242 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = b__908000045__6; if linked_243 == nil { arg_253 = ifn_244.Invoke_O__O(arg_245) } else { arg_253 = linked_243.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_242, arg_245) }; var arg_254 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); var tmp5 any; var root_246 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = s__908000043__3; if linked_247 == nil { tmp5 = ifn_248.Invoke_O__O(arg_249) } else { tmp5 = linked_247.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_246, arg_249) }; arg_254 = tmp4.Invoke_O__O(tmp5); if linked_251 == nil { return ifn_252.Invoke_O_O__O(arg_253, arg_254) } else { return linked_251.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_250, arg_253, arg_254) } } else { var root_259 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any; var root_255 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = b__908000045__6; if linked_256 == nil { arg_262 = ifn_257.Invoke_O__O(arg_258) } else { arg_262 = linked_256.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_255, arg_258) }; var arg_263 any; if linked_260 == nil { return ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { return linked_260.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) } } } else { var f__4 any; var root_264 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = s__908000043__3; if linked_265 == nil { f__4 = ifn_266.Invoke_O__O(arg_267) } else { f__4 = linked_265.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_264, arg_267) }; var root_282 any = A_arbace_c2j_check_A_const_42.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var root_273 any = A_arbace_c2j_check_A_const_50.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_275 lang.IFn
															if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = A_arbace_c2j_check_A_const_56; var arg_277 any; var root_268 any = A_arbace_c2j_check_A_const_52.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_53, t.F_ns, A_arbace_c2j_check_A_const_54, A_arbace_c2j_check_A_const_55)); var arg_272 any = f__4; if linked_269 == nil { arg_277 = ifn_270.Invoke_O_O__O(arg_271, arg_272) } else { arg_277 = linked_269.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_268, arg_271, arg_272) }; if linked_274 == nil { arg_285 = ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { arg_285 = linked_274.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_273, arg_276, arg_277) }
//line :34:1
	var arg_286 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); var tmp7 any; var root_278 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = s__908000043__3; if linked_279 == nil { tmp7 = ifn_280.Invoke_O__O(arg_281) } else { tmp7 = linked_279.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_278, arg_281) }; arg_286 = tmp6.Invoke_O__O(tmp7); if linked_283 == nil { return ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { return linked_283.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Ctor_O_O_I_O(c__ns, c__b__908000045 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ns = c__ns; t.F_b__908000045 = c__b__908000045; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Invoke_O__O(self any) any { { var i__908000044__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000044__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000044__1)); var root_236 any = A_arbace_c2j_check_A_const_37.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = t.F_b__908000045; var arg_240 any; var root_231 any = A_arbace_c2j_check_A_const_50.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_233 lang.IFn
																	if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = A_arbace_c2j_check_A_const_51; var arg_235 any; var root_226 any = A_arbace_c2j_check_A_const_52.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_53, t.F_ns, A_arbace_c2j_check_A_const_54, A_arbace_c2j_check_A_const_55)); var arg_230 any = f__2; if linked_227 == nil { arg_235 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { arg_235 = linked_227.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_226, arg_229, arg_230) }; if linked_232 == nil { arg_240 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { arg_240 = linked_232.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }
//line :34:1
	if linked_237 == nil { ifn_238.Invoke_O_O__O(arg_239, arg_240) } else { linked_237.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_236, arg_239, arg_240) }; i__908000044__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000044__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Ctor_O(c__fails any) { t.F_fails = c__fails }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Invoke_O_O_O_O__O(self, what__1, n__2, f__3 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																tmp1 = lang.IFn_Cast(f__3).Invoke_O__O(n__2)
//line :38:1
	return nil }(); if tmp2 != nil { if true { var t__6 jrt.Throwable_I = tmp2

		lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_25, what__1, n__2, t__6.GetMessage__String().Ref())
		var root_301 any = A_arbace_c2j_check_A_const_60.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = t.F_fails; var arg_305 any = A_arbace_c2j_check_A_const_11.GetRawRoot__O(); var arg_306 any = lang.Tuple_Create_O_O_O__IPersistentVector(n__2, what__1, t__6.GetMessage__String().Ref()); if linked_302 == nil { tmp1 = ifn_303.Invoke_O_O_O__O(arg_304, arg_305, arg_306) } else { tmp1 = linked_302.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_301, arg_304, arg_305, arg_306) } } }; return tmp1 }

func A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_lap__908000054_A{}; t.Ctor_O(p0); return t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()); var tmp2 jrt.Number_I; var na_328 int64 = x__2; var na_329 any; var root_330 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = t.F_t; if linked_331 == nil { na_329 = ifn_332.Invoke_O__O(arg_333) } else { na_329 = linked_331.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_330, arg_333) }; if jrt.Long_InstanceOf(na_329) { var n0_334 int64 = na_328; var n1_335 int64 = jrt.NN(jrt.Long_Cast(na_329)).LongValue__J(); var nr_336 int64 = n0_334 - n1_335; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_335 == -9223372036854775808); if tmp4 { tmp4 = (n0_334^n1_335)&(n0_334^nr_336) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_336)) } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_328, na_329) } } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_328, na_329) }; tmp1.Invoke_O_O_O_O__O(Lit_18, k__1, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D_NoInit(tmp2, 1.0e7)), 100.0)).Ref(), Lit_24); var root_323 any = A_arbace_c2j_check_A_const_62.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = t.F_t; var arg_327 any = jrt.Long_ValueOf_J__Long_NoInit(x__2).Ref(); if linked_324 == nil { return ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { return linked_324.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_323, arg_326, arg_327) } }




















































































type A_arbace_c2j_check_A struct{ jrt.Object }

var A_arbace_c2j_check_A_const_pool *jrt.RefArray

var A_arbace_c2j_check_A_const_0 *lang.Var

var A_arbace_c2j_check_A_const_1 any

var A_arbace_c2j_check_A_const_2 any

var A_arbace_c2j_check_A_const_3 any

var A_arbace_c2j_check_A_const_4 any

var A_arbace_c2j_check_A_const_5 any

var A_arbace_c2j_check_A_const_6 *lang.Var

var A_arbace_c2j_check_A_const_7 any

var A_arbace_c2j_check_A_const_8 *lang.Var

var A_arbace_c2j_check_A_const_9 *lang.Var

var A_arbace_c2j_check_A_const_10 *lang.Var

var A_arbace_c2j_check_A_const_11 *lang.Var

var A_arbace_c2j_check_A_const_12 any

var A_arbace_c2j_check_A_const_13 *lang.Var

var A_arbace_c2j_check_A_const_14 *lang.Var

var A_arbace_c2j_check_A_const_15 *lang.Var

var A_arbace_c2j_check_A_const_16 *lang.Var

var A_arbace_c2j_check_A_const_17 *lang.Keyword

var A_arbace_c2j_check_A_const_18 *lang.Var

var A_arbace_c2j_check_A_const_19 *lang.Var

var A_arbace_c2j_check_A_const_20 any

var A_arbace_c2j_check_A_const_21 *lang.Var

var A_arbace_c2j_check_A_const_22 *lang.Var

var A_arbace_c2j_check_A_const_23 *lang.Var

var A_arbace_c2j_check_A_const_24 *lang.Var

var A_arbace_c2j_check_A_const_25 *lang.Var

var A_arbace_c2j_check_A_const_26 *lang.Var

var A_arbace_c2j_check_A_const_27 *lang.Var

var A_arbace_c2j_check_A_const_28 *lang.Var

var A_arbace_c2j_check_A_const_29 *lang.Var

var A_arbace_c2j_check_A_const_30 *lang.Var

var A_arbace_c2j_check_A_const_31 *lang.Var

var A_arbace_c2j_check_A_const_32 *lang.Var

var A_arbace_c2j_check_A_const_33 *lang.Var

var A_arbace_c2j_check_A_const_34 *lang.Var

var A_arbace_c2j_check_A_const_35 *lang.Var

var A_arbace_c2j_check_A_const_36 any

var A_arbace_c2j_check_A_const_37 *lang.Var

var A_arbace_c2j_check_A_const_38 *lang.Var

var A_arbace_c2j_check_A_const_39 *lang.Var

var A_arbace_c2j_check_A_const_40 *lang.Var

var A_arbace_c2j_check_A_const_41 *lang.Var

var A_arbace_c2j_check_A_const_42 *lang.Var

var A_arbace_c2j_check_A_const_43 *lang.Var

var A_arbace_c2j_check_A_const_44 *lang.Var

var A_arbace_c2j_check_A_const_45 *lang.Var

var A_arbace_c2j_check_A_const_46 any

var A_arbace_c2j_check_A_const_47 *lang.Var

var A_arbace_c2j_check_A_const_48 *lang.Var

var A_arbace_c2j_check_A_const_49 *lang.Var

var A_arbace_c2j_check_A_const_50 *lang.Var

var A_arbace_c2j_check_A_const_51 any

var A_arbace_c2j_check_A_const_52 *lang.Var

var A_arbace_c2j_check_A_const_53 *lang.Keyword

var A_arbace_c2j_check_A_const_54 *lang.Keyword

var A_arbace_c2j_check_A_const_55 *lang.Keyword

var A_arbace_c2j_check_A_const_56 any

var A_arbace_c2j_check_A_const_57 *lang.Keyword

var A_arbace_c2j_check_A_const_58 *lang.Var

var A_arbace_c2j_check_A_const_59 *lang.Var

var A_arbace_c2j_check_A_const_60 *lang.Var

var A_arbace_c2j_check_A_const_61 *lang.Var

var A_arbace_c2j_check_A_const_62 *lang.Var

var A_arbace_c2j_check_A_const_63 *lang.Var

var A_arbace_c2j_check_A_const_64 *lang.Keyword

var A_arbace_c2j_check_A_const_65 *lang.Var

var A_arbace_c2j_check_A_const_66 *lang.Var

var A_arbace_c2j_check_A_const_67 *lang.Var

var A_arbace_c2j_check_A_const_68 *lang.Var

var A_arbace_c2j_check_A_const_69 *lang.Var

var A_arbace_c2j_check_A_const_70 *lang.Var

var A_arbace_c2j_check_A_const_71 *lang.Var

var A_arbace_c2j_check_A_const_72 *lang.Var

var A_arbace_c2j_check_A_const_73 any

var A_arbace_c2j_check_A_const_74 *lang.Var

var A_arbace_c2j_check_A_const_75 *lang.Var

var A_arbace_c2j_check_A_const_76 *lang.Keyword

var A_arbace_c2j_check_A_const_77 *lang.Keyword

var A_arbace_c2j_check_A_const_78 *lang.Keyword

var A_arbace_c2j_check_A_const_79 *lang.Keyword

var A_arbace_c2j_check_A_const_80 *lang.Keyword

var A_arbace_c2j_check_A_const_81 *lang.Keyword

var A_arbace_c2j_check_A_init jrt.ClassInit

func A_arbace_c2j_check_A_Init() { if !A_arbace_c2j_check_A_init.Done() { A_arbace_c2j_check_A_init.Run(A_arbace_c2j_check_A_clinit) } }

func A_arbace_c2j_check_A_clinit() { A_arbace_c2j_check_A_clinit_p0(); A_arbace_c2j_check_A_clinit_p1(); A_arbace_c2j_check_A_clinit_p2(); A_arbace_c2j_check_A_clinit_p3(); A_arbace_c2j_check_A_clinit_p4(); A_arbace_c2j_check_A_clinit_p5(); A_arbace_c2j_check_A_clinit_p6() }

func A_arbace_c2j_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 110); A_arbace_c2j_check_A_const_0 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[28]); A_arbace_c2j_check_A_const_1 = A_arbace_c2j_check_A_const_pool.A[29]; A_arbace_c2j_check_A_const_2 = A_arbace_c2j_check_A_const_pool.A[30]; A_arbace_c2j_check_A_const_3 = A_arbace_c2j_check_A_const_pool.A[31]; A_arbace_c2j_check_A_const_4 = A_arbace_c2j_check_A_const_pool.A[32]; A_arbace_c2j_check_A_const_5 = A_arbace_c2j_check_A_const_pool.A[33]; A_arbace_c2j_check_A_const_6 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[34]); A_arbace_c2j_check_A_const_7 = A_arbace_c2j_check_A_const_pool.A[35]; A_arbace_c2j_check_A_const_8 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[36]); A_arbace_c2j_check_A_const_9 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[37]); A_arbace_c2j_check_A_const_10 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[38]); A_arbace_c2j_check_A_const_11 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[39]); A_arbace_c2j_check_A_const_12 = A_arbace_c2j_check_A_const_pool.A[40] }

func A_arbace_c2j_check_A_clinit_p1() { A_arbace_c2j_check_A_const_13 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[41]); A_arbace_c2j_check_A_const_14 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[42]); A_arbace_c2j_check_A_const_15 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[43]); A_arbace_c2j_check_A_const_16 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[44]); A_arbace_c2j_check_A_const_17 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[45]); A_arbace_c2j_check_A_const_18 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[46]); A_arbace_c2j_check_A_const_19 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[47]); A_arbace_c2j_check_A_const_20 = A_arbace_c2j_check_A_const_pool.A[48]; A_arbace_c2j_check_A_const_21 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[49]); A_arbace_c2j_check_A_const_22 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[50]); A_arbace_c2j_check_A_const_23 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[51]); A_arbace_c2j_check_A_const_24 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[52]) }

func A_arbace_c2j_check_A_clinit_p2() { A_arbace_c2j_check_A_const_25 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[53]); A_arbace_c2j_check_A_const_26 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[54]); A_arbace_c2j_check_A_const_27 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[55]); A_arbace_c2j_check_A_const_28 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[56]); A_arbace_c2j_check_A_const_29 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[57]); A_arbace_c2j_check_A_const_30 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[58]); A_arbace_c2j_check_A_const_31 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[59]); A_arbace_c2j_check_A_const_32 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[60]); A_arbace_c2j_check_A_const_33 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[61]); A_arbace_c2j_check_A_const_34 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[62]); A_arbace_c2j_check_A_const_35 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[63]); A_arbace_c2j_check_A_const_36 = A_arbace_c2j_check_A_const_pool.A[64] }

func A_arbace_c2j_check_A_clinit_p3() { A_arbace_c2j_check_A_const_37 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[65]); A_arbace_c2j_check_A_const_38 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[66]); A_arbace_c2j_check_A_const_39 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[67]); A_arbace_c2j_check_A_const_40 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[68]); A_arbace_c2j_check_A_const_41 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[69]); A_arbace_c2j_check_A_const_42 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[70]); A_arbace_c2j_check_A_const_43 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[71]); A_arbace_c2j_check_A_const_44 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[72]); A_arbace_c2j_check_A_const_45 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[73]); A_arbace_c2j_check_A_const_46 = A_arbace_c2j_check_A_const_pool.A[74]; A_arbace_c2j_check_A_const_47 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[75]); A_arbace_c2j_check_A_const_48 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[76]) }

func A_arbace_c2j_check_A_clinit_p4() { A_arbace_c2j_check_A_const_49 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[77]); A_arbace_c2j_check_A_const_50 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[78]); A_arbace_c2j_check_A_const_51 = A_arbace_c2j_check_A_const_pool.A[79]; A_arbace_c2j_check_A_const_52 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[80]); A_arbace_c2j_check_A_const_53 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[81]); A_arbace_c2j_check_A_const_54 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[82]); A_arbace_c2j_check_A_const_55 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[83]); A_arbace_c2j_check_A_const_56 = A_arbace_c2j_check_A_const_pool.A[84]; A_arbace_c2j_check_A_const_57 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[85]); A_arbace_c2j_check_A_const_58 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[86]); A_arbace_c2j_check_A_const_59 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[87]); A_arbace_c2j_check_A_const_60 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[88]) }

func A_arbace_c2j_check_A_clinit_p5() { A_arbace_c2j_check_A_const_61 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[89]); A_arbace_c2j_check_A_const_62 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[90]); A_arbace_c2j_check_A_const_63 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[91]); A_arbace_c2j_check_A_const_64 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[92]); A_arbace_c2j_check_A_const_65 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[93]); A_arbace_c2j_check_A_const_66 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[94]); A_arbace_c2j_check_A_const_67 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[95]); A_arbace_c2j_check_A_const_68 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[96]); A_arbace_c2j_check_A_const_69 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[97]); A_arbace_c2j_check_A_const_70 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[98]); A_arbace_c2j_check_A_const_71 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[99]); A_arbace_c2j_check_A_const_72 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[100]) }

func A_arbace_c2j_check_A_clinit_p6() { A_arbace_c2j_check_A_const_73 = A_arbace_c2j_check_A_const_pool.A[101]; A_arbace_c2j_check_A_const_74 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[102]); A_arbace_c2j_check_A_const_75 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[103]); A_arbace_c2j_check_A_const_76 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[104]); A_arbace_c2j_check_A_const_77 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[105]); A_arbace_c2j_check_A_const_78 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[106]); A_arbace_c2j_check_A_const_79 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[107]); A_arbace_c2j_check_A_const_80 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[108]); A_arbace_c2j_check_A_const_81 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[109]) }

func A_arbace_c2j_check_A_New() *A_arbace_c2j_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_A) Ctor() {}

func (t *A_arbace_c2j_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_A_class }

func (t *A_arbace_c2j_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_A); return ok }

func A_arbace_c2j_check_A_Cast(x any) *A_arbace_c2j_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_A_class)) }; return v }



type A_arbace_c2j_check_check_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000019_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000019_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000037_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000037_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000039_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000039_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_A struct{ j2g_header uint64; F_ns, F_forms any }

var A_arbace_c2j_check_check_fn__908000041_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A struct{ j2g_header uint64; F_ns any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A struct{ j2g_header uint64; F_ns, F_iter__908000042, F_s__908000043 any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A struct{ j2g_header uint64; F_ns, F_b__908000045 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_lap__908000054_A struct{ j2g_header uint64; F_t any }

var A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A struct{ j2g_header uint64; F_fails any }

var A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A struct{ j2g_header uint64; F_iter__908000021, F_s__908000022 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A struct{ j2g_header uint64; F_iter__908000023, F_s__908000024 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__908000026, F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000004_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000004_A_New() *A_arbace_c2j_check_eval908000004_A { t := &A_arbace_c2j_check_eval908000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000004_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000004_A_class }

func (t *A_arbace_c2j_check_eval908000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000004_A); return ok }

func A_arbace_c2j_check_eval908000004_A_Cast(x any) *A_arbace_c2j_check_eval908000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000004_A_class)) }; return v }



type A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000008_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000008_A_New() *A_arbace_c2j_check_eval908000008_A { t := &A_arbace_c2j_check_eval908000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000008_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000008_A_class }

func (t *A_arbace_c2j_check_eval908000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000008_A); return ok }

func A_arbace_c2j_check_eval908000008_A_Cast(x any) *A_arbace_c2j_check_eval908000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000008_A_class)) }; return v }



type A_arbace_c2j_check_eval908000008_fn__908000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000008_fn__908000009_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000013_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_fn__908000013_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000015_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_check_read_all_fn__908000015_A_fn_class *jrt.Class
