//line aot_arbace_c2j_check.ae:1
package aot_arbace_c2j_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_New() *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_check_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_c2j_check_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_c2j_check_A_const_3, A_arbace_c2j_check_A_const_4, A_arbace_c2j_check_A_const_5, A_arbace_c2j_check_A_const_6, A_arbace_c2j_check_A_const_7); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_check_eval908000008_fn__908000009_A_New() *A_arbace_c2j_check_eval908000008_fn__908000009_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000008_fn__908000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_c2j_check_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_12), A_arbace_c2j_check_A_const_10.GetRawRoot__O(), A_arbace_c2j_check_A_const_11) }











func A_arbace_c2j_check_read_all_A_New() *A_arbace_c2j_check_read_all_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Ctor() {}
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_c2j_check_A_const_13.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	lang.IFn_Cast(A_arbace_c2j_check_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_17.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_18, jrt.Boolean_FALSE.Ref()))
//line :13:1
	{ tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_14.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_19.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_check_read_all_fn__908000013_A_New(); var tmp5 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000013_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_c2j_check_read_all_fn__908000013_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_22.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_check_read_all_fn__908000015_A_New_O(r__2); var tmp9 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000015_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_c2j_check_read_all_fn__908000015_A_fn_class = fncls__2d; tmp9 = fncls__2d } else { tmp9 = fncls__2 }; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp6, tmp7.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))) }
//line :13:1
		return nil
	}()
		lang.IFn_Cast(A_arbace_c2j_check_A_const_15.GetRawRoot__O()).Invoke__O()
//line :13:1
		if tmp10 != nil { panic(tmp10) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :13:1*/ tmp11 != nil { panic(tmp11) }; return tmp1 }


func A_arbace_c2j_check_read_all_fn__908000013_A_New() *A_arbace_c2j_check_read_all_fn__908000013_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000013_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Ctor() {}
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Invoke_O_O__O(self, p1__908000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_check_A_const_20.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_21, p1__908000012_SHARP___1) }
//line :16:1
func A_arbace_c2j_check_read_all_fn__908000015_A_New_O(p0 any) *A_arbace_c2j_check_read_all_fn__908000015_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000015_A{}; t.Ctor_O(p0); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_24, t.F_r) }

func A_arbace_c2j_check_check_A_New() *A_arbace_c2j_check_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_c2j_check_check_A) Ctor() {}
//line :18:1
func (t *A_arbace_c2j_check_check_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_25.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_43.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_check_check_fn__908000019_A_New(); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_c2j_check_check_fn__908000019_A_fn_class; if


	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_c2j_check_check_fn__908000019_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; files__2 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_c2j_check_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_46.GetRawRoot__O()).Invoke_O_O__O(dir__0, Lit_2)))); var forms__3 any; var iter__1927001039__auto____3 any; var tmp5 any = /*line :18:1*/A_arbace_c2j_check_check_iter__908000021__908000027_A_New(); var tmp6 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class; if



	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class = fncls__7d; tmp6 = fncls__7d } else { tmp6 = fncls__7 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); forms__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); var ns__4 any = /*line :18:1*/lang.IFn_Cast(A_arbace_c2j_check_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_47);








	lang.IFn_Cast(A_arbace_c2j_check_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_17.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_49, ns__4)); var tmp7 any = A_arbace_c2j_check_check_fn__908000037_A_New(); var tmp8 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c2j_check_check_fn__908000037_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_c2j_check_check_fn__908000037_A_fn_class = fncls__9d; tmp8 = fncls__9d } else { tmp8 = fncls__9 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); var tmp9 lang.IFn =

	lang.IFn_Cast(A_arbace_c2j_check_A_const_17.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_check_A_const_50; var tmp11 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp12 any = A_arbace_c2j_check_A_const_52; var tmp13 any = A_arbace_c2j_check_A_const_53; var tmp14 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); var tmp15 any = A_arbace_c2j_check_A_const_54; var tmp16 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp17 any = A_arbace_c2j_check_A_const_55; var tmp18 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp19 any = A_arbace_c2j_check_A_const_56; var tmp20 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp21 any = A_arbace_c2j_check_A_const_57; var tmp22 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentHashSet_EMPTY.Ref()); var tmp23 any = A_arbace_c2j_check_A_const_58; var tmp24 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp25 any = A_arbace_c2j_check_A_const_59; lang.IFn_Cast(A_arbace_c2j_check_A_const_16.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()))))); var tmp26 any; tmp34 := /*line :18:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














		{ var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_42.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_check_A_const_60; var tmp29 any = A_arbace_c2j_check_check_fn__908000039_A_New(); var tmp30 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_c2j_check_check_fn__908000039_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_c2j_check_check_fn__908000039_A_fn_class = fncls__10d; tmp30 = fncls__10d } else { tmp30 = fncls__10 }; var tmp31 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil))); var tmp32 any = A_arbace_c2j_check_check_fn__908000041_A_New_O_O(ns__4, forms__3); var tmp33 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_c2j_check_check_fn__908000041_A_fn_class = fncls__21d; tmp33 = fncls__21d } else { tmp33 = fncls__21 }; tmp26 = tmp27.Invoke_O_O__O(tmp31, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil)) }
//line :18:1
		return nil }();










	lang.IFn_Cast(A_arbace_c2j_check_A_const_15.GetRawRoot__O()).Invoke__O(); if /*line :18:1*/ tmp34 != nil { panic(tmp34) }; return tmp26 }


func A_arbace_c2j_check_check_fn__908000019_A_New() *A_arbace_c2j_check_check_fn__908000019_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000019_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Ctor() {}
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Invoke_O_O__O(self, p1__908000018_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(lang.IFn_Cast(A_arbace_c2j_check_A_const_44.GetRawRoot__O()).Invoke_O__O(p1__908000018_SHARP___1))).EndsWith_String__Z(Lit_7)).Ref() }
func A_arbace_c2j_check_check_iter__908000021__908000027_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Invoke_O_O__O(self, s__908000022__1 any) any { var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(self, s__908000022__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Ctor_O_O(c__iter__908000021, c__s__908000022 any) { t.F_iter__908000021 = c__iter__908000021; t.F_s__908000022 = c__s__908000022 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Invoke_O__O(self any) any { { var s__908000022__1 any; var t_ any = t.F_s__908000022; t.F_s__908000022 = nil; s__908000022__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(s__908000022__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_40.GetRawRoot__O()).Invoke_O__O(f__4))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__908000021); return lang.IFn_Cast(A_arbace_c2j_check_A_const_39.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_34.GetRawRoot__O()).Invoke_O__O(s__908000022__1))) } else { s__908000022__1 = lang.IFn_Cast(A_arbace_c2j_check_A_const_34.GetRawRoot__O()).Invoke_O__O(s__908000022__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Invoke_O_O__O(self, s__908000024__1 any) any { var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(self, s__908000024__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Ctor_O_O(c__iter__908000023, c__s__908000024 any) { t.F_iter__908000023 = c__iter__908000023; t.F_s__908000024 = c__s__908000024 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Invoke_O__O(self any) any { { var s__908000024__1 any; var t_ any = t.F_s__908000024; t.F_s__908000024 = nil; s__908000024__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(s__908000024__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000024__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_28.GetRawRoot__O()).Invoke_O__O(s__908000024__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_29.GetRawRoot__O()).Invoke_O__O(s__908000024__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000026__6 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_30.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(size__1927001038__auto____5, b__908000026__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); return lang.IFn_Cast(A_arbace_c2j_check_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_37.GetRawRoot__O()).Invoke_O__O(b__908000026__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_38.GetRawRoot__O()).Invoke_O__O(s__908000024__3))) } else { return lang.IFn_Cast(A_arbace_c2j_check_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_37.GetRawRoot__O()).Invoke_O__O(b__908000026__6), nil) } } else { var fm__4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(s__908000024__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__4)

	if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp5 any = A_arbace_c2j_check_A_const_32; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(fm__4))).Ref() } else { tmp4 = and__1927000168__auto____5 }
//line :22:1
	if jrt.J2g_Truth(tmp4) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); return lang.IFn_Cast(A_arbace_c2j_check_A_const_36.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_34.GetRawRoot__O()).Invoke_O__O(fm__4), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_34.GetRawRoot__O()).Invoke_O__O(s__908000024__3))) } else { s__908000024__1 = lang.IFn_Cast(A_arbace_c2j_check_A_const_34.GetRawRoot__O()).Invoke_O__O(s__908000024__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__908000026, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__908000026 = c__b__908000026; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Invoke_O__O(self any) any { { var i__908000025__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000025__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000025__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__2)

	if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_c2j_check_A_const_32; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :22:1
	if jrt.J2g_Truth(tmp2) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_33.GetRawRoot__O()); var tmp5 any = t.F_b__908000026; tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_check_A_const_34.GetRawRoot__O()).Invoke_O__O(fm__2)); i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } else { i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_check_check_fn__908000037_A_New() *A_arbace_c2j_check_check_fn__908000037_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000037_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Ctor() {}
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										tmp1 = lang.IFn_Cast(A_arbace_c2j_check_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_48)
//line :27:1
	return nil }(); lang.IFn_Cast(A_arbace_c2j_check_A_const_15.GetRawRoot__O()).Invoke__O(); if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_c2j_check_check_fn__908000039_A_New() *A_arbace_c2j_check_check_fn__908000039_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000039_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Ctor() {}
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Invoke_O_O_O__O(self, ___1, node__2 any) any { return node__2 }
//line :33:1
func A_arbace_c2j_check_check_fn__908000041_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_fn__908000041_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Ctor_O_O(c__ns, c__forms any) { t.F_ns = c__ns; t.F_forms = c__forms }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Invoke_O__O(self any) any { var names__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____1 any; var tmp3 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(t.F_ns); var tmp4 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class; if
										fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(t.F_forms); names__1 = tmp1.Invoke_O__O(tmp2); var tmp5 /*line :33:1*/*lang.Keyword = A_arbace_c2j_check_A_const_53; var order__2 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_9.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_c2j_check_A_const_52.Get__O())); var fails__3 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); var try_BANG___4 any; var tmp6 any = A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(fails__3); var tmp7 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class; if




	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class = fncls__11d; tmp7 = fncls__11d } else { tmp7 = fncls__11 }; try_BANG___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var t__5 any = /*line :33:1*/lang.IFn_Cast(A_arbace_c2j_check_A_const_51.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref()); var lap__6 any; var tmp8 any = A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(t__5); var tmp9 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class; if









	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class = fncls__20d; tmp9 = fncls__20d } else { tmp9 = fncls__20 }; lap__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil);
	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_11); var seq_908000056__7 any = /*line :33:1*/lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(order__2); var chunk_908000057__8 any; var count_908000058__9 int64 = 0; var i_908000059__10 int64 = 0; L1: for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000059__10, count_908000058__9) { var n__11 any = lang.Indexed_Cast(chunk_908000057__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000059__10)); var tmp10 *lang.Keyword = A_arbace_c2j_check_A_const_73; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_74.GetRawRoot__O()).Invoke_O__O(n__11)))) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__11, A_arbace_c2j_check_A_const_75.GetRawRoot__O()); seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } else { seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_908000056__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_908000056__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_908000056__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_908000056__12); seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_908000056__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__13 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_908000056__12); var tmp11 *lang.Keyword = A_arbace_c2j_check_A_const_73; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_74.GetRawRoot__O()).Invoke_O__O(n__13)))) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__13, A_arbace_c2j_check_A_const_75.GetRawRoot__O()); seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_908000056__12), nil, 0, 0; continue L1 } else { seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_908000056__12), nil, 0, 0; continue L1 } } } }
//line :33:1
		break L1 };












	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_13); var seq_908000060__7 any = /*line :33:1*/lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(order__2); var chunk_908000061__8 any; var count_908000062__9 int64 = 0; var i_908000063__10 int64 = 0; L2: for {













		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000063__10, count_908000062__9) { var n__11_2 any = lang.Indexed_Cast(chunk_908000061__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000063__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__11_2, A_arbace_c2j_check_A_const_77.GetRawRoot__O()); seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = seq_908000060__7, chunk_908000061__8, count_908000062__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000063__10); continue L2 } else { var temp__1927000414__auto____11_2 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_908000060__7); if jrt.J2g_Truth(temp__1927000414__auto____11_2) { var seq_908000060__12 any = temp__1927000414__auto____11_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_908000060__12)) { var c__1927000678__auto____13_2 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_908000060__12); seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_908000060__12), c__1927000678__auto____13_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var n__13_2 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_908000060__12); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__13_2, A_arbace_c2j_check_A_const_77.GetRawRoot__O()); seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_908000060__12), nil, 0, 0; continue L2 } } }
//line :33:1
		break L2 };














	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_14); var seq_908000064__7 any = /*line :33:1*/lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_78.Invoke_O__O(order__2)); var chunk_908000065__8 any; var count_908000066__9 int64 = 0; var i_908000067__10 int64 = 0; L3: for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000067__10, count_908000066__9) { var n__11_3 any = lang.Indexed_Cast(chunk_908000065__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000067__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__11_3, A_arbace_c2j_check_A_const_79.GetRawRoot__O()); seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = seq_908000064__7, chunk_908000065__8, count_908000066__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000067__10); continue L3 } else { var temp__1927000414__auto____11_3 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_908000064__7); if jrt.J2g_Truth(temp__1927000414__auto____11_3) { var seq_908000064__12 any = temp__1927000414__auto____11_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_908000064__12)) { var c__1927000678__auto____13_3 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_908000064__12); seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_908000064__12), c__1927000678__auto____13_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var n__13_3 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_908000064__12); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__13_3, A_arbace_c2j_check_A_const_79.GetRawRoot__O()); seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_908000064__12), nil, 0, 0; continue L3 } } }
//line :33:1
		break L3 };
















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_15); var seq_908000068__7 any = /*line :33:1*/lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(order__2); var chunk_908000069__8 any; var count_908000070__9 int64 = 0; var i_908000071__10 int64 = 0; L4: for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000071__10, count_908000070__9) { var n__11_4 any = lang.Indexed_Cast(chunk_908000069__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000071__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__11_4, A_arbace_c2j_check_A_const_80); seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = seq_908000068__7, chunk_908000069__8, count_908000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000071__10); continue L4 } else { var temp__1927000414__auto____11_4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_908000068__7); if jrt.J2g_Truth(temp__1927000414__auto____11_4) { var seq_908000068__12 any = temp__1927000414__auto____11_4; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_908000068__12)) { var c__1927000678__auto____13_4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_908000068__12); seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_908000068__12), c__1927000678__auto____13_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var n__13_4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_908000068__12); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__13_4, A_arbace_c2j_check_A_const_80); seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_908000068__12), nil, 0, 0; continue L4 } } }
//line :33:1
		break L4 }; var seq_908000072__7 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(order__2); var chunk_908000073__8 any; var count_908000074__9 int64 = 0; var i_908000075__10 int64 = 0; L5: for {


















			if lang.Numbers_Lt_J_J__Z_NoInit(i_908000075__10, count_908000074__9) { var n__11_5 any = lang.Indexed_Cast(chunk_908000073__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000075__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__11_5, A_arbace_c2j_check_A_const_81.GetRawRoot__O()); seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = seq_908000072__7, chunk_908000073__8, count_908000074__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000075__10); continue L5 } else { var temp__1927000414__auto____11_5 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_908000072__7); if jrt.J2g_Truth(temp__1927000414__auto____11_5) { var seq_908000072__12 any = temp__1927000414__auto____11_5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_908000072__12)) { var c__1927000678__auto____13_5 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_908000072__12); seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_908000072__12), c__1927000678__auto____13_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var n__13_5 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_908000072__12); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__13_5, A_arbace_c2j_check_A_const_81.GetRawRoot__O()); seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = lang.IFn_Cast(A_arbace_c2j_check_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_908000072__12), nil, 0, 0; continue L5 } } }
//line :33:1
			break L5 };



















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_17);
	lang.IFn_Cast(A_arbace_c2j_check_A_const_63.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(Lit_18, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__1)).Ref(), Lit_19, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(order__2)).Ref(), Lit_20, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_c2j_check_A_const_9.GetRawRoot__O()).Invoke_O__O(fails__3))).Ref(), Lit_21); return /*line :34:1*/ lang.IFn_Cast(A_arbace_c2j_check_A_const_9.GetRawRoot__O()).Invoke_O__O(fails__3) }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A{}; t.Ctor_O(p0); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Invoke_O_O__O(self, s__908000043__1 any) any { var tmp1 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(t.F_ns, self, s__908000043__1); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Ctor_O_O_O(c__ns, c__iter__908000042, c__s__908000043 any) { t.F_ns = c__ns; t.F_iter__908000042 = c__iter__908000042; t.F_s__908000043 = c__s__908000043 }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Invoke_O__O(self any) any { { var s__908000043__1 any; var t_ any = t.F_s__908000043; t.F_s__908000043 = nil; s__908000043__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_26.GetRawRoot__O()).Invoke_O__O(s__908000043__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000043__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_check_A_const_28.GetRawRoot__O()).Invoke_O__O(s__908000043__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_29.GetRawRoot__O()).Invoke_O__O(s__908000043__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000045__6 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_30.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(t.F_ns, b__908000045__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); return lang.IFn_Cast(A_arbace_c2j_check_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_37.GetRawRoot__O()).Invoke_O__O(b__908000045__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_38.GetRawRoot__O()).Invoke_O__O(s__908000043__3))) } else { return lang.IFn_Cast(A_arbace_c2j_check_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_37.GetRawRoot__O()).Invoke_O__O(b__908000045__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_27.GetRawRoot__O()).Invoke_O__O(s__908000043__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_64.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_check_A_const_70; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); return lang.IFn_Cast(A_arbace_c2j_check_A_const_36.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_check_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_67, t.F_ns, A_arbace_c2j_check_A_const_68, A_arbace_c2j_check_A_const_69)), f__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_check_A_const_34.GetRawRoot__O()).Invoke_O__O(s__908000043__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Ctor_O_O_I_O(c__ns, c__b__908000045 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ns = c__ns; t.F_b__908000045 = c__b__908000045; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Invoke_O__O(self any) any { { var i__908000044__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000044__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000044__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_33.GetRawRoot__O()); var tmp3 any = t.F_b__908000045; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_64.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_check_A_const_65; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_check_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_67, t.F_ns, A_arbace_c2j_check_A_const_68, A_arbace_c2j_check_A_const_69)), f__2))); i__908000044__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000044__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Ctor_O(c__fails any) { t.F_fails = c__fails }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Invoke_O_O_O_O__O(self, what__1, n__2, f__3 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																tmp1 = lang.IFn_Cast(f__3).Invoke_O__O(n__2)
//line :38:1
	return nil }(); if tmp2 != nil { if true { var t__6 jrt.Throwable_I = tmp2

		lang.IFn_Cast(A_arbace_c2j_check_A_const_63.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_25, what__1, n__2, t__6.GetMessage__String().Ref())
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_62.GetRawRoot__O()); var tmp4 any = t.F_fails; tmp1 = tmp3.Invoke_O_O_O__O(tmp4, A_arbace_c2j_check_A_const_10.GetRawRoot__O(), lang.Tuple_Create_O_O_O__IPersistentVector(n__2, what__1, t__6.GetMessage__String().Ref())) } }; return tmp1 }

func A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_lap__908000054_A{}; t.Ctor_O(p0); return t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_63.GetRawRoot__O()); var tmp2 jrt.Number_I; var na_15 int64 = x__2; var na_16 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_t); if jrt.Long_InstanceOf(na_16) { var n0_17 int64 = na_15; var n1_18 int64 = jrt.NN(jrt.Long_Cast(na_16)).LongValue__J(); var nr_19 int64 = n0_17 - n1_18; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_18 == -9223372036854775808); if tmp4 { tmp4 = (n0_17^n1_18)&(n0_17^nr_19) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_19)) } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_15, na_16) } } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_15, na_16) }; tmp1.Invoke_O_O_O_O__O(Lit_18, k__1, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D_NoInit(tmp2, 1.0e7)), 100.0)).Ref(), Lit_24); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_71.GetRawRoot__O()); var tmp6 any = t.F_t; return tmp5.Invoke_O_O__O(tmp6, jrt.Long_ValueOf_J__Long_NoInit(x__2).Ref()) }




















































































type A_arbace_c2j_check_A struct{ jrt.Object }

var A_arbace_c2j_check_A_const_pool *jrt.RefArray

var A_arbace_c2j_check_A_const_0 *lang.Var

var A_arbace_c2j_check_A_const_1 *lang.Var

var A_arbace_c2j_check_A_const_2 any

var A_arbace_c2j_check_A_const_3 any

var A_arbace_c2j_check_A_const_4 any

var A_arbace_c2j_check_A_const_5 any

var A_arbace_c2j_check_A_const_6 any

var A_arbace_c2j_check_A_const_7 any

var A_arbace_c2j_check_A_const_8 *lang.Var

var A_arbace_c2j_check_A_const_9 *lang.Var

var A_arbace_c2j_check_A_const_10 *lang.Var

var A_arbace_c2j_check_A_const_11 any

var A_arbace_c2j_check_A_const_12 *lang.Var

var A_arbace_c2j_check_A_const_13 *lang.Var

var A_arbace_c2j_check_A_const_14 *lang.Var

var A_arbace_c2j_check_A_const_15 *lang.Var

var A_arbace_c2j_check_A_const_16 *lang.Var

var A_arbace_c2j_check_A_const_17 *lang.Var

var A_arbace_c2j_check_A_const_18 *lang.Var

var A_arbace_c2j_check_A_const_19 *lang.Var

var A_arbace_c2j_check_A_const_20 *lang.Var

var A_arbace_c2j_check_A_const_21 *lang.Keyword

var A_arbace_c2j_check_A_const_22 *lang.Var

var A_arbace_c2j_check_A_const_23 *lang.Var

var A_arbace_c2j_check_A_const_24 any

var A_arbace_c2j_check_A_const_25 *lang.Var

var A_arbace_c2j_check_A_const_26 *lang.Var

var A_arbace_c2j_check_A_const_27 *lang.Var

var A_arbace_c2j_check_A_const_28 *lang.Var

var A_arbace_c2j_check_A_const_29 *lang.Var

var A_arbace_c2j_check_A_const_30 *lang.Var

var A_arbace_c2j_check_A_const_31 *lang.Var

var A_arbace_c2j_check_A_const_32 any

var A_arbace_c2j_check_A_const_33 *lang.Var

var A_arbace_c2j_check_A_const_34 *lang.Var

var A_arbace_c2j_check_A_const_35 *lang.Var

var A_arbace_c2j_check_A_const_36 *lang.Var

var A_arbace_c2j_check_A_const_37 *lang.Var

var A_arbace_c2j_check_A_const_38 *lang.Var

var A_arbace_c2j_check_A_const_39 *lang.Var

var A_arbace_c2j_check_A_const_40 *lang.Var

var A_arbace_c2j_check_A_const_41 *lang.Var

var A_arbace_c2j_check_A_const_42 *lang.Var

var A_arbace_c2j_check_A_const_43 *lang.Var

var A_arbace_c2j_check_A_const_44 *lang.Var

var A_arbace_c2j_check_A_const_45 *lang.Var

var A_arbace_c2j_check_A_const_46 *lang.Var

var A_arbace_c2j_check_A_const_47 any

var A_arbace_c2j_check_A_const_48 any

var A_arbace_c2j_check_A_const_49 *lang.Var

var A_arbace_c2j_check_A_const_50 *lang.Var

var A_arbace_c2j_check_A_const_51 *lang.Var

var A_arbace_c2j_check_A_const_52 *lang.Var

var A_arbace_c2j_check_A_const_53 *lang.Keyword

var A_arbace_c2j_check_A_const_54 *lang.Keyword

var A_arbace_c2j_check_A_const_55 *lang.Keyword

var A_arbace_c2j_check_A_const_56 *lang.Keyword

var A_arbace_c2j_check_A_const_57 *lang.Keyword

var A_arbace_c2j_check_A_const_58 *lang.Keyword

var A_arbace_c2j_check_A_const_59 *lang.Keyword

var A_arbace_c2j_check_A_const_60 *lang.Var

var A_arbace_c2j_check_A_const_61 *lang.Var

var A_arbace_c2j_check_A_const_62 *lang.Var

var A_arbace_c2j_check_A_const_63 *lang.Var

var A_arbace_c2j_check_A_const_64 *lang.Var

var A_arbace_c2j_check_A_const_65 any

var A_arbace_c2j_check_A_const_66 *lang.Var

var A_arbace_c2j_check_A_const_67 *lang.Keyword

var A_arbace_c2j_check_A_const_68 *lang.Keyword

var A_arbace_c2j_check_A_const_69 *lang.Keyword

var A_arbace_c2j_check_A_const_70 any

var A_arbace_c2j_check_A_const_71 *lang.Var

var A_arbace_c2j_check_A_const_72 *lang.Var

var A_arbace_c2j_check_A_const_73 *lang.Keyword

var A_arbace_c2j_check_A_const_74 *lang.Var

var A_arbace_c2j_check_A_const_75 *lang.Var

var A_arbace_c2j_check_A_const_76 *lang.Var

var A_arbace_c2j_check_A_const_77 *lang.Var

var A_arbace_c2j_check_A_const_78 *lang.Var

var A_arbace_c2j_check_A_const_79 *lang.Var

var A_arbace_c2j_check_A_const_80 *lang.Var

var A_arbace_c2j_check_A_const_81 *lang.Var

var A_arbace_c2j_check_A_init jrt.ClassInit

func A_arbace_c2j_check_A_Init() { if !A_arbace_c2j_check_A_init.Done() { A_arbace_c2j_check_A_init.Run(A_arbace_c2j_check_A_clinit) } }

func A_arbace_c2j_check_A_clinit() { A_arbace_c2j_check_A_clinit_p0(); A_arbace_c2j_check_A_clinit_p1(); A_arbace_c2j_check_A_clinit_p2(); A_arbace_c2j_check_A_clinit_p3(); A_arbace_c2j_check_A_clinit_p4(); A_arbace_c2j_check_A_clinit_p5(); A_arbace_c2j_check_A_clinit_p6() }

func A_arbace_c2j_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 110); A_arbace_c2j_check_A_const_0 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[28]); A_arbace_c2j_check_A_const_1 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[29]); A_arbace_c2j_check_A_const_2 = A_arbace_c2j_check_A_const_pool.A[30]; A_arbace_c2j_check_A_const_3 = A_arbace_c2j_check_A_const_pool.A[31]; A_arbace_c2j_check_A_const_4 = A_arbace_c2j_check_A_const_pool.A[32]; A_arbace_c2j_check_A_const_5 = A_arbace_c2j_check_A_const_pool.A[33]; A_arbace_c2j_check_A_const_6 = A_arbace_c2j_check_A_const_pool.A[34]; A_arbace_c2j_check_A_const_7 = A_arbace_c2j_check_A_const_pool.A[35]; A_arbace_c2j_check_A_const_8 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[36]); A_arbace_c2j_check_A_const_9 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[37]); A_arbace_c2j_check_A_const_10 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[38]); A_arbace_c2j_check_A_const_11 = A_arbace_c2j_check_A_const_pool.A[39]; A_arbace_c2j_check_A_const_12 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[40]) }

func A_arbace_c2j_check_A_clinit_p1() { A_arbace_c2j_check_A_const_13 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[41]); A_arbace_c2j_check_A_const_14 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[42]); A_arbace_c2j_check_A_const_15 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[43]); A_arbace_c2j_check_A_const_16 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[44]); A_arbace_c2j_check_A_const_17 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[45]); A_arbace_c2j_check_A_const_18 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[46]); A_arbace_c2j_check_A_const_19 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[47]); A_arbace_c2j_check_A_const_20 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[48]); A_arbace_c2j_check_A_const_21 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[49]); A_arbace_c2j_check_A_const_22 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[50]); A_arbace_c2j_check_A_const_23 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[51]); A_arbace_c2j_check_A_const_24 = A_arbace_c2j_check_A_const_pool.A[52] }

func A_arbace_c2j_check_A_clinit_p2() { A_arbace_c2j_check_A_const_25 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[53]); A_arbace_c2j_check_A_const_26 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[54]); A_arbace_c2j_check_A_const_27 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[55]); A_arbace_c2j_check_A_const_28 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[56]); A_arbace_c2j_check_A_const_29 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[57]); A_arbace_c2j_check_A_const_30 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[58]); A_arbace_c2j_check_A_const_31 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[59]); A_arbace_c2j_check_A_const_32 = A_arbace_c2j_check_A_const_pool.A[60]; A_arbace_c2j_check_A_const_33 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[61]); A_arbace_c2j_check_A_const_34 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[62]); A_arbace_c2j_check_A_const_35 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[63]); A_arbace_c2j_check_A_const_36 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[64]) }

func A_arbace_c2j_check_A_clinit_p3() { A_arbace_c2j_check_A_const_37 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[65]); A_arbace_c2j_check_A_const_38 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[66]); A_arbace_c2j_check_A_const_39 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[67]); A_arbace_c2j_check_A_const_40 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[68]); A_arbace_c2j_check_A_const_41 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[69]); A_arbace_c2j_check_A_const_42 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[70]); A_arbace_c2j_check_A_const_43 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[71]); A_arbace_c2j_check_A_const_44 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[72]); A_arbace_c2j_check_A_const_45 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[73]); A_arbace_c2j_check_A_const_46 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[74]); A_arbace_c2j_check_A_const_47 = A_arbace_c2j_check_A_const_pool.A[75]; A_arbace_c2j_check_A_const_48 = A_arbace_c2j_check_A_const_pool.A[76] }

func A_arbace_c2j_check_A_clinit_p4() { A_arbace_c2j_check_A_const_49 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[77]); A_arbace_c2j_check_A_const_50 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[78]); A_arbace_c2j_check_A_const_51 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[79]); A_arbace_c2j_check_A_const_52 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[80]); A_arbace_c2j_check_A_const_53 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[81]); A_arbace_c2j_check_A_const_54 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[82]); A_arbace_c2j_check_A_const_55 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[83]); A_arbace_c2j_check_A_const_56 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[84]); A_arbace_c2j_check_A_const_57 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[85]); A_arbace_c2j_check_A_const_58 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[86]); A_arbace_c2j_check_A_const_59 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[87]); A_arbace_c2j_check_A_const_60 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[88]) }

func A_arbace_c2j_check_A_clinit_p5() { A_arbace_c2j_check_A_const_61 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[89]); A_arbace_c2j_check_A_const_62 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[90]); A_arbace_c2j_check_A_const_63 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[91]); A_arbace_c2j_check_A_const_64 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[92]); A_arbace_c2j_check_A_const_65 = A_arbace_c2j_check_A_const_pool.A[93]; A_arbace_c2j_check_A_const_66 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[94]); A_arbace_c2j_check_A_const_67 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[95]); A_arbace_c2j_check_A_const_68 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[96]); A_arbace_c2j_check_A_const_69 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[97]); A_arbace_c2j_check_A_const_70 = A_arbace_c2j_check_A_const_pool.A[98]; A_arbace_c2j_check_A_const_71 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[99]); A_arbace_c2j_check_A_const_72 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[100]) }

func A_arbace_c2j_check_A_clinit_p6() { A_arbace_c2j_check_A_const_73 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[101]); A_arbace_c2j_check_A_const_74 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[102]); A_arbace_c2j_check_A_const_75 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[103]); A_arbace_c2j_check_A_const_76 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[104]); A_arbace_c2j_check_A_const_77 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[105]); A_arbace_c2j_check_A_const_78 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[106]); A_arbace_c2j_check_A_const_79 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[107]); A_arbace_c2j_check_A_const_80 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[108]); A_arbace_c2j_check_A_const_81 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[109]) }

func A_arbace_c2j_check_A_New() *A_arbace_c2j_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_A) Ctor() {}

func (t *A_arbace_c2j_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_A_class }

func (t *A_arbace_c2j_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_A); return ok }

func A_arbace_c2j_check_A_Cast(x any) *A_arbace_c2j_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_A_class)) }; return v }



type A_arbace_c2j_check_check_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000019_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000019_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000037_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000037_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000039_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000039_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_A struct{ j2g_header uint64; F_ns, F_forms any }

var A_arbace_c2j_check_check_fn__908000041_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A struct{ j2g_header uint64; F_ns any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A struct{ j2g_header uint64; F_ns, F_iter__908000042, F_s__908000043 any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A struct{ j2g_header uint64; F_ns, F_b__908000045 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_lap__908000054_A struct{ j2g_header uint64; F_t any }

var A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A struct{ j2g_header uint64; F_fails any }

var A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A struct{ j2g_header uint64; F_iter__908000021, F_s__908000022 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A struct{ j2g_header uint64; F_iter__908000023, F_s__908000024 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__908000026, F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000004_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000004_A_New() *A_arbace_c2j_check_eval908000004_A { t := &A_arbace_c2j_check_eval908000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000004_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000004_A_class }

func (t *A_arbace_c2j_check_eval908000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000004_A); return ok }

func A_arbace_c2j_check_eval908000004_A_Cast(x any) *A_arbace_c2j_check_eval908000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000004_A_class)) }; return v }



type A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000008_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000008_A_New() *A_arbace_c2j_check_eval908000008_A { t := &A_arbace_c2j_check_eval908000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000008_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000008_A_class }

func (t *A_arbace_c2j_check_eval908000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000008_A); return ok }

func A_arbace_c2j_check_eval908000008_A_Cast(x any) *A_arbace_c2j_check_eval908000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000008_A_class)) }; return v }



type A_arbace_c2j_check_eval908000008_fn__908000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000008_fn__908000009_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000013_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_fn__908000013_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000015_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_check_read_all_fn__908000015_A_fn_class *jrt.Class
