//line aot_arbace_c2j_check.ae:1
package aot_arbace_c2j_check

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_parse"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_New() *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_check_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_c2j_check_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_c2j_check_A_const_1, A_arbace_c2j_check_A_const_2, A_arbace_c2j_check_A_const_3, A_arbace_c2j_check_A_const_4, A_arbace_c2j_check_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_check_eval908000008_fn__908000009_A_New() *A_arbace_c2j_check_eval908000008_fn__908000009_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000008_fn__908000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_c2j_check_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c2j_check_A_const_11.GetRawRoot__O(), A_arbace_c2j_check_A_const_12) }











func A_arbace_c2j_check_read_all_A_New() *A_arbace_c2j_check_read_all_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Ctor() {}
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_c2j_check_A_const_13.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_57 any = A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_24, jrt.Boolean_FALSE.Ref()); if linked_58 == nil { ifn_59.Invoke_O__O(arg_60) } else { linked_58.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_57, arg_60) }; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_27 any = A_arbace_c2j_check_A_const_14.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any; var root_31 any = A_arbace_c2j_check_A_const_15.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var fnbody__42 any = A_arbace_c2j_check_read_all_fn__908000013_A_New(); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000013_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_c2j_check_read_all_fn__908000013_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; arg_34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp2, nil); var arg_35 any; var root_43 any = A_arbace_c2j_check_A_const_18.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any; var fnbody__53 any = A_arbace_c2j_check_read_all_fn__908000015_A_New_O(r__2); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000015_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__53); A_arbace_c2j_check_read_all_fn__908000015_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; arg_46 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp3, nil); if linked_44 == nil { arg_35 = ifn_45.Invoke_O__O(arg_46) } else { arg_35 = linked_44.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O__O(root_43, arg_46) }; if linked_32 == nil { arg_30 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { arg_30 = linked_32.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if linked_28 == nil { tmp1 = ifn_29.Invoke_O__O(arg_30) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_27, arg_30) } }
//line :15:1
		return nil }(); var root_54 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; if linked_55 == nil { ifn_56.Invoke__O() } else { linked_55.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_54) }
//line :13:1
		if tmp4 != nil { panic(tmp4) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :13:1*/ tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_c2j_check_read_all_fn__908000013_A_New() *A_arbace_c2j_check_read_all_fn__908000013_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000013_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Ctor() {}
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Invoke_O_O__O(self, p1__908000012_SHARP___1 any) any { var root_36 any = A_arbace_c2j_check_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_c2j_check_A_const_17; var arg_40 any = p1__908000012_SHARP___1; if linked_37 == nil { return ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { return linked_37.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) } }
//line :16:1
func A_arbace_c2j_check_read_all_fn__908000015_A_New_O(p0 any) *A_arbace_c2j_check_read_all_fn__908000015_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000015_A{}; t.Ctor_O(p0); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Invoke_O__O(self any) any { var root_47 any = A_arbace_c2j_check_A_const_19.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_c2j_check_A_const_20; var arg_51 any = t.F_r; if linked_48 == nil { return ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { return linked_48.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) } }

func A_arbace_c2j_check_check_A_New() *A_arbace_c2j_check_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_c2j_check_check_A) Ctor() {}
//line :18:1
func (t *A_arbace_c2j_check_check_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var root_66 any = A_arbace_c2j_check_A_const_25.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_68 lang.IFn; if


	linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_70 any = A_arbace_c2j_check_A_const_26.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var fnbody__80 any = A_arbace_c2j_check_check_fn__908000019_A_New(); var tmp1 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c2j_check_check_fn__908000019_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_c2j_check_check_fn__908000019_A_fn_class = fncls__79d; tmp1 = fncls__79d } else { tmp1 = fncls__79 }; arg_73 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp1, nil); var arg_74 any; var root_81 any = A_arbace_c2j_check_A_const_28.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var root_85 any = A_arbace_c2j_check_A_const_29.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_85, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = dir__0; var arg_89 any = Lit_2; if linked_86 == nil { arg_84 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { arg_84 = linked_86.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if linked_82 == nil { arg_74 = ifn_83.Invoke_O__O(arg_84) } else { arg_74 = linked_82.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_81, arg_84) }; if linked_71 == nil { arg_69 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; if linked_67 == nil { files__2 = ifn_68.Invoke_O__O(arg_69) } else { files__2 = linked_67.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_66, arg_69) }; var forms__3 any; var iter__1927001039__auto____3 any; var fnbody__212 any = /*line :18:1*/A_arbace_c2j_check_check_iter__908000021__908000027_A_New(); var tmp2 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class; if



	fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class = fncls__211d; tmp2 = fncls__211d } else { tmp2 = fncls__211 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__212, tmp2, nil); forms__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); var ns__4 any; var root_213 any = /*line :18:1*/A_arbace_c2j_check_A_const_45.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_215 lang.IFn; if







	linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = A_arbace_c2j_check_A_const_46; if linked_214 == nil { ns__4 = ifn_215.Invoke_O__O(arg_216) } else { ns__4 = linked_214.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_213, arg_216) }; var root_552 any =
	A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_74, ns__4); if linked_553 == nil { ifn_554.Invoke_O__O(arg_555) } else { linked_553.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_552, arg_555) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__551 any = A_arbace_c2j_check_check_fn__908000037_A_New(); var tmp4 *jrt.Class; var fncls__550 *jrt.Class = A_arbace_c2j_check_check_fn__908000037_A_fn_class; if fncls__550 == nil { var fncls__550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c2j_check_check_fn__908000037_A_fn_class = fncls__550d; tmp4 = fncls__550d } else { tmp4 = fncls__550 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__551, tmp4, nil); Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); var root_561 any =

	A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_check_A_const_75; var tmp7 any; var root_572 any = A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_573 == nil { tmp7 = ifn_574.Invoke_O__O(arg_575) } else { tmp7 = linked_573.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_572, arg_575) }; var tmp8 any = tmp7; var tmp9 any = A_arbace_c2j_check_A_const_58; var tmp10 any = A_arbace_c2j_check_A_const_57; var tmp11 any; var root_576 any = A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_578 lang.IFn; if
	linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = lang.PersistentVector_EMPTY.Ref(); if linked_577 == nil { tmp11 = ifn_578.Invoke_O__O(arg_579) } else { tmp11 = linked_577.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_576, arg_579) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_c2j_check_A_const_76; var tmp14 any; var root_580 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_582 lang.IFn; if
	linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_581 == nil { tmp14 = ifn_582.Invoke_O__O(arg_583) } else { tmp14 = linked_581.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_580, arg_583) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_c2j_check_A_const_77; var tmp17 any; var root_584 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_586 lang.IFn; if
	linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_585 == nil { tmp17 = ifn_586.Invoke_O__O(arg_587) } else { tmp17 = linked_585.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_584, arg_587) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_c2j_check_A_const_78; var tmp20 any; var root_588 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_590 lang.IFn; if

	linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_589 == nil { tmp20 = ifn_590.Invoke_O__O(arg_591) } else { tmp20 = linked_589.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_588, arg_591) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_c2j_check_A_const_79; var tmp23 any; var root_592 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_594 lang.IFn; if

	linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_593 == nil { tmp23 = ifn_594.Invoke_O__O(arg_595) } else { tmp23 = linked_593.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_592, arg_595) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_c2j_check_A_const_80; var tmp26 any; var root_596 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_598 lang.IFn; if


	linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_597 == nil { tmp26 = ifn_598.Invoke_O__O(arg_599) } else { tmp26 = linked_597.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_596, arg_599) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_c2j_check_A_const_81; var tmp29 any; var root_600 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_602 lang.IFn; if


	linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_601 == nil { tmp29 = ifn_602.Invoke_O__O(arg_603) } else { tmp29 = linked_601.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_600, arg_603) }; arg_564 = /*line :29:1*/tmp5.Invoke_O_O_O_O__O(tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, tmp27, tmp28, tmp29))); if linked_562 == nil { ifn_563.Invoke_O__O(arg_564) } else { linked_562.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_561, arg_564) }; var tmp30 any; tmp35 := /*line :18:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














		{ var root_217 any = A_arbace_c2j_check_A_const_47.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_with_redefs_fn_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var tmp31 any = A_arbace_c2j_check_A_const_48; var tmp32 *lang.Compiler_AOTFn; var fnbody__223 any = A_arbace_c2j_check_check_fn__908000039_A_New(); var tmp33 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_c2j_check_check_fn__908000039_A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_c2j_check_check_fn__908000039_A_fn_class = fncls__222d; tmp33 = fncls__222d } else { tmp33 = fncls__222 }; tmp32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__223, tmp33, nil); arg_220 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32.Ref())); var arg_221 any; var fnbody__539 any = A_arbace_c2j_check_check_fn__908000041_A_New_O_O(ns__4, forms__3); var tmp34 *jrt.Class; var fncls__538 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_A_fn_class; if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__539); A_arbace_c2j_check_check_fn__908000041_A_fn_class = fncls__538d; tmp34 = fncls__538d } else { tmp34 = fncls__538 }; arg_221 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__539, tmp34, nil); if linked_218 == nil { tmp30 = ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { tmp30 = linked_218.(*aot_arbace_core.A_arbace_core_with_redefs_fn_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) } }
//line :18:1
		return nil }(); var root_540 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_542 lang.IFn; if










	linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; if linked_541 == nil { ifn_542.Invoke__O() } else { linked_541.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_540) }; if /*line :18:1*/ tmp35 != nil { panic(tmp35) }; return tmp30 }


func A_arbace_c2j_check_check_fn__908000019_A_New() *A_arbace_c2j_check_check_fn__908000019_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000019_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Ctor() {}
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Invoke_O_O__O(self, p1__908000018_SHARP___1 any) any { var tmp1 any; var root_75 any = A_arbace_c2j_check_A_const_27.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = p1__908000018_SHARP___1; if linked_76 == nil { tmp1 = ifn_77.Invoke_O__O(arg_78) } else { tmp1 = linked_76.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_75, arg_78) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(tmp1)).EndsWith_String__Z(Lit_7)).Ref() }
func A_arbace_c2j_check_check_iter__908000021__908000027_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Invoke_O_O__O(self, s__908000022__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__210 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(self, s__908000022__1); var tmp2 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__210); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class = fncls__209d; tmp2 = fncls__209d } else { tmp2 = fncls__209 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__210, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Ctor_O_O(c__iter__908000021, c__s__908000022 any) { t.F_iter__908000021 = c__iter__908000021; t.F_s__908000022 = c__s__908000022 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Invoke_O__O(self any) any { { var s__908000022__1 any; var t_ any = t.F_s__908000022; t.F_s__908000022 = nil; s__908000022__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_90 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = s__908000022__1; if linked_91 == nil { temp__1927000414__auto____2 = ifn_92.Invoke_O__O(arg_93) } else { temp__1927000414__auto____2 = linked_91.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_90, arg_93) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_94 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = xs__1927001018__auto____3; if linked_95 == nil { f__4 = ifn_96.Invoke_O__O(arg_97) } else { f__4 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97) }; var iterys__1927001035__auto____5 any; var fnbody__187 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New(); var tmp1 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class = fncls__186d; tmp1 = fncls__186d } else { tmp1 = fncls__186 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__187, tmp1, nil); var fs__1927001036__auto____6 any; var root_188 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_192 any = A_arbace_c2j_check_A_const_43.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_c2j_check_read_all_A_fn_class); var ifn_194 lang.IFn
													if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = f__4; if linked_193 == nil { tmp3 = ifn_194.Invoke_O__O(arg_195) } else { tmp3 = linked_193.(*A_arbace_c2j_check_read_all_A).Invoke_O_O__O(root_192, arg_195) }
//line :22:1
	arg_191 = tmp2.Invoke_O__O(tmp3); if linked_189 == nil { fs__1927001036__auto____6 = ifn_190.Invoke_O__O(arg_191) } else { fs__1927001036__auto____6 = linked_189.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_196 any = A_arbace_c2j_check_A_const_44.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = fs__1927001036__auto____6; var arg_200 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__908000021); var tmp5 any; var root_201 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = s__908000022__1; if linked_202 == nil { tmp5 = ifn_203.Invoke_O__O(arg_204) } else { tmp5 = linked_202.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_201, arg_204) }; arg_200 = tmp4.Invoke_O__O(tmp5); if linked_197 == nil { return ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { return linked_197.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) } } else { var tmp6 any; var root_205 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = s__908000022__1; if linked_206 == nil { tmp6 = ifn_207.Invoke_O__O(arg_208) } else { tmp6 = linked_206.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_205, arg_208) }; s__908000022__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Invoke_O_O__O(self, s__908000024__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__185 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(self, s__908000024__1); var tmp2 *jrt.Class; var fncls__184 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class; if fncls__184 == nil { var fncls__184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__185); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class = fncls__184d; tmp2 = fncls__184d } else { tmp2 = fncls__184 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__185, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Ctor_O_O(c__iter__908000023, c__s__908000024 any) { t.F_iter__908000023 = c__iter__908000023; t.F_s__908000024 = c__s__908000024 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Invoke_O__O(self any) any { { var s__908000024__1 any; var t_ any = t.F_s__908000024; t.F_s__908000024 = nil; s__908000024__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_98 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = s__908000024__1; if linked_99 == nil { temp__1927000414__auto____2 = ifn_100.Invoke_O__O(arg_101) } else { temp__1927000414__auto____2 = linked_99.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_98, arg_101) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000024__3 any = temp__1927000414__auto____2; var tmp1 any; var root_102 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = s__908000024__3; if linked_103 == nil { tmp1 = ifn_104.Invoke_O__O(arg_105) } else { tmp1 = linked_103.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_102, arg_105) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_106 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = s__908000024__3; if linked_107 == nil { c__1927001037__auto____4 = ifn_108.Invoke_O__O(arg_109) } else { c__1927001037__auto____4 = linked_107.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_106, arg_109) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000026__6 any; var root_110 any = A_arbace_c2j_check_A_const_34.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_111 == nil { b__908000026__6 = ifn_112.Invoke_O__O(arg_113) } else { b__908000026__6 = linked_111.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_110, arg_113) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(size__1927001038__auto____5, b__908000026__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__132); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_133 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var root_138 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = b__908000026__6; if linked_139 == nil { arg_136 = ifn_140.Invoke_O__O(arg_141) } else { arg_136 = linked_139.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_138, arg_141) }; var arg_137 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); var tmp5 any; var root_142 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = s__908000024__3; if linked_143 == nil { tmp5 = ifn_144.Invoke_O__O(arg_145) } else { tmp5 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_142, arg_145) }; arg_137 = tmp4.Invoke_O__O(tmp5); if linked_134 == nil { return ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { return linked_134.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) } } else { var root_146 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_151 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = b__908000026__6; if linked_152 == nil { arg_149 = ifn_153.Invoke_O__O(arg_154) } else { arg_149 = linked_152.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_151, arg_154) }; var arg_150 any; if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } } else { var fm__4 any; var root_155 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__908000024__3; if linked_156 == nil { fm__4 = ifn_157.Invoke_O__O(arg_158) } else { fm__4 = linked_156.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_155, arg_158) }; var tmp6 any; var and__1927000168__auto____5 any; var root_159 any = A_arbace_c2j_check_A_const_35.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_161 lang.IFn

	if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = fm__4; if linked_160 == nil { and__1927000168__auto____5 = ifn_161.Invoke_O__O(arg_162) } else { and__1927000168__auto____5 = linked_160.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_159, arg_162) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 any = A_arbace_c2j_check_A_const_36; var tmp8 any; var root_163 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = fm__4; if linked_164 == nil { tmp8 = ifn_165.Invoke_O__O(arg_166) } else { tmp8 = linked_164.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_163, arg_166) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp6 = and__1927000168__auto____5 }
//line :22:1
	if jrt.J2g_Truth(tmp6) { var root_167 any = A_arbace_c2j_check_A_const_42.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any; var root_172 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn


		if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = fm__4; if linked_173 == nil { arg_170 = ifn_174.Invoke_O__O(arg_175) } else { arg_170 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }
//line :22:1
		var arg_171 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); var tmp10 any; var root_176 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__908000024__3; if linked_177 == nil { tmp10 = ifn_178.Invoke_O__O(arg_179) } else { tmp10 = linked_177.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_176, arg_179) }; arg_171 = tmp9.Invoke_O__O(tmp10); if linked_168 == nil { return ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { return linked_168.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) } } else { var tmp11 any; var root_180 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = s__908000024__3; if linked_181 == nil { tmp11 = ifn_182.Invoke_O__O(arg_183) } else { tmp11 = linked_181.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_180, arg_183) }; s__908000024__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__908000026, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__908000026 = c__b__908000026; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Invoke_O__O(self any) any { { var i__908000025__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000025__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000025__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_114 any = A_arbace_c2j_check_A_const_35.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_116 lang.IFn

	if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = fm__2; if linked_115 == nil { and__1927000168__auto____3 = ifn_116.Invoke_O__O(arg_117) } else { and__1927000168__auto____3 = linked_115.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_c2j_check_A_const_36; var tmp4 any; var root_118 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = fm__2; if linked_119 == nil { tmp4 = ifn_120.Invoke_O__O(arg_121) } else { tmp4 = linked_119.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_118, arg_121) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :22:1
	if jrt.J2g_Truth(tmp2) { var root_122 any = A_arbace_c2j_check_A_const_37.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = t.F_b__908000026; var arg_126 any; var root_127 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_129 lang.IFn


		if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = fm__2; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_127, arg_130) }
//line :22:1
		if linked_123 == nil { ifn_124.Invoke_O_O__O(arg_125, arg_126) } else { linked_123.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_122, arg_125, arg_126) }; i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } else { i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_check_check_fn__908000037_A_New() *A_arbace_c2j_check_check_fn__908000037_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000037_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Ctor() {}
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										tmp1 = lang.IFn_Cast(A_arbace_c2j_check_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_73)
//line :27:1
	return nil }(); var root_547 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; if linked_548 == nil { ifn_549.Invoke__O() } else { linked_548.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_547) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_c2j_check_check_fn__908000039_A_New() *A_arbace_c2j_check_check_fn__908000039_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000039_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Ctor() {}
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Invoke_O_O_O__O(self, ___1, node__2 any) any { return node__2 }
//line :33:1
func A_arbace_c2j_check_check_fn__908000041_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_fn__908000041_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Ctor_O_O(c__ns, c__forms any) { t.F_ns = c__ns; t.F_forms = c__forms }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Invoke_O__O(self any) any { var names__1 any; var root_224 any = A_arbace_c2j_check_A_const_49.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_226 lang.IFn; if
										linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any; var iter__1927001039__auto____1 any; var fnbody__309 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(t.F_ns); var tmp1 *jrt.Class; var fncls__308 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class; if fncls__308 == nil { var fncls__308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__309); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class = fncls__308d; tmp1 = fncls__308d } else { tmp1 = fncls__308 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__309, tmp1, nil); arg_227 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(t.F_forms); if linked_225 == nil { names__1 = ifn_226.Invoke_O__O(arg_227) } else { names__1 = linked_225.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_224, arg_227) }; var order__2 any; var root_310 any = /*line :33:1*/A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_312 lang.IFn; if
										linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var tmp2 *lang.Keyword = A_arbace_c2j_check_A_const_57; var arg_313 any = tmp2.Invoke_O__O(A_arbace_c2j_check_A_const_58.Get__O()); if linked_311 == nil { order__2 = ifn_312.Invoke_O__O(arg_313) } else { order__2 = linked_311.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_310, arg_313) }; var fails__3 any; var root_314 any = /*line :33:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_316 lang.IFn; if



	linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = lang.PersistentVector_EMPTY.Ref(); if linked_315 == nil { fails__3 = ifn_316.Invoke_O__O(arg_317) } else { fails__3 = linked_315.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_314, arg_317) }; var try_BANG___4 any; var fnbody__332 any = /*line :33:1*/A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(fails__3); var tmp3 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class; if




	fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__332); A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class = fncls__331d; tmp3 = fncls__331d } else { tmp3 = fncls__331 }; try_BANG___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__332, tmp3, nil); var t__5 any; var root_337 any = /*line :33:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_339 lang.IFn; if








	linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref(); if linked_338 == nil { t__5 = ifn_339.Invoke_O__O(arg_340) } else { t__5 = linked_338.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_337, arg_340) }; var lap__6 any; var fnbody__363 any = /*line :33:1*/A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(t__5); var tmp4 *jrt.Class; var fncls__362 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class; if









	fncls__362 == nil { var fncls__362d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__363); A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class = fncls__362d; tmp4 = fncls__362d } else { tmp4 = fncls__362 }; lap__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__363, tmp4, nil);
	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_11); var seq_908000056__7 any; var root_378 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_380 lang.IFn; if











	linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = order__2; if linked_379 == nil { seq_908000056__7 = ifn_380.Invoke_O__O(arg_381) } else { seq_908000056__7 = linked_379.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_378, arg_381) }; var chunk_908000057__8 any; var count_908000058__9 int64 = 0; var i_908000059__10 int64 = 0; L1:
//line :33:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000059__10, count_908000058__9) { var n__11 any = lang.Indexed_Cast(chunk_908000057__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000059__10)); var tmp5 any; var root_382 any = A_arbace_c2j_check_A_const_63.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var tmp6 *lang.Keyword = A_arbace_c2j_check_A_const_64; var tmp7 any; var root_386 any = A_arbace_c2j_check_A_const_65.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = n__11; if linked_387 == nil { tmp7 = ifn_388.Invoke_O__O(arg_389) } else { tmp7 = linked_387.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_386, arg_389) }; arg_385 = tmp6.Invoke_O__O(tmp7); if linked_383 == nil { tmp5 = ifn_384.Invoke_O__O(arg_385) } else { tmp5 = linked_383.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_382, arg_385) }; if jrt.J2g_Truth(tmp5) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__11, A_arbace_c2j_check_A_const_67.GetRawRoot__O()); seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } else { seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } } else { var temp__1927000414__auto____11 any; var root_390 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = seq_908000056__7; if linked_391 == nil { temp__1927000414__auto____11 = ifn_392.Invoke_O__O(arg_393) } else { temp__1927000414__auto____11 = linked_391.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_390, arg_393) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_908000056__12 any = temp__1927000414__auto____11; var tmp8 any; var root_394 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_908000056__12; if linked_395 == nil { tmp8 = ifn_396.Invoke_O__O(arg_397) } else { tmp8 = linked_395.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_394, arg_397) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____13 any; var root_398 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_908000056__12; if linked_399 == nil { c__1927000678__auto____13 = ifn_400.Invoke_O__O(arg_401) } else { c__1927000678__auto____13 = linked_399.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_398, arg_401) }; var tmp9 any; var root_494 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_908000056__12; if linked_495 == nil { tmp9 = ifn_496.Invoke_O__O(arg_497) } else { tmp9 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp9, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__13 any; var root_402 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = seq_908000056__12; if linked_403 == nil { n__13 = ifn_404.Invoke_O__O(arg_405) } else { n__13 = linked_403.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_402, arg_405) }; var tmp10 any; var root_406 any = A_arbace_c2j_check_A_const_63.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; var tmp11 *lang.Keyword = A_arbace_c2j_check_A_const_64; var tmp12 any; var root_410 any = A_arbace_c2j_check_A_const_65.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = n__13; if linked_411 == nil { tmp12 = ifn_412.Invoke_O__O(arg_413) } else { tmp12 = linked_411.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_410, arg_413) }; arg_409 = tmp11.Invoke_O__O(tmp12); if linked_407 == nil { tmp10 = ifn_408.Invoke_O__O(arg_409) } else { tmp10 = linked_407.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_406, arg_409) }; if jrt.J2g_Truth(tmp10) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__13, A_arbace_c2j_check_A_const_67.GetRawRoot__O()); var tmp13 any; var root_498 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_908000056__12; if linked_499 == nil { tmp13 = ifn_500.Invoke_O__O(arg_501) } else { tmp13 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp13, nil, 0, 0; continue L1 } else { var tmp14 any; var root_502 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = seq_908000056__12; if linked_503 == nil { tmp14 = ifn_504.Invoke_O__O(arg_505) } else { tmp14 = linked_503.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_502, arg_505) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp14, nil, 0, 0; continue L1 } } } }
//line :33:1
		break L1 };












	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_13); var seq_908000060__7 any; var root_414 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_416 lang.IFn; if













	linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = order__2; if linked_415 == nil { seq_908000060__7 = ifn_416.Invoke_O__O(arg_417) } else { seq_908000060__7 = linked_415.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_414, arg_417) }; var chunk_908000061__8 any; var count_908000062__9 int64 = 0; var i_908000063__10 int64 = 0; L2:
//line :33:1
	for {













		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000063__10, count_908000062__9) { var n__11_2 any = lang.Indexed_Cast(chunk_908000061__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000063__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__11_2, A_arbace_c2j_check_A_const_69.GetRawRoot__O()); seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = seq_908000060__7, chunk_908000061__8, count_908000062__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000063__10); continue L2 } else { var temp__1927000414__auto____11_2 any; var root_418 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = seq_908000060__7; if linked_419 == nil { temp__1927000414__auto____11_2 = ifn_420.Invoke_O__O(arg_421) } else { temp__1927000414__auto____11_2 = linked_419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_418, arg_421) }; if jrt.J2g_Truth(temp__1927000414__auto____11_2) { var seq_908000060__12 any = temp__1927000414__auto____11_2; var tmp15 any; var root_422 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = seq_908000060__12; if linked_423 == nil { tmp15 = ifn_424.Invoke_O__O(arg_425) } else { tmp15 = linked_423.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____13_2 any; var root_426 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = seq_908000060__12; if linked_427 == nil { c__1927000678__auto____13_2 = ifn_428.Invoke_O__O(arg_429) } else { c__1927000678__auto____13_2 = linked_427.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_426, arg_429) }; var tmp16 any; var root_506 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = seq_908000060__12; if linked_507 == nil { tmp16 = ifn_508.Invoke_O__O(arg_509) } else { tmp16 = linked_507.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_506, arg_509) }; seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = tmp16, c__1927000678__auto____13_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var n__13_2 any; var root_430 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_908000060__12; if linked_431 == nil { n__13_2 = ifn_432.Invoke_O__O(arg_433) } else { n__13_2 = linked_431.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_430, arg_433) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__13_2, A_arbace_c2j_check_A_const_69.GetRawRoot__O()); var tmp17 any; var root_510 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = seq_908000060__12; if linked_511 == nil { tmp17 = ifn_512.Invoke_O__O(arg_513) } else { tmp17 = linked_511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_510, arg_513) }; seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = tmp17, nil, 0, 0; continue L2 } } }
//line :33:1
		break L2 };














	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_14); var seq_908000064__7 any; var root_434 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_436 lang.IFn; if















	linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = A_arbace_c2j_check_A_const_66.Invoke_O__O(order__2); if linked_435 == nil { seq_908000064__7 = ifn_436.Invoke_O__O(arg_437) } else { seq_908000064__7 = linked_435.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_434, arg_437) }; var chunk_908000065__8 any; var count_908000066__9 int64 = 0; var i_908000067__10 int64 = 0; L3:
//line :33:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000067__10, count_908000066__9) { var n__11_3 any = lang.Indexed_Cast(chunk_908000065__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000067__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__11_3, A_arbace_c2j_check_A_const_70.GetRawRoot__O()); seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = seq_908000064__7, chunk_908000065__8, count_908000066__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000067__10); continue L3 } else { var temp__1927000414__auto____11_3 any; var root_438 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = seq_908000064__7; if linked_439 == nil { temp__1927000414__auto____11_3 = ifn_440.Invoke_O__O(arg_441) } else { temp__1927000414__auto____11_3 = linked_439.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_438, arg_441) }; if jrt.J2g_Truth(temp__1927000414__auto____11_3) { var seq_908000064__12 any = temp__1927000414__auto____11_3; var tmp18 any; var root_442 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_908000064__12; if linked_443 == nil { tmp18 = ifn_444.Invoke_O__O(arg_445) } else { tmp18 = linked_443.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_442, arg_445) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____13_3 any; var root_446 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = seq_908000064__12; if linked_447 == nil { c__1927000678__auto____13_3 = ifn_448.Invoke_O__O(arg_449) } else { c__1927000678__auto____13_3 = linked_447.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_446, arg_449) }; var tmp19 any; var root_514 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = seq_908000064__12; if linked_515 == nil { tmp19 = ifn_516.Invoke_O__O(arg_517) } else { tmp19 = linked_515.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_514, arg_517) }; seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = tmp19, c__1927000678__auto____13_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var n__13_3 any; var root_450 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = seq_908000064__12; if linked_451 == nil { n__13_3 = ifn_452.Invoke_O__O(arg_453) } else { n__13_3 = linked_451.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_450, arg_453) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__13_3, A_arbace_c2j_check_A_const_70.GetRawRoot__O()); var tmp20 any; var root_518 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = seq_908000064__12; if linked_519 == nil { tmp20 = ifn_520.Invoke_O__O(arg_521) } else { tmp20 = linked_519.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_518, arg_521) }; seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = tmp20, nil, 0, 0; continue L3 } } }
//line :33:1
		break L3 };
















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_15); var seq_908000068__7 any; var root_454 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if

















	linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = order__2; if linked_455 == nil { seq_908000068__7 = ifn_456.Invoke_O__O(arg_457) } else { seq_908000068__7 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; var chunk_908000069__8 any; var count_908000070__9 int64 = 0; var i_908000071__10 int64 = 0; L4:
//line :33:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000071__10, count_908000070__9) { var n__11_4 any = lang.Indexed_Cast(chunk_908000069__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000071__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__11_4, A_arbace_c2j_check_A_const_71); seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = seq_908000068__7, chunk_908000069__8, count_908000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000071__10); continue L4 } else { var temp__1927000414__auto____11_4 any; var root_458 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_908000068__7; if linked_459 == nil { temp__1927000414__auto____11_4 = ifn_460.Invoke_O__O(arg_461) } else { temp__1927000414__auto____11_4 = linked_459.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(temp__1927000414__auto____11_4) { var seq_908000068__12 any = temp__1927000414__auto____11_4; var tmp21 any; var root_462 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_908000068__12; if linked_463 == nil { tmp21 = ifn_464.Invoke_O__O(arg_465) } else { tmp21 = linked_463.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_462, arg_465) }; if jrt.J2g_Truth(tmp21) { var c__1927000678__auto____13_4 any; var root_466 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_908000068__12; if linked_467 == nil { c__1927000678__auto____13_4 = ifn_468.Invoke_O__O(arg_469) } else { c__1927000678__auto____13_4 = linked_467.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_466, arg_469) }; var tmp22 any; var root_522 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = seq_908000068__12; if linked_523 == nil { tmp22 = ifn_524.Invoke_O__O(arg_525) } else { tmp22 = linked_523.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_522, arg_525) }; seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = tmp22, c__1927000678__auto____13_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var n__13_4 any; var root_470 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = seq_908000068__12; if linked_471 == nil { n__13_4 = ifn_472.Invoke_O__O(arg_473) } else { n__13_4 = linked_471.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_470, arg_473) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__13_4, A_arbace_c2j_check_A_const_71); var tmp23 any; var root_526 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = seq_908000068__12; if linked_527 == nil { tmp23 = ifn_528.Invoke_O__O(arg_529) } else { tmp23 = linked_527.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_526, arg_529) }; seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = tmp23, nil, 0, 0; continue L4 } } }
//line :33:1
		break L4 }; var seq_908000072__7 any; var root_474 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_476 lang.IFn; if


















	linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = order__2; if linked_475 == nil { seq_908000072__7 = ifn_476.Invoke_O__O(arg_477) } else { seq_908000072__7 = linked_475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_474, arg_477) }; var chunk_908000073__8 any; var count_908000074__9 int64 = 0; var i_908000075__10 int64 = 0; L5:
//line :33:1
	for {


















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000075__10, count_908000074__9) { var n__11_5 any = lang.Indexed_Cast(chunk_908000073__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000075__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__11_5, A_arbace_c2j_check_A_const_72.GetRawRoot__O()); seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = seq_908000072__7, chunk_908000073__8, count_908000074__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000075__10); continue L5 } else { var temp__1927000414__auto____11_5 any; var root_478 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = seq_908000072__7; if linked_479 == nil { temp__1927000414__auto____11_5 = ifn_480.Invoke_O__O(arg_481) } else { temp__1927000414__auto____11_5 = linked_479.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_478, arg_481) }; if jrt.J2g_Truth(temp__1927000414__auto____11_5) { var seq_908000072__12 any = temp__1927000414__auto____11_5; var tmp24 any; var root_482 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = seq_908000072__12; if linked_483 == nil { tmp24 = ifn_484.Invoke_O__O(arg_485) } else { tmp24 = linked_483.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_482, arg_485) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____13_5 any; var root_486 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_908000072__12; if linked_487 == nil { c__1927000678__auto____13_5 = ifn_488.Invoke_O__O(arg_489) } else { c__1927000678__auto____13_5 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_486, arg_489) }; var tmp25 any; var root_530 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = seq_908000072__12; if linked_531 == nil { tmp25 = ifn_532.Invoke_O__O(arg_533) } else { tmp25 = linked_531.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_530, arg_533) }; seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = tmp25, c__1927000678__auto____13_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var n__13_5 any; var root_490 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = seq_908000072__12; if linked_491 == nil { n__13_5 = ifn_492.Invoke_O__O(arg_493) } else { n__13_5 = linked_491.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_490, arg_493) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__13_5, A_arbace_c2j_check_A_const_72.GetRawRoot__O()); var tmp26 any; var root_534 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = seq_908000072__12; if linked_535 == nil { tmp26 = ifn_536.Invoke_O__O(arg_537) } else { tmp26 = linked_535.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_534, arg_537) }; seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = tmp26, nil, 0, 0; continue L5 } } }
//line :33:1
		break L5 };



















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_17); var tmp27 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()); var tmp28 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__1)).Ref(); var tmp29 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(order__2)).Ref(); var tmp30 any; var root_374 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_376 lang.IFn; if
	linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = fails__3; if linked_375 == nil { tmp30 = ifn_376.Invoke_O__O(arg_377) } else { tmp30 = linked_375.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_374, arg_377) }; /*line :54:1*/tmp27.Invoke_O_O_O_O_O_O_O__O(Lit_18, tmp28, Lit_19, tmp29, Lit_20, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp30)).Ref(), Lit_21); var root_333 any = /*line :34:1*/A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = fails__3; if linked_334 == nil { return ifn_335.Invoke_O__O(arg_336) } else { return linked_334.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_333, arg_336) } }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A{}; t.Ctor_O(p0); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Invoke_O_O__O(self, s__908000043__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__307 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(t.F_ns, self, s__908000043__1); var tmp2 *jrt.Class; var fncls__306 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class; if fncls__306 == nil { var fncls__306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__307); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class = fncls__306d; tmp2 = fncls__306d } else { tmp2 = fncls__306 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__307, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Ctor_O_O_O(c__ns, c__iter__908000042, c__s__908000043 any) { t.F_ns = c__ns; t.F_iter__908000042 = c__iter__908000042; t.F_s__908000043 = c__s__908000043 }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Invoke_O__O(self any) any { { var s__908000043__1 any; var t_ any = t.F_s__908000043; t.F_s__908000043 = nil; s__908000043__1 = t_; for { var temp__1927000414__auto____2 any; var root_228 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = s__908000043__1; if linked_229 == nil { temp__1927000414__auto____2 = ifn_230.Invoke_O__O(arg_231) } else { temp__1927000414__auto____2 = linked_229.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000043__3 any = temp__1927000414__auto____2; var tmp1 any; var root_232 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = s__908000043__3; if linked_233 == nil { tmp1 = ifn_234.Invoke_O__O(arg_235) } else { tmp1 = linked_233.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_232, arg_235) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_236 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = s__908000043__3; if linked_237 == nil { c__1927001037__auto____4 = ifn_238.Invoke_O__O(arg_239) } else { c__1927001037__auto____4 = linked_237.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_236, arg_239) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000045__6 any; var root_240 any = A_arbace_c2j_check_A_const_34.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_241 == nil { b__908000045__6 = ifn_242.Invoke_O__O(arg_243) } else { b__908000045__6 = linked_241.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_240, arg_243) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__260 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(t.F_ns, b__908000045__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__259 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class; if fncls__259 == nil { var fncls__259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__260); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class = fncls__259d; tmp3 = fncls__259d } else { tmp3 = fncls__259 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__260, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_261 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var root_266 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = b__908000045__6; if linked_267 == nil { arg_264 = ifn_268.Invoke_O__O(arg_269) } else { arg_264 = linked_267.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_266, arg_269) }; var arg_265 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); var tmp5 any; var root_270 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = s__908000043__3; if linked_271 == nil { tmp5 = ifn_272.Invoke_O__O(arg_273) } else { tmp5 = linked_271.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_270, arg_273) }; arg_265 = tmp4.Invoke_O__O(tmp5); if linked_262 == nil { return ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { return linked_262.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) } } else { var root_274 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any; var root_279 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = b__908000045__6; if linked_280 == nil { arg_277 = ifn_281.Invoke_O__O(arg_282) } else { arg_277 = linked_280.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_279, arg_282) }; var arg_278 any; if linked_275 == nil { return ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { return linked_275.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_274, arg_277, arg_278) } } } else { var f__4 any; var root_283 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = s__908000043__3; if linked_284 == nil { f__4 = ifn_285.Invoke_O__O(arg_286) } else { f__4 = linked_284.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_283, arg_286) }; var root_287 any = A_arbace_c2j_check_A_const_42.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any; var root_292 any = A_arbace_c2j_check_A_const_50.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_294 lang.IFn
															if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = A_arbace_c2j_check_A_const_56; var arg_296 any; var root_297 any = A_arbace_c2j_check_A_const_52.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_53, t.F_ns, A_arbace_c2j_check_A_const_54, A_arbace_c2j_check_A_const_55)); var arg_301 any = f__4; if linked_298 == nil { arg_296 = ifn_299.Invoke_O_O__O(arg_300, arg_301) } else { arg_296 = linked_298.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_297, arg_300, arg_301) }; if linked_293 == nil { arg_290 = ifn_294.Invoke_O_O__O(arg_295, arg_296) } else { arg_290 = linked_293.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_292, arg_295, arg_296) }
//line :34:1
	var arg_291 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); var tmp7 any; var root_302 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = s__908000043__3; if linked_303 == nil { tmp7 = ifn_304.Invoke_O__O(arg_305) } else { tmp7 = linked_303.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_302, arg_305) }; arg_291 = tmp6.Invoke_O__O(tmp7); if linked_288 == nil { return ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { return linked_288.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Ctor_O_O_I_O(c__ns, c__b__908000045 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ns = c__ns; t.F_b__908000045 = c__b__908000045; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Invoke_O__O(self any) any { { var i__908000044__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000044__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000044__1)); var root_244 any = A_arbace_c2j_check_A_const_37.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = t.F_b__908000045; var arg_248 any; var root_249 any = A_arbace_c2j_check_A_const_50.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_251 lang.IFn
																	if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_c2j_check_A_const_51; var arg_253 any; var root_254 any = A_arbace_c2j_check_A_const_52.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_53, t.F_ns, A_arbace_c2j_check_A_const_54, A_arbace_c2j_check_A_const_55)); var arg_258 any = f__2; if linked_255 == nil { arg_253 = ifn_256.Invoke_O_O__O(arg_257, arg_258) } else { arg_253 = linked_255.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_254, arg_257, arg_258) }; if linked_250 == nil { arg_248 = ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { arg_248 = linked_250.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_249, arg_252, arg_253) }
//line :34:1
	if linked_245 == nil { ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { linked_245.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; i__908000044__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000044__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Ctor_O(c__fails any) { t.F_fails = c__fails }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Invoke_O_O_O_O__O(self, what__1, n__2, f__3 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																tmp1 = lang.IFn_Cast(f__3).Invoke_O__O(n__2)
//line :38:1
	return nil }(); if tmp2 != nil { if true { var t__6 jrt.Throwable_I = tmp2

		lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_25, what__1, n__2, t__6.GetMessage__String().Ref())
		var root_318 any = A_arbace_c2j_check_A_const_60.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = t.F_fails; var arg_322 any = A_arbace_c2j_check_A_const_11.GetRawRoot__O(); var arg_323 any = lang.Tuple_Create_O_O_O__IPersistentVector(n__2, what__1, t__6.GetMessage__String().Ref()); if linked_319 == nil { tmp1 = ifn_320.Invoke_O_O_O__O(arg_321, arg_322, arg_323) } else { tmp1 = linked_319.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_318, arg_321, arg_322, arg_323) } } }; return tmp1 }

func A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_lap__908000054_A{}; t.Ctor_O(p0); return t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()); var tmp2 jrt.Number_I; var na_353 int64 = x__2; var na_354 any; var root_355 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = t.F_t; if linked_356 == nil { na_354 = ifn_357.Invoke_O__O(arg_358) } else { na_354 = linked_356.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_355, arg_358) }; if jrt.Long_InstanceOf(na_354) { var n0_359 int64 = na_353; var n1_360 int64 = jrt.NN(jrt.Long_Cast(na_354)).LongValue__J(); var nr_361 int64 = n0_359 - n1_360; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_360 == -9223372036854775808); if tmp4 { tmp4 = (n0_359^n1_360)&(n0_359^nr_361) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_361)) } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_353, na_354) } } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_353, na_354) }; tmp1.Invoke_O_O_O_O__O(Lit_18, k__1, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D_NoInit(tmp2, 1.0e7)), 100.0)).Ref(), Lit_24); var root_341 any = A_arbace_c2j_check_A_const_62.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = t.F_t; var arg_345 any = jrt.Long_ValueOf_J__Long_NoInit(x__2).Ref(); if linked_342 == nil { return ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { return linked_342.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_341, arg_344, arg_345) } }




















































































type A_arbace_c2j_check_A struct{ jrt.Object }

var A_arbace_c2j_check_A_const_pool *jrt.RefArray

var A_arbace_c2j_check_A_const_0 *lang.Var

var A_arbace_c2j_check_A_const_1 any

var A_arbace_c2j_check_A_const_2 any

var A_arbace_c2j_check_A_const_3 any

var A_arbace_c2j_check_A_const_4 any

var A_arbace_c2j_check_A_const_5 any

var A_arbace_c2j_check_A_const_6 *lang.Var

var A_arbace_c2j_check_A_const_7 any

var A_arbace_c2j_check_A_const_8 *lang.Var

var A_arbace_c2j_check_A_const_9 *lang.Var

var A_arbace_c2j_check_A_const_10 *lang.Var

var A_arbace_c2j_check_A_const_11 *lang.Var

var A_arbace_c2j_check_A_const_12 any

var A_arbace_c2j_check_A_const_13 *lang.Var

var A_arbace_c2j_check_A_const_14 *lang.Var

var A_arbace_c2j_check_A_const_15 *lang.Var

var A_arbace_c2j_check_A_const_16 *lang.Var

var A_arbace_c2j_check_A_const_17 *lang.Keyword

var A_arbace_c2j_check_A_const_18 *lang.Var

var A_arbace_c2j_check_A_const_19 *lang.Var

var A_arbace_c2j_check_A_const_20 any

var A_arbace_c2j_check_A_const_21 *lang.Var

var A_arbace_c2j_check_A_const_22 *lang.Var

var A_arbace_c2j_check_A_const_23 *lang.Var

var A_arbace_c2j_check_A_const_24 *lang.Var

var A_arbace_c2j_check_A_const_25 *lang.Var

var A_arbace_c2j_check_A_const_26 *lang.Var

var A_arbace_c2j_check_A_const_27 *lang.Var

var A_arbace_c2j_check_A_const_28 *lang.Var

var A_arbace_c2j_check_A_const_29 *lang.Var

var A_arbace_c2j_check_A_const_30 *lang.Var

var A_arbace_c2j_check_A_const_31 *lang.Var

var A_arbace_c2j_check_A_const_32 *lang.Var

var A_arbace_c2j_check_A_const_33 *lang.Var

var A_arbace_c2j_check_A_const_34 *lang.Var

var A_arbace_c2j_check_A_const_35 *lang.Var

var A_arbace_c2j_check_A_const_36 any

var A_arbace_c2j_check_A_const_37 *lang.Var

var A_arbace_c2j_check_A_const_38 *lang.Var

var A_arbace_c2j_check_A_const_39 *lang.Var

var A_arbace_c2j_check_A_const_40 *lang.Var

var A_arbace_c2j_check_A_const_41 *lang.Var

var A_arbace_c2j_check_A_const_42 *lang.Var

var A_arbace_c2j_check_A_const_43 *lang.Var

var A_arbace_c2j_check_A_const_44 *lang.Var

var A_arbace_c2j_check_A_const_45 *lang.Var

var A_arbace_c2j_check_A_const_46 any

var A_arbace_c2j_check_A_const_47 *lang.Var

var A_arbace_c2j_check_A_const_48 *lang.Var

var A_arbace_c2j_check_A_const_49 *lang.Var

var A_arbace_c2j_check_A_const_50 *lang.Var

var A_arbace_c2j_check_A_const_51 any

var A_arbace_c2j_check_A_const_52 *lang.Var

var A_arbace_c2j_check_A_const_53 *lang.Keyword

var A_arbace_c2j_check_A_const_54 *lang.Keyword

var A_arbace_c2j_check_A_const_55 *lang.Keyword

var A_arbace_c2j_check_A_const_56 any

var A_arbace_c2j_check_A_const_57 *lang.Keyword

var A_arbace_c2j_check_A_const_58 *lang.Var

var A_arbace_c2j_check_A_const_59 *lang.Var

var A_arbace_c2j_check_A_const_60 *lang.Var

var A_arbace_c2j_check_A_const_61 *lang.Var

var A_arbace_c2j_check_A_const_62 *lang.Var

var A_arbace_c2j_check_A_const_63 *lang.Var

var A_arbace_c2j_check_A_const_64 *lang.Keyword

var A_arbace_c2j_check_A_const_65 *lang.Var

var A_arbace_c2j_check_A_const_66 *lang.Var

var A_arbace_c2j_check_A_const_67 *lang.Var

var A_arbace_c2j_check_A_const_68 *lang.Var

var A_arbace_c2j_check_A_const_69 *lang.Var

var A_arbace_c2j_check_A_const_70 *lang.Var

var A_arbace_c2j_check_A_const_71 *lang.Var

var A_arbace_c2j_check_A_const_72 *lang.Var

var A_arbace_c2j_check_A_const_73 any

var A_arbace_c2j_check_A_const_74 *lang.Var

var A_arbace_c2j_check_A_const_75 *lang.Var

var A_arbace_c2j_check_A_const_76 *lang.Keyword

var A_arbace_c2j_check_A_const_77 *lang.Keyword

var A_arbace_c2j_check_A_const_78 *lang.Keyword

var A_arbace_c2j_check_A_const_79 *lang.Keyword

var A_arbace_c2j_check_A_const_80 *lang.Keyword

var A_arbace_c2j_check_A_const_81 *lang.Keyword

var A_arbace_c2j_check_A_init jrt.ClassInit

func A_arbace_c2j_check_A_Init() { if !A_arbace_c2j_check_A_init.Done() { A_arbace_c2j_check_A_init.Run(A_arbace_c2j_check_A_clinit) } }

func A_arbace_c2j_check_A_clinit() { A_arbace_c2j_check_A_clinit_p0(); A_arbace_c2j_check_A_clinit_p1(); A_arbace_c2j_check_A_clinit_p2(); A_arbace_c2j_check_A_clinit_p3(); A_arbace_c2j_check_A_clinit_p4(); A_arbace_c2j_check_A_clinit_p5(); A_arbace_c2j_check_A_clinit_p6() }

func A_arbace_c2j_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 110); A_arbace_c2j_check_A_const_0 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[28]); A_arbace_c2j_check_A_const_1 = A_arbace_c2j_check_A_const_pool.A[29]; A_arbace_c2j_check_A_const_2 = A_arbace_c2j_check_A_const_pool.A[30]; A_arbace_c2j_check_A_const_3 = A_arbace_c2j_check_A_const_pool.A[31]; A_arbace_c2j_check_A_const_4 = A_arbace_c2j_check_A_const_pool.A[32]; A_arbace_c2j_check_A_const_5 = A_arbace_c2j_check_A_const_pool.A[33]; A_arbace_c2j_check_A_const_6 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[34]); A_arbace_c2j_check_A_const_7 = A_arbace_c2j_check_A_const_pool.A[35]; A_arbace_c2j_check_A_const_8 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[36]); A_arbace_c2j_check_A_const_9 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[37]); A_arbace_c2j_check_A_const_10 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[38]); A_arbace_c2j_check_A_const_11 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[39]); A_arbace_c2j_check_A_const_12 = A_arbace_c2j_check_A_const_pool.A[40] }

func A_arbace_c2j_check_A_clinit_p1() { A_arbace_c2j_check_A_const_13 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[41]); A_arbace_c2j_check_A_const_14 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[42]); A_arbace_c2j_check_A_const_15 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[43]); A_arbace_c2j_check_A_const_16 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[44]); A_arbace_c2j_check_A_const_17 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[45]); A_arbace_c2j_check_A_const_18 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[46]); A_arbace_c2j_check_A_const_19 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[47]); A_arbace_c2j_check_A_const_20 = A_arbace_c2j_check_A_const_pool.A[48]; A_arbace_c2j_check_A_const_21 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[49]); A_arbace_c2j_check_A_const_22 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[50]); A_arbace_c2j_check_A_const_23 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[51]); A_arbace_c2j_check_A_const_24 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[52]) }

func A_arbace_c2j_check_A_clinit_p2() { A_arbace_c2j_check_A_const_25 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[53]); A_arbace_c2j_check_A_const_26 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[54]); A_arbace_c2j_check_A_const_27 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[55]); A_arbace_c2j_check_A_const_28 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[56]); A_arbace_c2j_check_A_const_29 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[57]); A_arbace_c2j_check_A_const_30 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[58]); A_arbace_c2j_check_A_const_31 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[59]); A_arbace_c2j_check_A_const_32 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[60]); A_arbace_c2j_check_A_const_33 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[61]); A_arbace_c2j_check_A_const_34 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[62]); A_arbace_c2j_check_A_const_35 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[63]); A_arbace_c2j_check_A_const_36 = A_arbace_c2j_check_A_const_pool.A[64] }

func A_arbace_c2j_check_A_clinit_p3() { A_arbace_c2j_check_A_const_37 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[65]); A_arbace_c2j_check_A_const_38 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[66]); A_arbace_c2j_check_A_const_39 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[67]); A_arbace_c2j_check_A_const_40 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[68]); A_arbace_c2j_check_A_const_41 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[69]); A_arbace_c2j_check_A_const_42 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[70]); A_arbace_c2j_check_A_const_43 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[71]); A_arbace_c2j_check_A_const_44 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[72]); A_arbace_c2j_check_A_const_45 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[73]); A_arbace_c2j_check_A_const_46 = A_arbace_c2j_check_A_const_pool.A[74]; A_arbace_c2j_check_A_const_47 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[75]); A_arbace_c2j_check_A_const_48 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[76]) }

func A_arbace_c2j_check_A_clinit_p4() { A_arbace_c2j_check_A_const_49 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[77]); A_arbace_c2j_check_A_const_50 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[78]); A_arbace_c2j_check_A_const_51 = A_arbace_c2j_check_A_const_pool.A[79]; A_arbace_c2j_check_A_const_52 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[80]); A_arbace_c2j_check_A_const_53 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[81]); A_arbace_c2j_check_A_const_54 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[82]); A_arbace_c2j_check_A_const_55 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[83]); A_arbace_c2j_check_A_const_56 = A_arbace_c2j_check_A_const_pool.A[84]; A_arbace_c2j_check_A_const_57 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[85]); A_arbace_c2j_check_A_const_58 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[86]); A_arbace_c2j_check_A_const_59 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[87]); A_arbace_c2j_check_A_const_60 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[88]) }

func A_arbace_c2j_check_A_clinit_p5() { A_arbace_c2j_check_A_const_61 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[89]); A_arbace_c2j_check_A_const_62 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[90]); A_arbace_c2j_check_A_const_63 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[91]); A_arbace_c2j_check_A_const_64 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[92]); A_arbace_c2j_check_A_const_65 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[93]); A_arbace_c2j_check_A_const_66 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[94]); A_arbace_c2j_check_A_const_67 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[95]); A_arbace_c2j_check_A_const_68 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[96]); A_arbace_c2j_check_A_const_69 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[97]); A_arbace_c2j_check_A_const_70 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[98]); A_arbace_c2j_check_A_const_71 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[99]); A_arbace_c2j_check_A_const_72 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[100]) }

func A_arbace_c2j_check_A_clinit_p6() { A_arbace_c2j_check_A_const_73 = A_arbace_c2j_check_A_const_pool.A[101]; A_arbace_c2j_check_A_const_74 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[102]); A_arbace_c2j_check_A_const_75 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[103]); A_arbace_c2j_check_A_const_76 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[104]); A_arbace_c2j_check_A_const_77 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[105]); A_arbace_c2j_check_A_const_78 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[106]); A_arbace_c2j_check_A_const_79 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[107]); A_arbace_c2j_check_A_const_80 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[108]); A_arbace_c2j_check_A_const_81 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[109]) }

func A_arbace_c2j_check_A_New() *A_arbace_c2j_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_A) Ctor() {}

func (t *A_arbace_c2j_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_A_class }

func (t *A_arbace_c2j_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_A); return ok }

func A_arbace_c2j_check_A_Cast(x any) *A_arbace_c2j_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_A_class)) }; return v }



type A_arbace_c2j_check_check_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000019_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000019_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000037_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000037_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000039_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000039_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_A struct{ j2g_header uint64; F_ns, F_forms any }

var A_arbace_c2j_check_check_fn__908000041_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A struct{ j2g_header uint64; F_ns any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A struct{ j2g_header uint64; F_ns, F_iter__908000042, F_s__908000043 any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A struct{ j2g_header uint64; F_ns, F_b__908000045 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_lap__908000054_A struct{ j2g_header uint64; F_t any }

var A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A struct{ j2g_header uint64; F_fails any }

var A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A struct{ j2g_header uint64; F_iter__908000021, F_s__908000022 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A struct{ j2g_header uint64; F_iter__908000023, F_s__908000024 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__908000026, F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000004_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000004_A_New() *A_arbace_c2j_check_eval908000004_A { t := &A_arbace_c2j_check_eval908000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000004_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000004_A_class }

func (t *A_arbace_c2j_check_eval908000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000004_A); return ok }

func A_arbace_c2j_check_eval908000004_A_Cast(x any) *A_arbace_c2j_check_eval908000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000004_A_class)) }; return v }



type A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000008_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000008_A_New() *A_arbace_c2j_check_eval908000008_A { t := &A_arbace_c2j_check_eval908000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000008_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000008_A_class }

func (t *A_arbace_c2j_check_eval908000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000008_A); return ok }

func A_arbace_c2j_check_eval908000008_A_Cast(x any) *A_arbace_c2j_check_eval908000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000008_A_class)) }; return v }



type A_arbace_c2j_check_eval908000008_fn__908000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000008_fn__908000009_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000013_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_fn__908000013_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000015_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_check_read_all_fn__908000015_A_fn_class *jrt.Class
