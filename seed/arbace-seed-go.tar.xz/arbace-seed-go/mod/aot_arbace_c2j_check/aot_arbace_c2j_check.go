//line aot_arbace_c2j_check.ae:1
package aot_arbace_c2j_check

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_parse"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_New() *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_check_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_c2j_check_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_c2j_check_A_const_1, A_arbace_c2j_check_A_const_2, A_arbace_c2j_check_A_const_3, A_arbace_c2j_check_A_const_4, A_arbace_c2j_check_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_check_eval908000008_fn__908000009_A_New() *A_arbace_c2j_check_eval908000008_fn__908000009_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_eval908000008_fn__908000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_check_eval908000008_fn__908000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_c2j_check_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c2j_check_A_const_11.GetRawRoot__O(), A_arbace_c2j_check_A_const_12) }











func A_arbace_c2j_check_read_all_A_New() *A_arbace_c2j_check_read_all_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Ctor() {}
//line :13:1
func (t *A_arbace_c2j_check_read_all_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_c2j_check_A_const_13.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_55 any = A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_24, jrt.Boolean_FALSE.Ref()); if linked_56 == nil { ifn_57.Invoke_O__O(arg_58) } else { linked_56.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_55, arg_58) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_27 any = A_arbace_c2j_check_A_const_14.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any; var root_31 any = A_arbace_c2j_check_A_const_15.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var tmp2 any = A_arbace_c2j_check_read_all_fn__908000013_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000013_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_c2j_check_read_all_fn__908000013_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; arg_34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_35 any; var root_42 any = A_arbace_c2j_check_A_const_18.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any; var tmp4 any = A_arbace_c2j_check_read_all_fn__908000015_A_New_O(r__2); var tmp5 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c2j_check_read_all_fn__908000015_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_c2j_check_read_all_fn__908000015_A_fn_class = fncls__51d; tmp5 = fncls__51d } else { tmp5 = fncls__51 }; arg_45 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_43 == nil { arg_35 = ifn_44.Invoke_O__O(arg_45) } else { arg_35 = linked_43.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O__O(root_42, arg_45) }; if linked_32 == nil { arg_30 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { arg_30 = linked_32.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if linked_28 == nil { tmp1 = ifn_29.Invoke_O__O(arg_30) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_27, arg_30) } }
//line :15:1
		return nil }(); var root_52 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; if linked_53 == nil { ifn_54.Invoke__O() } else { linked_53.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_52) }
//line :13:1
		if tmp6 != nil { panic(tmp6) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :13:1*/ tmp7 != nil { panic(tmp7) }; return tmp1 }


func A_arbace_c2j_check_read_all_fn__908000013_A_New() *A_arbace_c2j_check_read_all_fn__908000013_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000013_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Ctor() {}
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000013_A) Invoke_O_O__O(self, p1__908000012_SHARP___1 any) any { var root_36 any = A_arbace_c2j_check_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_c2j_check_A_const_17; var arg_40 any = p1__908000012_SHARP___1; if linked_37 == nil { return ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { return linked_37.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) } }
//line :16:1
func A_arbace_c2j_check_read_all_fn__908000015_A_New_O(p0 any) *A_arbace_c2j_check_read_all_fn__908000015_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_read_all_fn__908000015_A{}; t.Ctor_O(p0); return t }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :16:1
func (t *A_arbace_c2j_check_read_all_fn__908000015_A) Invoke_O__O(self any) any { var root_46 any = A_arbace_c2j_check_A_const_19.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = A_arbace_c2j_check_A_const_20; var arg_50 any = t.F_r; if linked_47 == nil { return ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { return linked_47.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) } }

func A_arbace_c2j_check_check_A_New() *A_arbace_c2j_check_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_c2j_check_check_A) Ctor() {}
//line :18:1
func (t *A_arbace_c2j_check_check_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var root_64 any = A_arbace_c2j_check_A_const_25.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_66 lang.IFn; if


	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var root_68 any = A_arbace_c2j_check_A_const_26.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any; var tmp1 any = A_arbace_c2j_check_check_fn__908000019_A_New(); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c2j_check_check_fn__908000019_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_c2j_check_check_fn__908000019_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; arg_71 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_72 any; var root_78 any = A_arbace_c2j_check_A_const_28.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var root_82 any = A_arbace_c2j_check_A_const_29.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_82, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = dir__0; var arg_86 any = Lit_2; if linked_83 == nil { arg_81 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { arg_81 = linked_83.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; if linked_79 == nil { arg_72 = ifn_80.Invoke_O__O(arg_81) } else { arg_72 = linked_79.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_78, arg_81) }; if linked_69 == nil { arg_67 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { arg_67 = linked_69.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; if linked_65 == nil { files__2 = ifn_66.Invoke_O__O(arg_67) } else { files__2 = linked_65.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_64, arg_67) }; var forms__3 any; var iter__1927001039__auto____3 any; var tmp3 any = /*line :18:1*/A_arbace_c2j_check_check_iter__908000021__908000027_A_New(); var tmp4 *jrt.Class; var fncls__204 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class; if



	fncls__204 == nil { var fncls__204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class = fncls__204d; tmp4 = fncls__204d } else { tmp4 = fncls__204 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); forms__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); var ns__4 any; var root_205 any = /*line :18:1*/A_arbace_c2j_check_A_const_45.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_207 lang.IFn; if







	linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = A_arbace_c2j_check_A_const_46; if linked_206 == nil { ns__4 = ifn_207.Invoke_O__O(arg_208) } else { ns__4 = linked_206.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_205, arg_208) }; var root_536 any =
	A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_check_A_const_74, ns__4); if linked_537 == nil { ifn_538.Invoke_O__O(arg_539) } else { linked_537.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_536, arg_539) }; var tmp5 any = A_arbace_c2j_check_check_fn__908000037_A_New(); var tmp6 *jrt.Class; var fncls__535 *jrt.Class = A_arbace_c2j_check_check_fn__908000037_A_fn_class; if fncls__535 == nil { var fncls__535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_c2j_check_check_fn__908000037_A_fn_class = fncls__535d; tmp6 = fncls__535d } else { tmp6 = fncls__535 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var root_545 any =

	A_arbace_c2j_check_A_const_22.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_check_A_const_75; var tmp9 any; var root_556 any = A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_557 == nil { tmp9 = ifn_558.Invoke_O__O(arg_559) } else { tmp9 = linked_557.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_556, arg_559) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_c2j_check_A_const_58; var tmp12 any = A_arbace_c2j_check_A_const_57; var tmp13 any; var root_560 any = A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_562 lang.IFn; if
	linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = lang.PersistentVector_EMPTY.Ref(); if linked_561 == nil { tmp13 = ifn_562.Invoke_O__O(arg_563) } else { tmp13 = linked_561.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_560, arg_563) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_c2j_check_A_const_76; var tmp16 any; var root_564 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_566 lang.IFn; if
	linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_565 == nil { tmp16 = ifn_566.Invoke_O__O(arg_567) } else { tmp16 = linked_565.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_564, arg_567) }; var tmp17 any = tmp16; var tmp18 any = A_arbace_c2j_check_A_const_77; var tmp19 any; var root_568 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_570 lang.IFn; if
	linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_569 == nil { tmp19 = ifn_570.Invoke_O__O(arg_571) } else { tmp19 = linked_569.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_568, arg_571) }; var tmp20 any = tmp19; var tmp21 any = A_arbace_c2j_check_A_const_78; var tmp22 any; var root_572 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_574 lang.IFn; if

	linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_573 == nil { tmp22 = ifn_574.Invoke_O__O(arg_575) } else { tmp22 = linked_573.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_572, arg_575) }; var tmp23 any = tmp22; var tmp24 any = A_arbace_c2j_check_A_const_79; var tmp25 any; var root_576 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_578 lang.IFn; if

	linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_577 == nil { tmp25 = ifn_578.Invoke_O__O(arg_579) } else { tmp25 = linked_577.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_576, arg_579) }; var tmp26 any = tmp25; var tmp27 any = A_arbace_c2j_check_A_const_80; var tmp28 any; var root_580 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_582 lang.IFn; if


	linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_581 == nil { tmp28 = ifn_582.Invoke_O__O(arg_583) } else { tmp28 = linked_581.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_580, arg_583) }; var tmp29 any = tmp28; var tmp30 any = A_arbace_c2j_check_A_const_81; var tmp31 any; var root_584 any = /*line :29:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_586 lang.IFn; if


	linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_585 == nil { tmp31 = ifn_586.Invoke_O__O(arg_587) } else { tmp31 = linked_585.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_584, arg_587) }; arg_548 = /*line :29:1*/tmp7.Invoke_O_O_O_O__O(tmp8, tmp10, tmp11, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp23, tmp24, tmp26, tmp27, tmp29, tmp30, tmp31))); if linked_546 == nil { ifn_547.Invoke_O__O(arg_548) } else { linked_546.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_545, arg_548) }; var tmp32 any; tmp38 := /*line :18:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














		{ var root_209 any = A_arbace_c2j_check_A_const_47.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_with_redefs_fn_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var tmp33 any = A_arbace_c2j_check_A_const_48; var tmp34 any = A_arbace_c2j_check_check_fn__908000039_A_New(); var tmp35 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_c2j_check_check_fn__908000039_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_c2j_check_check_fn__908000039_A_fn_class = fncls__214d; tmp35 = fncls__214d } else { tmp35 = fncls__214 }; arg_212 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil))); var arg_213 any; var tmp36 any = A_arbace_c2j_check_check_fn__908000041_A_New_O_O(ns__4, forms__3); var tmp37 *jrt.Class; var fncls__524 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_A_fn_class; if fncls__524 == nil { var fncls__524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_c2j_check_check_fn__908000041_A_fn_class = fncls__524d; tmp37 = fncls__524d } else { tmp37 = fncls__524 }; arg_213 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); if linked_210 == nil { tmp32 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp32 = linked_210.(*aot_arbace_core.A_arbace_core_with_redefs_fn_A).Invoke_O_O_O__O(root_209, arg_212, arg_213) } }
//line :18:1
		return nil }(); var root_525 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_527 lang.IFn; if










	linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; if linked_526 == nil { ifn_527.Invoke__O() } else { linked_526.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_525) }; if /*line :18:1*/ tmp38 != nil { panic(tmp38) }; return tmp32 }


func A_arbace_c2j_check_check_fn__908000019_A_New() *A_arbace_c2j_check_check_fn__908000019_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000019_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Ctor() {}
//line :21:1
func (t *A_arbace_c2j_check_check_fn__908000019_A) Invoke_O_O__O(self, p1__908000018_SHARP___1 any) any { var tmp1 any; var root_73 any = A_arbace_c2j_check_A_const_27.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = p1__908000018_SHARP___1; if linked_74 == nil { tmp1 = ifn_75.Invoke_O__O(arg_76) } else { tmp1 = linked_74.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_73, arg_76) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(tmp1)).EndsWith_String__Z(Lit_7)).Ref() }
func A_arbace_c2j_check_check_iter__908000021__908000027_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_A) Invoke_O_O__O(self, s__908000022__1 any) any { var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(self, s__908000022__1); var tmp2 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class = fncls__203d; tmp2 = fncls__203d } else { tmp2 = fncls__203 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Ctor_O_O(c__iter__908000021, c__s__908000022 any) { t.F_iter__908000021 = c__iter__908000021; t.F_s__908000022 = c__s__908000022 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A) Invoke_O__O(self any) any { { var s__908000022__1 any; var t_ any = t.F_s__908000022; t.F_s__908000022 = nil; s__908000022__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_87 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__908000022__1; if linked_88 == nil { temp__1927000414__auto____2 = ifn_89.Invoke_O__O(arg_90) } else { temp__1927000414__auto____2 = linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_91 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = xs__1927001018__auto____3; if linked_92 == nil { f__4 = ifn_93.Invoke_O__O(arg_94) } else { f__4 = linked_92.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_91, arg_94) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New(); var tmp2 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class = fncls__181d; tmp2 = fncls__181d } else { tmp2 = fncls__181 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_182 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_186 any = A_arbace_c2j_check_A_const_43.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_c2j_check_read_all_A_fn_class); var ifn_188 lang.IFn
													if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = f__4; if linked_187 == nil { tmp4 = ifn_188.Invoke_O__O(arg_189) } else { tmp4 = linked_187.(*A_arbace_c2j_check_read_all_A).Invoke_O_O__O(root_186, arg_189) }
//line :22:1
	arg_185 = tmp3.Invoke_O__O(tmp4); if linked_183 == nil { fs__1927001036__auto____6 = ifn_184.Invoke_O__O(arg_185) } else { fs__1927001036__auto____6 = linked_183.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_190 any = A_arbace_c2j_check_A_const_44.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = fs__1927001036__auto____6; var arg_194 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__908000021); var tmp6 any; var root_195 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = s__908000022__1; if linked_196 == nil { tmp6 = ifn_197.Invoke_O__O(arg_198) } else { tmp6 = linked_196.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_195, arg_198) }; arg_194 = tmp5.Invoke_O__O(tmp6); if linked_191 == nil { return ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { return linked_191.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) } } else { var tmp7 any; var root_199 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__908000022__1; if linked_200 == nil { tmp7 = ifn_201.Invoke_O__O(arg_202) } else { tmp7 = linked_200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_199, arg_202) }; s__908000022__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_New() *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Ctor() {}
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A) Invoke_O_O__O(self, s__908000024__1 any) any { var tmp1 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(self, s__908000024__1); var tmp2 *jrt.Class; var fncls__180 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class; if fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class = fncls__180d; tmp2 = fncls__180d } else { tmp2 = fncls__180 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Ctor_O_O(c__iter__908000023, c__s__908000024 any) { t.F_iter__908000023 = c__iter__908000023; t.F_s__908000024 = c__s__908000024 }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A) Invoke_O__O(self any) any { { var s__908000024__1 any; var t_ any = t.F_s__908000024; t.F_s__908000024 = nil; s__908000024__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_95 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = s__908000024__1; if linked_96 == nil { temp__1927000414__auto____2 = ifn_97.Invoke_O__O(arg_98) } else { temp__1927000414__auto____2 = linked_96.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_95, arg_98) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000024__3 any = temp__1927000414__auto____2; var tmp1 any; var root_99 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = s__908000024__3; if linked_100 == nil { tmp1 = ifn_101.Invoke_O__O(arg_102) } else { tmp1 = linked_100.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_99, arg_102) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_103 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = s__908000024__3; if linked_104 == nil { c__1927001037__auto____4 = ifn_105.Invoke_O__O(arg_106) } else { c__1927001037__auto____4 = linked_104.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_103, arg_106) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000026__6 any; var root_107 any = A_arbace_c2j_check_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_108 == nil { b__908000026__6 = ifn_109.Invoke_O__O(arg_110) } else { b__908000026__6 = linked_108.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_107, arg_110) }; var tmp2 any = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(size__1927001038__auto____5, b__908000026__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_129 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var root_134 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = b__908000026__6; if linked_135 == nil { arg_132 = ifn_136.Invoke_O__O(arg_137) } else { arg_132 = linked_135.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_134, arg_137) }; var arg_133 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); var tmp5 any; var root_138 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__908000024__3; if linked_139 == nil { tmp5 = ifn_140.Invoke_O__O(arg_141) } else { tmp5 = linked_139.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_138, arg_141) }; arg_133 = tmp4.Invoke_O__O(tmp5); if linked_130 == nil { return ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { return linked_130.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) } } else { var root_142 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_147 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = b__908000026__6; if linked_148 == nil { arg_145 = ifn_149.Invoke_O__O(arg_150) } else { arg_145 = linked_148.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_147, arg_150) }; var arg_146 any; if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } } } else { var fm__4 any; var root_151 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__908000024__3; if linked_152 == nil { fm__4 = ifn_153.Invoke_O__O(arg_154) } else { fm__4 = linked_152.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_151, arg_154) }; var tmp6 any; var and__1927000168__auto____5 any; var root_155 any = A_arbace_c2j_check_A_const_35.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_157 lang.IFn

	if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = fm__4; if linked_156 == nil { and__1927000168__auto____5 = ifn_157.Invoke_O__O(arg_158) } else { and__1927000168__auto____5 = linked_156.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_155, arg_158) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 any = A_arbace_c2j_check_A_const_36; var tmp8 any; var root_159 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = fm__4; if linked_160 == nil { tmp8 = ifn_161.Invoke_O__O(arg_162) } else { tmp8 = linked_160.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_159, arg_162) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp6 = and__1927000168__auto____5 }
//line :22:1
	if jrt.J2g_Truth(tmp6) { var root_163 any = A_arbace_c2j_check_A_const_42.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var root_168 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_170 lang.IFn


		if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = fm__4; if linked_169 == nil { arg_166 = ifn_170.Invoke_O__O(arg_171) } else { arg_166 = linked_169.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_168, arg_171) }
//line :22:1
		var arg_167 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__908000023); var tmp10 any; var root_172 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = s__908000024__3; if linked_173 == nil { tmp10 = ifn_174.Invoke_O__O(arg_175) } else { tmp10 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }; arg_167 = tmp9.Invoke_O__O(tmp10); if linked_164 == nil { return ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { return linked_164.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) } } else { var tmp11 any; var root_176 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__908000024__3; if linked_177 == nil { tmp11 = ifn_178.Invoke_O__O(arg_179) } else { tmp11 = linked_177.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_176, arg_179) }; s__908000024__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :22:1
func A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__908000026, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__908000026 = c__b__908000026; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :22:1
func (t *A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A) Invoke_O__O(self any) any { { var i__908000025__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000025__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000025__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_111 any = A_arbace_c2j_check_A_const_35.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_113 lang.IFn

	if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = fm__2; if linked_112 == nil { and__1927000168__auto____3 = ifn_113.Invoke_O__O(arg_114) } else { and__1927000168__auto____3 = linked_112.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_c2j_check_A_const_36; var tmp4 any; var root_115 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = fm__2; if linked_116 == nil { tmp4 = ifn_117.Invoke_O__O(arg_118) } else { tmp4 = linked_116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_115, arg_118) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :22:1
	if jrt.J2g_Truth(tmp2) { var root_119 any = A_arbace_c2j_check_A_const_37.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = t.F_b__908000026; var arg_123 any; var root_124 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_126 lang.IFn


		if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = fm__2; if linked_125 == nil { arg_123 = ifn_126.Invoke_O__O(arg_127) } else { arg_123 = linked_125.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_124, arg_127) }
//line :22:1
		if linked_120 == nil { ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { linked_120.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } else { i__908000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000025__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_check_check_fn__908000037_A_New() *A_arbace_c2j_check_check_fn__908000037_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000037_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Ctor() {}
//line :27:1
func (t *A_arbace_c2j_check_check_fn__908000037_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										tmp1 = lang.IFn_Cast(A_arbace_c2j_check_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_check_A_const_73)
//line :27:1
	return nil }(); var root_532 any = A_arbace_c2j_check_A_const_21.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; if linked_533 == nil { ifn_534.Invoke__O() } else { linked_533.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_532) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_c2j_check_check_fn__908000039_A_New() *A_arbace_c2j_check_check_fn__908000039_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000039_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Ctor() {}
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000039_A) Invoke_O_O_O__O(self, ___1, node__2 any) any { return node__2 }
//line :33:1
func A_arbace_c2j_check_check_fn__908000041_A_New_O_O(p0, p1 any) *A_arbace_c2j_check_check_fn__908000041_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Ctor_O_O(c__ns, c__forms any) { t.F_ns = c__ns; t.F_forms = c__forms }
//line :33:1
func (t *A_arbace_c2j_check_check_fn__908000041_A) Invoke_O__O(self any) any { var names__1 any; var root_215 any = A_arbace_c2j_check_A_const_49.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_217 lang.IFn; if
										linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(t.F_ns); var tmp2 *jrt.Class; var fncls__297 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class; if fncls__297 == nil { var fncls__297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class = fncls__297d; tmp2 = fncls__297d } else { tmp2 = fncls__297 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_218 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(t.F_forms); if linked_216 == nil { names__1 = ifn_217.Invoke_O__O(arg_218) } else { names__1 = linked_216.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_215, arg_218) }; var order__2 any; var root_298 any = /*line :33:1*/A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_300 lang.IFn; if
										linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var tmp3 *lang.Keyword = A_arbace_c2j_check_A_const_57; var arg_301 any = tmp3.Invoke_O__O(A_arbace_c2j_check_A_const_58.Get__O()); if linked_299 == nil { order__2 = ifn_300.Invoke_O__O(arg_301) } else { order__2 = linked_299.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_298, arg_301) }; var fails__3 any; var root_302 any = /*line :33:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_304 lang.IFn; if



	linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = lang.PersistentVector_EMPTY.Ref(); if linked_303 == nil { fails__3 = ifn_304.Invoke_O__O(arg_305) } else { fails__3 = linked_303.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_302, arg_305) }; var try_BANG___4 any; var tmp4 any = /*line :33:1*/A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(fails__3); var tmp5 *jrt.Class; var fncls__319 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class; if




	fncls__319 == nil { var fncls__319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class = fncls__319d; tmp5 = fncls__319d } else { tmp5 = fncls__319 }; try_BANG___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var t__5 any; var root_324 any = /*line :33:1*/A_arbace_c2j_check_A_const_59.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_326 lang.IFn; if








	linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref(); if linked_325 == nil { t__5 = ifn_326.Invoke_O__O(arg_327) } else { t__5 = linked_325.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_324, arg_327) }; var lap__6 any; var tmp6 any = /*line :33:1*/A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(t__5); var tmp7 *jrt.Class; var fncls__349 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class; if









	fncls__349 == nil { var fncls__349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class = fncls__349d; tmp7 = fncls__349d } else { tmp7 = fncls__349 }; lap__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil);
	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_11); var seq_908000056__7 any; var root_364 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_366 lang.IFn; if











	linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = order__2; if linked_365 == nil { seq_908000056__7 = ifn_366.Invoke_O__O(arg_367) } else { seq_908000056__7 = linked_365.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_364, arg_367) }; var chunk_908000057__8 any; var count_908000058__9 int64 = 0; var i_908000059__10 int64 = 0; L1:
//line :33:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000059__10, count_908000058__9) { var n__11 any = lang.Indexed_Cast(chunk_908000057__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000059__10)); var tmp8 any; var root_368 any = A_arbace_c2j_check_A_const_63.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any; var tmp9 *lang.Keyword = A_arbace_c2j_check_A_const_64; var tmp10 any; var root_372 any = A_arbace_c2j_check_A_const_65.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = n__11; if linked_373 == nil { tmp10 = ifn_374.Invoke_O__O(arg_375) } else { tmp10 = linked_373.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_372, arg_375) }; arg_371 = tmp9.Invoke_O__O(tmp10); if linked_369 == nil { tmp8 = ifn_370.Invoke_O__O(arg_371) } else { tmp8 = linked_369.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_368, arg_371) }; if jrt.J2g_Truth(tmp8) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__11, A_arbace_c2j_check_A_const_67.GetRawRoot__O()); seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } else { seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = seq_908000056__7, chunk_908000057__8, count_908000058__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000059__10); continue L1 } } else { var temp__1927000414__auto____11 any; var root_376 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = seq_908000056__7; if linked_377 == nil { temp__1927000414__auto____11 = ifn_378.Invoke_O__O(arg_379) } else { temp__1927000414__auto____11 = linked_377.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_376, arg_379) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_908000056__12 any = temp__1927000414__auto____11; var tmp11 any; var root_380 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = seq_908000056__12; if linked_381 == nil { tmp11 = ifn_382.Invoke_O__O(arg_383) } else { tmp11 = linked_381.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_380, arg_383) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_384 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = seq_908000056__12; if linked_385 == nil { c__1927000678__auto____13 = ifn_386.Invoke_O__O(arg_387) } else { c__1927000678__auto____13 = linked_385.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_384, arg_387) }; var tmp12 any; var root_480 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = seq_908000056__12; if linked_481 == nil { tmp12 = ifn_482.Invoke_O__O(arg_483) } else { tmp12 = linked_481.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_480, arg_483) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__13 any; var root_388 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = seq_908000056__12; if linked_389 == nil { n__13 = ifn_390.Invoke_O__O(arg_391) } else { n__13 = linked_389.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_388, arg_391) }; var tmp13 any; var root_392 any = A_arbace_c2j_check_A_const_63.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any; var tmp14 *lang.Keyword = A_arbace_c2j_check_A_const_64; var tmp15 any; var root_396 any = A_arbace_c2j_check_A_const_65.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = n__13; if linked_397 == nil { tmp15 = ifn_398.Invoke_O__O(arg_399) } else { tmp15 = linked_397.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_396, arg_399) }; arg_395 = tmp14.Invoke_O__O(tmp15); if linked_393 == nil { tmp13 = ifn_394.Invoke_O__O(arg_395) } else { tmp13 = linked_393.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_392, arg_395) }; if jrt.J2g_Truth(tmp13) { lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_12, n__13, A_arbace_c2j_check_A_const_67.GetRawRoot__O()); var tmp16 any; var root_484 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = seq_908000056__12; if linked_485 == nil { tmp16 = ifn_486.Invoke_O__O(arg_487) } else { tmp16 = linked_485.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_484, arg_487) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp16, nil, 0, 0; continue L1 } else { var tmp17 any; var root_488 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = seq_908000056__12; if linked_489 == nil { tmp17 = ifn_490.Invoke_O__O(arg_491) } else { tmp17 = linked_489.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_488, arg_491) }; seq_908000056__7, chunk_908000057__8, count_908000058__9, i_908000059__10 = tmp17, nil, 0, 0; continue L1 } } } }
//line :33:1
		break L1 };












	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_13); var seq_908000060__7 any; var root_400 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_402 lang.IFn; if













	linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = order__2; if linked_401 == nil { seq_908000060__7 = ifn_402.Invoke_O__O(arg_403) } else { seq_908000060__7 = linked_401.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_400, arg_403) }; var chunk_908000061__8 any; var count_908000062__9 int64 = 0; var i_908000063__10 int64 = 0; L2:
//line :33:1
	for {













		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000063__10, count_908000062__9) { var n__11_2 any = lang.Indexed_Cast(chunk_908000061__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000063__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__11_2, A_arbace_c2j_check_A_const_69.GetRawRoot__O()); seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = seq_908000060__7, chunk_908000061__8, count_908000062__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000063__10); continue L2 } else { var temp__1927000414__auto____11_2 any; var root_404 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = seq_908000060__7; if linked_405 == nil { temp__1927000414__auto____11_2 = ifn_406.Invoke_O__O(arg_407) } else { temp__1927000414__auto____11_2 = linked_405.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_404, arg_407) }; if jrt.J2g_Truth(temp__1927000414__auto____11_2) { var seq_908000060__12 any = temp__1927000414__auto____11_2; var tmp18 any; var root_408 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = seq_908000060__12; if linked_409 == nil { tmp18 = ifn_410.Invoke_O__O(arg_411) } else { tmp18 = linked_409.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____13_2 any; var root_412 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = seq_908000060__12; if linked_413 == nil { c__1927000678__auto____13_2 = ifn_414.Invoke_O__O(arg_415) } else { c__1927000678__auto____13_2 = linked_413.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_412, arg_415) }; var tmp19 any; var root_492 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = seq_908000060__12; if linked_493 == nil { tmp19 = ifn_494.Invoke_O__O(arg_495) } else { tmp19 = linked_493.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_492, arg_495) }; seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = tmp19, c__1927000678__auto____13_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var n__13_2 any; var root_416 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = seq_908000060__12; if linked_417 == nil { n__13_2 = ifn_418.Invoke_O__O(arg_419) } else { n__13_2 = linked_417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_416, arg_419) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_14, n__13_2, A_arbace_c2j_check_A_const_69.GetRawRoot__O()); var tmp20 any; var root_496 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = seq_908000060__12; if linked_497 == nil { tmp20 = ifn_498.Invoke_O__O(arg_499) } else { tmp20 = linked_497.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_496, arg_499) }; seq_908000060__7, chunk_908000061__8, count_908000062__9, i_908000063__10 = tmp20, nil, 0, 0; continue L2 } } }
//line :33:1
		break L2 };














	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_14); var seq_908000064__7 any; var root_420 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_422 lang.IFn; if















	linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_c2j_check_A_const_66.Invoke_O__O(order__2); if linked_421 == nil { seq_908000064__7 = ifn_422.Invoke_O__O(arg_423) } else { seq_908000064__7 = linked_421.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_420, arg_423) }; var chunk_908000065__8 any; var count_908000066__9 int64 = 0; var i_908000067__10 int64 = 0; L3:
//line :33:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000067__10, count_908000066__9) { var n__11_3 any = lang.Indexed_Cast(chunk_908000065__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000067__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__11_3, A_arbace_c2j_check_A_const_70.GetRawRoot__O()); seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = seq_908000064__7, chunk_908000065__8, count_908000066__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000067__10); continue L3 } else { var temp__1927000414__auto____11_3 any; var root_424 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = seq_908000064__7; if linked_425 == nil { temp__1927000414__auto____11_3 = ifn_426.Invoke_O__O(arg_427) } else { temp__1927000414__auto____11_3 = linked_425.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_424, arg_427) }; if jrt.J2g_Truth(temp__1927000414__auto____11_3) { var seq_908000064__12 any = temp__1927000414__auto____11_3; var tmp21 any; var root_428 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = seq_908000064__12; if linked_429 == nil { tmp21 = ifn_430.Invoke_O__O(arg_431) } else { tmp21 = linked_429.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_428, arg_431) }; if jrt.J2g_Truth(tmp21) { var c__1927000678__auto____13_3 any; var root_432 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seq_908000064__12; if linked_433 == nil { c__1927000678__auto____13_3 = ifn_434.Invoke_O__O(arg_435) } else { c__1927000678__auto____13_3 = linked_433.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_432, arg_435) }; var tmp22 any; var root_500 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = seq_908000064__12; if linked_501 == nil { tmp22 = ifn_502.Invoke_O__O(arg_503) } else { tmp22 = linked_501.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_500, arg_503) }; seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = tmp22, c__1927000678__auto____13_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var n__13_3 any; var root_436 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = seq_908000064__12; if linked_437 == nil { n__13_3 = ifn_438.Invoke_O__O(arg_439) } else { n__13_3 = linked_437.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_436, arg_439) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_15, n__13_3, A_arbace_c2j_check_A_const_70.GetRawRoot__O()); var tmp23 any; var root_504 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = seq_908000064__12; if linked_505 == nil { tmp23 = ifn_506.Invoke_O__O(arg_507) } else { tmp23 = linked_505.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_504, arg_507) }; seq_908000064__7, chunk_908000065__8, count_908000066__9, i_908000067__10 = tmp23, nil, 0, 0; continue L3 } } }
//line :33:1
		break L3 };
















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_15); var seq_908000068__7 any; var root_440 any = /*line :33:1*/A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_442 lang.IFn; if

















	linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = order__2; if linked_441 == nil { seq_908000068__7 = ifn_442.Invoke_O__O(arg_443) } else { seq_908000068__7 = linked_441.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_440, arg_443) }; var chunk_908000069__8 any; var count_908000070__9 int64 = 0; var i_908000071__10 int64 = 0; L4:
//line :33:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000071__10, count_908000070__9) { var n__11_4 any = lang.Indexed_Cast(chunk_908000069__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000071__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__11_4, A_arbace_c2j_check_A_const_71); seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = seq_908000068__7, chunk_908000069__8, count_908000070__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000071__10); continue L4 } else { var temp__1927000414__auto____11_4 any; var root_444 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = seq_908000068__7; if linked_445 == nil { temp__1927000414__auto____11_4 = ifn_446.Invoke_O__O(arg_447) } else { temp__1927000414__auto____11_4 = linked_445.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_444, arg_447) }; if jrt.J2g_Truth(temp__1927000414__auto____11_4) { var seq_908000068__12 any = temp__1927000414__auto____11_4; var tmp24 any; var root_448 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = seq_908000068__12; if linked_449 == nil { tmp24 = ifn_450.Invoke_O__O(arg_451) } else { tmp24 = linked_449.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_448, arg_451) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____13_4 any; var root_452 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_908000068__12; if linked_453 == nil { c__1927000678__auto____13_4 = ifn_454.Invoke_O__O(arg_455) } else { c__1927000678__auto____13_4 = linked_453.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_452, arg_455) }; var tmp25 any; var root_508 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seq_908000068__12; if linked_509 == nil { tmp25 = ifn_510.Invoke_O__O(arg_511) } else { tmp25 = linked_509.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_508, arg_511) }; seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = tmp25, c__1927000678__auto____13_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var n__13_4 any; var root_456 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = seq_908000068__12; if linked_457 == nil { n__13_4 = ifn_458.Invoke_O__O(arg_459) } else { n__13_4 = linked_457.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_456, arg_459) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_16, n__13_4, A_arbace_c2j_check_A_const_71); var tmp26 any; var root_512 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = seq_908000068__12; if linked_513 == nil { tmp26 = ifn_514.Invoke_O__O(arg_515) } else { tmp26 = linked_513.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_512, arg_515) }; seq_908000068__7, chunk_908000069__8, count_908000070__9, i_908000071__10 = tmp26, nil, 0, 0; continue L4 } } }
//line :33:1
		break L4 }; var seq_908000072__7 any; var root_460 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_462 lang.IFn; if


















	linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = order__2; if linked_461 == nil { seq_908000072__7 = ifn_462.Invoke_O__O(arg_463) } else { seq_908000072__7 = linked_461.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_460, arg_463) }; var chunk_908000073__8 any; var count_908000074__9 int64 = 0; var i_908000075__10 int64 = 0; L5:
//line :33:1
	for {


















		if lang.Numbers_Lt_J_J__Z_NoInit(i_908000075__10, count_908000074__9) { var n__11_5 any = lang.Indexed_Cast(chunk_908000073__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_908000075__10)); lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__11_5, A_arbace_c2j_check_A_const_72.GetRawRoot__O()); seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = seq_908000072__7, chunk_908000073__8, count_908000074__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_908000075__10); continue L5 } else { var temp__1927000414__auto____11_5 any; var root_464 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = seq_908000072__7; if linked_465 == nil { temp__1927000414__auto____11_5 = ifn_466.Invoke_O__O(arg_467) } else { temp__1927000414__auto____11_5 = linked_465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_464, arg_467) }; if jrt.J2g_Truth(temp__1927000414__auto____11_5) { var seq_908000072__12 any = temp__1927000414__auto____11_5; var tmp27 any; var root_468 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = seq_908000072__12; if linked_469 == nil { tmp27 = ifn_470.Invoke_O__O(arg_471) } else { tmp27 = linked_469.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_468, arg_471) }; if jrt.J2g_Truth(tmp27) { var c__1927000678__auto____13_5 any; var root_472 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = seq_908000072__12; if linked_473 == nil { c__1927000678__auto____13_5 = ifn_474.Invoke_O__O(arg_475) } else { c__1927000678__auto____13_5 = linked_473.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_472, arg_475) }; var tmp28 any; var root_516 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = seq_908000072__12; if linked_517 == nil { tmp28 = ifn_518.Invoke_O__O(arg_519) } else { tmp28 = linked_517.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_516, arg_519) }; seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = tmp28, c__1927000678__auto____13_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var n__13_5 any; var root_476 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = seq_908000072__12; if linked_477 == nil { n__13_5 = ifn_478.Invoke_O__O(arg_479) } else { n__13_5 = linked_477.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_476, arg_479) }; lang.IFn_Cast(try_BANG___4).Invoke_O_O_O__O(Lit_17, n__13_5, A_arbace_c2j_check_A_const_72.GetRawRoot__O()); var tmp29 any; var root_520 any = A_arbace_c2j_check_A_const_68.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = seq_908000072__12; if linked_521 == nil { tmp29 = ifn_522.Invoke_O__O(arg_523) } else { tmp29 = linked_521.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_520, arg_523) }; seq_908000072__7, chunk_908000073__8, count_908000074__9, i_908000075__10 = tmp29, nil, 0, 0; continue L5 } } }
//line :33:1
		break L5 };



















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_17); var tmp30 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()); var tmp31 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__1)).Ref(); var tmp32 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(order__2)).Ref(); var tmp33 any; var root_360 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_362 lang.IFn; if
	linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = fails__3; if linked_361 == nil { tmp33 = ifn_362.Invoke_O__O(arg_363) } else { tmp33 = linked_361.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_360, arg_363) }; /*line :54:1*/tmp30.Invoke_O_O_O_O_O_O_O__O(Lit_18, tmp31, Lit_19, tmp32, Lit_20, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp33)).Ref(), Lit_21); var root_320 any = /*line :34:1*/A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = fails__3; if linked_321 == nil { return ifn_322.Invoke_O__O(arg_323) } else { return linked_321.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_320, arg_323) } }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A{}; t.Ctor_O(p0); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A) Invoke_O_O__O(self, s__908000043__1 any) any { var tmp1 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(t.F_ns, self, s__908000043__1); var tmp2 *jrt.Class; var fncls__296 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class; if fncls__296 == nil { var fncls__296d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class = fncls__296d; tmp2 = fncls__296d } else { tmp2 = fncls__296 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Ctor_O_O_O(c__ns, c__iter__908000042, c__s__908000043 any) { t.F_ns = c__ns; t.F_iter__908000042 = c__iter__908000042; t.F_s__908000043 = c__s__908000043 }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A) Invoke_O__O(self any) any { { var s__908000043__1 any; var t_ any = t.F_s__908000043; t.F_s__908000043 = nil; s__908000043__1 = t_; for { var temp__1927000414__auto____2 any; var root_219 any = A_arbace_c2j_check_A_const_30.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = s__908000043__1; if linked_220 == nil { temp__1927000414__auto____2 = ifn_221.Invoke_O__O(arg_222) } else { temp__1927000414__auto____2 = linked_220.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_219, arg_222) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__908000043__3 any = temp__1927000414__auto____2; var tmp1 any; var root_223 any = A_arbace_c2j_check_A_const_32.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = s__908000043__3; if linked_224 == nil { tmp1 = ifn_225.Invoke_O__O(arg_226) } else { tmp1 = linked_224.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_223, arg_226) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_227 any = A_arbace_c2j_check_A_const_33.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = s__908000043__3; if linked_228 == nil { c__1927001037__auto____4 = ifn_229.Invoke_O__O(arg_230) } else { c__1927001037__auto____4 = linked_228.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_227, arg_230) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__908000045__6 any; var root_231 any = A_arbace_c2j_check_A_const_34.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_232 == nil { b__908000045__6 = ifn_233.Invoke_O__O(arg_234) } else { b__908000045__6 = linked_232.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_231, arg_234) }; var tmp2 any = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(t.F_ns, b__908000045__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class; if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class = fncls__250d; tmp3 = fncls__250d } else { tmp3 = fncls__250 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_251 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var root_256 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = b__908000045__6; if linked_257 == nil { arg_254 = ifn_258.Invoke_O__O(arg_259) } else { arg_254 = linked_257.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_256, arg_259) }; var arg_255 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); var tmp5 any; var root_260 any = A_arbace_c2j_check_A_const_41.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = s__908000043__3; if linked_261 == nil { tmp5 = ifn_262.Invoke_O__O(arg_263) } else { tmp5 = linked_261.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_260, arg_263) }; arg_255 = tmp4.Invoke_O__O(tmp5); if linked_252 == nil { return ifn_253.Invoke_O_O__O(arg_254, arg_255) } else { return linked_252.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_251, arg_254, arg_255) } } else { var root_264 any = A_arbace_c2j_check_A_const_39.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_269 any = A_arbace_c2j_check_A_const_40.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = b__908000045__6; if linked_270 == nil { arg_267 = ifn_271.Invoke_O__O(arg_272) } else { arg_267 = linked_270.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_269, arg_272) }; var arg_268 any; if linked_265 == nil { return ifn_266.Invoke_O_O__O(arg_267, arg_268) } else { return linked_265.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_264, arg_267, arg_268) } } } else { var f__4 any; var root_273 any = A_arbace_c2j_check_A_const_31.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__908000043__3; if linked_274 == nil { f__4 = ifn_275.Invoke_O__O(arg_276) } else { f__4 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; var root_277 any = A_arbace_c2j_check_A_const_42.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any; var root_282 any = A_arbace_c2j_check_A_const_50.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_284 lang.IFn
															if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = A_arbace_c2j_check_A_const_56; var arg_286 any; var root_287 any = A_arbace_c2j_check_A_const_52.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_53, t.F_ns, A_arbace_c2j_check_A_const_54, A_arbace_c2j_check_A_const_55)); var arg_291 any = f__4; if linked_288 == nil { arg_286 = ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { arg_286 = linked_288.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) }; if linked_283 == nil { arg_280 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_280 = linked_283.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }
//line :34:1
	var arg_281 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__908000042); var tmp7 any; var root_292 any = A_arbace_c2j_check_A_const_38.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = s__908000043__3; if linked_293 == nil { tmp7 = ifn_294.Invoke_O__O(arg_295) } else { tmp7 = linked_293.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_292, arg_295) }; arg_281 = tmp6.Invoke_O__O(tmp7); if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :34:1
func A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Ctor_O_O_I_O(c__ns, c__b__908000045 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ns = c__ns; t.F_b__908000045 = c__b__908000045; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :34:1
func (t *A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A) Invoke_O__O(self any) any { { var i__908000044__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__908000044__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__908000044__1)); var root_235 any = A_arbace_c2j_check_A_const_37.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = t.F_b__908000045; var arg_239 any; var root_240 any = A_arbace_c2j_check_A_const_50.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A_fn_class); var ifn_242 lang.IFn
																	if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_c2j_check_A_const_51; var arg_244 any; var root_245 any = A_arbace_c2j_check_A_const_52.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_check_A_const_53, t.F_ns, A_arbace_c2j_check_A_const_54, A_arbace_c2j_check_A_const_55)); var arg_249 any = f__2; if linked_246 == nil { arg_244 = ifn_247.Invoke_O_O__O(arg_248, arg_249) } else { arg_244 = linked_246.(*aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(root_245, arg_248, arg_249) }; if linked_241 == nil { arg_239 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { arg_239 = linked_241.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_declare_class_BANG__A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }
//line :34:1
	if linked_236 == nil { ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { linked_236.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_235, arg_238, arg_239) }; i__908000044__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__908000044__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Ctor_O(c__fails any) { t.F_fails = c__fails }
//line :38:1
func (t *A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A) Invoke_O_O_O_O__O(self, what__1, n__2, f__3 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																tmp1 = lang.IFn_Cast(f__3).Invoke_O__O(n__2)
//line :38:1
	return nil }(); if tmp2 != nil { if true { var t__6 jrt.Throwable_I = tmp2

		lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_25, what__1, n__2, t__6.GetMessage__String().Ref())
		var root_306 any = A_arbace_c2j_check_A_const_60.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = t.F_fails; var arg_310 any = A_arbace_c2j_check_A_const_11.GetRawRoot__O(); var arg_311 any = lang.Tuple_Create_O_O_O__IPersistentVector(n__2, what__1, t__6.GetMessage__String().Ref()); if linked_307 == nil { tmp1 = ifn_308.Invoke_O_O_O__O(arg_309, arg_310, arg_311) } else { tmp1 = linked_307.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_306, arg_309, arg_310, arg_311) } } }; return tmp1 }

func A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_New_O(p0 any) *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_check_fn__908000041_lap__908000054_A{}; t.Ctor_O(p0); return t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :43:1
func (t *A_arbace_c2j_check_check_fn__908000041_lap__908000054_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_check_A_const_61.GetRawRoot__O()); var tmp2 jrt.Number_I; var na_340 int64 = x__2; var na_341 any; var root_342 any = A_arbace_c2j_check_A_const_9.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = t.F_t; if linked_343 == nil { na_341 = ifn_344.Invoke_O__O(arg_345) } else { na_341 = linked_343.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_342, arg_345) }; if jrt.Long_InstanceOf(na_341) { var n0_346 int64 = na_340; var n1_347 int64 = jrt.NN(jrt.Long_Cast(na_341)).LongValue__J(); var nr_348 int64 = n0_346 - n1_347; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_347 == -9223372036854775808); if tmp4 { tmp4 = (n0_346^n1_347)&(n0_346^nr_348) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_348)) } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_340, na_341) } } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_340, na_341) }; tmp1.Invoke_O_O_O_O__O(Lit_18, k__1, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D_NoInit(tmp2, 1.0e7)), 100.0)).Ref(), Lit_24); var root_328 any = A_arbace_c2j_check_A_const_62.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = t.F_t; var arg_332 any = jrt.Long_ValueOf_J__Long_NoInit(x__2).Ref(); if linked_329 == nil { return ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { return linked_329.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_328, arg_331, arg_332) } }




















































































type A_arbace_c2j_check_A struct{ jrt.Object }

var A_arbace_c2j_check_A_const_pool *jrt.RefArray

var A_arbace_c2j_check_A_const_0 *lang.Var

var A_arbace_c2j_check_A_const_1 any

var A_arbace_c2j_check_A_const_2 any

var A_arbace_c2j_check_A_const_3 any

var A_arbace_c2j_check_A_const_4 any

var A_arbace_c2j_check_A_const_5 any

var A_arbace_c2j_check_A_const_6 *lang.Var

var A_arbace_c2j_check_A_const_7 any

var A_arbace_c2j_check_A_const_8 *lang.Var

var A_arbace_c2j_check_A_const_9 *lang.Var

var A_arbace_c2j_check_A_const_10 *lang.Var

var A_arbace_c2j_check_A_const_11 *lang.Var

var A_arbace_c2j_check_A_const_12 any

var A_arbace_c2j_check_A_const_13 *lang.Var

var A_arbace_c2j_check_A_const_14 *lang.Var

var A_arbace_c2j_check_A_const_15 *lang.Var

var A_arbace_c2j_check_A_const_16 *lang.Var

var A_arbace_c2j_check_A_const_17 *lang.Keyword

var A_arbace_c2j_check_A_const_18 *lang.Var

var A_arbace_c2j_check_A_const_19 *lang.Var

var A_arbace_c2j_check_A_const_20 any

var A_arbace_c2j_check_A_const_21 *lang.Var

var A_arbace_c2j_check_A_const_22 *lang.Var

var A_arbace_c2j_check_A_const_23 *lang.Var

var A_arbace_c2j_check_A_const_24 *lang.Var

var A_arbace_c2j_check_A_const_25 *lang.Var

var A_arbace_c2j_check_A_const_26 *lang.Var

var A_arbace_c2j_check_A_const_27 *lang.Var

var A_arbace_c2j_check_A_const_28 *lang.Var

var A_arbace_c2j_check_A_const_29 *lang.Var

var A_arbace_c2j_check_A_const_30 *lang.Var

var A_arbace_c2j_check_A_const_31 *lang.Var

var A_arbace_c2j_check_A_const_32 *lang.Var

var A_arbace_c2j_check_A_const_33 *lang.Var

var A_arbace_c2j_check_A_const_34 *lang.Var

var A_arbace_c2j_check_A_const_35 *lang.Var

var A_arbace_c2j_check_A_const_36 any

var A_arbace_c2j_check_A_const_37 *lang.Var

var A_arbace_c2j_check_A_const_38 *lang.Var

var A_arbace_c2j_check_A_const_39 *lang.Var

var A_arbace_c2j_check_A_const_40 *lang.Var

var A_arbace_c2j_check_A_const_41 *lang.Var

var A_arbace_c2j_check_A_const_42 *lang.Var

var A_arbace_c2j_check_A_const_43 *lang.Var

var A_arbace_c2j_check_A_const_44 *lang.Var

var A_arbace_c2j_check_A_const_45 *lang.Var

var A_arbace_c2j_check_A_const_46 any

var A_arbace_c2j_check_A_const_47 *lang.Var

var A_arbace_c2j_check_A_const_48 *lang.Var

var A_arbace_c2j_check_A_const_49 *lang.Var

var A_arbace_c2j_check_A_const_50 *lang.Var

var A_arbace_c2j_check_A_const_51 any

var A_arbace_c2j_check_A_const_52 *lang.Var

var A_arbace_c2j_check_A_const_53 *lang.Keyword

var A_arbace_c2j_check_A_const_54 *lang.Keyword

var A_arbace_c2j_check_A_const_55 *lang.Keyword

var A_arbace_c2j_check_A_const_56 any

var A_arbace_c2j_check_A_const_57 *lang.Keyword

var A_arbace_c2j_check_A_const_58 *lang.Var

var A_arbace_c2j_check_A_const_59 *lang.Var

var A_arbace_c2j_check_A_const_60 *lang.Var

var A_arbace_c2j_check_A_const_61 *lang.Var

var A_arbace_c2j_check_A_const_62 *lang.Var

var A_arbace_c2j_check_A_const_63 *lang.Var

var A_arbace_c2j_check_A_const_64 *lang.Keyword

var A_arbace_c2j_check_A_const_65 *lang.Var

var A_arbace_c2j_check_A_const_66 *lang.Var

var A_arbace_c2j_check_A_const_67 *lang.Var

var A_arbace_c2j_check_A_const_68 *lang.Var

var A_arbace_c2j_check_A_const_69 *lang.Var

var A_arbace_c2j_check_A_const_70 *lang.Var

var A_arbace_c2j_check_A_const_71 *lang.Var

var A_arbace_c2j_check_A_const_72 *lang.Var

var A_arbace_c2j_check_A_const_73 any

var A_arbace_c2j_check_A_const_74 *lang.Var

var A_arbace_c2j_check_A_const_75 *lang.Var

var A_arbace_c2j_check_A_const_76 *lang.Keyword

var A_arbace_c2j_check_A_const_77 *lang.Keyword

var A_arbace_c2j_check_A_const_78 *lang.Keyword

var A_arbace_c2j_check_A_const_79 *lang.Keyword

var A_arbace_c2j_check_A_const_80 *lang.Keyword

var A_arbace_c2j_check_A_const_81 *lang.Keyword

var A_arbace_c2j_check_A_init jrt.ClassInit

func A_arbace_c2j_check_A_Init() { if !A_arbace_c2j_check_A_init.Done() { A_arbace_c2j_check_A_init.Run(A_arbace_c2j_check_A_clinit) } }

func A_arbace_c2j_check_A_clinit() { A_arbace_c2j_check_A_clinit_p0(); A_arbace_c2j_check_A_clinit_p1(); A_arbace_c2j_check_A_clinit_p2(); A_arbace_c2j_check_A_clinit_p3(); A_arbace_c2j_check_A_clinit_p4(); A_arbace_c2j_check_A_clinit_p5(); A_arbace_c2j_check_A_clinit_p6() }

func A_arbace_c2j_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 110); A_arbace_c2j_check_A_const_0 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[28]); A_arbace_c2j_check_A_const_1 = A_arbace_c2j_check_A_const_pool.A[29]; A_arbace_c2j_check_A_const_2 = A_arbace_c2j_check_A_const_pool.A[30]; A_arbace_c2j_check_A_const_3 = A_arbace_c2j_check_A_const_pool.A[31]; A_arbace_c2j_check_A_const_4 = A_arbace_c2j_check_A_const_pool.A[32]; A_arbace_c2j_check_A_const_5 = A_arbace_c2j_check_A_const_pool.A[33]; A_arbace_c2j_check_A_const_6 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[34]); A_arbace_c2j_check_A_const_7 = A_arbace_c2j_check_A_const_pool.A[35]; A_arbace_c2j_check_A_const_8 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[36]); A_arbace_c2j_check_A_const_9 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[37]); A_arbace_c2j_check_A_const_10 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[38]); A_arbace_c2j_check_A_const_11 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[39]); A_arbace_c2j_check_A_const_12 = A_arbace_c2j_check_A_const_pool.A[40] }

func A_arbace_c2j_check_A_clinit_p1() { A_arbace_c2j_check_A_const_13 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[41]); A_arbace_c2j_check_A_const_14 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[42]); A_arbace_c2j_check_A_const_15 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[43]); A_arbace_c2j_check_A_const_16 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[44]); A_arbace_c2j_check_A_const_17 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[45]); A_arbace_c2j_check_A_const_18 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[46]); A_arbace_c2j_check_A_const_19 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[47]); A_arbace_c2j_check_A_const_20 = A_arbace_c2j_check_A_const_pool.A[48]; A_arbace_c2j_check_A_const_21 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[49]); A_arbace_c2j_check_A_const_22 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[50]); A_arbace_c2j_check_A_const_23 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[51]); A_arbace_c2j_check_A_const_24 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[52]) }

func A_arbace_c2j_check_A_clinit_p2() { A_arbace_c2j_check_A_const_25 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[53]); A_arbace_c2j_check_A_const_26 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[54]); A_arbace_c2j_check_A_const_27 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[55]); A_arbace_c2j_check_A_const_28 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[56]); A_arbace_c2j_check_A_const_29 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[57]); A_arbace_c2j_check_A_const_30 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[58]); A_arbace_c2j_check_A_const_31 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[59]); A_arbace_c2j_check_A_const_32 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[60]); A_arbace_c2j_check_A_const_33 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[61]); A_arbace_c2j_check_A_const_34 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[62]); A_arbace_c2j_check_A_const_35 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[63]); A_arbace_c2j_check_A_const_36 = A_arbace_c2j_check_A_const_pool.A[64] }

func A_arbace_c2j_check_A_clinit_p3() { A_arbace_c2j_check_A_const_37 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[65]); A_arbace_c2j_check_A_const_38 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[66]); A_arbace_c2j_check_A_const_39 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[67]); A_arbace_c2j_check_A_const_40 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[68]); A_arbace_c2j_check_A_const_41 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[69]); A_arbace_c2j_check_A_const_42 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[70]); A_arbace_c2j_check_A_const_43 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[71]); A_arbace_c2j_check_A_const_44 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[72]); A_arbace_c2j_check_A_const_45 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[73]); A_arbace_c2j_check_A_const_46 = A_arbace_c2j_check_A_const_pool.A[74]; A_arbace_c2j_check_A_const_47 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[75]); A_arbace_c2j_check_A_const_48 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[76]) }

func A_arbace_c2j_check_A_clinit_p4() { A_arbace_c2j_check_A_const_49 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[77]); A_arbace_c2j_check_A_const_50 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[78]); A_arbace_c2j_check_A_const_51 = A_arbace_c2j_check_A_const_pool.A[79]; A_arbace_c2j_check_A_const_52 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[80]); A_arbace_c2j_check_A_const_53 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[81]); A_arbace_c2j_check_A_const_54 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[82]); A_arbace_c2j_check_A_const_55 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[83]); A_arbace_c2j_check_A_const_56 = A_arbace_c2j_check_A_const_pool.A[84]; A_arbace_c2j_check_A_const_57 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[85]); A_arbace_c2j_check_A_const_58 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[86]); A_arbace_c2j_check_A_const_59 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[87]); A_arbace_c2j_check_A_const_60 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[88]) }

func A_arbace_c2j_check_A_clinit_p5() { A_arbace_c2j_check_A_const_61 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[89]); A_arbace_c2j_check_A_const_62 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[90]); A_arbace_c2j_check_A_const_63 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[91]); A_arbace_c2j_check_A_const_64 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[92]); A_arbace_c2j_check_A_const_65 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[93]); A_arbace_c2j_check_A_const_66 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[94]); A_arbace_c2j_check_A_const_67 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[95]); A_arbace_c2j_check_A_const_68 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[96]); A_arbace_c2j_check_A_const_69 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[97]); A_arbace_c2j_check_A_const_70 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[98]); A_arbace_c2j_check_A_const_71 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[99]); A_arbace_c2j_check_A_const_72 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[100]) }

func A_arbace_c2j_check_A_clinit_p6() { A_arbace_c2j_check_A_const_73 = A_arbace_c2j_check_A_const_pool.A[101]; A_arbace_c2j_check_A_const_74 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[102]); A_arbace_c2j_check_A_const_75 = lang.Var_Cast(A_arbace_c2j_check_A_const_pool.A[103]); A_arbace_c2j_check_A_const_76 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[104]); A_arbace_c2j_check_A_const_77 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[105]); A_arbace_c2j_check_A_const_78 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[106]); A_arbace_c2j_check_A_const_79 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[107]); A_arbace_c2j_check_A_const_80 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[108]); A_arbace_c2j_check_A_const_81 = lang.Keyword_Cast(A_arbace_c2j_check_A_const_pool.A[109]) }

func A_arbace_c2j_check_A_New() *A_arbace_c2j_check_A { A_arbace_c2j_check_A_Init(); t := &A_arbace_c2j_check_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_A) Ctor() {}

func (t *A_arbace_c2j_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_A_class }

func (t *A_arbace_c2j_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_A); return ok }

func A_arbace_c2j_check_A_Cast(x any) *A_arbace_c2j_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_A_class)) }; return v }



type A_arbace_c2j_check_check_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000019_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000019_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000037_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000037_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000039_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_fn__908000039_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_A struct{ j2g_header uint64; F_ns, F_forms any }

var A_arbace_c2j_check_check_fn__908000041_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A struct{ j2g_header uint64; F_ns any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A struct{ j2g_header uint64; F_ns, F_iter__908000042, F_s__908000043 any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A struct{ j2g_header uint64; F_ns, F_b__908000045 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_fn__908000041_iter__908000042__908000046_fn__908000047_fn__908000048_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_lap__908000054_A struct{ j2g_header uint64; F_t any }

var A_arbace_c2j_check_check_fn__908000041_lap__908000054_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A struct{ j2g_header uint64; F_fails any }

var A_arbace_c2j_check_check_fn__908000041_try_BANG___908000052_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A struct{ j2g_header uint64; F_iter__908000021, F_s__908000022 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A struct{ j2g_header uint64; F_iter__908000023, F_s__908000024 any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_A_fn_class *jrt.Class



type A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__908000026, F_c__1927001037__auto__ any }

var A_arbace_c2j_check_check_iter__908000021__908000027_fn__908000028_iter__908000023__908000029_fn__908000030_fn__908000031_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000004_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000004_A_New() *A_arbace_c2j_check_eval908000004_A { t := &A_arbace_c2j_check_eval908000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000004_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000004_A_class }

func (t *A_arbace_c2j_check_eval908000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000004_A); return ok }

func A_arbace_c2j_check_eval908000004_A_Cast(x any) *A_arbace_c2j_check_eval908000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000004_A_class)) }; return v }



type A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000004_loading__1927001464__auto____908000005_A_fn_class *jrt.Class



type A_arbace_c2j_check_eval908000008_A struct{ jrt.Object }

func A_arbace_c2j_check_eval908000008_A_New() *A_arbace_c2j_check_eval908000008_A { t := &A_arbace_c2j_check_eval908000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_check_eval908000008_A) Ctor() {}

func (t *A_arbace_c2j_check_eval908000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_check_eval908000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_check_eval908000008_A_class }

func (t *A_arbace_c2j_check_eval908000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_check_eval908000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_check_eval908000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_check_eval908000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_check_eval908000008_A); return ok }

func A_arbace_c2j_check_eval908000008_A_Cast(x any) *A_arbace_c2j_check_eval908000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_check_eval908000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_check_eval908000008_A_class)) }; return v }



type A_arbace_c2j_check_eval908000008_fn__908000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_eval908000008_fn__908000009_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000013_A struct{ j2g_header uint64 }

var A_arbace_c2j_check_read_all_fn__908000013_A_fn_class *jrt.Class



type A_arbace_c2j_check_read_all_fn__908000015_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_check_read_all_fn__908000015_A_fn_class *jrt.Class
