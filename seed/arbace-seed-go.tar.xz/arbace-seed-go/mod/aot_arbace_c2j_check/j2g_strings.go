//line j2g_strings.ae:1
package aot_arbace_c2j_check

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn14,arbace.java.iokn2,asyn2,ioyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn20,arbace.classes.parseyn1,pyn21,arbace.classes.interpyn6,interpyn11,arbace.corekn3,docks16,arbace.c2j.check3,eofkn3,eofyn8,defclassyn6,arbacekn7,nestingkn3,topkn2,nskn5,orderkn12,headers-donekn8,counterskn11,switch-mapskn14,switch-holderskn12,source-triedkn14,assert-holderskn12,holder-firstv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,v11,arbace.core5,referR11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.c2j.checkm2,R12,s406,A quick check of the back end's output (standalone S6), without j2g: the Java forms of a\n  compiled tree analyzed in the running program, as one compilation, by the Java forms'\n  analysis the REPL uses (arbace.classes.interp/analyze-forms), against the program's classes\n  by reflection. j2g's analysis is the same code against the Java forms; this finds most of\n  what j2g's load would report, in seconds.v14,arbace.java.io6,readerv11,arbace.core5,doallv11,arbace.core10,take-whilev11,arbace.core4,not=R13,v11,arbace.core10,repeatedlyv11,arbace.core4,readm2,R14,R13,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core4,sortv11,arbace.core6,filterv11,arbace.core3,strv11,arbace.core8,file-seqv14,arbace.java.io4,filev11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core4,seq?R15,v11,arbace.core12,chunk-appendv11,arbace.core4,restv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv16,arbace.c2j.check8,read-allv11,arbace.core6,concatv11,arbace.core9,create-nsR16,v11,arbace.core14,with-redefs-fnv22,arbace.classes.analyze11,accessorizev11,arbace.core3,vecv22,arbace.classes.analyze14,declare-class!m2,R17,R18,v20,arbace.classes.parse11,parse-classR19,R17,R18,m2,R17,R18,R20,v22,arbace.classes.analyze6,*unit*v11,arbace.core4,atomv11,arbace.core5,swap!v11,arbace.core7,printlnv11,arbace.core6,reset!v11,arbace.core3,notR21,v22,arbace.classes.analyze4,declv22,arbace.classes.analyze16,supertypes-firstv22,arbace.classes.analyze15,resolve-header!v11,arbace.core4,nextv22,arbace.classes.analyze16,resolve-members!v22,arbace.classes.analyze12,add-bridges!v22,arbace.classes.analyze19,mark-enum-abstract!v22,arbace.classes.analyze14,analyze-class!R11,v11,arbace.core4,*ns*v18,arbace.classes.env13,*compile-set*R22,R23,R24,R25,R26,R27,")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000019")

var Lit_2 *jrt.String = jrt.Intern("arbace")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.check$check$iter__908000021__908000027")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000037")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000039")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000041")

var Lit_7 *jrt.String = jrt.Intern(".ae")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000041$iter__908000042__908000046")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000041$try_BANG___908000052")

var Lit_10 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000041$lap__908000054")

var Lit_11 *jrt.String = jrt.Intern("parse and declare")

var Lit_12 *jrt.String = jrt.Intern("header")

var Lit_13 *jrt.String = jrt.Intern("headers")

var Lit_14 *jrt.String = jrt.Intern("members")

var Lit_15 *jrt.String = jrt.Intern("bridges")

var Lit_16 *jrt.String = jrt.Intern("enum")

var Lit_17 *jrt.String = jrt.Intern("analysis")

var Lit_18 *jrt.String = jrt.Intern("aot check:")

var Lit_19 *jrt.String = jrt.Intern("top-level classes,")

var Lit_20 *jrt.String = jrt.Intern("classes analyzed,")

var Lit_21 *jrt.String = jrt.Intern("failed")

var Lit_22 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000041$iter__908000042__908000046$fn__908000047")

var Lit_23 *jrt.String = jrt.Intern("arbace.c2j.check$check$fn__908000041$iter__908000042__908000046$fn__908000047$fn__908000048")

var Lit_24 *jrt.String = jrt.Intern("s")

var Lit_25 *jrt.String = jrt.Intern("aot check: FAILED")

var Lit_26 *jrt.String = jrt.Intern("arbace.c2j.check$check$iter__908000021__908000027$fn__908000028")

var Lit_27 *jrt.String = jrt.Intern("arbace.c2j.check$check$iter__908000021__908000027$fn__908000028$iter__908000023__908000029")

var Lit_28 *jrt.String = jrt.Intern("arbace.c2j.check$check$iter__908000021__908000027$fn__908000028$iter__908000023__908000029$fn__908000030")

var Lit_29 *jrt.String = jrt.Intern("arbace.c2j.check$check$iter__908000021__908000027$fn__908000028$iter__908000023__908000029$fn__908000030$fn__908000031")

var Lit_30 *jrt.String = jrt.Intern("arbace.c2j.check$read_all$fn__908000013")

var Lit_31 *jrt.String = jrt.Intern("arbace.c2j.check$read_all$fn__908000015")

var Lit_32 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn1,fkn4,linekn6,columnkn4,fileyn3,dirv11,arbace.core5,in-nsMyn16,arbace.c2j.checkm2,R0,s406,A quick check of the back end's output (standalone S6), without j2g: the Java forms of a\n  compiled tree analyzed in the running program, as one compilation, by the Java forms'\n  analysis the REPL uses (arbace.classes.interp/analyze-forms), against the program's classes\n  by reflection. j2g's analysis is the same code against the Java forms; this finds most of\n  what j2g's load would report, in seconds.m2,R0,s406,A quick check of the back end's output (standalone S6), without j2g: the Java forms of a\n  compiled tree analyzed in the running program, as one compilation, by the Java forms'\n  analysis the REPL uses (arbace.classes.interp/analyze-forms), against the program's classes\n  by reflection. j2g's analysis is the same code against the Java forms; this finds most of\n  what j2g's load would report, in seconds.R1,v16,arbace.c2j.check8,read-allm10,R2,TR3,L1,V1,R4,R5,i13,R6,i1,R7,s19,arbace/c2j/check.aev16,arbace.c2j.check5,checkm10,R3,L1,V1,R8,R0,s81,Analyzes the Java forms of every file under dir; prints and returns the failures.R5,i18,R6,i1,R7,s19,arbace/c2j/check.ae")

var Lit_33 *jrt.String = jrt.Intern("arbace.c2j.check$eval908000004$loading__1927001464__auto____908000005")

var Lit_34 *jrt.String = jrt.Intern("arbace.c2j.check$eval908000008$fn__908000009")

var Lit_35 *jrt.String = jrt.Intern("arbace.c2j.check$read_all")

var Lit_36 *jrt.String = jrt.Intern("arbace.c2j.check$check")
