//line a2g_strings.ae:1
package aot_arbace_a2g_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("arbace.string")

var Lit_3 *jrt.String = jrt.Intern("as")

var Lit_4 *jrt.String = jrt.Intern("str")

var Lit_5 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_6 *jrt.String = jrt.Intern("io")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_8 *jrt.String = jrt.Intern("t")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_10 *jrt.String = jrt.Intern("env")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_12 *jrt.String = jrt.Intern("a")

var Lit_13 *jrt.String = jrt.Intern("arbace.a2g.world")

var Lit_14 *jrt.String = jrt.Intern("w")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_16 *jrt.String = jrt.Intern("jrt")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_18 *jrt.String = jrt.Intern("m")

var Lit_19 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_20 *jrt.String = jrt.Intern("nm")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.reach")

var Lit_22 *jrt.String = jrt.Intern("r")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.access")

var Lit_24 *jrt.String = jrt.Intern("acc")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.code")

var Lit_26 *jrt.String = jrt.Intern("c")

var Lit_27 *jrt.String = jrt.Intern("arbace.a2g.vh")

var Lit_28 *jrt.String = jrt.Intern("vh")

var Lit_29 *jrt.String = jrt.Intern("arbace.a2g.decls")

var Lit_30 *jrt.String = jrt.Intern("d")

var Lit_31 *jrt.String = jrt.Intern("arbace.a2g.out")

var Lit_32 *jrt.String = jrt.Intern("out")

var Lit_33 *jrt.String = jrt.Intern("arbace.a2g.dyn")

var Lit_34 *jrt.String = jrt.Intern("dyn")

var Lit_35 *jrt.String = jrt.Intern("arbace.a2g.dyncf")

var Lit_36 *jrt.String = jrt.Intern("dyncf")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.fromfn")

var Lit_38 *jrt.String = jrt.Intern("fromfn")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.checks")

var Lit_40 *jrt.String = jrt.Intern("chk")

var Lit_41 *jrt.String = jrt.Intern("arbace.a2g.embed")

var Lit_42 *jrt.String = jrt.Intern("embed")

var Lit_43 *jrt.String = jrt.Intern("arbace.a2g.edge")

var Lit_44 *jrt.String = jrt.Intern("edge")

var Lit_45 *jrt.String = jrt.Intern("arbace.a2g.zlib")

var Lit_46 *jrt.String = jrt.Intern("zlib")

var Lit_47 *jrt.String = jrt.Intern("arbace.g2a.print")

var Lit_48 *jrt.String = jrt.Intern("gp")

var Lit_49 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_50 *jrt.String = jrt.Intern("refer")

var Lit_51 *jrt.String = jrt.Intern("commute")

var Lit_52 *jrt.String = jrt.Intern("deref")

var Lit_53 *jrt.String = jrt.Intern("conj")

var Lit_54 *jrt.String = jrt.Intern("arbace.a2g.main")

var Lit_55 *jrt.String = jrt.Intern("doc")

var Lit_56 *jrt.String = jrt.Intern("bin/a2g: class forms to Go forms (doc/go/A2G-SPEC.md, doc/go/A2G-NOTES.md).\n\n  bin/a2g [OPTIONS]\n    --out DIR          output directory (default .tmp/a2g/out): DIR/gen/go/... the generated\n                       forms (A2G-SPEC §4.3: the files a2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/g2a build; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of class forms files (test fixtures)\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (A2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       a2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/g2a build --line-file DIR/prog\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): a2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/a2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)")

var Lit_57 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_58 *jrt.String = jrt.Intern("seq")

var Lit_59 *jrt.String = jrt.Intern("first")

var Lit_60 *jrt.String = jrt.Intern("next")

var Lit_61 *jrt.String = jrt.Intern("slice")

var Lit_62 *jrt.String = jrt.Intern("roots")

var Lit_63 *jrt.String = jrt.Intern("inputs")

var Lit_64 *jrt.String = jrt.Intern("ex-info")

var Lit_65 *jrt.String = jrt.Intern("rest")

var Lit_66 *jrt.String = jrt.Intern("assoc")

var Lit_67 *jrt.String = jrt.Intern("jdk")

var Lit_68 *jrt.String = jrt.Intern("record-edge")

var Lit_69 *jrt.String = jrt.Intern("update")

var Lit_70 *jrt.String = jrt.Intern("program")

var Lit_71 *jrt.String = jrt.Intern("lang")

var Lit_72 *jrt.String = jrt.Intern("jvm-reflection")

var Lit_73 *jrt.String = jrt.Intern("mains")

var Lit_74 *jrt.String = jrt.Intern("fnil")

var Lit_75 *jrt.String = jrt.Intern("re-pattern")

var Lit_76 *jrt.String = jrt.Intern("tests")

var Lit_77 *jrt.String = jrt.Intern("replace")

var Lit_78 *jrt.String = jrt.Intern("file")

var Lit_79 *jrt.String = jrt.Intern("set")

var Lit_80 *jrt.String = jrt.Intern("map")

var Lit_81 *jrt.String = jrt.Intern("internal")

var Lit_82 *jrt.String = jrt.Intern("keys")

var Lit_83 *jrt.String = jrt.Intern("read-forms")

var Lit_84 *jrt.String = jrt.Intern("merge")

var Lit_85 *jrt.String = jrt.Intern("into")

var Lit_86 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_87 *jrt.String = jrt.Intern("chunk-first")

var Lit_88 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_89 *jrt.String = jrt.Intern("chunk-append")

var Lit_90 *jrt.String = jrt.Intern("go")

var Lit_91 *jrt.String = jrt.Intern("go-class-name")

var Lit_92 *jrt.String = jrt.Intern("var")

var Lit_93 *jrt.String = jrt.Intern("standin")

var Lit_94 *jrt.String = jrt.Intern("chunk-cons")

var Lit_95 *jrt.String = jrt.Intern("cons")

var Lit_96 *jrt.String = jrt.Intern("chunk")

var Lit_97 *jrt.String = jrt.Intern("chunk-rest")

var Lit_98 *jrt.String = jrt.Intern("classes")

var Lit_99 *jrt.String = jrt.Intern("subs")

var Lit_100 *jrt.String = jrt.Intern("not")

var Lit_101 *jrt.String = jrt.Intern("jvm?")

var Lit_102 *jrt.String = jrt.Intern("unexported")

var Lit_103 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_104 *jrt.String = jrt.Intern("arbace.a2g.jvm")

var Lit_105 *jrt.String = jrt.Intern("unexported?")

var Lit_106 *jrt.String = jrt.Intern("ends-with?")

var Lit_107 *jrt.String = jrt.Intern("mapcat")

var Lit_108 *jrt.String = jrt.Intern("split")

var Lit_109 *jrt.String = jrt.Intern("decl")

var Lit_110 *jrt.String = jrt.Intern("concat")

var Lit_111 *jrt.String = jrt.Intern("root-keys")

var Lit_112 *jrt.String = jrt.Intern("filter")

var Lit_113 *jrt.String = jrt.Intern("starts-with?")

var Lit_114 *jrt.String = jrt.Intern("re-find")

var Lit_115 *jrt.String = jrt.Intern("\\$\\d")

var Lit_116 *jrt.String = jrt.Intern("order")

var Lit_117 *jrt.String = jrt.Intern("*unit*")

var Lit_118 *jrt.String = jrt.Intern("#")

var Lit_119 *jrt.String = jrt.Intern("name")

var Lit_120 *jrt.String = jrt.Intern("has?")

var Lit_121 *jrt.String = jrt.Intern("flags")

var Lit_122 *jrt.String = jrt.Intern("desc")

var Lit_123 *jrt.String = jrt.Intern("methods")

var Lit_124 *jrt.String = jrt.Intern("jrt-classes")

var Lit_125 *jrt.String = jrt.Intern("*w*")

var Lit_126 *jrt.String = jrt.Intern("go-name")

var Lit_127 *jrt.String = jrt.Intern("get-in")

var Lit_128 *jrt.String = jrt.Intern("funcs")

var Lit_129 *jrt.String = jrt.Intern("new-name")

var Lit_130 *jrt.String = jrt.Intern("static?")

var Lit_131 *jrt.String = jrt.Intern("method-base")

var Lit_132 *jrt.String = jrt.Intern("else")

var Lit_133 *jrt.String = jrt.Intern("contains?")

var Lit_134 *jrt.String = jrt.Intern("ctor-real-desc")

var Lit_135 *jrt.String = jrt.Intern("files")

var Lit_136 *jrt.String = jrt.Intern("seq?")

var Lit_137 *jrt.String = jrt.Intern("symbol?")

var Lit_138 *jrt.String = jrt.Intern("second")

var Lit_139 *jrt.String = jrt.Intern("tag")

var Lit_140 *jrt.String = jrt.Intern("*")

var Lit_141 *jrt.String = jrt.Intern("vector?")

var Lit_142 *jrt.String = jrt.Intern("drop")

var Lit_143 *jrt.String = jrt.Intern("volatile!")

var Lit_144 *jrt.String = jrt.Intern("re-matches")

var Lit_145 *jrt.String = jrt.Intern("vreset!")

var Lit_146 *jrt.String = jrt.Intern("coll?")

var Lit_147 *jrt.String = jrt.Intern("run!")

var Lit_148 *jrt.String = jrt.Intern("apply")

var Lit_149 *jrt.String = jrt.Intern("list")

var Lit_150 *jrt.String = jrt.Intern("remove")

var Lit_151 *jrt.String = jrt.Intern("mentions?")

var Lit_152 *jrt.String = jrt.Intern("empty?")

var Lit_153 *jrt.String = jrt.Intern("join")

var Lit_154 *jrt.String = jrt.Intern("some?")

var Lit_155 *jrt.String = jrt.Intern("not=")

var Lit_156 *jrt.String = jrt.Intern("method-recv-type")

var Lit_157 *jrt.String = jrt.Intern("form-names")

var Lit_158 *jrt.String = jrt.Intern("const")

var Lit_159 *jrt.String = jrt.Intern("type")

var Lit_160 *jrt.String = jrt.Intern("some")

var Lit_161 *jrt.String = jrt.Intern("string?")

var Lit_162 *jrt.String = jrt.Intern("vec")

var Lit_163 *jrt.String = jrt.Intern("init")

var Lit_164 *jrt.String = jrt.Intern("filter-init-body")

var Lit_165 *jrt.String = jrt.Intern("spit")

var Lit_166 *jrt.String = jrt.Intern("make-parents")

var Lit_167 *jrt.String = jrt.Intern("copy")

var Lit_168 *jrt.String = jrt.Intern("deflate")

var Lit_169 *jrt.String = jrt.Intern("par-mapv")

var Lit_170 *jrt.String = jrt.Intern("doall")

var Lit_171 *jrt.String = jrt.Intern("jobs")

var Lit_172 *jrt.String = jrt.Intern("resource-file")

var Lit_173 *jrt.String = jrt.Intern("ns")

var Lit_174 *jrt.String = jrt.Intern("go.arbace.cmd.arbace")

var Lit_175 *jrt.String = jrt.Intern("arbace.go")

var Lit_176 *jrt.String = jrt.Intern("line")

var Lit_177 *jrt.String = jrt.Intern("column")

var Lit_178 *jrt.String = jrt.Intern("load")

var Lit_179 *jrt.String = jrt.Intern("arbace/image")

var Lit_180 *jrt.String = jrt.Intern("arbace/image_types")

var Lit_181 *jrt.String = jrt.Intern("arbace/main")

var Lit_182 *jrt.String = jrt.Intern("arbace/rlwrap_linux")

var Lit_183 *jrt.String = jrt.Intern("arbace/rlwrap_other")

var Lit_184 *jrt.String = jrt.Intern("package")

var Lit_185 *jrt.String = jrt.Intern("main")

var Lit_186 *jrt.String = jrt.Intern("path")

var Lit_187 *jrt.String = jrt.Intern("image.go")

var Lit_188 *jrt.String = jrt.Intern("image_types.go")

var Lit_189 *jrt.String = jrt.Intern("main.go")

var Lit_190 *jrt.String = jrt.Intern("rlwrap_linux.go")

var Lit_191 *jrt.String = jrt.Intern("rlwrap_other.go")

var Lit_192 *jrt.String = jrt.Intern("embed-files")

var Lit_193 *jrt.String = jrt.Intern("image.bin")

var Lit_194 *jrt.String = jrt.Intern("resources")

var Lit_195 *jrt.String = jrt.Intern("res")

var Lit_196 *jrt.String = jrt.Intern("FS")

var Lit_197 *jrt.String = jrt.Intern("resources are the namespaces' sources RT.load reads (EVAL-NOTES.md, \"Loading\").\n")

var Lit_198 *jrt.String = jrt.Intern("imageData")

var Lit_199 *jrt.String = jrt.Intern("string")

var Lit_200 *jrt.String = jrt.Intern("imageData is the image of prepared namespaces (EXEC-NOTES.md; image.go): empty until bin/arbace-go --build writes it.\n")

var Lit_201 *jrt.String = jrt.Intern("arbaceVersion")

var Lit_202 *jrt.String = jrt.Intern("arbaceVersion is Arbace's version, the map *arbace-version* reads from the system property arbace.version: empty in a2g's output, set by bin/arbace-go's link (go build -ldflags -X main.arbaceVersion=...).\n")

var Lit_203 *jrt.String = jrt.Intern("func")

var Lit_204 *jrt.String = jrt.Intern("execRlwrap")

var Lit_205 *jrt.String = jrt.Intern("when")

var Lit_206 *jrt.String = jrt.Intern("!=")

var Lit_207 *jrt.String = jrt.Intern("")

var Lit_208 *jrt.String = jrt.Intern("System_SetProperty_String_String__String")

var Lit_209 *jrt.String = jrt.Intern("Str")

var Lit_210 *jrt.String = jrt.Intern("arbace.version")

var Lit_211 *jrt.String = jrt.Intern("let")

var Lit_212 *jrt.String = jrt.Intern("values")

var Lit_213 *jrt.String = jrt.Intern("sub")

var Lit_214 *jrt.String = jrt.Intern("err")

var Lit_215 *jrt.String = jrt.Intern("fs")

var Lit_216 *jrt.String = jrt.Intern("Sub")

var Lit_217 *jrt.String = jrt.Intern("==")

var Lit_218 *jrt.String = jrt.Intern("SetHost")

var Lit_219 *jrt.String = jrt.Intern("ProgramHost")

var Lit_220 *jrt.String = jrt.Intern("setupImage")

var Lit_221 *jrt.String = jrt.Intern("args")

var Lit_222 *jrt.String = jrt.Intern("NewRefArray")

var Lit_223 *jrt.String = jrt.Intern("String_class")

var Lit_224 *jrt.String = jrt.Intern("conv")

var Lit_225 *jrt.String = jrt.Intern("int32")

var Lit_226 *jrt.String = jrt.Intern("-")

var Lit_227 *jrt.String = jrt.Intern("len")

var Lit_228 *jrt.String = jrt.Intern("os")

var Lit_229 *jrt.String = jrt.Intern("Args")

var Lit_230 *jrt.String = jrt.Intern("range")

var Lit_231 *jrt.String = jrt.Intern("i")

var Lit_232 *jrt.String = jrt.Intern("subslice")

var Lit_233 *jrt.String = jrt.Intern("aset")

var Lit_234 *jrt.String = jrt.Intern(".-A")

var Lit_235 *jrt.String = jrt.Intern("status")

var Lit_236 *jrt.String = jrt.Intern("RunMain")

var Lit_237 *jrt.String = jrt.Intern("fn")

var Lit_238 *jrt.String = jrt.Intern("Main_Main_String1__V")

var Lit_239 *jrt.String = jrt.Intern("finishImage")

var Lit_240 *jrt.String = jrt.Intern("Exit")

var Lit_241 *jrt.String = jrt.Intern("imports")

var Lit_242 *jrt.String = jrt.Intern("io/fs")

var Lit_243 *jrt.String = jrt.Intern("arbace/jrt")

var Lit_244 *jrt.String = jrt.Intern("arbace/lang")

var Lit_245 *jrt.String = jrt.Intern("_")

var Lit_246 *jrt.String = jrt.Intern("pkg-path")

var Lit_247 *jrt.String = jrt.Intern("keyword")

var Lit_248 *jrt.String = jrt.Intern("sort")

var Lit_249 *jrt.String = jrt.Intern("distinct")

var Lit_250 *jrt.String = jrt.Intern("vals")

var Lit_251 *jrt.String = jrt.Intern("compiled-packages")

var Lit_252 *jrt.String = jrt.Intern("source-of")

var Lit_253 *jrt.String = jrt.Intern("now")

var Lit_254 *jrt.String = jrt.Intern("lits")

var Lit_255 *jrt.String = jrt.Intern("atom")

var Lit_256 *jrt.String = jrt.Intern("lit-prefix")

var Lit_257 *jrt.String = jrt.Intern("ups")

var Lit_258 *jrt.String = jrt.Intern("lambdas")

var Lit_259 *jrt.String = jrt.Intern("cuts")

var Lit_260 *jrt.String = jrt.Intern("forms")

var Lit_261 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_262 *jrt.String = jrt.Intern("error")

var Lit_263 *jrt.String = jrt.Intern("println")

var Lit_264 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_265 *jrt.String = jrt.Intern("hash-map")

var Lit_266 *jrt.String = jrt.Intern("*pkgstate*")

var Lit_267 *jrt.String = jrt.Intern("*races*")

var Lit_268 *jrt.String = jrt.Intern("*out*")

var Lit_269 *jrt.String = jrt.Intern("races")

var Lit_270 *jrt.String = jrt.Intern("secs")

var Lit_271 *jrt.String = jrt.Intern("swap!")

var Lit_272 *jrt.String = jrt.Intern("reduce")

var Lit_273 *jrt.String = jrt.Intern("symbol")

var Lit_274 *jrt.String = jrt.Intern("sort-by")

var Lit_275 *jrt.String = jrt.Intern("val")

var Lit_276 *jrt.String = jrt.Intern("print")

var Lit_277 *jrt.String = jrt.Intern("take")

var Lit_278 *jrt.String = jrt.Intern("comp")

var Lit_279 *jrt.String = jrt.Intern("vector")

var Lit_280 *jrt.String = jrt.Intern("apart")

var Lit_281 *jrt.String = jrt.Intern("reflected?")

var Lit_282 *jrt.String = jrt.Intern("reflected-forms")

var Lit_283 *jrt.String = jrt.Intern("class-forms")

var Lit_284 *jrt.String = jrt.Intern("map-indexed")

var Lit_285 *jrt.String = jrt.Intern("merge-apart!")

var Lit_286 *jrt.String = jrt.Intern("class-registration")

var Lit_287 *jrt.String = jrt.Intern("sources")

var Lit_288 *jrt.String = jrt.Intern("reset!")

var Lit_289 *jrt.String = jrt.Intern("variant-files")

var Lit_290 *jrt.String = jrt.Intern("load-world")

var Lit_291 *jrt.String = jrt.Intern("variants")

var Lit_292 *jrt.String = jrt.Intern("replaced")

var Lit_293 *jrt.String = jrt.Intern("cut")

var Lit_294 *jrt.String = jrt.Intern("added")

var Lit_295 *jrt.String = jrt.Intern("scan")

var Lit_296 *jrt.String = jrt.Intern("manifest-classes")

var Lit_297 *jrt.String = jrt.Intern("compile-set")

var Lit_298 *jrt.String = jrt.Intern("update-in")

var Lit_299 *jrt.String = jrt.Intern("T")

var Lit_300 *jrt.String = jrt.Intern("vmethods-cache")

var Lit_301 *jrt.String = jrt.Intern("trivial-cache")

var Lit_302 *jrt.String = jrt.Intern("erased")

var Lit_303 *jrt.String = jrt.Intern("handles")

var Lit_304 *jrt.String = jrt.Intern("top-of")

var Lit_305 *jrt.String = jrt.Intern("run")

var Lit_306 *jrt.String = jrt.Intern("slice?")

var Lit_307 *jrt.String = jrt.Intern("standin-roots")

var Lit_308 *jrt.String = jrt.Intern("state")

var Lit_309 *jrt.String = jrt.Intern("fis")

var Lit_310 *jrt.String = jrt.Intern("subclass-index")

var Lit_311 *jrt.String = jrt.Intern("collisions")

var Lit_312 *jrt.String = jrt.Intern("pkg")

var Lit_313 *jrt.String = jrt.Intern("package-private-overrides")

var Lit_314 *jrt.String = jrt.Intern("method")

var Lit_315 *jrt.String = jrt.Intern("hidden-by")

var Lit_316 *jrt.String = jrt.Intern("race-report")

var Lit_317 *jrt.String = jrt.Intern("reached")

var Lit_318 *jrt.String = jrt.Intern("world")

var Lit_319 *jrt.String = jrt.Intern("frequencies")

var Lit_320 *jrt.String = jrt.Intern("methods-with-missing-parts")

var Lit_321 *jrt.String = jrt.Intern("unavailable")

var Lit_322 *jrt.String = jrt.Intern("translated")

var Lit_323 *jrt.String = jrt.Intern("replaced-standins")

var Lit_324 *jrt.String = jrt.Intern("missing")

var Lit_325 *jrt.String = jrt.Intern("analysis-failures")

var Lit_326 *jrt.String = jrt.Intern("failed")

var Lit_327 *jrt.String = jrt.Intern("errors")

var Lit_328 *jrt.String = jrt.Intern("race-candidates")

var Lit_329 *jrt.String = jrt.Intern("times")

var Lit_330 *jrt.String = jrt.Intern("unit")

var Lit_331 *jrt.String = jrt.Intern("sorted-map")

var Lit_332 *jrt.String = jrt.Intern("future-call")

var Lit_333 *jrt.String = jrt.Intern("reverse")

var Lit_334 *jrt.String = jrt.Intern("file-seq")

var Lit_335 *jrt.String = jrt.Intern("delete-file")

var Lit_336 *jrt.String = jrt.Intern("file-text")

var Lit_337 *jrt.String = jrt.Intern("group-by")

var Lit_338 *jrt.String = jrt.Intern("filter-standins*")

var Lit_339 *jrt.String = jrt.Intern("write!")

var Lit_340 *jrt.String = jrt.Intern("copy-file!")

var Lit_341 *jrt.String = jrt.Intern("form-text")

var Lit_342 *jrt.String = jrt.Intern("pkg-name")

var Lit_343 *jrt.String = jrt.Intern("embedded")

var Lit_344 *jrt.String = jrt.Intern("cut-candidates")

var Lit_345 *jrt.String = jrt.Intern("embedded-data")

var Lit_346 *jrt.String = jrt.Intern("data")

var Lit_347 *jrt.String = jrt.Intern("read-string")

var Lit_348 *jrt.String = jrt.Intern("slurp")

var Lit_349 *jrt.String = jrt.Intern("root")

var Lit_350 *jrt.String = jrt.Intern("tree")

var Lit_351 *jrt.String = jrt.Intern("dirs")

var Lit_352 *jrt.String = jrt.Intern("java/api")

var Lit_353 *jrt.String = jrt.Intern("fjp-support-class")

var Lit_354 *jrt.String = jrt.Intern("String_Format_String_O1__String")

var Lit_355 *jrt.String = jrt.Intern("String_Format_Locale_String_O1__String")

var Lit_356 *jrt.String = jrt.Intern("String")

var Lit_357 *jrt.String = jrt.Intern("Class")

var Lit_358 *jrt.String = jrt.Intern("vars")

var Lit_359 *jrt.String = jrt.Intern("System_in")

var Lit_360 *jrt.String = jrt.Intern("System_out")

var Lit_361 *jrt.String = jrt.Intern("System_err")

var Lit_362 *jrt.String = jrt.Intern("System_SetIn_InputStream__V")

var Lit_363 *jrt.String = jrt.Intern("System_SetOut_PrintStream__V")

var Lit_364 *jrt.String = jrt.Intern("System_SetErr_PrintStream__V")

var Lit_365 *jrt.String = jrt.Intern("string-regex-methods")

var Lit_366 *jrt.String = jrt.Intern("ForkJoinPool")

var Lit_367 *jrt.String = jrt.Intern("fjp-support-methods")

var Lit_368 *jrt.String = jrt.Intern("*compile-set*")

var Lit_369 *jrt.String = jrt.Intern("*from-source*")

var Lit_370 *jrt.String = jrt.Intern("from-source")

var Lit_371 *jrt.String = jrt.Intern("fields")

var Lit_372 *jrt.String = jrt.Intern("java/io/ByteArrayInputStream")

var Lit_373 *jrt.String = jrt.Intern("<init>")

var Lit_374 *jrt.String = jrt.Intern("([B)V")

var Lit_375 *jrt.String = jrt.Intern("jdk/internal/jrt/StandardStreams")

var Lit_376 *jrt.String = jrt.Intern("in")

var Lit_377 *jrt.String = jrt.Intern("()Ljava/io/InputStream;")

var Lit_378 *jrt.String = jrt.Intern("()Ljava/io/PrintStream;")

var Lit_379 *jrt.String = jrt.Intern("java/util/regex/Pattern")

var Lit_380 *jrt.String = jrt.Intern("compile")

var Lit_381 *jrt.String = jrt.Intern("(Ljava/lang/String;)Ljava/util/regex/Pattern;")

var Lit_382 *jrt.String = jrt.Intern("(Ljava/lang/CharSequence;I)[Ljava/lang/String;")

var Lit_383 *jrt.String = jrt.Intern("matcher")

var Lit_384 *jrt.String = jrt.Intern("(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;")

var Lit_385 *jrt.String = jrt.Intern("matches")

var Lit_386 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/CharSequence;)Z")

var Lit_387 *jrt.String = jrt.Intern("java/util/regex/Matcher")

var Lit_388 *jrt.String = jrt.Intern("replaceAll")

var Lit_389 *jrt.String = jrt.Intern("(Ljava/lang/String;)Ljava/lang/String;")

var Lit_390 *jrt.String = jrt.Intern("replaceFirst")

var Lit_391 *jrt.String = jrt.Intern("jdk/internal/jrt/CaseInsensitiveComparator")

var Lit_392 *jrt.String = jrt.Intern("<clinit>")

var Lit_393 *jrt.String = jrt.Intern("()V")

var Lit_394 *jrt.String = jrt.Intern("java/util/Optional")

var Lit_395 *jrt.String = jrt.Intern("of")

var Lit_396 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Ljava/util/Optional;")

var Lit_397 *jrt.String = jrt.Intern("java/util/ArrayList")

var Lit_398 *jrt.String = jrt.Intern("add")

var Lit_399 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_400 *jrt.String = jrt.Intern("java/util/Collection")

var Lit_401 *jrt.String = jrt.Intern("stream")

var Lit_402 *jrt.String = jrt.Intern("()Ljava/util/stream/Stream;")

var Lit_403 *jrt.String = jrt.Intern("java/io/PrintWriter")

var Lit_404 *jrt.String = jrt.Intern("(Ljava/lang/String;)V")

var Lit_405 *jrt.String = jrt.Intern("java/io/PrintStream")

var Lit_406 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_407 *jrt.String = jrt.Intern("put")

var Lit_408 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_409 *jrt.String = jrt.Intern("java/util/Collections")

var Lit_410 *jrt.String = jrt.Intern("unmodifiableMap")

var Lit_411 *jrt.String = jrt.Intern("(Ljava/util/Map;)Ljava/util/Map;")

var Lit_412 *jrt.String = jrt.Intern("java/util/Formatter")

var Lit_413 *jrt.String = jrt.Intern("(Ljava/util/Locale;)V")

var Lit_414 *jrt.String = jrt.Intern("format")

var Lit_415 *jrt.String = jrt.Intern("(Ljava/lang/String;[Ljava/lang/Object;)Ljava/util/Formatter;")

var Lit_416 *jrt.String = jrt.Intern("toString")

var Lit_417 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_418 *jrt.String = jrt.Intern("root-fn")

var Lit_419 *jrt.String = jrt.Intern("repl-visible?")

var Lit_420 *jrt.String = jrt.Intern("compiled-class?")

var Lit_421 *jrt.String = jrt.Intern("includes?")

var Lit_422 *jrt.String = jrt.Intern("api-class")

var Lit_423 *jrt.String = jrt.Intern("proxy-roots")

var Lit_424 *jrt.String = jrt.Intern("(Ljava/lang/String;)Ljava/lang/Process;")

var Lit_425 *jrt.String = jrt.Intern("(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;")

var Lit_426 *jrt.String = jrt.Intern("(Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;")

var Lit_427 *jrt.String = jrt.Intern("([Ljava/lang/String;)Ljava/lang/Process;")

var Lit_428 *jrt.String = jrt.Intern("([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;")

var Lit_429 *jrt.String = jrt.Intern("([Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;")

var Lit_430 *jrt.String = jrt.Intern("fjp-support-key")

var Lit_431 *jrt.String = jrt.Intern("translatable?")

var Lit_432 *jrt.String = jrt.Intern("make-subclass-index")

var Lit_433 *jrt.String = jrt.Intern("compiled-pkg?")

var Lit_434 *jrt.String = jrt.Intern("*absent-members*")

var Lit_435 *jrt.String = jrt.Intern("*reached*")

var Lit_436 *jrt.String = jrt.Intern("enabled?")

var Lit_437 *jrt.String = jrt.Intern("a2g_dyn.go")

var Lit_438 *jrt.String = jrt.Intern("a2g_cf.go")

var Lit_439 *jrt.String = jrt.Intern("translate-classes")

var Lit_440 *jrt.String = jrt.Intern("go-file-name")

var Lit_441 *jrt.String = jrt.Intern("source-top")

var Lit_442 *jrt.String = jrt.Intern("memoize")

var Lit_443 *jrt.String = jrt.Intern("a2g_fromfn.go")

var Lit_444 *jrt.String = jrt.Intern("adapter-forms")

var Lit_445 *jrt.String = jrt.Intern("adapters")

var Lit_446 *jrt.String = jrt.Intern("registrations")

var Lit_447 *jrt.String = jrt.Intern("support-table-forms")

var Lit_448 *jrt.String = jrt.Intern("frames-forms")

var Lit_449 *jrt.String = jrt.Intern("support-forms")

var Lit_450 *jrt.String = jrt.Intern("hand-written?")

var Lit_451 *jrt.String = jrt.Intern("types")

var Lit_452 *jrt.String = jrt.Intern("with-member-types")

var Lit_453 *jrt.String = jrt.Intern("in-world?")

var Lit_454 *jrt.String = jrt.Intern("cut-forms")

var Lit_455 *jrt.String = jrt.Intern("cut-table-forms")

var Lit_456 *jrt.String = jrt.Intern("trivial-init?")

var Lit_457 *jrt.String = jrt.Intern("lazy-standins")

var Lit_458 *jrt.String = jrt.Intern("strings-forms")

var Lit_459 *jrt.String = jrt.Intern("ups-forms")

var Lit_460 *jrt.String = jrt.Intern("packages")

var Lit_461 *jrt.String = jrt.Intern("overrides")

var Lit_462 *jrt.String = jrt.Intern("checks")

var Lit_463 *jrt.String = jrt.Intern("pprint")

var Lit_464 *jrt.String = jrt.Intern("*renames*")

var Lit_465 *jrt.String = jrt.Intern("texts")

var Lit_466 *jrt.String = jrt.Intern("generated")

var Lit_467 *jrt.String = jrt.Intern("every?")

var Lit_468 *jrt.String = jrt.Intern("hand-written")

var Lit_469 *jrt.String = jrt.Intern("after")

var Lit_470 *jrt.String = jrt.Intern("go.arbace.jrt")

var Lit_471 *jrt.String = jrt.Intern("test-files")

var Lit_472 *jrt.String = jrt.Intern("pkg-ns")

var Lit_473 *jrt.String = jrt.Intern("write-resources!")

var Lit_474 *jrt.String = jrt.Intern("(?m)^\\(ns( |$)")

var Lit_475 *jrt.String = jrt.Intern("generics-text")

var Lit_476 *jrt.String = jrt.Intern("program-package-forms")

var Lit_477 *jrt.String = jrt.Intern("program-main-forms")

var Lit_478 *jrt.String = jrt.Intern("image-forms")

var Lit_479 *jrt.String = jrt.Intern("rlwrap-forms")

var Lit_480 *jrt.String = jrt.Intern("image-type-forms")

var Lit_481 *jrt.String = jrt.Intern("image-types")

var Lit_482 *jrt.String = jrt.Intern("prog-dir")

var Lit_483 *jrt.String = jrt.Intern("reach")

var Lit_484 *jrt.String = jrt.Intern("translate")

var Lit_485 *jrt.String = jrt.Intern("write")

var Lit_486 *jrt.String = jrt.Intern("steps")

var Lit_487 *jrt.String = jrt.Intern("pr-str")

var Lit_488 *jrt.String = jrt.Intern("+")

var Lit_489 *jrt.String = jrt.Intern("count")

var Lit_490 *jrt.String = jrt.Intern("id-floor")

var Lit_491 *jrt.String = jrt.Intern("run*")

var Lit_492 *jrt.String = jrt.Intern("default-edge")

var Lit_493 *jrt.String = jrt.Intern("read-edge")

var Lit_494 *jrt.String = jrt.Intern("advance-ids!")

var Lit_495 *jrt.String = jrt.Intern("*recorded*")

var Lit_496 *jrt.String = jrt.Intern("*recording*")

var Lit_497 *jrt.String = jrt.Intern("write-edge!")

var Lit_498 *jrt.String = jrt.Intern("recorded-edge")

var Lit_499 *jrt.String = jrt.Intern("*declared*")

var Lit_500 *jrt.String = jrt.Intern("*edge*")

var Lit_501 *jrt.String = jrt.Intern("*source-lookup*")

var Lit_502 *jrt.String = jrt.Intern("parse-args")

var Lit_503 *jrt.String = jrt.Intern("shutdown-agents")

var Lit_504 *jrt.String = jrt.Intern("arbace.a2g.main$_main")

var Lit_505 *jrt.String = jrt.Intern("arbace.a2g.main$advance_ids_BANG_")

var Lit_506 *jrt.String = jrt.Intern("a2g: the runtime's id counter (")

var Lit_507 *jrt.String = jrt.Intern(") is at a2g's id-floor (")

var Lit_508 *jrt.String = jrt.Intern(") already: raise it (a2g's output then names its temporaries afresh)")

var Lit_509 *jrt.String = jrt.Intern("arbace.a2g.main$apart")

var Lit_510 *jrt.String = jrt.Intern("Lit?")

var Lit_511 *jrt.String = jrt.Intern("arbace.a2g.main$apart$fn__1844000199")

var Lit_512 *jrt.String = jrt.Intern("a2g: error in")

var Lit_513 *jrt.String = jrt.Intern(":")

var Lit_514 *jrt.String = jrt.Intern("A2G_TRACE")

var Lit_515 *jrt.String = jrt.Intern("arbace.a2g.main$copy_file_BANG_")

var Lit_516 *jrt.String = jrt.Intern("arbace.a2g.main$eval1844000004$loading__1927001464__auto____1844000005")

var Lit_517 *jrt.String = jrt.Intern("arbace.a2g.main$eval1844000008$fn__1844000009")

var Lit_518 *jrt.String = jrt.Intern("arbace.a2g.main$filter_init_body")

var Lit_519 *jrt.String = jrt.Intern("arbace.a2g.main$filter_init_body$fn__1844000115")

var Lit_520 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_")

var Lit_521 *jrt.String = jrt.Intern("|")

var Lit_522 *jrt.String = jrt.Intern("(")

var Lit_523 *jrt.String = jrt.Intern(")(_[A-Za-z0-9_]*)?")

var Lit_524 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$drop_QMARK___1844000121")

var Lit_525 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$fn__1844000119")

var Lit_526 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$group__1844000124")

var Lit_527 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$group__1844000124$fn__1844000131")

var Lit_528 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138")

var Lit_529 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138$fn__1844000139")

var Lit_530 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138$fn__1844000139$fn__1844000140")

var Lit_531 *jrt.String = jrt.Intern("arbace.a2g.main$form_names")

var Lit_532 *jrt.String = jrt.Intern("arbace.a2g.main$internal")

var Lit_533 *jrt.String = jrt.Intern(".")

var Lit_534 *jrt.String = jrt.Intern("/")

var Lit_535 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes")

var Lit_536 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000031__1844000035")

var Lit_537 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000031__1844000035$fn__1844000036")

var Lit_538 *jrt.String = jrt.Intern("_class")

var Lit_539 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000031__1844000035$fn__1844000036$fn__1844000037")

var Lit_540 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000041__1844000045")

var Lit_541 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000041__1844000045$fn__1844000046")

var Lit_542 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000041__1844000045$fn__1844000046$fn__1844000047")

var Lit_543 *jrt.String = jrt.Intern("arbace.a2g.main$manifest_classes")

var Lit_544 *jrt.String = jrt.Intern("manifest.edn")

var Lit_545 *jrt.String = jrt.Intern("arbace.a2g.main$manifest_classes$fn__1844000028")

var Lit_546 *jrt.String = jrt.Intern("arbace.a2g.main$mentions_QMARK_")

var Lit_547 *jrt.String = jrt.Intern("arbace.a2g.main$mentions_QMARK_$w__1844000108")

var Lit_548 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_")

var Lit_549 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$conj_all__1844000204")

var Lit_550 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$conj_all__1844000204$fn__1844000205")

var Lit_551 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$fn__1844000209")

var Lit_552 *jrt.String = jrt.Intern("Lit_")

var Lit_553 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$fn__1844000214")

var Lit_554 *jrt.String = jrt.Intern("arbace.a2g.main$method_recv_type")

var Lit_555 *jrt.String = jrt.Intern("arbace.a2g.main$now")

var Lit_556 *jrt.String = jrt.Intern("arbace.a2g.main$parse_args")

var Lit_557 *jrt.String = jrt.Intern(".tmp/a2g/out")

var Lit_558 *jrt.String = jrt.Intern("--jdk")

var Lit_559 *jrt.String = jrt.Intern("--edge")

var Lit_560 *jrt.String = jrt.Intern("--record-edge")

var Lit_561 *jrt.String = jrt.Intern("--program")

var Lit_562 *jrt.String = jrt.Intern("arbace.lang.Main#main")

var Lit_563 *jrt.String = jrt.Intern("--out")

var Lit_564 *jrt.String = jrt.Intern("--input")

var Lit_565 *jrt.String = jrt.Intern("--root")

var Lit_566 *jrt.String = jrt.Intern("--lang")

var Lit_567 *jrt.String = jrt.Intern("--jvm-reflection")

var Lit_568 *jrt.String = jrt.Intern("--main")

var Lit_569 *jrt.String = jrt.Intern("--slice")

var Lit_570 *jrt.String = jrt.Intern("--tests")

var Lit_571 *jrt.String = jrt.Intern("a2g: unknown option ")

var Lit_572 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms")

var Lit_573 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms$iter__1844000187__1844000191")

var Lit_574 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms$iter__1844000187__1844000191$fn__1844000192")

var Lit_575 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms$iter__1844000187__1844000191$fn__1844000192$fn__1844000193")

var Lit_576 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms")

var Lit_577 *jrt.String = jrt.Intern("arbace/cmd/arbace")

var Lit_578 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms$iter__1844000176__1844000180")

var Lit_579 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms$iter__1844000176__1844000180$fn__1844000181")

var Lit_580 *jrt.String = jrt.Intern("res/")

var Lit_581 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms$iter__1844000176__1844000180$fn__1844000181$fn__1844000182")

var Lit_582 *jrt.String = jrt.Intern("arbace.a2g.main$registrations")

var Lit_583 *jrt.String = jrt.Intern("arbace.a2g.main$registrations$fn__1844000251")

var Lit_584 *jrt.String = jrt.Intern("arbace.a2g.main$registrations$fn__1844000251$fn__1844000255")

var Lit_585 *jrt.String = jrt.Intern("arbace.a2g.main$registrations$fn__1844000258")

var Lit_586 *jrt.String = jrt.Intern("arbace.a2g.main$repl_visible_QMARK_")

var Lit_587 *jrt.String = jrt.Intern("arbace.a2g.main$repl_visible_QMARK_$fn__1844000058")

var Lit_588 *jrt.String = jrt.Intern("arbace.a2g.main$resource_file")

var Lit_589 *jrt.String = jrt.Intern(".z")

var Lit_590 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys")

var Lit_591 *jrt.String = jrt.Intern("$*")

var Lit_592 *jrt.String = jrt.Intern("a2g: root class not found: ")

var Lit_593 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$fn__1844000062")

var Lit_594 *jrt.String = jrt.Intern("$")

var Lit_595 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$iter__1844000067__1844000071")

var Lit_596 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$iter__1844000067__1844000071$fn__1844000072")

var Lit_597 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$iter__1844000067__1844000071$fn__1844000072$fn__1844000073")

var Lit_598 *jrt.String = jrt.Intern("arbace.a2g.main$run")

var Lit_599 *jrt.String = jrt.Intern("a2g: the edge of this run in ")

var Lit_600 *jrt.String = jrt.Intern(": ")

var Lit_601 *jrt.String = jrt.Intern(" classes")

var Lit_602 *jrt.String = jrt.Intern("a2g: no edge ")

var Lit_603 *jrt.String = jrt.Intern(" (bin/a2g-edge update, or --jvm-reflection)")

var Lit_604 *jrt.String = jrt.Intern("arbace.a2g.main$run$fn__1844000901")

var Lit_605 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_")

var Lit_606 *jrt.String = jrt.Intern("JRT_CONV")

var Lit_607 *jrt.String = jrt.Intern("jdk/forms")

var Lit_608 *jrt.String = jrt.Intern("/data")

var Lit_609 *jrt.String = jrt.Intern("arbace")

var Lit_610 *jrt.String = jrt.Intern("arbace/lang/go")

var Lit_611 *jrt.String = jrt.Intern("overlay/jdk/variants")

var Lit_612 *jrt.String = jrt.Intern(", ")

var Lit_613 *jrt.String = jrt.Intern(" failures")

var Lit_614 *jrt.String = jrt.Intern("go/arbace/jrt")

var Lit_615 *jrt.String = jrt.Intern("java/util/concurrent/ExecutorService")

var Lit_616 *jrt.String = jrt.Intern("Formatted_O1__String")

var Lit_617 *jrt.String = jrt.Intern("java/lang/Iterable")

var Lit_618 *jrt.String = jrt.Intern("String_Join_CharSequence_Iterable__String")

var Lit_619 *jrt.String = jrt.Intern("DescribeConstable__Optional")

var Lit_620 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream")

var Lit_621 *jrt.String = jrt.Intern("java/util/stream/Stream")

var Lit_622 *jrt.String = jrt.Intern("Lines__Stream")

var Lit_623 *jrt.String = jrt.Intern("String_CASE_INSENSITIVE_ORDER")

var Lit_624 *jrt.String = jrt.Intern("a2g: ")

var Lit_625 *jrt.String = jrt.Intern(" constant VarHandles, on ")

var Lit_626 *jrt.String = jrt.Intern(" fields")

var Lit_627 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_628 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_629 *jrt.String = jrt.Intern("/gen")

var Lit_630 *jrt.String = jrt.Intern("/prog")

var Lit_631 *jrt.String = jrt.Intern("a2g_classes.go")

var Lit_632 *jrt.String = jrt.Intern("a2g_cut.go")

var Lit_633 *jrt.String = jrt.Intern("a2g_init.go")

var Lit_634 *jrt.String = jrt.Intern("a2g_strings.go")

var Lit_635 *jrt.String = jrt.Intern("a2g_up.go")

var Lit_636 *jrt.String = jrt.Intern("/go/arbace/jrt.ae")

var Lit_637 *jrt.String = jrt.Intern("\n")

var Lit_638 *jrt.String = jrt.Intern("/go/arbace/")

var Lit_639 *jrt.String = jrt.Intern(".ae")

var Lit_640 *jrt.String = jrt.Intern("/program.edn")

var Lit_641 *jrt.String = jrt.Intern("{:module \"arbace\" :go \"1.27\"}\n")

var Lit_642 *jrt.String = jrt.Intern("/namespaces.txt")

var Lit_643 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res")

var Lit_644 *jrt.String = jrt.Intern("arbace/classes/generics.edn")

var Lit_645 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace.ae")

var Lit_646 *jrt.String = jrt.Intern(";; Generated by a2g --program (A2G-SPEC §10.6): the program's main package.\n")

var Lit_647 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res/.g2a-data")

var Lit_648 *jrt.String = jrt.Intern("The main package's embedded sources (a2g --program): data, not Go forms.\n")

var Lit_649 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/main.ae")

var Lit_650 *jrt.String = jrt.Intern(";; Generated by a2g --program (A2G-SPEC §10.6).\n(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_651 *jrt.String = jrt.Intern("\n\n")

var Lit_652 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.ae")

var Lit_653 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/")

var Lit_654 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image_types.ae")

var Lit_655 *jrt.String = jrt.Intern(";; Generated by a2g --program: the program's struct types, by name (EXEC-NOTES.md).\n")

var Lit_656 *jrt.String = jrt.Intern("(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_657 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.bin")

var Lit_658 *jrt.String = jrt.Intern("/report.edn")

var Lit_659 *jrt.String = jrt.Intern("a2g: steps (s): ")

var Lit_660 *jrt.String = jrt.Intern(" (")

var Lit_661 *jrt.String = jrt.Intern(" jobs)")

var Lit_662 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$clj_files__1844000302")

var Lit_663 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$clj_files__1844000302$fn__1844000303")

var Lit_664 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000306")

var Lit_665 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000308")

var Lit_666 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000314")

var Lit_667 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000322")

var Lit_668 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000332")

var Lit_669 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000337")

var Lit_670 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000367")

var Lit_671 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000368")

var Lit_672 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000370")

var Lit_673 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000372")

var Lit_674 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000372$fn__1844000373")

var Lit_675 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000387")

var Lit_676 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000389")

var Lit_677 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000391")

var Lit_678 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000393")

var Lit_679 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000395")

var Lit_680 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000397")

var Lit_681 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000399")

var Lit_682 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000424")

var Lit_683 *jrt.String = jrt.Intern("a2g_lambdas.go")

var Lit_684 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000426")

var Lit_685 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000432")

var Lit_686 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000437")

var Lit_687 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000446")

var Lit_688 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000448")

var Lit_689 *jrt.String = jrt.Intern("a2g_frames.go")

var Lit_690 *jrt.String = jrt.Intern("a2g_support.go")

var Lit_691 *jrt.String = jrt.Intern("reflect_tables_a2g.go")

var Lit_692 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000450")

var Lit_693 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000456")

var Lit_694 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000458")

var Lit_695 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000460")

var Lit_696 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000462")

var Lit_697 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000484")

var Lit_698 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000486")

var Lit_699 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000488")

var Lit_700 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000494")

var Lit_701 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000496")

var Lit_702 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000498")

var Lit_703 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000500")

var Lit_704 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000526")

var Lit_705 *jrt.String = jrt.Intern("Go name ")

var Lit_706 *jrt.String = jrt.Intern("declared more than once in ")

var Lit_707 *jrt.String = jrt.Intern("a2g: error: Go name ")

var Lit_708 *jrt.String = jrt.Intern(" declared more than once in package ")

var Lit_709 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000532")

var Lit_710 *jrt.String = jrt.Intern("package-private, redeclared by ")

var Lit_711 *jrt.String = jrt.Intern(" in another package (A2G-SPEC §4.4: rename table)")

var Lit_712 *jrt.String = jrt.Intern("a2g: error: package-private ")

var Lit_713 *jrt.String = jrt.Intern(" is redeclared by ")

var Lit_714 *jrt.String = jrt.Intern(" in another Java package; Go would override it")

var Lit_715 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000580")

var Lit_716 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000586")

var Lit_717 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000610")

var Lit_718 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000610$fn__1844000612")

var Lit_719 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000610$fn__1844000617")

var Lit_720 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000646")

var Lit_721 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000648")

var Lit_722 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000688")

var Lit_723 *jrt.String = jrt.Intern("/go/arbace/jrt/")

var Lit_724 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000726")

var Lit_725 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000734")

var Lit_726 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000740")

var Lit_727 *jrt.String = jrt.Intern("_test")

var Lit_728 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000742")

var Lit_729 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$go_names__1844000736")

var Lit_730 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$go_names__1844000736$fn__1844000737")

var Lit_731 *jrt.String = jrt.Intern(".go")

var Lit_732 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$in_slice_QMARK___1844000324")

var Lit_733 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$in_slice_QMARK___1844000324$fn__1844000325")

var Lit_734 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000282__1844000286")

var Lit_735 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000282__1844000286$fn__1844000287")

var Lit_736 *jrt.String = jrt.Intern("packages.edn")

var Lit_737 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000282__1844000286$fn__1844000287$fn__1844000288")

var Lit_738 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000292__1844000296")

var Lit_739 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000292__1844000296$fn__1844000297")

var Lit_740 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000292__1844000296$fn__1844000297$fn__1844000298")

var Lit_741 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000339__1844000343")

var Lit_742 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000339__1844000343$fn__1844000344")

var Lit_743 *jrt.String = jrt.Intern("exec")

var Lit_744 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000339__1844000343$fn__1844000344$fn__1844000345")

var Lit_745 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000351__1844000355")

var Lit_746 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000351__1844000355$fn__1844000356")

var Lit_747 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000351__1844000355$fn__1844000356$fn__1844000357")

var Lit_748 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000377__1844000381")

var Lit_749 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000377__1844000381$fn__1844000382")

var Lit_750 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000377__1844000381$fn__1844000382$fn__1844000383")

var Lit_751 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000401__1844000407")

var Lit_752 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408")

var Lit_753 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408$iter__1844000403__1844000412")

var Lit_754 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408$iter__1844000403__1844000412$fn__1844000413")

var Lit_755 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408$iter__1844000403__1844000412$fn__1844000413$fn__1844000414")

var Lit_756 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000464__1844000468")

var Lit_757 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000464__1844000468$fn__1844000469")

var Lit_758 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000464__1844000468$fn__1844000469$fn__1844000470")

var Lit_759 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000474__1844000478")

var Lit_760 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000474__1844000478$fn__1844000479")

var Lit_761 *jrt.String = jrt.Intern("_Init")

var Lit_762 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000474__1844000478$fn__1844000479$fn__1844000480")

var Lit_763 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000502__1844000506")

var Lit_764 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000502__1844000506$fn__1844000507")

var Lit_765 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000502__1844000506$fn__1844000507$fn__1844000508")

var Lit_766 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000512__1844000516")

var Lit_767 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000512__1844000516$fn__1844000517")

var Lit_768 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000512__1844000516$fn__1844000517$fn__1844000518")

var Lit_769 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000534__1844000538")

var Lit_770 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000534__1844000538$fn__1844000539")

var Lit_771 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000534__1844000538$fn__1844000539$fn__1844000540")

var Lit_772 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000588__1844000592")

var Lit_773 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000588__1844000592$fn__1844000593")

var Lit_774 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000588__1844000592$fn__1844000593$fn__1844000594")

var Lit_775 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000620__1844000624")

var Lit_776 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000620__1844000624$fn__1844000625")

var Lit_777 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000620__1844000624$fn__1844000625$fn__1844000626")

var Lit_778 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000650__1844000654")

var Lit_779 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655")

var Lit_780 *jrt.String = jrt.Intern("standin_")

var Lit_781 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000656")

var Lit_782 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000656$fn__1844000660")

var Lit_783 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000656$fn__1844000660$fn__1844000661")

var Lit_784 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000668")

var Lit_785 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000668$fn__1844000669")

var Lit_786 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000674__1844000678")

var Lit_787 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000674__1844000678$fn__1844000679")

var Lit_788 *jrt.String = jrt.Intern("_test.ae")

var Lit_789 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000674__1844000678$fn__1844000679$fn__1844000680")

var Lit_790 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000690__1844000694")

var Lit_791 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000690__1844000694$fn__1844000695")

var Lit_792 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000690__1844000694$fn__1844000695$fn__1844000696")

var Lit_793 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000706__1844000710")

var Lit_794 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000706__1844000710$fn__1844000711")

var Lit_795 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000706__1844000710$fn__1844000711$fn__1844000712")

var Lit_796 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000744__1844000748")

var Lit_797 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000744__1844000748$fn__1844000749")

var Lit_798 *jrt.String = jrt.Intern("jrt/")

var Lit_799 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000744__1844000748$fn__1844000749$fn__1844000750")

var Lit_800 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000758__1844000762")

var Lit_801 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000758__1844000762$fn__1844000763")

var Lit_802 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000758__1844000762$fn__1844000763$fn__1844000764")

var Lit_803 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000774__1844000778")

var Lit_804 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000774__1844000778$fn__1844000779")

var Lit_805 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000774__1844000778$fn__1844000779$fn__1844000780")

var Lit_806 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000784__1844000788")

var Lit_807 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000784__1844000788$fn__1844000789")

var Lit_808 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000784__1844000788$fn__1844000789$fn__1844000790")

var Lit_809 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000800__1844000804")

var Lit_810 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000800__1844000804$fn__1844000805")

var Lit_811 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000800__1844000804$fn__1844000805$fn__1844000806")

var Lit_812 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000810__1844000814")

var Lit_813 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000810__1844000814$fn__1844000815")

var Lit_814 *jrt.String = jrt.Intern("arbace/")

var Lit_815 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000810__1844000814$fn__1844000815$fn__1844000816")

var Lit_816 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000826__1844000830")

var Lit_817 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831")

var Lit_818 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831$fn__1844000832")

var Lit_819 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831$fn__1844000832$fn__1844000836")

var Lit_820 *jrt.String = jrt.Intern("UTF-8")

var Lit_821 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831$fn__1844000842")

var Lit_822 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000847__1844000851")

var Lit_823 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852")

var Lit_824 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852$fn__1844000853")

var Lit_825 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852$fn__1844000853$fn__1844000857")

var Lit_826 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852$fn__1844000863")

var Lit_827 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887")

var Lit_828 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888")

var Lit_829 *jrt.String = jrt.Intern(" ")

var Lit_830 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888$fn__1844000889")

var Lit_831 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$jrt_java_QMARK___1844000328")

var Lit_832 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544")

var Lit_833 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544$fn__1844000545")

var Lit_834 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000547__1844000551")

var Lit_835 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000547__1844000551$fn__1844000552")

var Lit_836 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000547__1844000551$fn__1844000552$fn__1844000553")

var Lit_837 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000563__1844000567")

var Lit_838 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000563__1844000567$fn__1844000568")

var Lit_839 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000563__1844000567$fn__1844000568$fn__1844000569")

var Lit_840 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$slice_QMARK___1844000349")

var Lit_841 *jrt.String = jrt.Intern("arbace.a2g.main$secs")

var Lit_842 *jrt.String = jrt.Intern("arbace.a2g.main$source_top")

var Lit_843 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots")

var Lit_844 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000078__1844000082")

var Lit_845 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000078__1844000082$fn__1844000083")

var Lit_846 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000078__1844000082$fn__1844000083$fn__1844000084")

var Lit_847 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094")

var Lit_848 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095")

var Lit_849 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096")

var Lit_850 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096$fn__1844000097")

var Lit_851 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096$fn__1844000097$fn__1844000098")

var Lit_852 *jrt.String = jrt.Intern("arbace.a2g.main$top_of")

var Lit_853 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes")

var Lit_854 *jrt.String = jrt.Intern("A2G_CLASS_TIMES")

var Lit_855 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000219")

var Lit_856 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000219$fn__1844000223")

var Lit_857 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000226")

var Lit_858 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000232")

var Lit_859 *jrt.String = jrt.Intern("a2g: class time")

var Lit_860 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000241")

var Lit_861 *jrt.String = jrt.Intern("arbace.a2g.main$write_BANG_")

var Lit_862 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_")

var Lit_863 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$fn__1844000149")

var Lit_864 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158")

var Lit_865 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159")

var Lit_866 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000160")

var Lit_867 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000160$fn__1844000164")

var Lit_868 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000170")

var Lit_869 *jrt.String = jrt.Intern("in-ns")

var Lit_870 *jrt.String = jrt.Intern("private")

var Lit_871 *jrt.String = jrt.Intern("arglists")

var Lit_872 *jrt.String = jrt.Intern("arbace/a2g/main.ae")

var Lit_873 *jrt.String = jrt.Intern("t0")

var Lit_874 *jrt.String = jrt.Intern("s")

var Lit_875 *jrt.String = jrt.Intern("dir")

var Lit_876 *jrt.String = jrt.Intern("The classes the jrt manifest declares (internal names).")

var Lit_877 *jrt.String = jrt.Intern("manifest")

var Lit_878 *jrt.String = jrt.Intern("jrt's classes: those its forms register (Define) and those its manifest declares.")

var Lit_879 *jrt.String = jrt.Intern("n")

var Lit_880 *jrt.String = jrt.Intern("Can the REPL name class n's public members (internal name)? Not when n is in a JDK module's\n  package that the module does not export (jdk.internal.misc, sun.nio.cs ...): the JVM refuses\n  such access from Clojure code (IllegalAccessError), so the Go build's REPL world does not root\n  them (A2G-SPEC §10.6; JRT-NOTES.md, \"The JDK's resource data\", amendment RD2). Classes of no\n  JDK module (Arbace's, jrt's own jdk.internal.jrt) are visible.")

var Lit_881 *jrt.String = jrt.Intern("spec")

var Lit_882 *jrt.String = jrt.Intern("Method keys of a root spec. CLASS$* is the class and every named class nested in it (the\n  whole of Compiler, say).")

var Lit_883 *jrt.String = jrt.Intern("java/util/Locale")

var Lit_884 *jrt.String = jrt.Intern("java/util/Locale$Category")

var Lit_885 *jrt.String = jrt.Intern("Replaced stand-ins initialized on first use like any translated class, not eagerly: jrt's\n  hand-written code (but its tests) reads none of their statics, and their initialization needs\n  much of the program initialized first (Locale's: its constants, the default locale from the\n  system properties; JRT-NOTES.md, \"Text and locales\").")

var Lit_886 *jrt.String = jrt.Intern("Roots for the translated classes that replace jrt's stand-ins: their static initializer\n  and the members the stand-in defined (jrt's code may use them).")

var Lit_887 *jrt.String = jrt.Intern("f")

var Lit_888 *jrt.String = jrt.Intern("Go identifiers a top-level form declares.")

var Lit_889 *jrt.String = jrt.Intern("form")

var Lit_890 *jrt.String = jrt.Intern("names-re")

var Lit_891 *jrt.String = jrt.Intern("own-re")

var Lit_892 *jrt.String = jrt.Intern("gs")

var Lit_893 *jrt.String = jrt.Intern("text")

var Lit_894 *jrt.String = jrt.Intern("from")

var Lit_895 *jrt.String = jrt.Intern("to")

var Lit_896 *jrt.String = jrt.Intern("p")

var Lit_897 *jrt.String = jrt.Intern("b")

var Lit_898 *jrt.String = jrt.Intern("bytes")

var Lit_899 *jrt.String = jrt.Intern("The embedded resource p (bytes b) as it is written: as p.z, zlib-compressed, when that saves\n  a quarter or more (the sources, generics.edn, tzdb.dat), else as it is; jrt's OSHost.Resource\n  inflates a p.z when asked for p (amendment SZ2). [name bytes].")

var Lit_900 *jrt.String = jrt.Intern("ps")

var Lit_901 *jrt.String = jrt.Intern("Writes the embedded resources ps ([path bytes-fn] in order) under dir, compressed in\n  parallel (resource-file), written in order. Returns the names written.")

var Lit_902 *jrt.String = jrt.Intern("The main package: main.go and the embedded sources (res/..., EVAL-NOTES.md, \"Loading\").")

var Lit_903 *jrt.String = jrt.Intern("main: first rlwrap for an interactive REPL (execRlwrap, which replaces the process when it\n  applies), then the system property arbace.version from arbaceVersion (when the link set it),\n  then jrt's host for the build's system (jrt.ProgramHost: OSHost, or the box's on TamaGo,\n  doc/go/BOX-NOTES.md),\n  then the command line as a String[], then arbace.lang.Main.main inside jrt.RunMain\n  (the thread main, uncaught exceptions printed as the JVM prints them, status 1), its status\n  the process's.")

var Lit_904 *jrt.String = jrt.Intern("top")

var Lit_905 *jrt.String = jrt.Intern("The name a Go file is named after (§4.3): in arbace/lang the class forms file of top-level\n  class top (FxClasses for the classes of FxClasses.ae, so that --line-file positions name\n  it), in jrt the class (its Java source path).")

var Lit_906 *jrt.String = jrt.Intern("catch?")

var Lit_907 *jrt.String = jrt.Intern("Runs f (forms of class n, the i-th of its kind, tag naming the kind) on its own, with the\n  effects the sequential run has on the package's state recorded rather than applied: its\n  literals named apart (Lit?<tag><i>_k, in first-use order), what it conj'ed into the\n  package's ups, lambdas and cuts and into the races, in order, and its printed output. With\n  catch?, an exception is the result's :error [n message] (a translation's), else it is\n  thrown.")

var Lit_908 *jrt.String = jrt.Intern("renames")

var Lit_909 *jrt.String = jrt.Intern("Applies to the package state ps (and c/*races*) what result r of apart recorded, as the\n  sequential run would have done it: its printed output, its conj's replayed one by one, its\n  literals named in the package's pool (Lit_n, numbered in order of first use; one an earlier\n  class used keeps its name). Returns renames with r's literals' renames added.")

var Lit_910 *jrt.String = jrt.Intern("file-of")

var Lit_911 *jrt.String = jrt.Intern("cost-of")

var Lit_912 *jrt.String = jrt.Intern("pkgstates")

var Lit_913 *jrt.String = jrt.Intern("Translates the classes ns (in order) in parallel (jobs threads), each apart, and merges what\n  each did, in their order, as the sequential translation would have done it class after\n  class (merge-apart!): the forms into files ([pkg go-file] -> forms; file-of gives a\n  class's), its errors into errors. cost-of estimates a class's translation time (the\n  costliest start first). Returns the renames of the classes' literals (out/*renames*).")

var Lit_914 *jrt.String = jrt.Intern("The forms of a2g_classes.go of package pkg (out/class-registration of each class, in order),\n  the classes in parallel, each apart, merged in order into the package state ps (as\n  translate-classes). Returns [forms renames].")

var Lit_915 *jrt.String = jrt.Intern("opts")

var Lit_916 *jrt.String = jrt.Intern("a2g's run, in the class environment run binds.")

var Lit_917 *jrt.String = jrt.Intern("Where the runtime's id counter (RT/nextID, gensym's) stands when a2g's run starts. The\n  analyzer and the translator name temporaries by it (arr_100417), so a2g first advances it to\n  this fixed value: its output then depends on its inputs, not on how much code the running\n  Arbace compiled before (a2g's own namespaces load from source, and on the Go executable in\n  other amounts than on the JVM). A round value well above what loading a2g takes\n  (doc/STANDALONE-NOTES.md, SA13).")

var Lit_918 *jrt.String = jrt.Intern("Advances the runtime's id counter to id-floor (an error when it is past it already).")

var Lit_919 *jrt.String = jrt.Intern("a2g's run (bin/a2g's options as parse-args gives them). The classes outside the forms come\n  from the edge (--edge, default jdk/edge.edn: doc/STANDALONE-NOTES.md, S2), without the JVM's\n  reflection or ASM; --record-edge FILE: from the JVM's reflection, writing the edge of what\n  this run asked into FILE; --jvm-reflection: from the JVM's reflection (the edge unused).")

var Lit_920 *jrt.String = jrt.Intern("-main")

var Lit_921 *jrt.String = jrt.Intern("&")

var Lit_922 *jrt.String = jrt.Intern("jdk/edge.edn")
