//line a2g_strings.ae:1
package aot_arbace_a2g_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.a2g.worldyn1,wyn14,arbace.a2g.jrtyn3,jrtyn16,arbace.a2g.modelyn1,myn16,arbace.a2g.namesyn2,nmyn16,arbace.a2g.reachyn1,ryn17,arbace.a2g.accessyn3,accyn15,arbace.a2g.codeyn1,cyn13,arbace.a2g.vhyn2,vhyn16,arbace.a2g.declsyn1,dyn14,arbace.a2g.outyn3,outyn14,arbace.a2g.dynyn3,dynyn16,arbace.a2g.dyncfyn5,dyncfyn17,arbace.a2g.fromfnyn6,fromfnyn17,arbace.a2g.checksyn3,chkyn16,arbace.a2g.embedyn5,embedyn15,arbace.a2g.edgeyn4,edgeyn15,arbace.a2g.zlibyn4,zlibyn16,arbace.g2a.printyn2,gpyn11,arbace.corekn3,dockn3,outkn5,slicekn5,rootskn6,inputskn3,jdkkn5,mainskn11,record-edgekn7,programkn4,edgekn4,langkn5,testskn14,jvm-reflectionkn5,awaitkn2,gokn3,varkn7,standinkn4,filekn7,classeskn10,unexportedys14,arbace.a2g.jvm11,unexported?kn5,orderkn4,namekn5,flagskn4,desckn7,methodskn11,jrt-classeskn5,funcskn4,elsekn5,fileskn3,tagyn1,*yn4,inityn2,nsyn20,go.arbace.cmd.arbacekn7,requireyn9,arbace.goyn2,gokn4,linekn6,columnyn4,loadys2,go7,packageyn4,mainkn4,pathkn11,embed-filesys2,go3,varks2,go5,embedys5,embed2,FSyn6,stringys2,go4,funcyn10,execRlwrapyn4,whenyn2,!=yn13,arbaceVersionys3,jrt40,System_SetProperty_String_String__Stringys3,jrt3,Stryn3,letyn6,valuesyn3,subyn3,errys2,fs3,Subyn9,resourcesyn2,==ys3,jrt7,SetHostys3,jrt11,ProgramHostyn10,setupImageyn9,imageDatayn4,argsys3,jrt11,NewRefArrayys3,jrt12,String_classyn4,convyn5,int32yn1,-yn3,lenys2,os4,Argsyn5,rangeyn1,iyn8,subsliceyn4,asetyn3,.-Ayn6,statusys3,jrt7,RunMainyn2,fnys4,lang20,Main_Main_String1__Vyn11,finishImageys2,os4,Exitys2,go4,filekn7,importsyn2,fsyn2,osyn4,langyn1,_kn9,source-ofkn3,jrtkn4,litskn10,lit-prefixkn3,upskn7,lambdaskn4,cutskn5,formskn5,errorkn5,raceskn4,secsys3,a2g9,code-declyn7,a2gCodeyn5,sliceyn3,lityn14,a2gCodeDefinedyn4,boolkn13,variant-fileskn8,variantskn8,replacedkn3,cutkn5,addedkn11,compile-setkn1,Tkn14,vmethods-cachekn13,trivial-cachekn6,erasedkn2,vhkn6,slice?kn5,statekn3,fiskn14,subclass-indexkn3,pkgkn7,sourceskn6,methodkn9,hidden-bykn7,reachedkn5,worldkn26,methods-with-missing-partskn11,unavailablekn10,translatedkn17,replaced-standinskn7,missingkn17,analysis-failureskn6,failedkn6,errorskn15,race-candidateskn25,package-private-overrideskn5,timeskn4,unitkn8,embeddedkn14,cut-candidateskn13,embedded-datakn4,rootkn4,treekn4,dirskn11,late-inputskn4,waitkn4,varskn11,from-sourcekn7,handleskn6,fieldskn7,root-fnkn3,dynkn6,fromfnkn8,adapterskn13,registrationskn5,typeskn8,packageskn10,collisionskn9,overrideskn6,checksks15,arbace.a2g.main5,timeskn5,textskn9,generatedkn12,hand-writtenkn5,afteryn13,go.arbace.jrtkn10,test-fileskn9,resourceskn11,image-typeskn8,prog-dirkn3,reskn4,loadkn5,reachkn9,translatekn5,writekn5,stepsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,V3,R19,R1,R20,V3,R21,R1,R22,V3,R23,R1,R24,V3,R25,R1,R26,V3,R27,R1,R28,V3,R29,R1,R30,V3,R31,R1,R32,V3,R33,R1,R34,V3,R35,R1,R36,V3,R37,R1,R38,V3,R39,R1,R40,V3,R41,R1,R42,V3,R43,R1,R44,V3,R45,R1,R46,v11,arbace.core5,referR47,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.a2g.mainm2,R48,s2985,bin/a2g: class forms to Go forms (doc/go/A2G-SPEC.md, doc/go/A2G-NOTES.md).\n\n  bin/a2g [OPTIONS]\n    --out DIR          output directory (default .tmp/a2g/out): DIR/gen/go/... the generated\n                       forms (A2G-SPEC §4.3: the files a2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/g2a build; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of class forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.aot, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (a2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts a2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (A2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       a2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/g2a build --line-file DIR/prog\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): a2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/a2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)v11,arbace.core13,*loaded-libs*v11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,nextR49,R50,R51,R52,v11,arbace.core7,ex-infov11,arbace.core4,restv11,arbace.core5,assocR53,v11,arbace.core6,updateR54,v11,arbace.core4,fnilR55,R56,R57,v11,arbace.core10,re-patternR58,R59,R60,R61,v13,arbace.string7,replacev14,arbace.java.io4,filev11,arbace.core3,setv11,arbace.core3,mapv15,arbace.a2g.main8,internalv11,arbace.core3,strv11,arbace.core4,keysv16,arbace.a2g.world10,read-formsv11,arbace.core5,mergev11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR62,v16,arbace.a2g.names13,go-class-nameR63,R64,R65,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restR66,v11,arbace.core4,subsc47,c46,v11,arbace.core3,notl0,v15,arbace.a2g.edge4,jvm?R67,v11,arbace.core17,requiring-resolveR68,v13,arbace.string10,ends-with?v11,arbace.core6,mapcatv13,arbace.string5,splitv22,arbace.classes.analyze4,declv11,arbace.core6,concatv15,arbace.a2g.main9,root-keysv11,arbace.core6,filterv13,arbace.string12,starts-with?v11,arbace.core7,re-findp4,\\$\\dR69,v22,arbace.classes.analyze6,*unit*p1,#l2,R70,v16,arbace.a2g.model4,has?R71,l1,R72,R73,R74,v16,arbace.a2g.model3,*w*v16,arbace.a2g.model7,go-namev11,arbace.core6,get-inR75,v16,arbace.a2g.names8,new-namev16,arbace.a2g.model7,static?v16,arbace.a2g.names11,method-baseR76,v11,arbace.core9,contains?v22,arbace.classes.analyze14,ctor-real-descR77,v11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core6,secondR78,R79,v11,arbace.core7,vector?v11,arbace.core4,dropv11,arbace.core9,volatile!v11,arbace.core10,re-matchesv11,arbace.core7,vreset!v11,arbace.core5,coll?v11,arbace.core4,run!v11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core6,removev15,arbace.a2g.main9,mentions?v11,arbace.core6,empty?v13,arbace.string4,joinv11,arbace.core5,some?S4,s4,funcs3,vars5,consts4,typev11,arbace.core4,not=v15,arbace.a2g.main16,method-recv-typev15,arbace.a2g.main10,form-namesS3,s3,vars5,consts4,typev11,arbace.core4,somev11,arbace.core7,string?v11,arbace.core3,vecR80,v15,arbace.a2g.main16,filter-init-bodyv11,arbace.core4,spitv14,arbace.java.io12,make-parentsv14,arbace.java.io4,copyv15,arbace.a2g.zlib7,deflatev16,arbace.a2g.model8,par-mapvv11,arbace.core5,doallv16,arbace.a2g.model4,jobsv15,arbace.a2g.main13,resource-fileML3,R81,R82,ML2,R83,V3,R84,R1,R85,m4,R86,i263,R87,i30,m4,R86,i263,R87,i5,ML2,R88,s12,arbace/imagem4,R86,i266,R87,i5,ML2,R88,s18,arbace/image_typesm4,R86,i267,R87,i5,ML2,R88,s11,arbace/mainm4,R86,i268,R87,i5,ML2,R88,s19,arbace/rlwrap_linuxm4,R86,i269,R87,i5,ML2,R88,s19,arbace/rlwrap_otherm4,R86,i270,R87,i5,R89,R90,R91,V5,s8,image.gos14,image_types.gos7,main.gos15,rlwrap_linux.gos15,rlwrap_other.goR92,V2,s9,image.binnML2,R93,Myn9,resourcesm6,R94,V1,s3,resR78,R95,R48,s80,resources are the namespaces' sources RT.load reads (EVAL-NOTES.md, \"Loading\").\nm4,R86,i285,R87,i5,ML2,R93,Myn9,imageDatam6,R94,V1,s9,image.binR78,R96,R48,s118,imageData is the image of prepared namespaces (EXEC-NOTES.md; image.go): empty until bin/arbace-go --build writes it.\nm4,R86,i288,R87,i5,ML2,R93,Myn13,arbaceVersionm4,R78,R96,R48,s205,arbaceVersion is Arbace's version, the map *arbace-version* reads from the system property arbace.version: empty in a2g's output, set by bin/arbace-go's link (go build -ldflags -X main.arbaceVersion=...).\nm4,R86,i291,R87,i5,ML8,R97,R90,V0,ML1,R98,m4,R86,i295,R87,i7,ML3,R99,ML3,R100,R101,s0,m4,R86,i296,R87,i13,ML3,R102,ML2,R103,s14,arbace.versionm4,R86,i297,R87,i55,ML2,R103,R101,m4,R86,i297,R87,i82,m4,R86,i297,R87,i9,m4,R86,i296,R87,i7,ML3,R104,V2,ML3,R105,R106,R107,m4,R86,i298,R87,i13,ML3,R108,R109,s3,resm4,R86,i298,R87,i30,ML3,R99,ML3,R110,R107,nm4,R86,i299,R87,i15,ML2,R111,ML2,R112,R106,m4,R86,i300,R87,i24,m4,R86,i300,R87,i11,m4,R86,i299,R87,i9,m4,R86,i298,R87,i7,ML2,R113,R114,m4,R86,i301,R87,i7,ML4,R104,V2,R115,ML3,R116,R117,ML3,R118,R119,ML3,R120,ML2,R121,R122,m4,R86,i302,R87,i67,l1,m4,R86,i302,R87,i64,m4,R86,i302,R87,i52,m4,R86,i302,R87,i18,ML3,R123,V3,R124,R10,ML3,R125,R122,l1,m4,R86,i303,R87,i21,ML4,R126,ML2,R127,R115,m4,R86,i304,R87,i17,R124,ML2,R103,R10,m4,R86,i304,R87,i30,m4,R86,i304,R87,i11,m4,R86,i303,R87,i9,ML4,R104,V2,R128,ML2,R129,ML3,R130,V0,ML2,R131,R115,m4,R86,i305,R87,i42,m4,R86,i305,R87,i35,m4,R86,i305,R87,i22,ML1,R132,m4,R86,i306,R87,i11,ML2,R133,R128,m4,R86,i307,R87,i11,m4,R86,i305,R87,i9,m4,R86,i302,R87,i7,m4,R86,i294,R87,i5,R134,R135,V5,V2,R40,s5,embedV2,R136,s5,io/fsV2,R137,s2,osV2,R14,s10,arbace/jrtV2,R138,s11,arbace/langR139,v16,arbace.a2g.names8,pkg-pathv11,arbace.core7,keywordv11,arbace.core4,sortv11,arbace.core8,distinctv11,arbace.core4,valsv16,arbace.a2g.names17,compiled-packagesR140,R141,v15,arbace.a2g.main3,nowR142,v11,arbace.core4,atomR143,R144,R145,R146,R147,v11,arbace.core19,pop-thread-bindingsR148,v11,arbace.core7,printlnv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv15,arbace.a2g.code10,*pkgstate*v15,arbace.a2g.code7,*races*v11,arbace.core5,*out*R149,R150,v15,arbace.a2g.main4,secsv11,arbace.core5,swap!v11,arbace.core6,reducev11,arbace.core6,symbolv11,arbace.core7,sort-byv11,arbace.core3,valv11,arbace.core5,printv11,arbace.core4,takel25,v11,arbace.core4,compv11,arbace.core1,-v11,arbace.core6,vectorv15,arbace.a2g.main5,apartv16,arbace.a2g.model10,reflected?v16,arbace.a2g.decls15,reflected-formsv16,arbace.a2g.decls11,class-formsv11,arbace.core11,map-indexedv11,arbace.core5,rangev15,arbace.a2g.main12,merge-apart!R151,v16,arbace.a2g.model7,jrt-symv14,arbace.a2g.out18,class-registrationR93,v11,arbace.core9,with-metaR152,R153,R154,R153,R93,R155,m2,R78,R156,R152,R97,R80,R152,v11,arbace.core6,pr-strv11,arbace.core4,map?v16,arbace.a2g.embed7,sourcesv11,arbace.core6,reset!v11,arbace.core11,read-stringv11,arbace.core5,slurpR157,v16,arbace.a2g.world10,load-worldR158,R159,R160,R161,v14,arbace.a2g.jrt4,scanv15,arbace.a2g.main16,manifest-classesv15,arbace.a2g.main11,jrt-classesR162,v11,arbace.core9,update-inR163,R164,R165,R166,R167,v13,arbace.a2g.vh7,handlesv15,arbace.a2g.main6,top-ofv16,arbace.a2g.reach3,runR168,v15,arbace.a2g.main13,standin-rootsR169,R170,v17,arbace.a2g.fromfn3,fisR171,v17,arbace.a2g.checks10,collisionsR172,R173,v17,arbace.a2g.checks25,package-private-overridesR174,R175,v17,arbace.a2g.checks11,race-reportR176,R177,v11,arbace.core11,frequenciesR178,R179,R180,R181,R182,R183,R184,R185,R186,R187,R188,v16,arbace.a2g.model3,pkgR189,v11,arbace.core10,sorted-mapv11,arbace.core11,future-callv11,arbace.core7,reversev11,arbace.core8,file-seqv14,arbace.java.io11,delete-filev14,arbace.a2g.out9,file-textv11,arbace.core8,group-byv15,arbace.a2g.main16,filter-standins*v15,arbace.a2g.main6,write!v15,arbace.a2g.main10,copy-file!v16,arbace.g2a.print10,read-formsv14,arbace.a2g.out9,form-textv16,arbace.a2g.names8,pkg-nameR190,R191,R192,v16,arbace.a2g.embed4,datav16,arbace.a2g.embed14,cut-candidatesR193,R194,R195,V2,s4,langs8,java/apiV1,s4,langR196,R197,v14,arbace.a2g.out17,fjp-support-classV2,s31,String_Format_String_O1__Strings38,String_Format_Locale_String_O1__StringV2,R73,s6,StringV2,R73,s6,StringV2,R73,s5,ClassV2,R73,s6,StringR198,V3,s9,System_ins10,System_outs10,System_errV3,s27,System_SetIn_InputStream__Vs28,System_SetOut_PrintStream__Vs28,System_SetErr_PrintStream__VV2,R73,s6,Stringv14,arbace.a2g.out20,string-regex-methodsV2,R73,s12,ForkJoinPoolv14,arbace.a2g.out19,fjp-support-methodsv18,arbace.classes.env13,*compile-set*v18,arbace.classes.env13,*from-source*R199,R200,R201,v17,arbace.a2g.fromfn5,rootsV1,V3,s28,java/io/ByteArrayInputStreams6,<init>s5,([B)VV3,V3,s32,jdk/internal/jrt/StandardStreamss2,ins23,()Ljava/io/InputStream;V3,s32,jdk/internal/jrt/StandardStreamss3,outs23,()Ljava/io/PrintStream;V3,s32,jdk/internal/jrt/StandardStreamss3,errs23,()Ljava/io/PrintStream;V6,V3,s23,java/util/regex/Patterns7,compiles45,(Ljava/lang/String;)Ljava/util/regex/Pattern;V3,s23,java/util/regex/Patterns5,splits46,(Ljava/lang/CharSequence;I)[Ljava/lang/String;V3,s23,java/util/regex/Patterns7,matchers51,(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;V3,s23,java/util/regex/Patterns7,matchess45,(Ljava/lang/String;Ljava/lang/CharSequence;)ZV3,s23,java/util/regex/Matchers10,replaceAlls38,(Ljava/lang/String;)Ljava/lang/String;V3,s23,java/util/regex/Matchers12,replaceFirsts38,(Ljava/lang/String;)Ljava/lang/String;V1,V3,s42,jdk/internal/jrt/CaseInsensitiveComparators8,<clinit>s3,()VV1,V3,s18,java/util/Optionals2,ofs40,(Ljava/lang/Object;)Ljava/util/Optional;V3,V3,s19,java/util/ArrayLists6,<init>s3,()VV3,s19,java/util/ArrayLists3,adds21,(Ljava/lang/Object;)ZV3,s20,java/util/Collections6,streams27,()Ljava/util/stream/Stream;V1,V3,s19,java/io/PrintWriters5,prints21,(Ljava/lang/String;)VV1,V3,s19,java/io/PrintStreams5,prints21,(Ljava/lang/String;)VV3,V3,s17,java/util/HashMaps6,<init>s3,()VV3,s17,java/util/HashMaps3,puts56,(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;V3,s21,java/util/Collectionss15,unmodifiableMaps32,(Ljava/util/Map;)Ljava/util/Map;V4,V3,s19,java/util/Formatters6,<init>s3,()VV3,s19,java/util/Formatters6,<init>s21,(Ljava/util/Locale;)VV3,s19,java/util/Formatters6,formats60,(Ljava/lang/String;[Ljava/lang/Object;)Ljava/util/Formatter;V3,s19,java/util/Formatters8,toStrings20,()Ljava/lang/String;R202,v15,arbace.a2g.main13,repl-visible?v16,arbace.a2g.names15,compiled-class?v13,arbace.string9,includes?v14,arbace.a2g.dyn9,api-classv14,arbace.a2g.dyn5,rootsv14,arbace.a2g.dyn11,proxy-rootsV6,s39,(Ljava/lang/String;)Ljava/lang/Process;s58,(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s72,(Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;s40,([Ljava/lang/String;)Ljava/lang/Process;s59,([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s73,([Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;v14,arbace.a2g.out15,fjp-support-keyv16,arbace.a2g.model13,translatable?v16,arbace.a2g.model19,make-subclass-indexV2,R141,R58,v16,arbace.a2g.names13,compiled-pkg?v14,arbace.a2g.out16,*absent-members*v16,arbace.a2g.decls9,*reached*v14,arbace.a2g.dyn8,enabled?V2,R58,s10,a2g_dyn.gov14,arbace.a2g.dyn5,formsv16,arbace.a2g.dyncf8,enabled?V2,R58,s9,a2g_cf.gov16,arbace.a2g.dyncf5,formsv15,arbace.a2g.main17,translate-classesv14,arbace.a2g.out12,go-file-namev15,arbace.a2g.main10,source-topv11,arbace.core7,memoizeR203,V2,R58,s13,a2g_fromfn.gov17,arbace.a2g.fromfn5,formsR204,v14,arbace.a2g.out13,adapter-formsR205,v15,arbace.a2g.main13,registrationsR206,v14,arbace.a2g.out19,support-table-formsv14,arbace.a2g.out12,frames-formsv14,arbace.a2g.out13,support-formsv16,arbace.a2g.model13,hand-written?R207,v16,arbace.a2g.embed17,with-member-typesv16,arbace.a2g.model9,in-world?v14,arbace.a2g.out9,cut-formsv14,arbace.a2g.out15,cut-table-formsv16,arbace.a2g.model13,trivial-init?v15,arbace.a2g.main13,lazy-standinsR97,R80,v14,arbace.a2g.out13,strings-formsv14,arbace.a2g.out9,ups-formsR208,R209,R210,R211,v15,arbace.a2g.main10,report-strR212,v14,arbace.a2g.out9,*renames*R213,R214,v11,arbace.core6,every?R215,R216,ML3,R81,R217,ML2,R83,V3,R84,R1,R85,m4,R86,i817,R87,i60,m4,R86,i817,R87,i42,R89,R14,R218,R88,R81,ML2,R83,V3,R84,R1,R85,m4,R86,i828,R87,i79,v16,arbace.a2g.names6,pkg-nsR89,R88,v15,arbace.a2g.main16,write-resources!p14,(?m)^\\(ns( |$)v16,arbace.a2g.dyncf13,generics-textR219,v15,arbace.a2g.main21,program-package-formsv15,arbace.a2g.main18,program-main-formsv16,arbace.a2g.embed11,image-formsv16,arbace.a2g.embed12,rlwrap-formsv16,arbace.a2g.embed16,image-type-formsR220,R221,R222,R223,R224,R225,R226,R227,v11,arbace.core1,+v11,arbace.core5,countv15,arbace.a2g.main8,id-floorv15,arbace.a2g.main4,run*v15,arbace.a2g.main12,default-edgev15,arbace.a2g.edge9,read-edgev15,arbace.a2g.main12,advance-ids!v18,arbace.classes.env10,*recorded*v15,arbace.a2g.edge11,*recording*v15,arbace.a2g.edge11,write-edge!v15,arbace.a2g.edge13,recorded-edgev18,arbace.classes.env10,*declared*v15,arbace.a2g.edge6,*edge*v22,arbace.classes.analyze15,*source-lookup*v15,arbace.a2g.main10,parse-argsv15,arbace.a2g.main3,runv11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("a2g: the runtime's id counter (")

var Lit_2 *jrt.String = jrt.Intern(") is at a2g's id-floor (")

var Lit_3 *jrt.String = jrt.Intern(") already: raise it (a2g's output then names its temporaries afresh)")

var Lit_4 *jrt.String = jrt.Intern("Lit?")

var Lit_5 *jrt.String = jrt.Intern("_")

var Lit_6 *jrt.String = jrt.Intern("arbace.a2g.main$apart$fn__1844000199")

var Lit_7 *jrt.String = jrt.Intern("a2g: error in")

var Lit_8 *jrt.String = jrt.Intern(":")

var Lit_9 *jrt.String = jrt.Intern("A2G_TRACE")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.main$filter_init_body$fn__1844000115")

var Lit_11 *jrt.String = jrt.Intern("|")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$fn__1844000119")

var Lit_13 *jrt.String = jrt.Intern("(")

var Lit_14 *jrt.String = jrt.Intern(")(_[A-Za-z0-9_]*)?")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$drop_QMARK___1844000121")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$group__1844000124")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138")

var Lit_18 *jrt.String = jrt.Intern("method")

var Lit_19 *jrt.String = jrt.Intern("init")

var Lit_20 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$group__1844000124$fn__1844000131")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138$fn__1844000139")

var Lit_22 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138$fn__1844000139$fn__1844000140")

var Lit_23 *jrt.String = jrt.Intern("func")

var Lit_24 *jrt.String = jrt.Intern("type")

var Lit_25 *jrt.String = jrt.Intern("var")

var Lit_26 *jrt.String = jrt.Intern(".")

var Lit_27 *jrt.String = jrt.Intern("/")

var Lit_28 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000031__1844000035")

var Lit_29 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000041__1844000045")

var Lit_30 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000031__1844000035$fn__1844000036")

var Lit_31 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000031__1844000035$fn__1844000036$fn__1844000037")

var Lit_32 *jrt.String = jrt.Intern("_class")

var Lit_33 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000041__1844000045$fn__1844000046")

var Lit_34 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes$iter__1844000041__1844000045$fn__1844000046$fn__1844000047")

var Lit_35 *jrt.String = jrt.Intern("manifest.edn")

var Lit_36 *jrt.String = jrt.Intern("arbace.a2g.main$manifest_classes$fn__1844000028")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.main$mentions_QMARK_$w__1844000108")

var Lit_38 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$conj_all__1844000204")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$fn__1844000209")

var Lit_40 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$fn__1844000214")

var Lit_41 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_$conj_all__1844000204$fn__1844000205")

var Lit_42 *jrt.String = jrt.Intern("Lit_")

var Lit_43 *jrt.String = jrt.Intern(".tmp/a2g/out")

var Lit_44 *jrt.String = jrt.Intern("--jdk")

var Lit_45 *jrt.String = jrt.Intern("--main")

var Lit_46 *jrt.String = jrt.Intern("--out")

var Lit_47 *jrt.String = jrt.Intern("--record-edge")

var Lit_48 *jrt.String = jrt.Intern("--program")

var Lit_49 *jrt.String = jrt.Intern("arbace.lang.Main#main")

var Lit_50 *jrt.String = jrt.Intern("--edge")

var Lit_51 *jrt.String = jrt.Intern("--root")

var Lit_52 *jrt.String = jrt.Intern("--slice")

var Lit_53 *jrt.String = jrt.Intern("--lang")

var Lit_54 *jrt.String = jrt.Intern("--tests")

var Lit_55 *jrt.String = jrt.Intern("--input")

var Lit_56 *jrt.String = jrt.Intern("--jvm-reflection")

var Lit_57 *jrt.String = jrt.Intern("--await")

var Lit_58 *jrt.String = jrt.Intern("a2g: unknown option ")

var Lit_59 *jrt.String = jrt.Intern("main.go")

var Lit_60 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms$iter__1844000187__1844000191")

var Lit_61 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms$iter__1844000187__1844000191$fn__1844000192")

var Lit_62 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms$iter__1844000187__1844000191$fn__1844000192$fn__1844000193")

var Lit_63 *jrt.String = jrt.Intern("arbace/cmd/arbace")

var Lit_64 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms$iter__1844000176__1844000180")

var Lit_65 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms$iter__1844000176__1844000180$fn__1844000181")

var Lit_66 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms$iter__1844000176__1844000180$fn__1844000181$fn__1844000182")

var Lit_67 *jrt.String = jrt.Intern("res/")

var Lit_68 *jrt.String = jrt.Intern("arbace.a2g.main$registrations$fn__1844000252")

var Lit_69 *jrt.String = jrt.Intern("arbace.a2g.main$registrations$code_QMARK___1844000259")

var Lit_70 *jrt.String = jrt.Intern("CodeDecl")

var Lit_71 *jrt.String = jrt.Intern("DefineCode")

var Lit_72 *jrt.String = jrt.Intern("LinkCode")

var Lit_73 *jrt.String = jrt.Intern("arbace.a2g.main$registrations$fn__1844000261")

var Lit_74 *jrt.String = jrt.Intern("r")

var Lit_75 *jrt.String = jrt.Intern("arbace.a2g.main$registrations$fn__1844000252$fn__1844000256")

var Lit_76 *jrt.String = jrt.Intern("arbace.a2g.main$repl_visible_QMARK_$fn__1844000058")

var Lit_77 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$big_QMARK___1844000265")

var Lit_78 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$val_str__1844000267")

var Lit_79 *jrt.String = jrt.Intern("{")

var Lit_80 *jrt.String = jrt.Intern("}\n")

var Lit_81 *jrt.String = jrt.Intern(",\n ")

var Lit_82 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$iter__1844000285__1844000289")

var Lit_83 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$iter__1844000285__1844000289$fn__1844000290")

var Lit_84 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$iter__1844000285__1844000289$fn__1844000290$fn__1844000291")

var Lit_85 *jrt.String = jrt.Intern(" ")

var Lit_86 *jrt.String = jrt.Intern("}")

var Lit_87 *jrt.String = jrt.Intern(",\n  ")

var Lit_88 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$val_str__1844000267$iter__1844000268__1844000272")

var Lit_89 *jrt.String = jrt.Intern("[")

var Lit_90 *jrt.String = jrt.Intern("]")

var Lit_91 *jrt.String = jrt.Intern("\n  ")

var Lit_92 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$val_str__1844000267$iter__1844000268__1844000272$fn__1844000273")

var Lit_93 *jrt.String = jrt.Intern("arbace.a2g.main$report_str$val_str__1844000267$iter__1844000268__1844000272$fn__1844000273$fn__1844000274")

var Lit_94 *jrt.String = jrt.Intern(".z")

var Lit_95 *jrt.String = jrt.Intern("$*")

var Lit_96 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$fn__1844000062")

var Lit_97 *jrt.String = jrt.Intern("a2g: root class not found: ")

var Lit_98 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$iter__1844000067__1844000071")

var Lit_99 *jrt.String = jrt.Intern("<clinit>")

var Lit_100 *jrt.String = jrt.Intern("()V")

var Lit_101 *jrt.String = jrt.Intern("$")

var Lit_102 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$iter__1844000067__1844000071$fn__1844000072")

var Lit_103 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys$iter__1844000067__1844000071$fn__1844000072$fn__1844000073")

var Lit_104 *jrt.String = jrt.Intern("arbace.a2g.main$run$fn__1844000958")

var Lit_105 *jrt.String = jrt.Intern("a2g: the edge of this run in ")

var Lit_106 *jrt.String = jrt.Intern(": ")

var Lit_107 *jrt.String = jrt.Intern(" classes")

var Lit_108 *jrt.String = jrt.Intern("a2g: no edge ")

var Lit_109 *jrt.String = jrt.Intern(" (bin/a2g-edge update, or --jvm-reflection)")

var Lit_110 *jrt.String = jrt.Intern("JRT_CONV")

var Lit_111 *jrt.String = jrt.Intern("jdk/forms")

var Lit_112 *jrt.String = jrt.Intern("/data")

var Lit_113 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$late_QMARK___1844000323")

var Lit_114 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$compiled_packages_BANG___1844000325")

var Lit_115 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$wait__1844000337")

var Lit_116 *jrt.String = jrt.Intern("arbace")

var Lit_117 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000339__1844000343")

var Lit_118 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000349__1844000353")

var Lit_119 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$clj_files__1844000359")

var Lit_120 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000363")

var Lit_121 *jrt.String = jrt.Intern("arbace/lang/go")

var Lit_122 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000365")

var Lit_123 *jrt.String = jrt.Intern("overlay/jdk/variants")

var Lit_124 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000371")

var Lit_125 *jrt.String = jrt.Intern(", ")

var Lit_126 *jrt.String = jrt.Intern(" failures")

var Lit_127 *jrt.String = jrt.Intern("go/arbace/jrt")

var Lit_128 *jrt.String = jrt.Intern("java/util/Formatter")

var Lit_129 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000379")

var Lit_130 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$in_slice_QMARK___1844000381")

var Lit_131 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$jrt_java_QMARK___1844000385")

var Lit_132 *jrt.String = jrt.Intern("jdk/internal/jrt/StandardStreams")

var Lit_133 *jrt.String = jrt.Intern("jdk/internal/jrt/CaseInsensitiveComparator")

var Lit_134 *jrt.String = jrt.Intern("java/util/regex/Pattern")

var Lit_135 *jrt.String = jrt.Intern("java/util/concurrent/ExecutorService")

var Lit_136 *jrt.String = jrt.Intern("Formatted_O1__String")

var Lit_137 *jrt.String = jrt.Intern("java/lang/Iterable")

var Lit_138 *jrt.String = jrt.Intern("String_Join_CharSequence_Iterable__String")

var Lit_139 *jrt.String = jrt.Intern("java/util/Optional")

var Lit_140 *jrt.String = jrt.Intern("DescribeConstable__Optional")

var Lit_141 *jrt.String = jrt.Intern("java/io/ByteArrayInputStream")

var Lit_142 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream")

var Lit_143 *jrt.String = jrt.Intern("java/util/stream/Stream")

var Lit_144 *jrt.String = jrt.Intern("Lines__Stream")

var Lit_145 *jrt.String = jrt.Intern("String_CASE_INSENSITIVE_ORDER")

var Lit_146 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000389")

var Lit_147 *jrt.String = jrt.Intern("a2g: ")

var Lit_148 *jrt.String = jrt.Intern(" constant VarHandles, on ")

var Lit_149 *jrt.String = jrt.Intern(" fields")

var Lit_150 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000394")

var Lit_151 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_152 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_153 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000396__1844000400")

var Lit_154 *jrt.String = jrt.Intern("java/io/PrintWriter")

var Lit_155 *jrt.String = jrt.Intern("java/io/PrintStream")

var Lit_156 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_157 *jrt.String = jrt.Intern("java/util/Collections")

var Lit_158 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$slice_QMARK___1844000406")

var Lit_159 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000408__1844000412")

var Lit_160 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000424")

var Lit_161 *jrt.String = jrt.Intern("/gen")

var Lit_162 *jrt.String = jrt.Intern("/prog")

var Lit_163 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000434__1844000438")

var Lit_164 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000444")

var Lit_165 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000446")

var Lit_166 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000448")

var Lit_167 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000450")

var Lit_168 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000452")

var Lit_169 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000454")

var Lit_170 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000456")

var Lit_171 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000458__1844000464")

var Lit_172 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000481")

var Lit_173 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000483")

var Lit_174 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000489")

var Lit_175 *jrt.String = jrt.Intern("a2g_classes.go")

var Lit_176 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000494")

var Lit_177 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000503")

var Lit_178 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000505")

var Lit_179 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000507")

var Lit_180 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000513")

var Lit_181 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000515")

var Lit_182 *jrt.String = jrt.Intern("a2g_cut.go")

var Lit_183 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000517")

var Lit_184 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000519")

var Lit_185 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000521__1844000525")

var Lit_186 *jrt.String = jrt.Intern("a2g_init.go")

var Lit_187 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000531__1844000535")

var Lit_188 *jrt.String = jrt.Intern("a2g_strings.go")

var Lit_189 *jrt.String = jrt.Intern("a2g_up.go")

var Lit_190 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000541")

var Lit_191 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000543")

var Lit_192 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000545")

var Lit_193 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000551")

var Lit_194 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000553")

var Lit_195 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000555")

var Lit_196 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000557")

var Lit_197 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000559__1844000563")

var Lit_198 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000569__1844000573")

var Lit_199 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000583")

var Lit_200 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000589")

var Lit_201 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000591__1844000595")

var Lit_202 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601")

var Lit_203 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000637")

var Lit_204 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000643")

var Lit_205 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000645__1844000649")

var Lit_206 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000667")

var Lit_207 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000677__1844000681")

var Lit_208 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000703")

var Lit_209 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000705")

var Lit_210 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000707__1844000711")

var Lit_211 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000731__1844000735")

var Lit_212 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000745")

var Lit_213 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000747__1844000751")

var Lit_214 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000763__1844000767")

var Lit_215 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000783")

var Lit_216 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000791")

var Lit_217 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$go_names__1844000793")

var Lit_218 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000797")

var Lit_219 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000799")

var Lit_220 *jrt.String = jrt.Intern("/go/arbace/jrt.ae")

var Lit_221 *jrt.String = jrt.Intern("arbace/jrt")

var Lit_222 *jrt.String = jrt.Intern("\n")

var Lit_223 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000801__1844000805")

var Lit_224 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000815__1844000819")

var Lit_225 *jrt.String = jrt.Intern("/go/arbace/")

var Lit_226 *jrt.String = jrt.Intern(".ae")

var Lit_227 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000831__1844000835")

var Lit_228 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000841__1844000845")

var Lit_229 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000857__1844000861")

var Lit_230 *jrt.String = jrt.Intern("/program.edn")

var Lit_231 *jrt.String = jrt.Intern("{:module \"arbace\" :go \"1.27\"}\n")

var Lit_232 *jrt.String = jrt.Intern("/namespaces.txt")

var Lit_233 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000867__1844000871")

var Lit_234 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res")

var Lit_235 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887")

var Lit_236 *jrt.String = jrt.Intern("arbace/classes/generics.edn")

var Lit_237 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000904__1844000908")

var Lit_238 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace.ae")

var Lit_239 *jrt.String = jrt.Intern(";; Generated by a2g --program (A2G-SPEC §10.6): the program's main package.\n")

var Lit_240 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res/.g2a-data")

var Lit_241 *jrt.String = jrt.Intern("The main package's embedded sources (a2g --program): data, not Go forms.\n")

var Lit_242 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/main.ae")

var Lit_243 *jrt.String = jrt.Intern(";; Generated by a2g --program (A2G-SPEC §10.6).\n(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_244 *jrt.String = jrt.Intern("\n\n")

var Lit_245 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.ae")

var Lit_246 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/")

var Lit_247 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image_types.ae")

var Lit_248 *jrt.String = jrt.Intern(";; Generated by a2g --program: the program's struct types, by name (EXEC-NOTES.md).\n")

var Lit_249 *jrt.String = jrt.Intern("(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_250 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.bin")

var Lit_251 *jrt.String = jrt.Intern("")

var Lit_252 *jrt.String = jrt.Intern("/report.edn")

var Lit_253 *jrt.String = jrt.Intern("a2g: steps (s): ")

var Lit_254 *jrt.String = jrt.Intern(" (")

var Lit_255 *jrt.String = jrt.Intern(" jobs)")

var Lit_256 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000940__1844000944")

var Lit_257 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$clj_files__1844000359$fn__1844000360")

var Lit_258 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$compiled_packages_BANG___1844000325$iter__1844000326__1844000330")

var Lit_259 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$compiled_packages_BANG___1844000325$iter__1844000326__1844000330$fn__1844000331")

var Lit_260 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$compiled_packages_BANG___1844000325$iter__1844000326__1844000330$fn__1844000331$fn__1844000332")

var Lit_261 *jrt.String = jrt.Intern("packages.edn")

var Lit_262 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000424$fn__1844000425")

var Lit_263 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000424$fn__1844000427")

var Lit_264 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000424$fn__1844000429")

var Lit_265 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000424$fn__1844000429$fn__1844000430")

var Lit_266 *jrt.String = jrt.Intern("a2g_lambdas.go")

var Lit_267 *jrt.String = jrt.Intern("a2g_frames.go")

var Lit_268 *jrt.String = jrt.Intern("a2g_support.go")

var Lit_269 *jrt.String = jrt.Intern("reflect_tables_a2g.go")

var Lit_270 *jrt.String = jrt.Intern("Go name ")

var Lit_271 *jrt.String = jrt.Intern("declared more than once in ")

var Lit_272 *jrt.String = jrt.Intern("a2g: error: Go name ")

var Lit_273 *jrt.String = jrt.Intern(" declared more than once in package ")

var Lit_274 *jrt.String = jrt.Intern("package-private, redeclared by ")

var Lit_275 *jrt.String = jrt.Intern(" in another package (A2G-SPEC §4.4: rename table)")

var Lit_276 *jrt.String = jrt.Intern("a2g: error: package-private ")

var Lit_277 *jrt.String = jrt.Intern(" is redeclared by ")

var Lit_278 *jrt.String = jrt.Intern(" in another Java package; Go would override it")

var Lit_279 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000667$fn__1844000669")

var Lit_280 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$fn__1844000667$fn__1844000674")

var Lit_281 *jrt.String = jrt.Intern("/go/arbace/jrt/")

var Lit_282 *jrt.String = jrt.Intern("_test")

var Lit_283 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$go_names__1844000793$fn__1844000794")

var Lit_284 *jrt.String = jrt.Intern(".go")

var Lit_285 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$in_slice_QMARK___1844000381$fn__1844000382")

var Lit_286 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000339__1844000343$fn__1844000344")

var Lit_287 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000339__1844000343$fn__1844000344$fn__1844000345")

var Lit_288 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000349__1844000353$fn__1844000354")

var Lit_289 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000349__1844000353$fn__1844000354$fn__1844000355")

var Lit_290 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000396__1844000400$fn__1844000401")

var Lit_291 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000396__1844000400$fn__1844000401$fn__1844000402")

var Lit_292 *jrt.String = jrt.Intern("exec")

var Lit_293 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000408__1844000412$fn__1844000413")

var Lit_294 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000408__1844000412$fn__1844000413$fn__1844000414")

var Lit_295 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000434__1844000438$fn__1844000439")

var Lit_296 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000434__1844000438$fn__1844000439$fn__1844000440")

var Lit_297 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000458__1844000464$fn__1844000465")

var Lit_298 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000458__1844000464$fn__1844000465$iter__1844000460__1844000469")

var Lit_299 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000458__1844000464$fn__1844000465$iter__1844000460__1844000469$fn__1844000470")

var Lit_300 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000458__1844000464$fn__1844000465$iter__1844000460__1844000469$fn__1844000470$fn__1844000471")

var Lit_301 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000521__1844000525$fn__1844000526")

var Lit_302 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000521__1844000525$fn__1844000526$fn__1844000527")

var Lit_303 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000531__1844000535$fn__1844000536")

var Lit_304 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000531__1844000535$fn__1844000536$fn__1844000537")

var Lit_305 *jrt.String = jrt.Intern("_Init")

var Lit_306 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000559__1844000563$fn__1844000564")

var Lit_307 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000559__1844000563$fn__1844000564$fn__1844000565")

var Lit_308 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000569__1844000573$fn__1844000574")

var Lit_309 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000569__1844000573$fn__1844000574$fn__1844000575")

var Lit_310 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000591__1844000595$fn__1844000596")

var Lit_311 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000591__1844000595$fn__1844000596$fn__1844000597")

var Lit_312 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000645__1844000649$fn__1844000650")

var Lit_313 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000645__1844000649$fn__1844000650$fn__1844000651")

var Lit_314 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000677__1844000681$fn__1844000682")

var Lit_315 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000677__1844000681$fn__1844000682$fn__1844000683")

var Lit_316 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000707__1844000711$fn__1844000712")

var Lit_317 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000707__1844000711$fn__1844000712$fn__1844000713")

var Lit_318 *jrt.String = jrt.Intern("standin_")

var Lit_319 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000707__1844000711$fn__1844000712$fn__1844000725")

var Lit_320 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000707__1844000711$fn__1844000712$fn__1844000713$fn__1844000717")

var Lit_321 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000707__1844000711$fn__1844000712$fn__1844000713$fn__1844000717$fn__1844000718")

var Lit_322 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000707__1844000711$fn__1844000712$fn__1844000725$fn__1844000726")

var Lit_323 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000731__1844000735$fn__1844000736")

var Lit_324 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000731__1844000735$fn__1844000736$fn__1844000737")

var Lit_325 *jrt.String = jrt.Intern("_test.ae")

var Lit_326 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000747__1844000751$fn__1844000752")

var Lit_327 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000747__1844000751$fn__1844000752$fn__1844000753")

var Lit_328 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000763__1844000767$fn__1844000768")

var Lit_329 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000763__1844000767$fn__1844000768$fn__1844000769")

var Lit_330 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000801__1844000805$fn__1844000806")

var Lit_331 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000801__1844000805$fn__1844000806$fn__1844000807")

var Lit_332 *jrt.String = jrt.Intern("jrt/")

var Lit_333 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000815__1844000819$fn__1844000820")

var Lit_334 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000815__1844000819$fn__1844000820$fn__1844000821")

var Lit_335 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000831__1844000835$fn__1844000836")

var Lit_336 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000831__1844000835$fn__1844000836$fn__1844000837")

var Lit_337 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000841__1844000845$fn__1844000846")

var Lit_338 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000841__1844000845$fn__1844000846$fn__1844000847")

var Lit_339 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000857__1844000861$fn__1844000862")

var Lit_340 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000857__1844000861$fn__1844000862$fn__1844000863")

var Lit_341 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000867__1844000871$fn__1844000872")

var Lit_342 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000867__1844000871$fn__1844000872$fn__1844000873")

var Lit_343 *jrt.String = jrt.Intern("arbace/")

var Lit_344 *jrt.String = jrt.Intern("-")

var Lit_345 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888")

var Lit_346 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888$fn__1844000889")

var Lit_347 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888$fn__1844000899")

var Lit_348 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888$fn__1844000889$fn__1844000893")

var Lit_349 *jrt.String = jrt.Intern("UTF-8")

var Lit_350 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000904__1844000908$fn__1844000909")

var Lit_351 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000904__1844000908$fn__1844000909$fn__1844000910")

var Lit_352 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000904__1844000908$fn__1844000909$fn__1844000920")

var Lit_353 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000904__1844000908$fn__1844000909$fn__1844000910$fn__1844000914")

var Lit_354 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000940__1844000944$fn__1844000945")

var Lit_355 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$iter__1844000940__1844000944$fn__1844000945$fn__1844000946")

var Lit_356 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601$fn__1844000602")

var Lit_357 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601$iter__1844000604__1844000608")

var Lit_358 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601$iter__1844000620__1844000624")

var Lit_359 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601$iter__1844000604__1844000608$fn__1844000609")

var Lit_360 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601$iter__1844000604__1844000608$fn__1844000609$fn__1844000610")

var Lit_361 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601$iter__1844000620__1844000624$fn__1844000625")

var Lit_362 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_$report_of__1844000601$iter__1844000620__1844000624$fn__1844000625$fn__1844000626")

var Lit_363 *jrt.String = jrt.Intern("aot.edn")

var Lit_364 *jrt.String = jrt.Intern(" ready after ")

var Lit_365 *jrt.String = jrt.Intern(" s")

var Lit_366 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000078__1844000082")

var Lit_367 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094")

var Lit_368 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000078__1844000082$fn__1844000083")

var Lit_369 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000078__1844000082$fn__1844000083$fn__1844000084")

var Lit_370 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095")

var Lit_371 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096")

var Lit_372 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096$fn__1844000097")

var Lit_373 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096$fn__1844000097$fn__1844000098")

var Lit_374 *jrt.String = jrt.Intern("<init>")

var Lit_375 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000219")

var Lit_376 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000226")

var Lit_377 *jrt.String = jrt.Intern("A2G_CLASS_TIMES")

var Lit_378 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000232")

var Lit_379 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000241")

var Lit_380 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes$fn__1844000219$fn__1844000223")

var Lit_381 *jrt.String = jrt.Intern("a2g: class time")

var Lit_382 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$fn__1844000149")

var Lit_383 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158")

var Lit_384 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159")

var Lit_385 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000160")

var Lit_386 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000170")

var Lit_387 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000160$fn__1844000164")

var Lit_388 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn4,linekn6,columnkn4,fileyn2,t0yn4,argsyn1,syn3,diryn4,scanyn8,manifestkn3,tagyn6,Stringyn4,specyn1,Tyn1,fyn4,formyn8,names-reyn6,own-reyn5,formsyn2,gsyn4,textyn4,fromyn2,toyn1,pyn5,bytesyn2,psyn8,embeddedyn5,worldyn3,pkgyn3,topyn3,tagyn1,iyn1,nyn6,catch?yn1,ryn7,renamesyn2,nsyn7,file-ofyn7,cost-ofyn9,pkgstatesyn5,filesyn6,errorsyn7,classesyn6,reportyn4,optsyn1,&v11,arbace.core5,in-nsMyn15,arbace.a2g.mainm2,R0,s2985,bin/a2g: class forms to Go forms (doc/go/A2G-SPEC.md, doc/go/A2G-NOTES.md).\n\n  bin/a2g [OPTIONS]\n    --out DIR          output directory (default .tmp/a2g/out): DIR/gen/go/... the generated\n                       forms (A2G-SPEC §4.3: the files a2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/g2a build; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of class forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.aot, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (a2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts a2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (A2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       a2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/g2a build --line-file DIR/prog\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): a2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/a2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)m2,R0,s2985,bin/a2g: class forms to Go forms (doc/go/A2G-SPEC.md, doc/go/A2G-NOTES.md).\n\n  bin/a2g [OPTIONS]\n    --out DIR          output directory (default .tmp/a2g/out): DIR/gen/go/... the generated\n                       forms (A2G-SPEC §4.3: the files a2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/g2a build; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of class forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.aot, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (a2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts a2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (A2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       a2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/g2a build --line-file DIR/prog\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): a2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/a2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)R1,v15,arbace.a2g.main3,nowm10,R2,TR3,L1,V0,R4,i64,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main4,secsm10,R2,TR3,L1,V1,R7,R4,i65,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main10,parse-argsm8,R3,L1,V1,R8,R4,i67,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main8,internalm10,R2,TR3,L1,V1,R9,R4,i86,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main16,manifest-classesm10,R3,L1,V1,R10,R0,s55,The classes the jrt manifest declares (internal names).R4,i88,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main11,jrt-classesm10,R3,L1,V2,R11,R12,R0,s81,jrt's classes: those its forms register (Define) and those its manifest declares.R4,i96,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main13,repl-visible?m12,R2,TR3,L1,V1,Myn1,nm2,R13,R14,R0,s443,Can the REPL name class n's public members (internal name)? Not when n is in a JDK module's\n  package that the module does not export (jdk.internal.misc, sun.nio.cs ...): the JVM refuses\n  such access from Clojure code (IllegalAccessError), so the Go build's REPL world does not root\n  them (A2G-SPEC §10.6; JRT-NOTES.md, \"The JDK's resource data\", amendment RD2). Classes of no\n  JDK module (Arbace's, jrt's own jdk.internal.jrt) are visible.R4,i104,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main9,root-keysm12,R2,TR3,L1,V1,R15,R0,s115,Method keys of a root spec. CLASS$* is the class and every named class nested in it (the\n  whole of Compiler, say).R4,i116,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main13,lazy-standinsS2,s16,java/util/Locales25,java/util/Locale$Categorym8,R4,i136,R5,i1,R6,s18,arbace/a2g/main.aeR0,s335,Replaced stand-ins initialized on first use like any translated class, not eagerly: jrt's\n  hand-written code (but its tests) reads none of their statics, and their initialization needs\n  much of the program initialized first (Locale's: its constants, the default locale from the\n  system properties; JRT-NOTES.md, \"Text and locales\").v15,arbace.a2g.main13,standin-rootsm10,R3,L1,V2,R11,R16,R0,s153,Roots for the translated classes that replace jrt's stand-ins: their static initializer\n  and the members the stand-in defined (jrt's code may use them).R4,i143,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main10,form-namesm12,R2,TR3,L1,V1,R17,R0,s41,Go identifiers a top-level form declares.R4,i167,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main16,method-recv-typem10,R2,TR3,L1,V1,R17,R4,i178,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main9,mentions?m10,R2,TR3,L1,V2,R18,R19,R4,i186,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main16,filter-init-bodym10,R2,TR3,L1,V2,R17,R20,R4,i195,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main16,filter-standins*m8,R3,L1,V2,R21,R22,R4,i199,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main6,write!m10,R2,TR3,L1,V2,R17,R23,R4,i230,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main10,copy-file!m10,R2,TR3,L1,V2,R24,R25,R4,i234,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main13,resource-filem12,R2,TR3,L1,V2,R26,Myn1,bm2,R13,R27,R0,s253,The embedded resource p (bytes b) as it is written: as p.z, zlib-compressed, when that saves\n  a quarter or more (the sources, generics.edn, tzdb.dat), else as it is; jrt's OSHost.Resource\n  inflates a p.z when asked for p (amendment SZ2). [name bytes].R4,i238,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main16,write-resources!m12,R2,TR3,L1,V2,R10,R28,R0,s157,Writes the embedded resources ps ([path bytes-fn] in order) under dir, compressed in\n  parallel (resource-file), written in order. Returns the names written.R4,i246,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main6,top-ofm10,R2,TR3,L1,V1,Myn1,nm2,R13,R14,R4,i258,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main21,program-package-formsm12,R2,TR3,L1,V1,R29,R0,s87,The main package: main.go and the embedded sources (res/..., EVAL-NOTES.md, \"Loading\").R4,i260,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main18,program-main-formsm12,R2,TR3,L1,V0,R0,s496,main: first rlwrap for an interactive REPL (execRlwrap, which replaces the process when it\n  applies), then the system property arbace.version from arbaceVersion (when the link set it),\n  then jrt's host for the build's system (jrt.ProgramHost: OSHost, or the box's on TamaGo,\n  doc/go/BOX-NOTES.md),\n  then the command line as a String[], then arbace.lang.Main.main inside jrt.RunMain\n  (the thread main, uncaught exceptions printed as the JVM prints them, status 1), its status\n  the process's.R4,i272,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main10,source-topm12,R2,TR3,L1,V3,R30,R31,R32,R0,s229,The name a Go file is named after (§4.3): in arbace/lang the class forms file of top-level\n  class top (FxClasses for the classes of FxClasses.ae, so that --line-file positions name\n  it), in jrt the class (its Java source path).R4,i309,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main5,apartm12,R2,TR3,L1,V5,R33,R34,R35,R17,R36,R0,s456,Runs f (forms of class n, the i-th of its kind, tag naming the kind) on its own, with the\n  effects the sequential run has on the package's state recorded rather than applied: its\n  literals named apart (Lit?<tag><i>_k, in first-use order), what it conj'ed into the\n  package's ups, lambdas and cuts and into the races, in order, and its printed output. With\n  catch?, an exception is the result's :error [n message] (a translation's), else it is\n  thrown.R4,i322,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main12,merge-apart!m12,R2,TR3,L1,V3,R37,R28,R38,R0,s354,Applies to the package state ps (and c/*races*) what result r of apart recorded, as the\n  sequential run would have done it: its printed output, its conj's replayed one by one, its\n  literals named in the package's pool (Lit_n, numbered in order of first use; one an earlier\n  class used keeps its name). Returns renames with r's literals' renames added.R4,i347,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main17,translate-classesm10,R3,L1,V6,R39,R40,R41,R42,R43,R44,R0,s441,Translates the classes ns (in order) in parallel (jobs threads), each apart, and merges what\n  each did, in their order, as the sequential translation would have done it class after\n  class (merge-apart!): the forms into files ([pkg go-file] -> forms; file-of gives a\n  class's), its errors into errors. cost-of estimates a class's translation time (the\n  costliest start first). Returns the renames of the classes' literals (out/*renames*).R4,i371,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main13,registrationsm10,R3,L1,V3,R31,R45,R28,R0,s224,The forms of a2g_classes.go of package pkg (out/class-registration of each class, in order),\n  the classes in parallel, each apart, merged in order into the package state ps (as\n  translate-classes). Returns [forms renames].R4,i397,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main12,default-edgem6,R4,i418,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main10,report-strm12,R2,TR3,L1,V1,R46,R0,s243,report.edn's text: the map a key per line, a map or vector with more than one element an\n  element per line, the rest as pr-str prints it (arbace.pprint took half a minute on the\n  program's report, on the critical path at the end of the run).R4,i420,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main4,run*m10,R3,L1,V1,R47,R0,s46,a2g's run, in the class environment run binds.R4,i434,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main8,id-floorl100000,m8,R4,i897,R5,i1,R6,s18,arbace/a2g/main.aeR0,s483,Where the runtime's id counter (RT/nextID, gensym's) stands when a2g's run starts. The\n  analyzer and the translator name temporaries by it (arr_100417), so a2g first advances it to\n  this fixed value: its output then depends on its inputs, not on how much code the running\n  Arbace compiled before (a2g's own namespaces load from source, and on the Go executable in\n  other amounts than on the JVM). A round value well above what loading a2g takes\n  (doc/STANDALONE-NOTES.md, SA13).v15,arbace.a2g.main12,advance-ids!m12,R2,TR3,L1,V0,R0,s84,Advances the runtime's id counter to id-floor (an error when it is past it already).R4,i906,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main3,runm10,R3,L1,V1,R47,R0,s369,a2g's run (bin/a2g's options as parse-args gives them). The classes outside the forms come\n  from the edge (--edge, default jdk/edge.edn: doc/STANDALONE-NOTES.md, S2), without the JVM's\n  reflection or ASM; --record-edge FILE: from the JVM's reflection, writing the edge of what\n  this run asked into FILE; --jvm-reflection: from the JVM's reflection (the edge unused).R4,i915,R5,i1,R6,s18,arbace/a2g/main.aev15,arbace.a2g.main5,-mainm8,R3,L1,V2,R48,R8,R4,i948,R5,i1,R6,s18,arbace/a2g/main.ae")

var Lit_389 *jrt.String = jrt.Intern("arbace.a2g.main$eval1844000004$loading__1927001464__auto____1844000005")

var Lit_390 *jrt.String = jrt.Intern("arbace.a2g.main$eval1844000008$fn__1844000009")

var Lit_391 *jrt.String = jrt.Intern("arbace.a2g.main$now")

var Lit_392 *jrt.String = jrt.Intern("arbace.a2g.main$secs")

var Lit_393 *jrt.String = jrt.Intern("arbace.a2g.main$parse_args")

var Lit_394 *jrt.String = jrt.Intern("arbace.a2g.main$internal")

var Lit_395 *jrt.String = jrt.Intern("arbace.a2g.main$manifest_classes")

var Lit_396 *jrt.String = jrt.Intern("arbace.a2g.main$jrt_classes")

var Lit_397 *jrt.String = jrt.Intern("arbace.a2g.main$repl_visible_QMARK_")

var Lit_398 *jrt.String = jrt.Intern("arbace.a2g.main$root_keys")

var Lit_399 *jrt.String = jrt.Intern("arbace.a2g.main$standin_roots")

var Lit_400 *jrt.String = jrt.Intern("arbace.a2g.main$form_names")

var Lit_401 *jrt.String = jrt.Intern("arbace.a2g.main$method_recv_type")

var Lit_402 *jrt.String = jrt.Intern("arbace.a2g.main$mentions_QMARK_")

var Lit_403 *jrt.String = jrt.Intern("arbace.a2g.main$filter_init_body")

var Lit_404 *jrt.String = jrt.Intern("arbace.a2g.main$filter_standins_STAR_")

var Lit_405 *jrt.String = jrt.Intern("arbace.a2g.main$write_BANG_")

var Lit_406 *jrt.String = jrt.Intern("arbace.a2g.main$copy_file_BANG_")

var Lit_407 *jrt.String = jrt.Intern("arbace.a2g.main$resource_file")

var Lit_408 *jrt.String = jrt.Intern("arbace.a2g.main$write_resources_BANG_")

var Lit_409 *jrt.String = jrt.Intern("arbace.a2g.main$top_of")

var Lit_410 *jrt.String = jrt.Intern("arbace.a2g.main$program_package_forms")

var Lit_411 *jrt.String = jrt.Intern("arbace.a2g.main$program_main_forms")

var Lit_412 *jrt.String = jrt.Intern("arbace.a2g.main$source_top")

var Lit_413 *jrt.String = jrt.Intern("arbace.a2g.main$apart")

var Lit_414 *jrt.String = jrt.Intern("arbace.a2g.main$merge_apart_BANG_")

var Lit_415 *jrt.String = jrt.Intern("arbace.a2g.main$translate_classes")

var Lit_416 *jrt.String = jrt.Intern("arbace.a2g.main$registrations")

var Lit_417 *jrt.String = jrt.Intern("jdk/edge.edn")

var Lit_418 *jrt.String = jrt.Intern("arbace.a2g.main$report_str")

var Lit_419 *jrt.String = jrt.Intern("arbace.a2g.main$run_STAR_")

var Lit_420 *jrt.String = jrt.Intern("arbace.a2g.main$advance_ids_BANG_")

var Lit_421 *jrt.String = jrt.Intern("arbace.a2g.main$run")

var Lit_422 *jrt.String = jrt.Intern("arbace.a2g.main$_main")
