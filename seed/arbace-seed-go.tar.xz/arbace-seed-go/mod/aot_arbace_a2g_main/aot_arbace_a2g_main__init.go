//line aot_arbace_a2g_main__init.ae:1
package aot_arbace_a2g_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_main__init_A_Unit0__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_main__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_main__init_A_const_1) }
//line :1:1
func A_arbace_a2g_main__init_A_Unit1__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_main__init_A_Unit2__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_Init(); tmp2 = A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_main__init_A_Unit3__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_main__init_A_const_1)).Equals_O__Z(A_arbace_a2g_main__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_main_eval1844000008_fn__1844000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_main_eval1844000008_fn__1844000009_A_Init(); tmp2 = A_arbace_a2g_main_eval1844000008_fn__1844000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_main__init_A_Load__O() any { A_arbace_a2g_main__init_A_Init(); A_arbace_a2g_main__init_A_Unit0__O(); A_arbace_a2g_main__init_A_Unit1__O(); A_arbace_a2g_main__init_A_Unit2__O(); A_arbace_a2g_main__init_A_Unit3__O(); A_arbace_a2g_main__init_A_Unit4__O(); A_arbace_a2g_main__init_A_Unit5__O(); A_arbace_a2g_main__init_A_Unit6__O(); A_arbace_a2g_main__init_A_Unit7__O(); A_arbace_a2g_main__init_A_Unit8__O(); A_arbace_a2g_main__init_A_Unit9__O(); A_arbace_a2g_main__init_A_Unit10__O(); A_arbace_a2g_main__init_A_Unit11__O(); A_arbace_a2g_main__init_A_Unit12__O(); A_arbace_a2g_main__init_A_Unit13__O(); A_arbace_a2g_main__init_A_Unit14__O(); A_arbace_a2g_main__init_A_Unit15__O(); A_arbace_a2g_main__init_A_Unit16__O(); A_arbace_a2g_main__init_A_Unit17__O(); A_arbace_a2g_main__init_A_Unit18__O(); A_arbace_a2g_main__init_A_Unit19__O(); A_arbace_a2g_main__init_A_Unit20__O(); A_arbace_a2g_main__init_A_Unit21__O(); A_arbace_a2g_main__init_A_Unit22__O(); A_arbace_a2g_main__init_A_Unit23__O(); A_arbace_a2g_main__init_A_Unit24__O(); A_arbace_a2g_main__init_A_Unit25__O(); A_arbace_a2g_main__init_A_Unit26__O(); A_arbace_a2g_main__init_A_Unit27__O(); A_arbace_a2g_main__init_A_Unit28__O(); A_arbace_a2g_main__init_A_Unit29__O(); A_arbace_a2g_main__init_A_Unit30__O(); A_arbace_a2g_main__init_A_Unit31__O(); A_arbace_a2g_main__init_A_Unit32__O(); A_arbace_a2g_main__init_A_Unit33__O(); A_arbace_a2g_main__init_A_Unit34__O(); A_arbace_a2g_main__init_A_Unit35__O(); A_arbace_a2g_main__init_A_Unit36__O(); return nil }






















































func A_arbace_a2g_main__init_A_Unit4__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_4; var tmp2 any = A_arbace_a2g_main_now_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_now_A_Init(); tmp3 = A_arbace_a2g_main_now_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_5)); return A_arbace_a2g_main__init_A_const_4.Ref() }
func A_arbace_a2g_main__init_A_Unit5__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(61, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_6; var tmp2 any = A_arbace_a2g_main_secs_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_secs_A_Init(); tmp3 = A_arbace_a2g_main_secs_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_7)); return A_arbace_a2g_main__init_A_const_6.Ref() }

func A_arbace_a2g_main__init_A_Unit6__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_8; var tmp2 any = A_arbace_a2g_main_parse_args_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_parse_args_A_Init(); tmp3 = A_arbace_a2g_main_parse_args_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_9)); return A_arbace_a2g_main__init_A_const_8.Ref() }

















func A_arbace_a2g_main__init_A_Unit7__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_10; var tmp2 any = A_arbace_a2g_main_internal_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_internal_A_Init(); tmp3 = A_arbace_a2g_main_internal_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_11)); return A_arbace_a2g_main__init_A_const_10.Ref() }

func A_arbace_a2g_main__init_A_Unit8__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_12; var tmp2 any = A_arbace_a2g_main_manifest_classes_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_manifest_classes_A_Init(); tmp3 = A_arbace_a2g_main_manifest_classes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_13)); return A_arbace_a2g_main__init_A_const_12.Ref() }







func A_arbace_a2g_main__init_A_Unit9__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_14; var tmp2 any = A_arbace_a2g_main_jrt_classes_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_jrt_classes_A_Init(); tmp3 = A_arbace_a2g_main_jrt_classes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_15)); return A_arbace_a2g_main__init_A_const_14.Ref() }







func A_arbace_a2g_main__init_A_Unit10__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_16; var tmp2 any = A_arbace_a2g_main_repl_visible_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_repl_visible_QMARK__A_Init(); tmp3 = A_arbace_a2g_main_repl_visible_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_17)); return A_arbace_a2g_main__init_A_const_16.Ref() }











func A_arbace_a2g_main__init_A_Unit11__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_18; var tmp2 any = A_arbace_a2g_main_root_keys_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_root_keys_A_Init(); tmp3 = A_arbace_a2g_main_root_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_19)); return A_arbace_a2g_main__init_A_const_18.Ref() }



















func A_arbace_a2g_main__init_A_Unit12__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); jrt.NN(A_arbace_a2g_main__init_A_const_20).BindRoot_O__V(A_arbace_a2g_main__init_A_const_21); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_20; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_22)); return A_arbace_a2g_main__init_A_const_20.Ref() }






func A_arbace_a2g_main__init_A_Unit13__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_23; var tmp2 any = A_arbace_a2g_main_standin_roots_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_standin_roots_A_Init(); tmp3 = A_arbace_a2g_main_standin_roots_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_24)); return A_arbace_a2g_main__init_A_const_23.Ref() }























func A_arbace_a2g_main__init_A_Unit14__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_25; var tmp2 any = A_arbace_a2g_main_form_names_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_form_names_A_Init(); tmp3 = A_arbace_a2g_main_form_names_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_26)); return A_arbace_a2g_main__init_A_const_25.Ref() }










func A_arbace_a2g_main__init_A_Unit15__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_27; var tmp2 any = A_arbace_a2g_main_method_recv_type_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_method_recv_type_A_Init(); tmp3 = A_arbace_a2g_main_method_recv_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_28)); return A_arbace_a2g_main__init_A_const_27.Ref() }







func A_arbace_a2g_main__init_A_Unit16__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(181, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_29; var tmp2 any = A_arbace_a2g_main_mentions_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_mentions_QMARK__A_Init(); tmp3 = A_arbace_a2g_main_mentions_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_30)); return A_arbace_a2g_main__init_A_const_29.Ref() }








func A_arbace_a2g_main__init_A_Unit17__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_31; var tmp2 any = A_arbace_a2g_main_filter_init_body_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_filter_init_body_A_Init(); tmp3 = A_arbace_a2g_main_filter_init_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_32)); return A_arbace_a2g_main__init_A_const_31.Ref() }



func A_arbace_a2g_main__init_A_Unit18__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(194, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_33; var tmp2 any = A_arbace_a2g_main_filter_standins_STAR__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_filter_standins_STAR__A_Init(); tmp3 = A_arbace_a2g_main_filter_standins_STAR__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_33; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_34)); return A_arbace_a2g_main__init_A_const_33.Ref() }






























func A_arbace_a2g_main__init_A_Unit19__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(225, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_35; var tmp2 any = A_arbace_a2g_main_write_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_write_BANG__A_Init(); tmp3 = A_arbace_a2g_main_write_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_36)); return A_arbace_a2g_main__init_A_const_35.Ref() }



func A_arbace_a2g_main__init_A_Unit20__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(229, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_37; var tmp2 any = A_arbace_a2g_main_copy_file_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_copy_file_BANG__A_Init(); tmp3 = A_arbace_a2g_main_copy_file_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_38)); return A_arbace_a2g_main__init_A_const_37.Ref() }



func A_arbace_a2g_main__init_A_Unit21__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(233, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_39; var tmp2 any = A_arbace_a2g_main_resource_file_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_resource_file_A_Init(); tmp3 = A_arbace_a2g_main_resource_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_40)); return A_arbace_a2g_main__init_A_const_39.Ref() }







func A_arbace_a2g_main__init_A_Unit22__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(241, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_41; var tmp2 any = A_arbace_a2g_main_write_resources_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_write_resources_BANG__A_Init(); tmp3 = A_arbace_a2g_main_write_resources_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_42)); return A_arbace_a2g_main__init_A_const_41.Ref() }











func A_arbace_a2g_main__init_A_Unit23__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(253, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_43; var tmp2 any = A_arbace_a2g_main_top_of_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_top_of_A_Init(); tmp3 = A_arbace_a2g_main_top_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_44)); return A_arbace_a2g_main__init_A_const_43.Ref() }

func A_arbace_a2g_main__init_A_Unit24__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_45; var tmp2 any = A_arbace_a2g_main_program_package_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_program_package_forms_A_Init(); tmp3 = A_arbace_a2g_main_program_package_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_46)); return A_arbace_a2g_main__init_A_const_45.Ref() }











func A_arbace_a2g_main__init_A_Unit25__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_47; var tmp2 any = A_arbace_a2g_main_program_main_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_program_main_forms_A_Init(); tmp3 = A_arbace_a2g_main_program_main_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_48)); return A_arbace_a2g_main__init_A_const_47.Ref() }




































func A_arbace_a2g_main__init_A_Unit26__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(304, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_49; var tmp2 any = A_arbace_a2g_main_source_top_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_source_top_A_Init(); tmp3 = A_arbace_a2g_main_source_top_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_50)); return A_arbace_a2g_main__init_A_const_49.Ref() }












func A_arbace_a2g_main__init_A_Unit27__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(317, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_51; var tmp2 any = A_arbace_a2g_main_apart_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_apart_A_Init(); tmp3 = A_arbace_a2g_main_apart_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_52)); return A_arbace_a2g_main__init_A_const_51.Ref() }
























func A_arbace_a2g_main__init_A_Unit28__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(342, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_53; var tmp2 any = A_arbace_a2g_main_merge_apart_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_merge_apart_BANG__A_Init(); tmp3 = A_arbace_a2g_main_merge_apart_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_54)); return A_arbace_a2g_main__init_A_const_53.Ref() }























func A_arbace_a2g_main__init_A_Unit29__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(366, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_55; var tmp2 any = A_arbace_a2g_main_translate_classes_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_translate_classes_A_Init(); tmp3 = A_arbace_a2g_main_translate_classes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_56)); return A_arbace_a2g_main__init_A_const_55.Ref() }

























func A_arbace_a2g_main__init_A_Unit30__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(392, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_57; var tmp2 any = A_arbace_a2g_main_registrations_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_registrations_A_Init(); tmp3 = A_arbace_a2g_main_registrations_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_58)); return A_arbace_a2g_main__init_A_const_57.Ref() }









func A_arbace_a2g_main__init_A_Unit31__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(402, 1); jrt.NN(A_arbace_a2g_main__init_A_const_59).BindRoot_O__V(Lit_922); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_59; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_60)); return A_arbace_a2g_main__init_A_const_59.Ref() }

func A_arbace_a2g_main__init_A_Unit32__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(404, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_61; var tmp2 any = A_arbace_a2g_main_run_STAR__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_run_STAR__A_Init(); tmp3 = A_arbace_a2g_main_run_STAR__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_62)); return A_arbace_a2g_main__init_A_const_61.Ref() }



































































































































































































































































































































































































































































func A_arbace_a2g_main__init_A_Unit33__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(856, 1); jrt.NN(A_arbace_a2g_main__init_A_const_63).BindRoot_O__V(A_arbace_a2g_main__init_A_const_64); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_63; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_65)); return A_arbace_a2g_main__init_A_const_63.Ref() }








func A_arbace_a2g_main__init_A_Unit34__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(865, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_66; var tmp2 any = A_arbace_a2g_main_advance_ids_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_advance_ids_BANG__A_Init(); tmp3 = A_arbace_a2g_main_advance_ids_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_67)); return A_arbace_a2g_main__init_A_const_66.Ref() }








func A_arbace_a2g_main__init_A_Unit35__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(874, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_68; var tmp2 any = A_arbace_a2g_main_run_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main_run_A_Init(); tmp3 = A_arbace_a2g_main_run_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_69)); return A_arbace_a2g_main__init_A_const_68.Ref() }
































func A_arbace_a2g_main__init_A_Unit36__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(907, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_70; var tmp2 any = A_arbace_a2g_main__main_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_main__main_A_Init(); tmp3 = A_arbace_a2g_main__main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_71)); return A_arbace_a2g_main__init_A_const_70.Ref() }



type A_arbace_a2g_main__init_A struct{ jrt.Object }

var A_arbace_a2g_main__init_A_const_0 *lang.Var

var A_arbace_a2g_main__init_A_const_1 any

var A_arbace_a2g_main__init_A_const_2 any

var A_arbace_a2g_main__init_A_const_3 any

var A_arbace_a2g_main__init_A_const_4 *lang.Var

var A_arbace_a2g_main__init_A_const_5 any

var A_arbace_a2g_main__init_A_const_6 *lang.Var

var A_arbace_a2g_main__init_A_const_7 any

var A_arbace_a2g_main__init_A_const_8 *lang.Var

var A_arbace_a2g_main__init_A_const_9 any

var A_arbace_a2g_main__init_A_const_10 *lang.Var

var A_arbace_a2g_main__init_A_const_11 any

var A_arbace_a2g_main__init_A_const_12 *lang.Var

var A_arbace_a2g_main__init_A_const_13 any

var A_arbace_a2g_main__init_A_const_14 *lang.Var

var A_arbace_a2g_main__init_A_const_15 any

var A_arbace_a2g_main__init_A_const_16 *lang.Var

var A_arbace_a2g_main__init_A_const_17 any

var A_arbace_a2g_main__init_A_const_18 *lang.Var

var A_arbace_a2g_main__init_A_const_19 any

var A_arbace_a2g_main__init_A_const_20 *lang.Var

var A_arbace_a2g_main__init_A_const_21 any

var A_arbace_a2g_main__init_A_const_22 any

var A_arbace_a2g_main__init_A_const_23 *lang.Var

var A_arbace_a2g_main__init_A_const_24 any

var A_arbace_a2g_main__init_A_const_25 *lang.Var

var A_arbace_a2g_main__init_A_const_26 any

var A_arbace_a2g_main__init_A_const_27 *lang.Var

var A_arbace_a2g_main__init_A_const_28 any

var A_arbace_a2g_main__init_A_const_29 *lang.Var

var A_arbace_a2g_main__init_A_const_30 any

var A_arbace_a2g_main__init_A_const_31 *lang.Var

var A_arbace_a2g_main__init_A_const_32 any

var A_arbace_a2g_main__init_A_const_33 *lang.Var

var A_arbace_a2g_main__init_A_const_34 any

var A_arbace_a2g_main__init_A_const_35 *lang.Var

var A_arbace_a2g_main__init_A_const_36 any

var A_arbace_a2g_main__init_A_const_37 *lang.Var

var A_arbace_a2g_main__init_A_const_38 any

var A_arbace_a2g_main__init_A_const_39 *lang.Var

var A_arbace_a2g_main__init_A_const_40 any

var A_arbace_a2g_main__init_A_const_41 *lang.Var

var A_arbace_a2g_main__init_A_const_42 any

var A_arbace_a2g_main__init_A_const_43 *lang.Var

var A_arbace_a2g_main__init_A_const_44 any

var A_arbace_a2g_main__init_A_const_45 *lang.Var

var A_arbace_a2g_main__init_A_const_46 any

var A_arbace_a2g_main__init_A_const_47 *lang.Var

var A_arbace_a2g_main__init_A_const_48 any

var A_arbace_a2g_main__init_A_const_49 *lang.Var

var A_arbace_a2g_main__init_A_const_50 any

var A_arbace_a2g_main__init_A_const_51 *lang.Var

var A_arbace_a2g_main__init_A_const_52 any

var A_arbace_a2g_main__init_A_const_53 *lang.Var

var A_arbace_a2g_main__init_A_const_54 any

var A_arbace_a2g_main__init_A_const_55 *lang.Var

var A_arbace_a2g_main__init_A_const_56 any

var A_arbace_a2g_main__init_A_const_57 *lang.Var

var A_arbace_a2g_main__init_A_const_58 any

var A_arbace_a2g_main__init_A_const_59 *lang.Var

var A_arbace_a2g_main__init_A_const_60 any

var A_arbace_a2g_main__init_A_const_61 *lang.Var

var A_arbace_a2g_main__init_A_const_62 any

var A_arbace_a2g_main__init_A_const_63 *lang.Var

var A_arbace_a2g_main__init_A_const_64 any

var A_arbace_a2g_main__init_A_const_65 any

var A_arbace_a2g_main__init_A_const_66 *lang.Var

var A_arbace_a2g_main__init_A_const_67 any

var A_arbace_a2g_main__init_A_const_68 *lang.Var

var A_arbace_a2g_main__init_A_const_69 any

var A_arbace_a2g_main__init_A_const_70 *lang.Var

var A_arbace_a2g_main__init_A_const_71 any

var A_arbace_a2g_main__init_A_init jrt.ClassInit

func A_arbace_a2g_main__init_A_Init() { if !A_arbace_a2g_main__init_A_init.Done() { A_arbace_a2g_main__init_A_init.Run(A_arbace_a2g_main__init_A_clinit) } }

func A_arbace_a2g_main__init_A_clinit() { A_arbace_a2g_main__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_869); A_arbace_a2g_main__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_54)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_56))); A_arbace_a2g_main__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_56)); A_arbace_a2g_main__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_main__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_54, Lit_253); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_main__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_54, Lit_270); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_main__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_873).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(61).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_54, Lit_502); A_arbace_a2g_main__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_221).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_54, Lit_81); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_main__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_874).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(81).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_54, Lit_296); A_arbace_a2g_main__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_875).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_876, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(83).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_54, Lit_124); A_arbace_a2g_main__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_295).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_877).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_878, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_54, Lit_419); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_main__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_879)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_356).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_880, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_54, Lit_111); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_main__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_881).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_882, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_54, Lit_457); A_arbace_a2g_main__init_A_const_21 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_883, Lit_884)).Ref(); A_arbace_a2g_main__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(131).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_885)); A_arbace_a2g_main__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_54, Lit_307); A_arbace_a2g_main__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_295).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_299).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_886, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(138).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_54, Lit_157); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_main__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_887).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_888, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(162).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_54, Lit_156); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_main__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_887).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_54, Lit_151); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_a2g_main__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_889).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_890).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(181).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_54, Lit_164); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_a2g_main__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_887).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_891).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(190).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_54, Lit_338); A_arbace_a2g_main__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_260).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_892).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(194).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_54, Lit_339); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_a2g_main__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_887).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_893).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(225).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_54, Lit_340); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_a2g_main__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_894).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_895).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(229).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_54, Lit_172); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_a2g_main__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_896).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_897)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_898).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_899, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(233).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_54, Lit_473); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_a2g_main__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_875).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_900).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_901, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(241).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_54, Lit_304); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_a2g_main__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_879)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_356).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(253).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_54, Lit_476); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_a2g_main__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_343).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_902, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(255).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_54, Lit_477); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_a2g_main__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_903, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(267).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_54, Lit_441); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_a2g_main__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_318).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_312).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_904).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_905, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(304).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_54, Lit_280); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_a2g_main__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_139).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_231).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_879).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_887).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_906).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_907, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(317).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_54, Lit_285); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_a2g_main__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_22).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_900).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_908).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_909, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(342).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_54, Lit_439); A_arbace_a2g_main__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_173).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_910).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_911).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_912).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_327).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_913, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(366).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_54, Lit_446); A_arbace_a2g_main__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_312).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_900).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_914, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(392).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_54, Lit_492); A_arbace_a2g_main__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(402).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_54, Lit_491); A_arbace_a2g_main__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_915).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_916, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(404).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_54, Lit_490); A_arbace_a2g_main__init_A_const_64 = jrt.Long_ValueOf_J__Long(100000).Ref(); A_arbace_a2g_main__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(856).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_917)); A_arbace_a2g_main__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_54, Lit_494); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_870).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_a2g_main__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_918, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(865).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_54, Lit_305); A_arbace_a2g_main__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_915).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Lit_919, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(874).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)); A_arbace_a2g_main__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_54, Lit_920); A_arbace_a2g_main__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_871).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_921).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_221).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), jrt.Integer_ValueOf_I__Integer(907).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(), Lit_872)) }

func A_arbace_a2g_main__init_A_New() *A_arbace_a2g_main__init_A { A_arbace_a2g_main__init_A_Init(); t := &A_arbace_a2g_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_main__init_A) Ctor() {}

func (t *A_arbace_a2g_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_main__init_A_class }

func (t *A_arbace_a2g_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_main__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_main__init_A); return ok }

func A_arbace_a2g_main__init_A_Cast(x any) *A_arbace_a2g_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_main__init_A_class)) }; return v }
