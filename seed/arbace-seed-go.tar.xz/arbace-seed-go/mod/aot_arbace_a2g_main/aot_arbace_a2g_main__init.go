//line aot_arbace_a2g_main__init.ae:1
package aot_arbace_a2g_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_main__init_A_Unit0__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_a2g_main__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_main__init_A_const_1) }
//line :1:1
func A_arbace_a2g_main__init_A_Unit1__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_main__init_A_Unit2__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_363, false); A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_main__init_A_Unit3__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_main__init_A_const_1)).Equals_O__Z(A_arbace_a2g_main__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_main_eval1844000008_fn__1844000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_main_eval1844000008_fn__1844000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_364, false); A_arbace_a2g_main_eval1844000008_fn__1844000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_main__init_A_Load__O() any { A_arbace_a2g_main__init_A_Init(); A_arbace_a2g_main__init_A_Unit0__O(); A_arbace_a2g_main__init_A_Unit1__O(); A_arbace_a2g_main__init_A_Unit2__O(); A_arbace_a2g_main__init_A_Unit3__O(); A_arbace_a2g_main__init_A_Unit4__O(); A_arbace_a2g_main__init_A_Unit5__O(); A_arbace_a2g_main__init_A_Unit6__O(); A_arbace_a2g_main__init_A_Unit7__O(); A_arbace_a2g_main__init_A_Unit8__O(); A_arbace_a2g_main__init_A_Unit9__O(); A_arbace_a2g_main__init_A_Unit10__O(); A_arbace_a2g_main__init_A_Unit11__O(); A_arbace_a2g_main__init_A_Unit12__O(); A_arbace_a2g_main__init_A_Unit13__O(); A_arbace_a2g_main__init_A_Unit14__O(); A_arbace_a2g_main__init_A_Unit15__O(); A_arbace_a2g_main__init_A_Unit16__O(); A_arbace_a2g_main__init_A_Unit17__O(); A_arbace_a2g_main__init_A_Unit18__O(); A_arbace_a2g_main__init_A_Unit19__O(); A_arbace_a2g_main__init_A_Unit20__O(); A_arbace_a2g_main__init_A_Unit21__O(); A_arbace_a2g_main__init_A_Unit22__O(); A_arbace_a2g_main__init_A_Unit23__O(); A_arbace_a2g_main__init_A_Unit24__O(); A_arbace_a2g_main__init_A_Unit25__O(); A_arbace_a2g_main__init_A_Unit26__O(); A_arbace_a2g_main__init_A_Unit27__O(); A_arbace_a2g_main__init_A_Unit28__O(); A_arbace_a2g_main__init_A_Unit29__O(); A_arbace_a2g_main__init_A_Unit30__O(); A_arbace_a2g_main__init_A_Unit31__O(); A_arbace_a2g_main__init_A_Unit32__O(); A_arbace_a2g_main__init_A_Unit33__O(); A_arbace_a2g_main__init_A_Unit34__O(); A_arbace_a2g_main__init_A_Unit35__O(); A_arbace_a2g_main__init_A_Unit36__O(); return nil }






















































func A_arbace_a2g_main__init_A_Unit4__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_4; var tmp2 any = A_arbace_a2g_main_now_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_main_now_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_365, false); A_arbace_a2g_main_now_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_5)); return A_arbace_a2g_main__init_A_const_4 }
func A_arbace_a2g_main__init_A_Unit5__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(61, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_6; var tmp2 any = A_arbace_a2g_main_secs_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_main_secs_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_366, false); A_arbace_a2g_main_secs_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_7)); return A_arbace_a2g_main__init_A_const_6 }

func A_arbace_a2g_main__init_A_Unit6__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_8; var tmp2 any = A_arbace_a2g_main_parse_args_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_main_parse_args_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_367, false); A_arbace_a2g_main_parse_args_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_9)); return A_arbace_a2g_main__init_A_const_8 }

















func A_arbace_a2g_main__init_A_Unit7__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_10; var tmp2 any = A_arbace_a2g_main_internal_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_main_internal_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_368, false); A_arbace_a2g_main_internal_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_11)); return A_arbace_a2g_main__init_A_const_10 }

func A_arbace_a2g_main__init_A_Unit8__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_12; var tmp2 any = A_arbace_a2g_main_manifest_classes_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_main_manifest_classes_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_369, false); A_arbace_a2g_main_manifest_classes_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_13)); return A_arbace_a2g_main__init_A_const_12 }







func A_arbace_a2g_main__init_A_Unit9__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_14; var tmp2 any = A_arbace_a2g_main_jrt_classes_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_main_jrt_classes_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_370, false); A_arbace_a2g_main_jrt_classes_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_15)); return A_arbace_a2g_main__init_A_const_14 }







func A_arbace_a2g_main__init_A_Unit10__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_16; var tmp2 any = A_arbace_a2g_main_repl_visible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_main_repl_visible_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_371, false); A_arbace_a2g_main_repl_visible_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_17)); return A_arbace_a2g_main__init_A_const_16 }











func A_arbace_a2g_main__init_A_Unit11__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_18; var tmp2 any = A_arbace_a2g_main_root_keys_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_main_root_keys_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_372, false); A_arbace_a2g_main_root_keys_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_19)); return A_arbace_a2g_main__init_A_const_18 }



















func A_arbace_a2g_main__init_A_Unit12__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); A_arbace_a2g_main__init_A_const_20.BindRoot_O__V(A_arbace_a2g_main__init_A_const_21); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_22)); return A_arbace_a2g_main__init_A_const_20 }






func A_arbace_a2g_main__init_A_Unit13__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_23; var tmp2 any = A_arbace_a2g_main_standin_roots_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_main_standin_roots_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_373, false); A_arbace_a2g_main_standin_roots_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_24)); return A_arbace_a2g_main__init_A_const_23 }























func A_arbace_a2g_main__init_A_Unit14__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_25; var tmp2 any = A_arbace_a2g_main_form_names_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_main_form_names_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_374, false); A_arbace_a2g_main_form_names_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_26)); return A_arbace_a2g_main__init_A_const_25 }










func A_arbace_a2g_main__init_A_Unit15__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_27; var tmp2 any = A_arbace_a2g_main_method_recv_type_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_main_method_recv_type_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_375, false); A_arbace_a2g_main_method_recv_type_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_28)); return A_arbace_a2g_main__init_A_const_27 }







func A_arbace_a2g_main__init_A_Unit16__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(181, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_29; var tmp2 any = A_arbace_a2g_main_mentions_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_main_mentions_QMARK__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_376, false); A_arbace_a2g_main_mentions_QMARK__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_30)); return A_arbace_a2g_main__init_A_const_29 }








func A_arbace_a2g_main__init_A_Unit17__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_31; var tmp2 any = A_arbace_a2g_main_filter_init_body_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_main_filter_init_body_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_377, false); A_arbace_a2g_main_filter_init_body_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_32)); return A_arbace_a2g_main__init_A_const_31 }



func A_arbace_a2g_main__init_A_Unit18__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(194, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_33; var tmp2 any = A_arbace_a2g_main_filter_standins_STAR__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_main_filter_standins_STAR__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_378, false); A_arbace_a2g_main_filter_standins_STAR__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_34)); return A_arbace_a2g_main__init_A_const_33 }






























func A_arbace_a2g_main__init_A_Unit19__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(225, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_35; var tmp2 any = A_arbace_a2g_main_write_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_main_write_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_379, false); A_arbace_a2g_main_write_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_36)); return A_arbace_a2g_main__init_A_const_35 }



func A_arbace_a2g_main__init_A_Unit20__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(229, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_37; var tmp2 any = A_arbace_a2g_main_copy_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_main_copy_file_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_380, false); A_arbace_a2g_main_copy_file_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_38)); return A_arbace_a2g_main__init_A_const_37 }



func A_arbace_a2g_main__init_A_Unit21__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(233, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_39; var tmp2 any = A_arbace_a2g_main_resource_file_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_a2g_main_resource_file_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_381, false); A_arbace_a2g_main_resource_file_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_40)); return A_arbace_a2g_main__init_A_const_39 }







func A_arbace_a2g_main__init_A_Unit22__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(241, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_41; var tmp2 any = A_arbace_a2g_main_write_resources_BANG__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_a2g_main_write_resources_BANG__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_382, false); A_arbace_a2g_main_write_resources_BANG__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_42)); return A_arbace_a2g_main__init_A_const_41 }











func A_arbace_a2g_main__init_A_Unit23__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(253, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_43; var tmp2 any = A_arbace_a2g_main_top_of_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_a2g_main_top_of_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_383, false); A_arbace_a2g_main_top_of_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_44)); return A_arbace_a2g_main__init_A_const_43 }

func A_arbace_a2g_main__init_A_Unit24__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_45; var tmp2 any = A_arbace_a2g_main_program_package_forms_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_a2g_main_program_package_forms_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_384, false); A_arbace_a2g_main_program_package_forms_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_46)); return A_arbace_a2g_main__init_A_const_45 }











func A_arbace_a2g_main__init_A_Unit25__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_47; var tmp2 any = A_arbace_a2g_main_program_main_forms_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_main_program_main_forms_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_385, false); A_arbace_a2g_main_program_main_forms_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_48)); return A_arbace_a2g_main__init_A_const_47 }




































func A_arbace_a2g_main__init_A_Unit26__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(304, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_49; var tmp2 any = A_arbace_a2g_main_source_top_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_a2g_main_source_top_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_386, false); A_arbace_a2g_main_source_top_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_50)); return A_arbace_a2g_main__init_A_const_49 }












func A_arbace_a2g_main__init_A_Unit27__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(317, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_51; var tmp2 any = A_arbace_a2g_main_apart_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_a2g_main_apart_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_387, false); A_arbace_a2g_main_apart_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_52)); return A_arbace_a2g_main__init_A_const_51 }
























func A_arbace_a2g_main__init_A_Unit28__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(342, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_53; var tmp2 any = A_arbace_a2g_main_merge_apart_BANG__A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_a2g_main_merge_apart_BANG__A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_388, false); A_arbace_a2g_main_merge_apart_BANG__A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_54)); return A_arbace_a2g_main__init_A_const_53 }























func A_arbace_a2g_main__init_A_Unit29__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(366, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_55; var tmp2 any = A_arbace_a2g_main_translate_classes_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_a2g_main_translate_classes_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_389, false); A_arbace_a2g_main_translate_classes_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_56)); return A_arbace_a2g_main__init_A_const_55 }

























func A_arbace_a2g_main__init_A_Unit30__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(392, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_57; var tmp2 any = A_arbace_a2g_main_registrations_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_a2g_main_registrations_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_390, false); A_arbace_a2g_main_registrations_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_58)); return A_arbace_a2g_main__init_A_const_57 }




















func A_arbace_a2g_main__init_A_Unit31__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(413, 1); A_arbace_a2g_main__init_A_const_59.BindRoot_O__V(Lit_391); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_60)); return A_arbace_a2g_main__init_A_const_59 }

func A_arbace_a2g_main__init_A_Unit32__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(415, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_61; var tmp2 any = A_arbace_a2g_main_run_STAR__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_a2g_main_run_STAR__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_392, false); A_arbace_a2g_main_run_STAR__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_62)); return A_arbace_a2g_main__init_A_const_61 }



































































































































































































































































































































































































































































func A_arbace_a2g_main__init_A_Unit33__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(867, 1); A_arbace_a2g_main__init_A_const_63.BindRoot_O__V(A_arbace_a2g_main__init_A_const_64); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_63; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_65)); return A_arbace_a2g_main__init_A_const_63 }








func A_arbace_a2g_main__init_A_Unit34__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(876, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_66; var tmp2 any = A_arbace_a2g_main_advance_ids_BANG__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_a2g_main_advance_ids_BANG__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_393, false); A_arbace_a2g_main_advance_ids_BANG__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_67)); return A_arbace_a2g_main__init_A_const_66 }








func A_arbace_a2g_main__init_A_Unit35__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(885, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_68; var tmp2 any = A_arbace_a2g_main_run_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_a2g_main_run_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_394, false); A_arbace_a2g_main_run_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_69)); return A_arbace_a2g_main__init_A_const_68 }
































func A_arbace_a2g_main__init_A_Unit36__O() any { A_arbace_a2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(918, 1); var tmp1 *lang.Var = A_arbace_a2g_main__init_A_const_70; var tmp2 any = A_arbace_a2g_main__main_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_a2g_main__main_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_395, true); A_arbace_a2g_main__main_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_a2g_main__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_main__init_A_const_71)); return A_arbace_a2g_main__init_A_const_70 }



type A_arbace_a2g_main__init_A struct{ jrt.Object }

var A_arbace_a2g_main__init_A_const_pool *jrt.RefArray

var A_arbace_a2g_main__init_A_const_0 *lang.Var

var A_arbace_a2g_main__init_A_const_1 any

var A_arbace_a2g_main__init_A_const_2 any

var A_arbace_a2g_main__init_A_const_3 any

var A_arbace_a2g_main__init_A_const_4 *lang.Var

var A_arbace_a2g_main__init_A_const_5 any

var A_arbace_a2g_main__init_A_const_6 *lang.Var

var A_arbace_a2g_main__init_A_const_7 any

var A_arbace_a2g_main__init_A_const_8 *lang.Var

var A_arbace_a2g_main__init_A_const_9 any

var A_arbace_a2g_main__init_A_const_10 *lang.Var

var A_arbace_a2g_main__init_A_const_11 any

var A_arbace_a2g_main__init_A_const_12 *lang.Var

var A_arbace_a2g_main__init_A_const_13 any

var A_arbace_a2g_main__init_A_const_14 *lang.Var

var A_arbace_a2g_main__init_A_const_15 any

var A_arbace_a2g_main__init_A_const_16 *lang.Var

var A_arbace_a2g_main__init_A_const_17 any

var A_arbace_a2g_main__init_A_const_18 *lang.Var

var A_arbace_a2g_main__init_A_const_19 any

var A_arbace_a2g_main__init_A_const_20 *lang.Var

var A_arbace_a2g_main__init_A_const_21 any

var A_arbace_a2g_main__init_A_const_22 any

var A_arbace_a2g_main__init_A_const_23 *lang.Var

var A_arbace_a2g_main__init_A_const_24 any

var A_arbace_a2g_main__init_A_const_25 *lang.Var

var A_arbace_a2g_main__init_A_const_26 any

var A_arbace_a2g_main__init_A_const_27 *lang.Var

var A_arbace_a2g_main__init_A_const_28 any

var A_arbace_a2g_main__init_A_const_29 *lang.Var

var A_arbace_a2g_main__init_A_const_30 any

var A_arbace_a2g_main__init_A_const_31 *lang.Var

var A_arbace_a2g_main__init_A_const_32 any

var A_arbace_a2g_main__init_A_const_33 *lang.Var

var A_arbace_a2g_main__init_A_const_34 any

var A_arbace_a2g_main__init_A_const_35 *lang.Var

var A_arbace_a2g_main__init_A_const_36 any

var A_arbace_a2g_main__init_A_const_37 *lang.Var

var A_arbace_a2g_main__init_A_const_38 any

var A_arbace_a2g_main__init_A_const_39 *lang.Var

var A_arbace_a2g_main__init_A_const_40 any

var A_arbace_a2g_main__init_A_const_41 *lang.Var

var A_arbace_a2g_main__init_A_const_42 any

var A_arbace_a2g_main__init_A_const_43 *lang.Var

var A_arbace_a2g_main__init_A_const_44 any

var A_arbace_a2g_main__init_A_const_45 *lang.Var

var A_arbace_a2g_main__init_A_const_46 any

var A_arbace_a2g_main__init_A_const_47 *lang.Var

var A_arbace_a2g_main__init_A_const_48 any

var A_arbace_a2g_main__init_A_const_49 *lang.Var

var A_arbace_a2g_main__init_A_const_50 any

var A_arbace_a2g_main__init_A_const_51 *lang.Var

var A_arbace_a2g_main__init_A_const_52 any

var A_arbace_a2g_main__init_A_const_53 *lang.Var

var A_arbace_a2g_main__init_A_const_54 any

var A_arbace_a2g_main__init_A_const_55 *lang.Var

var A_arbace_a2g_main__init_A_const_56 any

var A_arbace_a2g_main__init_A_const_57 *lang.Var

var A_arbace_a2g_main__init_A_const_58 any

var A_arbace_a2g_main__init_A_const_59 *lang.Var

var A_arbace_a2g_main__init_A_const_60 any

var A_arbace_a2g_main__init_A_const_61 *lang.Var

var A_arbace_a2g_main__init_A_const_62 any

var A_arbace_a2g_main__init_A_const_63 *lang.Var

var A_arbace_a2g_main__init_A_const_64 any

var A_arbace_a2g_main__init_A_const_65 any

var A_arbace_a2g_main__init_A_const_66 *lang.Var

var A_arbace_a2g_main__init_A_const_67 any

var A_arbace_a2g_main__init_A_const_68 *lang.Var

var A_arbace_a2g_main__init_A_const_69 any

var A_arbace_a2g_main__init_A_const_70 *lang.Var

var A_arbace_a2g_main__init_A_const_71 any

var A_arbace_a2g_main__init_A_init jrt.ClassInit

func A_arbace_a2g_main__init_A_Init() { if !A_arbace_a2g_main__init_A_init.Done() { A_arbace_a2g_main__init_A_init.Run(A_arbace_a2g_main__init_A_clinit) } }

func A_arbace_a2g_main__init_A_clinit() { A_arbace_a2g_main__init_A_clinit_p0(); A_arbace_a2g_main__init_A_clinit_p1(); A_arbace_a2g_main__init_A_clinit_p2(); A_arbace_a2g_main__init_A_clinit_p3(); A_arbace_a2g_main__init_A_clinit_p4(); A_arbace_a2g_main__init_A_clinit_p5() }

func A_arbace_a2g_main__init_A_clinit_p0() { A_arbace_a2g_main__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_362, 120); A_arbace_a2g_main__init_A_const_0 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[48]); A_arbace_a2g_main__init_A_const_1 = A_arbace_a2g_main__init_A_const_pool.A[49]; A_arbace_a2g_main__init_A_const_2 = A_arbace_a2g_main__init_A_const_pool.A[50]; A_arbace_a2g_main__init_A_const_3 = A_arbace_a2g_main__init_A_const_pool.A[51]; A_arbace_a2g_main__init_A_const_4 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[52]); A_arbace_a2g_main__init_A_const_5 = A_arbace_a2g_main__init_A_const_pool.A[53]; A_arbace_a2g_main__init_A_const_6 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[54]); A_arbace_a2g_main__init_A_const_7 = A_arbace_a2g_main__init_A_const_pool.A[55]; A_arbace_a2g_main__init_A_const_8 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[56]); A_arbace_a2g_main__init_A_const_9 = A_arbace_a2g_main__init_A_const_pool.A[57]; A_arbace_a2g_main__init_A_const_10 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[58]); A_arbace_a2g_main__init_A_const_11 = A_arbace_a2g_main__init_A_const_pool.A[59]; A_arbace_a2g_main__init_A_const_12 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[60]) }

func A_arbace_a2g_main__init_A_clinit_p1() { A_arbace_a2g_main__init_A_const_13 = A_arbace_a2g_main__init_A_const_pool.A[61]; A_arbace_a2g_main__init_A_const_14 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[62]); A_arbace_a2g_main__init_A_const_15 = A_arbace_a2g_main__init_A_const_pool.A[63]; A_arbace_a2g_main__init_A_const_16 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[64]); A_arbace_a2g_main__init_A_const_17 = A_arbace_a2g_main__init_A_const_pool.A[65]; A_arbace_a2g_main__init_A_const_18 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[66]); A_arbace_a2g_main__init_A_const_19 = A_arbace_a2g_main__init_A_const_pool.A[67]; A_arbace_a2g_main__init_A_const_20 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[68]); A_arbace_a2g_main__init_A_const_21 = A_arbace_a2g_main__init_A_const_pool.A[69]; A_arbace_a2g_main__init_A_const_22 = A_arbace_a2g_main__init_A_const_pool.A[70]; A_arbace_a2g_main__init_A_const_23 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[71]); A_arbace_a2g_main__init_A_const_24 = A_arbace_a2g_main__init_A_const_pool.A[72]; A_arbace_a2g_main__init_A_const_25 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[73]); A_arbace_a2g_main__init_A_const_26 = A_arbace_a2g_main__init_A_const_pool.A[74] }

func A_arbace_a2g_main__init_A_clinit_p2() { A_arbace_a2g_main__init_A_const_27 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[75]); A_arbace_a2g_main__init_A_const_28 = A_arbace_a2g_main__init_A_const_pool.A[76]; A_arbace_a2g_main__init_A_const_29 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[77]); A_arbace_a2g_main__init_A_const_30 = A_arbace_a2g_main__init_A_const_pool.A[78]; A_arbace_a2g_main__init_A_const_31 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[79]); A_arbace_a2g_main__init_A_const_32 = A_arbace_a2g_main__init_A_const_pool.A[80]; A_arbace_a2g_main__init_A_const_33 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[81]); A_arbace_a2g_main__init_A_const_34 = A_arbace_a2g_main__init_A_const_pool.A[82]; A_arbace_a2g_main__init_A_const_35 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[83]); A_arbace_a2g_main__init_A_const_36 = A_arbace_a2g_main__init_A_const_pool.A[84]; A_arbace_a2g_main__init_A_const_37 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[85]); A_arbace_a2g_main__init_A_const_38 = A_arbace_a2g_main__init_A_const_pool.A[86]; A_arbace_a2g_main__init_A_const_39 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[87]) }

func A_arbace_a2g_main__init_A_clinit_p3() { A_arbace_a2g_main__init_A_const_40 = A_arbace_a2g_main__init_A_const_pool.A[88]; A_arbace_a2g_main__init_A_const_41 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[89]); A_arbace_a2g_main__init_A_const_42 = A_arbace_a2g_main__init_A_const_pool.A[90]; A_arbace_a2g_main__init_A_const_43 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[91]); A_arbace_a2g_main__init_A_const_44 = A_arbace_a2g_main__init_A_const_pool.A[92]; A_arbace_a2g_main__init_A_const_45 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[93]); A_arbace_a2g_main__init_A_const_46 = A_arbace_a2g_main__init_A_const_pool.A[94]; A_arbace_a2g_main__init_A_const_47 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[95]); A_arbace_a2g_main__init_A_const_48 = A_arbace_a2g_main__init_A_const_pool.A[96]; A_arbace_a2g_main__init_A_const_49 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[97]); A_arbace_a2g_main__init_A_const_50 = A_arbace_a2g_main__init_A_const_pool.A[98]; A_arbace_a2g_main__init_A_const_51 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[99]); A_arbace_a2g_main__init_A_const_52 = A_arbace_a2g_main__init_A_const_pool.A[100] }

func A_arbace_a2g_main__init_A_clinit_p4() { A_arbace_a2g_main__init_A_const_53 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[101]); A_arbace_a2g_main__init_A_const_54 = A_arbace_a2g_main__init_A_const_pool.A[102]; A_arbace_a2g_main__init_A_const_55 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[103]); A_arbace_a2g_main__init_A_const_56 = A_arbace_a2g_main__init_A_const_pool.A[104]; A_arbace_a2g_main__init_A_const_57 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[105]); A_arbace_a2g_main__init_A_const_58 = A_arbace_a2g_main__init_A_const_pool.A[106]; A_arbace_a2g_main__init_A_const_59 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[107]); A_arbace_a2g_main__init_A_const_60 = A_arbace_a2g_main__init_A_const_pool.A[108]; A_arbace_a2g_main__init_A_const_61 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[109]); A_arbace_a2g_main__init_A_const_62 = A_arbace_a2g_main__init_A_const_pool.A[110]; A_arbace_a2g_main__init_A_const_63 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[111]); A_arbace_a2g_main__init_A_const_64 = A_arbace_a2g_main__init_A_const_pool.A[112]; A_arbace_a2g_main__init_A_const_65 = A_arbace_a2g_main__init_A_const_pool.A[113] }

func A_arbace_a2g_main__init_A_clinit_p5() { A_arbace_a2g_main__init_A_const_66 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[114]); A_arbace_a2g_main__init_A_const_67 = A_arbace_a2g_main__init_A_const_pool.A[115]; A_arbace_a2g_main__init_A_const_68 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[116]); A_arbace_a2g_main__init_A_const_69 = A_arbace_a2g_main__init_A_const_pool.A[117]; A_arbace_a2g_main__init_A_const_70 = lang.Var_Cast(A_arbace_a2g_main__init_A_const_pool.A[118]); A_arbace_a2g_main__init_A_const_71 = A_arbace_a2g_main__init_A_const_pool.A[119] }

func A_arbace_a2g_main__init_A_New() *A_arbace_a2g_main__init_A { A_arbace_a2g_main__init_A_Init(); t := &A_arbace_a2g_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_main__init_A) Ctor() {}

func (t *A_arbace_a2g_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_main__init_A_class }

func (t *A_arbace_a2g_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_main__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_main__init_A); return ok }

func A_arbace_a2g_main__init_A_Cast(x any) *A_arbace_a2g_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_main__init_A_class)) }; return v }
