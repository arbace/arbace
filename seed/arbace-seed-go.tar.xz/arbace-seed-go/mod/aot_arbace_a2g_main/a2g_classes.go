//line a2g_classes.ae:1
package aot_arbace_a2g_main

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_A_New()}; return nil }

var A_arbace_a2g_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_main_A_new}

var A_arbace_a2g_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_A"})

func init() { i := A_arbace_a2g_main_A_class.Info(); i.IsInstance = A_arbace_a2g_main_A_InstanceOf; i.Init = A_arbace_a2g_main_A_Init; i.Table = A_arbace_a2g_main_A_members; jrt.RegisterGoType(A_arbace_a2g_main_A_class, reflect.TypeFor[A_arbace_a2g_main_A]()) }

func A_arbace_a2g_main__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main__main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main__main_A_New()}; return nil }

func A_arbace_a2g_main__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main__main_A_fn_class)}; return nil }

var A_arbace_a2g_main__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main__main_A_invoke, New: A_arbace_a2g_main__main_A_new, Get: A_arbace_a2g_main__main_A_get}

var A_arbace_a2g_main__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "_main", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main__main_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main__main_A_class.Info(); i.IsInstance = A_arbace_a2g_main__main_A_InstanceOf; i.Init = A_arbace_a2g_main__main_A_Init; i.Table = A_arbace_a2g_main__main_A_members; jrt.RegisterGoType(A_arbace_a2g_main__main_A_class, reflect.TypeFor[A_arbace_a2g_main__main_A]()) }

func A_arbace_a2g_main_advance_ids_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_advance_ids_BANG__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_advance_ids_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_advance_ids_BANG__A_New()}; return nil }

func A_arbace_a2g_main_advance_ids_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_advance_ids_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_main_advance_ids_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_advance_ids_BANG__A_invoke, New: A_arbace_a2g_main_advance_ids_BANG__A_new, Get: A_arbace_a2g_main_advance_ids_BANG__A_get}

var A_arbace_a2g_main_advance_ids_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$advance_ids_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "advance_ids_BANG_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_advance_ids_BANG__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_advance_ids_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_main_advance_ids_BANG__A_InstanceOf; i.Init = A_arbace_a2g_main_advance_ids_BANG__A_Init; i.Table = A_arbace_a2g_main_advance_ids_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_main_advance_ids_BANG__A_class, reflect.TypeFor[A_arbace_a2g_main_advance_ids_BANG__A]()) }

func A_arbace_a2g_main_apart_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_apart_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_main_apart_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_apart_A_New()}; return nil }

func A_arbace_a2g_main_apart_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_apart_A_fn_class)}; return nil }

var A_arbace_a2g_main_apart_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_apart_A_invoke, New: A_arbace_a2g_main_apart_A_new, Get: A_arbace_a2g_main_apart_A_get}

var A_arbace_a2g_main_apart_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$apart", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "apart", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_apart_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_apart_A_class.Info(); i.IsInstance = A_arbace_a2g_main_apart_A_InstanceOf; i.Init = A_arbace_a2g_main_apart_A_Init; i.Table = A_arbace_a2g_main_apart_A_members; jrt.RegisterGoType(A_arbace_a2g_main_apart_A_class, reflect.TypeFor[A_arbace_a2g_main_apart_A]()) }

func A_arbace_a2g_main_apart_fn__1844000199_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_apart_fn__1844000199_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_apart_fn__1844000199_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_apart_fn__1844000199_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_apart_fn__1844000199_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_apart_fn__1844000199_A_fn_class)}; return nil }

var A_arbace_a2g_main_apart_fn__1844000199_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_apart_fn__1844000199_A_invoke, New: A_arbace_a2g_main_apart_fn__1844000199_A_new, Get: A_arbace_a2g_main_apart_fn__1844000199_A_get}

var A_arbace_a2g_main_apart_fn__1844000199_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$apart$fn__1844000199", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_apart_A_class, Simple: "fn__1844000199", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_apart_fn__1844000199_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_apart_fn__1844000199_A_class.Info(); i.IsInstance = A_arbace_a2g_main_apart_fn__1844000199_A_InstanceOf; i.Init = A_arbace_a2g_main_apart_fn__1844000199_A_Init; i.Table = A_arbace_a2g_main_apart_fn__1844000199_A_members; jrt.RegisterGoType(A_arbace_a2g_main_apart_fn__1844000199_A_class, reflect.TypeFor[A_arbace_a2g_main_apart_fn__1844000199_A]()) }

func A_arbace_a2g_main_copy_file_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_copy_file_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_copy_file_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_copy_file_BANG__A_New()}; return nil }

func A_arbace_a2g_main_copy_file_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_copy_file_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_main_copy_file_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_copy_file_BANG__A_invoke, New: A_arbace_a2g_main_copy_file_BANG__A_new, Get: A_arbace_a2g_main_copy_file_BANG__A_get}

var A_arbace_a2g_main_copy_file_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$copy_file_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "copy_file_BANG_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_copy_file_BANG__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_copy_file_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_main_copy_file_BANG__A_InstanceOf; i.Init = A_arbace_a2g_main_copy_file_BANG__A_Init; i.Table = A_arbace_a2g_main_copy_file_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_main_copy_file_BANG__A_class, reflect.TypeFor[A_arbace_a2g_main_copy_file_BANG__A]()) }

func A_arbace_a2g_main_eval1844000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_eval1844000004_A_New()}; return nil }

var A_arbace_a2g_main_eval1844000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_main_eval1844000004_A_new}

var A_arbace_a2g_main_eval1844000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$eval1844000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_main_A_class, Simple: "eval1844000004", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_eval1844000004_A"})

func init() { i := A_arbace_a2g_main_eval1844000004_A_class.Info(); i.IsInstance = A_arbace_a2g_main_eval1844000004_A_InstanceOf; i.Table = A_arbace_a2g_main_eval1844000004_A_members; jrt.RegisterGoType(A_arbace_a2g_main_eval1844000004_A_class, reflect.TypeFor[A_arbace_a2g_main_eval1844000004_A]()) }

func A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_New()}; return nil }

func A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_fn_class)}; return nil }

var A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_invoke, New: A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_new, Get: A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_get}

var A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$eval1844000004$loading__1927001464__auto____1844000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_eval1844000004_A_class, Simple: "loading__1927001464__auto____1844000005", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_class.Info(); i.IsInstance = A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_InstanceOf; i.Init = A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_Init; i.Table = A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_members; jrt.RegisterGoType(A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A_class, reflect.TypeFor[A_arbace_a2g_main_eval1844000004_loading__1927001464__auto____1844000005_A]()) }

func A_arbace_a2g_main_eval1844000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_eval1844000008_A_New()}; return nil }

var A_arbace_a2g_main_eval1844000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_main_eval1844000008_A_new}

var A_arbace_a2g_main_eval1844000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$eval1844000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_main_A_class, Simple: "eval1844000008", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_eval1844000008_A"})

func init() { i := A_arbace_a2g_main_eval1844000008_A_class.Info(); i.IsInstance = A_arbace_a2g_main_eval1844000008_A_InstanceOf; i.Table = A_arbace_a2g_main_eval1844000008_A_members; jrt.RegisterGoType(A_arbace_a2g_main_eval1844000008_A_class, reflect.TypeFor[A_arbace_a2g_main_eval1844000008_A]()) }

func A_arbace_a2g_main_eval1844000008_fn__1844000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_eval1844000008_fn__1844000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_eval1844000008_fn__1844000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_eval1844000008_fn__1844000009_A_New()}; return nil }

func A_arbace_a2g_main_eval1844000008_fn__1844000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_eval1844000008_fn__1844000009_A_fn_class)}; return nil }

var A_arbace_a2g_main_eval1844000008_fn__1844000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_eval1844000008_fn__1844000009_A_invoke, New: A_arbace_a2g_main_eval1844000008_fn__1844000009_A_new, Get: A_arbace_a2g_main_eval1844000008_fn__1844000009_A_get}

var A_arbace_a2g_main_eval1844000008_fn__1844000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$eval1844000008$fn__1844000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_eval1844000008_A_class, Simple: "fn__1844000009", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_eval1844000008_fn__1844000009_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_eval1844000008_fn__1844000009_A_class.Info(); i.IsInstance = A_arbace_a2g_main_eval1844000008_fn__1844000009_A_InstanceOf; i.Init = A_arbace_a2g_main_eval1844000008_fn__1844000009_A_Init; i.Table = A_arbace_a2g_main_eval1844000008_fn__1844000009_A_members; jrt.RegisterGoType(A_arbace_a2g_main_eval1844000008_fn__1844000009_A_class, reflect.TypeFor[A_arbace_a2g_main_eval1844000008_fn__1844000009_A]()) }

func A_arbace_a2g_main_filter_init_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_init_body_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_filter_init_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_init_body_A_New()}; return nil }

func A_arbace_a2g_main_filter_init_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_init_body_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_init_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_init_body_A_invoke, New: A_arbace_a2g_main_filter_init_body_A_new, Get: A_arbace_a2g_main_filter_init_body_A_get}

var A_arbace_a2g_main_filter_init_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_init_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "filter_init_body", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_init_body_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_init_body_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_init_body_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_init_body_A_Init; i.Table = A_arbace_a2g_main_filter_init_body_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_init_body_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_init_body_A]()) }

func A_arbace_a2g_main_filter_init_body_fn__1844000115_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_init_body_fn__1844000115_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_filter_init_body_fn__1844000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_init_body_fn__1844000115_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_filter_init_body_fn__1844000115_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_init_body_fn__1844000115_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_init_body_fn__1844000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_init_body_fn__1844000115_A_invoke, New: A_arbace_a2g_main_filter_init_body_fn__1844000115_A_new, Get: A_arbace_a2g_main_filter_init_body_fn__1844000115_A_get}

var A_arbace_a2g_main_filter_init_body_fn__1844000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_init_body$fn__1844000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_filter_init_body_A_class, Simple: "fn__1844000115", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_init_body_fn__1844000115_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_init_body_fn__1844000115_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_init_body_fn__1844000115_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_init_body_fn__1844000115_A_Init; i.Table = A_arbace_a2g_main_filter_init_body_fn__1844000115_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_init_body_fn__1844000115_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_init_body_fn__1844000115_A]()) }

func A_arbace_a2g_main_filter_standins_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__A_New()}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__A_new, Get: A_arbace_a2g_main_filter_standins_STAR__A_get}

var A_arbace_a2g_main_filter_standins_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "filter_standins_STAR_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__A]()) }

func A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_new, Get: A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_get}

var A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_$drop_QMARK___1844000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_filter_standins_STAR__A_class, Simple: "drop_QMARK___1844000121", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__drop_QMARK___1844000121_A]()) }

func A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_New()}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_new, Get: A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_get}

var A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_$fn__1844000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_filter_standins_STAR__A_class, Simple: "fn__1844000119", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__fn__1844000119_A]()) }

func A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_new, Get: A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_get}

var A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_$group__1844000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_filter_standins_STAR__A_class, Simple: "group__1844000124", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A]()) }

func A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_new, Get: A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_get}

var A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_$group__1844000124$fn__1844000131", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_filter_standins_STAR__group__1844000124_A_class, Simple: "fn__1844000131", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__group__1844000124_fn__1844000131_A]()) }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_new, Get: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_get}

var A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_filter_standins_STAR__A_class, Simple: "iter__1844000134__1844000138", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A]()) }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_new, Get: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_get}

var A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138$fn__1844000139", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_A_class, Simple: "fn__1844000139", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A]()) }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_fn_class)}; return nil }

var A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_invoke, New: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_new, Get: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_get}

var A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$filter_standins_STAR_$iter__1844000134__1844000138$fn__1844000139$fn__1844000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_A_class, Simple: "fn__1844000140", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_class.Info(); i.IsInstance = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_InstanceOf; i.Init = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_Init; i.Table = A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_members; jrt.RegisterGoType(A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A_class, reflect.TypeFor[A_arbace_a2g_main_filter_standins_STAR__iter__1844000134__1844000138_fn__1844000139_fn__1844000140_A]()) }

func A_arbace_a2g_main_form_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_form_names_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_form_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_form_names_A_New()}; return nil }

func A_arbace_a2g_main_form_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_form_names_A_fn_class)}; return nil }

var A_arbace_a2g_main_form_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_form_names_A_invoke, New: A_arbace_a2g_main_form_names_A_new, Get: A_arbace_a2g_main_form_names_A_get}

var A_arbace_a2g_main_form_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$form_names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "form_names", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_form_names_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_form_names_A_class.Info(); i.IsInstance = A_arbace_a2g_main_form_names_A_InstanceOf; i.Init = A_arbace_a2g_main_form_names_A_Init; i.Table = A_arbace_a2g_main_form_names_A_members; jrt.RegisterGoType(A_arbace_a2g_main_form_names_A_class, reflect.TypeFor[A_arbace_a2g_main_form_names_A]()) }

func A_arbace_a2g_main_internal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_internal_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_internal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_internal_A_New()}; return nil }

func A_arbace_a2g_main_internal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_internal_A_fn_class)}; return nil }

var A_arbace_a2g_main_internal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_internal_A_invoke, New: A_arbace_a2g_main_internal_A_new, Get: A_arbace_a2g_main_internal_A_get}

var A_arbace_a2g_main_internal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$internal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "internal", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_internal_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_internal_A_class.Info(); i.IsInstance = A_arbace_a2g_main_internal_A_InstanceOf; i.Init = A_arbace_a2g_main_internal_A_Init; i.Table = A_arbace_a2g_main_internal_A_members; jrt.RegisterGoType(A_arbace_a2g_main_internal_A_class, reflect.TypeFor[A_arbace_a2g_main_internal_A]()) }

func A_arbace_a2g_main_jrt_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_jrt_classes_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_jrt_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_jrt_classes_A_New()}; return nil }

func A_arbace_a2g_main_jrt_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_jrt_classes_A_fn_class)}; return nil }

var A_arbace_a2g_main_jrt_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_jrt_classes_A_invoke, New: A_arbace_a2g_main_jrt_classes_A_new, Get: A_arbace_a2g_main_jrt_classes_A_get}

var A_arbace_a2g_main_jrt_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$jrt_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "jrt_classes", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_jrt_classes_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_jrt_classes_A_class.Info(); i.IsInstance = A_arbace_a2g_main_jrt_classes_A_InstanceOf; i.Init = A_arbace_a2g_main_jrt_classes_A_Init; i.Table = A_arbace_a2g_main_jrt_classes_A_members; jrt.RegisterGoType(A_arbace_a2g_main_jrt_classes_A_class, reflect.TypeFor[A_arbace_a2g_main_jrt_classes_A]()) }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_New()}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_fn_class)}; return nil }

var A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_invoke, New: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_new, Get: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_get}

var A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$jrt_classes$iter__1844000031__1844000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_jrt_classes_A_class, Simple: "iter__1844000031__1844000035", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_class.Info(); i.IsInstance = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_InstanceOf; i.Init = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_Init; i.Table = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_members; jrt.RegisterGoType(A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_class, reflect.TypeFor[A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A]()) }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_fn_class)}; return nil }

var A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_invoke, New: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_new, Get: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_get}

var A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$jrt_classes$iter__1844000031__1844000035$fn__1844000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_A_class, Simple: "fn__1844000036", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_class.Info(); i.IsInstance = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_InstanceOf; i.Init = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_Init; i.Table = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_members; jrt.RegisterGoType(A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_class, reflect.TypeFor[A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A]()) }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_fn_class)}; return nil }

var A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_invoke, New: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_new, Get: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_get}

var A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$jrt_classes$iter__1844000031__1844000035$fn__1844000036$fn__1844000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_A_class, Simple: "fn__1844000037", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_class.Info(); i.IsInstance = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_InstanceOf; i.Init = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_Init; i.Table = A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_members; jrt.RegisterGoType(A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A_class, reflect.TypeFor[A_arbace_a2g_main_jrt_classes_iter__1844000031__1844000035_fn__1844000036_fn__1844000037_A]()) }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_New()}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_fn_class)}; return nil }

var A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_invoke, New: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_new, Get: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_get}

var A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$jrt_classes$iter__1844000041__1844000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_jrt_classes_A_class, Simple: "iter__1844000041__1844000045", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_class.Info(); i.IsInstance = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_InstanceOf; i.Init = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_Init; i.Table = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_members; jrt.RegisterGoType(A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_class, reflect.TypeFor[A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A]()) }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_fn_class)}; return nil }

var A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_invoke, New: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_new, Get: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_get}

var A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$jrt_classes$iter__1844000041__1844000045$fn__1844000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_A_class, Simple: "fn__1844000046", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_class.Info(); i.IsInstance = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_InstanceOf; i.Init = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_Init; i.Table = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_members; jrt.RegisterGoType(A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_class, reflect.TypeFor[A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A]()) }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_fn_class)}; return nil }

var A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_invoke, New: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_new, Get: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_get}

var A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$jrt_classes$iter__1844000041__1844000045$fn__1844000046$fn__1844000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_A_class, Simple: "fn__1844000047", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_class.Info(); i.IsInstance = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_InstanceOf; i.Init = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_Init; i.Table = A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_members; jrt.RegisterGoType(A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A_class, reflect.TypeFor[A_arbace_a2g_main_jrt_classes_iter__1844000041__1844000045_fn__1844000046_fn__1844000047_A]()) }

func A_arbace_a2g_main_manifest_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_manifest_classes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_manifest_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_manifest_classes_A_New()}; return nil }

func A_arbace_a2g_main_manifest_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_manifest_classes_A_fn_class)}; return nil }

var A_arbace_a2g_main_manifest_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_manifest_classes_A_invoke, New: A_arbace_a2g_main_manifest_classes_A_new, Get: A_arbace_a2g_main_manifest_classes_A_get}

var A_arbace_a2g_main_manifest_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$manifest_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "manifest_classes", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_manifest_classes_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_manifest_classes_A_class.Info(); i.IsInstance = A_arbace_a2g_main_manifest_classes_A_InstanceOf; i.Init = A_arbace_a2g_main_manifest_classes_A_Init; i.Table = A_arbace_a2g_main_manifest_classes_A_members; jrt.RegisterGoType(A_arbace_a2g_main_manifest_classes_A_class, reflect.TypeFor[A_arbace_a2g_main_manifest_classes_A]()) }

func A_arbace_a2g_main_manifest_classes_fn__1844000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_manifest_classes_fn__1844000028_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_manifest_classes_fn__1844000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_manifest_classes_fn__1844000028_A_New()}; return nil }

func A_arbace_a2g_main_manifest_classes_fn__1844000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_manifest_classes_fn__1844000028_A_fn_class)}; return nil }

var A_arbace_a2g_main_manifest_classes_fn__1844000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_manifest_classes_fn__1844000028_A_invoke, New: A_arbace_a2g_main_manifest_classes_fn__1844000028_A_new, Get: A_arbace_a2g_main_manifest_classes_fn__1844000028_A_get}

var A_arbace_a2g_main_manifest_classes_fn__1844000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$manifest_classes$fn__1844000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_manifest_classes_A_class, Simple: "fn__1844000028", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_manifest_classes_fn__1844000028_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_manifest_classes_fn__1844000028_A_class.Info(); i.IsInstance = A_arbace_a2g_main_manifest_classes_fn__1844000028_A_InstanceOf; i.Init = A_arbace_a2g_main_manifest_classes_fn__1844000028_A_Init; i.Table = A_arbace_a2g_main_manifest_classes_fn__1844000028_A_members; jrt.RegisterGoType(A_arbace_a2g_main_manifest_classes_fn__1844000028_A_class, reflect.TypeFor[A_arbace_a2g_main_manifest_classes_fn__1844000028_A]()) }

func A_arbace_a2g_main_mentions_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_mentions_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_mentions_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_mentions_QMARK__A_New()}; return nil }

func A_arbace_a2g_main_mentions_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_mentions_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_main_mentions_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_mentions_QMARK__A_invoke, New: A_arbace_a2g_main_mentions_QMARK__A_new, Get: A_arbace_a2g_main_mentions_QMARK__A_get}

var A_arbace_a2g_main_mentions_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$mentions_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "mentions_QMARK_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_mentions_QMARK__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_mentions_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_main_mentions_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_main_mentions_QMARK__A_Init; i.Table = A_arbace_a2g_main_mentions_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_main_mentions_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_main_mentions_QMARK__A]()) }

func A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_mentions_QMARK__w__1844000108_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_fn_class)}; return nil }

var A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_invoke, New: A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_new, Get: A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_get}

var A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$mentions_QMARK_$w__1844000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_mentions_QMARK__A_class, Simple: "w__1844000108", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_mentions_QMARK__w__1844000108_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_class.Info(); i.IsInstance = A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_InstanceOf; i.Init = A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_Init; i.Table = A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_members; jrt.RegisterGoType(A_arbace_a2g_main_mentions_QMARK__w__1844000108_A_class, reflect.TypeFor[A_arbace_a2g_main_mentions_QMARK__w__1844000108_A]()) }

func A_arbace_a2g_main_merge_apart_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_merge_apart_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_merge_apart_BANG__A_New()}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_merge_apart_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_main_merge_apart_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_merge_apart_BANG__A_invoke, New: A_arbace_a2g_main_merge_apart_BANG__A_new, Get: A_arbace_a2g_main_merge_apart_BANG__A_get}

var A_arbace_a2g_main_merge_apart_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$merge_apart_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "merge_apart_BANG_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_merge_apart_BANG__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_merge_apart_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_main_merge_apart_BANG__A_InstanceOf; i.Init = A_arbace_a2g_main_merge_apart_BANG__A_Init; i.Table = A_arbace_a2g_main_merge_apart_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_main_merge_apart_BANG__A_class, reflect.TypeFor[A_arbace_a2g_main_merge_apart_BANG__A]()) }

func A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_New()}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_fn_class)}; return nil }

var A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_invoke, New: A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_new, Get: A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_get}

var A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$merge_apart_BANG_$conj_all__1844000204", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_merge_apart_BANG__A_class, Simple: "conj_all__1844000204", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_class.Info(); i.IsInstance = A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_InstanceOf; i.Init = A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_Init; i.Table = A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_members; jrt.RegisterGoType(A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_class, reflect.TypeFor[A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A]()) }

func A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_fn_class)}; return nil }

var A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_invoke, New: A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_new, Get: A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_get}

var A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$merge_apart_BANG_$conj_all__1844000204$fn__1844000205", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_A_class, Simple: "fn__1844000205", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_class.Info(); i.IsInstance = A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_InstanceOf; i.Init = A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_Init; i.Table = A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_members; jrt.RegisterGoType(A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A_class, reflect.TypeFor[A_arbace_a2g_main_merge_apart_BANG__conj_all__1844000204_fn__1844000205_A]()) }

func A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_fn_class)}; return nil }

var A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_invoke, New: A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_new, Get: A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_get}

var A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$merge_apart_BANG_$fn__1844000209", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_merge_apart_BANG__A_class, Simple: "fn__1844000209", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_class.Info(); i.IsInstance = A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_InstanceOf; i.Init = A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_Init; i.Table = A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_members; jrt.RegisterGoType(A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A_class, reflect.TypeFor[A_arbace_a2g_main_merge_apart_BANG__fn__1844000209_A]()) }

func A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_New_I(args[0].(int32))}; return nil }

func A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_fn_class)}; return nil }

var A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (I)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_invoke, New: A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_new, Get: A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_get}

var A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$merge_apart_BANG_$fn__1844000214", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_merge_apart_BANG__A_class, Simple: "fn__1844000214", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_class.Info(); i.IsInstance = A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_InstanceOf; i.Init = A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_Init; i.Table = A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_members; jrt.RegisterGoType(A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A_class, reflect.TypeFor[A_arbace_a2g_main_merge_apart_BANG__fn__1844000214_A]()) }

func A_arbace_a2g_main_method_recv_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_method_recv_type_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_method_recv_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_method_recv_type_A_New()}; return nil }

func A_arbace_a2g_main_method_recv_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_method_recv_type_A_fn_class)}; return nil }

var A_arbace_a2g_main_method_recv_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_method_recv_type_A_invoke, New: A_arbace_a2g_main_method_recv_type_A_new, Get: A_arbace_a2g_main_method_recv_type_A_get}

var A_arbace_a2g_main_method_recv_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$method_recv_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "method_recv_type", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_method_recv_type_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_method_recv_type_A_class.Info(); i.IsInstance = A_arbace_a2g_main_method_recv_type_A_InstanceOf; i.Init = A_arbace_a2g_main_method_recv_type_A_Init; i.Table = A_arbace_a2g_main_method_recv_type_A_members; jrt.RegisterGoType(A_arbace_a2g_main_method_recv_type_A_class, reflect.TypeFor[A_arbace_a2g_main_method_recv_type_A]()) }

func A_arbace_a2g_main_now_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_now_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_now_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_now_A_New()}; return nil }

func A_arbace_a2g_main_now_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_now_A_fn_class)}; return nil }

var A_arbace_a2g_main_now_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_now_A_invoke, New: A_arbace_a2g_main_now_A_new, Get: A_arbace_a2g_main_now_A_get}

var A_arbace_a2g_main_now_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$now", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "now", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_now_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_now_A_class.Info(); i.IsInstance = A_arbace_a2g_main_now_A_InstanceOf; i.Init = A_arbace_a2g_main_now_A_Init; i.Table = A_arbace_a2g_main_now_A_members; jrt.RegisterGoType(A_arbace_a2g_main_now_A_class, reflect.TypeFor[A_arbace_a2g_main_now_A]()) }

func A_arbace_a2g_main_parse_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_parse_args_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_parse_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_parse_args_A_New()}; return nil }

func A_arbace_a2g_main_parse_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_parse_args_A_fn_class)}; return nil }

var A_arbace_a2g_main_parse_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_parse_args_A_invoke, New: A_arbace_a2g_main_parse_args_A_new, Get: A_arbace_a2g_main_parse_args_A_get}

var A_arbace_a2g_main_parse_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$parse_args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "parse_args", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_parse_args_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_parse_args_A_class.Info(); i.IsInstance = A_arbace_a2g_main_parse_args_A_InstanceOf; i.Init = A_arbace_a2g_main_parse_args_A_Init; i.Table = A_arbace_a2g_main_parse_args_A_members; jrt.RegisterGoType(A_arbace_a2g_main_parse_args_A_class, reflect.TypeFor[A_arbace_a2g_main_parse_args_A]()) }

func A_arbace_a2g_main_program_main_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_main_forms_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_program_main_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_main_forms_A_New()}; return nil }

func A_arbace_a2g_main_program_main_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_main_forms_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_main_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_main_forms_A_invoke, New: A_arbace_a2g_main_program_main_forms_A_new, Get: A_arbace_a2g_main_program_main_forms_A_get}

var A_arbace_a2g_main_program_main_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_main_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "program_main_forms", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_main_forms_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_main_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_main_forms_A_InstanceOf; i.Init = A_arbace_a2g_main_program_main_forms_A_Init; i.Table = A_arbace_a2g_main_program_main_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_main_forms_A_class, reflect.TypeFor[A_arbace_a2g_main_program_main_forms_A]()) }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_New()}; return nil }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_invoke, New: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_new, Get: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_get}

var A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_main_forms$iter__1844000187__1844000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_program_main_forms_A_class, Simple: "iter__1844000187__1844000191", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_InstanceOf; i.Init = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_Init; i.Table = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_class, reflect.TypeFor[A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A]()) }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_invoke, New: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_new, Get: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_get}

var A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_main_forms$iter__1844000187__1844000191$fn__1844000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_A_class, Simple: "fn__1844000192", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_InstanceOf; i.Init = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_Init; i.Table = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_class, reflect.TypeFor[A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A]()) }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_invoke, New: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_new, Get: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_get}

var A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_main_forms$iter__1844000187__1844000191$fn__1844000192$fn__1844000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_A_class, Simple: "fn__1844000193", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_InstanceOf; i.Init = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_Init; i.Table = A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A_class, reflect.TypeFor[A_arbace_a2g_main_program_main_forms_iter__1844000187__1844000191_fn__1844000192_fn__1844000193_A]()) }

func A_arbace_a2g_main_program_package_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_package_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_program_package_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_package_forms_A_New()}; return nil }

func A_arbace_a2g_main_program_package_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_package_forms_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_package_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_package_forms_A_invoke, New: A_arbace_a2g_main_program_package_forms_A_new, Get: A_arbace_a2g_main_program_package_forms_A_get}

var A_arbace_a2g_main_program_package_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_package_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "program_package_forms", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_package_forms_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_package_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_package_forms_A_InstanceOf; i.Init = A_arbace_a2g_main_program_package_forms_A_Init; i.Table = A_arbace_a2g_main_program_package_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_package_forms_A_class, reflect.TypeFor[A_arbace_a2g_main_program_package_forms_A]()) }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_New()}; return nil }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_invoke, New: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_new, Get: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_get}

var A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_package_forms$iter__1844000176__1844000180", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_program_package_forms_A_class, Simple: "iter__1844000176__1844000180", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_InstanceOf; i.Init = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_Init; i.Table = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_class, reflect.TypeFor[A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A]()) }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_invoke, New: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_new, Get: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_get}

var A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_package_forms$iter__1844000176__1844000180$fn__1844000181", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_A_class, Simple: "fn__1844000181", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_InstanceOf; i.Init = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_Init; i.Table = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_class, reflect.TypeFor[A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A]()) }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_fn_class)}; return nil }

var A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_invoke, New: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_new, Get: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_get}

var A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$program_package_forms$iter__1844000176__1844000180$fn__1844000181$fn__1844000182", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_A_class, Simple: "fn__1844000182", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_class.Info(); i.IsInstance = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_InstanceOf; i.Init = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_Init; i.Table = A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_members; jrt.RegisterGoType(A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A_class, reflect.TypeFor[A_arbace_a2g_main_program_package_forms_iter__1844000176__1844000180_fn__1844000181_fn__1844000182_A]()) }

func A_arbace_a2g_main_registrations_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_registrations_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_registrations_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_registrations_A_New()}; return nil }

func A_arbace_a2g_main_registrations_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_registrations_A_fn_class)}; return nil }

var A_arbace_a2g_main_registrations_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_registrations_A_invoke, New: A_arbace_a2g_main_registrations_A_new, Get: A_arbace_a2g_main_registrations_A_get}

var A_arbace_a2g_main_registrations_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$registrations", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "registrations", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_registrations_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_registrations_A_class.Info(); i.IsInstance = A_arbace_a2g_main_registrations_A_InstanceOf; i.Init = A_arbace_a2g_main_registrations_A_Init; i.Table = A_arbace_a2g_main_registrations_A_members; jrt.RegisterGoType(A_arbace_a2g_main_registrations_A_class, reflect.TypeFor[A_arbace_a2g_main_registrations_A]()) }

func A_arbace_a2g_main_registrations_fn__1844000251_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_registrations_fn__1844000251_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_registrations_fn__1844000251_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_registrations_fn__1844000251_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_registrations_fn__1844000251_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_registrations_fn__1844000251_A_fn_class)}; return nil }

var A_arbace_a2g_main_registrations_fn__1844000251_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_registrations_fn__1844000251_A_invoke, New: A_arbace_a2g_main_registrations_fn__1844000251_A_new, Get: A_arbace_a2g_main_registrations_fn__1844000251_A_get}

var A_arbace_a2g_main_registrations_fn__1844000251_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$registrations$fn__1844000251", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_registrations_A_class, Simple: "fn__1844000251", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_registrations_fn__1844000251_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_registrations_fn__1844000251_A_class.Info(); i.IsInstance = A_arbace_a2g_main_registrations_fn__1844000251_A_InstanceOf; i.Init = A_arbace_a2g_main_registrations_fn__1844000251_A_Init; i.Table = A_arbace_a2g_main_registrations_fn__1844000251_A_members; jrt.RegisterGoType(A_arbace_a2g_main_registrations_fn__1844000251_A_class, reflect.TypeFor[A_arbace_a2g_main_registrations_fn__1844000251_A]()) }

func A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_fn_class)}; return nil }

var A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_invoke, New: A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_new, Get: A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_get}

var A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$registrations$fn__1844000251$fn__1844000255", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_registrations_fn__1844000251_A_class, Simple: "fn__1844000255", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_class.Info(); i.IsInstance = A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_InstanceOf; i.Init = A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_Init; i.Table = A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_members; jrt.RegisterGoType(A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A_class, reflect.TypeFor[A_arbace_a2g_main_registrations_fn__1844000251_fn__1844000255_A]()) }

func A_arbace_a2g_main_registrations_fn__1844000258_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_registrations_fn__1844000258_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_registrations_fn__1844000258_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_registrations_fn__1844000258_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_registrations_fn__1844000258_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_registrations_fn__1844000258_A_fn_class)}; return nil }

var A_arbace_a2g_main_registrations_fn__1844000258_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_registrations_fn__1844000258_A_invoke, New: A_arbace_a2g_main_registrations_fn__1844000258_A_new, Get: A_arbace_a2g_main_registrations_fn__1844000258_A_get}

var A_arbace_a2g_main_registrations_fn__1844000258_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$registrations$fn__1844000258", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_registrations_A_class, Simple: "fn__1844000258", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_registrations_fn__1844000258_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_registrations_fn__1844000258_A_class.Info(); i.IsInstance = A_arbace_a2g_main_registrations_fn__1844000258_A_InstanceOf; i.Init = A_arbace_a2g_main_registrations_fn__1844000258_A_Init; i.Table = A_arbace_a2g_main_registrations_fn__1844000258_A_members; jrt.RegisterGoType(A_arbace_a2g_main_registrations_fn__1844000258_A_class, reflect.TypeFor[A_arbace_a2g_main_registrations_fn__1844000258_A]()) }

func A_arbace_a2g_main_repl_visible_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_repl_visible_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_repl_visible_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_repl_visible_QMARK__A_New()}; return nil }

func A_arbace_a2g_main_repl_visible_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_repl_visible_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_main_repl_visible_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_repl_visible_QMARK__A_invoke, New: A_arbace_a2g_main_repl_visible_QMARK__A_new, Get: A_arbace_a2g_main_repl_visible_QMARK__A_get}

var A_arbace_a2g_main_repl_visible_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$repl_visible_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "repl_visible_QMARK_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_repl_visible_QMARK__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_repl_visible_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_main_repl_visible_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_main_repl_visible_QMARK__A_Init; i.Table = A_arbace_a2g_main_repl_visible_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_main_repl_visible_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_main_repl_visible_QMARK__A]()) }

func A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_fn_class)}; return nil }

var A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_invoke, New: A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_new, Get: A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_get}

var A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$repl_visible_QMARK_$fn__1844000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_repl_visible_QMARK__A_class, Simple: "fn__1844000058", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_class.Info(); i.IsInstance = A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_InstanceOf; i.Init = A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_Init; i.Table = A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_members; jrt.RegisterGoType(A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A_class, reflect.TypeFor[A_arbace_a2g_main_repl_visible_QMARK__fn__1844000058_A]()) }

func A_arbace_a2g_main_resource_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_resource_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_resource_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_resource_file_A_New()}; return nil }

func A_arbace_a2g_main_resource_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_resource_file_A_fn_class)}; return nil }

var A_arbace_a2g_main_resource_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_resource_file_A_invoke, New: A_arbace_a2g_main_resource_file_A_new, Get: A_arbace_a2g_main_resource_file_A_get}

var A_arbace_a2g_main_resource_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$resource_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "resource_file", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_resource_file_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_resource_file_A_class.Info(); i.IsInstance = A_arbace_a2g_main_resource_file_A_InstanceOf; i.Init = A_arbace_a2g_main_resource_file_A_Init; i.Table = A_arbace_a2g_main_resource_file_A_members; jrt.RegisterGoType(A_arbace_a2g_main_resource_file_A_class, reflect.TypeFor[A_arbace_a2g_main_resource_file_A]()) }

func A_arbace_a2g_main_root_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_root_keys_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_root_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_root_keys_A_New()}; return nil }

func A_arbace_a2g_main_root_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_root_keys_A_fn_class)}; return nil }

var A_arbace_a2g_main_root_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_root_keys_A_invoke, New: A_arbace_a2g_main_root_keys_A_new, Get: A_arbace_a2g_main_root_keys_A_get}

var A_arbace_a2g_main_root_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$root_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "root_keys", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_root_keys_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_root_keys_A_class.Info(); i.IsInstance = A_arbace_a2g_main_root_keys_A_InstanceOf; i.Init = A_arbace_a2g_main_root_keys_A_Init; i.Table = A_arbace_a2g_main_root_keys_A_members; jrt.RegisterGoType(A_arbace_a2g_main_root_keys_A_class, reflect.TypeFor[A_arbace_a2g_main_root_keys_A]()) }

func A_arbace_a2g_main_root_keys_fn__1844000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_root_keys_fn__1844000062_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_root_keys_fn__1844000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_root_keys_fn__1844000062_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_root_keys_fn__1844000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_root_keys_fn__1844000062_A_fn_class)}; return nil }

var A_arbace_a2g_main_root_keys_fn__1844000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_root_keys_fn__1844000062_A_invoke, New: A_arbace_a2g_main_root_keys_fn__1844000062_A_new, Get: A_arbace_a2g_main_root_keys_fn__1844000062_A_get}

var A_arbace_a2g_main_root_keys_fn__1844000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$root_keys$fn__1844000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_root_keys_A_class, Simple: "fn__1844000062", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_root_keys_fn__1844000062_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_root_keys_fn__1844000062_A_class.Info(); i.IsInstance = A_arbace_a2g_main_root_keys_fn__1844000062_A_InstanceOf; i.Init = A_arbace_a2g_main_root_keys_fn__1844000062_A_Init; i.Table = A_arbace_a2g_main_root_keys_fn__1844000062_A_members; jrt.RegisterGoType(A_arbace_a2g_main_root_keys_fn__1844000062_A_class, reflect.TypeFor[A_arbace_a2g_main_root_keys_fn__1844000062_A]()) }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_fn_class)}; return nil }

var A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_invoke, New: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_new, Get: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_get}

var A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$root_keys$iter__1844000067__1844000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_root_keys_A_class, Simple: "iter__1844000067__1844000071", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_class.Info(); i.IsInstance = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_InstanceOf; i.Init = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_Init; i.Table = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_members; jrt.RegisterGoType(A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_class, reflect.TypeFor[A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A]()) }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_fn_class)}; return nil }

var A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_invoke, New: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_new, Get: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_get}

var A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$root_keys$iter__1844000067__1844000071$fn__1844000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_A_class, Simple: "fn__1844000072", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_class.Info(); i.IsInstance = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_InstanceOf; i.Init = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_Init; i.Table = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_members; jrt.RegisterGoType(A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_class, reflect.TypeFor[A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A]()) }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_New_O_O_I_O_O(args[0], args[1], args[2].(int32), args[3], args[4])}; return nil }

func A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_fn_class)}; return nil }

var A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_invoke, New: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_new, Get: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_get}

var A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$root_keys$iter__1844000067__1844000071$fn__1844000072$fn__1844000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_A_class, Simple: "fn__1844000073", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_class.Info(); i.IsInstance = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_InstanceOf; i.Init = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_Init; i.Table = A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_members; jrt.RegisterGoType(A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A_class, reflect.TypeFor[A_arbace_a2g_main_root_keys_iter__1844000067__1844000071_fn__1844000072_fn__1844000073_A]()) }

func A_arbace_a2g_main_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_A_New()}; return nil }

func A_arbace_a2g_main_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_A_invoke, New: A_arbace_a2g_main_run_A_new, Get: A_arbace_a2g_main_run_A_get}

var A_arbace_a2g_main_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "run", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_A_InstanceOf; i.Init = A_arbace_a2g_main_run_A_Init; i.Table = A_arbace_a2g_main_run_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_A_class, reflect.TypeFor[A_arbace_a2g_main_run_A]()) }

func A_arbace_a2g_main_run_fn__1844000901_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_fn__1844000901_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_fn__1844000901_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_fn__1844000901_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_fn__1844000901_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_fn__1844000901_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_fn__1844000901_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_fn__1844000901_A_invoke, New: A_arbace_a2g_main_run_fn__1844000901_A_new, Get: A_arbace_a2g_main_run_fn__1844000901_A_get}

var A_arbace_a2g_main_run_fn__1844000901_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run$fn__1844000901", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_A_class, Simple: "fn__1844000901", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_fn__1844000901_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_fn__1844000901_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_fn__1844000901_A_InstanceOf; i.Init = A_arbace_a2g_main_run_fn__1844000901_A_Init; i.Table = A_arbace_a2g_main_run_fn__1844000901_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_fn__1844000901_A_class, reflect.TypeFor[A_arbace_a2g_main_run_fn__1844000901_A]()) }

func A_arbace_a2g_main_run_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__A_invoke, New: A_arbace_a2g_main_run_STAR__A_new, Get: A_arbace_a2g_main_run_STAR__A_get}

var A_arbace_a2g_main_run_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "run_STAR_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__A_Init; i.Table = A_arbace_a2g_main_run_STAR__A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__A]()) }

func A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__clj_files__1844000302_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_invoke, New: A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_new, Get: A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_get}

var A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$clj_files__1844000302", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "clj_files__1844000302", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__clj_files__1844000302_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_Init; i.Table = A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__clj_files__1844000302_A]()) }

func A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_invoke, New: A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_new, Get: A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_get}

var A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$clj_files__1844000302$fn__1844000303", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__clj_files__1844000302_A_class, Simple: "fn__1844000303", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_Init; i.Table = A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__clj_files__1844000302_fn__1844000303_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000306_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000306_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000306_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000306_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000306_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000306_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000306_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000306_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000306_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000306_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000306_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000306", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000306", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000306_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000306_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000306_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000306_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000306_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000306_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000306_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000308_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000308_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000308_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000308_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000308_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000308_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000308_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000308_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000308_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000308_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000308_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000308", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000308", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000308_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000308_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000308_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000308_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000308_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000308_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000308_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000314_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000314_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000314_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000314_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000314_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000314_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000314_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000314_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000314_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000314_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000314_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000314", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000314", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000314_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000314_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000314_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000314_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000314_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000314_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000314_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000322_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000322_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000322_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000322_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000322_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000322_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000322_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000322_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000322_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000322_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000322_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000322", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000322", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000322_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000322_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000322_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000322_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000322_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000322_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000322_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000332_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000332_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000332_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000332_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000332_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000332_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000332_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000332_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000332_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000332_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000332_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000332", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000332", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000332_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000332_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000332_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000332_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000332_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000332_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000332_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000337_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000337_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000337_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000337_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000337_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000337_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000337_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000337_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000337_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000337_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000337_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000337", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000337", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000337_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000337_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000337_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000337_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000337_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000337_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000337_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000367_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000367_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000367_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000367_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000367_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000367_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000367_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000367_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000367_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000367", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000367", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000367_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000367_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000367_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000367_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000367_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000367_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000367_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000368", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__fn__1844000367_A_class, Simple: "fn__1844000368", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000368_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000370", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__fn__1844000367_A_class, Simple: "fn__1844000370", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000370_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000372", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__fn__1844000367_A_class, Simple: "fn__1844000372", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000367$fn__1844000372$fn__1844000373", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_A_class, Simple: "fn__1844000373", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000367_fn__1844000372_fn__1844000373_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000387_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000387_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000387_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000387_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000387_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000387_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000387_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000387_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000387_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000387_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000387_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000387", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000387", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000387_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000387_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000387_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000387_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000387_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000387_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000387_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000389_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000389_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000389_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000389_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000389_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000389_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000389_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000389_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000389_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000389_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000389_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000389", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000389", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000389_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000389_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000389_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000389_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000389_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000389_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000389_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000391_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000391_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000391_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000391_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000391_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000391_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000391_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000391_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000391_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000391_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000391_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000391", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000391", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000391_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000391_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000391_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000391_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000391_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000391_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000391_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000393_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000393_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000393_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000393_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000393_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000393_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000393_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000393_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000393_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000393_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000393_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000393", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000393", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000393_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000393_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000393_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000393_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000393_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000393_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000393_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000395_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000395_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000395_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000395_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000395_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000395_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000395_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000395_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000395_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000395_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000395_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000395", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000395", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000395_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000395_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000395_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000395_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000395_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000395_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000395_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000397_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000397_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000397_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000397_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000397_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000397_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000397_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000397_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000397_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000397_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000397_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000397", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000397", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000397_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000397_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000397_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000397_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000397_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000397_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000397_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000399_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000399_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000399_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000399_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000399_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000399_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000399_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000399_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000399_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000399_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000399_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000399", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000399", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000399_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000399_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000399_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000399_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000399_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000399_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000399_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000424_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000424_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000424_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000424_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000424_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000424_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000424_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000424_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000424_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000424_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000424_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000424", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000424", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000424_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000424_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000424_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000424_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000424_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000424_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000424_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000426_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000426_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000426_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000426_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000426_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000426_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000426_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000426_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000426_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000426_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000426_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000426", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000426", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000426_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000426_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000426_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000426_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000426_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000426_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000426_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000432_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000432_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000432_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000432_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000432_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000432_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000432_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000432_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000432_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000432_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000432_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000432", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000432", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000432_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000432_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000432_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000432_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000432_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000432_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000432_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000437_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000437_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000437_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000437_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000437_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000437_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000437_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000437_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000437_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000437_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000437_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000437", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000437", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000437_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000437_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000437_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000437_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000437_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000437_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000437_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000446_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000446_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000446_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000446_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000446_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000446_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000446_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000446_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000446_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000446_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000446_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000446", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000446", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000446_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000446_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000446_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000446_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000446_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000446_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000446_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000448_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000448_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000448_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000448_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000448_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000448_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000448_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000448_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000448_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000448_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000448_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000448", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000448", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000448_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000448_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000448_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000448_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000448_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000448_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000448_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000450_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000450_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000450_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000450_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000450_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000450_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000450_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000450_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000450_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000450_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000450_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000450", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000450", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000450_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000450_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000450_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000450_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000450_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000450_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000450_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000456_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000456_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000456_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000456_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000456_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000456_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000456_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000456_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000456_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000456_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000456_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000456", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000456", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000456_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000456_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000456_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000456_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000456_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000456_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000456_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000458_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000458_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000458_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000458_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000458_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000458_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000458_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000458_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000458_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000458_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000458_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000458", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000458", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000458_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000458_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000458_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000458_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000458_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000458_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000458_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000460_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000460_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000460_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000460_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000460_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000460_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000460_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000460_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000460_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000460_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000460_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000460", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000460", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000460_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000460_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000460_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000460_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000460_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000460_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000460_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000462_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000462_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000462_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000462_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000462_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000462_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000462_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000462_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000462_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000462_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000462_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000462", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000462", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000462_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000462_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000462_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000462_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000462_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000462_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000462_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000484_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000484_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000484_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000484_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000484_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000484_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000484_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000484_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000484_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000484_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000484_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000484", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000484", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000484_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000484_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000484_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000484_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000484_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000484_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000484_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000486_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000486_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000486_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000486_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000486_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000486_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000486_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000486_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000486_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000486_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000486_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000486", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000486", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000486_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000486_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000486_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000486_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000486_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000486_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000486_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000488_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000488_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000488_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000488_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000488_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000488_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000488_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000488_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000488_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000488_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000488_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000488", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000488", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000488_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000488_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000488_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000488_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000488_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000488_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000488_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000494_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000494_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000494_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000494_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000494_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000494_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000494_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000494_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000494_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000494_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000494_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000494", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000494", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000494_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000494_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000494_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000494_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000494_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000494_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000494_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000496_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000496_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000496_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000496_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000496_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000496_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000496_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000496_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000496_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000496_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000496_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000496", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000496", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000496_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000496_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000496_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000496_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000496_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000496_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000496_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000498_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000498_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000498_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000498_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000498_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000498_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000498_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000498_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000498_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000498_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000498_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000498", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000498", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000498_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000498_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000498_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000498_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000498_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000498_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000498_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000500_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000500_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000500_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000500_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000500_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000500_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000500_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000500_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000500_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000500_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000500_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000500", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000500", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000500_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000500_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000500_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000500_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000500_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000500_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000500_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000526_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000526_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000526_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000526_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000526_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000526_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000526_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000526_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000526_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000526_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000526_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000526", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000526", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000526_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000526_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000526_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000526_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000526_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000526_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000526_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000532_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000532_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000532_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000532_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000532_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000532_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000532_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000532_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000532_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000532_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000532_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000532", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000532", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000532_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000532_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000532_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000532_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000532_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000532_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000532_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000580_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000580_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000580_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000580_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000580_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000580_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000580_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000580_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000580_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000580_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000580_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000580", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000580", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000580_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000580_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000580_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000580_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000580_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000580_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000580_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000586_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000586_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000586_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000586_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000586_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000586_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000586_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000586_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000586_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000586_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000586_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000586", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000586", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000586_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000586_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000586_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000586_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000586_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000586_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000586_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000610_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000610_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000610_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000610_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000610_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000610_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000610_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000610_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000610_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000610_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000610_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000610", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000610", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000610_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000610_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000610_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000610_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000610_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000610_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000610_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000610$fn__1844000612", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__fn__1844000610_A_class, Simple: "fn__1844000612", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000612_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000610$fn__1844000617", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__fn__1844000610_A_class, Simple: "fn__1844000617", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000610_fn__1844000617_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000646_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000646_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000646_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000646_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000646_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000646_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000646_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000646_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000646_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000646_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000646_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000646", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000646", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000646_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000646_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000646_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000646_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000646_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000646_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000646_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000648_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000648_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000648_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000648_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000648_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000648_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000648_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000648_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000648_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000648_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000648_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000648", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000648", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000648_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000648_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000648_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000648_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000648_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000648_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000648_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000688_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000688_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000688_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000688_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000688_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000688_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000688_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000688_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000688_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000688_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000688_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000688", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000688", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000688_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000688_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000688_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000688_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000688_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000688_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000688_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000726_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000726_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000726_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000726_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000726_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000726_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000726_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000726_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000726_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000726_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000726_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000726", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000726", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000726_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000726_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000726_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000726_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000726_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000726_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000726_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000734_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000734_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000734_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000734_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000734_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000734_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000734_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000734_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000734_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000734_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000734_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000734", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000734", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000734_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000734_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000734_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000734_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000734_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000734_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000734_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000740_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000740_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000740_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000740_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000740_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000740_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000740_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000740_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000740_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000740_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000740_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000740", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000740", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000740_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000740_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000740_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000740_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000740_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000740_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000740_A]()) }

func A_arbace_a2g_main_run_STAR__fn__1844000742_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__fn__1844000742_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000742_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__fn__1844000742_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__fn__1844000742_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__fn__1844000742_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__fn__1844000742_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__fn__1844000742_A_invoke, New: A_arbace_a2g_main_run_STAR__fn__1844000742_A_new, Get: A_arbace_a2g_main_run_STAR__fn__1844000742_A_get}

var A_arbace_a2g_main_run_STAR__fn__1844000742_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$fn__1844000742", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "fn__1844000742", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__fn__1844000742_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__fn__1844000742_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__fn__1844000742_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__fn__1844000742_A_Init; i.Table = A_arbace_a2g_main_run_STAR__fn__1844000742_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__fn__1844000742_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__fn__1844000742_A]()) }

func A_arbace_a2g_main_run_STAR__go_names__1844000736_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__go_names__1844000736_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__go_names__1844000736_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__go_names__1844000736_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__go_names__1844000736_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__go_names__1844000736_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__go_names__1844000736_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__go_names__1844000736_A_invoke, New: A_arbace_a2g_main_run_STAR__go_names__1844000736_A_new, Get: A_arbace_a2g_main_run_STAR__go_names__1844000736_A_get}

var A_arbace_a2g_main_run_STAR__go_names__1844000736_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$go_names__1844000736", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "go_names__1844000736", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__go_names__1844000736_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__go_names__1844000736_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__go_names__1844000736_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__go_names__1844000736_A_Init; i.Table = A_arbace_a2g_main_run_STAR__go_names__1844000736_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__go_names__1844000736_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__go_names__1844000736_A]()) }

func A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_invoke, New: A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_new, Get: A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_get}

var A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$go_names__1844000736$fn__1844000737", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__go_names__1844000736_A_class, Simple: "fn__1844000737", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_Init; i.Table = A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__go_names__1844000736_fn__1844000737_A]()) }

func A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_invoke, New: A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_new, Get: A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_get}

var A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$in_slice_QMARK___1844000324", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "in_slice_QMARK___1844000324", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_Init; i.Table = A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A]()) }

func A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_invoke, New: A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_new, Get: A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_get}

var A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$in_slice_QMARK___1844000324$fn__1844000325", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_A_class, Simple: "fn__1844000325", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_Init; i.Table = A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__in_slice_QMARK___1844000324_fn__1844000325_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000282__1844000286", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000282__1844000286", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000282__1844000286$fn__1844000287", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_A_class, Simple: "fn__1844000287", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000282__1844000286$fn__1844000287$fn__1844000288", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_A_class, Simple: "fn__1844000288", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000282__1844000286_fn__1844000287_fn__1844000288_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000292__1844000296", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000292__1844000296", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000292__1844000296$fn__1844000297", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_A_class, Simple: "fn__1844000297", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000292__1844000296$fn__1844000297$fn__1844000298", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_A_class, Simple: "fn__1844000298", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000292__1844000296_fn__1844000297_fn__1844000298_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000339__1844000343", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000339__1844000343", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000339__1844000343$fn__1844000344", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_A_class, Simple: "fn__1844000344", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000339__1844000343$fn__1844000344$fn__1844000345", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_A_class, Simple: "fn__1844000345", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000339__1844000343_fn__1844000344_fn__1844000345_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000351__1844000355", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000351__1844000355", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000351__1844000355$fn__1844000356", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_A_class, Simple: "fn__1844000356", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000351__1844000355$fn__1844000356$fn__1844000357", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_A_class, Simple: "fn__1844000357", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000351__1844000355_fn__1844000356_fn__1844000357_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000377__1844000381", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000377__1844000381", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000377__1844000381$fn__1844000382", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_A_class, Simple: "fn__1844000382", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000377__1844000381$fn__1844000382$fn__1844000383", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_A_class, Simple: "fn__1844000383", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000377__1844000381_fn__1844000382_fn__1844000383_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000401__1844000407", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000401__1844000407", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_A_class, Simple: "fn__1844000408", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408$iter__1844000403__1844000412", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_A_class, Simple: "iter__1844000403__1844000412", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408$iter__1844000403__1844000412$fn__1844000413", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_A_class, Simple: "fn__1844000413", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000401__1844000407$fn__1844000408$iter__1844000403__1844000412$fn__1844000413$fn__1844000414", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_A_class, Simple: "fn__1844000414", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000401__1844000407_fn__1844000408_iter__1844000403__1844000412_fn__1844000413_fn__1844000414_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000464__1844000468", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000464__1844000468", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000464__1844000468$fn__1844000469", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_A_class, Simple: "fn__1844000469", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000464__1844000468$fn__1844000469$fn__1844000470", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_A_class, Simple: "fn__1844000470", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000464__1844000468_fn__1844000469_fn__1844000470_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000474__1844000478", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000474__1844000478", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000474__1844000478$fn__1844000479", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_A_class, Simple: "fn__1844000479", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000474__1844000478$fn__1844000479$fn__1844000480", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_A_class, Simple: "fn__1844000480", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000474__1844000478_fn__1844000479_fn__1844000480_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000502__1844000506", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000502__1844000506", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000502__1844000506$fn__1844000507", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_A_class, Simple: "fn__1844000507", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000502__1844000506$fn__1844000507$fn__1844000508", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_A_class, Simple: "fn__1844000508", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000502__1844000506_fn__1844000507_fn__1844000508_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000512__1844000516", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000512__1844000516", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000512__1844000516$fn__1844000517", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_A_class, Simple: "fn__1844000517", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000512__1844000516$fn__1844000517$fn__1844000518", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_A_class, Simple: "fn__1844000518", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000512__1844000516_fn__1844000517_fn__1844000518_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000534__1844000538", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000534__1844000538", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000534__1844000538$fn__1844000539", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_A_class, Simple: "fn__1844000539", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000534__1844000538$fn__1844000539$fn__1844000540", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_A_class, Simple: "fn__1844000540", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000534__1844000538_fn__1844000539_fn__1844000540_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000588__1844000592", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000588__1844000592", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000588__1844000592$fn__1844000593", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_A_class, Simple: "fn__1844000593", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000588__1844000592$fn__1844000593$fn__1844000594", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_A_class, Simple: "fn__1844000594", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000588__1844000592_fn__1844000593_fn__1844000594_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000620__1844000624", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000620__1844000624", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000620__1844000624$fn__1844000625", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_A_class, Simple: "fn__1844000625", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000620__1844000624$fn__1844000625$fn__1844000626", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_A_class, Simple: "fn__1844000626", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000620__1844000624_fn__1844000625_fn__1844000626_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000650__1844000654", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000650__1844000654", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_A_class, Simple: "fn__1844000655", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000656", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_class, Simple: "fn__1844000656", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000656$fn__1844000660", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_A_class, Simple: "fn__1844000660", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000656$fn__1844000660$fn__1844000661", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_A_class, Simple: "fn__1844000661", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000656_fn__1844000660_fn__1844000661_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000668", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_A_class, Simple: "fn__1844000668", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000650__1844000654$fn__1844000655$fn__1844000668$fn__1844000669", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_A_class, Simple: "fn__1844000669", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000650__1844000654_fn__1844000655_fn__1844000668_fn__1844000669_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000674__1844000678", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000674__1844000678", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000674__1844000678$fn__1844000679", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_A_class, Simple: "fn__1844000679", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000674__1844000678$fn__1844000679$fn__1844000680", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_A_class, Simple: "fn__1844000680", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000674__1844000678_fn__1844000679_fn__1844000680_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000690__1844000694", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000690__1844000694", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000690__1844000694$fn__1844000695", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_A_class, Simple: "fn__1844000695", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000690__1844000694$fn__1844000695$fn__1844000696", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_A_class, Simple: "fn__1844000696", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000690__1844000694_fn__1844000695_fn__1844000696_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000706__1844000710", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000706__1844000710", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000706__1844000710$fn__1844000711", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_A_class, Simple: "fn__1844000711", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000706__1844000710$fn__1844000711$fn__1844000712", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_A_class, Simple: "fn__1844000712", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000706__1844000710_fn__1844000711_fn__1844000712_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000744__1844000748", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000744__1844000748", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000744__1844000748$fn__1844000749", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_A_class, Simple: "fn__1844000749", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000744__1844000748$fn__1844000749$fn__1844000750", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_A_class, Simple: "fn__1844000750", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000744__1844000748_fn__1844000749_fn__1844000750_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000758__1844000762", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000758__1844000762", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000758__1844000762$fn__1844000763", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_A_class, Simple: "fn__1844000763", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000758__1844000762$fn__1844000763$fn__1844000764", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_A_class, Simple: "fn__1844000764", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000758__1844000762_fn__1844000763_fn__1844000764_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000774__1844000778", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000774__1844000778", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000774__1844000778$fn__1844000779", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_A_class, Simple: "fn__1844000779", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000774__1844000778$fn__1844000779$fn__1844000780", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_A_class, Simple: "fn__1844000780", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000774__1844000778_fn__1844000779_fn__1844000780_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000784__1844000788", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000784__1844000788", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000784__1844000788$fn__1844000789", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_A_class, Simple: "fn__1844000789", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000784__1844000788$fn__1844000789$fn__1844000790", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_A_class, Simple: "fn__1844000790", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000784__1844000788_fn__1844000789_fn__1844000790_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000800__1844000804", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000800__1844000804", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000800__1844000804$fn__1844000805", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_A_class, Simple: "fn__1844000805", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000800__1844000804$fn__1844000805$fn__1844000806", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_A_class, Simple: "fn__1844000806", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000800__1844000804_fn__1844000805_fn__1844000806_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000810__1844000814", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000810__1844000814", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000810__1844000814$fn__1844000815", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_A_class, Simple: "fn__1844000815", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000810__1844000814$fn__1844000815$fn__1844000816", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_A_class, Simple: "fn__1844000816", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000810__1844000814_fn__1844000815_fn__1844000816_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000826__1844000830", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000826__1844000830", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_A_class, Simple: "fn__1844000831", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831$fn__1844000832", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_class, Simple: "fn__1844000832", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831$fn__1844000832$fn__1844000836", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_A_class, Simple: "fn__1844000836", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000832_fn__1844000836_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000826__1844000830$fn__1844000831$fn__1844000842", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_A_class, Simple: "fn__1844000842", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000826__1844000830_fn__1844000831_fn__1844000842_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000847__1844000851", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000847__1844000851", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_A_class, Simple: "fn__1844000852", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852$fn__1844000853", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_class, Simple: "fn__1844000853", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852$fn__1844000853$fn__1844000857", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_A_class, Simple: "fn__1844000857", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000853_fn__1844000857_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000847__1844000851$fn__1844000852$fn__1844000863", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_A_class, Simple: "fn__1844000863", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000847__1844000851_fn__1844000852_fn__1844000863_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000883__1844000887", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "iter__1844000883__1844000887", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_A_class, Simple: "fn__1844000888", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A]()) }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_invoke, New: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_new, Get: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_get}

var A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$iter__1844000883__1844000887$fn__1844000888$fn__1844000889", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_A_class, Simple: "fn__1844000889", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_Init; i.Table = A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__iter__1844000883__1844000887_fn__1844000888_fn__1844000889_A]()) }

func A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_invoke, New: A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_new, Get: A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_get}

var A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$jrt_java_QMARK___1844000328", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "jrt_java_QMARK___1844000328", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_Init; i.Table = A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__jrt_java_QMARK___1844000328_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "report_of__1844000544", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544$fn__1844000545", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__report_of__1844000544_A_class, Simple: "fn__1844000545", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_fn__1844000545_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000547__1844000551", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__report_of__1844000544_A_class, Simple: "iter__1844000547__1844000551", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000547__1844000551$fn__1844000552", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_A_class, Simple: "fn__1844000552", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000547__1844000551$fn__1844000552$fn__1844000553", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_A_class, Simple: "fn__1844000553", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000547__1844000551_fn__1844000552_fn__1844000553_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_New()}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000563__1844000567", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__report_of__1844000544_A_class, Simple: "iter__1844000563__1844000567", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000563__1844000567$fn__1844000568", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_A_class, Simple: "fn__1844000568", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A]()) }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_invoke, New: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_new, Get: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_get}

var A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$report_of__1844000544$iter__1844000563__1844000567$fn__1844000568$fn__1844000569", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_A_class, Simple: "fn__1844000569", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_Init; i.Table = A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__report_of__1844000544_iter__1844000563__1844000567_fn__1844000568_fn__1844000569_A]()) }

func A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_fn_class)}; return nil }

var A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_invoke, New: A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_new, Get: A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_get}

var A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$run_STAR_$slice_QMARK___1844000349", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_run_STAR__A_class, Simple: "slice_QMARK___1844000349", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_class.Info(); i.IsInstance = A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_InstanceOf; i.Init = A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_Init; i.Table = A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_members; jrt.RegisterGoType(A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A_class, reflect.TypeFor[A_arbace_a2g_main_run_STAR__slice_QMARK___1844000349_A]()) }

func A_arbace_a2g_main_secs_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_secs_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_secs_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_secs_A_New()}; return nil }

func A_arbace_a2g_main_secs_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_secs_A_fn_class)}; return nil }

var A_arbace_a2g_main_secs_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_secs_A_invoke, New: A_arbace_a2g_main_secs_A_new, Get: A_arbace_a2g_main_secs_A_get}

var A_arbace_a2g_main_secs_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$secs", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "secs", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_secs_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_secs_A_class.Info(); i.IsInstance = A_arbace_a2g_main_secs_A_InstanceOf; i.Init = A_arbace_a2g_main_secs_A_Init; i.Table = A_arbace_a2g_main_secs_A_members; jrt.RegisterGoType(A_arbace_a2g_main_secs_A_class, reflect.TypeFor[A_arbace_a2g_main_secs_A]()) }

func A_arbace_a2g_main_source_top_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_source_top_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_source_top_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_source_top_A_New()}; return nil }

func A_arbace_a2g_main_source_top_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_source_top_A_fn_class)}; return nil }

var A_arbace_a2g_main_source_top_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_source_top_A_invoke, New: A_arbace_a2g_main_source_top_A_new, Get: A_arbace_a2g_main_source_top_A_get}

var A_arbace_a2g_main_source_top_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$source_top", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "source_top", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_source_top_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_source_top_A_class.Info(); i.IsInstance = A_arbace_a2g_main_source_top_A_InstanceOf; i.Init = A_arbace_a2g_main_source_top_A_Init; i.Table = A_arbace_a2g_main_source_top_A_members; jrt.RegisterGoType(A_arbace_a2g_main_source_top_A_class, reflect.TypeFor[A_arbace_a2g_main_source_top_A]()) }

func A_arbace_a2g_main_standin_roots_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_standin_roots_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_A_New()}; return nil }

func A_arbace_a2g_main_standin_roots_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_A_invoke, New: A_arbace_a2g_main_standin_roots_A_new, Get: A_arbace_a2g_main_standin_roots_A_get}

var A_arbace_a2g_main_standin_roots_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "standin_roots", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_A_Init; i.Table = A_arbace_a2g_main_standin_roots_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_New()}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000078__1844000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_standin_roots_A_class, Simple: "iter__1844000078__1844000082", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000078__1844000082$fn__1844000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_A_class, Simple: "fn__1844000083", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000078__1844000082$fn__1844000083$fn__1844000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_A_class, Simple: "fn__1844000084", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000078__1844000082_fn__1844000083_fn__1844000084_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000088__1844000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_standin_roots_A_class, Simple: "iter__1844000088__1844000094", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_A_class, Simple: "fn__1844000095", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_A_class, Simple: "iter__1844000090__1844000096", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096$fn__1844000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_A_class, Simple: "fn__1844000097", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A]()) }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_New_O_O_O_I_O_O_O(args[0], args[1], args[2], args[3].(int32), args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_fn_class)}; return nil }

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_invoke, New: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_new, Get: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_get}

var A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$standin_roots$iter__1844000088__1844000094$fn__1844000095$iter__1844000090__1844000096$fn__1844000097$fn__1844000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_A_class, Simple: "fn__1844000098", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_class.Info(); i.IsInstance = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_InstanceOf; i.Init = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_Init; i.Table = A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_members; jrt.RegisterGoType(A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A_class, reflect.TypeFor[A_arbace_a2g_main_standin_roots_iter__1844000088__1844000094_fn__1844000095_iter__1844000090__1844000096_fn__1844000097_fn__1844000098_A]()) }

func A_arbace_a2g_main_top_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_top_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_top_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_top_of_A_New()}; return nil }

func A_arbace_a2g_main_top_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_top_of_A_fn_class)}; return nil }

var A_arbace_a2g_main_top_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_top_of_A_invoke, New: A_arbace_a2g_main_top_of_A_new, Get: A_arbace_a2g_main_top_of_A_get}

var A_arbace_a2g_main_top_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$top_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "top_of", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_top_of_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_top_of_A_class.Info(); i.IsInstance = A_arbace_a2g_main_top_of_A_InstanceOf; i.Init = A_arbace_a2g_main_top_of_A_Init; i.Table = A_arbace_a2g_main_top_of_A_members; jrt.RegisterGoType(A_arbace_a2g_main_top_of_A_class, reflect.TypeFor[A_arbace_a2g_main_top_of_A]()) }

func A_arbace_a2g_main_translate_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_translate_classes_A).Invoke_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_main_translate_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_translate_classes_A_New()}; return nil }

func A_arbace_a2g_main_translate_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_translate_classes_A_fn_class)}; return nil }

var A_arbace_a2g_main_translate_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_translate_classes_A_invoke, New: A_arbace_a2g_main_translate_classes_A_new, Get: A_arbace_a2g_main_translate_classes_A_get}

var A_arbace_a2g_main_translate_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$translate_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF6_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "translate_classes", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_translate_classes_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_translate_classes_A_class.Info(); i.IsInstance = A_arbace_a2g_main_translate_classes_A_InstanceOf; i.Init = A_arbace_a2g_main_translate_classes_A_Init; i.Table = A_arbace_a2g_main_translate_classes_A_members; jrt.RegisterGoType(A_arbace_a2g_main_translate_classes_A_class, reflect.TypeFor[A_arbace_a2g_main_translate_classes_A]()) }

func A_arbace_a2g_main_translate_classes_fn__1844000219_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_translate_classes_fn__1844000219_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000219_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_translate_classes_fn__1844000219_A_New()}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000219_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_translate_classes_fn__1844000219_A_fn_class)}; return nil }

var A_arbace_a2g_main_translate_classes_fn__1844000219_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_translate_classes_fn__1844000219_A_invoke, New: A_arbace_a2g_main_translate_classes_fn__1844000219_A_new, Get: A_arbace_a2g_main_translate_classes_fn__1844000219_A_get}

var A_arbace_a2g_main_translate_classes_fn__1844000219_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$translate_classes$fn__1844000219", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_translate_classes_A_class, Simple: "fn__1844000219", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_translate_classes_fn__1844000219_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_translate_classes_fn__1844000219_A_class.Info(); i.IsInstance = A_arbace_a2g_main_translate_classes_fn__1844000219_A_InstanceOf; i.Init = A_arbace_a2g_main_translate_classes_fn__1844000219_A_Init; i.Table = A_arbace_a2g_main_translate_classes_fn__1844000219_A_members; jrt.RegisterGoType(A_arbace_a2g_main_translate_classes_fn__1844000219_A_class, reflect.TypeFor[A_arbace_a2g_main_translate_classes_fn__1844000219_A]()) }

func A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_fn_class)}; return nil }

var A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_invoke, New: A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_new, Get: A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_get}

var A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$translate_classes$fn__1844000219$fn__1844000223", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_translate_classes_fn__1844000219_A_class, Simple: "fn__1844000223", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_class.Info(); i.IsInstance = A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_InstanceOf; i.Init = A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_Init; i.Table = A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_members; jrt.RegisterGoType(A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A_class, reflect.TypeFor[A_arbace_a2g_main_translate_classes_fn__1844000219_fn__1844000223_A]()) }

func A_arbace_a2g_main_translate_classes_fn__1844000226_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_translate_classes_fn__1844000226_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000226_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_translate_classes_fn__1844000226_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000226_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_translate_classes_fn__1844000226_A_fn_class)}; return nil }

var A_arbace_a2g_main_translate_classes_fn__1844000226_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_translate_classes_fn__1844000226_A_invoke, New: A_arbace_a2g_main_translate_classes_fn__1844000226_A_new, Get: A_arbace_a2g_main_translate_classes_fn__1844000226_A_get}

var A_arbace_a2g_main_translate_classes_fn__1844000226_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$translate_classes$fn__1844000226", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_translate_classes_A_class, Simple: "fn__1844000226", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_translate_classes_fn__1844000226_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_translate_classes_fn__1844000226_A_class.Info(); i.IsInstance = A_arbace_a2g_main_translate_classes_fn__1844000226_A_InstanceOf; i.Init = A_arbace_a2g_main_translate_classes_fn__1844000226_A_Init; i.Table = A_arbace_a2g_main_translate_classes_fn__1844000226_A_members; jrt.RegisterGoType(A_arbace_a2g_main_translate_classes_fn__1844000226_A_class, reflect.TypeFor[A_arbace_a2g_main_translate_classes_fn__1844000226_A]()) }

func A_arbace_a2g_main_translate_classes_fn__1844000232_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_translate_classes_fn__1844000232_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000232_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_translate_classes_fn__1844000232_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000232_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_translate_classes_fn__1844000232_A_fn_class)}; return nil }

var A_arbace_a2g_main_translate_classes_fn__1844000232_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_translate_classes_fn__1844000232_A_invoke, New: A_arbace_a2g_main_translate_classes_fn__1844000232_A_new, Get: A_arbace_a2g_main_translate_classes_fn__1844000232_A_get}

var A_arbace_a2g_main_translate_classes_fn__1844000232_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$translate_classes$fn__1844000232", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_translate_classes_A_class, Simple: "fn__1844000232", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_translate_classes_fn__1844000232_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_translate_classes_fn__1844000232_A_class.Info(); i.IsInstance = A_arbace_a2g_main_translate_classes_fn__1844000232_A_InstanceOf; i.Init = A_arbace_a2g_main_translate_classes_fn__1844000232_A_Init; i.Table = A_arbace_a2g_main_translate_classes_fn__1844000232_A_members; jrt.RegisterGoType(A_arbace_a2g_main_translate_classes_fn__1844000232_A_class, reflect.TypeFor[A_arbace_a2g_main_translate_classes_fn__1844000232_A]()) }

func A_arbace_a2g_main_translate_classes_fn__1844000241_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_translate_classes_fn__1844000241_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000241_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_translate_classes_fn__1844000241_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_main_translate_classes_fn__1844000241_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_translate_classes_fn__1844000241_A_fn_class)}; return nil }

var A_arbace_a2g_main_translate_classes_fn__1844000241_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_translate_classes_fn__1844000241_A_invoke, New: A_arbace_a2g_main_translate_classes_fn__1844000241_A_new, Get: A_arbace_a2g_main_translate_classes_fn__1844000241_A_get}

var A_arbace_a2g_main_translate_classes_fn__1844000241_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$translate_classes$fn__1844000241", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_translate_classes_A_class, Simple: "fn__1844000241", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_translate_classes_fn__1844000241_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_translate_classes_fn__1844000241_A_class.Info(); i.IsInstance = A_arbace_a2g_main_translate_classes_fn__1844000241_A_InstanceOf; i.Init = A_arbace_a2g_main_translate_classes_fn__1844000241_A_Init; i.Table = A_arbace_a2g_main_translate_classes_fn__1844000241_A_members; jrt.RegisterGoType(A_arbace_a2g_main_translate_classes_fn__1844000241_A_class, reflect.TypeFor[A_arbace_a2g_main_translate_classes_fn__1844000241_A]()) }

func A_arbace_a2g_main_write_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_write_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_BANG__A_New()}; return nil }

func A_arbace_a2g_main_write_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_main_write_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_BANG__A_invoke, New: A_arbace_a2g_main_write_BANG__A_new, Get: A_arbace_a2g_main_write_BANG__A_get}

var A_arbace_a2g_main_write_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "write_BANG_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_BANG__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_BANG__A_InstanceOf; i.Init = A_arbace_a2g_main_write_BANG__A_Init; i.Table = A_arbace_a2g_main_write_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_BANG__A_class, reflect.TypeFor[A_arbace_a2g_main_write_BANG__A]()) }

func A_arbace_a2g_main_write_resources_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_resources_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_resources_BANG__A_New()}; return nil }

func A_arbace_a2g_main_write_resources_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_resources_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_main_write_resources_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_resources_BANG__A_invoke, New: A_arbace_a2g_main_write_resources_BANG__A_new, Get: A_arbace_a2g_main_write_resources_BANG__A_get}

var A_arbace_a2g_main_write_resources_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_resources_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_main_A_class, Simple: "write_resources_BANG_", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_resources_BANG__A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_resources_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_resources_BANG__A_InstanceOf; i.Init = A_arbace_a2g_main_write_resources_BANG__A_Init; i.Table = A_arbace_a2g_main_write_resources_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_resources_BANG__A_class, reflect.TypeFor[A_arbace_a2g_main_write_resources_BANG__A]()) }

func A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_New()}; return nil }

func A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_fn_class)}; return nil }

var A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_invoke, New: A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_new, Get: A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_get}

var A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_resources_BANG_$fn__1844000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_write_resources_BANG__A_class, Simple: "fn__1844000149", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_InstanceOf; i.Init = A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_Init; i.Table = A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A_class, reflect.TypeFor[A_arbace_a2g_main_write_resources_BANG__fn__1844000149_A]()) }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_New_O(args[0])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_fn_class)}; return nil }

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_invoke, New: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_new, Get: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_get}

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_main_write_resources_BANG__A_class, Simple: "iter__1844000154__1844000158", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_InstanceOf; i.Init = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_Init; i.Table = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_class, reflect.TypeFor[A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A]()) }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_fn_class)}; return nil }

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_invoke, New: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_new, Get: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_get}

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_A_class, Simple: "fn__1844000159", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_InstanceOf; i.Init = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_Init; i.Table = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_class, reflect.TypeFor[A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A]()) }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_fn_class)}; return nil }

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_invoke, New: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_new, Get: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_get}

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000160", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_class, Simple: "fn__1844000160", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_InstanceOf; i.Init = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_Init; i.Table = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_class, reflect.TypeFor[A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A]()) }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_fn_class)}; return nil }

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_invoke, New: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_new, Get: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_get}

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000160$fn__1844000164", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_A_class, Simple: "fn__1844000164", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_InstanceOf; i.Init = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_Init; i.Table = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A_class, reflect.TypeFor[A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000160_fn__1844000164_A]()) }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_fn_class)}; return nil }

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_invoke, New: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_new, Get: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_get}

var A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main$write_resources_BANG_$iter__1844000154__1844000158$fn__1844000159$fn__1844000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_A_class, Simple: "fn__1844000170", Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_class.Info(); i.IsInstance = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_InstanceOf; i.Init = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_Init; i.Table = A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_members; jrt.RegisterGoType(A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A_class, reflect.TypeFor[A_arbace_a2g_main_write_resources_BANG__iter__1844000154__1844000158_fn__1844000159_fn__1844000170_A]()) }

func A_arbace_a2g_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_main__init_A_Load__O(); case 1: return A_arbace_a2g_main__init_A_Unit0__O(); case 2: return A_arbace_a2g_main__init_A_Unit1__O(); case 3: return A_arbace_a2g_main__init_A_Unit10__O(); case 4: return A_arbace_a2g_main__init_A_Unit11__O(); case 5: return A_arbace_a2g_main__init_A_Unit12__O(); case 6: return A_arbace_a2g_main__init_A_Unit13__O(); case 7: return A_arbace_a2g_main__init_A_Unit14__O(); case 8: return A_arbace_a2g_main__init_A_Unit15__O(); case 9: return A_arbace_a2g_main__init_A_Unit16__O(); case 10: return A_arbace_a2g_main__init_A_Unit17__O(); case 11: return A_arbace_a2g_main__init_A_Unit18__O(); case 12: return A_arbace_a2g_main__init_A_Unit19__O(); case 13: return A_arbace_a2g_main__init_A_Unit2__O(); case 14: return A_arbace_a2g_main__init_A_Unit20__O(); case 15: return A_arbace_a2g_main__init_A_Unit21__O(); case 16: return A_arbace_a2g_main__init_A_Unit22__O(); case 17: return A_arbace_a2g_main__init_A_Unit23__O(); case 18: return A_arbace_a2g_main__init_A_Unit24__O(); case 19: return A_arbace_a2g_main__init_A_Unit25__O(); case 20: return A_arbace_a2g_main__init_A_Unit26__O(); case 21: return A_arbace_a2g_main__init_A_Unit27__O(); case 22: return A_arbace_a2g_main__init_A_Unit28__O(); case 23: return A_arbace_a2g_main__init_A_Unit29__O(); case 24: return A_arbace_a2g_main__init_A_Unit3__O(); case 25: return A_arbace_a2g_main__init_A_Unit30__O(); case 26: return A_arbace_a2g_main__init_A_Unit31__O(); case 27: return A_arbace_a2g_main__init_A_Unit32__O(); case 28: return A_arbace_a2g_main__init_A_Unit33__O(); case 29: return A_arbace_a2g_main__init_A_Unit34__O(); case 30: return A_arbace_a2g_main__init_A_Unit35__O(); case 31: return A_arbace_a2g_main__init_A_Unit36__O(); case 32: return A_arbace_a2g_main__init_A_Unit4__O(); case 33: return A_arbace_a2g_main__init_A_Unit5__O(); case 34: return A_arbace_a2g_main__init_A_Unit6__O(); case 35: return A_arbace_a2g_main__init_A_Unit7__O(); case 36: return A_arbace_a2g_main__init_A_Unit8__O(); case 37: return A_arbace_a2g_main__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_main__init_A_New()}; return nil }

var A_arbace_a2g_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_main__init_A_invoke, New: A_arbace_a2g_main__init_A_new}

var A_arbace_a2g_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_main.A_arbace_a2g_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_a2g_main__init_A_class.Info(); i.IsInstance = A_arbace_a2g_main__init_A_InstanceOf; i.Init = A_arbace_a2g_main__init_A_Init; i.Table = A_arbace_a2g_main__init_A_members; jrt.RegisterGoType(A_arbace_a2g_main__init_A_class, reflect.TypeFor[A_arbace_a2g_main__init_A]()) }
