//line aot_arbace_j2g_embed.ae:1
package aot_arbace_j2g_embed

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_edge"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_New() *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed_A_const_1); lang.IFn_Cast(A_arbace_j2g_embed_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_3, A_arbace_j2g_embed_A_const_4, A_arbace_j2g_embed_A_const_5, A_arbace_j2g_embed_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_New() *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000008_fn__1991000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_7.GetRawRoot__O()); var tmp2 any; var root_12 any = A_arbace_j2g_embed_A_const_8.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = A_arbace_j2g_embed_A_const_9; if linked_13 == nil { tmp2 = ifn_14.Invoke_O__O(arg_15) } else { tmp2 = linked_13.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_12, arg_15) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_embed_A_const_10.GetRawRoot__O(), A_arbace_j2g_embed_A_const_11) }















































func A_arbace_j2g_embed_sources_A_New() *A_arbace_j2g_embed_sources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_embed_sources_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_embed_sources_A) Invoke_O_O__O(self, root__0 any) any { var base__2 any; var root_22 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_22, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_24 lang.IFn; if


	linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = root__0; var arg_26 any = Lit_40; if linked_23 == nil { base__2 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { base__2 = linked_23.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = /*line :49:1*/A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_New_O(base__2); var tmp2 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class; if



	fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class = fncls__141d; tmp2 = fncls__141d } else { tmp2 = fncls__141 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_359 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = base__2; if linked_360 == nil { tmp4 = ifn_361.Invoke_O__O(arg_362) } else { tmp4 = linked_360.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_359, arg_362) }; files__3 = tmp3.Invoke_O__O(tmp4); var vdir__4 any; var root_142 any = /*line :49:1*/A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_142, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_144 lang.IFn; if








	linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = root__0; var arg_146 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); if linked_143 == nil { vdir__4 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { vdir__4 = linked_143.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) }; var variants__5 any; if
	jrt.NN(jrt.File_Cast(vdir__4)).IsDirectory__Z() { var iter__1927001039__auto____5 any; var tmp5 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_New_O(vdir__4); var tmp6 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class
		if fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class = fncls__235d; tmp6 = fncls__235d } else { tmp6 = fncls__235 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp8 any; var root_363 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = vdir__4; if linked_364 == nil { tmp8 = ifn_365.Invoke_O__O(arg_366) } else { tmp8 = linked_364.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_363, arg_366) }; variants__5 = tmp7.Invoke_O__O(tmp8) } else {
//line :59:1
			variants__5 = nil }; var root_353 any =



	A_arbace_j2g_embed_A_const_31.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any; var tmp9 any = A_arbace_j2g_embed_sources_fn__1991000038_A_New(); var tmp10 *jrt.Class; var fncls__339 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class; if fncls__339 == nil { var fncls__339d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class = fncls__339d; tmp10 = fncls__339d } else { tmp10 = fncls__339 }; arg_356 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_357 any; var root_343 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_345 lang.IFn; if





















	linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_45.GetRawRoot__O()).Invoke__O(); var arg_347 any = files__3; if linked_344 == nil { arg_357 = ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { arg_357 = linked_344.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) }; var arg_358 any; var root_348 any = /*line :63:1*/A_arbace_j2g_embed_A_const_46.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_350 lang.IFn; if






















	linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var arg_352 any = variants__5; if linked_349 == nil { arg_358 = ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { arg_358 = linked_349.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) }; if /*line :63:1*/ linked_354 == nil { return ifn_355.Invoke_O_O_O__O(arg_356, arg_357, arg_358) } else { return linked_354.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_353, arg_356, arg_357, arg_358) } }
//line :53:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :53:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A) Invoke_O_O__O(self, s__1991000014__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_New_O_O_O(t.F_base, s__1991000014__1, self); var tmp2 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class = fncls__140d; tmp2 = fncls__140d } else { tmp2 = fncls__140 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :53:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A) Ctor_O_O_O(c__base, c__s__1991000014, c__iter__1991000013 any) { t.F_base = c__base; t.F_s__1991000014 = c__s__1991000014; t.F_iter__1991000013 = c__iter__1991000013 }
//line :53:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A) Invoke_O__O(self any) any { { var s__1991000014__1 any; var t_ any = t.F_s__1991000014; t.F_s__1991000014 = nil; s__1991000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_27 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = s__1991000014__1; if linked_28 == nil { temp__1927000414__auto____2 = ifn_29.Invoke_O__O(arg_30) } else { temp__1927000414__auto____2 = linked_28.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_27, arg_30) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_31 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__1991000014__3; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_35 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__1991000014__3; if linked_36 == nil { c__1927001037__auto____4 = ifn_37.Invoke_O__O(arg_38) } else { c__1927001037__auto____4 = linked_36.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_35, arg_38) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000016__6 any; var root_39 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_40 == nil { b__1991000016__6 = ifn_41.Invoke_O__O(arg_42) } else { b__1991000016__6 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_39, arg_42) }; var tmp2 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_New_O_O_I_O(b__1991000016__6, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_81 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var root_73 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = b__1991000016__6; if linked_74 == nil { arg_84 = ifn_75.Invoke_O__O(arg_76) } else { arg_84 = linked_74.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_73, arg_76) }; var arg_85 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000013); var tmp5 any; var root_77 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = s__1991000014__3; if linked_78 == nil { tmp5 = ifn_79.Invoke_O__O(arg_80) } else { tmp5 = linked_78.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_77, arg_80) }; arg_85 = tmp4.Invoke_O__O(tmp5); if linked_82 == nil { return ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { return linked_82.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_81, arg_84, arg_85) } } else { var root_90 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var root_86 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = b__1991000016__6; if linked_87 == nil { arg_93 = ifn_88.Invoke_O__O(arg_89) } else { arg_93 = linked_87.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_86, arg_89) }; var arg_94 any; if linked_91 == nil { return ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { return linked_91.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_90, arg_93, arg_94) } } } else { var f__4 any; var root_95 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = s__1991000014__3; if linked_96 == nil { f__4 = ifn_97.Invoke_O__O(arg_98) } else { f__4 = linked_96.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_95, arg_98) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var root_99 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_103 any = Lit_28; if linked_100 == nil { tmp6 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { tmp6 = linked_100.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_99, arg_102, arg_103) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :53:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp8 any; var root_104 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_106 lang.IFn

		if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_105 == nil { tmp8 = ifn_106.Invoke_O__O(arg_107) } else { tmp8 = linked_105.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_104, arg_107) }; rel__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :53:1
		var tmp9 any; var root_114 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_116 lang.IFn


		if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any; var tmp10 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_New_O(rel__5); var tmp11 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class = fncls__113d; tmp11 = fncls__113d } else { tmp11 = fncls__113 }; arg_117 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_118 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_115 == nil { tmp9 = ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { tmp9 = linked_115.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) }
//line :53:1
		if jrt.J2g_Truth(tmp9) { var root_127 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_131 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1991000013); var tmp13 any; var root_123 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = s__1991000014__3; if linked_124 == nil { tmp13 = ifn_125.Invoke_O__O(arg_126) } else { tmp13 = linked_124.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_123, arg_126) }; arg_131 = tmp12.Invoke_O__O(tmp13); if linked_128 == nil { return ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { return linked_128.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_127, arg_130, arg_131) } } else { var tmp14 any; var root_132 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__1991000014__3; if linked_133 == nil { tmp14 = ifn_134.Invoke_O__O(arg_135) } else { tmp14 = linked_133.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_132, arg_135) }; s__1991000014__1 = tmp14; continue L1 } } else { var tmp15 any; var root_136 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = s__1991000014__3; if linked_137 == nil { tmp15 = ifn_138.Invoke_O__O(arg_139) } else { tmp15 = linked_137.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_136, arg_139) }; s__1991000014__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :53:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :53:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A) Ctor_O_O_I_O(c__b__1991000016, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000016 = c__b__1991000016; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :53:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A) Invoke_O__O(self any) any { { var i__1991000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000015__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var root_43 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_47 any = Lit_28; if linked_44 == nil { tmp2 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp2 = linked_44.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_43, arg_46, arg_47) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :53:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp4 any; var root_48 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_50 lang.IFn

		if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_49 == nil { tmp4 = ifn_50.Invoke_O__O(arg_51) } else { tmp4 = linked_49.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_48, arg_51) }; rel__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :53:1
		var tmp5 any; var root_58 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_60 lang.IFn


		if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var tmp6 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_New_O(rel__3); var tmp7 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class = fncls__57d; tmp7 = fncls__57d } else { tmp7 = fncls__57 }; arg_61 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_62 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_59 == nil { tmp5 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { tmp5 = linked_59.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }
//line :53:1
		if jrt.J2g_Truth(tmp5) { var root_67 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = t.F_b__1991000016; var arg_71 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_68 == nil { ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { linked_68.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } else { i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } } else { i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_52 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = t.F_rel; var arg_56 any = p1__1991000012_SHARP___1; if linked_53 == nil { return ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { return linked_53.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_52, arg_55, arg_56) } }
//line :56:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_108 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = t.F_rel; var arg_112 any = p1__1991000012_SHARP___1; if linked_109 == nil { return ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { return linked_109.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_108, arg_111, arg_112) } }



func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A) Invoke_O_O__O(self, s__1991000028__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_New_O_O_O(t.F_vdir, s__1991000028__1, self); var tmp2 *jrt.Class; var fncls__234 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class; if fncls__234 == nil { var fncls__234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class = fncls__234d; tmp2 = fncls__234d } else { tmp2 = fncls__234 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :60:1
func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A) Ctor_O_O_O(c__vdir, c__s__1991000028, c__iter__1991000027 any) { t.F_vdir = c__vdir; t.F_s__1991000028 = c__s__1991000028; t.F_iter__1991000027 = c__iter__1991000027 }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A) Invoke_O__O(self any) any { { var s__1991000028__1 any; var t_ any = t.F_s__1991000028; t.F_s__1991000028 = nil; s__1991000028__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_147 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = s__1991000028__1; if linked_148 == nil { temp__1927000414__auto____2 = ifn_149.Invoke_O__O(arg_150) } else { temp__1927000414__auto____2 = linked_148.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_147, arg_150) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000028__3 any = temp__1927000414__auto____2; var tmp1 any; var root_151 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__1991000028__3; if linked_152 == nil { tmp1 = ifn_153.Invoke_O__O(arg_154) } else { tmp1 = linked_152.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_155 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__1991000028__3; if linked_156 == nil { c__1927001037__auto____4 = ifn_157.Invoke_O__O(arg_158) } else { c__1927001037__auto____4 = linked_156.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_155, arg_158) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000030__6 any; var root_159 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_160 == nil { b__1991000030__6 = ifn_161.Invoke_O__O(arg_162) } else { b__1991000030__6 = linked_160.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_159, arg_162) }; var tmp2 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_New_O_O_I_O(t.F_vdir, b__1991000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class = fncls__181d; tmp3 = fncls__181d } else { tmp3 = fncls__181 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_190 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_182 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = b__1991000030__6; if linked_183 == nil { arg_193 = ifn_184.Invoke_O__O(arg_185) } else { arg_193 = linked_183.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_182, arg_185) }; var arg_194 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000027); var tmp5 any; var root_186 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__1991000028__3; if linked_187 == nil { tmp5 = ifn_188.Invoke_O__O(arg_189) } else { tmp5 = linked_187.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_186, arg_189) }; arg_194 = tmp4.Invoke_O__O(tmp5); if linked_191 == nil { return ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { return linked_191.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) } } else { var root_199 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_195 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = b__1991000030__6; if linked_196 == nil { arg_202 = ifn_197.Invoke_O__O(arg_198) } else { arg_202 = linked_196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_195, arg_198) }; var arg_203 any; if linked_200 == nil { return ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { return linked_200.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) } } } else { var f__4 any; var root_204 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = s__1991000028__3; if linked_205 == nil { f__4 = ifn_206.Invoke_O__O(arg_207) } else { f__4 = linked_205.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_204, arg_207) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var root_208 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_212 any = Lit_28; if linked_209 == nil { tmp6 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { tmp6 = linked_209.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_208, arg_211, arg_212) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :60:1
	if jrt.J2g_Truth(tmp6) { var root_225 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any; var tmp7 any; var root_213 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_215 lang.IFn

		if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_214 == nil { tmp7 = ifn_215.Invoke_O__O(arg_216) } else { tmp7 = linked_214.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_213, arg_216) }
//line :60:1
		arg_228 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_229 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000027); var tmp9 any; var root_221 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__1991000028__3; if linked_222 == nil { tmp9 = ifn_223.Invoke_O__O(arg_224) } else { tmp9 = linked_222.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_221, arg_224) }; arg_229 = tmp8.Invoke_O__O(tmp9); if linked_226 == nil { return ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { return linked_226.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } } else { var tmp10 any; var root_230 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = s__1991000028__3; if linked_231 == nil { tmp10 = ifn_232.Invoke_O__O(arg_233) } else { tmp10 = linked_231.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_230, arg_233) }; s__1991000028__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :60:1
func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A) Ctor_O_O_I_O(c__vdir, c__b__1991000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_vdir = c__vdir; t.F_b__1991000030 = c__b__1991000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A) Invoke_O__O(self any) any { { var i__1991000029__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000029__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var root_163 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_167 any = Lit_28; if linked_164 == nil { tmp2 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { tmp2 = linked_164.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_163, arg_166, arg_167) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :60:1
	if jrt.J2g_Truth(tmp2) { var root_176 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = t.F_b__1991000030; var arg_180 any; var tmp3 any; var root_168 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_170 lang.IFn

		if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_169 == nil { tmp3 = ifn_170.Invoke_O__O(arg_171) } else { tmp3 = linked_169.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_168, arg_171) }
//line :60:1
		arg_180 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_177 == nil { ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { linked_177.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) }; i__1991000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000029__1); continue L1 } else { i__1991000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000029__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_fn__1991000038_A_New() *A_arbace_j2g_embed_sources_fn__1991000038_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_A) Ctor() {}
//line :63:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_A) Invoke_O_O_O__O(self, m__1, p__1991000037__2 any) any { var vec__1991000039__3 any = p__1991000037__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000039__3, lang.RT_IntCast_J__I_NoInit(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000039__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_236 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_238 lang.IFn; if


	linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = rel__4; var arg_240 any = Lit_44; if linked_237 == nil { tmp1 = ifn_238.Invoke_O_O__O(arg_239, arg_240) } else { tmp1 = linked_237.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_236, arg_239, arg_240) }; if /*line :64:1*/ jrt.J2g_Truth(tmp1) { var p__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28); var tmp3 any; var root_241 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_243 lang.IFn


		if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = rel__4; var arg_245 any = A_arbace_j2g_embed_A_const_33; var arg_246 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_44)))).Ref(); if linked_242 == nil { tmp3 = ifn_243.Invoke_O_O_O__O(arg_244, arg_245, arg_246) } else { tmp3 = linked_242.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_241, arg_244, arg_245, arg_246) }; p__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
//line :64:1
		var pairs__7 any; var root_251 any = A_arbace_j2g_embed_A_const_34.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_253 lang.IFn



		if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = A_arbace_j2g_embed_A_const_35; var arg_255 any; var root_247 any = A_arbace_j2g_embed_A_const_36.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = text__5; if linked_248 == nil { arg_255 = ifn_249.Invoke_O__O(arg_250) } else { arg_255 = linked_248.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_247, arg_250) }; if linked_252 == nil { pairs__7 = ifn_253.Invoke_O_O__O(arg_254, arg_255) } else { pairs__7 = linked_252.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_251, arg_254, arg_255) }
		var tmp4 any; var root_319 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = m__1; var arg_323 any = p__6; if linked_320 == nil { tmp4 = ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { tmp4 = linked_320.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }; if jrt.J2g_Truth(tmp4) { } else { var tmp5 any; var root_324 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_326 lang.IFn
			if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(); var arg_328 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_325 == nil { tmp5 = ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { tmp5 = linked_325.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_324, arg_327, arg_328) }
//line :69:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5)))
		}
		var root_289 any = A_arbace_j2g_embed_A_const_37.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = m__1; var arg_293 any = p__6; var arg_294 any; var tmp6 any = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp7 *jrt.Class; var fncls__288 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class; if fncls__288 == nil { var fncls__288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class = fncls__288d; tmp7 = fncls__288d } else { tmp7 = fncls__288 }; arg_294 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_290 == nil { return ifn_291.Invoke_O_O_O__O(arg_292, arg_293, arg_294) } else { return linked_290.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_289, arg_292, arg_293, arg_294) } } else {
//line :64:1
			var tmp8 any; var root_295 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_297 lang.IFn














			if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = rel__4; var arg_299 any = Lit_49; if linked_296 == nil { tmp8 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp8 = linked_296.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_295, arg_298, arg_299) }
//line :64:1
			if jrt.J2g_Truth(tmp8) { var p__6_2 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28); var tmp10 any; var root_300 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_302 lang.IFn















				if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = rel__4; var arg_304 any = A_arbace_j2g_embed_A_const_33; var arg_305 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_49)))).Ref(); if linked_301 == nil { tmp10 = ifn_302.Invoke_O_O_O__O(arg_303, arg_304, arg_305) } else { tmp10 = linked_301.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_300, arg_303, arg_304, arg_305) }; p__6_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil)).Ref()
				var tmp11 any; var root_329 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = m__1; var arg_333 any = p__6_2; if linked_330 == nil { tmp11 = ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { tmp11 = linked_330.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_329, arg_332, arg_333) }; if jrt.J2g_Truth(tmp11) { } else { var tmp12 any; var root_334 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_336 lang.IFn
					if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(); var arg_338 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_335 == nil { tmp12 = ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { tmp12 = linked_335.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) }
//line :81:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp12)))
				}
				var root_306 any = A_arbace_j2g_embed_A_const_37.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = m__1; var arg_310 any = p__6_2; var arg_311 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_312 any = text__5; if linked_307 == nil { return ifn_308.Invoke_O_O_O_O__O(arg_309, arg_310, arg_311, arg_312) } else { return linked_307.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_306, arg_309, arg_310, arg_311, arg_312) } } else {
//line :64:1
					if A_arbace_j2g_embed_A_const_41 != nil {



















						var root_313 any = A_arbace_j2g_embed_A_const_42.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = m__1; var arg_317 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(); var arg_318 any = text__5; if linked_314 == nil { return ifn_315.Invoke_O_O_O__O(arg_316, arg_317, arg_318) } else { return linked_314.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_313, arg_316, arg_317, arg_318) } } else {
//line :64:1
							return nil } } } }






func A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :71:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A) Invoke_O_O__O(self, src__1 any) any {
	var root_282 any = A_arbace_j2g_embed_A_const_31.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var tmp1 any = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_New_O_O(t.F_p, t.F_rel); var tmp2 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class; if fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class = fncls__281d; tmp2 = fncls__281d } else { tmp2 = fncls__281 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_286 any = src__1; var arg_287 any = t.F_pairs; if linked_283 == nil { return ifn_284.Invoke_O_O_O__O(arg_285, arg_286, arg_287) } else { return linked_283.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_282, arg_285, arg_286, arg_287) } }
//line :72:1
func A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :72:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :72:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A) Invoke_O_O_O__O(self, src__1, p__1991000043__2 any) any { var vec__1991000045__3 any = p__1991000043__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000045__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000045__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var root_267 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); var arg_271 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref(); if linked_268 == nil { tmp1 = ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { tmp1 = linked_268.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_267, arg_270, arg_271) } }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_276 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_278 lang.IFn
		if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var tmp3 any = t.F_rel; var arg_279 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_51, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_40.GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(); var arg_280 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_277 == nil { tmp2 = ifn_278.Invoke_O_O__O(arg_279, arg_280) } else { tmp2 = linked_277.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_276, arg_279, arg_280) }
//line :74:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp4 /*line :77:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp5 any; var root_256 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = src__1; var arg_260 any = A_arbace_j2g_embed_A_const_33; var arg_261 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); if linked_257 == nil { tmp5 = ifn_258.Invoke_O_O_O__O(arg_259, arg_260, arg_261) } else { tmp5 = linked_257.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_256, arg_259, arg_260, arg_261) }; var tmp6 any = tmp5; var tmp7 any; var root_262 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = src__1; var arg_266 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__6), int64(lang.RT_Count_O__I_NoInit(old__4)))).Ref(); if linked_263 == nil { tmp7 = ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { tmp7 = linked_263.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp6, new__5, tmp7)).Ref() }















func A_arbace_j2g_embed_reify__1991000052_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_j2g_embed_reify__1991000052_A { t := &A_arbace_j2g_embed_reify__1991000052_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :93:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :93:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :93:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :93:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :93:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_j2g_embed_A_Init(); tmp1 = A_arbace_j2g_embed_A_const_48; return lang.Symbol_Cast(tmp1) }
//line :93:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :93:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_j2g_embed_reify__1991000052_A_New_IPersistentMap(m) }





func A_arbace_j2g_embed_read_all_A_New() *A_arbace_j2g_embed_read_all_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_j2g_embed_read_all_A) Ctor() {}
//line :99:1
func (t *A_arbace_j2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var root_385 any = A_arbace_j2g_embed_A_const_53.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_387 lang.IFn; if

	linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_embed_A_const_55; var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any = A_arbace_j2g_embed_A_const_56; var tmp5 any = A_arbace_j2g_embed_A_const_57.GetRawRoot__O(); var tmp6 any = A_arbace_j2g_embed_A_const_58; var tmp7 any = A_arbace_j2g_embed_read_all_fn__1991000054_A_New(); var tmp8 *jrt.Class; var fncls__375 *jrt.Class = A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class; if

	fncls__375 == nil { var fncls__375d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class = fncls__375d; tmp8 = fncls__375d } else { tmp8 = fncls__375 }; arg_388 = /*line :101:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); if linked_386 == nil { ifn_387.Invoke_O__O(arg_388) } else { linked_386.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_385, arg_388) }; var tmp9 any; tmp11 := /*line :99:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any; var root_367 any = A_arbace_j2g_embed_A_const_49.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_369 lang.IFn





		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = A_arbace_j2g_embed_A_const_50; var arg_371 any = r__2; if linked_368 == nil { f__6 = ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { f__6 = linked_368.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) }
		if lang.Util_Equiv_O_O__Z_NoInit(f__6, A_arbace_j2g_embed_A_const_51) { tmp9 = acc__5 } else { var tmp10 any; var root_389 any = A_arbace_j2g_embed_A_const_10.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = acc__5; var arg_393 any = f__6; if linked_390 == nil { tmp10 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { tmp10 = linked_390.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }; acc__5 = tmp10; continue L1 }
//line :99:1
		break L1 } }; return nil }(); var root_372 any = A_arbace_j2g_embed_A_const_52.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_374 lang.IFn; if

	linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; if linked_373 == nil { ifn_374.Invoke__O() } else { linked_373.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_372) }; if /*line :99:1*/ tmp11 != nil { panic(tmp11) }; return tmp9 }



func A_arbace_j2g_embed_read_all_fn__1991000054_A_New() *A_arbace_j2g_embed_read_all_fn__1991000054_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_fn__1991000054_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000054_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000054_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_j2g_embed_class_like_QMARK__A_New() *A_arbace_j2g_embed_class_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Ctor() {}
//line :108:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_1); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)), int64(lang.RT_Count_O__I_NoInit(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_embed_package_like_QMARK__A_New() *A_arbace_j2g_embed_package_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_1))); if and__1927000168__auto____2 {
											var root_398 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var root_394 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = s__0; if linked_395 == nil { arg_401 = ifn_396.Invoke_O__O(arg_397) } else { arg_401 = linked_395.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_394, arg_397) }; if linked_399 == nil { return ifn_400.Invoke_O__O(arg_401) } else { return linked_399.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_398, arg_401) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_embed_names_A_New() *A_arbace_j2g_embed_names_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_j2g_embed_names_A) Ctor() {}
//line :115:1
func (t *A_arbace_j2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any; var root_402 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_404 lang.IFn; if



	linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_403 == nil { acc__2 = ifn_404.Invoke_O__O(arg_405) } else { acc__2 = linked_403.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_402, arg_405) }; var walk__3 any; var tmp1 any = /*line :115:1*/A_arbace_j2g_embed_names_walk__1991000059_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__647 *jrt.Class = A_arbace_j2g_embed_names_walk__1991000059_A_fn_class; if




	fncls__647 == nil { var fncls__647d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_embed_names_walk__1991000059_A_fn_class = fncls__647d; tmp2 = fncls__647d } else { tmp2 = fncls__647 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var seq_1991000083__4 any; var root_656 any = /*line :115:1*/A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_658 lang.IFn; if




















	linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any; var root_652 any = A_arbace_j2g_embed_A_const_74.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, A_arbace_j2g_embed_read_all_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = text__0; if linked_653 == nil { arg_659 = ifn_654.Invoke_O__O(arg_655) } else { arg_659 = linked_653.(*A_arbace_j2g_embed_read_all_A).Invoke_O_O__O(root_652, arg_655) }; if linked_657 == nil { seq_1991000083__4 = ifn_658.Invoke_O__O(arg_659) } else { seq_1991000083__4 = linked_657.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_656, arg_659) }; var chunk_1991000084__5 any; var count_1991000085__6 int64 = 0; var i_1991000086__7 int64 = 0; L1:
//line :115:1
	for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000086__7, count_1991000085__6) { var f__8 any = lang.Indexed_Cast(chunk_1991000084__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000086__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000086__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_660 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = seq_1991000083__4; if linked_661 == nil { temp__1927000414__auto____8 = ifn_662.Invoke_O__O(arg_663) } else { temp__1927000414__auto____8 = linked_661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_660, arg_663) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1991000083__9 any = temp__1927000414__auto____8; var tmp3 any; var root_664 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = seq_1991000083__9; if linked_665 == nil { tmp3 = ifn_666.Invoke_O__O(arg_667) } else { tmp3 = linked_665.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_664, arg_667) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_668 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = seq_1991000083__9; if linked_669 == nil { c__1927000678__auto____10 = ifn_670.Invoke_O__O(arg_671) } else { c__1927000678__auto____10 = linked_669.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_668, arg_671) }; var tmp4 any; var root_676 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = seq_1991000083__9; if linked_677 == nil { tmp4 = ifn_678.Invoke_O__O(arg_679) } else { tmp4 = linked_677.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_676, arg_679) }; seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_672 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = seq_1991000083__9; if linked_673 == nil { f__10 = ifn_674.Invoke_O__O(arg_675) } else { f__10 = linked_673.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_672, arg_675) }; lang.IFn_Cast(walk__3).Invoke_O__O(f__10); var tmp5 any; var root_680 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = seq_1991000083__9; if linked_681 == nil { tmp5 = ifn_682.Invoke_O__O(arg_683) } else { tmp5 = linked_681.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_680, arg_683) }; seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = tmp5, nil, 0, 0; continue L1 } } }
//line :115:1
		break L1 }; var root_648 any =





















	A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = acc__2; if linked_649 == nil { return ifn_650.Invoke_O__O(arg_651) } else { return linked_649.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_648, arg_651) } }
//line :120:1
func A_arbace_j2g_embed_names_walk__1991000059_A_New_O(p0 any) *A_arbace_j2g_embed_names_walk__1991000059_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_walk__1991000059_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_j2g_embed_names_walk__1991000059_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :120:1
func (t *A_arbace_j2g_embed_names_walk__1991000059_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__1)
											if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											var tmp1 any; var root_406 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_408 lang.IFn
											if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = x__1; if linked_407 == nil { tmp1 = ifn_408.Invoke_O__O(arg_409) } else { tmp1 = linked_407.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_406, arg_409) }
//line :122:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any; var root_507 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = x__1; if linked_508 == nil { tmp3 = ifn_509.Invoke_O__O(arg_510) } else { tmp3 = linked_508.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_507, arg_510) }; and__1927000168__auto____2 = lang.Util_Identical_O_O__Z_NoInit(tmp3, nil); if and__1927000168__auto____2 { var root_515 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any; var root_511 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = x__1; if linked_512 == nil { arg_518 = ifn_513.Invoke_O__O(arg_514) } else { arg_518 = linked_512.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_511, arg_514) }; if linked_516 == nil { tmp2 = ifn_517.Invoke_O__O(arg_518) } else { tmp2 = linked_516.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_515, arg_518) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) {
			var root_523 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = t.F_acc; var arg_527 any; var root_519 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = x__1; if linked_520 == nil { arg_527 = ifn_521.Invoke_O__O(arg_522) } else { arg_527 = linked_520.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_519, arg_522) }; if linked_524 == nil { ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { linked_524.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_523, arg_526, arg_527) } }
		var tmp4 any; var and__1927000168__auto____2_2 any; var root_410 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = x__1; if linked_411 == nil { and__1927000168__auto____2_2 = ifn_412.Invoke_O__O(arg_413) } else { and__1927000168__auto____2_2 = linked_411.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_410, arg_413) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var root_418 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any; var root_414 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = x__1; if linked_415 == nil { arg_421 = ifn_416.Invoke_O__O(arg_417) } else { arg_421 = linked_415.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_414, arg_417) }; if linked_419 == nil { tmp4 = ifn_420.Invoke_O__O(arg_421) } else { tmp4 = linked_419.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_418, arg_421) } } else { tmp4 = and__1927000168__auto____2_2 }; if jrt.J2g_Truth(tmp4) {
			var root_426 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = t.F_acc; var arg_430 any; var root_422 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = x__1; if linked_423 == nil { arg_430 = ifn_424.Invoke_O__O(arg_425) } else { arg_430 = linked_423.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_422, arg_425) }; if linked_427 == nil { return ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { return linked_427.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_426, arg_429, arg_430) } } else {
//line :126:1
				return nil } } else {
//line :122:1
					var tmp5 any; var or__1927000174__auto____2 any; var root_431 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_433 lang.IFn





					if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = x__1; if linked_432 == nil { or__1927000174__auto____2 = ifn_433.Invoke_O__O(arg_434) } else { or__1927000174__auto____2 = linked_432.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_431, arg_434) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { var root_435 any = A_arbace_j2g_embed_A_const_66.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = x__1; if linked_436 == nil { tmp5 = ifn_437.Invoke_O__O(arg_438) } else { tmp5 = linked_436.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_435, arg_438) } }
//line :122:1
					if jrt.J2g_Truth(tmp5) {






						var tmp6 any; var and__1927000168__auto____2_3 any; var root_532 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any; var root_528 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = x__1; if linked_529 == nil { arg_535 = ifn_530.Invoke_O__O(arg_531) } else { arg_535 = linked_529.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_528, arg_531) }; if linked_533 == nil { and__1927000168__auto____2_3 = ifn_534.Invoke_O__O(arg_535) } else { and__1927000168__auto____2_3 = linked_533.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_532, arg_535) }; if jrt.J2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool; var tmp7 any; var root_540 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any; var root_536 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = x__1; if linked_537 == nil { arg_543 = ifn_538.Invoke_O__O(arg_539) } else { arg_543 = linked_537.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_536, arg_539) }; if linked_541 == nil { tmp7 = ifn_542.Invoke_O__O(arg_543) } else { tmp7 = linked_541.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_540, arg_543) }; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z_NoInit(tmp7, nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_552 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_j2g_embed_package_like_QMARK__A_fn_class); var ifn_554 lang.IFn
							if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any; var root_548 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var root_544 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = x__1; if linked_545 == nil { arg_551 = ifn_546.Invoke_O__O(arg_547) } else { arg_551 = linked_545.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_544, arg_547) }; if linked_549 == nil { arg_555 = ifn_550.Invoke_O__O(arg_551) } else { arg_555 = linked_549.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_548, arg_551) }; if linked_553 == nil { and__1927000168__auto____4 = ifn_554.Invoke_O__O(arg_555) } else { and__1927000168__auto____4 = linked_553.(*A_arbace_j2g_embed_package_like_QMARK__A).Invoke_O_O__O(root_552, arg_555) }
//line :129:1
							if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_560 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_562 lang.IFn
								if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any; var root_556 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = x__1; if linked_557 == nil { arg_563 = ifn_558.Invoke_O__O(arg_559) } else { arg_563 = linked_557.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_556, arg_559) }; if linked_561 == nil { and__1927000168__auto____5 = ifn_562.Invoke_O__O(arg_563) } else { and__1927000168__auto____5 = linked_561.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_560, arg_563) }
//line :129:1
								if jrt.J2g_Truth(and__1927000168__auto____5) {

									var root_568 any = A_arbace_j2g_embed_A_const_71.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var arg_572 any; var root_564 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = x__1; if linked_565 == nil { arg_572 = ifn_566.Invoke_O__O(arg_567) } else { arg_572 = linked_565.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_564, arg_567) }; if linked_569 == nil { tmp6 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { tmp6 = linked_569.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_568, arg_571, arg_572) } } else {
//line :129:1
										tmp6 = and__1927000168__auto____5 } } else { tmp6 = and__1927000168__auto____4 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp6 = and__1927000168__auto____2_3 }; if jrt.J2g_Truth(tmp6) { var seq_1991000060__2 any; var root_577 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_579 lang.IFn


											if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any; var root_573 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = x__1; if linked_574 == nil { arg_580 = ifn_575.Invoke_O__O(arg_576) } else { arg_580 = linked_574.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_573, arg_576) }; if linked_578 == nil { seq_1991000060__2 = ifn_579.Invoke_O__O(arg_580) } else { seq_1991000060__2 = linked_578.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_577, arg_580) }
//line :129:1
											var chunk_1991000061__3 any; var count_1991000062__4 int64 = 0; var i_1991000063__5 int64 = 0; L1: for {


												if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000063__5, count_1991000062__4) { var c__6 any = lang.Indexed_Cast(chunk_1991000061__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000063__5)); var root_601 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = t.F_acc; var arg_605 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp9 any; var root_597 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = x__1; if linked_598 == nil { tmp9 = ifn_599.Invoke_O__O(arg_600) } else { tmp9 = linked_598.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_597, arg_600) }; arg_605 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, c__6)).Ref(); if linked_602 == nil { ifn_603.Invoke_O_O__O(arg_604, arg_605) } else { linked_602.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_601, arg_604, arg_605) }; seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000063__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_581 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = seq_1991000060__2; if linked_582 == nil { temp__1927000414__auto____6 = ifn_583.Invoke_O__O(arg_584) } else { temp__1927000414__auto____6 = linked_582.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1991000060__7 any = temp__1927000414__auto____6; var tmp10 any; var root_585 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = seq_1991000060__7; if linked_586 == nil { tmp10 = ifn_587.Invoke_O__O(arg_588) } else { tmp10 = linked_586.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____8 any; var root_589 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = seq_1991000060__7; if linked_590 == nil { c__1927000678__auto____8 = ifn_591.Invoke_O__O(arg_592) } else { c__1927000678__auto____8 = linked_590.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_589, arg_592) }; var tmp11 any; var root_606 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1991000060__7; if linked_607 == nil { tmp11 = ifn_608.Invoke_O__O(arg_609) } else { tmp11 = linked_607.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_606, arg_609) }; seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = tmp11, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_593 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = seq_1991000060__7; if linked_594 == nil { c__8 = ifn_595.Invoke_O__O(arg_596) } else { c__8 = linked_594.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_593, arg_596) }; var root_614 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = t.F_acc; var arg_618 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp13 any; var root_610 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = x__1; if linked_611 == nil { tmp13 = ifn_612.Invoke_O__O(arg_613) } else { tmp13 = linked_611.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_610, arg_613) }; arg_618 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, c__8)).Ref(); if linked_615 == nil { ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { linked_615.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; var tmp14 any; var root_619 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = seq_1991000060__7; if linked_620 == nil { tmp14 = ifn_621.Invoke_O__O(arg_622) } else { tmp14 = linked_620.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_619, arg_622) }; seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = tmp14, nil, 0, 0; continue L1 } } }
//line :129:1
												break L1 } }
//line :122:1
						var seq_1991000064__2 any; var root_439 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn










						if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = x__1; if linked_440 == nil { seq_1991000064__2 = ifn_441.Invoke_O__O(arg_442) } else { seq_1991000064__2 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }
//line :122:1
						var chunk_1991000065__3 any; var count_1991000066__4 int64 = 0; var i_1991000067__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000067__5, count_1991000066__4) { var y__6 any = lang.Indexed_Cast(chunk_1991000065__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000067__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000067__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_443 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_1991000064__2; if linked_444 == nil { temp__1927000414__auto____6_2 = ifn_445.Invoke_O__O(arg_446) } else { temp__1927000414__auto____6_2 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1991000064__7 any = temp__1927000414__auto____6_2; var tmp15 any; var root_447 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_1991000064__7; if linked_448 == nil { tmp15 = ifn_449.Invoke_O__O(arg_450) } else { tmp15 = linked_448.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_447, arg_450) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____8_2 any; var root_451 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = seq_1991000064__7; if linked_452 == nil { c__1927000678__auto____8_2 = ifn_453.Invoke_O__O(arg_454) } else { c__1927000678__auto____8_2 = linked_452.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_451, arg_454) }; var tmp16 any; var root_623 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = seq_1991000064__7; if linked_624 == nil { tmp16 = ifn_625.Invoke_O__O(arg_626) } else { tmp16 = linked_624.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_623, arg_626) }; seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = tmp16, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_455 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = seq_1991000064__7; if linked_456 == nil { y__8 = ifn_457.Invoke_O__O(arg_458) } else { y__8 = linked_456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_455, arg_458) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp17 any; var root_627 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = seq_1991000064__7; if linked_628 == nil { tmp17 = ifn_629.Invoke_O__O(arg_630) } else { tmp17 = linked_628.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_627, arg_630) }; seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = tmp17, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :122:1
								var tmp18 any; var root_459 any = A_arbace_j2g_embed_A_const_67.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_461 lang.IFn











								if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = x__1; if linked_460 == nil { tmp18 = ifn_461.Invoke_O__O(arg_462) } else { tmp18 = linked_460.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_459, arg_462) }
//line :122:1
								if jrt.J2g_Truth(tmp18) { var seq_1991000068__2 any; var root_463 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_465 lang.IFn











									if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = x__1; if linked_464 == nil { seq_1991000068__2 = ifn_465.Invoke_O__O(arg_466) } else { seq_1991000068__2 = linked_464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_463, arg_466) }
//line :122:1
									var chunk_1991000069__3 any; var count_1991000070__4 int64 = 0; var i_1991000071__5 int64 = 0; L3: for {











										if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000071__5, count_1991000070__4) { var vec__1991000072__6 any = lang.Indexed_Cast(chunk_1991000069__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000071__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000072__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000072__6, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000071__5); continue L3 } else { var temp__1927000414__auto____6_3 any; var root_467 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = seq_1991000068__2; if linked_468 == nil { temp__1927000414__auto____6_3 = ifn_469.Invoke_O__O(arg_470) } else { temp__1927000414__auto____6_3 = linked_468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1991000068__7 any = temp__1927000414__auto____6_3; var tmp19 any; var root_471 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq_1991000068__7; if linked_472 == nil { tmp19 = ifn_473.Invoke_O__O(arg_474) } else { tmp19 = linked_472.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_471, arg_474) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____8_3 any; var root_475 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = seq_1991000068__7; if linked_476 == nil { c__1927000678__auto____8_3 = ifn_477.Invoke_O__O(arg_478) } else { c__1927000678__auto____8_3 = linked_476.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_475, arg_478) }; var tmp20 any; var root_631 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = seq_1991000068__7; if linked_632 == nil { tmp20 = ifn_633.Invoke_O__O(arg_634) } else { tmp20 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_631, arg_634) }; seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = tmp20, c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1991000075__8 any; var root_479 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1991000068__7; if linked_480 == nil { vec__1991000075__8 = ifn_481.Invoke_O__O(arg_482) } else { vec__1991000075__8 = linked_480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_479, arg_482) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000075__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000075__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); var tmp21 any; var root_635 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = seq_1991000068__7; if linked_636 == nil { tmp21 = ifn_637.Invoke_O__O(arg_638) } else { tmp21 = linked_636.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_635, arg_638) }; seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = tmp21, nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :122:1
											var tmp22 any; var root_483 any = A_arbace_j2g_embed_A_const_68.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_485 lang.IFn












											if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = x__1; if linked_484 == nil { tmp22 = ifn_485.Invoke_O__O(arg_486) } else { tmp22 = linked_484.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_483, arg_486) }
//line :122:1
											if jrt.J2g_Truth(tmp22) { var seq_1991000078__2 any; var root_487 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_489 lang.IFn












												if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = x__1; if linked_488 == nil { seq_1991000078__2 = ifn_489.Invoke_O__O(arg_490) } else { seq_1991000078__2 = linked_488.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_487, arg_490) }
//line :122:1
												var chunk_1991000079__3 any; var count_1991000080__4 int64 = 0; var i_1991000081__5 int64 = 0; L4: for {












													if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000081__5, count_1991000080__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1991000079__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000081__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000081__5); continue L4 } else { var temp__1927000414__auto____6_4 any; var root_491 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = seq_1991000078__2; if linked_492 == nil { temp__1927000414__auto____6_4 = ifn_493.Invoke_O__O(arg_494) } else { temp__1927000414__auto____6_4 = linked_492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_491, arg_494) }; if jrt.J2g_Truth(temp__1927000414__auto____6_4) { var seq_1991000078__7 any = temp__1927000414__auto____6_4; var tmp23 any; var root_495 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = seq_1991000078__7; if linked_496 == nil { tmp23 = ifn_497.Invoke_O__O(arg_498) } else { tmp23 = linked_496.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_495, arg_498) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____8_4 any; var root_499 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = seq_1991000078__7; if linked_500 == nil { c__1927000678__auto____8_4 = ifn_501.Invoke_O__O(arg_502) } else { c__1927000678__auto____8_4 = linked_500.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_499, arg_502) }; var tmp24 any; var root_639 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = seq_1991000078__7; if linked_640 == nil { tmp24 = ifn_641.Invoke_O__O(arg_642) } else { tmp24 = linked_640.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_639, arg_642) }; seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = tmp24, c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var y__8_2 any; var root_503 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_1991000078__7; if linked_504 == nil { y__8_2 = ifn_505.Invoke_O__O(arg_506) } else { y__8_2 = linked_504.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_503, arg_506) }; lang.IFn_Cast(self).Invoke_O__O(y__8_2); var tmp25 any; var root_643 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = seq_1991000078__7; if linked_644 == nil { tmp25 = ifn_645.Invoke_O__O(arg_646) } else { tmp25 = linked_644.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_643, arg_646) }; seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = tmp25, nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :122:1
														return nil } } } } }; /*line :120:1*/panic("j2g: unreachable") }





























func A_arbace_j2g_embed_cut_candidates_A_New() *A_arbace_j2g_embed_cut_candidates_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var root_817 any = A_arbace_j2g_embed_A_const_75.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_New(); var tmp2 *jrt.Class; var fncls__792 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class; if fncls__792 == nil { var fncls__792d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class = fncls__792d; tmp2 = fncls__792d } else { tmp2 = fncls__792 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_812 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any; var root_807 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var arg_811 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_84.GetRawRoot__O()); var tmp6 any; var root_793 any = A_arbace_j2g_embed_A_const_85.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; if linked_794 == nil { tmp6 = ifn_795.Invoke__O() } else { tmp6 = linked_794.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_793) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_New(); var tmp9 *jrt.Class; var fncls__800 *jrt.Class = A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class; if fncls__800 == nil { var fncls__800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class = fncls__800d; tmp9 = fncls__800d } else { tmp9 = fncls__800 }; arg_811 = tmp5.Invoke_O_O_O__O(tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), srcs__0); if linked_808 == nil { arg_815 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { arg_815 = linked_808.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; var arg_816 any = A_arbace_j2g_embed_A_const_87.GetRawRoot__O(); if linked_813 == nil { tmp4 = ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { tmp4 = linked_813.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_812, arg_815, arg_816) }; arg_820 = tmp3.Invoke_O__O(tmp4); if linked_818 == nil { return ifn_819.Invoke_O__O(arg_820) } else { return linked_818.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_817, arg_820) } }
//line :155:1
func A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_New() *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_fn__1991000103_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A) Ctor() {}
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A) Invoke_O_O__O(self, p__1991000102__1 any) any { var vec__1991000104__2 any = p__1991000102__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000104__2, lang.RT_IntCast_J__I_NoInit(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000104__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_796 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, A_arbace_j2g_embed_names_A_fn_class); var ifn_798 lang.IFn; _ = ___3; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = text__4; if linked_797 == nil { return ifn_798.Invoke_O__O(arg_799) } else { return linked_797.(*A_arbace_j2g_embed_names_A).Invoke_O_O__O(root_796, arg_799) } }
//line :155:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_New() *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A) Ctor() {}
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A) Invoke_O_O__O(self, s__1991000089__1 any) any { var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_New_O_O(s__1991000089__1, self); var tmp2 *jrt.Class; var fncls__791 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class; if fncls__791 == nil { var fncls__791d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class = fncls__791d; tmp2 = fncls__791d } else { tmp2 = fncls__791 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :155:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A) Ctor_O_O(c__s__1991000089, c__iter__1991000088 any) { t.F_s__1991000089 = c__s__1991000089; t.F_iter__1991000088 = c__iter__1991000088 }
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A) Invoke_O__O(self any) any { { var s__1991000089__1 any; var t_ any = t.F_s__1991000089; t.F_s__1991000089 = nil; s__1991000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_684 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = s__1991000089__1; if linked_685 == nil { temp__1927000414__auto____2 = ifn_686.Invoke_O__O(arg_687) } else { temp__1927000414__auto____2 = linked_685.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_684, arg_687) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000089__3 any = temp__1927000414__auto____2; var tmp1 any; var root_688 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = s__1991000089__3; if linked_689 == nil { tmp1 = ifn_690.Invoke_O__O(arg_691) } else { tmp1 = linked_689.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_688, arg_691) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_692 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = s__1991000089__3; if linked_693 == nil { c__1927001037__auto____4 = ifn_694.Invoke_O__O(arg_695) } else { c__1927001037__auto____4 = linked_693.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_692, arg_695) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000091__6 any; var root_696 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_697 == nil { b__1991000091__6 = ifn_698.Invoke_O__O(arg_699) } else { b__1991000091__6 = linked_697.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_696, arg_699) }; var tmp2 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_New_O_I_O(b__1991000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__728 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class; if fncls__728 == nil { var fncls__728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class = fncls__728d; tmp3 = fncls__728d } else { tmp3 = fncls__728 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_737 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any; var root_729 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = b__1991000091__6; if linked_730 == nil { arg_740 = ifn_731.Invoke_O__O(arg_732) } else { arg_740 = linked_730.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_729, arg_732) }; var arg_741 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000088); var tmp5 any; var root_733 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = s__1991000089__3; if linked_734 == nil { tmp5 = ifn_735.Invoke_O__O(arg_736) } else { tmp5 = linked_734.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_733, arg_736) }; arg_741 = tmp4.Invoke_O__O(tmp5); if linked_738 == nil { return ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { return linked_738.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_737, arg_740, arg_741) } } else { var root_746 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var root_742 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = b__1991000091__6; if linked_743 == nil { arg_749 = ifn_744.Invoke_O__O(arg_745) } else { arg_749 = linked_743.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_742, arg_745) }; var arg_750 any; if linked_747 == nil { return ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { return linked_747.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } } } else { var n__4 any; var root_751 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = s__1991000089__3; if linked_752 == nil { n__4 = ifn_753.Invoke_O__O(arg_754) } else { n__4 = linked_752.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_751, arg_754) }; var tmp6 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_755 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_757 lang.IFn
															if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = A_arbace_j2g_embed_A_const_77; var arg_759 any = n__4; if linked_756 == nil { or__1927000174__auto____5 = ifn_757.Invoke_O_O__O(arg_758, arg_759) } else { or__1927000174__auto____5 = linked_756.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_755, arg_758, arg_759) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
																var root_760 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = A_arbace_j2g_embed_A_const_78; var arg_764 any = n__4; if linked_761 == nil { and__1927000168__auto____5 = ifn_762.Invoke_O_O__O(arg_763, arg_764) } else { and__1927000168__auto____5 = linked_761.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_760, arg_763, arg_764) } }
//line :156:1
	if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_766 any = A_arbace_j2g_embed_A_const_79.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = A_arbace_j2g_embed_A_const_80; var arg_770 any = n__4; var arg_771 any; var tmp7 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_New_O(n__4); var tmp8 *jrt.Class; var fncls__765 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class; if fncls__765 == nil { var fncls__765d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class = fncls__765d; tmp8 = fncls__765d } else { tmp8 = fncls__765 }; arg_771 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_767 == nil { tmp6 = ifn_768.Invoke_O_O_O__O(arg_769, arg_770, arg_771) } else { tmp6 = linked_767.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_766, arg_769, arg_770, arg_771) } } else {
//line :156:1
			tmp6 = and__1927000168__auto____5 }
//line :155:1
	if jrt.J2g_Truth(tmp6) { var root_782 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any; var root_772 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_774 lang.IFn






		if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = n__4; var arg_776 any = Lit_1; var arg_777 any = Lit_7; if linked_773 == nil { arg_785 = ifn_774.Invoke_O_O_O__O(arg_775, arg_776, arg_777) } else { arg_785 = linked_773.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_772, arg_775, arg_776, arg_777) }
//line :155:1
		var arg_786 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1991000088); var tmp10 any; var root_778 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = s__1991000089__3; if linked_779 == nil { tmp10 = ifn_780.Invoke_O__O(arg_781) } else { tmp10 = linked_779.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_778, arg_781) }; arg_786 = tmp9.Invoke_O__O(tmp10); if linked_783 == nil { return ifn_784.Invoke_O_O__O(arg_785, arg_786) } else { return linked_783.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_782, arg_785, arg_786) } } else { var tmp11 any; var root_787 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = s__1991000089__3; if linked_788 == nil { tmp11 = ifn_789.Invoke_O__O(arg_790) } else { tmp11 = linked_788.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_787, arg_790) }; s__1991000089__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :155:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A) Ctor_O_I_O(c__b__1991000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000091 = c__b__1991000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :155:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A) Invoke_O__O(self any) any { { var i__1991000090__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000090__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_700 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_702 lang.IFn
																	if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_j2g_embed_A_const_77; var arg_704 any = n__2; if linked_701 == nil { or__1927000174__auto____3 = ifn_702.Invoke_O_O__O(arg_703, arg_704) } else { or__1927000174__auto____3 = linked_701.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_700, arg_703, arg_704) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
																		var root_705 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = A_arbace_j2g_embed_A_const_78; var arg_709 any = n__2; if linked_706 == nil { and__1927000168__auto____3 = ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { and__1927000168__auto____3 = linked_706.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) } }
//line :156:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {


		var root_711 any = A_arbace_j2g_embed_A_const_79.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = A_arbace_j2g_embed_A_const_80; var arg_715 any = n__2; var arg_716 any; var tmp3 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_New_O(n__2); var tmp4 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class; if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class = fncls__710d; tmp4 = fncls__710d } else { tmp4 = fncls__710 }; arg_716 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_712 == nil { tmp2 = ifn_713.Invoke_O_O_O__O(arg_714, arg_715, arg_716) } else { tmp2 = linked_712.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_711, arg_714, arg_715, arg_716) } } else {
//line :156:1
			tmp2 = and__1927000168__auto____3 }
//line :155:1
	if jrt.J2g_Truth(tmp2) { var root_723 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = t.F_b__1991000091; var arg_727 any; var root_717 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_719 lang.IFn






		if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = n__2; var arg_721 any = Lit_1; var arg_722 any = Lit_7; if linked_718 == nil { arg_727 = ifn_719.Invoke_O_O_O__O(arg_720, arg_721, arg_722) } else { arg_727 = linked_718.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_717, arg_720, arg_721, arg_722) }
//line :155:1
		if linked_724 == nil { ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { linked_724.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_723, arg_726, arg_727) }; i__1991000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000090__1); continue L1 } else { i__1991000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000090__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :159:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :159:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :159:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_j2g_embed_with_member_types_A_New() *A_arbace_j2g_embed_with_member_types_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_embed_with_member_types_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_types__1991000109_A_New(); var tmp2 *jrt.Class; var fncls__850 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class; if




	fncls__850 == nil { var fncls__850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class = fncls__850d; tmp2 = fncls__850d } else { tmp2 = fncls__850 }; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var elem__4 any; var tmp3 any = /*line :164:1*/A_arbace_j2g_embed_with_member_types_elem__1991000117_A_New(); var tmp4 *jrt.Class; var fncls__851 *jrt.Class = A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class; if








	fncls__851 == nil { var fncls__851d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class = fncls__851d; tmp4 = fncls__851d } else { tmp4 = fncls__851 }; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var member_types__5 any; var tmp5 any = /*line :164:1*/A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_New_O_O(elem__4, types__3); var tmp6 *jrt.Class; var fncls__973 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class; if










	fncls__973 == nil { var fncls__973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class = fncls__973d; tmp6 = fncls__973d } else { tmp6 = fncls__973 }; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var more__6 any; var iter__1927001039__auto____6 any; var tmp7 any = /*line :164:1*/A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp8 *jrt.Class; var fncls__1086 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class; if




















	fncls__1086 == nil { var fncls__1086d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class = fncls__1086d; tmp8 = fncls__1086d } else { tmp8 = fncls__1086 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); var root_1096 any =




	A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var root_1092 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any; var root_1087 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = cands__0; var arg_1091 any = more__6; if linked_1088 == nil { arg_1095 = ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { arg_1095 = linked_1088.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) }; if linked_1093 == nil { arg_1099 = ifn_1094.Invoke_O__O(arg_1095) } else { arg_1099 = linked_1093.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1092, arg_1095) }; if linked_1097 == nil { return ifn_1098.Invoke_O__O(arg_1099) } else { return linked_1097.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1096, arg_1099) } }
//line :169:1
func A_arbace_j2g_embed_with_member_types_types__1991000109_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_82.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_88.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_New(); var tmp4 *jrt.Class; var fncls__826 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class; if fncls__826 == nil { var fncls__826d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class = fncls__826d; tmp4 = fncls__826d } else { tmp4 = fncls__826 }; var tmp5 any = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp6 any; var root_833 any = A_arbace_j2g_embed_A_const_89.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_835 lang.IFn
	if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any; var tmp7 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_New(); var tmp8 *jrt.Class; var fncls__832 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class; if fncls__832 == nil { var fncls__832d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class = fncls__832d; tmp8 = fncls__832d } else { tmp8 = fncls__832 }; arg_836 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_837 any = jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref(); if linked_834 == nil { tmp6 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { tmp6 = linked_834.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }
//line :170:1
	var tmp9 any = tmp6; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_88.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_New(); var tmp12 *jrt.Class
	var fncls__838 /*line :170:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class

	if fncls__838 == nil { var fncls__838d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class = fncls__838d; tmp12 = fncls__838d } else { tmp12 = fncls__838 }
//line :170:1
	return tmp1.Invoke_O_O_O__O(tmp5, tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :170:1
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A) Ctor() {}
//line :170:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A) Invoke_O_O__O(self, m__1 any) any { var root_821 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(); var arg_825 any = jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref(); if linked_822 == nil { return ifn_823.Invoke_O_O__O(arg_824, arg_825) } else { return linked_822.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_821, arg_824, arg_825) } }
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A) Ctor() {}
//line :171:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_j2g_embed_with_member_types_elem__1991000117_A_New() *A_arbace_j2g_embed_with_member_types_elem__1991000117_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_elem__1991000117_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000117_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000117_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_A{}; t.Ctor_O_O(p0, p1); return t }
//line :175:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :175:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_New_O(n__1); var tmp2 *jrt.Class; var fncls__858 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class; if
														fncls__858 == nil { var fncls__858d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class = fncls__858d; tmp2 = fncls__858d } else { tmp2 = fncls__858 }; temp__1927000414__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var root_969 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_971 lang.IFn

		if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any; var root_965 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any; var root_961 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_New(); var tmp4 *jrt.Class; var fncls__955 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class
		if fncls__955 == nil { var fncls__955d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class = fncls__955d; tmp4 = fncls__955d } else { tmp4 = fncls__955 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp6 any; var root_956 any = A_arbace_j2g_embed_A_const_89.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = t.F_elem; var arg_960 any = lang.IFn_Cast(t.F_types).Invoke_O__O(c__3); if linked_957 == nil { tmp6 = ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { tmp6 = linked_957.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }; arg_964 = tmp5.Invoke_O__O(tmp6)
//line :178:1
		if linked_962 == nil { arg_968 = ifn_963.Invoke_O__O(arg_964) } else { arg_968 = linked_962.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_961, arg_964) }; if linked_966 == nil { arg_972 = ifn_967.Invoke_O__O(arg_968) } else { arg_972 = linked_966.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_965, arg_968) }; if linked_970 == nil { return ifn_971.Invoke_O__O(arg_972) } else { return linked_970.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_969, arg_972) } } else {
//line :176:1
			return nil } }
//line :176:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_852 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var t_ any = t.F_n; t.F_n = nil; arg_855 = t_; var arg_856 any = Lit_7; var arg_857 any = Lit_1; if linked_853 == nil { tmp2 = ifn_854.Invoke_O_O_O__O(arg_855, arg_856, arg_857) } else { tmp2 = linked_853.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_852, arg_855, arg_856, arg_857) }; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_New() *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A) Ctor() {}
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A) Invoke_O_O__O(self, s__1991000123__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_New_O_O(s__1991000123__1, self); var tmp2 *jrt.Class; var fncls__954 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class; if fncls__954 == nil { var fncls__954d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class = fncls__954d; tmp2 = fncls__954d } else { tmp2 = fncls__954 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :179:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A) Ctor_O_O(c__s__1991000123, c__iter__1991000122 any) { t.F_s__1991000123 = c__s__1991000123; t.F_iter__1991000122 = c__iter__1991000122 }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A) Invoke_O__O(self any) any { { var s__1991000123__1 any; var t_ any = t.F_s__1991000123; t.F_s__1991000123 = nil; s__1991000123__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_859 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = s__1991000123__1; if linked_860 == nil { temp__1927000414__auto____2 = ifn_861.Invoke_O__O(arg_862) } else { temp__1927000414__auto____2 = linked_860.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_859, arg_862) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_863 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_865 lang.IFn; if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = s__1991000123__3; if linked_864 == nil { tmp1 = ifn_865.Invoke_O__O(arg_866) } else { tmp1 = linked_864.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_863, arg_866) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_867 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = s__1991000123__3; if linked_868 == nil { c__1927001037__auto____4 = ifn_869.Invoke_O__O(arg_870) } else { c__1927001037__auto____4 = linked_868.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_867, arg_870) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000125__6 any; var root_871 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_872 == nil { b__1991000125__6 = ifn_873.Invoke_O__O(arg_874) } else { b__1991000125__6 = linked_872.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_871, arg_874) }; var tmp2 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_New_O_I_O(b__1991000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__895 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class; if fncls__895 == nil { var fncls__895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class = fncls__895d; tmp3 = fncls__895d } else { tmp3 = fncls__895 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_904 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any; var root_896 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = b__1991000125__6; if linked_897 == nil { arg_907 = ifn_898.Invoke_O__O(arg_899) } else { arg_907 = linked_897.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_896, arg_899) }; var arg_908 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000122); var tmp5 any; var root_900 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = s__1991000123__3; if linked_901 == nil { tmp5 = ifn_902.Invoke_O__O(arg_903) } else { tmp5 = linked_901.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_900, arg_903) }; arg_908 = tmp4.Invoke_O__O(tmp5); if linked_905 == nil { return ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { return linked_905.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) } } else { var root_913 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any; var root_909 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = b__1991000125__6; if linked_910 == nil { arg_916 = ifn_911.Invoke_O__O(arg_912) } else { arg_916 = linked_910.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_909, arg_912) }; var arg_917 any; if linked_914 == nil { return ifn_915.Invoke_O_O__O(arg_916, arg_917) } else { return linked_914.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_913, arg_916, arg_917) } } } else { var t__4 any; var root_918 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = s__1991000123__3; if linked_919 == nil { t__4 = ifn_920.Invoke_O__O(arg_921) } else { t__4 = linked_919.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_918, arg_921) }; var tmp6 any; var root_922 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_924 lang.IFn
																		if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref(); if linked_923 == nil { tmp6 = ifn_924.Invoke_O__O(arg_925) } else { tmp6 = linked_923.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_922, arg_925) }
//line :179:1
	if jrt.J2g_Truth(tmp6) { var tn__5 any; var root_926 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_928 lang.IFn

		if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(); var arg_930 any = Lit_1; var arg_931 any = Lit_7; if linked_927 == nil { tn__5 = ifn_928.Invoke_O_O_O__O(arg_929, arg_930, arg_931) } else { tn__5 = linked_927.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_926, arg_929, arg_930, arg_931) }
//line :179:1
		var tmp7 any; var and__1927000168__auto____6 any; var root_932 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_934 lang.IFn


		if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = A_arbace_j2g_embed_A_const_93; var arg_936 any = tn__5; if linked_933 == nil { and__1927000168__auto____6 = ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { and__1927000168__auto____6 = linked_933.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_932, arg_935, arg_936) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
			tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :182:1
				tmp7 = and__1927000168__auto____6 }
//line :179:1
		if jrt.J2g_Truth(tmp7) { var root_941 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = tn__5; var arg_945 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000122); var tmp9 any; var root_937 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = s__1991000123__3; if linked_938 == nil { tmp9 = ifn_939.Invoke_O__O(arg_940) } else { tmp9 = linked_938.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_937, arg_940) }; arg_945 = tmp8.Invoke_O__O(tmp9); if linked_942 == nil { return ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { return linked_942.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) } } else { var tmp10 any; var root_946 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = s__1991000123__3; if linked_947 == nil { tmp10 = ifn_948.Invoke_O__O(arg_949) } else { tmp10 = linked_947.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_946, arg_949) }; s__1991000123__1 = tmp10; continue L1 } } else { var tmp11 any; var root_950 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = s__1991000123__3; if linked_951 == nil { tmp11 = ifn_952.Invoke_O__O(arg_953) } else { tmp11 = linked_951.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_950, arg_953) }; s__1991000123__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :179:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A) Ctor_O_I_O(c__b__1991000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000125 = c__b__1991000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A) Invoke_O__O(self any) any { { var i__1991000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000124__1)); var tmp2 any; var root_875 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_877 lang.IFn
																				if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref(); if linked_876 == nil { tmp2 = ifn_877.Invoke_O__O(arg_878) } else { tmp2 = linked_876.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_875, arg_878) }
//line :179:1
	if jrt.J2g_Truth(tmp2) { var tn__3 any; var root_879 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_881 lang.IFn

		if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(); var arg_883 any = Lit_1; var arg_884 any = Lit_7; if linked_880 == nil { tn__3 = ifn_881.Invoke_O_O_O__O(arg_882, arg_883, arg_884) } else { tn__3 = linked_880.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_879, arg_882, arg_883, arg_884) }
//line :179:1
		var tmp3 any; var and__1927000168__auto____4 any; var root_885 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_887 lang.IFn


		if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = A_arbace_j2g_embed_A_const_93; var arg_889 any = tn__3; if linked_886 == nil { and__1927000168__auto____4 = ifn_887.Invoke_O_O__O(arg_888, arg_889) } else { and__1927000168__auto____4 = linked_886.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_885, arg_888, arg_889) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
			tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :182:1
				tmp3 = and__1927000168__auto____4 }
//line :179:1
		if jrt.J2g_Truth(tmp3) { var root_890 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = t.F_b__1991000125; var arg_894 any = tn__3; if linked_891 == nil { ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { linked_891.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_890, arg_893, arg_894) }; i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } else { i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } } else { i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A) Invoke_O_O__O(self, s__1991000134__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1991000134__1, self); var tmp2 *jrt.Class; var fncls__1085 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class; if fncls__1085 == nil { var fncls__1085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class = fncls__1085d; tmp2 = fncls__1085d } else { tmp2 = fncls__1085 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :185:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1991000134, c__iter__1991000133 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1991000134 = c__s__1991000134; t.F_iter__1991000133 = c__iter__1991000133 }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A) Invoke_O__O(self any) any { { var s__1991000134__1 any; var t_ any = t.F_s__1991000134; t.F_s__1991000134 = nil; s__1991000134__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_974 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = s__1991000134__1; if linked_975 == nil { temp__1927000414__auto____2 = ifn_976.Invoke_O__O(arg_977) } else { temp__1927000414__auto____2 = linked_975.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_974, arg_977) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_978 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = xs__1927001018__auto____3; if linked_979 == nil { n__4 = ifn_980.Invoke_O__O(arg_981) } else { n__4 = linked_979.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_978, arg_981) }; var tmp1 any; var root_982 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_984 lang.IFn
															if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4); if linked_983 == nil { tmp1 = ifn_984.Invoke_O__O(arg_985) } else { tmp1 = linked_983.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_982, arg_985) }
//line :185:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_New_O(t.F_in_world_QMARK_); var tmp3 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class = fncls__1056d; tmp3 = fncls__1056d } else { tmp3 = fncls__1056 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1064 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var root_1058 any = A_arbace_j2g_embed_A_const_94.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A_fn_class); var ifn_1060 lang.IFn

		if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = A_arbace_j2g_embed_A_const_95; var arg_1062 any = n__4; var arg_1063 any; var tmp6 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_New_O_O(n__4, t.F_member_types); var tmp7 *jrt.Class; var fncls__1057 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class; if fncls__1057 == nil { var fncls__1057d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class = fncls__1057d; tmp7 = fncls__1057d } else { tmp7 = fncls__1057 }; arg_1063 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_1059 == nil { tmp5 = ifn_1060.Invoke_O_O_O__O(arg_1061, arg_1062, arg_1063) } else { tmp5 = linked_1059.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A).Invoke_O_O_O_O__O(root_1058, arg_1061, arg_1062, arg_1063) }
//line :185:1
		arg_1067 = tmp4.Invoke_O__O(tmp5); if linked_1065 == nil { fs__1927001036__auto____6 = ifn_1066.Invoke_O__O(arg_1067) } else { fs__1927001036__auto____6 = linked_1065.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1064, arg_1067) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1072 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any = fs__1927001036__auto____6; var arg_1076 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000133); var tmp9 any; var root_1068 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = s__1991000134__1; if linked_1069 == nil { tmp9 = ifn_1070.Invoke_O__O(arg_1071) } else { tmp9 = linked_1069.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1068, arg_1071) }; arg_1076 = tmp8.Invoke_O__O(tmp9); if linked_1073 == nil { return ifn_1074.Invoke_O_O__O(arg_1075, arg_1076) } else { return linked_1073.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1072, arg_1075, arg_1076) } } else { var tmp10 any; var root_1077 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = s__1991000134__1; if linked_1078 == nil { tmp10 = ifn_1079.Invoke_O__O(arg_1080) } else { tmp10 = linked_1078.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1077, arg_1080) }; s__1991000134__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1081 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = s__1991000134__1; if linked_1082 == nil { tmp11 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp11 = linked_1082.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1081, arg_1084) }; s__1991000134__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :185:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A) Invoke_O_O__O(self, s__1991000136__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_New_O_O_O(t.F_in_world_QMARK_, s__1991000136__1, self); var tmp2 *jrt.Class; var fncls__1055 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class; if fncls__1055 == nil { var fncls__1055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class = fncls__1055d; tmp2 = fncls__1055d } else { tmp2 = fncls__1055 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :185:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1991000136, c__iter__1991000135 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1991000136 = c__s__1991000136; t.F_iter__1991000135 = c__iter__1991000135 }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A) Invoke_O__O(self any) any { { var s__1991000136__1 any; var t_ any = t.F_s__1991000136; t.F_s__1991000136 = nil; s__1991000136__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_986 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = s__1991000136__1; if linked_987 == nil { temp__1927000414__auto____2 = ifn_988.Invoke_O__O(arg_989) } else { temp__1927000414__auto____2 = linked_987.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_986, arg_989) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000136__3 any = temp__1927000414__auto____2; var tmp1 any; var root_990 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = s__1991000136__3; if linked_991 == nil { tmp1 = ifn_992.Invoke_O__O(arg_993) } else { tmp1 = linked_991.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_990, arg_993) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_994 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = s__1991000136__3; if linked_995 == nil { c__1927001037__auto____4 = ifn_996.Invoke_O__O(arg_997) } else { c__1927001037__auto____4 = linked_995.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_994, arg_997) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000138__6 any; var root_998 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_999 == nil { b__1991000138__6 = ifn_1000.Invoke_O__O(arg_1001) } else { b__1991000138__6 = linked_999.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_998, arg_1001) }; var tmp2 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_New_O_O_I_O(b__1991000138__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class = fncls__1011d; tmp3 = fncls__1011d } else { tmp3 = fncls__1011 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1020 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any; var root_1012 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = b__1991000138__6; if linked_1013 == nil { arg_1023 = ifn_1014.Invoke_O__O(arg_1015) } else { arg_1023 = linked_1013.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1012, arg_1015) }; var arg_1024 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000135); var tmp5 any; var root_1016 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = s__1991000136__3; if linked_1017 == nil { tmp5 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp5 = linked_1017.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1016, arg_1019) }; arg_1024 = tmp4.Invoke_O__O(tmp5); if linked_1021 == nil { return ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { return linked_1021.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) } } else { var root_1029 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any; var root_1025 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = b__1991000138__6; if linked_1026 == nil { arg_1032 = ifn_1027.Invoke_O__O(arg_1028) } else { arg_1032 = linked_1026.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1025, arg_1028) }; var arg_1033 any; if linked_1030 == nil { return ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { return linked_1030.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) } } } else { var tn__4 any; var root_1034 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = s__1991000136__3; if linked_1035 == nil { tn__4 = ifn_1036.Invoke_O__O(arg_1037) } else { tn__4 = linked_1035.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1034, arg_1037) }; var tmp6 any; var root_1038 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1040 lang.IFn


	if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4); if linked_1039 == nil { tmp6 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp6 = linked_1039.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1038, arg_1041) }
//line :185:1
	if jrt.J2g_Truth(tmp6) { var root_1046 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = tn__4; var arg_1050 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000135); var tmp8 any; var root_1042 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = s__1991000136__3; if linked_1043 == nil { tmp8 = ifn_1044.Invoke_O__O(arg_1045) } else { tmp8 = linked_1043.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1042, arg_1045) }; arg_1050 = tmp7.Invoke_O__O(tmp8); if linked_1047 == nil { return ifn_1048.Invoke_O_O__O(arg_1049, arg_1050) } else { return linked_1047.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1046, arg_1049, arg_1050) } } else { var tmp9 any; var root_1051 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = s__1991000136__3; if linked_1052 == nil { tmp9 = ifn_1053.Invoke_O__O(arg_1054) } else { tmp9 = linked_1052.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1051, arg_1054) }; s__1991000136__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :185:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A) Ctor_O_O_I_O(c__b__1991000138, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000138 = c__b__1991000138; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :185:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A) Invoke_O__O(self any) any { { var i__1991000137__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000137__1)); var tmp2 any; var root_1002 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1004 lang.IFn


	if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2); if linked_1003 == nil { tmp2 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp2 = linked_1003.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1002, arg_1005) }
//line :185:1
	if jrt.J2g_Truth(tmp2) { var root_1006 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = t.F_b__1991000138; var arg_1010 any = tn__2; if linked_1007 == nil { ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { linked_1007.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) }; i__1991000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000137__1); continue L1 } else { i__1991000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000137__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :187:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :187:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_j2g_embed_data_A_New() *A_arbace_j2g_embed_data_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_j2g_embed_data_A) Ctor() {}
//line :195:1
func (t *A_arbace_j2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any; var root_1100 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1100, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1102 lang.IFn; if




	linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = dir__0; if linked_1101 == nil { base__2 = ifn_1102.Invoke_O__O(arg_1103) } else { base__2 = linked_1101.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1100, arg_1103) }; var root_1194 any =
	A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_45.GetRawRoot__O()).Invoke__O(); var arg_1198 any; if
	jrt.NN(jrt.File_Cast(base__2)).IsDirectory__Z() { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_New_O(base__2); var tmp2 *jrt.Class; var fncls__1189 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class
		if fncls__1189 == nil { var fncls__1189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class = fncls__1189d; tmp2 = fncls__1189d } else { tmp2 = fncls__1189 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1190 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = base__2; if linked_1191 == nil { tmp4 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp4 = linked_1191.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1190, arg_1193) }; arg_1198 = tmp3.Invoke_O__O(tmp4) } else {
//line :202:1
			arg_1198 = nil }; if /*line :201:1*/ linked_1195 == nil { return ifn_1196.Invoke_O_O__O(arg_1197, arg_1198) } else { return linked_1195.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1194, arg_1197, arg_1198) } }

func A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_New_O(p0 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_A{}; t.Ctor_O(p0); return t }
//line :203:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :203:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A) Invoke_O_O__O(self, s__1991000153__1 any) any { var tmp1 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_New_O_O_O(t.F_base, s__1991000153__1, self); var tmp2 *jrt.Class; var fncls__1188 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class; if fncls__1188 == nil { var fncls__1188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class = fncls__1188d; tmp2 = fncls__1188d } else { tmp2 = fncls__1188 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :203:1
func A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :203:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A) Ctor_O_O_O(c__base, c__s__1991000153, c__iter__1991000152 any) { t.F_base = c__base; t.F_s__1991000153 = c__s__1991000153; t.F_iter__1991000152 = c__iter__1991000152 }
//line :203:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A) Invoke_O__O(self any) any { { var s__1991000153__1 any; var t_ any = t.F_s__1991000153; t.F_s__1991000153 = nil; s__1991000153__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1107 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = s__1991000153__1; if linked_1108 == nil { temp__1927000414__auto____2 = ifn_1109.Invoke_O__O(arg_1110) } else { temp__1927000414__auto____2 = linked_1108.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1107, arg_1110) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000153__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1111 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = s__1991000153__3; if linked_1112 == nil { tmp1 = ifn_1113.Invoke_O__O(arg_1114) } else { tmp1 = linked_1112.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1111, arg_1114) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1115 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = s__1991000153__3; if linked_1116 == nil { c__1927001037__auto____4 = ifn_1117.Invoke_O__O(arg_1118) } else { c__1927001037__auto____4 = linked_1116.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1115, arg_1118) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000155__6 any; var root_1119 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1120 == nil { b__1991000155__6 = ifn_1121.Invoke_O__O(arg_1122) } else { b__1991000155__6 = linked_1120.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1119, arg_1122) }; var tmp2 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_New_O_I_O_O(t.F_base, size__1927001038__auto____5, b__1991000155__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1138 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class; if fncls__1138 == nil { var fncls__1138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class = fncls__1138d; tmp3 = fncls__1138d } else { tmp3 = fncls__1138 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1147 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any; var root_1139 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = b__1991000155__6; if linked_1140 == nil { arg_1150 = ifn_1141.Invoke_O__O(arg_1142) } else { arg_1150 = linked_1140.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1139, arg_1142) }; var arg_1151 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000152); var tmp5 any; var root_1143 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = s__1991000153__3; if linked_1144 == nil { tmp5 = ifn_1145.Invoke_O__O(arg_1146) } else { tmp5 = linked_1144.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1143, arg_1146) }; arg_1151 = tmp4.Invoke_O__O(tmp5); if linked_1148 == nil { return ifn_1149.Invoke_O_O__O(arg_1150, arg_1151) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1147, arg_1150, arg_1151) } } else { var root_1156 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any; var root_1152 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = b__1991000155__6; if linked_1153 == nil { arg_1159 = ifn_1154.Invoke_O__O(arg_1155) } else { arg_1159 = linked_1153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1152, arg_1155) }; var arg_1160 any; if linked_1157 == nil { return ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { return linked_1157.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) } } } else { var f__4 any; var root_1161 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = s__1991000153__3; if linked_1162 == nil { f__4 = ifn_1163.Invoke_O__O(arg_1164) } else { f__4 = linked_1162.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1161, arg_1164) }; if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var root_1179 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any; var tmp6 any; var root_1169 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1171 lang.IFn

	if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any; var root_1165 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_1166 == nil { arg_1172 = ifn_1167.Invoke_O__O(arg_1168) } else { arg_1172 = linked_1166.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1165, arg_1168) }; var arg_1173 any = jrt.File_separator.Ref(); var arg_1174 any = Lit_7; if linked_1170 == nil { tmp6 = ifn_1171.Invoke_O_O_O__O(arg_1172, arg_1173, arg_1174) } else { tmp6 = linked_1170.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1169, arg_1172, arg_1173, arg_1174) }
//line :203:1
	arg_1182 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, f__4); var arg_1183 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000152); var tmp8 any; var root_1175 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = s__1991000153__3; if linked_1176 == nil { tmp8 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp8 = linked_1176.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1175, arg_1178) }; arg_1183 = tmp7.Invoke_O__O(tmp8); if linked_1180 == nil { return ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { return linked_1180.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) } } else { var tmp9 any; var root_1184 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = s__1991000153__3; if linked_1185 == nil { tmp9 = ifn_1186.Invoke_O__O(arg_1187) } else { tmp9 = linked_1185.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1184, arg_1187) }; s__1991000153__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :203:1
func A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :203:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A) Ctor_O_I_O_O(c__base any, c__size__1927001038__auto__ int32, c__b__1991000155, c__c__1927001037__auto__ any) { t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000155 = c__b__1991000155; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :203:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A) Invoke_O__O(self any) any { { var i__1991000154__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000154__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var root_1133 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = t.F_b__1991000155; var arg_1137 any; var tmp2 any; var root_1127 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1129 lang.IFn

	if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any; var root_1123 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_1124 == nil { arg_1130 = ifn_1125.Invoke_O__O(arg_1126) } else { arg_1130 = linked_1124.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1123, arg_1126) }; var arg_1131 any = jrt.File_separator.Ref(); var arg_1132 any = Lit_7; if linked_1128 == nil { tmp2 = ifn_1129.Invoke_O_O_O__O(arg_1130, arg_1131, arg_1132) } else { tmp2 = linked_1128.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132) }
//line :203:1
	arg_1137 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, f__2); if linked_1134 == nil { ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { linked_1134.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) }; i__1991000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000154__1); continue L1 } else { i__1991000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000154__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_j2g_embed_image_type_forms_A_New() *A_arbace_j2g_embed_image_type_forms_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Ctor() {}
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any = A_arbace_j2g_embed_A_const_96; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_New_O(prog_dir__0); var tmp2 *jrt.Class; var fncls__1326 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class; if





	fncls__1326 == nil { var fncls__1326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class = fncls__1326d; tmp2 = fncls__1326d } else { tmp2 = fncls__1326 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_j2g_embed_A_const_112); var types__4 any; var root_1419 any = /*line :221:1*/A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1421 lang.IFn; if












	linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var arg_1423 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_84.GetRawRoot__O()); var tmp4 any; var root_1327 any = A_arbace_j2g_embed_A_const_85.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; if linked_1328 == nil { tmp4 = ifn_1329.Invoke__O() } else { tmp4 = linked_1328.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_1327) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_New_O(re__2); var tmp7 *jrt.Class; var fncls__1412 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class; if fncls__1412 == nil { var fncls__1412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class = fncls__1412d; tmp7 = fncls__1412d } else { tmp7 = fncls__1412 }; arg_1423 = tmp3.Invoke_O_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), files__3); if linked_1420 == nil { types__4 = ifn_1421.Invoke_O_O__O(arg_1422, arg_1423) } else { types__4 = linked_1420.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1419, arg_1422, arg_1423) }; var root_1629 any =



	A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_100, Lit_18, A_arbace_j2g_embed_A_const_101, A_arbace_j2g_embed_A_const_102)); var arg_1633 any; var iter__1927001039__auto____5 any; var tmp8 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_New(); var tmp9 *jrt.Class; var fncls__1614 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class; if
	fncls__1614 == nil { var fncls__1614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class = fncls__1614d; tmp9 = fncls__1614d } else { tmp9 = fncls__1614 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp11 any; var root_1624 any = A_arbace_j2g_embed_A_const_110.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_partition_all_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = A_arbace_j2g_embed_A_const_111; var arg_1628 any; var root_1619 any = A_arbace_j2g_embed_A_const_46.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_1623 any; var root_1615 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any = types__4; if linked_1616 == nil { arg_1623 = ifn_1617.Invoke_O__O(arg_1618) } else { arg_1623 = linked_1616.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1615, arg_1618) }; if linked_1620 == nil { arg_1628 = ifn_1621.Invoke_O_O__O(arg_1622, arg_1623) } else { arg_1628 = linked_1620.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1619, arg_1622, arg_1623) }; if linked_1625 == nil { tmp11 = ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { tmp11 = linked_1625.(*aot_arbace_core.A_arbace_core_partition_all_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) }; arg_1633 = tmp10.Invoke_O__O(tmp11); if /*line :238:1*/ linked_1630 == nil { return ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { return linked_1630.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) } }
//line :227:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A) Invoke_O_O__O(self, s__1991000164__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_New_O_O_O(t.F_prog_dir, s__1991000164__1, self); var tmp2 *jrt.Class; var fncls__1325 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class; if fncls__1325 == nil { var fncls__1325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class = fncls__1325d; tmp2 = fncls__1325d } else { tmp2 = fncls__1325 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :227:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A) Ctor_O_O_O(c__prog_dir, c__s__1991000164, c__iter__1991000163 any) { t.F_prog_dir = c__prog_dir; t.F_s__1991000164 = c__s__1991000164; t.F_iter__1991000163 = c__iter__1991000163 }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A) Invoke_O__O(self any) any { { var s__1991000164__1 any; var t_ any = t.F_s__1991000164; t.F_s__1991000164 = nil; s__1991000164__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1199 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = s__1991000164__1; if linked_1200 == nil { temp__1927000414__auto____2 = ifn_1201.Invoke_O__O(arg_1202) } else { temp__1927000414__auto____2 = linked_1200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1199, arg_1202) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1991000171__4 any; var root_1203 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = xs__1927001018__auto____3; if linked_1204 == nil { vec__1991000171__4 = ifn_1205.Invoke_O__O(arg_1206) } else { vec__1991000171__4 = linked_1204.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1203, arg_1206) }; var pkg__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000171__4, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000171__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dir__7 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_24, pkg__5); var iterys__1927001035__auto____8 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_New_O(alias__6); var tmp2 *jrt.Class; var fncls__1303 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class; if fncls__1303 == nil { var fncls__1303d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class = fncls__1303d; tmp2 = fncls__1303d } else { tmp2 = fncls__1303 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____9 any; var root_1308 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp4 any; var root_1304 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1306 lang.IFn

	if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = jrt.NN(jrt.File_Cast(dir__7)).ListFiles__File1().Ref(); if linked_1305 == nil { tmp4 = ifn_1306.Invoke_O__O(arg_1307) } else { tmp4 = linked_1305.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1304, arg_1307) }
//line :227:1
	arg_1311 = tmp3.Invoke_O__O(tmp4); if linked_1309 == nil { fs__1927001036__auto____9 = ifn_1310.Invoke_O__O(arg_1311) } else { fs__1927001036__auto____9 = linked_1309.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1308, arg_1311) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_1316 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = fs__1927001036__auto____9; var arg_1320 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1991000163); var tmp6 any; var root_1312 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = s__1991000164__1; if linked_1313 == nil { tmp6 = ifn_1314.Invoke_O__O(arg_1315) } else { tmp6 = linked_1313.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1312, arg_1315) }; arg_1320 = tmp5.Invoke_O__O(tmp6); if linked_1317 == nil { return ifn_1318.Invoke_O_O__O(arg_1319, arg_1320) } else { return linked_1317.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1316, arg_1319, arg_1320) } } else { var tmp7 any; var root_1321 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = s__1991000164__1; if linked_1322 == nil { tmp7 = ifn_1323.Invoke_O__O(arg_1324) } else { tmp7 = linked_1322.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1321, arg_1324) }; s__1991000164__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :227:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A) Invoke_O_O__O(self, s__1991000166__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_New_O_O_O(t.F_alias, s__1991000166__1, self); var tmp2 *jrt.Class; var fncls__1302 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class; if fncls__1302 == nil { var fncls__1302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class = fncls__1302d; tmp2 = fncls__1302d } else { tmp2 = fncls__1302 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :227:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A) Ctor_O_O_O(c__alias, c__s__1991000166, c__iter__1991000165 any) { t.F_alias = c__alias; t.F_s__1991000166 = c__s__1991000166; t.F_iter__1991000165 = c__iter__1991000165 }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A) Invoke_O__O(self any) any { { var s__1991000166__1 any; var t_ any = t.F_s__1991000166; t.F_s__1991000166 = nil; s__1991000166__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1213 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = s__1991000166__1; if linked_1214 == nil { temp__1927000414__auto____2 = ifn_1215.Invoke_O__O(arg_1216) } else { temp__1927000414__auto____2 = linked_1214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1213, arg_1216) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000166__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1217 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = s__1991000166__3; if linked_1218 == nil { tmp1 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp1 = linked_1218.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1217, arg_1220) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1221 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = s__1991000166__3; if linked_1222 == nil { c__1927001037__auto____4 = ifn_1223.Invoke_O__O(arg_1224) } else { c__1927001037__auto____4 = linked_1222.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1221, arg_1224) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000168__6 any; var root_1225 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1226 == nil { b__1991000168__6 = ifn_1227.Invoke_O__O(arg_1228) } else { b__1991000168__6 = linked_1226.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1225, arg_1228) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, c__1927001037__auto____4, b__1991000168__6); var tmp3 *jrt.Class; var fncls__1248 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class; if fncls__1248 == nil { var fncls__1248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class = fncls__1248d; tmp3 = fncls__1248d } else { tmp3 = fncls__1248 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1257 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any; var root_1249 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = b__1991000168__6; if linked_1250 == nil { arg_1260 = ifn_1251.Invoke_O__O(arg_1252) } else { arg_1260 = linked_1250.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1249, arg_1252) }; var arg_1261 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000165); var tmp5 any; var root_1253 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = s__1991000166__3; if linked_1254 == nil { tmp5 = ifn_1255.Invoke_O__O(arg_1256) } else { tmp5 = linked_1254.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1253, arg_1256) }; arg_1261 = tmp4.Invoke_O__O(tmp5); if linked_1258 == nil { return ifn_1259.Invoke_O_O__O(arg_1260, arg_1261) } else { return linked_1258.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1257, arg_1260, arg_1261) } } else { var root_1266 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any; var root_1262 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = b__1991000168__6; if linked_1263 == nil { arg_1269 = ifn_1264.Invoke_O__O(arg_1265) } else { arg_1269 = linked_1263.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1262, arg_1265) }; var arg_1270 any; if linked_1267 == nil { return ifn_1268.Invoke_O_O__O(arg_1269, arg_1270) } else { return linked_1267.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1266, arg_1269, arg_1270) } } } else { var f__4 any; var root_1271 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = s__1991000166__3; if linked_1272 == nil { f__4 = ifn_1273.Invoke_O__O(arg_1274) } else { f__4 = linked_1272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1271, arg_1274) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1275 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1279 any = Lit_28; if linked_1276 == nil { and__1927000168__auto____6 = ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { and__1927000168__auto____6 = linked_1276.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_1285 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any; var root_1280 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1284 any = Lit_29; if linked_1281 == nil { arg_1288 = ifn_1282.Invoke_O_O__O(arg_1283, arg_1284) } else { arg_1288 = linked_1281.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1280, arg_1283, arg_1284) }; if linked_1286 == nil { tmp6 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp6 = linked_1286.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1285, arg_1288) } } else {
//line :230:1
			tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :227:1
	if jrt.J2g_Truth(tmp6) { var root_1293 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4); var arg_1297 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000165); var tmp8 any; var root_1289 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = s__1991000166__3; if linked_1290 == nil { tmp8 = ifn_1291.Invoke_O__O(arg_1292) } else { tmp8 = linked_1290.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1289, arg_1292) }; arg_1297 = tmp7.Invoke_O__O(tmp8); if linked_1294 == nil { return ifn_1295.Invoke_O_O__O(arg_1296, arg_1297) } else { return linked_1294.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1293, arg_1296, arg_1297) } } else { var tmp9 any; var root_1298 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = s__1991000166__3; if linked_1299 == nil { tmp9 = ifn_1300.Invoke_O__O(arg_1301) } else { tmp9 = linked_1299.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1298, arg_1301) }; s__1991000166__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :227:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000168 any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000168 = c__b__1991000168 }
//line :227:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A) Invoke_O__O(self any) any { { var i__1991000167__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000167__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1229 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1233 any = Lit_28; if linked_1230 == nil { and__1927000168__auto____4 = ifn_1231.Invoke_O_O__O(arg_1232, arg_1233) } else { and__1927000168__auto____4 = linked_1230.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1229, arg_1232, arg_1233) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1239 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1239, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1241 lang.IFn; if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; var arg_1242 any; var root_1234 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1238 any = Lit_29; if linked_1235 == nil { arg_1242 = ifn_1236.Invoke_O_O__O(arg_1237, arg_1238) } else { arg_1242 = linked_1235.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1234, arg_1237, arg_1238) }; if linked_1240 == nil { tmp2 = ifn_1241.Invoke_O__O(arg_1242) } else { tmp2 = linked_1240.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1239, arg_1242) } } else {
//line :230:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :227:1
	if jrt.J2g_Truth(tmp2) { var root_1243 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = t.F_b__1991000168; var arg_1247 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2); if linked_1244 == nil { ifn_1245.Invoke_O_O__O(arg_1246, arg_1247) } else { linked_1244.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1243, arg_1246, arg_1247) }; i__1991000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000167__1); continue L1 } else { i__1991000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000167__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A) Invoke_O_O__O(self, p__1991000182__1 any) any { var vec__1991000184__2 any = p__1991000182__1; var alias__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000184__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000184__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1408 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_New_O(alias__3); var tmp2 *jrt.Class; var fncls__1398 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class; if fncls__1398 == nil { var fncls__1398d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class = fncls__1398d; tmp2 = fncls__1398d } else { tmp2 = fncls__1398 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp4 any; var root_1403 any = A_arbace_j2g_embed_A_const_98.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = t.F_re; var arg_1407 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4); if linked_1404 == nil { tmp4 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { tmp4 = linked_1404.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }; arg_1411 = tmp3.Invoke_O__O(tmp4); if linked_1409 == nil { return ifn_1410.Invoke_O__O(arg_1411) } else { return linked_1409.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1408, arg_1411) } }
//line :234:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A) Invoke_O_O__O(self, s__1991000188__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_New_O_O_O(t.F_alias, s__1991000188__1, self); var tmp2 *jrt.Class; var fncls__1397 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class; if fncls__1397 == nil { var fncls__1397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class = fncls__1397d; tmp2 = fncls__1397d } else { tmp2 = fncls__1397 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :234:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A) Ctor_O_O_O(c__alias, c__s__1991000188, c__iter__1991000187 any) { t.F_alias = c__alias; t.F_s__1991000188 = c__s__1991000188; t.F_iter__1991000187 = c__iter__1991000187 }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A) Invoke_O__O(self any) any { { var s__1991000188__1 any; var t_ any = t.F_s__1991000188; t.F_s__1991000188 = nil; s__1991000188__1 = t_; for { var temp__1927000414__auto____2 any; var root_1330 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = s__1991000188__1; if linked_1331 == nil { temp__1927000414__auto____2 = ifn_1332.Invoke_O__O(arg_1333) } else { temp__1927000414__auto____2 = linked_1331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1330, arg_1333) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000188__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1334 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = s__1991000188__3; if linked_1335 == nil { tmp1 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp1 = linked_1335.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1334, arg_1337) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1338 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = s__1991000188__3; if linked_1339 == nil { c__1927001037__auto____4 = ifn_1340.Invoke_O__O(arg_1341) } else { c__1927001037__auto____4 = linked_1339.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1338, arg_1341) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000190__6 any; var root_1342 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1343 == nil { b__1991000190__6 = ifn_1344.Invoke_O__O(arg_1345) } else { b__1991000190__6 = linked_1343.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1342, arg_1345) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_New_O_O_I_O(t.F_alias, b__1991000190__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1356 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class; if fncls__1356 == nil { var fncls__1356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class = fncls__1356d; tmp3 = fncls__1356d } else { tmp3 = fncls__1356 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1365 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any; var root_1357 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = b__1991000190__6; if linked_1358 == nil { arg_1368 = ifn_1359.Invoke_O__O(arg_1360) } else { arg_1368 = linked_1358.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1357, arg_1360) }; var arg_1369 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000187); var tmp5 any; var root_1361 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = s__1991000188__3; if linked_1362 == nil { tmp5 = ifn_1363.Invoke_O__O(arg_1364) } else { tmp5 = linked_1362.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1361, arg_1364) }; arg_1369 = tmp4.Invoke_O__O(tmp5); if linked_1366 == nil { return ifn_1367.Invoke_O_O__O(arg_1368, arg_1369) } else { return linked_1366.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1365, arg_1368, arg_1369) } } else { var root_1374 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any; var root_1370 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = b__1991000190__6; if linked_1371 == nil { arg_1377 = ifn_1372.Invoke_O__O(arg_1373) } else { arg_1377 = linked_1371.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1370, arg_1373) }; var arg_1378 any; if linked_1375 == nil { return ifn_1376.Invoke_O_O__O(arg_1377, arg_1378) } else { return linked_1375.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1374, arg_1377, arg_1378) } } } else { var vec__1991000198__4 any; var root_1379 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = s__1991000188__3; if linked_1380 == nil { vec__1991000198__4 = ifn_1381.Invoke_O__O(arg_1382) } else { vec__1991000198__4 = linked_1380.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1379, arg_1382) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000198__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000198__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1392 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1394 lang.IFn; _ = ___5; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any; var root_1383 any = A_arbace_j2g_embed_A_const_97.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = t.F_alias; var arg_1387 any = n__6; if linked_1384 == nil { arg_1395 = ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { arg_1395 = linked_1384.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }; var arg_1396 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000187); var tmp7 any; var root_1388 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = s__1991000188__3; if linked_1389 == nil { tmp7 = ifn_1390.Invoke_O__O(arg_1391) } else { tmp7 = linked_1389.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1388, arg_1391) }; arg_1396 = tmp6.Invoke_O__O(tmp7); if linked_1393 == nil { return ifn_1394.Invoke_O_O__O(arg_1395, arg_1396) } else { return linked_1393.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1392, arg_1395, arg_1396) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :234:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A) Ctor_O_O_I_O(c__alias, c__b__1991000190 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_b__1991000190 = c__b__1991000190; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :234:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A) Invoke_O__O(self any) any { { var i__1991000189__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000189__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1991000194__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000189__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000194__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000194__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1351 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1353 lang.IFn; _ = ___3; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = t.F_b__1991000190; var arg_1355 any; var root_1346 any = A_arbace_j2g_embed_A_const_97.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = t.F_alias; var arg_1350 any = n__4; if linked_1347 == nil { arg_1355 = ifn_1348.Invoke_O_O__O(arg_1349, arg_1350) } else { arg_1355 = linked_1347.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1346, arg_1349, arg_1350) }; if linked_1352 == nil { ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { linked_1352.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) }; i__1991000189__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000189__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A) Ctor() {}
//line :239:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A) Invoke_O_O__O(self, s__1991000205__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_New_O_O(s__1991000205__1, self); var tmp2 *jrt.Class; var fncls__1613 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class; if fncls__1613 == nil { var fncls__1613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class = fncls__1613d; tmp2 = fncls__1613d } else { tmp2 = fncls__1613 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :239:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A{}; t.Ctor_O_O(p0, p1); return t }
//line :239:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A) Ctor_O_O(c__s__1991000205, c__iter__1991000204 any) { t.F_s__1991000205 = c__s__1991000205; t.F_iter__1991000204 = c__iter__1991000204 }
//line :239:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A) Invoke_O__O(self any) any { { var s__1991000205__1 any; var t_ any = t.F_s__1991000205; t.F_s__1991000205 = nil; s__1991000205__1 = t_; for { var temp__1927000414__auto____2 any; var root_1424 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = s__1991000205__1; if linked_1425 == nil { temp__1927000414__auto____2 = ifn_1426.Invoke_O__O(arg_1427) } else { temp__1927000414__auto____2 = linked_1425.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1424, arg_1427) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1428 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = s__1991000205__3; if linked_1429 == nil { tmp1 = ifn_1430.Invoke_O__O(arg_1431) } else { tmp1 = linked_1429.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1428, arg_1431) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1432 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = s__1991000205__3; if linked_1433 == nil { c__1927001037__auto____4 = ifn_1434.Invoke_O__O(arg_1435) } else { c__1927001037__auto____4 = linked_1433.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1432, arg_1435) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000207__6 any; var root_1436 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1437 == nil { b__1991000207__6 = ifn_1438.Invoke_O__O(arg_1439) } else { b__1991000207__6 = linked_1437.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1436, arg_1439) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_New_O_I_O(b__1991000207__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1511 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class; if fncls__1511 == nil { var fncls__1511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class = fncls__1511d; tmp3 = fncls__1511d } else { tmp3 = fncls__1511 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1520 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any; var root_1512 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = b__1991000207__6; if linked_1513 == nil { arg_1523 = ifn_1514.Invoke_O__O(arg_1515) } else { arg_1523 = linked_1513.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1512, arg_1515) }; var arg_1524 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000204); var tmp5 any; var root_1516 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = s__1991000205__3; if linked_1517 == nil { tmp5 = ifn_1518.Invoke_O__O(arg_1519) } else { tmp5 = linked_1517.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1516, arg_1519) }; arg_1524 = tmp4.Invoke_O__O(tmp5); if linked_1521 == nil { return ifn_1522.Invoke_O_O__O(arg_1523, arg_1524) } else { return linked_1521.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1520, arg_1523, arg_1524) } } else { var root_1529 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any; var root_1525 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = b__1991000207__6; if linked_1526 == nil { arg_1532 = ifn_1527.Invoke_O__O(arg_1528) } else { arg_1532 = linked_1526.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1525, arg_1528) }; var arg_1533 any; if linked_1530 == nil { return ifn_1531.Invoke_O_O__O(arg_1532, arg_1533) } else { return linked_1530.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1529, arg_1532, arg_1533) } } } else { var part__4 any; var root_1534 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = s__1991000205__3; if linked_1535 == nil { part__4 = ifn_1536.Invoke_O__O(arg_1537) } else { part__4 = linked_1535.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1534, arg_1537) }; var root_1608 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_103; var tmp8 any = A_arbace_j2g_embed_A_const_104; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_A_const_105; var tmp12 any; var root_1597 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1599 lang.IFn


	if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var arg_1601 any = A_arbace_j2g_embed_A_const_106; var arg_1602 any = A_arbace_j2g_embed_A_const_107; var arg_1603 any; var iter__1927001039__auto____5 any; var tmp13 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_New(); var tmp14 *jrt.Class; var fncls__1596 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class
	if fncls__1596 == nil { var fncls__1596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class = fncls__1596d; tmp14 = fncls__1596d } else { tmp14 = fncls__1596 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_1603 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(part__4)
//line :242:1
	if linked_1598 == nil { tmp12 = ifn_1599.Invoke_O_O_O_O__O(arg_1600, arg_1601, arg_1602, arg_1603) } else { tmp12 = linked_1598.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1597, arg_1600, arg_1601, arg_1602, arg_1603) }
//line :240:1
	arg_1611 = tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :239:1
	var arg_1612 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1991000204); var tmp16 any; var root_1604 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = s__1991000205__3; if linked_1605 == nil { tmp16 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp16 = linked_1605.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1604, arg_1607) }; arg_1612 = tmp15.Invoke_O__O(tmp16); if linked_1609 == nil { return ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { return linked_1609.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :239:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :239:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A) Ctor_O_I_O(c__b__1991000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000207 = c__b__1991000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :239:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A) Invoke_O__O(self any) any { { var i__1991000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var part__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000206__1)); var root_1506 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = t.F_b__1991000207; var arg_1510 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_103; var tmp4 any = A_arbace_j2g_embed_A_const_104; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_105; var tmp8 any; var root_1499 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1501 lang.IFn


	if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var arg_1503 any = A_arbace_j2g_embed_A_const_106; var arg_1504 any = A_arbace_j2g_embed_A_const_107; var arg_1505 any; var iter__1927001039__auto____3 any; var tmp9 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_New(); var tmp10 *jrt.Class; var fncls__1498 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class
	if fncls__1498 == nil { var fncls__1498d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class = fncls__1498d; tmp10 = fncls__1498d } else { tmp10 = fncls__1498 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_1505 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(part__2)
//line :242:1
	if linked_1500 == nil { tmp8 = ifn_1501.Invoke_O_O_O_O__O(arg_1502, arg_1503, arg_1504, arg_1505) } else { tmp8 = linked_1500.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1499, arg_1502, arg_1503, arg_1504, arg_1505) }
//line :240:1
	arg_1510 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :239:1
	if linked_1507 == nil { ifn_1508.Invoke_O_O__O(arg_1509, arg_1510) } else { linked_1507.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1506, arg_1509, arg_1510) }; i__1991000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A) Ctor() {}
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A) Invoke_O_O__O(self, s__1991000212__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_New_O_O(s__1991000212__1, self); var tmp2 *jrt.Class; var fncls__1497 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class; if fncls__1497 == nil { var fncls__1497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class = fncls__1497d; tmp2 = fncls__1497d } else { tmp2 = fncls__1497 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :243:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A{}; t.Ctor_O_O(p0, p1); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A) Ctor_O_O(c__s__1991000212, c__iter__1991000211 any) { t.F_s__1991000212 = c__s__1991000212; t.F_iter__1991000211 = c__iter__1991000211 }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A) Invoke_O__O(self any) any { { var s__1991000212__1 any; var t_ any = t.F_s__1991000212; t.F_s__1991000212 = nil; s__1991000212__1 = t_; for { var temp__1927000414__auto____2 any; var root_1440 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = s__1991000212__1; if linked_1441 == nil { temp__1927000414__auto____2 = ifn_1442.Invoke_O__O(arg_1443) } else { temp__1927000414__auto____2 = linked_1441.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1440, arg_1443) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000212__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1444 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = s__1991000212__3; if linked_1445 == nil { tmp1 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp1 = linked_1445.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1444, arg_1447) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1448 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = s__1991000212__3; if linked_1449 == nil { c__1927001037__auto____4 = ifn_1450.Invoke_O__O(arg_1451) } else { c__1927001037__auto____4 = linked_1449.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1448, arg_1451) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000214__6 any; var root_1452 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1453 == nil { b__1991000214__6 = ifn_1454.Invoke_O__O(arg_1455) } else { b__1991000214__6 = linked_1453.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1452, arg_1455) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_New_O_I_O(b__1991000214__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1461 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class; if fncls__1461 == nil { var fncls__1461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class = fncls__1461d; tmp3 = fncls__1461d } else { tmp3 = fncls__1461 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1470 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any; var root_1462 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = b__1991000214__6; if linked_1463 == nil { arg_1473 = ifn_1464.Invoke_O__O(arg_1465) } else { arg_1473 = linked_1463.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1462, arg_1465) }; var arg_1474 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); var tmp5 any; var root_1466 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = s__1991000212__3; if linked_1467 == nil { tmp5 = ifn_1468.Invoke_O__O(arg_1469) } else { tmp5 = linked_1467.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1466, arg_1469) }; arg_1474 = tmp4.Invoke_O__O(tmp5); if linked_1471 == nil { return ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { return linked_1471.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) } } else { var root_1479 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any; var root_1475 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = b__1991000214__6; if linked_1476 == nil { arg_1482 = ifn_1477.Invoke_O__O(arg_1478) } else { arg_1482 = linked_1476.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1475, arg_1478) }; var arg_1483 any; if linked_1480 == nil { return ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { return linked_1480.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) } } } else { var t__4 any; var root_1484 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = s__1991000212__3; if linked_1485 == nil { t__4 = ifn_1486.Invoke_O__O(arg_1487) } else { t__4 = linked_1485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1484, arg_1487) }; var root_1492 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_108; var arg_1495 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__4)); var arg_1496 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); var tmp9 any; var root_1488 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = s__1991000212__3; if linked_1489 == nil { tmp9 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp9 = linked_1489.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1488, arg_1491) }; arg_1496 = tmp8.Invoke_O__O(tmp9); if linked_1493 == nil { return ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { return linked_1493.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :243:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A) Ctor_O_I_O(c__b__1991000214 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000214 = c__b__1991000214; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A) Invoke_O__O(self any) any { { var i__1991000213__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000213__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000213__1)); var root_1456 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = t.F_b__1991000214; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_108; var arg_1460 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__2)); if linked_1457 == nil { ifn_1458.Invoke_O_O__O(arg_1459, arg_1460) } else { linked_1457.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1456, arg_1459, arg_1460) }; i__1991000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000213__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :243:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A) Ctor() {}
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A) Invoke_O_O__O(self, s__1991000223__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_New_O_O(s__1991000223__1, self); var tmp2 *jrt.Class; var fncls__1595 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class; if fncls__1595 == nil { var fncls__1595d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class = fncls__1595d; tmp2 = fncls__1595d } else { tmp2 = fncls__1595 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :243:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A{}; t.Ctor_O_O(p0, p1); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A) Ctor_O_O(c__s__1991000223, c__iter__1991000222 any) { t.F_s__1991000223 = c__s__1991000223; t.F_iter__1991000222 = c__iter__1991000222 }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A) Invoke_O__O(self any) any { { var s__1991000223__1 any; var t_ any = t.F_s__1991000223; t.F_s__1991000223 = nil; s__1991000223__1 = t_; for { var temp__1927000414__auto____2 any; var root_1538 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = s__1991000223__1; if linked_1539 == nil { temp__1927000414__auto____2 = ifn_1540.Invoke_O__O(arg_1541) } else { temp__1927000414__auto____2 = linked_1539.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1538, arg_1541) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000223__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1542 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = s__1991000223__3; if linked_1543 == nil { tmp1 = ifn_1544.Invoke_O__O(arg_1545) } else { tmp1 = linked_1543.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1542, arg_1545) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1546 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = s__1991000223__3; if linked_1547 == nil { c__1927001037__auto____4 = ifn_1548.Invoke_O__O(arg_1549) } else { c__1927001037__auto____4 = linked_1547.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1546, arg_1549) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000225__6 any; var root_1550 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1551 == nil { b__1991000225__6 = ifn_1552.Invoke_O__O(arg_1553) } else { b__1991000225__6 = linked_1551.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1550, arg_1553) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_New_O_I_O(b__1991000225__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1559 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class; if fncls__1559 == nil { var fncls__1559d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class = fncls__1559d; tmp3 = fncls__1559d } else { tmp3 = fncls__1559 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1568 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any; var root_1560 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = b__1991000225__6; if linked_1561 == nil { arg_1571 = ifn_1562.Invoke_O__O(arg_1563) } else { arg_1571 = linked_1561.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1560, arg_1563) }; var arg_1572 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000222); var tmp5 any; var root_1564 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = s__1991000223__3; if linked_1565 == nil { tmp5 = ifn_1566.Invoke_O__O(arg_1567) } else { tmp5 = linked_1565.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1564, arg_1567) }; arg_1572 = tmp4.Invoke_O__O(tmp5); if linked_1569 == nil { return ifn_1570.Invoke_O_O__O(arg_1571, arg_1572) } else { return linked_1569.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1568, arg_1571, arg_1572) } } else { var root_1577 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any; var root_1573 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = b__1991000225__6; if linked_1574 == nil { arg_1580 = ifn_1575.Invoke_O__O(arg_1576) } else { arg_1580 = linked_1574.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1573, arg_1576) }; var arg_1581 any; if linked_1578 == nil { return ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { return linked_1578.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) } } } else { var t__4 any; var root_1582 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = s__1991000223__3; if linked_1583 == nil { t__4 = ifn_1584.Invoke_O__O(arg_1585) } else { t__4 = linked_1583.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1582, arg_1585) }; var root_1590 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_108; var arg_1593 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__4)); var arg_1594 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000222); var tmp9 any; var root_1586 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = s__1991000223__3; if linked_1587 == nil { tmp9 = ifn_1588.Invoke_O__O(arg_1589) } else { tmp9 = linked_1587.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1586, arg_1589) }; arg_1594 = tmp8.Invoke_O__O(tmp9); if linked_1591 == nil { return ifn_1592.Invoke_O_O__O(arg_1593, arg_1594) } else { return linked_1591.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1590, arg_1593, arg_1594) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :243:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A) Ctor_O_I_O(c__b__1991000225 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000225 = c__b__1991000225; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A) Invoke_O__O(self any) any { { var i__1991000224__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000224__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000224__1)); var root_1554 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = t.F_b__1991000225; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_108; var arg_1558 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__2)); if linked_1555 == nil { ifn_1556.Invoke_O_O__O(arg_1557, arg_1558) } else { linked_1555.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1554, arg_1557, arg_1558) }; i__1991000224__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000224__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





















































































































































































































type A_arbace_j2g_embed_A struct{ jrt.Object }

var A_arbace_j2g_embed_A_const_pool *jrt.RefArray

var A_arbace_j2g_embed_A_const_0 *lang.Var

var A_arbace_j2g_embed_A_const_1 any

var A_arbace_j2g_embed_A_const_2 *lang.Var

var A_arbace_j2g_embed_A_const_3 any

var A_arbace_j2g_embed_A_const_4 any

var A_arbace_j2g_embed_A_const_5 any

var A_arbace_j2g_embed_A_const_6 any

var A_arbace_j2g_embed_A_const_7 *lang.Var

var A_arbace_j2g_embed_A_const_8 *lang.Var

var A_arbace_j2g_embed_A_const_9 *lang.Var

var A_arbace_j2g_embed_A_const_10 *lang.Var

var A_arbace_j2g_embed_A_const_11 any

var A_arbace_j2g_embed_A_const_12 *lang.Var

var A_arbace_j2g_embed_A_const_13 *lang.Var

var A_arbace_j2g_embed_A_const_14 *lang.Var

var A_arbace_j2g_embed_A_const_15 *lang.Var

var A_arbace_j2g_embed_A_const_16 *lang.Var

var A_arbace_j2g_embed_A_const_17 *lang.Var

var A_arbace_j2g_embed_A_const_18 *lang.Var

var A_arbace_j2g_embed_A_const_19 *lang.Var

var A_arbace_j2g_embed_A_const_20 *lang.Var

var A_arbace_j2g_embed_A_const_21 *lang.Var

var A_arbace_j2g_embed_A_const_22 *lang.Var

var A_arbace_j2g_embed_A_const_23 *lang.Var

var A_arbace_j2g_embed_A_const_24 *lang.Var

var A_arbace_j2g_embed_A_const_25 *lang.Var

var A_arbace_j2g_embed_A_const_26 *lang.Var

var A_arbace_j2g_embed_A_const_27 *lang.Var

var A_arbace_j2g_embed_A_const_28 *lang.Var

var A_arbace_j2g_embed_A_const_29 *lang.Var

var A_arbace_j2g_embed_A_const_30 *lang.Var

var A_arbace_j2g_embed_A_const_31 *lang.Var

var A_arbace_j2g_embed_A_const_32 *lang.Var

var A_arbace_j2g_embed_A_const_33 any

var A_arbace_j2g_embed_A_const_34 *lang.Var

var A_arbace_j2g_embed_A_const_35 any

var A_arbace_j2g_embed_A_const_36 *lang.Var

var A_arbace_j2g_embed_A_const_37 *lang.Var

var A_arbace_j2g_embed_A_const_38 *lang.Var

var A_arbace_j2g_embed_A_const_39 *lang.Var

var A_arbace_j2g_embed_A_const_40 *lang.Var

var A_arbace_j2g_embed_A_const_41 *lang.Keyword

var A_arbace_j2g_embed_A_const_42 *lang.Var

var A_arbace_j2g_embed_A_const_43 *lang.Var

var A_arbace_j2g_embed_A_const_44 *lang.Var

var A_arbace_j2g_embed_A_const_45 *lang.Var

var A_arbace_j2g_embed_A_const_46 *lang.Var

var A_arbace_j2g_embed_A_const_47 *lang.Var

var A_arbace_j2g_embed_A_const_48 any

var A_arbace_j2g_embed_A_const_49 *lang.Var

var A_arbace_j2g_embed_A_const_50 any

var A_arbace_j2g_embed_A_const_51 *lang.Keyword

var A_arbace_j2g_embed_A_const_52 *lang.Var

var A_arbace_j2g_embed_A_const_53 *lang.Var

var A_arbace_j2g_embed_A_const_54 *lang.Var

var A_arbace_j2g_embed_A_const_55 *lang.Var

var A_arbace_j2g_embed_A_const_56 *lang.Var

var A_arbace_j2g_embed_A_const_57 *lang.Var

var A_arbace_j2g_embed_A_const_58 *lang.Var

var A_arbace_j2g_embed_A_const_59 *lang.Var

var A_arbace_j2g_embed_A_const_60 *lang.Var

var A_arbace_j2g_embed_A_const_61 *lang.Var

var A_arbace_j2g_embed_A_const_62 *lang.Var

var A_arbace_j2g_embed_A_const_63 *lang.Var

var A_arbace_j2g_embed_A_const_64 *lang.Var

var A_arbace_j2g_embed_A_const_65 *lang.Var

var A_arbace_j2g_embed_A_const_66 *lang.Var

var A_arbace_j2g_embed_A_const_67 *lang.Var

var A_arbace_j2g_embed_A_const_68 *lang.Var

var A_arbace_j2g_embed_A_const_69 *lang.Var

var A_arbace_j2g_embed_A_const_70 *lang.Var

var A_arbace_j2g_embed_A_const_71 *lang.Var

var A_arbace_j2g_embed_A_const_72 *lang.Var

var A_arbace_j2g_embed_A_const_73 *lang.Var

var A_arbace_j2g_embed_A_const_74 *lang.Var

var A_arbace_j2g_embed_A_const_75 *lang.Var

var A_arbace_j2g_embed_A_const_76 *lang.Var

var A_arbace_j2g_embed_A_const_77 any

var A_arbace_j2g_embed_A_const_78 any

var A_arbace_j2g_embed_A_const_79 *lang.Var

var A_arbace_j2g_embed_A_const_80 *lang.Keyword

var A_arbace_j2g_embed_A_const_81 *lang.Var

var A_arbace_j2g_embed_A_const_82 *lang.Var

var A_arbace_j2g_embed_A_const_83 *lang.Var

var A_arbace_j2g_embed_A_const_84 *lang.Var

var A_arbace_j2g_embed_A_const_85 *lang.Var

var A_arbace_j2g_embed_A_const_86 *lang.Var

var A_arbace_j2g_embed_A_const_87 *lang.Var

var A_arbace_j2g_embed_A_const_88 *lang.Var

var A_arbace_j2g_embed_A_const_89 *lang.Var

var A_arbace_j2g_embed_A_const_90 *lang.Var

var A_arbace_j2g_embed_A_const_91 *lang.Var

var A_arbace_j2g_embed_A_const_92 *lang.Var

var A_arbace_j2g_embed_A_const_93 any

var A_arbace_j2g_embed_A_const_94 *lang.Var

var A_arbace_j2g_embed_A_const_95 *lang.Keyword

var A_arbace_j2g_embed_A_const_96 any

var A_arbace_j2g_embed_A_const_97 *lang.Var

var A_arbace_j2g_embed_A_const_98 *lang.Var

var A_arbace_j2g_embed_A_const_99 *lang.Var

var A_arbace_j2g_embed_A_const_100 any

var A_arbace_j2g_embed_A_const_101 *lang.Keyword

var A_arbace_j2g_embed_A_const_102 any

var A_arbace_j2g_embed_A_const_103 any

var A_arbace_j2g_embed_A_const_104 any

var A_arbace_j2g_embed_A_const_105 any

var A_arbace_j2g_embed_A_const_106 any

var A_arbace_j2g_embed_A_const_107 any

var A_arbace_j2g_embed_A_const_108 any

var A_arbace_j2g_embed_A_const_109 any

var A_arbace_j2g_embed_A_const_110 *lang.Var

var A_arbace_j2g_embed_A_const_111 any

var A_arbace_j2g_embed_A_const_112 any

var A_arbace_j2g_embed_A_init jrt.ClassInit

func A_arbace_j2g_embed_A_Init() { if !A_arbace_j2g_embed_A_init.Done() { A_arbace_j2g_embed_A_init.Run(A_arbace_j2g_embed_A_clinit) } }

func A_arbace_j2g_embed_A_clinit() { A_arbace_j2g_embed_A_clinit_p0(); A_arbace_j2g_embed_A_clinit_p1(); A_arbace_j2g_embed_A_clinit_p2(); A_arbace_j2g_embed_A_clinit_p3(); A_arbace_j2g_embed_A_clinit_p4(); A_arbace_j2g_embed_A_clinit_p5(); A_arbace_j2g_embed_A_clinit_p6(); A_arbace_j2g_embed_A_clinit_p7(); A_arbace_j2g_embed_A_clinit_p8(); A_arbace_j2g_embed_A_clinit_p9() }

func A_arbace_j2g_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 146); A_arbace_j2g_embed_A_const_0 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[33]); A_arbace_j2g_embed_A_const_1 = A_arbace_j2g_embed_A_const_pool.A[34]; A_arbace_j2g_embed_A_const_2 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[35]); A_arbace_j2g_embed_A_const_3 = A_arbace_j2g_embed_A_const_pool.A[36]; A_arbace_j2g_embed_A_const_4 = A_arbace_j2g_embed_A_const_pool.A[37]; A_arbace_j2g_embed_A_const_5 = A_arbace_j2g_embed_A_const_pool.A[38]; A_arbace_j2g_embed_A_const_6 = A_arbace_j2g_embed_A_const_pool.A[39]; A_arbace_j2g_embed_A_const_7 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[40]); A_arbace_j2g_embed_A_const_8 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[41]); A_arbace_j2g_embed_A_const_9 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[42]); A_arbace_j2g_embed_A_const_10 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[43]); A_arbace_j2g_embed_A_const_11 = A_arbace_j2g_embed_A_const_pool.A[44] }

func A_arbace_j2g_embed_A_clinit_p1() { A_arbace_j2g_embed_A_const_12 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[45]); A_arbace_j2g_embed_A_const_13 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[46]); A_arbace_j2g_embed_A_const_14 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[47]); A_arbace_j2g_embed_A_const_15 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[48]); A_arbace_j2g_embed_A_const_16 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[49]); A_arbace_j2g_embed_A_const_17 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[50]); A_arbace_j2g_embed_A_const_18 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[51]); A_arbace_j2g_embed_A_const_19 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[52]); A_arbace_j2g_embed_A_const_20 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[53]); A_arbace_j2g_embed_A_const_21 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[54]); A_arbace_j2g_embed_A_const_22 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[55]); A_arbace_j2g_embed_A_const_23 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[56]) }

func A_arbace_j2g_embed_A_clinit_p2() { A_arbace_j2g_embed_A_const_24 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[57]); A_arbace_j2g_embed_A_const_25 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[58]); A_arbace_j2g_embed_A_const_26 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[59]); A_arbace_j2g_embed_A_const_27 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[60]); A_arbace_j2g_embed_A_const_28 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[61]); A_arbace_j2g_embed_A_const_29 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[62]); A_arbace_j2g_embed_A_const_30 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[63]); A_arbace_j2g_embed_A_const_31 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[64]); A_arbace_j2g_embed_A_const_32 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[65]); A_arbace_j2g_embed_A_const_33 = A_arbace_j2g_embed_A_const_pool.A[66]; A_arbace_j2g_embed_A_const_34 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[67]); A_arbace_j2g_embed_A_const_35 = A_arbace_j2g_embed_A_const_pool.A[68] }

func A_arbace_j2g_embed_A_clinit_p3() { A_arbace_j2g_embed_A_const_36 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[69]); A_arbace_j2g_embed_A_const_37 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[70]); A_arbace_j2g_embed_A_const_38 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[71]); A_arbace_j2g_embed_A_const_39 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[72]); A_arbace_j2g_embed_A_const_40 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[73]); A_arbace_j2g_embed_A_const_41 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[74]); A_arbace_j2g_embed_A_const_42 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[75]); A_arbace_j2g_embed_A_const_43 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[76]); A_arbace_j2g_embed_A_const_44 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[77]); A_arbace_j2g_embed_A_const_45 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[78]); A_arbace_j2g_embed_A_const_46 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[79]); A_arbace_j2g_embed_A_const_47 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[80]) }

func A_arbace_j2g_embed_A_clinit_p4() { A_arbace_j2g_embed_A_const_48 = A_arbace_j2g_embed_A_const_pool.A[81]; A_arbace_j2g_embed_A_const_49 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[82]); A_arbace_j2g_embed_A_const_50 = A_arbace_j2g_embed_A_const_pool.A[83]; A_arbace_j2g_embed_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[84]); A_arbace_j2g_embed_A_const_52 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[85]); A_arbace_j2g_embed_A_const_53 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[86]); A_arbace_j2g_embed_A_const_54 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[87]); A_arbace_j2g_embed_A_const_55 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[88]); A_arbace_j2g_embed_A_const_56 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[89]); A_arbace_j2g_embed_A_const_57 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[90]); A_arbace_j2g_embed_A_const_58 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[91]); A_arbace_j2g_embed_A_const_59 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[92]) }

func A_arbace_j2g_embed_A_clinit_p5() { A_arbace_j2g_embed_A_const_60 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[93]); A_arbace_j2g_embed_A_const_61 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[94]); A_arbace_j2g_embed_A_const_62 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[95]); A_arbace_j2g_embed_A_const_63 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[96]); A_arbace_j2g_embed_A_const_64 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[97]); A_arbace_j2g_embed_A_const_65 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[98]); A_arbace_j2g_embed_A_const_66 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[99]); A_arbace_j2g_embed_A_const_67 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[100]); A_arbace_j2g_embed_A_const_68 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[101]); A_arbace_j2g_embed_A_const_69 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[102]); A_arbace_j2g_embed_A_const_70 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[103]); A_arbace_j2g_embed_A_const_71 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[104]) }

func A_arbace_j2g_embed_A_clinit_p6() { A_arbace_j2g_embed_A_const_72 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[105]); A_arbace_j2g_embed_A_const_73 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[106]); A_arbace_j2g_embed_A_const_74 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[107]); A_arbace_j2g_embed_A_const_75 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[108]); A_arbace_j2g_embed_A_const_76 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[109]); A_arbace_j2g_embed_A_const_77 = A_arbace_j2g_embed_A_const_pool.A[110]; A_arbace_j2g_embed_A_const_78 = A_arbace_j2g_embed_A_const_pool.A[111]; A_arbace_j2g_embed_A_const_79 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[112]); A_arbace_j2g_embed_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[113]); A_arbace_j2g_embed_A_const_81 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[114]); A_arbace_j2g_embed_A_const_82 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[115]); A_arbace_j2g_embed_A_const_83 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[116]) }

func A_arbace_j2g_embed_A_clinit_p7() { A_arbace_j2g_embed_A_const_84 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[117]); A_arbace_j2g_embed_A_const_85 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[118]); A_arbace_j2g_embed_A_const_86 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[119]); A_arbace_j2g_embed_A_const_87 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[120]); A_arbace_j2g_embed_A_const_88 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[121]); A_arbace_j2g_embed_A_const_89 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[122]); A_arbace_j2g_embed_A_const_90 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[123]); A_arbace_j2g_embed_A_const_91 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[124]); A_arbace_j2g_embed_A_const_92 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[125]); A_arbace_j2g_embed_A_const_93 = A_arbace_j2g_embed_A_const_pool.A[126]; A_arbace_j2g_embed_A_const_94 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[127]); A_arbace_j2g_embed_A_const_95 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[128]) }

func A_arbace_j2g_embed_A_clinit_p8() { A_arbace_j2g_embed_A_const_96 = A_arbace_j2g_embed_A_const_pool.A[129]; A_arbace_j2g_embed_A_const_97 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[130]); A_arbace_j2g_embed_A_const_98 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[131]); A_arbace_j2g_embed_A_const_99 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[132]); A_arbace_j2g_embed_A_const_100 = A_arbace_j2g_embed_A_const_pool.A[133]; A_arbace_j2g_embed_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[134]); A_arbace_j2g_embed_A_const_102 = A_arbace_j2g_embed_A_const_pool.A[135]; A_arbace_j2g_embed_A_const_103 = A_arbace_j2g_embed_A_const_pool.A[136]; A_arbace_j2g_embed_A_const_104 = A_arbace_j2g_embed_A_const_pool.A[137]; A_arbace_j2g_embed_A_const_105 = A_arbace_j2g_embed_A_const_pool.A[138]; A_arbace_j2g_embed_A_const_106 = A_arbace_j2g_embed_A_const_pool.A[139]; A_arbace_j2g_embed_A_const_107 = A_arbace_j2g_embed_A_const_pool.A[140]; A_arbace_j2g_embed_A_const_108 = A_arbace_j2g_embed_A_const_pool.A[141]; A_arbace_j2g_embed_A_const_109 = A_arbace_j2g_embed_A_const_pool.A[142] }

func A_arbace_j2g_embed_A_clinit_p9() { A_arbace_j2g_embed_A_const_110 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[143]); A_arbace_j2g_embed_A_const_111 = A_arbace_j2g_embed_A_const_pool.A[144]; A_arbace_j2g_embed_A_const_112 = A_arbace_j2g_embed_A_const_pool.A[145] }

func A_arbace_j2g_embed_A_New() *A_arbace_j2g_embed_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_A) Ctor() {}

func (t *A_arbace_j2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_A_class }

func (t *A_arbace_j2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_A); return ok }

func A_arbace_j2g_embed_A_Cast(x any) *A_arbace_j2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_A_class)) }; return v }



type A_arbace_j2g_embed_class_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_class_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_fn__1991000103_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A struct{ j2g_header uint64; F_s__1991000089, F_iter__1991000088 any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A struct{ j2g_header uint64; F_b__1991000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_data_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A struct{ j2g_header uint64; F_base, F_s__1991000153, F_iter__1991000152 any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A struct{ j2g_header uint64; F_base any; F_size__1927001038__auto__ int32; F_b__1991000155, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000004_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000004_A_New() *A_arbace_j2g_embed_eval1991000004_A { t := &A_arbace_j2g_embed_eval1991000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000004_A_class }

func (t *A_arbace_j2g_embed_eval1991000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); return ok }

func A_arbace_j2g_embed_eval1991000004_A_Cast(x any) *A_arbace_j2g_embed_eval1991000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000004_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000008_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000008_A_New() *A_arbace_j2g_embed_eval1991000008_A { t := &A_arbace_j2g_embed_eval1991000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000008_A_class }

func (t *A_arbace_j2g_embed_eval1991000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); return ok }

func A_arbace_j2g_embed_eval1991000008_A_Cast(x any) *A_arbace_j2g_embed_eval1991000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000008_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000008_fn__1991000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_A struct{ j2g_header uint64; F_re any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A struct{ j2g_header uint64; F_alias, F_s__1991000188, F_iter__1991000187 any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A struct{ j2g_header uint64; F_alias, F_b__1991000190 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A struct{ j2g_header uint64; F_prog_dir any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A struct{ j2g_header uint64; F_prog_dir, F_s__1991000164, F_iter__1991000163 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A struct{ j2g_header uint64; F_alias, F_s__1991000166, F_iter__1991000165 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000168 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A struct{ j2g_header uint64; F_s__1991000205, F_iter__1991000204 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A struct{ j2g_header uint64; F_b__1991000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A struct{ j2g_header uint64; F_s__1991000212, F_iter__1991000211 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A struct{ j2g_header uint64; F_b__1991000214 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A struct{ j2g_header uint64; F_s__1991000223, F_iter__1991000222 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A struct{ j2g_header uint64; F_b__1991000225 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_names_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_walk__1991000059_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_embed_names_walk__1991000059_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_fn__1991000054_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class *jrt.Class



type A_arbace_j2g_embed_reify__1991000052_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_LispReader_Resolver() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_IObj() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_IMeta() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_reify__1991000052_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_reify__1991000052_A_class }

func (t *A_arbace_j2g_embed_reify__1991000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_reify__1991000052_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_reify__1991000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_reify__1991000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_reify__1991000052_A); return ok }

func A_arbace_j2g_embed_reify__1991000052_A_Cast(x any) *A_arbace_j2g_embed_reify__1991000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_reify__1991000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_reify__1991000052_A_class)) }; return v }



type A_arbace_j2g_embed_sources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A struct{ j2g_header uint64; F_p, F_pairs, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A struct{ j2g_header uint64; F_p, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A struct{ j2g_header uint64; F_base, F_s__1991000014, F_iter__1991000013 any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A struct{ j2g_header uint64; F_b__1991000016, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A struct{ j2g_header uint64; F_vdir any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A struct{ j2g_header uint64; F_vdir, F_s__1991000028, F_iter__1991000027 any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A struct{ j2g_header uint64; F_vdir, F_b__1991000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_elem__1991000117_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types, F_s__1991000134, F_iter__1991000133 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A struct{ j2g_header uint64; F_n, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A struct{ j2g_header uint64; F_in_world_QMARK_ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A struct{ j2g_header uint64; F_in_world_QMARK_, F_s__1991000136, F_iter__1991000135 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A struct{ j2g_header uint64; F_b__1991000138, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_A struct{ j2g_header uint64; F_elem, F_types any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A struct{ j2g_header uint64; F_s__1991000123, F_iter__1991000122 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A struct{ j2g_header uint64; F_b__1991000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class *jrt.Class
