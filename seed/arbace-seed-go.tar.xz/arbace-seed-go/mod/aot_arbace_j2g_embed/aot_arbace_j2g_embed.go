//line aot_arbace_j2g_embed.ae:1
package aot_arbace_j2g_embed

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_edge"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_New() *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed_A_const_1); lang.IFn_Cast(A_arbace_j2g_embed_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_3, A_arbace_j2g_embed_A_const_4, A_arbace_j2g_embed_A_const_5, A_arbace_j2g_embed_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_New() *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000008_fn__1991000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_embed_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_embed_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_embed_A_const_10.GetRawRoot__O(), A_arbace_j2g_embed_A_const_11) }







































































func A_arbace_j2g_embed_sources_A_New() *A_arbace_j2g_embed_sources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_embed_sources_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_embed_sources_A) DoInvoke_O_O_O__O(self, root__0, p__1991000014__1 any) any { var vec__1991000015__3 any = p__1991000014__1; var also__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var base__5 any; var root_22 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_22, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_24 lang.IFn; if




	linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = root__0; var arg_26 any = Lit_49; if linked_23 == nil { base__5 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { base__5 = linked_23.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; var files__6 any; var iter__1927001039__auto____6 any; var fnbody__170 any = /*line :73:1*/A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_New_O_O(also__4, base__5); var tmp1 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class; if





	fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__170); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class = fncls__169d; tmp1 = fncls__169d } else { tmp1 = fncls__169 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp3 any; var root_394 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = base__5; if linked_395 == nil { tmp3 = ifn_396.Invoke_O__O(arg_397) } else { tmp3 = linked_395.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_394, arg_397) }; files__6 = tmp2.Invoke_O__O(tmp3); var vdir__7 any; var root_171 any = /*line :73:1*/A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_171, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_173 lang.IFn; if











	linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = root__0; var arg_175 any = A_arbace_j2g_embed_A_const_31.GetRawRoot__O(); if linked_172 == nil { vdir__7 = ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { vdir__7 = linked_172.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) }; var variants__8 any; if
	jrt.File_Cast(vdir__7).IsDirectory__Z() { var iter__1927001039__auto____8 any; var fnbody__267 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_New_O(vdir__7); var tmp4 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class
		if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__267); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class = fncls__266d; tmp4 = fncls__266d } else { tmp4 = fncls__266 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__267, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp6 any; var root_398 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = vdir__7; if linked_399 == nil { tmp6 = ifn_400.Invoke_O__O(arg_401) } else { tmp6 = linked_399.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_398, arg_401) }; variants__8 = tmp5.Invoke_O__O(tmp6) } else {
//line :86:1
			variants__8 = nil }; var root_268 any =



	A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any; var fnbody__380 any = A_arbace_j2g_embed_sources_fn__1991000047_A_New(); var tmp7 *jrt.Class; var fncls__379 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class; if fncls__379 == nil { var fncls__379d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class = fncls__379d; tmp7 = fncls__379d } else { tmp7 = fncls__379 }; arg_271 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__380, tmp7, nil); var arg_272 any; var root_381 any = A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_383 lang.IFn; if





















	linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_385 any = files__6; if linked_382 == nil { arg_272 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { arg_272 = linked_382.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) }; var arg_273 any; var root_389 any = /*line :90:1*/A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_391 lang.IFn; if






















	linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var arg_393 any = variants__8; if linked_390 == nil { arg_273 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { arg_273 = linked_390.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }; if /*line :90:1*/ linked_269 == nil { return ifn_270.Invoke_O_O_O__O(arg_271, arg_272, arg_273) } else { return linked_269.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_268, arg_271, arg_272, arg_273) } }
//line :79:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :79:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A) Ctor_O_O(c__also, c__base any) { t.F_also = c__also; t.F_base = c__base }
//line :79:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A) Invoke_O_O__O(self, s__1991000019__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_New_O_O_O_O(t.F_also, t.F_base, s__1991000019__1, self); var tmp2 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__168); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class = fncls__167d; tmp2 = fncls__167d } else { tmp2 = fncls__167 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :79:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :79:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A) Ctor_O_O_O_O(c__also, c__base, c__s__1991000019, c__iter__1991000018 any) { t.F_also = c__also; t.F_base = c__base; t.F_s__1991000019 = c__s__1991000019; t.F_iter__1991000018 = c__iter__1991000018 }
//line :79:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A) Invoke_O__O(self any) any { { var s__1991000019__1 any; var t_ any = t.F_s__1991000019; t.F_s__1991000019 = nil; s__1991000019__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_27 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = s__1991000019__1; if linked_28 == nil { temp__1927000414__auto____2 = ifn_29.Invoke_O__O(arg_30) } else { temp__1927000414__auto____2 = linked_28.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_27, arg_30) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000019__3 any = temp__1927000414__auto____2; var tmp1 any; var root_31 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__1991000019__3; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_35 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__1991000019__3; if linked_36 == nil { c__1927001037__auto____4 = ifn_37.Invoke_O__O(arg_38) } else { c__1927001037__auto____4 = linked_36.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_35, arg_38) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000021__6 any; var root_39 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_40 == nil { b__1991000021__6 = ifn_41.Invoke_O__O(arg_42) } else { b__1991000021__6 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_39, arg_42) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_New_O_O_O_I_O(t.F_also, t.F_base, b__1991000021__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__86); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_87 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var root_92 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = b__1991000021__6; if linked_93 == nil { arg_90 = ifn_94.Invoke_O__O(arg_95) } else { arg_90 = linked_93.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_92, arg_95) }; var arg_91 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000018); var tmp5 any; var root_96 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = s__1991000019__3; if linked_97 == nil { tmp5 = ifn_98.Invoke_O__O(arg_99) } else { tmp5 = linked_97.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_96, arg_99) }; arg_91 = tmp4.Invoke_O__O(tmp5); if linked_88 == nil { return ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { return linked_88.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_87, arg_90, arg_91) } } else { var root_100 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any; var root_105 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = b__1991000021__6; if linked_106 == nil { arg_103 = ifn_107.Invoke_O__O(arg_108) } else { arg_103 = linked_106.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_105, arg_108) }; var arg_104 any; if linked_101 == nil { return ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { return linked_101.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) } } } else { var f__4 any; var root_109 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = s__1991000019__3; if linked_110 == nil { f__4 = ifn_111.Invoke_O__O(arg_112) } else { f__4 = linked_110.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_109, arg_112) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()
														if and__1927000168__auto____5 { var root_113 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_117 any = Lit_28; if linked_114 == nil { tmp6 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp6 = linked_114.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_113, arg_116, arg_117) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :79:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil); var tmp8 any; var root_118 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_120 lang.IFn

		if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_119 == nil { tmp8 = ifn_120.Invoke_O__O(arg_121) } else { tmp8 = linked_119.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_118, arg_121) }; rel__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :79:1
		var tmp9 any; var or__1927000174__auto____6 any; var root_122 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_124 lang.IFn


		if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any; var fnbody__133 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_New_O(rel__5); var tmp10 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__133); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class = fncls__132d; tmp10 = fncls__132d } else { tmp10 = fncls__132 }; arg_125 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__133, tmp10, nil); var arg_126 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_123 == nil { or__1927000174__auto____6 = ifn_124.Invoke_O_O__O(arg_125, arg_126) } else { or__1927000174__auto____6 = linked_123.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_122, arg_125, arg_126) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else {
			var root_134 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any; var fnbody__145 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_New_O(rel__5); var tmp11 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__145); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class = fncls__144d; tmp11 = fncls__144d } else { tmp11 = fncls__144 }; arg_137 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp11, nil); var arg_138 any = t.F_also; if linked_135 == nil { tmp9 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { tmp9 = linked_135.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) } }
//line :79:1
		if jrt.J2g_Truth(tmp9) { var root_146 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_150 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1991000018); var tmp13 any; var root_155 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__1991000019__3; if linked_156 == nil { tmp13 = ifn_157.Invoke_O__O(arg_158) } else { tmp13 = linked_156.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_155, arg_158) }; arg_150 = tmp12.Invoke_O__O(tmp13); if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else { var tmp14 any; var root_159 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = s__1991000019__3; if linked_160 == nil { tmp14 = ifn_161.Invoke_O__O(arg_162) } else { tmp14 = linked_160.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_159, arg_162) }; s__1991000019__1 = tmp14; continue L1 } } else { var tmp15 any; var root_163 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = s__1991000019__3; if linked_164 == nil { tmp15 = ifn_165.Invoke_O__O(arg_166) } else { tmp15 = linked_164.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_163, arg_166) }; s__1991000019__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :79:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :79:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A) Ctor_O_O_O_I_O(c__also, c__base, c__b__1991000021 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_also = c__also; t.F_base = c__base; t.F_b__1991000021 = c__b__1991000021; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :79:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A) Invoke_O__O(self any) any { { var i__1991000020__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000020__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000020__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()
																if and__1927000168__auto____3 { var root_43 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_47 any = Lit_28; if linked_44 == nil { tmp2 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp2 = linked_44.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_43, arg_46, arg_47) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :79:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil); var tmp4 any; var root_48 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_50 lang.IFn

		if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_49 == nil { tmp4 = ifn_50.Invoke_O__O(arg_51) } else { tmp4 = linked_49.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_48, arg_51) }; rel__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :79:1
		var tmp5 any; var or__1927000174__auto____4 any; var root_52 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_54 lang.IFn


		if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any; var fnbody__63 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_New_O(rel__3); var tmp6 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__63); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class = fncls__62d; tmp6 = fncls__62d } else { tmp6 = fncls__62 }; arg_55 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp6, nil); var arg_56 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_53 == nil { or__1927000174__auto____4 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { or__1927000174__auto____4 = linked_53.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else {
			var root_64 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var fnbody__75 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_New_O(rel__3); var tmp7 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__75); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class = fncls__74d; tmp7 = fncls__74d } else { tmp7 = fncls__74 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp7, nil); var arg_68 any = t.F_also; if linked_65 == nil { tmp5 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { tmp5 = linked_65.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) } }
//line :79:1
		if jrt.J2g_Truth(tmp5) { var root_76 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = t.F_b__1991000021; var arg_80 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_77 == nil { ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { linked_77.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_76, arg_79, arg_80) }; i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } else { i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } } else { i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :82:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_57 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = t.F_rel; var arg_61 any = p1__1991000012_SHARP___1; if linked_58 == nil { return ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { return linked_58.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } }
//line :82:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :82:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_127 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = t.F_rel; var arg_131 any = p1__1991000012_SHARP___1; if linked_128 == nil { return ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { return linked_128.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) } }
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A{}; t.Ctor_O(p0); return t }
//line :83:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :83:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A) Invoke_O_O__O(self, p1__1991000013_SHARP___1 any) any { var root_69 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = t.F_rel; var arg_73 any = p1__1991000013_SHARP___1; if linked_70 == nil { return ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { return linked_70.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_69, arg_72, arg_73) } }
//line :83:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A{}; t.Ctor_O(p0); return t }
//line :83:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :83:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A) Invoke_O_O__O(self, p1__1991000013_SHARP___1 any) any { var root_139 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = t.F_rel; var arg_143 any = p1__1991000013_SHARP___1; if linked_140 == nil { return ifn_141.Invoke_O_O__O(arg_142, arg_143) } else { return linked_140.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_139, arg_142, arg_143) } }



func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :87:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A) Invoke_O_O__O(self, s__1991000037__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__265 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_New_O_O_O(t.F_vdir, s__1991000037__1, self); var tmp2 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__265); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class = fncls__264d; tmp2 = fncls__264d } else { tmp2 = fncls__264 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__265, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :87:1
func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :87:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A) Ctor_O_O_O(c__vdir, c__s__1991000037, c__iter__1991000036 any) { t.F_vdir = c__vdir; t.F_s__1991000037 = c__s__1991000037; t.F_iter__1991000036 = c__iter__1991000036 }
//line :87:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A) Invoke_O__O(self any) any { { var s__1991000037__1 any; var t_ any = t.F_s__1991000037; t.F_s__1991000037 = nil; s__1991000037__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_176 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__1991000037__1; if linked_177 == nil { temp__1927000414__auto____2 = ifn_178.Invoke_O__O(arg_179) } else { temp__1927000414__auto____2 = linked_177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_176, arg_179) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000037__3 any = temp__1927000414__auto____2; var tmp1 any; var root_180 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = s__1991000037__3; if linked_181 == nil { tmp1 = ifn_182.Invoke_O__O(arg_183) } else { tmp1 = linked_181.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_180, arg_183) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_184 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__1991000037__3; if linked_185 == nil { c__1927001037__auto____4 = ifn_186.Invoke_O__O(arg_187) } else { c__1927001037__auto____4 = linked_185.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_184, arg_187) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000039__6 any; var root_188 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_189 == nil { b__1991000039__6 = ifn_190.Invoke_O__O(arg_191) } else { b__1991000039__6 = linked_189.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_188, arg_191) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__211 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_New_O_O_I_O(b__1991000039__6, t.F_vdir, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__210 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class; if fncls__210 == nil { var fncls__210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__211); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class = fncls__210d; tmp3 = fncls__210d } else { tmp3 = fncls__210 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__211, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_212 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var root_217 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = b__1991000039__6; if linked_218 == nil { arg_215 = ifn_219.Invoke_O__O(arg_220) } else { arg_215 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_217, arg_220) }; var arg_216 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000036); var tmp5 any; var root_221 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__1991000037__3; if linked_222 == nil { tmp5 = ifn_223.Invoke_O__O(arg_224) } else { tmp5 = linked_222.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_221, arg_224) }; arg_216 = tmp4.Invoke_O__O(tmp5); if linked_213 == nil { return ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { return linked_213.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) } } else { var root_225 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any; var root_230 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = b__1991000039__6; if linked_231 == nil { arg_228 = ifn_232.Invoke_O__O(arg_233) } else { arg_228 = linked_231.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_230, arg_233) }; var arg_229 any; if linked_226 == nil { return ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { return linked_226.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } } } else { var f__4 any; var root_234 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = s__1991000037__3; if linked_235 == nil { f__4 = ifn_236.Invoke_O__O(arg_237) } else { f__4 = linked_235.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_234, arg_237) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()
														if and__1927000168__auto____5 { var root_238 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_242 any = Lit_28; if linked_239 == nil { tmp6 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { tmp6 = linked_239.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_238, arg_241, arg_242) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :87:1
	if jrt.J2g_Truth(tmp6) { var root_243 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var tmp7 any; var root_248 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_250 lang.IFn

		if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = jrt.File_Cast(t.F_vdir).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_249 == nil { tmp7 = ifn_250.Invoke_O__O(arg_251) } else { tmp7 = linked_249.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_248, arg_251) }
//line :87:1
		arg_246 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_247 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000036); var tmp9 any; var root_256 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__1991000037__3; if linked_257 == nil { tmp9 = ifn_258.Invoke_O__O(arg_259) } else { tmp9 = linked_257.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_256, arg_259) }; arg_247 = tmp8.Invoke_O__O(tmp9); if linked_244 == nil { return ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { return linked_244.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) } } else { var tmp10 any; var root_260 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = s__1991000037__3; if linked_261 == nil { tmp10 = ifn_262.Invoke_O__O(arg_263) } else { tmp10 = linked_261.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_260, arg_263) }; s__1991000037__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :87:1
func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :87:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A) Ctor_O_O_I_O(c__b__1991000039, c__vdir any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000039 = c__b__1991000039; t.F_vdir = c__vdir; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :87:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A) Invoke_O__O(self any) any { { var i__1991000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000038__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()
																if and__1927000168__auto____3 { var root_192 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_196 any = Lit_28; if linked_193 == nil { tmp2 = ifn_194.Invoke_O_O__O(arg_195, arg_196) } else { tmp2 = linked_193.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_192, arg_195, arg_196) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :87:1
	if jrt.J2g_Truth(tmp2) { var root_197 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = t.F_b__1991000039; var arg_201 any; var tmp3 any; var root_202 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_204 lang.IFn

		if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = jrt.File_Cast(t.F_vdir).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_203 == nil { tmp3 = ifn_204.Invoke_O__O(arg_205) } else { tmp3 = linked_203.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_202, arg_205) }
//line :87:1
		arg_201 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_198 == nil { ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { linked_198.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) }; i__1991000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000038__1); continue L1 } else { i__1991000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_fn__1991000047_A_New() *A_arbace_j2g_embed_sources_fn__1991000047_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_A) Invoke_O_O_O__O(self, m__1, p__1991000046__2 any) any { var vec__1991000048__3 any = p__1991000046__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000048__3, lang.RT_IntCast_J__I_NoInit(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000048__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_274 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_276 lang.IFn; if


	linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = rel__4; var arg_278 any = Lit_53; if linked_275 == nil { tmp1 = ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { tmp1 = linked_275.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_274, arg_277, arg_278) }; if /*line :91:1*/ jrt.J2g_Truth(tmp1) { var p__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_28); var tmp3 any; var root_279 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_281 lang.IFn


		if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = rel__4; var arg_283 any = A_arbace_j2g_embed_A_const_34; var arg_284 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_53)))).Ref(); if linked_280 == nil { tmp3 = ifn_281.Invoke_O_O_O__O(arg_282, arg_283, arg_284) } else { tmp3 = linked_280.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_279, arg_282, arg_283, arg_284) }; p__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
//line :91:1
		var pairs__7 any; var root_285 any = A_arbace_j2g_embed_A_const_35.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_287 lang.IFn



		if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = A_arbace_j2g_embed_A_const_36; var arg_289 any; var root_290 any = A_arbace_j2g_embed_A_const_37.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = text__5; if linked_291 == nil { arg_289 = ifn_292.Invoke_O__O(arg_293) } else { arg_289 = linked_291.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_290, arg_293) }; if linked_286 == nil { pairs__7 = ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { pairs__7 = linked_286.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_285, arg_288, arg_289) }
		var tmp4 any; var root_359 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = m__1; var arg_363 any = p__6; if linked_360 == nil { tmp4 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp4 = linked_360.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if jrt.J2g_Truth(tmp4) { } else { var tmp5 any; var root_364 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_366 lang.IFn
			if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(); var arg_368 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_365 == nil { tmp5 = ifn_366.Invoke_O_O__O(arg_367, arg_368) } else { tmp5 = linked_365.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_364, arg_367, arg_368) }
//line :96:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5)))
		}
		var root_294 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = m__1; var arg_298 any = p__6; var arg_299 any; var fnbody__334 any = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp6 *jrt.Class; var fncls__333 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class; if fncls__333 == nil { var fncls__333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__334); A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class = fncls__333d; tmp6 = fncls__333d } else { tmp6 = fncls__333 }; arg_299 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__334, tmp6, nil); if linked_295 == nil { return ifn_296.Invoke_O_O_O__O(arg_297, arg_298, arg_299) } else { return linked_295.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_294, arg_297, arg_298, arg_299) } } else {
//line :91:1
			var tmp7 any; var root_335 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_337 lang.IFn














			if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = rel__4; var arg_339 any = Lit_58; if linked_336 == nil { tmp7 = ifn_337.Invoke_O_O__O(arg_338, arg_339) } else { tmp7 = linked_336.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_335, arg_338, arg_339) }
//line :91:1
			if jrt.J2g_Truth(tmp7) { var p__6_2 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_28); var tmp9 any; var root_340 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_342 lang.IFn















				if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = rel__4; var arg_344 any = A_arbace_j2g_embed_A_const_34; var arg_345 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_58)))).Ref(); if linked_341 == nil { tmp9 = ifn_342.Invoke_O_O_O__O(arg_343, arg_344, arg_345) } else { tmp9 = linked_341.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_340, arg_343, arg_344, arg_345) }; p__6_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref()
				var tmp10 any; var root_369 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = m__1; var arg_373 any = p__6_2; if linked_370 == nil { tmp10 = ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { tmp10 = linked_370.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_369, arg_372, arg_373) }; if jrt.J2g_Truth(tmp10) { } else { var tmp11 any; var root_374 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_376 lang.IFn
					if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(); var arg_378 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_375 == nil { tmp11 = ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { tmp11 = linked_375.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) }
//line :108:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp11)))
				}
				var root_346 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = m__1; var arg_350 any = p__6_2; var arg_351 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_352 any = text__5; if linked_347 == nil { return ifn_348.Invoke_O_O_O_O__O(arg_349, arg_350, arg_351, arg_352) } else { return linked_347.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_346, arg_349, arg_350, arg_351, arg_352) } } else {
//line :91:1
					if A_arbace_j2g_embed_A_const_42 != nil {



















						var root_353 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = m__1; var arg_357 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(); var arg_358 any = text__5; if linked_354 == nil { return ifn_355.Invoke_O_O_O__O(arg_356, arg_357, arg_358) } else { return linked_354.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_353, arg_356, arg_357, arg_358) } } else {
//line :91:1
							return nil } } } }






func A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :98:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :98:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A) Invoke_O_O__O(self, src__1 any) any {
	var root_300 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var fnbody__332 any = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_New_O_O(t.F_p, t.F_rel); var tmp1 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__332); A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class = fncls__331d; tmp1 = fncls__331d } else { tmp1 = fncls__331 }; arg_303 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__332, tmp1, nil); var arg_304 any = src__1; var arg_305 any = t.F_pairs; if linked_301 == nil { return ifn_302.Invoke_O_O_O__O(arg_303, arg_304, arg_305) } else { return linked_301.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_300, arg_303, arg_304, arg_305) } }
//line :99:1
func A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :99:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :99:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A) Invoke_O_O_O__O(self, src__1, p__1991000052__2 any) any { var vec__1991000054__3 any = p__1991000052__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000054__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000054__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var root_317 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); var arg_321 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref(); if linked_318 == nil { tmp1 = ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { tmp1 = linked_318.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_317, arg_320, arg_321) } }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_322 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_324 lang.IFn
		if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var tmp3 any = t.F_rel; var arg_325 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_60, nil, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_41.GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(); var arg_326 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_323 == nil { tmp2 = ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { tmp2 = linked_323.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) }
//line :101:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp4 /*line :104:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp5 any; var root_306 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = src__1; var arg_310 any = A_arbace_j2g_embed_A_const_34; var arg_311 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); if linked_307 == nil { tmp5 = ifn_308.Invoke_O_O_O__O(arg_309, arg_310, arg_311) } else { tmp5 = linked_307.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_306, arg_309, arg_310, arg_311) }; var tmp6 any = tmp5; var tmp7 any; var root_312 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = src__1; var arg_316 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__6), int64(lang.RT_Count_O__I_NoInit(old__4)))).Ref(); if linked_313 == nil { tmp7 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp7 = linked_313.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp6, new__5, tmp7)).Ref() }















func A_arbace_j2g_embed_reify__1991000061_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_j2g_embed_reify__1991000061_A { t := &A_arbace_j2g_embed_reify__1991000061_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :120:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :120:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :120:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :120:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :120:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_j2g_embed_A_Init(); tmp1 = A_arbace_j2g_embed_A_const_49; return lang.Symbol_Cast(tmp1) }
//line :120:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :120:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_j2g_embed_reify__1991000061_A_New_IPersistentMap(m) }





func A_arbace_j2g_embed_read_all_A_New() *A_arbace_j2g_embed_read_all_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_embed_read_all_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var root_410 any = A_arbace_j2g_embed_A_const_54.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_412 lang.IFn; if

	linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_55.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_embed_A_const_56; var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any = A_arbace_j2g_embed_A_const_57; var tmp5 any = A_arbace_j2g_embed_A_const_58.GetRawRoot__O(); var tmp6 any = A_arbace_j2g_embed_A_const_59; var tmp7 *lang.Compiler_AOTFn; var fnbody__424 any = A_arbace_j2g_embed_read_all_fn__1991000063_A_New(); var tmp8 *jrt.Class; var fncls__423 *jrt.Class = A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class; if

	fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class = fncls__423d; tmp8 = fncls__423d } else { tmp8 = fncls__423 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__424, tmp8, nil); arg_413 = /*line :128:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7.Ref()); if linked_411 == nil { ifn_412.Invoke_O__O(arg_413) } else { linked_411.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_410, arg_413) }; var tmp9 any; tmp11 := /*line :126:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any; var root_402 any = A_arbace_j2g_embed_A_const_50.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_404 lang.IFn





		if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = A_arbace_j2g_embed_A_const_51; var arg_406 any = r__2; if linked_403 == nil { f__6 = ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { f__6 = linked_403.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) }
		if lang.Util_Equiv_O_O__Z_NoInit(f__6, A_arbace_j2g_embed_A_const_52) { tmp9 = acc__5 } else { var tmp10 any; var root_425 any = A_arbace_j2g_embed_A_const_10.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = acc__5; var arg_429 any = f__6; if linked_426 == nil { tmp10 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { tmp10 = linked_426.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; acc__5 = tmp10; continue L1 }
//line :126:1
		break L1 } }; return nil }(); var root_407 any = A_arbace_j2g_embed_A_const_53.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_409 lang.IFn; if

	linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; if linked_408 == nil { ifn_409.Invoke__O() } else { linked_408.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_407) }; if /*line :126:1*/ tmp11 != nil { panic(tmp11) }; return tmp9 }



func A_arbace_j2g_embed_read_all_fn__1991000063_A_New() *A_arbace_j2g_embed_read_all_fn__1991000063_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_fn__1991000063_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000063_A) Ctor() {}
//line :130:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000063_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_j2g_embed_class_like_QMARK__A_New() *A_arbace_j2g_embed_class_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Ctor() {}
//line :135:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_1); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)), int64(lang.RT_Count_O__I_NoInit(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_embed_package_like_QMARK__A_New() *A_arbace_j2g_embed_package_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_1))); if and__1927000168__auto____2 {
											var root_430 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any; var root_434 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = s__0; if linked_435 == nil { arg_433 = ifn_436.Invoke_O__O(arg_437) } else { arg_433 = linked_435.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if linked_431 == nil { return ifn_432.Invoke_O__O(arg_433) } else { return linked_431.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_430, arg_433) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_embed_names_A_New() *A_arbace_j2g_embed_names_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_j2g_embed_names_A) Ctor() {}
//line :142:1
func (t *A_arbace_j2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any; var root_438 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_440 lang.IFn; if



	linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_439 == nil { acc__2 = ifn_440.Invoke_O__O(arg_441) } else { acc__2 = linked_439.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_438, arg_441) }; var walk__3 any; var fnbody__684 any = /*line :142:1*/A_arbace_j2g_embed_names_walk__1991000068_A_New_O(acc__2); var tmp1 *jrt.Class; var fncls__683 *jrt.Class = A_arbace_j2g_embed_names_walk__1991000068_A_fn_class; if




	fncls__683 == nil { var fncls__683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__684); A_arbace_j2g_embed_names_walk__1991000068_A_fn_class = fncls__683d; tmp1 = fncls__683d } else { tmp1 = fncls__683 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__684, tmp1, nil); var seq_1991000092__4 any; var root_689 any = /*line :142:1*/A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_691 lang.IFn; if




















	linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any; var root_693 any = A_arbace_j2g_embed_A_const_75.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, A_arbace_j2g_embed_read_all_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = text__0; if linked_694 == nil { arg_692 = ifn_695.Invoke_O__O(arg_696) } else { arg_692 = linked_694.(*A_arbace_j2g_embed_read_all_A).Invoke_O_O__O(root_693, arg_696) }; if linked_690 == nil { seq_1991000092__4 = ifn_691.Invoke_O__O(arg_692) } else { seq_1991000092__4 = linked_690.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_689, arg_692) }; var chunk_1991000093__5 any; var count_1991000094__6 int64 = 0; var i_1991000095__7 int64 = 0; L1:
//line :142:1
	for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000095__7, count_1991000094__6) { var f__8 any = lang.Indexed_Cast(chunk_1991000093__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000095__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000095__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_697 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = seq_1991000092__4; if linked_698 == nil { temp__1927000414__auto____8 = ifn_699.Invoke_O__O(arg_700) } else { temp__1927000414__auto____8 = linked_698.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_697, arg_700) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1991000092__9 any = temp__1927000414__auto____8; var tmp2 any; var root_701 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = seq_1991000092__9; if linked_702 == nil { tmp2 = ifn_703.Invoke_O__O(arg_704) } else { tmp2 = linked_702.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_701, arg_704) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____10 any; var root_705 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = seq_1991000092__9; if linked_706 == nil { c__1927000678__auto____10 = ifn_707.Invoke_O__O(arg_708) } else { c__1927000678__auto____10 = linked_706.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_705, arg_708) }; var tmp3 any; var root_713 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq_1991000092__9; if linked_714 == nil { tmp3 = ifn_715.Invoke_O__O(arg_716) } else { tmp3 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_713, arg_716) }; seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = tmp3, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_709 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seq_1991000092__9; if linked_710 == nil { f__10 = ifn_711.Invoke_O__O(arg_712) } else { f__10 = linked_710.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_709, arg_712) }; lang.IFn_Cast(walk__3).Invoke_O__O(f__10); var tmp4 any; var root_717 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_1991000092__9; if linked_718 == nil { tmp4 = ifn_719.Invoke_O__O(arg_720) } else { tmp4 = linked_718.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_717, arg_720) }; seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = tmp4, nil, 0, 0; continue L1 } } }
//line :142:1
		break L1 }; var root_685 any =





















	A_arbace_j2g_embed_A_const_74.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = acc__2; if linked_686 == nil { return ifn_687.Invoke_O__O(arg_688) } else { return linked_686.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_685, arg_688) } }
//line :147:1
func A_arbace_j2g_embed_names_walk__1991000068_A_New_O(p0 any) *A_arbace_j2g_embed_names_walk__1991000068_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_walk__1991000068_A{}; t.Ctor_O(p0); return t }
//line :147:1
func (t *A_arbace_j2g_embed_names_walk__1991000068_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :147:1
func (t *A_arbace_j2g_embed_names_walk__1991000068_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__1)
											if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											var tmp1 any; var root_442 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_444 lang.IFn
											if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = x__1; if linked_443 == nil { tmp1 = ifn_444.Invoke_O__O(arg_445) } else { tmp1 = linked_443.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_442, arg_445) }
//line :149:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any; var root_543 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = x__1; if linked_544 == nil { tmp3 = ifn_545.Invoke_O__O(arg_546) } else { tmp3 = linked_544.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_543, arg_546) }; and__1927000168__auto____2 = lang.Util_Identical_O_O__Z_NoInit(tmp3, nil); if and__1927000168__auto____2 { var root_547 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var root_551 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = x__1; if linked_552 == nil { arg_550 = ifn_553.Invoke_O__O(arg_554) } else { arg_550 = linked_552.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_551, arg_554) }; if linked_548 == nil { tmp2 = ifn_549.Invoke_O__O(arg_550) } else { tmp2 = linked_548.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_547, arg_550) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) {
			var root_555 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = t.F_acc; var arg_559 any; var root_560 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = x__1; if linked_561 == nil { arg_559 = ifn_562.Invoke_O__O(arg_563) } else { arg_559 = linked_561.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_560, arg_563) }; if linked_556 == nil { ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { linked_556.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_555, arg_558, arg_559) } }
		var tmp4 any; var and__1927000168__auto____2_2 any; var root_446 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = x__1; if linked_447 == nil { and__1927000168__auto____2_2 = ifn_448.Invoke_O__O(arg_449) } else { and__1927000168__auto____2_2 = linked_447.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_446, arg_449) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var root_450 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var root_454 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = x__1; if linked_455 == nil { arg_453 = ifn_456.Invoke_O__O(arg_457) } else { arg_453 = linked_455.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_454, arg_457) }; if linked_451 == nil { tmp4 = ifn_452.Invoke_O__O(arg_453) } else { tmp4 = linked_451.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_450, arg_453) } } else { tmp4 = and__1927000168__auto____2_2 }; if jrt.J2g_Truth(tmp4) {
			var root_458 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = t.F_acc; var arg_462 any; var root_463 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = x__1; if linked_464 == nil { arg_462 = ifn_465.Invoke_O__O(arg_466) } else { arg_462 = linked_464.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_463, arg_466) }; if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else {
//line :153:1
				return nil } } else {
//line :149:1
					var tmp5 any; var or__1927000174__auto____2 any; var root_467 any = A_arbace_j2g_embed_A_const_66.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_469 lang.IFn





					if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = x__1; if linked_468 == nil { or__1927000174__auto____2 = ifn_469.Invoke_O__O(arg_470) } else { or__1927000174__auto____2 = linked_468.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { var root_471 any = A_arbace_j2g_embed_A_const_67.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = x__1; if linked_472 == nil { tmp5 = ifn_473.Invoke_O__O(arg_474) } else { tmp5 = linked_472.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_471, arg_474) } }
//line :149:1
					if jrt.J2g_Truth(tmp5) {






						var tmp6 any; var and__1927000168__auto____2_3 any; var root_564 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any; var root_568 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = x__1; if linked_569 == nil { arg_567 = ifn_570.Invoke_O__O(arg_571) } else { arg_567 = linked_569.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_568, arg_571) }; if linked_565 == nil { and__1927000168__auto____2_3 = ifn_566.Invoke_O__O(arg_567) } else { and__1927000168__auto____2_3 = linked_565.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_564, arg_567) }; if jrt.J2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool; var tmp7 any; var root_572 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var root_576 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = x__1; if linked_577 == nil { arg_575 = ifn_578.Invoke_O__O(arg_579) } else { arg_575 = linked_577.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_576, arg_579) }; if linked_573 == nil { tmp7 = ifn_574.Invoke_O__O(arg_575) } else { tmp7 = linked_573.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_572, arg_575) }; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z_NoInit(tmp7, nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_580 any = A_arbace_j2g_embed_A_const_71.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, A_arbace_j2g_embed_package_like_QMARK__A_fn_class); var ifn_582 lang.IFn
							if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any; var root_584 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any; var root_588 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = x__1; if linked_589 == nil { arg_587 = ifn_590.Invoke_O__O(arg_591) } else { arg_587 = linked_589.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_588, arg_591) }; if linked_585 == nil { arg_583 = ifn_586.Invoke_O__O(arg_587) } else { arg_583 = linked_585.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_584, arg_587) }; if linked_581 == nil { and__1927000168__auto____4 = ifn_582.Invoke_O__O(arg_583) } else { and__1927000168__auto____4 = linked_581.(*A_arbace_j2g_embed_package_like_QMARK__A).Invoke_O_O__O(root_580, arg_583) }
//line :156:1
							if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_592 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_594 lang.IFn
								if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any; var root_596 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = x__1; if linked_597 == nil { arg_595 = ifn_598.Invoke_O__O(arg_599) } else { arg_595 = linked_597.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_596, arg_599) }; if linked_593 == nil { and__1927000168__auto____5 = ifn_594.Invoke_O__O(arg_595) } else { and__1927000168__auto____5 = linked_593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_592, arg_595) }
//line :156:1
								if jrt.J2g_Truth(and__1927000168__auto____5) {

									var root_600 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var arg_604 any; var root_605 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = x__1; if linked_606 == nil { arg_604 = ifn_607.Invoke_O__O(arg_608) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_605, arg_608) }; if linked_601 == nil { tmp6 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { tmp6 = linked_601.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_600, arg_603, arg_604) } } else {
//line :156:1
										tmp6 = and__1927000168__auto____5 } } else { tmp6 = and__1927000168__auto____4 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp6 = and__1927000168__auto____2_3 }; if jrt.J2g_Truth(tmp6) { var seq_1991000069__2 any; var root_609 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_611 lang.IFn


											if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any; var root_613 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = x__1; if linked_614 == nil { arg_612 = ifn_615.Invoke_O__O(arg_616) } else { arg_612 = linked_614.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_613, arg_616) }; if linked_610 == nil { seq_1991000069__2 = ifn_611.Invoke_O__O(arg_612) } else { seq_1991000069__2 = linked_610.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_609, arg_612) }
//line :156:1
											var chunk_1991000070__3 any; var count_1991000071__4 int64 = 0; var i_1991000072__5 int64 = 0; L1: for {


												if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000072__5, count_1991000071__4) { var c__6 any = lang.Indexed_Cast(chunk_1991000070__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000072__5)); var root_633 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = t.F_acc; var arg_637 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp9 any; var root_638 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = x__1; if linked_639 == nil { tmp9 = ifn_640.Invoke_O__O(arg_641) } else { tmp9 = linked_639.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_638, arg_641) }; arg_637 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, c__6)).Ref(); if linked_634 == nil { ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { linked_634.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_633, arg_636, arg_637) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000072__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_617 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = seq_1991000069__2; if linked_618 == nil { temp__1927000414__auto____6 = ifn_619.Invoke_O__O(arg_620) } else { temp__1927000414__auto____6 = linked_618.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_617, arg_620) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1991000069__7 any = temp__1927000414__auto____6; var tmp10 any; var root_621 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = seq_1991000069__7; if linked_622 == nil { tmp10 = ifn_623.Invoke_O__O(arg_624) } else { tmp10 = linked_622.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_621, arg_624) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____8 any; var root_625 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = seq_1991000069__7; if linked_626 == nil { c__1927000678__auto____8 = ifn_627.Invoke_O__O(arg_628) } else { c__1927000678__auto____8 = linked_626.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_625, arg_628) }; var tmp11 any; var root_642 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = seq_1991000069__7; if linked_643 == nil { tmp11 = ifn_644.Invoke_O__O(arg_645) } else { tmp11 = linked_643.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_642, arg_645) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = tmp11, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_629 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = seq_1991000069__7; if linked_630 == nil { c__8 = ifn_631.Invoke_O__O(arg_632) } else { c__8 = linked_630.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_629, arg_632) }; var root_646 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = t.F_acc; var arg_650 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp13 any; var root_651 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = x__1; if linked_652 == nil { tmp13 = ifn_653.Invoke_O__O(arg_654) } else { tmp13 = linked_652.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_651, arg_654) }; arg_650 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, c__8)).Ref(); if linked_647 == nil { ifn_648.Invoke_O_O__O(arg_649, arg_650) } else { linked_647.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_646, arg_649, arg_650) }; var tmp14 any; var root_655 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = seq_1991000069__7; if linked_656 == nil { tmp14 = ifn_657.Invoke_O__O(arg_658) } else { tmp14 = linked_656.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_655, arg_658) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = tmp14, nil, 0, 0; continue L1 } } }
//line :156:1
												break L1 } }
//line :149:1
						var seq_1991000073__2 any; var root_475 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_477 lang.IFn










						if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__1; if linked_476 == nil { seq_1991000073__2 = ifn_477.Invoke_O__O(arg_478) } else { seq_1991000073__2 = linked_476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_475, arg_478) }
//line :149:1
						var chunk_1991000074__3 any; var count_1991000075__4 int64 = 0; var i_1991000076__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000076__5, count_1991000075__4) { var y__6 any = lang.Indexed_Cast(chunk_1991000074__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000076__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000076__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_479 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1991000073__2; if linked_480 == nil { temp__1927000414__auto____6_2 = ifn_481.Invoke_O__O(arg_482) } else { temp__1927000414__auto____6_2 = linked_480.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_479, arg_482) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1991000073__7 any = temp__1927000414__auto____6_2; var tmp15 any; var root_483 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = seq_1991000073__7; if linked_484 == nil { tmp15 = ifn_485.Invoke_O__O(arg_486) } else { tmp15 = linked_484.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_483, arg_486) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____8_2 any; var root_487 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = seq_1991000073__7; if linked_488 == nil { c__1927000678__auto____8_2 = ifn_489.Invoke_O__O(arg_490) } else { c__1927000678__auto____8_2 = linked_488.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_487, arg_490) }; var tmp16 any; var root_659 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = seq_1991000073__7; if linked_660 == nil { tmp16 = ifn_661.Invoke_O__O(arg_662) } else { tmp16 = linked_660.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_659, arg_662) }; seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = tmp16, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_491 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = seq_1991000073__7; if linked_492 == nil { y__8 = ifn_493.Invoke_O__O(arg_494) } else { y__8 = linked_492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_491, arg_494) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp17 any; var root_663 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = seq_1991000073__7; if linked_664 == nil { tmp17 = ifn_665.Invoke_O__O(arg_666) } else { tmp17 = linked_664.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_663, arg_666) }; seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = tmp17, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :149:1
								var tmp18 any; var root_495 any = A_arbace_j2g_embed_A_const_68.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_497 lang.IFn











								if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = x__1; if linked_496 == nil { tmp18 = ifn_497.Invoke_O__O(arg_498) } else { tmp18 = linked_496.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_495, arg_498) }
//line :149:1
								if jrt.J2g_Truth(tmp18) { var seq_1991000077__2 any; var root_499 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_501 lang.IFn











									if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = x__1; if linked_500 == nil { seq_1991000077__2 = ifn_501.Invoke_O__O(arg_502) } else { seq_1991000077__2 = linked_500.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_499, arg_502) }
//line :149:1
									var chunk_1991000078__3 any; var count_1991000079__4 int64 = 0; var i_1991000080__5 int64 = 0; L3: for {











										if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000080__5, count_1991000079__4) { var vec__1991000081__6 any = lang.Indexed_Cast(chunk_1991000078__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000080__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000081__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000081__6, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000080__5); continue L3 } else { var temp__1927000414__auto____6_3 any; var root_503 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_1991000077__2; if linked_504 == nil { temp__1927000414__auto____6_3 = ifn_505.Invoke_O__O(arg_506) } else { temp__1927000414__auto____6_3 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1991000077__7 any = temp__1927000414__auto____6_3; var tmp19 any; var root_507 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_1991000077__7; if linked_508 == nil { tmp19 = ifn_509.Invoke_O__O(arg_510) } else { tmp19 = linked_508.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_507, arg_510) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____8_3 any; var root_511 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1991000077__7; if linked_512 == nil { c__1927000678__auto____8_3 = ifn_513.Invoke_O__O(arg_514) } else { c__1927000678__auto____8_3 = linked_512.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_511, arg_514) }; var tmp20 any; var root_667 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq_1991000077__7; if linked_668 == nil { tmp20 = ifn_669.Invoke_O__O(arg_670) } else { tmp20 = linked_668.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_667, arg_670) }; seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = tmp20, c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1991000084__8 any; var root_515 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = seq_1991000077__7; if linked_516 == nil { vec__1991000084__8 = ifn_517.Invoke_O__O(arg_518) } else { vec__1991000084__8 = linked_516.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_515, arg_518) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000084__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000084__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); var tmp21 any; var root_671 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = seq_1991000077__7; if linked_672 == nil { tmp21 = ifn_673.Invoke_O__O(arg_674) } else { tmp21 = linked_672.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_671, arg_674) }; seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = tmp21, nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :149:1
											var tmp22 any; var root_519 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_521 lang.IFn












											if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = x__1; if linked_520 == nil { tmp22 = ifn_521.Invoke_O__O(arg_522) } else { tmp22 = linked_520.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_519, arg_522) }
//line :149:1
											if jrt.J2g_Truth(tmp22) { var seq_1991000087__2 any; var root_523 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_525 lang.IFn












												if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = x__1; if linked_524 == nil { seq_1991000087__2 = ifn_525.Invoke_O__O(arg_526) } else { seq_1991000087__2 = linked_524.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_523, arg_526) }
//line :149:1
												var chunk_1991000088__3 any; var count_1991000089__4 int64 = 0; var i_1991000090__5 int64 = 0; L4: for {












													if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000090__5, count_1991000089__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1991000088__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000090__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000090__5); continue L4 } else { var temp__1927000414__auto____6_4 any; var root_527 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = seq_1991000087__2; if linked_528 == nil { temp__1927000414__auto____6_4 = ifn_529.Invoke_O__O(arg_530) } else { temp__1927000414__auto____6_4 = linked_528.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_527, arg_530) }; if jrt.J2g_Truth(temp__1927000414__auto____6_4) { var seq_1991000087__7 any = temp__1927000414__auto____6_4; var tmp23 any; var root_531 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = seq_1991000087__7; if linked_532 == nil { tmp23 = ifn_533.Invoke_O__O(arg_534) } else { tmp23 = linked_532.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_531, arg_534) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____8_4 any; var root_535 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = seq_1991000087__7; if linked_536 == nil { c__1927000678__auto____8_4 = ifn_537.Invoke_O__O(arg_538) } else { c__1927000678__auto____8_4 = linked_536.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_535, arg_538) }; var tmp24 any; var root_675 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = seq_1991000087__7; if linked_676 == nil { tmp24 = ifn_677.Invoke_O__O(arg_678) } else { tmp24 = linked_676.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_675, arg_678) }; seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = tmp24, c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var y__8_2 any; var root_539 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = seq_1991000087__7; if linked_540 == nil { y__8_2 = ifn_541.Invoke_O__O(arg_542) } else { y__8_2 = linked_540.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_539, arg_542) }; lang.IFn_Cast(self).Invoke_O__O(y__8_2); var tmp25 any; var root_679 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = seq_1991000087__7; if linked_680 == nil { tmp25 = ifn_681.Invoke_O__O(arg_682) } else { tmp25 = linked_680.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_679, arg_682) }; seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = tmp25, nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :149:1
														return nil } } } } }; /*line :147:1*/panic("j2g: unreachable") }





























func A_arbace_j2g_embed_cut_candidates_A_New() *A_arbace_j2g_embed_cut_candidates_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var root_721 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any; var iter__1927001039__auto____2 any; var fnbody__838 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_New(); var tmp1 *jrt.Class; var fncls__837 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class; if fncls__837 == nil { var fncls__837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class = fncls__837d; tmp1 = fncls__837d } else { tmp1 = fncls__837 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__838, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_839 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var root_844 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var arg_848 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp5 any; var root_855 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; if linked_856 == nil { tmp5 = ifn_857.Invoke__O() } else { tmp5 = linked_856.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_855) }; var tmp6 any = tmp5; var tmp7 *lang.Compiler_AOTFn; var fnbody__863 any = A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_New(); var tmp8 *jrt.Class; var fncls__862 *jrt.Class = A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class; if fncls__862 == nil { var fncls__862d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class = fncls__862d; tmp8 = fncls__862d } else { tmp8 = fncls__862 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__863, tmp8, nil); arg_848 = tmp4.Invoke_O_O_O__O(tmp6, tmp7.Ref(), srcs__0); if linked_845 == nil { arg_842 = ifn_846.Invoke_O_O__O(arg_847, arg_848) } else { arg_842 = linked_845.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_844, arg_847, arg_848) }; var arg_843 any = A_arbace_j2g_embed_A_const_88.GetRawRoot__O(); if linked_840 == nil { tmp3 = ifn_841.Invoke_O_O__O(arg_842, arg_843) } else { tmp3 = linked_840.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_839, arg_842, arg_843) }; arg_724 = tmp2.Invoke_O__O(tmp3); if linked_722 == nil { return ifn_723.Invoke_O__O(arg_724) } else { return linked_722.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_721, arg_724) } }
//line :182:1
func A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_New() *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_fn__1991000112_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A) Invoke_O_O__O(self, p__1991000111__1 any) any { var vec__1991000113__2 any = p__1991000111__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000113__2, lang.RT_IntCast_J__I_NoInit(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000113__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_858 any = A_arbace_j2g_embed_A_const_87.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, A_arbace_j2g_embed_names_A_fn_class); var ifn_860 lang.IFn; _ = ___3; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = text__4; if linked_859 == nil { return ifn_860.Invoke_O__O(arg_861) } else { return linked_859.(*A_arbace_j2g_embed_names_A).Invoke_O_O__O(root_858, arg_861) } }
//line :182:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_New() *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A) Invoke_O_O__O(self, s__1991000098__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__836 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_New_O_O(s__1991000098__1, self); var tmp2 *jrt.Class; var fncls__835 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class; if fncls__835 == nil { var fncls__835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__836); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class = fncls__835d; tmp2 = fncls__835d } else { tmp2 = fncls__835 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__836, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :182:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A) Ctor_O_O(c__s__1991000098, c__iter__1991000097 any) { t.F_s__1991000098 = c__s__1991000098; t.F_iter__1991000097 = c__iter__1991000097 }
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A) Invoke_O__O(self any) any { { var s__1991000098__1 any; var t_ any = t.F_s__1991000098; t.F_s__1991000098 = nil; s__1991000098__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_725 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = s__1991000098__1; if linked_726 == nil { temp__1927000414__auto____2 = ifn_727.Invoke_O__O(arg_728) } else { temp__1927000414__auto____2 = linked_726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_725, arg_728) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000098__3 any = temp__1927000414__auto____2; var tmp1 any; var root_729 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = s__1991000098__3; if linked_730 == nil { tmp1 = ifn_731.Invoke_O__O(arg_732) } else { tmp1 = linked_730.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_729, arg_732) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_733 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = s__1991000098__3; if linked_734 == nil { c__1927001037__auto____4 = ifn_735.Invoke_O__O(arg_736) } else { c__1927001037__auto____4 = linked_734.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_733, arg_736) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000100__6 any; var root_737 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_738 == nil { b__1991000100__6 = ifn_739.Invoke_O__O(arg_740) } else { b__1991000100__6 = linked_738.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_737, arg_740) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__771 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_New_I_O_O(size__1927001038__auto____5, b__1991000100__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__770 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class; if fncls__770 == nil { var fncls__770d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__771); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class = fncls__770d; tmp3 = fncls__770d } else { tmp3 = fncls__770 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__771, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_772 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var root_777 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = b__1991000100__6; if linked_778 == nil { arg_775 = ifn_779.Invoke_O__O(arg_780) } else { arg_775 = linked_778.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_777, arg_780) }; var arg_776 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000097); var tmp5 any; var root_781 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = s__1991000098__3; if linked_782 == nil { tmp5 = ifn_783.Invoke_O__O(arg_784) } else { tmp5 = linked_782.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_781, arg_784) }; arg_776 = tmp4.Invoke_O__O(tmp5); if linked_773 == nil { return ifn_774.Invoke_O_O__O(arg_775, arg_776) } else { return linked_773.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_772, arg_775, arg_776) } } else { var root_785 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; var root_790 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = b__1991000100__6; if linked_791 == nil { arg_788 = ifn_792.Invoke_O__O(arg_793) } else { arg_788 = linked_791.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_790, arg_793) }; var arg_789 any; if linked_786 == nil { return ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { return linked_786.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) } } } else { var n__4 any; var root_794 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = s__1991000098__3; if linked_795 == nil { n__4 = ifn_796.Invoke_O__O(arg_797) } else { n__4 = linked_795.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_794, arg_797) }; var tmp6 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_798 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_800 lang.IFn

	if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = A_arbace_j2g_embed_A_const_78; var arg_802 any = n__4; if linked_799 == nil { or__1927000174__auto____5 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { or__1927000174__auto____5 = linked_799.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
		var root_803 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = A_arbace_j2g_embed_A_const_79; var arg_807 any = n__4; if linked_804 == nil { and__1927000168__auto____5 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { and__1927000168__auto____5 = linked_804.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) } }
//line :184:1
	if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_808 any = A_arbace_j2g_embed_A_const_80.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = A_arbace_j2g_embed_A_const_81; var arg_812 any = n__4; var arg_813 any; var fnbody__815 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_New_O(n__4); var tmp7 *jrt.Class; var fncls__814 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class; if fncls__814 == nil { var fncls__814d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__815); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class = fncls__814d; tmp7 = fncls__814d } else { tmp7 = fncls__814 }; arg_813 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__815, tmp7, nil); if linked_809 == nil { tmp6 = ifn_810.Invoke_O_O_O__O(arg_811, arg_812, arg_813) } else { tmp6 = linked_809.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_808, arg_811, arg_812, arg_813) } } else {
//line :184:1
			tmp6 = and__1927000168__auto____5 }
//line :182:1
	if jrt.J2g_Truth(tmp6) { var root_816 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_821 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_823 lang.IFn







		if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = n__4; var arg_825 any = Lit_1; var arg_826 any = Lit_7; if linked_822 == nil { arg_819 = ifn_823.Invoke_O_O_O__O(arg_824, arg_825, arg_826) } else { arg_819 = linked_822.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_821, arg_824, arg_825, arg_826) }
//line :182:1
		var arg_820 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000097); var tmp9 any; var root_827 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = s__1991000098__3; if linked_828 == nil { tmp9 = ifn_829.Invoke_O__O(arg_830) } else { tmp9 = linked_828.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_827, arg_830) }; arg_820 = tmp8.Invoke_O__O(tmp9); if linked_817 == nil { return ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { return linked_817.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) } } else { var tmp10 any; var root_831 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = s__1991000098__3; if linked_832 == nil { tmp10 = ifn_833.Invoke_O__O(arg_834) } else { tmp10 = linked_832.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_831, arg_834) }; s__1991000098__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1991000100, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000100 = c__b__1991000100; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A) Invoke_O__O(self any) any { { var i__1991000099__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000099__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000099__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_741 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_743 lang.IFn

	if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = A_arbace_j2g_embed_A_const_78; var arg_745 any = n__2; if linked_742 == nil { or__1927000174__auto____3 = ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { or__1927000174__auto____3 = linked_742.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
		var root_746 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = A_arbace_j2g_embed_A_const_79; var arg_750 any = n__2; if linked_747 == nil { and__1927000168__auto____3 = ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { and__1927000168__auto____3 = linked_747.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } }
//line :184:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {


		var root_751 any = A_arbace_j2g_embed_A_const_80.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = A_arbace_j2g_embed_A_const_81; var arg_755 any = n__2; var arg_756 any; var fnbody__758 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_New_O(n__2); var tmp3 *jrt.Class; var fncls__757 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class; if fncls__757 == nil { var fncls__757d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__758); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class = fncls__757d; tmp3 = fncls__757d } else { tmp3 = fncls__757 }; arg_756 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__758, tmp3, nil); if linked_752 == nil { tmp2 = ifn_753.Invoke_O_O_O__O(arg_754, arg_755, arg_756) } else { tmp2 = linked_752.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_751, arg_754, arg_755, arg_756) } } else {
//line :184:1
			tmp2 = and__1927000168__auto____3 }
//line :182:1
	if jrt.J2g_Truth(tmp2) { var root_759 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = t.F_b__1991000100; var arg_763 any; var root_764 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_766 lang.IFn







		if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = n__2; var arg_768 any = Lit_1; var arg_769 any = Lit_7; if linked_765 == nil { arg_763 = ifn_766.Invoke_O_O_O__O(arg_767, arg_768, arg_769) } else { arg_763 = linked_765.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_764, arg_767, arg_768, arg_769) }
//line :182:1
		if linked_760 == nil { ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { linked_760.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; i__1991000099__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000099__1); continue L1 } else { i__1991000099__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000099__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A{}; t.Ctor_O(p0); return t }
//line :187:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :187:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :187:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :187:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A{}; t.Ctor_O(p0); return t }
//line :187:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :187:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :187:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_j2g_embed_with_member_types_A_New() *A_arbace_j2g_embed_with_member_types_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var fnbody__897 any = A_arbace_j2g_embed_with_member_types_types__1991000118_A_New(); var tmp1 *jrt.Class; var fncls__896 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class; if




	fncls__896 == nil { var fncls__896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class = fncls__896d; tmp1 = fncls__896d } else { tmp1 = fncls__896 }; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__897, tmp1, nil); var elem__4 any; var fnbody__899 any = /*line :192:1*/A_arbace_j2g_embed_with_member_types_elem__1991000126_A_New(); var tmp2 *jrt.Class; var fncls__898 *jrt.Class = A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class; if








	fncls__898 == nil { var fncls__898d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class = fncls__898d; tmp2 = fncls__898d } else { tmp2 = fncls__898 }; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__899, tmp2, nil); var member_types__5 any; var fnbody__1026 any = /*line :192:1*/A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_New_O_O(elem__4, types__3); var tmp3 *jrt.Class; var fncls__1025 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class; if










	fncls__1025 == nil { var fncls__1025d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1026); A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class = fncls__1025d; tmp3 = fncls__1025d } else { tmp3 = fncls__1025 }; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1026, tmp3, nil); var more__6 any; var iter__1927001039__auto____6 any; var fnbody__1145 any = /*line :192:1*/A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp4 *jrt.Class; var fncls__1144 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class; if




















	fncls__1144 == nil { var fncls__1144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__1145); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class = fncls__1144d; tmp4 = fncls__1144d } else { tmp4 = fncls__1144 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1145, tmp4, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); var root_1146 any =




	A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var root_1150 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any; var root_1154 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = cands__0; var arg_1158 any = more__6; if linked_1155 == nil { arg_1153 = ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { arg_1153 = linked_1155.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) }; if linked_1151 == nil { arg_1149 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1149 = linked_1151.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1150, arg_1153) }; if linked_1147 == nil { return ifn_1148.Invoke_O__O(arg_1149) } else { return linked_1147.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1146, arg_1149) } }
//line :197:1
func A_arbace_j2g_embed_with_member_types_types__1991000118_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_A) Ctor() {}
//line :197:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_83.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp3 *lang.Compiler_AOTFn; var fnbody__881 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_New(); var tmp4 *jrt.Class; var fncls__880 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class; if fncls__880 == nil { var fncls__880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class = fncls__880d; tmp4 = fncls__880d } else { tmp4 = fncls__880 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__881, tmp4, nil); var tmp5 any = tmp2.Invoke_O_O__O(tmp3.Ref(), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp6 any; var root_882 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_884 lang.IFn
	if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var fnbody__888 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_New(); var tmp7 *jrt.Class; var fncls__887 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class; if fncls__887 == nil { var fncls__887d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class = fncls__887d; tmp7 = fncls__887d } else { tmp7 = fncls__887 }; arg_885 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__888, tmp7, nil); var arg_886 any = jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref(); if linked_883 == nil { tmp6 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { tmp6 = linked_883.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }
//line :198:1
	var tmp8 any = tmp6; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp10 *lang.Compiler_AOTFn; var fnbody__895 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_New(); var tmp11 *jrt.Class
	var fncls__894 /*line :198:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class

	if fncls__894 == nil { var fncls__894d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class = fncls__894d; tmp11 = fncls__894d } else { tmp11 = fncls__894 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__895, tmp11, nil)
//line :198:1
	return tmp1.Invoke_O_O_O__O(tmp5, tmp8, tmp9.Invoke_O_O__O(tmp10.Ref(), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :198:1
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A) Ctor() {}
//line :198:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A) Invoke_O_O__O(self, m__1 any) any { var root_875 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(); var arg_879 any = jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref(); if linked_876 == nil { return ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { return linked_876.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) } }
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A) Ctor() {}
//line :200:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_j2g_embed_with_member_types_elem__1991000126_A_New() *A_arbace_j2g_embed_with_member_types_elem__1991000126_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_elem__1991000126_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000126_A) Ctor() {}
//line :201:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000126_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :203:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :203:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__907 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_New_O(n__1); var tmp2 *jrt.Class; var fncls__906 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class; if
														fncls__906 == nil { var fncls__906d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__907); A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class = fncls__906d; tmp2 = fncls__906d } else { tmp2 = fncls__906 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__907, tmp2, nil); temp__1927000414__auto____2 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var root_908 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_910 lang.IFn

		if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any; var root_912 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any; var root_916 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any; var iter__1927001039__auto____4 any; var fnbody__1019 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_New(); var tmp3 *jrt.Class; var fncls__1018 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class
		if fncls__1018 == nil { var fncls__1018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class = fncls__1018d; tmp3 = fncls__1018d } else { tmp3 = fncls__1018 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1019, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp5 any; var root_1020 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = t.F_elem; var arg_1024 any = lang.IFn_Cast(t.F_types).Invoke_O__O(c__3); if linked_1021 == nil { tmp5 = ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { tmp5 = linked_1021.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) }; arg_919 = tmp4.Invoke_O__O(tmp5)
//line :206:1
		if linked_917 == nil { arg_915 = ifn_918.Invoke_O__O(arg_919) } else { arg_915 = linked_917.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_916, arg_919) }; if linked_913 == nil { arg_911 = ifn_914.Invoke_O__O(arg_915) } else { arg_911 = linked_913.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_912, arg_915) }; if linked_909 == nil { return ifn_910.Invoke_O__O(arg_911) } else { return linked_909.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_908, arg_911) } } else {
//line :204:1
			return nil } }
//line :204:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A{}; t.Ctor_O(p0); return t }
//line :204:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :204:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_900 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var t_ any = t.F_n; t.F_n = nil; arg_903 = t_; var arg_904 any = Lit_7; var arg_905 any = Lit_1; if linked_901 == nil { tmp2 = ifn_902.Invoke_O_O_O__O(arg_903, arg_904, arg_905) } else { tmp2 = linked_901.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_900, arg_903, arg_904, arg_905) }; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_New() *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A) Ctor() {}
//line :207:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A) Invoke_O_O__O(self, s__1991000132__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1017 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_New_O_O(s__1991000132__1, self); var tmp2 *jrt.Class; var fncls__1016 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class; if fncls__1016 == nil { var fncls__1016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__1017); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class = fncls__1016d; tmp2 = fncls__1016d } else { tmp2 = fncls__1016 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1017, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :207:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A) Ctor_O_O(c__s__1991000132, c__iter__1991000131 any) { t.F_s__1991000132 = c__s__1991000132; t.F_iter__1991000131 = c__iter__1991000131 }
//line :207:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A) Invoke_O__O(self any) any { { var s__1991000132__1 any; var t_ any = t.F_s__1991000132; t.F_s__1991000132 = nil; s__1991000132__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_920 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = s__1991000132__1; if linked_921 == nil { temp__1927000414__auto____2 = ifn_922.Invoke_O__O(arg_923) } else { temp__1927000414__auto____2 = linked_921.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_920, arg_923) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000132__3 any = temp__1927000414__auto____2; var tmp1 any; var root_924 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = s__1991000132__3; if linked_925 == nil { tmp1 = ifn_926.Invoke_O__O(arg_927) } else { tmp1 = linked_925.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_924, arg_927) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_928 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = s__1991000132__3; if linked_929 == nil { c__1927001037__auto____4 = ifn_930.Invoke_O__O(arg_931) } else { c__1927001037__auto____4 = linked_929.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_928, arg_931) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000134__6 any; var root_932 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_933 == nil { b__1991000134__6 = ifn_934.Invoke_O__O(arg_935) } else { b__1991000134__6 = linked_933.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_932, arg_935) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__957 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000134__6); var tmp3 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__957); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class = fncls__956d; tmp3 = fncls__956d } else { tmp3 = fncls__956 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__957, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_958 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_963 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = b__1991000134__6; if linked_964 == nil { arg_961 = ifn_965.Invoke_O__O(arg_966) } else { arg_961 = linked_964.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_963, arg_966) }; var arg_962 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000131); var tmp5 any; var root_967 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = s__1991000132__3; if linked_968 == nil { tmp5 = ifn_969.Invoke_O__O(arg_970) } else { tmp5 = linked_968.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_967, arg_970) }; arg_962 = tmp4.Invoke_O__O(tmp5); if linked_959 == nil { return ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { return linked_959.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) } } else { var root_971 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var root_976 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = b__1991000134__6; if linked_977 == nil { arg_974 = ifn_978.Invoke_O__O(arg_979) } else { arg_974 = linked_977.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_976, arg_979) }; var arg_975 any; if linked_972 == nil { return ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { return linked_972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } } else { var t__4 any; var root_980 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = s__1991000132__3; if linked_981 == nil { t__4 = ifn_982.Invoke_O__O(arg_983) } else { t__4 = linked_981.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_980, arg_983) }; var tmp6 any; var root_984 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_986 lang.IFn
																		if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref(); if linked_985 == nil { tmp6 = ifn_986.Invoke_O__O(arg_987) } else { tmp6 = linked_985.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_984, arg_987) }
//line :207:1
	if jrt.J2g_Truth(tmp6) { var tn__5 any; var root_988 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_990 lang.IFn

		if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(); var arg_992 any = Lit_1; var arg_993 any = Lit_7; if linked_989 == nil { tn__5 = ifn_990.Invoke_O_O_O__O(arg_991, arg_992, arg_993) } else { tn__5 = linked_989.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_988, arg_991, arg_992, arg_993) }
//line :207:1
		var tmp7 any; var and__1927000168__auto____6 any; var root_994 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_996 lang.IFn


		if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = A_arbace_j2g_embed_A_const_94; var arg_998 any = tn__5; if linked_995 == nil { and__1927000168__auto____6 = ifn_996.Invoke_O_O__O(arg_997, arg_998) } else { and__1927000168__auto____6 = linked_995.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_994, arg_997, arg_998) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
			tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :210:1
				tmp7 = and__1927000168__auto____6 }
//line :207:1
		if jrt.J2g_Truth(tmp7) { var root_999 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = tn__5; var arg_1003 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000131); var tmp9 any; var root_1004 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = s__1991000132__3; if linked_1005 == nil { tmp9 = ifn_1006.Invoke_O__O(arg_1007) } else { tmp9 = linked_1005.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1004, arg_1007) }; arg_1003 = tmp8.Invoke_O__O(tmp9); if linked_1000 == nil { return ifn_1001.Invoke_O_O__O(arg_1002, arg_1003) } else { return linked_1000.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_999, arg_1002, arg_1003) } } else { var tmp10 any; var root_1008 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = s__1991000132__3; if linked_1009 == nil { tmp10 = ifn_1010.Invoke_O__O(arg_1011) } else { tmp10 = linked_1009.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1008, arg_1011) }; s__1991000132__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1012 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = s__1991000132__3; if linked_1013 == nil { tmp11 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp11 = linked_1013.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1012, arg_1015) }; s__1991000132__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :207:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :207:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000134 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000134 = c__b__1991000134 }
//line :207:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A) Invoke_O__O(self any) any { { var i__1991000133__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000133__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000133__1)); var tmp2 any; var root_936 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_938 lang.IFn
																				if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref(); if linked_937 == nil { tmp2 = ifn_938.Invoke_O__O(arg_939) } else { tmp2 = linked_937.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_936, arg_939) }
//line :207:1
	if jrt.J2g_Truth(tmp2) { var tn__3 any; var root_940 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_942 lang.IFn

		if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(); var arg_944 any = Lit_1; var arg_945 any = Lit_7; if linked_941 == nil { tn__3 = ifn_942.Invoke_O_O_O__O(arg_943, arg_944, arg_945) } else { tn__3 = linked_941.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_940, arg_943, arg_944, arg_945) }
//line :207:1
		var tmp3 any; var and__1927000168__auto____4 any; var root_946 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_948 lang.IFn


		if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = A_arbace_j2g_embed_A_const_94; var arg_950 any = tn__3; if linked_947 == nil { and__1927000168__auto____4 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { and__1927000168__auto____4 = linked_947.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
			tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :210:1
				tmp3 = and__1927000168__auto____4 }
//line :207:1
		if jrt.J2g_Truth(tmp3) { var root_951 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = t.F_b__1991000134; var arg_955 any = tn__3; if linked_952 == nil { ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { linked_952.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }; i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } else { i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } } else { i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A) Invoke_O_O__O(self, s__1991000143__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1143 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1991000143__1, self); var tmp2 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__1143); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class = fncls__1142d; tmp2 = fncls__1142d } else { tmp2 = fncls__1142 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1143, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :213:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1991000143, c__iter__1991000142 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1991000143 = c__s__1991000143; t.F_iter__1991000142 = c__iter__1991000142 }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A) Invoke_O__O(self any) any { { var s__1991000143__1 any; var t_ any = t.F_s__1991000143; t.F_s__1991000143 = nil; s__1991000143__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1027 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = s__1991000143__1; if linked_1028 == nil { temp__1927000414__auto____2 = ifn_1029.Invoke_O__O(arg_1030) } else { temp__1927000414__auto____2 = linked_1028.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1027, arg_1030) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1031 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = xs__1927001018__auto____3; if linked_1032 == nil { n__4 = ifn_1033.Invoke_O__O(arg_1034) } else { n__4 = linked_1032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1031, arg_1034) }; var tmp1 any; var root_1035 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1037 lang.IFn
															if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4); if linked_1036 == nil { tmp1 = ifn_1037.Invoke_O__O(arg_1038) } else { tmp1 = linked_1036.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1035, arg_1038) }
//line :213:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1112 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_New_O(t.F_in_world_QMARK_); var tmp2 *jrt.Class; var fncls__1111 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class; if fncls__1111 == nil { var fncls__1111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__1112); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class = fncls__1111d; tmp2 = fncls__1111d } else { tmp2 = fncls__1111 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1112, tmp2, nil); var fs__1927001036__auto____6 any; var root_1113 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1117 any = A_arbace_j2g_embed_A_const_95.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A_fn_class); var ifn_1119 lang.IFn

		if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = A_arbace_j2g_embed_A_const_96; var arg_1121 any = n__4; var arg_1122 any; var fnbody__1124 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_New_O_O(n__4, t.F_member_types); var tmp5 *jrt.Class; var fncls__1123 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class; if fncls__1123 == nil { var fncls__1123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__1124); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class = fncls__1123d; tmp5 = fncls__1123d } else { tmp5 = fncls__1123 }; arg_1122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1124, tmp5, nil); if linked_1118 == nil { tmp4 = ifn_1119.Invoke_O_O_O__O(arg_1120, arg_1121, arg_1122) } else { tmp4 = linked_1118.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A).Invoke_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122) }
//line :213:1
		arg_1116 = tmp3.Invoke_O__O(tmp4); if linked_1114 == nil { fs__1927001036__auto____6 = ifn_1115.Invoke_O__O(arg_1116) } else { fs__1927001036__auto____6 = linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1125 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = fs__1927001036__auto____6; var arg_1129 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000142); var tmp7 any; var root_1130 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = s__1991000143__1; if linked_1131 == nil { tmp7 = ifn_1132.Invoke_O__O(arg_1133) } else { tmp7 = linked_1131.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1130, arg_1133) }; arg_1129 = tmp6.Invoke_O__O(tmp7); if linked_1126 == nil { return ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { return linked_1126.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) } } else { var tmp8 any; var root_1134 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = s__1991000143__1; if linked_1135 == nil { tmp8 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp8 = linked_1135.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1134, arg_1137) }; s__1991000143__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1138 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = s__1991000143__1; if linked_1139 == nil { tmp9 = ifn_1140.Invoke_O__O(arg_1141) } else { tmp9 = linked_1139.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1138, arg_1141) }; s__1991000143__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :213:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A{}; t.Ctor_O(p0); return t }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A) Invoke_O_O__O(self, s__1991000145__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1110 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_New_O_O_O(t.F_in_world_QMARK_, s__1991000145__1, self); var tmp2 *jrt.Class; var fncls__1109 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class; if fncls__1109 == nil { var fncls__1109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__1110); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class = fncls__1109d; tmp2 = fncls__1109d } else { tmp2 = fncls__1109 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1110, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :213:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1991000145, c__iter__1991000144 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1991000145 = c__s__1991000145; t.F_iter__1991000144 = c__iter__1991000144 }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A) Invoke_O__O(self any) any { { var s__1991000145__1 any; var t_ any = t.F_s__1991000145; t.F_s__1991000145 = nil; s__1991000145__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1039 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = s__1991000145__1; if linked_1040 == nil { temp__1927000414__auto____2 = ifn_1041.Invoke_O__O(arg_1042) } else { temp__1927000414__auto____2 = linked_1040.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1039, arg_1042) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000145__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1043 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = s__1991000145__3; if linked_1044 == nil { tmp1 = ifn_1045.Invoke_O__O(arg_1046) } else { tmp1 = linked_1044.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1043, arg_1046) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1047 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = s__1991000145__3; if linked_1048 == nil { c__1927001037__auto____4 = ifn_1049.Invoke_O__O(arg_1050) } else { c__1927001037__auto____4 = linked_1048.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1047, arg_1050) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000147__6 any; var root_1051 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1052 == nil { b__1991000147__6 = ifn_1053.Invoke_O__O(arg_1054) } else { b__1991000147__6 = linked_1052.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1051, arg_1054) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1065 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_New_O_O_I_O(b__1991000147__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1064 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class; if fncls__1064 == nil { var fncls__1064d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__1065); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class = fncls__1064d; tmp3 = fncls__1064d } else { tmp3 = fncls__1064 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1065, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1066 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any; var root_1071 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = b__1991000147__6; if linked_1072 == nil { arg_1069 = ifn_1073.Invoke_O__O(arg_1074) } else { arg_1069 = linked_1072.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1071, arg_1074) }; var arg_1070 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000144); var tmp5 any; var root_1075 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = s__1991000145__3; if linked_1076 == nil { tmp5 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp5 = linked_1076.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1075, arg_1078) }; arg_1070 = tmp4.Invoke_O__O(tmp5); if linked_1067 == nil { return ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { return linked_1067.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) } } else { var root_1079 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var root_1084 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = b__1991000147__6; if linked_1085 == nil { arg_1082 = ifn_1086.Invoke_O__O(arg_1087) } else { arg_1082 = linked_1085.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1084, arg_1087) }; var arg_1083 any; if linked_1080 == nil { return ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { return linked_1080.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) } } } else { var tn__4 any; var root_1088 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = s__1991000145__3; if linked_1089 == nil { tn__4 = ifn_1090.Invoke_O__O(arg_1091) } else { tn__4 = linked_1089.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1088, arg_1091) }; var tmp6 any; var root_1092 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1094 lang.IFn


	if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4); if linked_1093 == nil { tmp6 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp6 = linked_1093.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1092, arg_1095) }
//line :213:1
	if jrt.J2g_Truth(tmp6) { var root_1096 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = tn__4; var arg_1100 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000144); var tmp8 any; var root_1101 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = s__1991000145__3; if linked_1102 == nil { tmp8 = ifn_1103.Invoke_O__O(arg_1104) } else { tmp8 = linked_1102.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1101, arg_1104) }; arg_1100 = tmp7.Invoke_O__O(tmp8); if linked_1097 == nil { return ifn_1098.Invoke_O_O__O(arg_1099, arg_1100) } else { return linked_1097.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1096, arg_1099, arg_1100) } } else { var tmp9 any; var root_1105 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = s__1991000145__3; if linked_1106 == nil { tmp9 = ifn_1107.Invoke_O__O(arg_1108) } else { tmp9 = linked_1106.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1105, arg_1108) }; s__1991000145__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :213:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A) Ctor_O_O_I_O(c__b__1991000147, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000147 = c__b__1991000147; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :213:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A) Invoke_O__O(self any) any { { var i__1991000146__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000146__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000146__1)); var tmp2 any; var root_1055 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1057 lang.IFn


	if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2); if linked_1056 == nil { tmp2 = ifn_1057.Invoke_O__O(arg_1058) } else { tmp2 = linked_1056.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1055, arg_1058) }
//line :213:1
	if jrt.J2g_Truth(tmp2) { var root_1059 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = t.F_b__1991000147; var arg_1063 any = tn__2; if linked_1060 == nil { ifn_1061.Invoke_O_O__O(arg_1062, arg_1063) } else { linked_1060.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1059, arg_1062, arg_1063) }; i__1991000146__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000146__1); continue L1 } else { i__1991000146__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000146__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :215:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :215:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_j2g_embed_data_A_New() *A_arbace_j2g_embed_data_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_j2g_embed_data_A) Ctor() {}
//line :223:1
func (t *A_arbace_j2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any; var root_1159 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1159, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1161 lang.IFn; if




	linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = dir__0; if linked_1160 == nil { base__2 = ifn_1161.Invoke_O__O(arg_1162) } else { base__2 = linked_1160.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1159, arg_1162) }; var root_1163 any =
	A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_1167 any; if
	jrt.File_Cast(base__2).IsDirectory__Z() { var iter__1927001039__auto____3 any; var fnbody__1256 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_New_O(base__2); var tmp1 *jrt.Class; var fncls__1255 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class
		if fncls__1255 == nil { var fncls__1255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__1256); A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class = fncls__1255d; tmp1 = fncls__1255d } else { tmp1 = fncls__1255 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1256, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_1257 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = base__2; if linked_1258 == nil { tmp3 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp3 = linked_1258.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1257, arg_1260) }; arg_1167 = tmp2.Invoke_O__O(tmp3) } else {
//line :230:1
			arg_1167 = nil }; if /*line :229:1*/ linked_1164 == nil { return ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { return linked_1164.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) } }

func A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_New_O(p0 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :231:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A) Invoke_O_O__O(self, s__1991000162__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1254 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_New_O_O_O(s__1991000162__1, t.F_base, self); var tmp2 *jrt.Class; var fncls__1253 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class; if fncls__1253 == nil { var fncls__1253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__1254); A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class = fncls__1253d; tmp2 = fncls__1253d } else { tmp2 = fncls__1253 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1254, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :231:1
func A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :231:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A) Ctor_O_O_O(c__s__1991000162, c__base, c__iter__1991000161 any) { t.F_s__1991000162 = c__s__1991000162; t.F_base = c__base; t.F_iter__1991000161 = c__iter__1991000161 }
//line :231:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A) Invoke_O__O(self any) any { { var s__1991000162__1 any; var t_ any = t.F_s__1991000162; t.F_s__1991000162 = nil; s__1991000162__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1171 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = s__1991000162__1; if linked_1172 == nil { temp__1927000414__auto____2 = ifn_1173.Invoke_O__O(arg_1174) } else { temp__1927000414__auto____2 = linked_1172.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1171, arg_1174) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000162__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1175 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = s__1991000162__3; if linked_1176 == nil { tmp1 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp1 = linked_1176.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1175, arg_1178) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1179 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = s__1991000162__3; if linked_1180 == nil { c__1927001037__auto____4 = ifn_1181.Invoke_O__O(arg_1182) } else { c__1927001037__auto____4 = linked_1180.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1179, arg_1182) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000164__6 any; var root_1183 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1184 == nil { b__1991000164__6 = ifn_1185.Invoke_O__O(arg_1186) } else { b__1991000164__6 = linked_1184.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1183, arg_1186) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1203 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_New_O_O_I_O(t.F_base, b__1991000164__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1202 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class; if fncls__1202 == nil { var fncls__1202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__1203); A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class = fncls__1202d; tmp3 = fncls__1202d } else { tmp3 = fncls__1202 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1203, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1204 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any; var root_1209 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = b__1991000164__6; if linked_1210 == nil { arg_1207 = ifn_1211.Invoke_O__O(arg_1212) } else { arg_1207 = linked_1210.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1209, arg_1212) }; var arg_1208 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000161); var tmp5 any; var root_1213 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = s__1991000162__3; if linked_1214 == nil { tmp5 = ifn_1215.Invoke_O__O(arg_1216) } else { tmp5 = linked_1214.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1213, arg_1216) }; arg_1208 = tmp4.Invoke_O__O(tmp5); if linked_1205 == nil { return ifn_1206.Invoke_O_O__O(arg_1207, arg_1208) } else { return linked_1205.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1204, arg_1207, arg_1208) } } else { var root_1217 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any; var root_1222 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = b__1991000164__6; if linked_1223 == nil { arg_1220 = ifn_1224.Invoke_O__O(arg_1225) } else { arg_1220 = linked_1223.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1222, arg_1225) }; var arg_1221 any; if linked_1218 == nil { return ifn_1219.Invoke_O_O__O(arg_1220, arg_1221) } else { return linked_1218.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1217, arg_1220, arg_1221) } } } else { var f__4 any; var root_1226 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = s__1991000162__3; if linked_1227 == nil { f__4 = ifn_1228.Invoke_O__O(arg_1229) } else { f__4 = linked_1227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1226, arg_1229) }; if jrt.File_Cast(f__4).IsFile__Z() { var root_1230 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any; var tmp6 any; var root_1235 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1237 lang.IFn

	if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any; var root_1241 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_1242 == nil { arg_1238 = ifn_1243.Invoke_O__O(arg_1244) } else { arg_1238 = linked_1242.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1241, arg_1244) }; var arg_1239 any = jrt.File_separator.Ref(); var arg_1240 any = Lit_7; if linked_1236 == nil { tmp6 = ifn_1237.Invoke_O_O_O__O(arg_1238, arg_1239, arg_1240) } else { tmp6 = linked_1236.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1235, arg_1238, arg_1239, arg_1240) }
//line :231:1
	arg_1233 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, f__4); var arg_1234 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000161); var tmp8 any; var root_1245 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = s__1991000162__3; if linked_1246 == nil { tmp8 = ifn_1247.Invoke_O__O(arg_1248) } else { tmp8 = linked_1246.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1245, arg_1248) }; arg_1234 = tmp7.Invoke_O__O(tmp8); if linked_1231 == nil { return ifn_1232.Invoke_O_O__O(arg_1233, arg_1234) } else { return linked_1231.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1230, arg_1233, arg_1234) } } else { var tmp9 any; var root_1249 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = s__1991000162__3; if linked_1250 == nil { tmp9 = ifn_1251.Invoke_O__O(arg_1252) } else { tmp9 = linked_1250.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1249, arg_1252) }; s__1991000162__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :231:1
func A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :231:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A) Ctor_O_O_I_O(c__base, c__b__1991000164 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_base = c__base; t.F_b__1991000164 = c__b__1991000164; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :231:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A) Invoke_O__O(self any) any { { var i__1991000163__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000163__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000163__1)); if jrt.File_Cast(f__2).IsFile__Z() { var root_1187 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = t.F_b__1991000164; var arg_1191 any; var tmp2 any; var root_1192 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1194 lang.IFn

	if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any; var root_1198 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_1199 == nil { arg_1195 = ifn_1200.Invoke_O__O(arg_1201) } else { arg_1195 = linked_1199.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1198, arg_1201) }; var arg_1196 any = jrt.File_separator.Ref(); var arg_1197 any = Lit_7; if linked_1193 == nil { tmp2 = ifn_1194.Invoke_O_O_O__O(arg_1195, arg_1196, arg_1197) } else { tmp2 = linked_1193.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1192, arg_1195, arg_1196, arg_1197) }
//line :231:1
	arg_1191 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, f__2); if linked_1188 == nil { ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { linked_1188.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; i__1991000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000163__1); continue L1 } else { i__1991000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000163__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_generated_A_New() *A_arbace_j2g_embed_generated_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_generated_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_j2g_embed_generated_A) Ctor() {}
//line :235:1
func (t *A_arbace_j2g_embed_generated_A) Invoke_O_O__O(self, root__0 any) any {







	var root_1261 any = A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_1265 any; var tmp1 any; var root_1269 any = A_arbace_j2g_embed_A_const_97.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = A_arbace_j2g_embed_A_const_98; if linked_1270 == nil { tmp1 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp1 = linked_1270.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_1269, arg_1272) }; arg_1265 = lang.IFn_Cast(tmp1).Invoke_O__O(root__0); if linked_1262 == nil { return ifn_1263.Invoke_O_O__O(arg_1264, arg_1265) } else { return linked_1262.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1261, arg_1264, arg_1265)
	} }
func A_arbace_j2g_embed_user_resources_A_New() *A_arbace_j2g_embed_user_resources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_j2g_embed_user_resources_A) Ctor() {}
//line :245:1
func (t *A_arbace_j2g_embed_user_resources_A) Invoke_O_O_O__O(self, specs__0, taken__1 any) any { { var G__1991000176__3_ any = specs__0; var vec__1991000177__4 any = G__1991000176__3_; var seq__1991000178__5 any; var root_1273 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1275 lang.IFn












	if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = vec__1991000177__4; if linked_1274 == nil { seq__1991000178__5 = ifn_1275.Invoke_O__O(arg_1276) } else { seq__1991000178__5 = linked_1274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1273, arg_1276) }
//line :245:1
	var first__1991000179__6 any; var root_1277 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1279 lang.IFn












	if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = seq__1991000178__5; if linked_1278 == nil { first__1991000179__6 = ifn_1279.Invoke_O__O(arg_1280) } else { first__1991000179__6 = linked_1278.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1277, arg_1280) }
//line :245:1
	var seq__1991000178__7 any; var root_1281 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1283 lang.IFn












	if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = seq__1991000178__5; if linked_1282 == nil { seq__1991000178__7 = ifn_1283.Invoke_O__O(arg_1284) } else { seq__1991000178__7 = linked_1282.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1281, arg_1284) }
//line :245:1
	var spec__8 any = first__1991000179__6; var more__9 any = seq__1991000178__7; var k__10 int64 = 0; var srcs__11 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var data__12 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var plain__13 any = lang.PersistentHashSet_EMPTY.Ref(); var owners__14 any = lang.PersistentVector_EMPTY.Ref(); var G__1991000176__15_ any = G__1991000176__3_; var k__16 int64 = k__10; var srcs__17 any = srcs__11; var data__18 any = data__12; var plain__19 any = plain__13; var owners__20 any = owners__14; _ = spec__8; _ = more__9; L1: for { var vec__1991000180__21 any = G__1991000176__15_; var seq__1991000181__22 any; var root_1291 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1293 lang.IFn












		if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = vec__1991000180__21; if linked_1292 == nil { seq__1991000181__22 = ifn_1293.Invoke_O__O(arg_1294) } else { seq__1991000181__22 = linked_1292.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1291, arg_1294) }
//line :245:1
		var first__1991000182__23 any; var root_1295 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1297 lang.IFn












		if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = seq__1991000181__22; if linked_1296 == nil { first__1991000182__23 = ifn_1297.Invoke_O__O(arg_1298) } else { first__1991000182__23 = linked_1296.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1295, arg_1298) }
//line :245:1
		var seq__1991000181__24 any; var root_1299 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1301 lang.IFn












		if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = seq__1991000181__22; if linked_1300 == nil { seq__1991000181__24 = ifn_1301.Invoke_O__O(arg_1302) } else { seq__1991000181__24 = linked_1300.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1299, arg_1302) }
//line :245:1
		var spec__25 any = first__1991000182__23
		var more__26 any = seq__1991000181__24
		var k__27 int64 = k__16
		var srcs__28 any = srcs__17
		var data__29 any = data__18
		var plain__30 any = plain__19
		var owners__31 any = owners__20







		if lang.Util_Identical_O_O__Z_NoInit(spec__25, nil) { return lang.Tuple_Create_O_O_O__IPersistentVector(srcs__28, data__29, owners__31) } else { var i__32 int32 = jrt.NN(jrt.String_Cast(spec__25)).LastIndexOf_String__I(Lit_48); var vec__1991000183__33 any


			if lang.Numbers_IsPos_J__Z_NoInit(int64(i__32)) { var tmp1 any; var root_1499 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = spec__25; var arg_1503 any = A_arbace_j2g_embed_A_const_34; var arg_1504 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__32).Ref(); if linked_1500 == nil { tmp1 = ifn_1501.Invoke_O_O_O__O(arg_1502, arg_1503, arg_1504) } else { tmp1 = linked_1500.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1499, arg_1502, arg_1503, arg_1504) }; var tmp2 any = tmp1; var tmp3 any; var root_1505 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = spec__25; var arg_1509 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__32))).Ref(); if linked_1506 == nil { tmp3 = ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { tmp3 = linked_1506.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) }; vec__1991000183__33 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) } else { vec__1991000183__33 = lang.Tuple_Create_O_O__IPersistentVector(spec__25, nil) }
//line :259:1
			var dir__34 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000183__33, lang.RT_IntCast_J__I_NoInit(0), nil); var prefix__35 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000183__33, lang.RT_IntCast_J__I_NoInit(1), nil); var base__36 any; var root_1303 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1303, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1305 lang.IFn



			if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = dir__34; if linked_1304 == nil { base__36 = ifn_1305.Invoke_O__O(arg_1306) } else { base__36 = linked_1304.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1303, arg_1306) }
//line :259:1
			var ___37 any; _ = ___37




			if jrt.File_Cast(base__36).IsDirectory__Z() { ___37 = nil } else { var tmp4 any; var root_1307 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1309 lang.IFn
				if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, spec__25, nil, dir__34)).Ref(); var arg_1311 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1308 == nil { tmp4 = ifn_1309.Invoke_O_O__O(arg_1310, arg_1311) } else { tmp4 = linked_1308.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1307, arg_1310, arg_1311) }
//line :264:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
//line :259:1
			var files__38 any; var iter__1927001039__auto____38 any; var fnbody__1423 any = A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A_New_O_O(base__36, prefix__35); var tmp5 *jrt.Class
			var fncls__1422 /*line :259:1*/*jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A_fn_class






			if fncls__1422 == nil { var fncls__1422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__1423); A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A_fn_class = fncls__1422d; tmp5 = fncls__1422d } else { tmp5 = fncls__1422 }; iter__1927001039__auto____38 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1423, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____38); var tmp7 any; var root_1510 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any; var root_1514 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = base__36; if linked_1515 == nil { arg_1513 = ifn_1516.Invoke_O__O(arg_1517) } else { arg_1513 = linked_1515.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1514, arg_1517) }; if linked_1511 == nil { tmp7 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp7 = linked_1511.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1510, arg_1513) }; files__38 = tmp6.Invoke_O__O(tmp7)
//line :259:1
			var vec__1991000186__39 any; var root_1424 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1426 lang.IFn










			if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any; var fnbody__1498 any = A_arbace_j2g_embed_user_resources_fn__1991000201_A_New_O_O_O_J(spec__25, taken__1, plain__30, k__27); var tmp8 *jrt.Class; var fncls__1497 *jrt.Class = A_arbace_j2g_embed_user_resources_fn__1991000201_A_fn_class; if fncls__1497 == nil { var fncls__1497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__1498); A_arbace_j2g_embed_user_resources_fn__1991000201_A_fn_class = fncls__1497d; tmp8 = fncls__1497d } else { tmp8 = fncls__1497 }; arg_1427 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1498, tmp8, nil); var arg_1428 any = lang.Tuple_Create_O_O_O__IPersistentVector(srcs__28, data__29, plain__30); var arg_1429 any = files__38; if linked_1425 == nil { vec__1991000186__39 = ifn_1426.Invoke_O_O_O__O(arg_1427, arg_1428, arg_1429) } else { vec__1991000186__39 = linked_1425.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1424, arg_1427, arg_1428, arg_1429) }
//line :259:1
			var srcs__40 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000186__39, lang.RT_IntCast_J__I_NoInit(0), nil); var data__41 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000186__39, lang.RT_IntCast_J__I_NoInit(1), nil); var plain_SINGLEQUOTE___42 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000186__39, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp9 int64 = lang.Numbers_Inc_J__J_NoInit(k__27); var tmp10 any; var root_1518 any = A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1520 lang.IFn
























			if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = owners__31; var arg_1522 any; var iter__1927001039__auto____43 any; var fnbody__1584 any = A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A_New_J(k__27); var tmp11 *jrt.Class; var fncls__1583 *jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A_fn_class; if fncls__1583 == nil { var fncls__1583d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__1584); A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A_fn_class = fncls__1583d; tmp11 = fncls__1583d } else { tmp11 = fncls__1583 }; iter__1927001039__auto____43 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1584, tmp11, nil); var tmp12 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____43); var tmp13 any; var root_1585 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any; var root_1589 any = A_arbace_j2g_embed_A_const_100.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = plain__30; var arg_1593 any = plain_SINGLEQUOTE___42; if linked_1590 == nil { arg_1588 = ifn_1591.Invoke_O_O__O(arg_1592, arg_1593) } else { arg_1588 = linked_1590.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1589, arg_1592, arg_1593) }; if linked_1586 == nil { tmp13 = ifn_1587.Invoke_O__O(arg_1588) } else { tmp13 = linked_1586.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1585, arg_1588) }; arg_1522 = tmp12.Invoke_O__O(tmp13); if linked_1519 == nil { tmp10 = ifn_1520.Invoke_O_O__O(arg_1521, arg_1522) } else { tmp10 = linked_1519.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1518, arg_1521, arg_1522) }
//line :283:1
			G__1991000176__15_, k__16, srcs__17, data__18, plain__19, owners__20 = more__26, tmp9, srcs__40, data__41, plain_SINGLEQUOTE___42, tmp10; continue L1 } } }; /*line :245:1*/panic("j2g: unreachable") }




















func A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :266:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A) Ctor_O_O(c__base, c__prefix any) { t.F_base = c__base; t.F_prefix = c__prefix }
//line :266:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A) Invoke_O_O__O(self, s__1991000190__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1421 any = A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A_New_O_O_O_O(s__1991000190__1, t.F_base, t.F_prefix, self); var tmp2 *jrt.Class; var fncls__1420 *jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A_fn_class; if fncls__1420 == nil { var fncls__1420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1421); A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A_fn_class = fncls__1420d; tmp2 = fncls__1420d } else { tmp2 = fncls__1420 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1421, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :266:1
func A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :266:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A) Ctor_O_O_O_O(c__s__1991000190, c__base, c__prefix, c__iter__1991000189 any) { t.F_s__1991000190 = c__s__1991000190; t.F_base = c__base; t.F_prefix = c__prefix; t.F_iter__1991000189 = c__iter__1991000189 }
//line :266:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A) Invoke_O__O(self any) any { { var s__1991000190__1 any; var t_ any = t.F_s__1991000190; t.F_s__1991000190 = nil; s__1991000190__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1312 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = s__1991000190__1; if linked_1313 == nil { temp__1927000414__auto____2 = ifn_1314.Invoke_O__O(arg_1315) } else { temp__1927000414__auto____2 = linked_1313.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1312, arg_1315) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000190__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1316 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = s__1991000190__3; if linked_1317 == nil { tmp1 = ifn_1318.Invoke_O__O(arg_1319) } else { tmp1 = linked_1317.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1316, arg_1319) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1320 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = s__1991000190__3; if linked_1321 == nil { c__1927001037__auto____4 = ifn_1322.Invoke_O__O(arg_1323) } else { c__1927001037__auto____4 = linked_1321.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1320, arg_1323) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000192__6 any; var root_1324 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1325 == nil { b__1991000192__6 = ifn_1326.Invoke_O__O(arg_1327) } else { b__1991000192__6 = linked_1325.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1324, arg_1327) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1357 any = A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A_New_O_O_O_I_O(t.F_base, t.F_prefix, b__1991000192__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1356 *jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A_fn_class; if fncls__1356 == nil { var fncls__1356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__1357); A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A_fn_class = fncls__1356d; tmp3 = fncls__1356d } else { tmp3 = fncls__1356 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1357, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1358 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any; var root_1363 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = b__1991000192__6; if linked_1364 == nil { arg_1361 = ifn_1365.Invoke_O__O(arg_1366) } else { arg_1361 = linked_1364.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1363, arg_1366) }; var arg_1362 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000189); var tmp5 any; var root_1367 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = s__1991000190__3; if linked_1368 == nil { tmp5 = ifn_1369.Invoke_O__O(arg_1370) } else { tmp5 = linked_1368.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1367, arg_1370) }; arg_1362 = tmp4.Invoke_O__O(tmp5); if linked_1359 == nil { return ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { return linked_1359.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) } } else { var root_1371 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any; var root_1376 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = b__1991000192__6; if linked_1377 == nil { arg_1374 = ifn_1378.Invoke_O__O(arg_1379) } else { arg_1374 = linked_1377.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1376, arg_1379) }; var arg_1375 any; if linked_1372 == nil { return ifn_1373.Invoke_O_O__O(arg_1374, arg_1375) } else { return linked_1372.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1371, arg_1374, arg_1375) } } } else { var f__4 any; var root_1380 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = s__1991000190__3; if linked_1381 == nil { f__4 = ifn_1382.Invoke_O__O(arg_1383) } else { f__4 = linked_1381.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1380, arg_1383) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()
															if and__1927000168__auto____5 { var root_1384 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any; var root_1388 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1392 any = Lit_1; if linked_1389 == nil { arg_1387 = ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { arg_1387 = linked_1389.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) }; if linked_1385 == nil { tmp6 = ifn_1386.Invoke_O__O(arg_1387) } else { tmp6 = linked_1385.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1384, arg_1387) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :266:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var root_1393 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1395 lang.IFn

		if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any; var root_1399 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_1400 == nil { arg_1396 = ifn_1401.Invoke_O__O(arg_1402) } else { arg_1396 = linked_1400.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1399, arg_1402) }; var arg_1397 any = jrt.File_separator.Ref(); var arg_1398 any = Lit_7; if linked_1394 == nil { rel__5 = ifn_1395.Invoke_O_O_O__O(arg_1396, arg_1397, arg_1398) } else { rel__5 = linked_1394.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1393, arg_1396, arg_1397, arg_1398) }
//line :266:1
		var root_1403 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any; var tmp7 any; var tmp8 any; var root_1408 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1410 lang.IFn


		if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = t.F_prefix; if linked_1409 == nil { tmp8 = ifn_1410.Invoke_O__O(arg_1411) } else { tmp8 = linked_1409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1408, arg_1411) }; if jrt.J2g_Truth(tmp8) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, nil, rel__5)).Ref() } else { tmp7 = rel__5 }
//line :266:1
		arg_1406 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, f__4); var arg_1407 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1991000189); var tmp10 any; var root_1412 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = s__1991000190__3; if linked_1413 == nil { tmp10 = ifn_1414.Invoke_O__O(arg_1415) } else { tmp10 = linked_1413.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1412, arg_1415) }; arg_1407 = tmp9.Invoke_O__O(tmp10); if linked_1404 == nil { return ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { return linked_1404.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) } } else { var tmp11 any; var root_1416 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = s__1991000190__3; if linked_1417 == nil { tmp11 = ifn_1418.Invoke_O__O(arg_1419) } else { tmp11 = linked_1417.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1416, arg_1419) }; s__1991000190__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :266:1
func A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :266:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A) Ctor_O_O_O_I_O(c__base, c__prefix, c__b__1991000192 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_base = c__base; t.F_prefix = c__prefix; t.F_b__1991000192 = c__b__1991000192; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :266:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A) Invoke_O__O(self any) any { { var i__1991000191__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000191__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()
																	if and__1927000168__auto____3 { var root_1328 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any; var root_1332 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1336 any = Lit_1; if linked_1333 == nil { arg_1331 = ifn_1334.Invoke_O_O__O(arg_1335, arg_1336) } else { arg_1331 = linked_1333.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1332, arg_1335, arg_1336) }; if linked_1329 == nil { tmp2 = ifn_1330.Invoke_O__O(arg_1331) } else { tmp2 = linked_1329.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1328, arg_1331) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :266:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var root_1337 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1339 lang.IFn

		if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any; var root_1343 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_1344 == nil { arg_1340 = ifn_1345.Invoke_O__O(arg_1346) } else { arg_1340 = linked_1344.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1343, arg_1346) }; var arg_1341 any = jrt.File_separator.Ref(); var arg_1342 any = Lit_7; if linked_1338 == nil { rel__3 = ifn_1339.Invoke_O_O_O__O(arg_1340, arg_1341, arg_1342) } else { rel__3 = linked_1338.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1337, arg_1340, arg_1341, arg_1342) }
//line :266:1
		var root_1347 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = t.F_b__1991000192; var arg_1351 any; var tmp3 any; var tmp4 any; var root_1352 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1354 lang.IFn


		if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = t.F_prefix; if linked_1353 == nil { tmp4 = ifn_1354.Invoke_O__O(arg_1355) } else { tmp4 = linked_1353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1352, arg_1355) }; if jrt.J2g_Truth(tmp4) { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, nil, rel__3)).Ref() } else { tmp3 = rel__3 }
//line :266:1
		arg_1351 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, f__2); if linked_1348 == nil { ifn_1349.Invoke_O_O__O(arg_1350, arg_1351) } else { linked_1348.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1347, arg_1350, arg_1351) }; i__1991000191__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000191__1); continue L1 } else { i__1991000191__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000191__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_user_resources_fn__1991000201_A_New_O_O_O_J(p0, p1, p2 any, p3 int64) *A_arbace_j2g_embed_user_resources_fn__1991000201_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_fn__1991000201_A{}; t.Ctor_O_O_O_J(p0, p1, p2, p3); return t }
//line :270:1
func (t *A_arbace_j2g_embed_user_resources_fn__1991000201_A) Ctor_O_O_O_J(c__spec, c__taken, c__plain any, c__k int64) { t.F_spec = c__spec; t.F_taken = c__taken; t.F_plain = c__plain; t.F_k = c__k }
//line :270:1
func (t *A_arbace_j2g_embed_user_resources_fn__1991000201_A) Invoke_O_O_O__O(self, p__1991000199__1, p__1991000200__2 any) any { var vec__1991000202__3 any = p__1991000199__1; var srcs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000202__3, lang.RT_IntCast_J__I_NoInit(0), nil); var data__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000202__3, lang.RT_IntCast_J__I_NoInit(1), nil); var plain_SINGLEQUOTE___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000202__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__1991000205__7 any = p__1991000200__2; var p__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000205__7, lang.RT_IntCast_J__I_NoInit(0), nil); var f__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000205__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____10 any; var root_1450 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1452 lang.IFn; if
																linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = t.F_taken; var arg_1454 any = p__8; if linked_1451 == nil { or__1927000174__auto____10 = ifn_1452.Invoke_O_O__O(arg_1453, arg_1454) } else { or__1927000174__auto____10 = linked_1451.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1450, arg_1453, arg_1454) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var root_1455 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = srcs__4; var arg_1459 any = p__8; if linked_1456 == nil { tmp1 = ifn_1457.Invoke_O_O__O(arg_1458, arg_1459) } else { tmp1 = linked_1456.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1455, arg_1458, arg_1459) } }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1460 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1462 lang.IFn
																	if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_60, nil, Lit_75), jrt.RefArrayOf(jrt.Object_class, nil, t.F_spec, nil, p__8, nil)).Ref(); var arg_1464 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1461 == nil { tmp2 = ifn_1462.Invoke_O_O__O(arg_1463, arg_1464) } else { tmp2 = linked_1461.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1460, arg_1463, arg_1464) }
//line :271:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp3 any; var root_1430 any =

	A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1432 lang.IFn; if
	linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = A_arbace_j2g_embed_A_const_99; var arg_1434 any = p__8; if linked_1431 == nil { tmp3 = ifn_1432.Invoke_O_O__O(arg_1433, arg_1434) } else { tmp3 = linked_1431.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1430, arg_1433, arg_1434) }; if /*line :273:1*/ jrt.J2g_Truth(tmp3) {

		var tmp4 any; var root_1435 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = t.F_plain; var arg_1439 any = p__8; if linked_1436 == nil { tmp4 = ifn_1437.Invoke_O_O__O(arg_1438, arg_1439) } else { tmp4 = linked_1436.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1435, arg_1438, arg_1439) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1440 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1442 lang.IFn
			if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_60, nil, Lit_75), jrt.RefArrayOf(jrt.Object_class, nil, t.F_spec, nil, p__8, nil)).Ref(); var arg_1444 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1441 == nil { tmp5 = ifn_1442.Invoke_O_O__O(arg_1443, arg_1444) } else { tmp5 = linked_1441.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1440, arg_1443, arg_1444) }
//line :275:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5))) } else { var tmp6 any; var root_1465 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1467 lang.IFn

				if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = srcs__4; var arg_1469 any = p__8; var arg_1470 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__9); if linked_1466 == nil { tmp6 = ifn_1467.Invoke_O_O_O__O(arg_1468, arg_1469, arg_1470) } else { tmp6 = linked_1466.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1465, arg_1468, arg_1469, arg_1470) }
//line :275:1
				var tmp7 any = tmp6; var tmp8 any; var root_1475 any = A_arbace_j2g_embed_A_const_10.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1477 lang.IFn

				if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = plain_SINGLEQUOTE___6; var arg_1479 any = p__8; if linked_1476 == nil { tmp8 = ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { tmp8 = linked_1476.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) }
//line :275:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, data__5, tmp8) } } else {
//line :273:1
					var tmp9 any; var root_1445 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1447 lang.IFn





					if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = t.F_plain; var arg_1449 any = p__8; if linked_1446 == nil { tmp9 = ifn_1447.Invoke_O_O__O(arg_1448, arg_1449) } else { tmp9 = linked_1446.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1445, arg_1448, arg_1449) }
//line :273:1
					if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_1480 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1482 lang.IFn





						if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = data__5; var arg_1484 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_76, nil, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(t.F_k).Ref(), nil, p__8)).Ref(); var arg_1485 any = f__9; if linked_1481 == nil { tmp10 = ifn_1482.Invoke_O_O_O__O(arg_1483, arg_1484, arg_1485) } else { tmp10 = linked_1481.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1480, arg_1483, arg_1484, arg_1485) }
//line :273:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(srcs__4, tmp10, plain_SINGLEQUOTE___6) } else { if A_arbace_j2g_embed_A_const_42 != nil { var tmp11 any; var root_1486 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1488 lang.IFn






							if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = data__5; var arg_1490 any = p__8; var arg_1491 any = f__9; if linked_1487 == nil { tmp11 = ifn_1488.Invoke_O_O_O__O(arg_1489, arg_1490, arg_1491) } else { tmp11 = linked_1487.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1486, arg_1489, arg_1490, arg_1491) }
//line :273:1
							var tmp12 any = tmp11; var tmp13 any; var root_1492 any = A_arbace_j2g_embed_A_const_10.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1494 lang.IFn






							if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = plain_SINGLEQUOTE___6; var arg_1496 any = p__8; if linked_1493 == nil { tmp13 = ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { tmp13 = linked_1493.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) }
//line :273:1
							return lang.Tuple_Create_O_O_O__IPersistentVector(srcs__4, tmp12, tmp13) } else { return nil } } } }










func A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A_New_J(p0 int64) *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A{}; t.Ctor_J(p0); return t }
//line :284:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A) Ctor_J(c__k int64) { t.F_k = c__k }
//line :284:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A) Invoke_O_O__O(self, s__1991000210__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1582 any = A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A_New_O_J_O(self, t.F_k, s__1991000210__1); var tmp2 *jrt.Class; var fncls__1581 *jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A_fn_class; if fncls__1581 == nil { var fncls__1581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__1582); A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A_fn_class = fncls__1581d; tmp2 = fncls__1581d } else { tmp2 = fncls__1581 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1582, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :284:1
func A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A_New_O_J_O(p0 any, p1 int64, p2 any) *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A{}; t.Ctor_O_J_O(p0, p1, p2); return t }
//line :284:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A) Ctor_O_J_O(c__iter__1991000209 any, c__k int64, c__s__1991000210 any) { t.F_iter__1991000209 = c__iter__1991000209; t.F_k = c__k; t.F_s__1991000210 = c__s__1991000210 }
//line :284:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A) Invoke_O__O(self any) any { { var s__1991000210__1 any; var t_ any = t.F_s__1991000210; t.F_s__1991000210 = nil; s__1991000210__1 = t_; for { var temp__1927000414__auto____2 any; var root_1523 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = s__1991000210__1; if linked_1524 == nil { temp__1927000414__auto____2 = ifn_1525.Invoke_O__O(arg_1526) } else { temp__1927000414__auto____2 = linked_1524.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1523, arg_1526) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1527 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = s__1991000210__3; if linked_1528 == nil { tmp1 = ifn_1529.Invoke_O__O(arg_1530) } else { tmp1 = linked_1528.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1527, arg_1530) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1531 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = s__1991000210__3; if linked_1532 == nil { c__1927001037__auto____4 = ifn_1533.Invoke_O__O(arg_1534) } else { c__1927001037__auto____4 = linked_1532.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1531, arg_1534) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000212__6 any; var root_1535 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1536 == nil { b__1991000212__6 = ifn_1537.Invoke_O__O(arg_1538) } else { b__1991000212__6 = linked_1536.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1535, arg_1538) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1545 any = A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A_New_J_I_O_O(t.F_k, size__1927001038__auto____5, c__1927001037__auto____4, b__1991000212__6); var tmp3 *jrt.Class; var fncls__1544 *jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A_fn_class; if fncls__1544 == nil { var fncls__1544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1545); A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A_fn_class = fncls__1544d; tmp3 = fncls__1544d } else { tmp3 = fncls__1544 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1545, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1546 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any; var root_1551 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = b__1991000212__6; if linked_1552 == nil { arg_1549 = ifn_1553.Invoke_O__O(arg_1554) } else { arg_1549 = linked_1552.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1551, arg_1554) }; var arg_1550 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000209); var tmp5 any; var root_1555 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = s__1991000210__3; if linked_1556 == nil { tmp5 = ifn_1557.Invoke_O__O(arg_1558) } else { tmp5 = linked_1556.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1555, arg_1558) }; arg_1550 = tmp4.Invoke_O__O(tmp5); if linked_1547 == nil { return ifn_1548.Invoke_O_O__O(arg_1549, arg_1550) } else { return linked_1547.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1546, arg_1549, arg_1550) } } else { var root_1559 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any; var root_1564 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = b__1991000212__6; if linked_1565 == nil { arg_1562 = ifn_1566.Invoke_O__O(arg_1567) } else { arg_1562 = linked_1565.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1564, arg_1567) }; var arg_1563 any; if linked_1560 == nil { return ifn_1561.Invoke_O_O__O(arg_1562, arg_1563) } else { return linked_1560.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1559, arg_1562, arg_1563) } } } else { var p__4 any; var root_1568 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = s__1991000210__3; if linked_1569 == nil { p__4 = ifn_1570.Invoke_O__O(arg_1571) } else { p__4 = linked_1569.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1568, arg_1571) }; var root_1572 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(t.F_k).Ref(), p__4); var arg_1576 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000209); var tmp7 any; var root_1577 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = s__1991000210__3; if linked_1578 == nil { tmp7 = ifn_1579.Invoke_O__O(arg_1580) } else { tmp7 = linked_1578.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1577, arg_1580) }; arg_1576 = tmp6.Invoke_O__O(tmp7); if linked_1573 == nil { return ifn_1574.Invoke_O_O__O(arg_1575, arg_1576) } else { return linked_1573.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1572, arg_1575, arg_1576) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :284:1
func A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A_New_J_I_O_O(p0 int64, p1 int32, p2, p3 any) *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A{}; t.Ctor_J_I_O_O(p0, p1, p2, p3); return t }
//line :284:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A) Ctor_J_I_O_O(c__k int64, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000212 any) { t.F_k = c__k; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000212 = c__b__1991000212 }
//line :284:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A) Invoke_O__O(self any) any { { var i__1991000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000211__1)); var root_1539 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = t.F_b__1991000212; var arg_1543 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(t.F_k).Ref(), p__2); if linked_1540 == nil { ifn_1541.Invoke_O_O__O(arg_1542, arg_1543) } else { linked_1540.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1539, arg_1542, arg_1543) }; i__1991000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000211__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_resource_dir_names_A_New() *A_arbace_j2g_embed_resource_dir_names_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_resource_dir_names_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_j2g_embed_resource_dir_names_A) Ctor() {}
//line :286:1
func (t *A_arbace_j2g_embed_resource_dir_names_A) Invoke_O_O__O(self, specs__0 any) any {



	var root_1594 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any; var iter__1927001039__auto____2 any; var fnbody__1679 any = A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A_New(); var tmp1 *jrt.Class; var fncls__1678 *jrt.Class = A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A_fn_class; if fncls__1678 == nil { var fncls__1678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A_fn_class = fncls__1678d; tmp1 = fncls__1678d } else { tmp1 = fncls__1678 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1679, tmp1, nil); arg_1597 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(specs__0); if linked_1595 == nil { return ifn_1596.Invoke_O__O(arg_1597) } else { return linked_1595.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1594, arg_1597) } }
//line :290:1
func A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A_New() *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A) Ctor() {}
//line :290:1
func (t *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A) Invoke_O_O__O(self, s__1991000221__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1677 any = A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A_New_O_O(s__1991000221__1, self); var tmp2 *jrt.Class; var fncls__1676 *jrt.Class = A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A_fn_class; if fncls__1676 == nil { var fncls__1676d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1677); A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A_fn_class = fncls__1676d; tmp2 = fncls__1676d } else { tmp2 = fncls__1676 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1677, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :290:1
func A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A{}; t.Ctor_O_O(p0, p1); return t }
//line :290:1
func (t *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A) Ctor_O_O(c__s__1991000221, c__iter__1991000220 any) { t.F_s__1991000221 = c__s__1991000221; t.F_iter__1991000220 = c__iter__1991000220 }
//line :290:1
func (t *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A) Invoke_O__O(self any) any { { var s__1991000221__1 any; var t_ any = t.F_s__1991000221; t.F_s__1991000221 = nil; s__1991000221__1 = t_; for { var temp__1927000414__auto____2 any; var root_1598 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = s__1991000221__1; if linked_1599 == nil { temp__1927000414__auto____2 = ifn_1600.Invoke_O__O(arg_1601) } else { temp__1927000414__auto____2 = linked_1599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1598, arg_1601) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000221__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1602 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = s__1991000221__3; if linked_1603 == nil { tmp1 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp1 = linked_1603.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1602, arg_1605) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1606 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = s__1991000221__3; if linked_1607 == nil { c__1927001037__auto____4 = ifn_1608.Invoke_O__O(arg_1609) } else { c__1927001037__auto____4 = linked_1607.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1606, arg_1609) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000223__6 any; var root_1610 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1611 == nil { b__1991000223__6 = ifn_1612.Invoke_O__O(arg_1613) } else { b__1991000223__6 = linked_1611.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1610, arg_1613) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1630 any = A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000223__6); var tmp3 *jrt.Class; var fncls__1629 *jrt.Class = A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_fn_class; if fncls__1629 == nil { var fncls__1629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__1630); A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_fn_class = fncls__1629d; tmp3 = fncls__1629d } else { tmp3 = fncls__1629 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1630, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1631 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any; var root_1636 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = b__1991000223__6; if linked_1637 == nil { arg_1634 = ifn_1638.Invoke_O__O(arg_1639) } else { arg_1634 = linked_1637.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1636, arg_1639) }; var arg_1635 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000220); var tmp5 any; var root_1640 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = s__1991000221__3; if linked_1641 == nil { tmp5 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp5 = linked_1641.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1640, arg_1643) }; arg_1635 = tmp4.Invoke_O__O(tmp5); if linked_1632 == nil { return ifn_1633.Invoke_O_O__O(arg_1634, arg_1635) } else { return linked_1632.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1631, arg_1634, arg_1635) } } else { var root_1644 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any; var root_1649 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = b__1991000223__6; if linked_1650 == nil { arg_1647 = ifn_1651.Invoke_O__O(arg_1652) } else { arg_1647 = linked_1650.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1649, arg_1652) }; var arg_1648 any; if linked_1645 == nil { return ifn_1646.Invoke_O_O__O(arg_1647, arg_1648) } else { return linked_1645.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1644, arg_1647, arg_1648) } } } else { var spec__4 any; var root_1653 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = s__1991000221__3; if linked_1654 == nil { spec__4 = ifn_1655.Invoke_O__O(arg_1656) } else { spec__4 = linked_1654.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1653, arg_1656) }; var i__5 int32 = jrt.NN(jrt.String_Cast(spec__4)).LastIndexOf_String__I(Lit_48); var dir__6 any

	if lang.Numbers_IsPos_J__Z_NoInit(int64(i__5)) { var root_1657 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = spec__4; var arg_1661 any = A_arbace_j2g_embed_A_const_34; var arg_1662 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__5).Ref(); if linked_1658 == nil { dir__6 = ifn_1659.Invoke_O_O_O__O(arg_1660, arg_1661, arg_1662) } else { dir__6 = linked_1658.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1657, arg_1660, arg_1661, arg_1662) } } else { dir__6 = spec__4 }
//line :290:1
	var root_1663 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any; var tmp6 any; var root_1668 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1668, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1670 lang.IFn


	if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = dir__6; if linked_1669 == nil { tmp6 = ifn_1670.Invoke_O__O(arg_1671) } else { tmp6 = linked_1669.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1668, arg_1671) }; arg_1666 = jrt.File_Cast(tmp6).GetAbsoluteFile__File().GetName__String().Ref()
//line :290:1
	var arg_1667 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000220); var tmp8 any; var root_1672 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = s__1991000221__3; if linked_1673 == nil { tmp8 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp8 = linked_1673.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1672, arg_1675) }; arg_1667 = tmp7.Invoke_O__O(tmp8); if linked_1664 == nil { return ifn_1665.Invoke_O_O__O(arg_1666, arg_1667) } else { return linked_1664.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1663, arg_1666, arg_1667) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :290:1
func A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :290:1
func (t *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000223 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000223 = c__b__1991000223 }
//line :290:1
func (t *A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A) Invoke_O__O(self any) any { { var i__1991000222__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000222__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000222__1)); var i__3 int32 = jrt.NN(jrt.String_Cast(spec__2)).LastIndexOf_String__I(Lit_48); var dir__4 any

	if lang.Numbers_IsPos_J__Z_NoInit(int64(i__3)) { var root_1614 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = spec__2; var arg_1618 any = A_arbace_j2g_embed_A_const_34; var arg_1619 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__3).Ref(); if linked_1615 == nil { dir__4 = ifn_1616.Invoke_O_O_O__O(arg_1617, arg_1618, arg_1619) } else { dir__4 = linked_1615.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1614, arg_1617, arg_1618, arg_1619) } } else { dir__4 = spec__2 }
//line :290:1
	var root_1620 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = t.F_b__1991000223; var arg_1624 any; var tmp2 any; var root_1625 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1625, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1627 lang.IFn


	if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = dir__4; if linked_1626 == nil { tmp2 = ifn_1627.Invoke_O__O(arg_1628) } else { tmp2 = linked_1626.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1625, arg_1628) }; arg_1624 = jrt.File_Cast(tmp2).GetAbsoluteFile__File().GetName__String().Ref()
//line :290:1
	if linked_1621 == nil { ifn_1622.Invoke_O_O__O(arg_1623, arg_1624) } else { linked_1621.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1620, arg_1623, arg_1624) }; i__1991000222__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000222__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_package_loaders_A_New() *A_arbace_j2g_embed_package_loaders_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_j2g_embed_package_loaders_A) Ctor() {}
//line :295:1
func (t *A_arbace_j2g_embed_package_loaders_A) Invoke_O_O_O__O(self, dirs__0, taken__1 any) any {





	var root_1680 any = A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_1684 any; var iter__1927001039__auto____3 any; var fnbody__1880 any = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A_New_O(taken__1); var tmp1 *jrt.Class; var fncls__1879 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A_fn_class
	if fncls__1879 == nil { var fncls__1879d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__1880); A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A_fn_class = fncls__1879d; tmp1 = fncls__1879d } else { tmp1 = fncls__1879 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1880, tmp1, nil); arg_1684 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(dirs__0)
//line :301:1
	if linked_1681 == nil { return ifn_1682.Invoke_O_O__O(arg_1683, arg_1684) } else { return linked_1681.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1680, arg_1683, arg_1684) } }
func A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A_New_O(p0 any) *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A) Ctor_O(c__taken any) { t.F_taken = c__taken }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A) Invoke_O_O__O(self, s__1991000232__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1878 any = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A_New_O_O_O(t.F_taken, s__1991000232__1, self); var tmp2 *jrt.Class; var fncls__1877 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A_fn_class; if fncls__1877 == nil { var fncls__1877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1878); A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A_fn_class = fncls__1877d; tmp2 = fncls__1877d } else { tmp2 = fncls__1877 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1878, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :302:1
func A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A) Ctor_O_O_O(c__taken, c__s__1991000232, c__iter__1991000231 any) { t.F_taken = c__taken; t.F_s__1991000232 = c__s__1991000232; t.F_iter__1991000231 = c__iter__1991000231 }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A) Invoke_O__O(self any) any { { var s__1991000232__1 any; var t_ any = t.F_s__1991000232; t.F_s__1991000232 = nil; s__1991000232__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1688 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = s__1991000232__1; if linked_1689 == nil { temp__1927000414__auto____2 = ifn_1690.Invoke_O__O(arg_1691) } else { temp__1927000414__auto____2 = linked_1689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1688, arg_1691) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var dir__4 any; var root_1692 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = xs__1927001018__auto____3; if linked_1693 == nil { dir__4 = ifn_1694.Invoke_O__O(arg_1695) } else { dir__4 = linked_1693.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1692, arg_1695) }; var base__5 any; var root_1696 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1696, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1698 lang.IFn
															if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = dir__4; if linked_1697 == nil { base__5 = ifn_1698.Invoke_O__O(arg_1699) } else { base__5 = linked_1697.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1696, arg_1699) }
//line :302:1
	var iterys__1927001035__auto____6 any; var fnbody__1851 any = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A_New_O_O(t.F_taken, base__5); var tmp1 *jrt.Class; var fncls__1850 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A_fn_class; if fncls__1850 == nil { var fncls__1850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1851); A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A_fn_class = fncls__1850d; tmp1 = fncls__1850d } else { tmp1 = fncls__1850 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1851, tmp1, nil); var fs__1927001036__auto____7 any; var root_1852 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp3 any; var root_1856 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1858 lang.IFn

	if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any; var root_1860 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = base__5; if linked_1861 == nil { arg_1859 = ifn_1862.Invoke_O__O(arg_1863) } else { arg_1859 = linked_1861.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1860, arg_1863) }; if linked_1857 == nil { tmp3 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp3 = linked_1857.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1856, arg_1859) }
//line :302:1
	arg_1855 = tmp2.Invoke_O__O(tmp3); if linked_1853 == nil { fs__1927001036__auto____7 = ifn_1854.Invoke_O__O(arg_1855) } else { fs__1927001036__auto____7 = linked_1853.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1852, arg_1855) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_1864 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = fs__1927001036__auto____7; var arg_1868 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000231); var tmp5 any; var root_1869 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = s__1991000232__1; if linked_1870 == nil { tmp5 = ifn_1871.Invoke_O__O(arg_1872) } else { tmp5 = linked_1870.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1869, arg_1872) }; arg_1868 = tmp4.Invoke_O__O(tmp5); if linked_1865 == nil { return ifn_1866.Invoke_O_O__O(arg_1867, arg_1868) } else { return linked_1865.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1864, arg_1867, arg_1868) } } else { var tmp6 any; var root_1873 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = s__1991000232__1; if linked_1874 == nil { tmp6 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp6 = linked_1874.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1873, arg_1876) }; s__1991000232__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :302:1
func A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A{}; t.Ctor_O_O(p0, p1); return t }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A) Ctor_O_O(c__taken, c__base any) { t.F_taken = c__taken; t.F_base = c__base }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A) Invoke_O_O__O(self, s__1991000234__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1849 any = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A_New_O_O_O_O(t.F_taken, t.F_base, s__1991000234__1, self); var tmp2 *jrt.Class; var fncls__1848 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A_fn_class; if fncls__1848 == nil { var fncls__1848d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__1849); A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A_fn_class = fncls__1848d; tmp2 = fncls__1848d } else { tmp2 = fncls__1848 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1849, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :302:1
func A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A) Ctor_O_O_O_O(c__taken, c__base, c__s__1991000234, c__iter__1991000233 any) { t.F_taken = c__taken; t.F_base = c__base; t.F_s__1991000234 = c__s__1991000234; t.F_iter__1991000233 = c__iter__1991000233 }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A) Invoke_O__O(self any) any { { var s__1991000234__1 any; var t_ any = t.F_s__1991000234; t.F_s__1991000234 = nil; s__1991000234__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1700 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = s__1991000234__1; if linked_1701 == nil { temp__1927000414__auto____2 = ifn_1702.Invoke_O__O(arg_1703) } else { temp__1927000414__auto____2 = linked_1701.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1700, arg_1703) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000234__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1704 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = s__1991000234__3; if linked_1705 == nil { tmp1 = ifn_1706.Invoke_O__O(arg_1707) } else { tmp1 = linked_1705.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1704, arg_1707) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1708 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = s__1991000234__3; if linked_1709 == nil { c__1927001037__auto____4 = ifn_1710.Invoke_O__O(arg_1711) } else { c__1927001037__auto____4 = linked_1709.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1708, arg_1711) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000236__6 any; var root_1712 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1713 == nil { b__1991000236__6 = ifn_1714.Invoke_O__O(arg_1715) } else { b__1991000236__6 = linked_1713.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1712, arg_1715) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1763 any = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A_New_O_O_O_I_O(b__1991000236__6, t.F_taken, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1762 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A_fn_class; if fncls__1762 == nil { var fncls__1762d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__1763); A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A_fn_class = fncls__1762d; tmp3 = fncls__1762d } else { tmp3 = fncls__1762 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1763, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1764 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any; var root_1769 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = b__1991000236__6; if linked_1770 == nil { arg_1767 = ifn_1771.Invoke_O__O(arg_1772) } else { arg_1767 = linked_1770.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1769, arg_1772) }; var arg_1768 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000233); var tmp5 any; var root_1773 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = s__1991000234__3; if linked_1774 == nil { tmp5 = ifn_1775.Invoke_O__O(arg_1776) } else { tmp5 = linked_1774.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1773, arg_1776) }; arg_1768 = tmp4.Invoke_O__O(tmp5); if linked_1765 == nil { return ifn_1766.Invoke_O_O__O(arg_1767, arg_1768) } else { return linked_1765.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1764, arg_1767, arg_1768) } } else { var root_1777 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any; var root_1782 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = b__1991000236__6; if linked_1783 == nil { arg_1780 = ifn_1784.Invoke_O__O(arg_1785) } else { arg_1780 = linked_1783.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1782, arg_1785) }; var arg_1781 any; if linked_1778 == nil { return ifn_1779.Invoke_O_O__O(arg_1780, arg_1781) } else { return linked_1778.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1777, arg_1780, arg_1781) } } } else { var f__4 any; var root_1786 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = s__1991000234__3; if linked_1787 == nil { f__4 = ifn_1788.Invoke_O__O(arg_1789) } else { f__4 = linked_1787.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1786, arg_1789) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()


	if and__1927000168__auto____5 { var root_1790 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1794 any = Lit_28; if linked_1791 == nil { tmp6 = ifn_1792.Invoke_O_O__O(arg_1793, arg_1794) } else { tmp6 = linked_1791.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1790, arg_1793, arg_1794) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :302:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var root_1795 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1797 lang.IFn



		if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any; var root_1801 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_1802 == nil { arg_1798 = ifn_1803.Invoke_O__O(arg_1804) } else { arg_1798 = linked_1802.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1801, arg_1804) }; var arg_1799 any = jrt.File_separator.Ref(); var arg_1800 any = Lit_7; if linked_1796 == nil { rel__5 = ifn_1797.Invoke_O_O_O__O(arg_1798, arg_1799, arg_1800) } else { rel__5 = linked_1796.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1795, arg_1798, arg_1799, arg_1800) }
//line :302:1
		var m__6 any; var root_1805 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1807 lang.IFn




		if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = A_arbace_j2g_embed_A_const_101; var arg_1809 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4); if linked_1806 == nil { m__6 = ifn_1807.Invoke_O_O__O(arg_1808, arg_1809) } else { m__6 = linked_1806.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1805, arg_1808, arg_1809) }
//line :302:1
		var tmp7 any
		var and__1927000168__auto____7 any = m__6




		if jrt.J2g_Truth(and__1927000168__auto____7) { var root_1814 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any; var root_1818 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = t.F_taken; var arg_1822 any = rel__5; if linked_1819 == nil { arg_1817 = ifn_1820.Invoke_O_O__O(arg_1821, arg_1822) } else { arg_1817 = linked_1819.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1818, arg_1821, arg_1822) }; if linked_1815 == nil { tmp7 = ifn_1816.Invoke_O__O(arg_1817) } else { tmp7 = linked_1815.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1814, arg_1817) } } else { tmp7 = and__1927000168__auto____7 }
//line :302:1
		if jrt.J2g_Truth(tmp7) { var root_1823 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any; var tmp8 *jrt.RefArray = jrt.ConstRefArray("[0,7,s43:;; j2g --java-namespaces: the Java package ns29:'s namespace, a no-op loader\ns74:;; (its classes are the program's; bin/arbace-go --build-program, RPS93).\ns4:(ns ns2:)\n", []*jrt.Class{jrt.String_class}); var tmp9 any; var root_1828 any = A_arbace_j2g_embed_A_const_102.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1830 lang.IFn






			if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = m__6; if linked_1829 == nil { tmp9 = ifn_1830.Invoke_O__O(arg_1831) } else { tmp9 = linked_1829.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1828, arg_1831) }
//line :302:1
			var tmp10 any = tmp9; var tmp11 any; var root_1832 any = A_arbace_j2g_embed_A_const_102.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1834 lang.IFn








			if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = m__6; if linked_1833 == nil { tmp11 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp11 = linked_1833.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1832, arg_1835) }
//line :302:1
			arg_1826 = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, nil, nil, tmp11, nil)).Ref()); var arg_1827 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1991000233); var tmp13 any; var root_1836 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = s__1991000234__3; if linked_1837 == nil { tmp13 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp13 = linked_1837.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1836, arg_1839) }; arg_1827 = tmp12.Invoke_O__O(tmp13); if linked_1824 == nil { return ifn_1825.Invoke_O_O__O(arg_1826, arg_1827) } else { return linked_1824.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1823, arg_1826, arg_1827) } } else { var tmp14 any; var root_1840 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = s__1991000234__3; if linked_1841 == nil { tmp14 = ifn_1842.Invoke_O__O(arg_1843) } else { tmp14 = linked_1841.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1840, arg_1843) }; s__1991000234__1 = tmp14; continue L1 } } else { var tmp15 any; var root_1844 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = s__1991000234__3; if linked_1845 == nil { tmp15 = ifn_1846.Invoke_O__O(arg_1847) } else { tmp15 = linked_1845.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1844, arg_1847) }; s__1991000234__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :302:1
func A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A) Ctor_O_O_O_I_O(c__b__1991000236, c__taken, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000236 = c__b__1991000236; t.F_taken = c__taken; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :302:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A) Invoke_O__O(self any) any { { var i__1991000235__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000235__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000235__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()


	if and__1927000168__auto____3 { var root_1716 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1720 any = Lit_28; if linked_1717 == nil { tmp2 = ifn_1718.Invoke_O_O__O(arg_1719, arg_1720) } else { tmp2 = linked_1717.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1716, arg_1719, arg_1720) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :302:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var root_1721 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1723 lang.IFn



		if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any; var root_1727 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_1728 == nil { arg_1724 = ifn_1729.Invoke_O__O(arg_1730) } else { arg_1724 = linked_1728.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1727, arg_1730) }; var arg_1725 any = jrt.File_separator.Ref(); var arg_1726 any = Lit_7; if linked_1722 == nil { rel__3 = ifn_1723.Invoke_O_O_O__O(arg_1724, arg_1725, arg_1726) } else { rel__3 = linked_1722.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1721, arg_1724, arg_1725, arg_1726) }
//line :302:1
		var m__4 any; var root_1731 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1733 lang.IFn




		if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = A_arbace_j2g_embed_A_const_101; var arg_1735 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2); if linked_1732 == nil { m__4 = ifn_1733.Invoke_O_O__O(arg_1734, arg_1735) } else { m__4 = linked_1732.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1731, arg_1734, arg_1735) }
//line :302:1
		var tmp3 any
		var and__1927000168__auto____5 any = m__4




		if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1740 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any; var root_1744 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = t.F_taken; var arg_1748 any = rel__3; if linked_1745 == nil { arg_1743 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { arg_1743 = linked_1745.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; if linked_1741 == nil { tmp3 = ifn_1742.Invoke_O__O(arg_1743) } else { tmp3 = linked_1741.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1740, arg_1743) } } else { tmp3 = and__1927000168__auto____5 }
//line :302:1
		if jrt.J2g_Truth(tmp3) { var root_1749 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = t.F_b__1991000236; var arg_1753 any; var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,7,s43:;; j2g --java-namespaces: the Java package ns29:'s namespace, a no-op loader\ns74:;; (its classes are the program's; bin/arbace-go --build-program, RPS93).\ns4:(ns ns2:)\n", []*jrt.Class{jrt.String_class}); var tmp5 any; var root_1754 any = A_arbace_j2g_embed_A_const_102.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1756 lang.IFn






			if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = m__4; if linked_1755 == nil { tmp5 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp5 = linked_1755.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1754, arg_1757) }
//line :302:1
			var tmp6 any = tmp5; var tmp7 any; var root_1758 any = A_arbace_j2g_embed_A_const_102.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1760 lang.IFn








			if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = m__4; if linked_1759 == nil { tmp7 = ifn_1760.Invoke_O__O(arg_1761) } else { tmp7 = linked_1759.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1758, arg_1761) }
//line :302:1
			arg_1753 = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, nil, nil, tmp7, nil)).Ref()); if linked_1750 == nil { ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { linked_1750.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) }; i__1991000235__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000235__1); continue L1 } else { i__1991000235__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000235__1); continue L1 } } else { i__1991000235__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000235__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
























func A_arbace_j2g_embed_image_type_forms_A_New() *A_arbace_j2g_embed_image_type_forms_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Ctor() {}
//line :327:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any = A_arbace_j2g_embed_A_const_103; var files__3 any; var iter__1927001039__auto____3 any; var fnbody__2013 any = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A_New_O(prog_dir__0); var tmp1 *jrt.Class; var fncls__2012 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A_fn_class; if





	fncls__2012 == nil { var fncls__2012d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__2013); A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A_fn_class = fncls__2012d; tmp1 = fncls__2012d } else { tmp1 = fncls__2012 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2013, tmp1, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_j2g_embed_A_const_120); var types__4 any; var root_2014 any = /*line :327:1*/A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2016 lang.IFn; if












	linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var arg_2018 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp3 any; var root_2025 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; if linked_2026 == nil { tmp3 = ifn_2027.Invoke__O() } else { tmp3 = linked_2026.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_2025) }; var tmp4 any = tmp3; var tmp5 *lang.Compiler_AOTFn; var fnbody__2114 any = A_arbace_j2g_embed_image_type_forms_fn__1991000268_A_New_O(re__2); var tmp6 *jrt.Class; var fncls__2113 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000268_A_fn_class; if fncls__2113 == nil { var fncls__2113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__2114); A_arbace_j2g_embed_image_type_forms_fn__1991000268_A_fn_class = fncls__2113d; tmp6 = fncls__2113d } else { tmp6 = fncls__2113 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2114, tmp6, nil); arg_2018 = tmp2.Invoke_O_O_O__O(tmp4, tmp5.Ref(), files__3); if linked_2015 == nil { types__4 = ifn_2016.Invoke_O_O__O(arg_2017, arg_2018) } else { types__4 = linked_2015.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2014, arg_2017, arg_2018) }; var root_2115 any =



	A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_107, Lit_18, A_arbace_j2g_embed_A_const_108, A_arbace_j2g_embed_A_const_109)); var arg_2119 any; var iter__1927001039__auto____5 any; var fnbody__2319 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A_New(); var tmp7 *jrt.Class; var fncls__2318 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A_fn_class; if
	fncls__2318 == nil { var fncls__2318d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A_fn_class = fncls__2318d; tmp7 = fncls__2318d } else { tmp7 = fncls__2318 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2319, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp9 any; var root_2320 any = A_arbace_j2g_embed_A_const_118.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, aot_arbace_core.A_arbace_core_partition_all_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = A_arbace_j2g_embed_A_const_119; var arg_2324 any; var root_2325 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_2329 any; var root_2330 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = types__4; if linked_2331 == nil { arg_2329 = ifn_2332.Invoke_O__O(arg_2333) } else { arg_2329 = linked_2331.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2330, arg_2333) }; if linked_2326 == nil { arg_2324 = ifn_2327.Invoke_O_O__O(arg_2328, arg_2329) } else { arg_2324 = linked_2326.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2325, arg_2328, arg_2329) }; if linked_2321 == nil { tmp9 = ifn_2322.Invoke_O_O__O(arg_2323, arg_2324) } else { tmp9 = linked_2321.(*aot_arbace_core.A_arbace_core_partition_all_A).Invoke_O_O_O__O(root_2320, arg_2323, arg_2324) }; arg_2119 = tmp8.Invoke_O__O(tmp9); if /*line :344:1*/ linked_2116 == nil { return ifn_2117.Invoke_O_O__O(arg_2118, arg_2119) } else { return linked_2116.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2115, arg_2118, arg_2119) } }
//line :333:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A{}; t.Ctor_O(p0); return t }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A) Invoke_O_O__O(self, s__1991000249__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2011 any = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A_New_O_O_O(t.F_prog_dir, s__1991000249__1, self); var tmp2 *jrt.Class; var fncls__2010 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A_fn_class; if fncls__2010 == nil { var fncls__2010d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__2011); A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A_fn_class = fncls__2010d; tmp2 = fncls__2010d } else { tmp2 = fncls__2010 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2011, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :333:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A) Ctor_O_O_O(c__prog_dir, c__s__1991000249, c__iter__1991000248 any) { t.F_prog_dir = c__prog_dir; t.F_s__1991000249 = c__s__1991000249; t.F_iter__1991000248 = c__iter__1991000248 }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A) Invoke_O__O(self any) any { { var s__1991000249__1 any; var t_ any = t.F_s__1991000249; t.F_s__1991000249 = nil; s__1991000249__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1881 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = s__1991000249__1; if linked_1882 == nil { temp__1927000414__auto____2 = ifn_1883.Invoke_O__O(arg_1884) } else { temp__1927000414__auto____2 = linked_1882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1881, arg_1884) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1991000256__4 any; var root_1885 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = xs__1927001018__auto____3; if linked_1886 == nil { vec__1991000256__4 = ifn_1887.Invoke_O__O(arg_1888) } else { vec__1991000256__4 = linked_1886.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1885, arg_1888) }; var pkg__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000256__4, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000256__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dir__7 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_24, pkg__5); var iterys__1927001035__auto____8 any; var fnbody__1988 any = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A_New_O(alias__6); var tmp1 *jrt.Class; var fncls__1987 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A_fn_class; if fncls__1987 == nil { var fncls__1987d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__1988); A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A_fn_class = fncls__1987d; tmp1 = fncls__1987d } else { tmp1 = fncls__1987 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1988, tmp1, nil); var fs__1927001036__auto____9 any; var root_1989 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp3 any; var root_1993 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1995 lang.IFn

	if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = jrt.File_Cast(dir__7).ListFiles__File1().Ref(); if linked_1994 == nil { tmp3 = ifn_1995.Invoke_O__O(arg_1996) } else { tmp3 = linked_1994.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1993, arg_1996) }
//line :333:1
	arg_1992 = tmp2.Invoke_O__O(tmp3); if linked_1990 == nil { fs__1927001036__auto____9 = ifn_1991.Invoke_O__O(arg_1992) } else { fs__1927001036__auto____9 = linked_1990.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1989, arg_1992) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_1997 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = fs__1927001036__auto____9; var arg_2001 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000248); var tmp5 any; var root_2002 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = s__1991000249__1; if linked_2003 == nil { tmp5 = ifn_2004.Invoke_O__O(arg_2005) } else { tmp5 = linked_2003.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2002, arg_2005) }; arg_2001 = tmp4.Invoke_O__O(tmp5); if linked_1998 == nil { return ifn_1999.Invoke_O_O__O(arg_2000, arg_2001) } else { return linked_1998.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1997, arg_2000, arg_2001) } } else { var tmp6 any; var root_2006 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any = s__1991000249__1; if linked_2007 == nil { tmp6 = ifn_2008.Invoke_O__O(arg_2009) } else { tmp6 = linked_2007.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2006, arg_2009) }; s__1991000249__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :333:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A{}; t.Ctor_O(p0); return t }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A) Invoke_O_O__O(self, s__1991000251__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1986 any = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A_New_O_O_O(t.F_alias, s__1991000251__1, self); var tmp2 *jrt.Class; var fncls__1985 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A_fn_class; if fncls__1985 == nil { var fncls__1985d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__1986); A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A_fn_class = fncls__1985d; tmp2 = fncls__1985d } else { tmp2 = fncls__1985 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1986, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :333:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A) Ctor_O_O_O(c__alias, c__s__1991000251, c__iter__1991000250 any) { t.F_alias = c__alias; t.F_s__1991000251 = c__s__1991000251; t.F_iter__1991000250 = c__iter__1991000250 }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A) Invoke_O__O(self any) any { { var s__1991000251__1 any; var t_ any = t.F_s__1991000251; t.F_s__1991000251 = nil; s__1991000251__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1895 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = s__1991000251__1; if linked_1896 == nil { temp__1927000414__auto____2 = ifn_1897.Invoke_O__O(arg_1898) } else { temp__1927000414__auto____2 = linked_1896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1895, arg_1898) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000251__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1899 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = s__1991000251__3; if linked_1900 == nil { tmp1 = ifn_1901.Invoke_O__O(arg_1902) } else { tmp1 = linked_1900.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1899, arg_1902) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1903 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = s__1991000251__3; if linked_1904 == nil { c__1927001037__auto____4 = ifn_1905.Invoke_O__O(arg_1906) } else { c__1927001037__auto____4 = linked_1904.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1903, arg_1906) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000253__6 any; var root_1907 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1908 == nil { b__1991000253__6 = ifn_1909.Invoke_O__O(arg_1910) } else { b__1991000253__6 = linked_1908.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1907, arg_1910) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1931 any = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, b__1991000253__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1930 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A_fn_class; if fncls__1930 == nil { var fncls__1930d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__1931); A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A_fn_class = fncls__1930d; tmp3 = fncls__1930d } else { tmp3 = fncls__1930 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1931, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1932 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any; var root_1937 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = b__1991000253__6; if linked_1938 == nil { arg_1935 = ifn_1939.Invoke_O__O(arg_1940) } else { arg_1935 = linked_1938.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1937, arg_1940) }; var arg_1936 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000250); var tmp5 any; var root_1941 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = s__1991000251__3; if linked_1942 == nil { tmp5 = ifn_1943.Invoke_O__O(arg_1944) } else { tmp5 = linked_1942.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1941, arg_1944) }; arg_1936 = tmp4.Invoke_O__O(tmp5); if linked_1933 == nil { return ifn_1934.Invoke_O_O__O(arg_1935, arg_1936) } else { return linked_1933.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1932, arg_1935, arg_1936) } } else { var root_1945 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any; var root_1950 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = b__1991000253__6; if linked_1951 == nil { arg_1948 = ifn_1952.Invoke_O__O(arg_1953) } else { arg_1948 = linked_1951.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1950, arg_1953) }; var arg_1949 any; if linked_1946 == nil { return ifn_1947.Invoke_O_O__O(arg_1948, arg_1949) } else { return linked_1946.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1945, arg_1948, arg_1949) } } } else { var f__4 any; var root_1954 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1956 lang.IFn; if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = s__1991000251__3; if linked_1955 == nil { f__4 = ifn_1956.Invoke_O__O(arg_1957) } else { f__4 = linked_1955.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1954, arg_1957) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1958 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1962 any = Lit_28; if linked_1959 == nil { and__1927000168__auto____6 = ifn_1960.Invoke_O_O__O(arg_1961, arg_1962) } else { and__1927000168__auto____6 = linked_1959.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1958, arg_1961, arg_1962) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_1963 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any; var root_1967 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1967, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1969 lang.IFn; if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1971 any = Lit_29; if linked_1968 == nil { arg_1966 = ifn_1969.Invoke_O_O__O(arg_1970, arg_1971) } else { arg_1966 = linked_1968.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1967, arg_1970, arg_1971) }; if linked_1964 == nil { tmp6 = ifn_1965.Invoke_O__O(arg_1966) } else { tmp6 = linked_1964.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1963, arg_1966) } } else {
//line :336:1
			tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :333:1
	if jrt.J2g_Truth(tmp6) { var root_1972 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4); var arg_1976 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000250); var tmp8 any; var root_1977 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1977, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1979 lang.IFn; if linked_1978 == nil { ifn_1979 = lang.IFn_Cast(root_1977) } else { ifn_1979 = nil }; var arg_1980 any = s__1991000251__3; if linked_1978 == nil { tmp8 = ifn_1979.Invoke_O__O(arg_1980) } else { tmp8 = linked_1978.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1977, arg_1980) }; arg_1976 = tmp7.Invoke_O__O(tmp8); if linked_1973 == nil { return ifn_1974.Invoke_O_O__O(arg_1975, arg_1976) } else { return linked_1973.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1972, arg_1975, arg_1976) } } else { var tmp9 any; var root_1981 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = s__1991000251__3; if linked_1982 == nil { tmp9 = ifn_1983.Invoke_O__O(arg_1984) } else { tmp9 = linked_1982.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1981, arg_1984) }; s__1991000251__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :333:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__b__1991000253, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000253 = c__b__1991000253; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :333:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A) Invoke_O__O(self any) any { { var i__1991000252__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000252__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000252__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1911 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1915 any = Lit_28; if linked_1912 == nil { and__1927000168__auto____4 = ifn_1913.Invoke_O_O__O(arg_1914, arg_1915) } else { and__1927000168__auto____4 = linked_1912.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1911, arg_1914, arg_1915) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1916 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1916, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1918 lang.IFn; if linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any; var root_1920 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1924 any = Lit_29; if linked_1921 == nil { arg_1919 = ifn_1922.Invoke_O_O__O(arg_1923, arg_1924) } else { arg_1919 = linked_1921.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1920, arg_1923, arg_1924) }; if linked_1917 == nil { tmp2 = ifn_1918.Invoke_O__O(arg_1919) } else { tmp2 = linked_1917.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1916, arg_1919) } } else {
//line :336:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :333:1
	if jrt.J2g_Truth(tmp2) { var root_1925 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = t.F_b__1991000253; var arg_1929 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2); if linked_1926 == nil { ifn_1927.Invoke_O_O__O(arg_1928, arg_1929) } else { linked_1926.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1925, arg_1928, arg_1929) }; i__1991000252__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000252__1); continue L1 } else { i__1991000252__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000252__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_embed_image_type_forms_fn__1991000268_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000268_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000268_A{}; t.Ctor_O(p0); return t }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_A) Invoke_O_O__O(self, p__1991000267__1 any) any { var vec__1991000269__2 any = p__1991000267__1; var alias__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000269__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000269__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2028 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any; var iter__1927001039__auto____5 any; var fnbody__2103 any = A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A_New_O(alias__3); var tmp1 *jrt.Class; var fncls__2102 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A_fn_class; if fncls__2102 == nil { var fncls__2102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__2103); A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A_fn_class = fncls__2102d; tmp1 = fncls__2102d } else { tmp1 = fncls__2102 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2103, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp3 any; var root_2104 any = A_arbace_j2g_embed_A_const_105.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = t.F_re; var arg_2108 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4); if linked_2105 == nil { tmp3 = ifn_2106.Invoke_O_O__O(arg_2107, arg_2108) } else { tmp3 = linked_2105.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_2104, arg_2107, arg_2108) }; arg_2031 = tmp2.Invoke_O__O(tmp3); if linked_2029 == nil { return ifn_2030.Invoke_O__O(arg_2031) } else { return linked_2029.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2028, arg_2031) } }
//line :340:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A{}; t.Ctor_O(p0); return t }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A) Invoke_O_O__O(self, s__1991000273__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2101 any = A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A_New_O_O_O(t.F_alias, s__1991000273__1, self); var tmp2 *jrt.Class; var fncls__2100 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A_fn_class; if fncls__2100 == nil { var fncls__2100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__2101); A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A_fn_class = fncls__2100d; tmp2 = fncls__2100d } else { tmp2 = fncls__2100 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2101, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :340:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A) Ctor_O_O_O(c__alias, c__s__1991000273, c__iter__1991000272 any) { t.F_alias = c__alias; t.F_s__1991000273 = c__s__1991000273; t.F_iter__1991000272 = c__iter__1991000272 }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A) Invoke_O__O(self any) any { { var s__1991000273__1 any; var t_ any = t.F_s__1991000273; t.F_s__1991000273 = nil; s__1991000273__1 = t_; for { var temp__1927000414__auto____2 any; var root_2032 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = s__1991000273__1; if linked_2033 == nil { temp__1927000414__auto____2 = ifn_2034.Invoke_O__O(arg_2035) } else { temp__1927000414__auto____2 = linked_2033.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2032, arg_2035) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000273__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2036 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = s__1991000273__3; if linked_2037 == nil { tmp1 = ifn_2038.Invoke_O__O(arg_2039) } else { tmp1 = linked_2037.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2036, arg_2039) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2040 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = s__1991000273__3; if linked_2041 == nil { c__1927001037__auto____4 = ifn_2042.Invoke_O__O(arg_2043) } else { c__1927001037__auto____4 = linked_2041.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2040, arg_2043) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000275__6 any; var root_2044 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2045 == nil { b__1991000275__6 = ifn_2046.Invoke_O__O(arg_2047) } else { b__1991000275__6 = linked_2045.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2044, arg_2047) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2059 any = A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, b__1991000275__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2058 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A_fn_class; if fncls__2058 == nil { var fncls__2058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2059); A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A_fn_class = fncls__2058d; tmp3 = fncls__2058d } else { tmp3 = fncls__2058 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2059, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2060 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any; var root_2065 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = b__1991000275__6; if linked_2066 == nil { arg_2063 = ifn_2067.Invoke_O__O(arg_2068) } else { arg_2063 = linked_2066.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2065, arg_2068) }; var arg_2064 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000272); var tmp5 any; var root_2069 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2071 lang.IFn; if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = s__1991000273__3; if linked_2070 == nil { tmp5 = ifn_2071.Invoke_O__O(arg_2072) } else { tmp5 = linked_2070.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2069, arg_2072) }; arg_2064 = tmp4.Invoke_O__O(tmp5); if linked_2061 == nil { return ifn_2062.Invoke_O_O__O(arg_2063, arg_2064) } else { return linked_2061.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2060, arg_2063, arg_2064) } } else { var root_2073 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2075 lang.IFn; if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any; var root_2078 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = b__1991000275__6; if linked_2079 == nil { arg_2076 = ifn_2080.Invoke_O__O(arg_2081) } else { arg_2076 = linked_2079.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2078, arg_2081) }; var arg_2077 any; if linked_2074 == nil { return ifn_2075.Invoke_O_O__O(arg_2076, arg_2077) } else { return linked_2074.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2073, arg_2076, arg_2077) } } } else { var vec__1991000283__4 any; var root_2082 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = s__1991000273__3; if linked_2083 == nil { vec__1991000283__4 = ifn_2084.Invoke_O__O(arg_2085) } else { vec__1991000283__4 = linked_2083.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2082, arg_2085) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000283__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000283__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2086 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2088 lang.IFn; _ = ___5; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var root_2091 any = A_arbace_j2g_embed_A_const_104.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any = t.F_alias; var arg_2095 any = n__6; if linked_2092 == nil { arg_2089 = ifn_2093.Invoke_O_O__O(arg_2094, arg_2095) } else { arg_2089 = linked_2092.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_2091, arg_2094, arg_2095) }; var arg_2090 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000272); var tmp7 any; var root_2096 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = s__1991000273__3; if linked_2097 == nil { tmp7 = ifn_2098.Invoke_O__O(arg_2099) } else { tmp7 = linked_2097.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2096, arg_2099) }; arg_2090 = tmp6.Invoke_O__O(tmp7); if linked_2087 == nil { return ifn_2088.Invoke_O_O__O(arg_2089, arg_2090) } else { return linked_2087.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2086, arg_2089, arg_2090) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :340:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__b__1991000275, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000275 = c__b__1991000275; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :340:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A) Invoke_O__O(self any) any { { var i__1991000274__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000274__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1991000279__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000274__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000279__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000279__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2048 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2050 lang.IFn; _ = ___3; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = t.F_b__1991000275; var arg_2052 any; var root_2053 any = A_arbace_j2g_embed_A_const_104.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = t.F_alias; var arg_2057 any = n__4; if linked_2054 == nil { arg_2052 = ifn_2055.Invoke_O_O__O(arg_2056, arg_2057) } else { arg_2052 = linked_2054.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_2053, arg_2056, arg_2057) }; if linked_2049 == nil { ifn_2050.Invoke_O_O__O(arg_2051, arg_2052) } else { linked_2049.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2048, arg_2051, arg_2052) }; i__1991000274__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000274__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A) Ctor() {}
//line :345:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A) Invoke_O_O__O(self, s__1991000290__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2317 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A_New_O_O(s__1991000290__1, self); var tmp2 *jrt.Class; var fncls__2316 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A_fn_class; if fncls__2316 == nil { var fncls__2316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__2317); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A_fn_class = fncls__2316d; tmp2 = fncls__2316d } else { tmp2 = fncls__2316 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2317, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :345:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A{}; t.Ctor_O_O(p0, p1); return t }
//line :345:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A) Ctor_O_O(c__s__1991000290, c__iter__1991000289 any) { t.F_s__1991000290 = c__s__1991000290; t.F_iter__1991000289 = c__iter__1991000289 }
//line :345:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A) Invoke_O__O(self any) any { { var s__1991000290__1 any; var t_ any = t.F_s__1991000290; t.F_s__1991000290 = nil; s__1991000290__1 = t_; for { var temp__1927000414__auto____2 any; var root_2120 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = s__1991000290__1; if linked_2121 == nil { temp__1927000414__auto____2 = ifn_2122.Invoke_O__O(arg_2123) } else { temp__1927000414__auto____2 = linked_2121.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2120, arg_2123) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000290__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2124 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2126 lang.IFn; if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = s__1991000290__3; if linked_2125 == nil { tmp1 = ifn_2126.Invoke_O__O(arg_2127) } else { tmp1 = linked_2125.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2124, arg_2127) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2128 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = s__1991000290__3; if linked_2129 == nil { c__1927001037__auto____4 = ifn_2130.Invoke_O__O(arg_2131) } else { c__1927001037__auto____4 = linked_2129.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2128, arg_2131) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000292__6 any; var root_2132 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2133 == nil { b__1991000292__6 = ifn_2134.Invoke_O__O(arg_2135) } else { b__1991000292__6 = linked_2133.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2132, arg_2135) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2211 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A_New_O_I_O(b__1991000292__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2210 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A_fn_class; if fncls__2210 == nil { var fncls__2210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__2211); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A_fn_class = fncls__2210d; tmp3 = fncls__2210d } else { tmp3 = fncls__2210 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2211, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2212 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any; var root_2217 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2217, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2219 lang.IFn; if linked_2218 == nil { ifn_2219 = lang.IFn_Cast(root_2217) } else { ifn_2219 = nil }; var arg_2220 any = b__1991000292__6; if linked_2218 == nil { arg_2215 = ifn_2219.Invoke_O__O(arg_2220) } else { arg_2215 = linked_2218.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2217, arg_2220) }; var arg_2216 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000289); var tmp5 any; var root_2221 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = s__1991000290__3; if linked_2222 == nil { tmp5 = ifn_2223.Invoke_O__O(arg_2224) } else { tmp5 = linked_2222.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2221, arg_2224) }; arg_2216 = tmp4.Invoke_O__O(tmp5); if linked_2213 == nil { return ifn_2214.Invoke_O_O__O(arg_2215, arg_2216) } else { return linked_2213.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2212, arg_2215, arg_2216) } } else { var root_2225 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any; var root_2230 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2232 lang.IFn; if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any = b__1991000292__6; if linked_2231 == nil { arg_2228 = ifn_2232.Invoke_O__O(arg_2233) } else { arg_2228 = linked_2231.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2230, arg_2233) }; var arg_2229 any; if linked_2226 == nil { return ifn_2227.Invoke_O_O__O(arg_2228, arg_2229) } else { return linked_2226.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2225, arg_2228, arg_2229) } } } else { var part__4 any; var root_2234 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any = s__1991000290__3; if linked_2235 == nil { part__4 = ifn_2236.Invoke_O__O(arg_2237) } else { part__4 = linked_2235.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2234, arg_2237) }; var root_2238 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2240 lang.IFn; if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_110; var tmp8 any = A_arbace_j2g_embed_A_const_111; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_A_const_112; var tmp12 any; var root_2243 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2245 lang.IFn


	if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = A_arbace_j2g_embed_A_const_106.GetRawRoot__O(); var arg_2247 any = A_arbace_j2g_embed_A_const_113; var arg_2248 any = A_arbace_j2g_embed_A_const_117; var arg_2249 any; var iter__1927001039__auto____5 any; var fnbody__2311 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A_New(); var tmp13 *jrt.Class; var fncls__2310 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A_fn_class
	if fncls__2310 == nil { var fncls__2310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A_fn_class = fncls__2310d; tmp13 = fncls__2310d } else { tmp13 = fncls__2310 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2311, tmp13, nil); arg_2249 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(part__4)
//line :348:1
	if linked_2244 == nil { tmp12 = ifn_2245.Invoke_O_O_O_O__O(arg_2246, arg_2247, arg_2248, arg_2249) } else { tmp12 = linked_2244.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2243, arg_2246, arg_2247, arg_2248, arg_2249) }
//line :346:1
	arg_2241 = tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :345:1
	var arg_2242 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1991000289); var tmp15 any; var root_2312 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = s__1991000290__3; if linked_2313 == nil { tmp15 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp15 = linked_2313.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2312, arg_2315) }; arg_2242 = tmp14.Invoke_O__O(tmp15); if linked_2239 == nil { return ifn_2240.Invoke_O_O__O(arg_2241, arg_2242) } else { return linked_2239.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2238, arg_2241, arg_2242) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :345:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :345:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A) Ctor_O_I_O(c__b__1991000292 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000292 = c__b__1991000292; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :345:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A) Invoke_O__O(self any) any { { var i__1991000291__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000291__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var part__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000291__1)); var root_2136 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = t.F_b__1991000292; var arg_2140 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_110; var tmp4 any = A_arbace_j2g_embed_A_const_111; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_112; var tmp8 any; var root_2141 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_2142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2141, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2143 lang.IFn


	if linked_2142 == nil { ifn_2143 = lang.IFn_Cast(root_2141) } else { ifn_2143 = nil }; var arg_2144 any = A_arbace_j2g_embed_A_const_106.GetRawRoot__O(); var arg_2145 any = A_arbace_j2g_embed_A_const_113; var arg_2146 any = A_arbace_j2g_embed_A_const_114; var arg_2147 any; var iter__1927001039__auto____3 any; var fnbody__2209 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A_New(); var tmp9 *jrt.Class; var fncls__2208 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A_fn_class
	if fncls__2208 == nil { var fncls__2208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A_fn_class = fncls__2208d; tmp9 = fncls__2208d } else { tmp9 = fncls__2208 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2209, tmp9, nil); arg_2147 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(part__2)
//line :348:1
	if linked_2142 == nil { tmp8 = ifn_2143.Invoke_O_O_O_O__O(arg_2144, arg_2145, arg_2146, arg_2147) } else { tmp8 = linked_2142.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2141, arg_2144, arg_2145, arg_2146, arg_2147) }
//line :346:1
	arg_2140 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :345:1
	if linked_2137 == nil { ifn_2138.Invoke_O_O__O(arg_2139, arg_2140) } else { linked_2137.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2136, arg_2139, arg_2140) }; i__1991000291__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000291__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A) Ctor() {}
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A) Invoke_O_O__O(self, s__1991000297__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2207 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A_New_O_O(s__1991000297__1, self); var tmp2 *jrt.Class; var fncls__2206 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A_fn_class; if fncls__2206 == nil { var fncls__2206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__2207); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A_fn_class = fncls__2206d; tmp2 = fncls__2206d } else { tmp2 = fncls__2206 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2207, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :349:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A{}; t.Ctor_O_O(p0, p1); return t }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A) Ctor_O_O(c__s__1991000297, c__iter__1991000296 any) { t.F_s__1991000297 = c__s__1991000297; t.F_iter__1991000296 = c__iter__1991000296 }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A) Invoke_O__O(self any) any { { var s__1991000297__1 any; var t_ any = t.F_s__1991000297; t.F_s__1991000297 = nil; s__1991000297__1 = t_; for { var temp__1927000414__auto____2 any; var root_2148 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = s__1991000297__1; if linked_2149 == nil { temp__1927000414__auto____2 = ifn_2150.Invoke_O__O(arg_2151) } else { temp__1927000414__auto____2 = linked_2149.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2148, arg_2151) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000297__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2152 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = s__1991000297__3; if linked_2153 == nil { tmp1 = ifn_2154.Invoke_O__O(arg_2155) } else { tmp1 = linked_2153.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2152, arg_2155) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2156 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = s__1991000297__3; if linked_2157 == nil { c__1927001037__auto____4 = ifn_2158.Invoke_O__O(arg_2159) } else { c__1927001037__auto____4 = linked_2157.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2156, arg_2159) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000299__6 any; var root_2160 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2161 == nil { b__1991000299__6 = ifn_2162.Invoke_O__O(arg_2163) } else { b__1991000299__6 = linked_2161.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2160, arg_2163) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2170 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000299__6); var tmp3 *jrt.Class; var fncls__2169 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A_fn_class; if fncls__2169 == nil { var fncls__2169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__2170); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A_fn_class = fncls__2169d; tmp3 = fncls__2169d } else { tmp3 = fncls__2169 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2170, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2171 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2173 lang.IFn; if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any; var root_2176 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2178 lang.IFn; if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any = b__1991000299__6; if linked_2177 == nil { arg_2174 = ifn_2178.Invoke_O__O(arg_2179) } else { arg_2174 = linked_2177.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2176, arg_2179) }; var arg_2175 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000296); var tmp5 any; var root_2180 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_2181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2180, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2182 lang.IFn; if linked_2181 == nil { ifn_2182 = lang.IFn_Cast(root_2180) } else { ifn_2182 = nil }; var arg_2183 any = s__1991000297__3; if linked_2181 == nil { tmp5 = ifn_2182.Invoke_O__O(arg_2183) } else { tmp5 = linked_2181.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2180, arg_2183) }; arg_2175 = tmp4.Invoke_O__O(tmp5); if linked_2172 == nil { return ifn_2173.Invoke_O_O__O(arg_2174, arg_2175) } else { return linked_2172.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2171, arg_2174, arg_2175) } } else { var root_2184 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2184, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2186 lang.IFn; if linked_2185 == nil { ifn_2186 = lang.IFn_Cast(root_2184) } else { ifn_2186 = nil }; var arg_2187 any; var root_2189 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any = b__1991000299__6; if linked_2190 == nil { arg_2187 = ifn_2191.Invoke_O__O(arg_2192) } else { arg_2187 = linked_2190.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2189, arg_2192) }; var arg_2188 any; if linked_2185 == nil { return ifn_2186.Invoke_O_O__O(arg_2187, arg_2188) } else { return linked_2185.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2184, arg_2187, arg_2188) } } } else { var t__4 any; var root_2193 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = s__1991000297__3; if linked_2194 == nil { t__4 = ifn_2195.Invoke_O__O(arg_2196) } else { t__4 = linked_2194.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2193, arg_2196) }; var root_2197 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_115; var arg_2200 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_116, t__4)); var arg_2201 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000296); var tmp9 any; var root_2202 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = s__1991000297__3; if linked_2203 == nil { tmp9 = ifn_2204.Invoke_O__O(arg_2205) } else { tmp9 = linked_2203.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2202, arg_2205) }; arg_2201 = tmp8.Invoke_O__O(tmp9); if linked_2198 == nil { return ifn_2199.Invoke_O_O__O(arg_2200, arg_2201) } else { return linked_2198.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2197, arg_2200, arg_2201) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000299 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000299 = c__b__1991000299 }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A) Invoke_O__O(self any) any { { var i__1991000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000298__1)); var root_2164 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2166 lang.IFn; if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = t.F_b__1991000299; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_115; var arg_2168 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_116, t__2)); if linked_2165 == nil { ifn_2166.Invoke_O_O__O(arg_2167, arg_2168) } else { linked_2165.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2164, arg_2167, arg_2168) }; i__1991000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000298__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A) Ctor() {}
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A) Invoke_O_O__O(self, s__1991000308__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2309 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A_New_O_O(self, s__1991000308__1); var tmp2 *jrt.Class; var fncls__2308 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A_fn_class; if fncls__2308 == nil { var fncls__2308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__2309); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A_fn_class = fncls__2308d; tmp2 = fncls__2308d } else { tmp2 = fncls__2308 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2309, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :349:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A{}; t.Ctor_O_O(p0, p1); return t }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A) Ctor_O_O(c__iter__1991000307, c__s__1991000308 any) { t.F_iter__1991000307 = c__iter__1991000307; t.F_s__1991000308 = c__s__1991000308 }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A) Invoke_O__O(self any) any { { var s__1991000308__1 any; var t_ any = t.F_s__1991000308; t.F_s__1991000308 = nil; s__1991000308__1 = t_; for { var temp__1927000414__auto____2 any; var root_2250 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_2251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2252 lang.IFn; if linked_2251 == nil { ifn_2252 = lang.IFn_Cast(root_2250) } else { ifn_2252 = nil }; var arg_2253 any = s__1991000308__1; if linked_2251 == nil { temp__1927000414__auto____2 = ifn_2252.Invoke_O__O(arg_2253) } else { temp__1927000414__auto____2 = linked_2251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2250, arg_2253) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000308__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2254 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = s__1991000308__3; if linked_2255 == nil { tmp1 = ifn_2256.Invoke_O__O(arg_2257) } else { tmp1 = linked_2255.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2254, arg_2257) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2258 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = s__1991000308__3; if linked_2259 == nil { c__1927001037__auto____4 = ifn_2260.Invoke_O__O(arg_2261) } else { c__1927001037__auto____4 = linked_2259.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2258, arg_2261) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000310__6 any; var root_2262 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2263 == nil { b__1991000310__6 = ifn_2264.Invoke_O__O(arg_2265) } else { b__1991000310__6 = linked_2263.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2262, arg_2265) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2272 any = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000310__6); var tmp3 *jrt.Class; var fncls__2271 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A_fn_class; if fncls__2271 == nil { var fncls__2271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__2272); A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A_fn_class = fncls__2271d; tmp3 = fncls__2271d } else { tmp3 = fncls__2271 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2272, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2273 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2275 lang.IFn; if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any; var root_2278 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = b__1991000310__6; if linked_2279 == nil { arg_2276 = ifn_2280.Invoke_O__O(arg_2281) } else { arg_2276 = linked_2279.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2278, arg_2281) }; var arg_2277 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000307); var tmp5 any; var root_2282 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2284 lang.IFn; if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = s__1991000308__3; if linked_2283 == nil { tmp5 = ifn_2284.Invoke_O__O(arg_2285) } else { tmp5 = linked_2283.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2282, arg_2285) }; arg_2277 = tmp4.Invoke_O__O(tmp5); if linked_2274 == nil { return ifn_2275.Invoke_O_O__O(arg_2276, arg_2277) } else { return linked_2274.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2273, arg_2276, arg_2277) } } else { var root_2286 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any; var root_2291 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2293 lang.IFn; if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any = b__1991000310__6; if linked_2292 == nil { arg_2289 = ifn_2293.Invoke_O__O(arg_2294) } else { arg_2289 = linked_2292.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2291, arg_2294) }; var arg_2290 any; if linked_2287 == nil { return ifn_2288.Invoke_O_O__O(arg_2289, arg_2290) } else { return linked_2287.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2286, arg_2289, arg_2290) } } } else { var t__4 any; var root_2295 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any = s__1991000308__3; if linked_2296 == nil { t__4 = ifn_2297.Invoke_O__O(arg_2298) } else { t__4 = linked_2296.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2295, arg_2298) }; var root_2299 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_115; var arg_2302 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_116, t__4)); var arg_2303 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000307); var tmp9 any; var root_2304 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2304, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2306 lang.IFn; if linked_2305 == nil { ifn_2306 = lang.IFn_Cast(root_2304) } else { ifn_2306 = nil }; var arg_2307 any = s__1991000308__3; if linked_2305 == nil { tmp9 = ifn_2306.Invoke_O__O(arg_2307) } else { tmp9 = linked_2305.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2304, arg_2307) }; arg_2303 = tmp8.Invoke_O__O(tmp9); if linked_2300 == nil { return ifn_2301.Invoke_O_O__O(arg_2302, arg_2303) } else { return linked_2300.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2299, arg_2302, arg_2303) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000310 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000310 = c__b__1991000310 }
//line :349:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A) Invoke_O__O(self any) any { { var i__1991000309__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000309__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000309__1)); var root_2266 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = t.F_b__1991000310; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_115; var arg_2270 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_106.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_116, t__2)); if linked_2267 == nil { ifn_2268.Invoke_O_O__O(arg_2269, arg_2270) } else { linked_2267.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2266, arg_2269, arg_2270) }; i__1991000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000309__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

































































































































































































































































type A_arbace_j2g_embed_A struct{ jrt.Object }

var A_arbace_j2g_embed_A_const_pool *jrt.RefArray

var A_arbace_j2g_embed_A_const_0 *lang.Var

var A_arbace_j2g_embed_A_const_1 any

var A_arbace_j2g_embed_A_const_2 *lang.Var

var A_arbace_j2g_embed_A_const_3 any

var A_arbace_j2g_embed_A_const_4 any

var A_arbace_j2g_embed_A_const_5 any

var A_arbace_j2g_embed_A_const_6 any

var A_arbace_j2g_embed_A_const_7 *lang.Var

var A_arbace_j2g_embed_A_const_8 *lang.Var

var A_arbace_j2g_embed_A_const_9 *lang.Var

var A_arbace_j2g_embed_A_const_10 *lang.Var

var A_arbace_j2g_embed_A_const_11 any

var A_arbace_j2g_embed_A_const_12 *lang.Var

var A_arbace_j2g_embed_A_const_13 *lang.Var

var A_arbace_j2g_embed_A_const_14 *lang.Var

var A_arbace_j2g_embed_A_const_15 *lang.Var

var A_arbace_j2g_embed_A_const_16 *lang.Var

var A_arbace_j2g_embed_A_const_17 *lang.Var

var A_arbace_j2g_embed_A_const_18 *lang.Var

var A_arbace_j2g_embed_A_const_19 *lang.Var

var A_arbace_j2g_embed_A_const_20 *lang.Var

var A_arbace_j2g_embed_A_const_21 *lang.Var

var A_arbace_j2g_embed_A_const_22 *lang.Var

var A_arbace_j2g_embed_A_const_23 *lang.Var

var A_arbace_j2g_embed_A_const_24 *lang.Var

var A_arbace_j2g_embed_A_const_25 *lang.Var

var A_arbace_j2g_embed_A_const_26 *lang.Var

var A_arbace_j2g_embed_A_const_27 *lang.Var

var A_arbace_j2g_embed_A_const_28 *lang.Var

var A_arbace_j2g_embed_A_const_29 *lang.Var

var A_arbace_j2g_embed_A_const_30 *lang.Var

var A_arbace_j2g_embed_A_const_31 *lang.Var

var A_arbace_j2g_embed_A_const_32 *lang.Var

var A_arbace_j2g_embed_A_const_33 *lang.Var

var A_arbace_j2g_embed_A_const_34 any

var A_arbace_j2g_embed_A_const_35 *lang.Var

var A_arbace_j2g_embed_A_const_36 any

var A_arbace_j2g_embed_A_const_37 *lang.Var

var A_arbace_j2g_embed_A_const_38 *lang.Var

var A_arbace_j2g_embed_A_const_39 *lang.Var

var A_arbace_j2g_embed_A_const_40 *lang.Var

var A_arbace_j2g_embed_A_const_41 *lang.Var

var A_arbace_j2g_embed_A_const_42 *lang.Keyword

var A_arbace_j2g_embed_A_const_43 *lang.Var

var A_arbace_j2g_embed_A_const_44 *lang.Var

var A_arbace_j2g_embed_A_const_45 *lang.Var

var A_arbace_j2g_embed_A_const_46 *lang.Var

var A_arbace_j2g_embed_A_const_47 *lang.Var

var A_arbace_j2g_embed_A_const_48 *lang.Var

var A_arbace_j2g_embed_A_const_49 any

var A_arbace_j2g_embed_A_const_50 *lang.Var

var A_arbace_j2g_embed_A_const_51 any

var A_arbace_j2g_embed_A_const_52 *lang.Keyword

var A_arbace_j2g_embed_A_const_53 *lang.Var

var A_arbace_j2g_embed_A_const_54 *lang.Var

var A_arbace_j2g_embed_A_const_55 *lang.Var

var A_arbace_j2g_embed_A_const_56 *lang.Var

var A_arbace_j2g_embed_A_const_57 *lang.Var

var A_arbace_j2g_embed_A_const_58 *lang.Var

var A_arbace_j2g_embed_A_const_59 *lang.Var

var A_arbace_j2g_embed_A_const_60 *lang.Var

var A_arbace_j2g_embed_A_const_61 *lang.Var

var A_arbace_j2g_embed_A_const_62 *lang.Var

var A_arbace_j2g_embed_A_const_63 *lang.Var

var A_arbace_j2g_embed_A_const_64 *lang.Var

var A_arbace_j2g_embed_A_const_65 *lang.Var

var A_arbace_j2g_embed_A_const_66 *lang.Var

var A_arbace_j2g_embed_A_const_67 *lang.Var

var A_arbace_j2g_embed_A_const_68 *lang.Var

var A_arbace_j2g_embed_A_const_69 *lang.Var

var A_arbace_j2g_embed_A_const_70 *lang.Var

var A_arbace_j2g_embed_A_const_71 *lang.Var

var A_arbace_j2g_embed_A_const_72 *lang.Var

var A_arbace_j2g_embed_A_const_73 *lang.Var

var A_arbace_j2g_embed_A_const_74 *lang.Var

var A_arbace_j2g_embed_A_const_75 *lang.Var

var A_arbace_j2g_embed_A_const_76 *lang.Var

var A_arbace_j2g_embed_A_const_77 *lang.Var

var A_arbace_j2g_embed_A_const_78 any

var A_arbace_j2g_embed_A_const_79 any

var A_arbace_j2g_embed_A_const_80 *lang.Var

var A_arbace_j2g_embed_A_const_81 *lang.Keyword

var A_arbace_j2g_embed_A_const_82 *lang.Var

var A_arbace_j2g_embed_A_const_83 *lang.Var

var A_arbace_j2g_embed_A_const_84 *lang.Var

var A_arbace_j2g_embed_A_const_85 *lang.Var

var A_arbace_j2g_embed_A_const_86 *lang.Var

var A_arbace_j2g_embed_A_const_87 *lang.Var

var A_arbace_j2g_embed_A_const_88 *lang.Var

var A_arbace_j2g_embed_A_const_89 *lang.Var

var A_arbace_j2g_embed_A_const_90 *lang.Var

var A_arbace_j2g_embed_A_const_91 *lang.Var

var A_arbace_j2g_embed_A_const_92 *lang.Var

var A_arbace_j2g_embed_A_const_93 *lang.Var

var A_arbace_j2g_embed_A_const_94 any

var A_arbace_j2g_embed_A_const_95 *lang.Var

var A_arbace_j2g_embed_A_const_96 *lang.Keyword

var A_arbace_j2g_embed_A_const_97 *lang.Var

var A_arbace_j2g_embed_A_const_98 any

var A_arbace_j2g_embed_A_const_99 any

var A_arbace_j2g_embed_A_const_100 *lang.Var

var A_arbace_j2g_embed_A_const_101 any

var A_arbace_j2g_embed_A_const_102 *lang.Var

var A_arbace_j2g_embed_A_const_103 any

var A_arbace_j2g_embed_A_const_104 *lang.Var

var A_arbace_j2g_embed_A_const_105 *lang.Var

var A_arbace_j2g_embed_A_const_106 *lang.Var

var A_arbace_j2g_embed_A_const_107 any

var A_arbace_j2g_embed_A_const_108 *lang.Keyword

var A_arbace_j2g_embed_A_const_109 any

var A_arbace_j2g_embed_A_const_110 any

var A_arbace_j2g_embed_A_const_111 any

var A_arbace_j2g_embed_A_const_112 any

var A_arbace_j2g_embed_A_const_113 any

var A_arbace_j2g_embed_A_const_114 any

var A_arbace_j2g_embed_A_const_115 any

var A_arbace_j2g_embed_A_const_116 any

var A_arbace_j2g_embed_A_const_117 any

var A_arbace_j2g_embed_A_const_118 *lang.Var

var A_arbace_j2g_embed_A_const_119 any

var A_arbace_j2g_embed_A_const_120 any

var A_arbace_j2g_embed_A_init jrt.ClassInit

func A_arbace_j2g_embed_A_Init() { if !A_arbace_j2g_embed_A_init.Done() { A_arbace_j2g_embed_A_init.Run(A_arbace_j2g_embed_A_clinit) } }

func A_arbace_j2g_embed_A_clinit() { A_arbace_j2g_embed_A_clinit_p0(); A_arbace_j2g_embed_A_clinit_p1(); A_arbace_j2g_embed_A_clinit_p2(); A_arbace_j2g_embed_A_clinit_p3(); A_arbace_j2g_embed_A_clinit_p4(); A_arbace_j2g_embed_A_clinit_p5(); A_arbace_j2g_embed_A_clinit_p6(); A_arbace_j2g_embed_A_clinit_p7(); A_arbace_j2g_embed_A_clinit_p8(); A_arbace_j2g_embed_A_clinit_p9() }

func A_arbace_j2g_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 155); A_arbace_j2g_embed_A_const_0 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[34]); A_arbace_j2g_embed_A_const_1 = A_arbace_j2g_embed_A_const_pool.A[35]; A_arbace_j2g_embed_A_const_2 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[36]); A_arbace_j2g_embed_A_const_3 = A_arbace_j2g_embed_A_const_pool.A[37]; A_arbace_j2g_embed_A_const_4 = A_arbace_j2g_embed_A_const_pool.A[38]; A_arbace_j2g_embed_A_const_5 = A_arbace_j2g_embed_A_const_pool.A[39]; A_arbace_j2g_embed_A_const_6 = A_arbace_j2g_embed_A_const_pool.A[40]; A_arbace_j2g_embed_A_const_7 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[41]); A_arbace_j2g_embed_A_const_8 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[42]); A_arbace_j2g_embed_A_const_9 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[43]); A_arbace_j2g_embed_A_const_10 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[44]); A_arbace_j2g_embed_A_const_11 = A_arbace_j2g_embed_A_const_pool.A[45] }

func A_arbace_j2g_embed_A_clinit_p1() { A_arbace_j2g_embed_A_const_12 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[46]); A_arbace_j2g_embed_A_const_13 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[47]); A_arbace_j2g_embed_A_const_14 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[48]); A_arbace_j2g_embed_A_const_15 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[49]); A_arbace_j2g_embed_A_const_16 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[50]); A_arbace_j2g_embed_A_const_17 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[51]); A_arbace_j2g_embed_A_const_18 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[52]); A_arbace_j2g_embed_A_const_19 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[53]); A_arbace_j2g_embed_A_const_20 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[54]); A_arbace_j2g_embed_A_const_21 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[55]); A_arbace_j2g_embed_A_const_22 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[56]); A_arbace_j2g_embed_A_const_23 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[57]) }

func A_arbace_j2g_embed_A_clinit_p2() { A_arbace_j2g_embed_A_const_24 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[58]); A_arbace_j2g_embed_A_const_25 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[59]); A_arbace_j2g_embed_A_const_26 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[60]); A_arbace_j2g_embed_A_const_27 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[61]); A_arbace_j2g_embed_A_const_28 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[62]); A_arbace_j2g_embed_A_const_29 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[63]); A_arbace_j2g_embed_A_const_30 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[64]); A_arbace_j2g_embed_A_const_31 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[65]); A_arbace_j2g_embed_A_const_32 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[66]); A_arbace_j2g_embed_A_const_33 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[67]); A_arbace_j2g_embed_A_const_34 = A_arbace_j2g_embed_A_const_pool.A[68]; A_arbace_j2g_embed_A_const_35 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[69]) }

func A_arbace_j2g_embed_A_clinit_p3() { A_arbace_j2g_embed_A_const_36 = A_arbace_j2g_embed_A_const_pool.A[70]; A_arbace_j2g_embed_A_const_37 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[71]); A_arbace_j2g_embed_A_const_38 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[72]); A_arbace_j2g_embed_A_const_39 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[73]); A_arbace_j2g_embed_A_const_40 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[74]); A_arbace_j2g_embed_A_const_41 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[75]); A_arbace_j2g_embed_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[76]); A_arbace_j2g_embed_A_const_43 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[77]); A_arbace_j2g_embed_A_const_44 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[78]); A_arbace_j2g_embed_A_const_45 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[79]); A_arbace_j2g_embed_A_const_46 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[80]); A_arbace_j2g_embed_A_const_47 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[81]) }

func A_arbace_j2g_embed_A_clinit_p4() { A_arbace_j2g_embed_A_const_48 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[82]); A_arbace_j2g_embed_A_const_49 = A_arbace_j2g_embed_A_const_pool.A[83]; A_arbace_j2g_embed_A_const_50 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[84]); A_arbace_j2g_embed_A_const_51 = A_arbace_j2g_embed_A_const_pool.A[85]; A_arbace_j2g_embed_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[86]); A_arbace_j2g_embed_A_const_53 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[87]); A_arbace_j2g_embed_A_const_54 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[88]); A_arbace_j2g_embed_A_const_55 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[89]); A_arbace_j2g_embed_A_const_56 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[90]); A_arbace_j2g_embed_A_const_57 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[91]); A_arbace_j2g_embed_A_const_58 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[92]); A_arbace_j2g_embed_A_const_59 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[93]) }

func A_arbace_j2g_embed_A_clinit_p5() { A_arbace_j2g_embed_A_const_60 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[94]); A_arbace_j2g_embed_A_const_61 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[95]); A_arbace_j2g_embed_A_const_62 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[96]); A_arbace_j2g_embed_A_const_63 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[97]); A_arbace_j2g_embed_A_const_64 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[98]); A_arbace_j2g_embed_A_const_65 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[99]); A_arbace_j2g_embed_A_const_66 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[100]); A_arbace_j2g_embed_A_const_67 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[101]); A_arbace_j2g_embed_A_const_68 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[102]); A_arbace_j2g_embed_A_const_69 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[103]); A_arbace_j2g_embed_A_const_70 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[104]); A_arbace_j2g_embed_A_const_71 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[105]) }

func A_arbace_j2g_embed_A_clinit_p6() { A_arbace_j2g_embed_A_const_72 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[106]); A_arbace_j2g_embed_A_const_73 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[107]); A_arbace_j2g_embed_A_const_74 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[108]); A_arbace_j2g_embed_A_const_75 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[109]); A_arbace_j2g_embed_A_const_76 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[110]); A_arbace_j2g_embed_A_const_77 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[111]); A_arbace_j2g_embed_A_const_78 = A_arbace_j2g_embed_A_const_pool.A[112]; A_arbace_j2g_embed_A_const_79 = A_arbace_j2g_embed_A_const_pool.A[113]; A_arbace_j2g_embed_A_const_80 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[114]); A_arbace_j2g_embed_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[115]); A_arbace_j2g_embed_A_const_82 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[116]); A_arbace_j2g_embed_A_const_83 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[117]) }

func A_arbace_j2g_embed_A_clinit_p7() { A_arbace_j2g_embed_A_const_84 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[118]); A_arbace_j2g_embed_A_const_85 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[119]); A_arbace_j2g_embed_A_const_86 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[120]); A_arbace_j2g_embed_A_const_87 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[121]); A_arbace_j2g_embed_A_const_88 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[122]); A_arbace_j2g_embed_A_const_89 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[123]); A_arbace_j2g_embed_A_const_90 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[124]); A_arbace_j2g_embed_A_const_91 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[125]); A_arbace_j2g_embed_A_const_92 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[126]); A_arbace_j2g_embed_A_const_93 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[127]); A_arbace_j2g_embed_A_const_94 = A_arbace_j2g_embed_A_const_pool.A[128]; A_arbace_j2g_embed_A_const_95 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[129]) }

func A_arbace_j2g_embed_A_clinit_p8() { A_arbace_j2g_embed_A_const_96 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[130]); A_arbace_j2g_embed_A_const_97 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[131]); A_arbace_j2g_embed_A_const_98 = A_arbace_j2g_embed_A_const_pool.A[132]; A_arbace_j2g_embed_A_const_99 = A_arbace_j2g_embed_A_const_pool.A[133]; A_arbace_j2g_embed_A_const_100 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[134]); A_arbace_j2g_embed_A_const_101 = A_arbace_j2g_embed_A_const_pool.A[135]; A_arbace_j2g_embed_A_const_102 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[136]); A_arbace_j2g_embed_A_const_103 = A_arbace_j2g_embed_A_const_pool.A[137]; A_arbace_j2g_embed_A_const_104 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[138]); A_arbace_j2g_embed_A_const_105 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[139]); A_arbace_j2g_embed_A_const_106 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[140]); A_arbace_j2g_embed_A_const_107 = A_arbace_j2g_embed_A_const_pool.A[141]; A_arbace_j2g_embed_A_const_108 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[142]) }

func A_arbace_j2g_embed_A_clinit_p9() { A_arbace_j2g_embed_A_const_109 = A_arbace_j2g_embed_A_const_pool.A[143]; A_arbace_j2g_embed_A_const_110 = A_arbace_j2g_embed_A_const_pool.A[144]; A_arbace_j2g_embed_A_const_111 = A_arbace_j2g_embed_A_const_pool.A[145]; A_arbace_j2g_embed_A_const_112 = A_arbace_j2g_embed_A_const_pool.A[146]; A_arbace_j2g_embed_A_const_113 = A_arbace_j2g_embed_A_const_pool.A[147]; A_arbace_j2g_embed_A_const_114 = A_arbace_j2g_embed_A_const_pool.A[148]; A_arbace_j2g_embed_A_const_115 = A_arbace_j2g_embed_A_const_pool.A[149]; A_arbace_j2g_embed_A_const_116 = A_arbace_j2g_embed_A_const_pool.A[150]; A_arbace_j2g_embed_A_const_117 = A_arbace_j2g_embed_A_const_pool.A[151]; A_arbace_j2g_embed_A_const_118 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[152]); A_arbace_j2g_embed_A_const_119 = A_arbace_j2g_embed_A_const_pool.A[153]; A_arbace_j2g_embed_A_const_120 = A_arbace_j2g_embed_A_const_pool.A[154] }

func A_arbace_j2g_embed_A_New() *A_arbace_j2g_embed_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_A) Ctor() {}

func (t *A_arbace_j2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_A_class }

func (t *A_arbace_j2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_A); return ok }

func A_arbace_j2g_embed_A_Cast(x any) *A_arbace_j2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_A_class)) }; return v }



type A_arbace_j2g_embed_class_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_class_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_fn__1991000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A struct{ j2g_header uint64; F_s__1991000098, F_iter__1991000097 any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1991000100, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_data_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A struct{ j2g_header uint64; F_s__1991000162, F_base, F_iter__1991000161 any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A struct{ j2g_header uint64; F_base, F_b__1991000164 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000004_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000004_A_New() *A_arbace_j2g_embed_eval1991000004_A { t := &A_arbace_j2g_embed_eval1991000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000004_A_class }

func (t *A_arbace_j2g_embed_eval1991000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); return ok }

func A_arbace_j2g_embed_eval1991000004_A_Cast(x any) *A_arbace_j2g_embed_eval1991000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000004_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000008_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000008_A_New() *A_arbace_j2g_embed_eval1991000008_A { t := &A_arbace_j2g_embed_eval1991000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000008_A_class }

func (t *A_arbace_j2g_embed_eval1991000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); return ok }

func A_arbace_j2g_embed_eval1991000008_A_Cast(x any) *A_arbace_j2g_embed_eval1991000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000008_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000008_fn__1991000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class *jrt.Class



type A_arbace_j2g_embed_generated_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_generated_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000268_A struct{ j2g_header uint64; F_re any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000268_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A struct{ j2g_header uint64; F_alias, F_s__1991000273, F_iter__1991000272 any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_b__1991000275, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000268_iter__1991000272__1991000276_fn__1991000277_fn__1991000278_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A struct{ j2g_header uint64; F_prog_dir any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A struct{ j2g_header uint64; F_prog_dir, F_s__1991000249, F_iter__1991000248 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A struct{ j2g_header uint64; F_alias, F_s__1991000251, F_iter__1991000250 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_b__1991000253, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000248__1991000254_fn__1991000255_iter__1991000250__1991000259_fn__1991000260_fn__1991000261_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A struct{ j2g_header uint64; F_s__1991000290, F_iter__1991000289 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A struct{ j2g_header uint64; F_b__1991000292 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A struct{ j2g_header uint64; F_s__1991000297, F_iter__1991000296 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000299 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_fn__1991000295_iter__1991000296__1991000300_fn__1991000301_fn__1991000302_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A struct{ j2g_header uint64; F_iter__1991000307, F_s__1991000308 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000310 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000289__1991000293_fn__1991000294_iter__1991000307__1991000311_fn__1991000312_fn__1991000313_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_names_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_walk__1991000068_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_embed_names_walk__1991000068_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_loaders_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A struct{ j2g_header uint64; F_taken any }

var A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A struct{ j2g_header uint64; F_taken, F_s__1991000232, F_iter__1991000231 any }

var A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A struct{ j2g_header uint64; F_taken, F_base any }

var A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A struct{ j2g_header uint64; F_taken, F_base, F_s__1991000234, F_iter__1991000233 any }

var A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A struct{ j2g_header uint64; F_b__1991000236, F_taken, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_package_loaders_iter__1991000231__1991000237_fn__1991000238_iter__1991000233__1991000239_fn__1991000240_fn__1991000241_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_fn__1991000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class *jrt.Class



type A_arbace_j2g_embed_reify__1991000061_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_LispReader_Resolver() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_IObj() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_IMeta() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_reify__1991000061_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_reify__1991000061_A_class }

func (t *A_arbace_j2g_embed_reify__1991000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_reify__1991000061_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_reify__1991000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_reify__1991000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_reify__1991000061_A); return ok }

func A_arbace_j2g_embed_reify__1991000061_A_Cast(x any) *A_arbace_j2g_embed_reify__1991000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_reify__1991000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_reify__1991000061_A_class)) }; return v }



type A_arbace_j2g_embed_resource_dir_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_resource_dir_names_A_fn_class *jrt.Class



type A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_A_fn_class *jrt.Class



type A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A struct{ j2g_header uint64; F_s__1991000221, F_iter__1991000220 any }

var A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_A_fn_class *jrt.Class



type A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000223 any }

var A_arbace_j2g_embed_resource_dir_names_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A struct{ j2g_header uint64; F_p, F_pairs, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A struct{ j2g_header uint64; F_p, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A struct{ j2g_header uint64; F_also, F_base any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A struct{ j2g_header uint64; F_also, F_base, F_s__1991000019, F_iter__1991000018 any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A struct{ j2g_header uint64; F_also, F_base, F_b__1991000021 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A struct{ j2g_header uint64; F_vdir any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A struct{ j2g_header uint64; F_vdir, F_s__1991000037, F_iter__1991000036 any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A struct{ j2g_header uint64; F_b__1991000039, F_vdir any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_user_resources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_fn__1991000201_A struct{ j2g_header uint64; F_spec, F_taken, F_plain any; F_k int64 }

var A_arbace_j2g_embed_user_resources_fn__1991000201_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A struct{ j2g_header uint64; F_base, F_prefix any }

var A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A struct{ j2g_header uint64; F_s__1991000190, F_base, F_prefix, F_iter__1991000189 any }

var A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A struct{ j2g_header uint64; F_base, F_prefix, F_b__1991000192 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_user_resources_iter__1991000189__1991000193_fn__1991000194_fn__1991000195_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A struct{ j2g_header uint64; F_k int64 }

var A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A struct{ j2g_header uint64; F_iter__1991000209 any; F_k int64; F_s__1991000210 any }

var A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A struct{ j2g_header uint64; F_k int64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000212 any }

var A_arbace_j2g_embed_user_resources_iter__1991000209__1991000213_fn__1991000214_fn__1991000215_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_elem__1991000126_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types, F_s__1991000143, F_iter__1991000142 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A struct{ j2g_header uint64; F_n, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A struct{ j2g_header uint64; F_in_world_QMARK_ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A struct{ j2g_header uint64; F_in_world_QMARK_, F_s__1991000145, F_iter__1991000144 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A struct{ j2g_header uint64; F_b__1991000147, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_A struct{ j2g_header uint64; F_elem, F_types any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A struct{ j2g_header uint64; F_s__1991000132, F_iter__1991000131 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000134 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class *jrt.Class
