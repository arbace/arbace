//line aot_arbace_j2g_embed.ae:1
package aot_arbace_j2g_embed

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_edge"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_New() *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed_A_const_1); lang.IFn_Cast(A_arbace_j2g_embed_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_3, A_arbace_j2g_embed_A_const_4, A_arbace_j2g_embed_A_const_5, A_arbace_j2g_embed_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_New() *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000008_fn__1991000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_embed_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_embed_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_embed_A_const_10.GetRawRoot__O(), A_arbace_j2g_embed_A_const_11) }


















































func A_arbace_j2g_embed_sources_A_New() *A_arbace_j2g_embed_sources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_j2g_embed_sources_A) Ctor() {}
//line :52:1
func (t *A_arbace_j2g_embed_sources_A) DoInvoke_O_O_O__O(self, root__0, p__1991000014__1 any) any { var vec__1991000015__3 any = p__1991000014__1; var also__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var base__5 any; var root_22 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_22, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_24 lang.IFn; if




	linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = root__0; var arg_26 any = Lit_45; if linked_23 == nil { base__5 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { base__5 = linked_23.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; var files__6 any; var iter__1927001039__auto____6 any; var fnbody__170 any = /*line :52:1*/A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_New_O_O(also__4, base__5); var tmp1 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class; if





	fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__170); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class = fncls__169d; tmp1 = fncls__169d } else { tmp1 = fncls__169 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp3 any; var root_394 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = base__5; if linked_395 == nil { tmp3 = ifn_396.Invoke_O__O(arg_397) } else { tmp3 = linked_395.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_394, arg_397) }; files__6 = tmp2.Invoke_O__O(tmp3); var vdir__7 any; var root_171 any = /*line :52:1*/A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_171, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_173 lang.IFn; if











	linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = root__0; var arg_175 any = A_arbace_j2g_embed_A_const_31.GetRawRoot__O(); if linked_172 == nil { vdir__7 = ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { vdir__7 = linked_172.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) }; var variants__8 any; if
	jrt.File_Cast(vdir__7).IsDirectory__Z() { var iter__1927001039__auto____8 any; var fnbody__267 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_New_O(vdir__7); var tmp4 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class
		if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__267); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class = fncls__266d; tmp4 = fncls__266d } else { tmp4 = fncls__266 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__267, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp6 any; var root_398 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = vdir__7; if linked_399 == nil { tmp6 = ifn_400.Invoke_O__O(arg_401) } else { tmp6 = linked_399.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_398, arg_401) }; variants__8 = tmp5.Invoke_O__O(tmp6) } else {
//line :65:1
			variants__8 = nil }; var root_268 any =



	A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any; var fnbody__380 any = A_arbace_j2g_embed_sources_fn__1991000047_A_New(); var tmp7 *jrt.Class; var fncls__379 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class; if fncls__379 == nil { var fncls__379d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class = fncls__379d; tmp7 = fncls__379d } else { tmp7 = fncls__379 }; arg_271 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__380, tmp7, nil); var arg_272 any; var root_381 any = A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_383 lang.IFn; if





















	linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_385 any = files__6; if linked_382 == nil { arg_272 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { arg_272 = linked_382.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) }; var arg_273 any; var root_389 any = /*line :69:1*/A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_391 lang.IFn; if






















	linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var arg_393 any = variants__8; if linked_390 == nil { arg_273 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { arg_273 = linked_390.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }; if /*line :69:1*/ linked_269 == nil { return ifn_270.Invoke_O_O_O__O(arg_271, arg_272, arg_273) } else { return linked_269.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_268, arg_271, arg_272, arg_273) } }
//line :58:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :58:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A) Ctor_O_O(c__also, c__base any) { t.F_also = c__also; t.F_base = c__base }
//line :58:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A) Invoke_O_O__O(self, s__1991000019__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_New_O_O_O_O(t.F_also, t.F_base, s__1991000019__1, self); var tmp2 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__168); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class = fncls__167d; tmp2 = fncls__167d } else { tmp2 = fncls__167 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :58:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :58:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A) Ctor_O_O_O_O(c__also, c__base, c__s__1991000019, c__iter__1991000018 any) { t.F_also = c__also; t.F_base = c__base; t.F_s__1991000019 = c__s__1991000019; t.F_iter__1991000018 = c__iter__1991000018 }
//line :58:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A) Invoke_O__O(self any) any { { var s__1991000019__1 any; var t_ any = t.F_s__1991000019; t.F_s__1991000019 = nil; s__1991000019__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_27 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = s__1991000019__1; if linked_28 == nil { temp__1927000414__auto____2 = ifn_29.Invoke_O__O(arg_30) } else { temp__1927000414__auto____2 = linked_28.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_27, arg_30) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000019__3 any = temp__1927000414__auto____2; var tmp1 any; var root_31 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__1991000019__3; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_35 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__1991000019__3; if linked_36 == nil { c__1927001037__auto____4 = ifn_37.Invoke_O__O(arg_38) } else { c__1927001037__auto____4 = linked_36.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_35, arg_38) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000021__6 any; var root_39 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_40 == nil { b__1991000021__6 = ifn_41.Invoke_O__O(arg_42) } else { b__1991000021__6 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_39, arg_42) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_New_O_O_O_I_O(t.F_also, t.F_base, b__1991000021__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__86); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_87 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var root_92 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = b__1991000021__6; if linked_93 == nil { arg_90 = ifn_94.Invoke_O__O(arg_95) } else { arg_90 = linked_93.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_92, arg_95) }; var arg_91 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000018); var tmp5 any; var root_96 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = s__1991000019__3; if linked_97 == nil { tmp5 = ifn_98.Invoke_O__O(arg_99) } else { tmp5 = linked_97.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_96, arg_99) }; arg_91 = tmp4.Invoke_O__O(tmp5); if linked_88 == nil { return ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { return linked_88.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_87, arg_90, arg_91) } } else { var root_100 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any; var root_105 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = b__1991000021__6; if linked_106 == nil { arg_103 = ifn_107.Invoke_O__O(arg_108) } else { arg_103 = linked_106.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_105, arg_108) }; var arg_104 any; if linked_101 == nil { return ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { return linked_101.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) } } } else { var f__4 any; var root_109 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = s__1991000019__3; if linked_110 == nil { f__4 = ifn_111.Invoke_O__O(arg_112) } else { f__4 = linked_110.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_109, arg_112) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()
														if and__1927000168__auto____5 { var root_113 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_117 any = Lit_28; if linked_114 == nil { tmp6 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp6 = linked_114.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_113, arg_116, arg_117) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :58:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_50, nil); var tmp8 any; var root_118 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_120 lang.IFn

		if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_119 == nil { tmp8 = ifn_120.Invoke_O__O(arg_121) } else { tmp8 = linked_119.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_118, arg_121) }; rel__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :58:1
		var tmp9 any; var or__1927000174__auto____6 any; var root_122 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_124 lang.IFn


		if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any; var fnbody__133 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_New_O(rel__5); var tmp10 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__133); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class = fncls__132d; tmp10 = fncls__132d } else { tmp10 = fncls__132 }; arg_125 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__133, tmp10, nil); var arg_126 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_123 == nil { or__1927000174__auto____6 = ifn_124.Invoke_O_O__O(arg_125, arg_126) } else { or__1927000174__auto____6 = linked_123.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_122, arg_125, arg_126) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else {
			var root_134 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any; var fnbody__145 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_New_O(rel__5); var tmp11 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__145); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class = fncls__144d; tmp11 = fncls__144d } else { tmp11 = fncls__144 }; arg_137 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp11, nil); var arg_138 any = t.F_also; if linked_135 == nil { tmp9 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { tmp9 = linked_135.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) } }
//line :58:1
		if jrt.J2g_Truth(tmp9) { var root_146 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_150 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1991000018); var tmp13 any; var root_155 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__1991000019__3; if linked_156 == nil { tmp13 = ifn_157.Invoke_O__O(arg_158) } else { tmp13 = linked_156.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_155, arg_158) }; arg_150 = tmp12.Invoke_O__O(tmp13); if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else { var tmp14 any; var root_159 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = s__1991000019__3; if linked_160 == nil { tmp14 = ifn_161.Invoke_O__O(arg_162) } else { tmp14 = linked_160.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_159, arg_162) }; s__1991000019__1 = tmp14; continue L1 } } else { var tmp15 any; var root_163 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = s__1991000019__3; if linked_164 == nil { tmp15 = ifn_165.Invoke_O__O(arg_166) } else { tmp15 = linked_164.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_163, arg_166) }; s__1991000019__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :58:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :58:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A) Ctor_O_O_O_I_O(c__also, c__base, c__b__1991000021 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_also = c__also; t.F_base = c__base; t.F_b__1991000021 = c__b__1991000021; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :58:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A) Invoke_O__O(self any) any { { var i__1991000020__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000020__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000020__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()
																if and__1927000168__auto____3 { var root_43 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_47 any = Lit_28; if linked_44 == nil { tmp2 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp2 = linked_44.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_43, arg_46, arg_47) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :58:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_50, nil); var tmp4 any; var root_48 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_50 lang.IFn

		if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_49 == nil { tmp4 = ifn_50.Invoke_O__O(arg_51) } else { tmp4 = linked_49.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_48, arg_51) }; rel__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :58:1
		var tmp5 any; var or__1927000174__auto____4 any; var root_52 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_54 lang.IFn


		if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any; var fnbody__63 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_New_O(rel__3); var tmp6 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__63); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class = fncls__62d; tmp6 = fncls__62d } else { tmp6 = fncls__62 }; arg_55 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp6, nil); var arg_56 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_53 == nil { or__1927000174__auto____4 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { or__1927000174__auto____4 = linked_53.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else {
			var root_64 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var fnbody__75 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_New_O(rel__3); var tmp7 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__75); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class = fncls__74d; tmp7 = fncls__74d } else { tmp7 = fncls__74 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp7, nil); var arg_68 any = t.F_also; if linked_65 == nil { tmp5 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { tmp5 = linked_65.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) } }
//line :58:1
		if jrt.J2g_Truth(tmp5) { var root_76 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = t.F_b__1991000021; var arg_80 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_77 == nil { ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { linked_77.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_76, arg_79, arg_80) }; i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } else { i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } } else { i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_57 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = t.F_rel; var arg_61 any = p1__1991000012_SHARP___1; if linked_58 == nil { return ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { return linked_58.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } }
//line :61:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_127 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = t.F_rel; var arg_131 any = p1__1991000012_SHARP___1; if linked_128 == nil { return ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { return linked_128.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) } }
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :62:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A) Invoke_O_O__O(self, p1__1991000013_SHARP___1 any) any { var root_69 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = t.F_rel; var arg_73 any = p1__1991000013_SHARP___1; if linked_70 == nil { return ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { return linked_70.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_69, arg_72, arg_73) } }
//line :62:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :62:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A) Invoke_O_O__O(self, p1__1991000013_SHARP___1 any) any { var root_139 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = t.F_rel; var arg_143 any = p1__1991000013_SHARP___1; if linked_140 == nil { return ifn_141.Invoke_O_O__O(arg_142, arg_143) } else { return linked_140.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_139, arg_142, arg_143) } }



func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :66:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A) Invoke_O_O__O(self, s__1991000037__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__265 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_New_O_O_O(t.F_vdir, s__1991000037__1, self); var tmp2 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__265); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class = fncls__264d; tmp2 = fncls__264d } else { tmp2 = fncls__264 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__265, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :66:1
func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A) Ctor_O_O_O(c__vdir, c__s__1991000037, c__iter__1991000036 any) { t.F_vdir = c__vdir; t.F_s__1991000037 = c__s__1991000037; t.F_iter__1991000036 = c__iter__1991000036 }
//line :66:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A) Invoke_O__O(self any) any { { var s__1991000037__1 any; var t_ any = t.F_s__1991000037; t.F_s__1991000037 = nil; s__1991000037__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_176 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__1991000037__1; if linked_177 == nil { temp__1927000414__auto____2 = ifn_178.Invoke_O__O(arg_179) } else { temp__1927000414__auto____2 = linked_177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_176, arg_179) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000037__3 any = temp__1927000414__auto____2; var tmp1 any; var root_180 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = s__1991000037__3; if linked_181 == nil { tmp1 = ifn_182.Invoke_O__O(arg_183) } else { tmp1 = linked_181.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_180, arg_183) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_184 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__1991000037__3; if linked_185 == nil { c__1927001037__auto____4 = ifn_186.Invoke_O__O(arg_187) } else { c__1927001037__auto____4 = linked_185.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_184, arg_187) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000039__6 any; var root_188 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_189 == nil { b__1991000039__6 = ifn_190.Invoke_O__O(arg_191) } else { b__1991000039__6 = linked_189.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_188, arg_191) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__211 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_New_O_O_I_O(b__1991000039__6, t.F_vdir, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__210 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class; if fncls__210 == nil { var fncls__210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__211); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class = fncls__210d; tmp3 = fncls__210d } else { tmp3 = fncls__210 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__211, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_212 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var root_217 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = b__1991000039__6; if linked_218 == nil { arg_215 = ifn_219.Invoke_O__O(arg_220) } else { arg_215 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_217, arg_220) }; var arg_216 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000036); var tmp5 any; var root_221 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__1991000037__3; if linked_222 == nil { tmp5 = ifn_223.Invoke_O__O(arg_224) } else { tmp5 = linked_222.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_221, arg_224) }; arg_216 = tmp4.Invoke_O__O(tmp5); if linked_213 == nil { return ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { return linked_213.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) } } else { var root_225 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any; var root_230 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = b__1991000039__6; if linked_231 == nil { arg_228 = ifn_232.Invoke_O__O(arg_233) } else { arg_228 = linked_231.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_230, arg_233) }; var arg_229 any; if linked_226 == nil { return ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { return linked_226.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } } } else { var f__4 any; var root_234 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = s__1991000037__3; if linked_235 == nil { f__4 = ifn_236.Invoke_O__O(arg_237) } else { f__4 = linked_235.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_234, arg_237) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()
														if and__1927000168__auto____5 { var root_238 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_242 any = Lit_28; if linked_239 == nil { tmp6 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { tmp6 = linked_239.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_238, arg_241, arg_242) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :66:1
	if jrt.J2g_Truth(tmp6) { var root_243 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var tmp7 any; var root_248 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_250 lang.IFn

		if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = jrt.File_Cast(t.F_vdir).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_249 == nil { tmp7 = ifn_250.Invoke_O__O(arg_251) } else { tmp7 = linked_249.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_248, arg_251) }
//line :66:1
		arg_246 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_247 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000036); var tmp9 any; var root_256 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__1991000037__3; if linked_257 == nil { tmp9 = ifn_258.Invoke_O__O(arg_259) } else { tmp9 = linked_257.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_256, arg_259) }; arg_247 = tmp8.Invoke_O__O(tmp9); if linked_244 == nil { return ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { return linked_244.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) } } else { var tmp10 any; var root_260 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = s__1991000037__3; if linked_261 == nil { tmp10 = ifn_262.Invoke_O__O(arg_263) } else { tmp10 = linked_261.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_260, arg_263) }; s__1991000037__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A) Ctor_O_O_I_O(c__b__1991000039, c__vdir any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000039 = c__b__1991000039; t.F_vdir = c__vdir; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A) Invoke_O__O(self any) any { { var i__1991000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000038__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()
																if and__1927000168__auto____3 { var root_192 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_196 any = Lit_28; if linked_193 == nil { tmp2 = ifn_194.Invoke_O_O__O(arg_195, arg_196) } else { tmp2 = linked_193.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_192, arg_195, arg_196) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :66:1
	if jrt.J2g_Truth(tmp2) { var root_197 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = t.F_b__1991000039; var arg_201 any; var tmp3 any; var root_202 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_204 lang.IFn

		if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = jrt.File_Cast(t.F_vdir).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_203 == nil { tmp3 = ifn_204.Invoke_O__O(arg_205) } else { tmp3 = linked_203.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_202, arg_205) }
//line :66:1
		arg_201 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_198 == nil { ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { linked_198.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) }; i__1991000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000038__1); continue L1 } else { i__1991000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_fn__1991000047_A_New() *A_arbace_j2g_embed_sources_fn__1991000047_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_A) Ctor() {}
//line :69:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_A) Invoke_O_O_O__O(self, m__1, p__1991000046__2 any) any { var vec__1991000048__3 any = p__1991000046__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000048__3, lang.RT_IntCast_J__I_NoInit(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000048__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_274 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_276 lang.IFn; if


	linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = rel__4; var arg_278 any = Lit_49; if linked_275 == nil { tmp1 = ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { tmp1 = linked_275.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_274, arg_277, arg_278) }; if /*line :70:1*/ jrt.J2g_Truth(tmp1) { var p__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_50, nil, Lit_28); var tmp3 any; var root_279 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_281 lang.IFn


		if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = rel__4; var arg_283 any = A_arbace_j2g_embed_A_const_34; var arg_284 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_49)))).Ref(); if linked_280 == nil { tmp3 = ifn_281.Invoke_O_O_O__O(arg_282, arg_283, arg_284) } else { tmp3 = linked_280.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_279, arg_282, arg_283, arg_284) }; p__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
//line :70:1
		var pairs__7 any; var root_285 any = A_arbace_j2g_embed_A_const_35.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_287 lang.IFn



		if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = A_arbace_j2g_embed_A_const_36; var arg_289 any; var root_290 any = A_arbace_j2g_embed_A_const_37.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = text__5; if linked_291 == nil { arg_289 = ifn_292.Invoke_O__O(arg_293) } else { arg_289 = linked_291.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_290, arg_293) }; if linked_286 == nil { pairs__7 = ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { pairs__7 = linked_286.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_285, arg_288, arg_289) }
		var tmp4 any; var root_359 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = m__1; var arg_363 any = p__6; if linked_360 == nil { tmp4 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp4 = linked_360.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if jrt.J2g_Truth(tmp4) { } else { var tmp5 any; var root_364 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_366 lang.IFn
			if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(); var arg_368 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_365 == nil { tmp5 = ifn_366.Invoke_O_O__O(arg_367, arg_368) } else { tmp5 = linked_365.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_364, arg_367, arg_368) }
//line :75:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5)))
		}
		var root_294 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = m__1; var arg_298 any = p__6; var arg_299 any; var fnbody__334 any = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp6 *jrt.Class; var fncls__333 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class; if fncls__333 == nil { var fncls__333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__334); A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class = fncls__333d; tmp6 = fncls__333d } else { tmp6 = fncls__333 }; arg_299 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__334, tmp6, nil); if linked_295 == nil { return ifn_296.Invoke_O_O_O__O(arg_297, arg_298, arg_299) } else { return linked_295.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_294, arg_297, arg_298, arg_299) } } else {
//line :70:1
			var tmp7 any; var root_335 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_337 lang.IFn














			if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = rel__4; var arg_339 any = Lit_54; if linked_336 == nil { tmp7 = ifn_337.Invoke_O_O__O(arg_338, arg_339) } else { tmp7 = linked_336.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_335, arg_338, arg_339) }
//line :70:1
			if jrt.J2g_Truth(tmp7) { var p__6_2 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_50, nil, Lit_28); var tmp9 any; var root_340 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_342 lang.IFn















				if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = rel__4; var arg_344 any = A_arbace_j2g_embed_A_const_34; var arg_345 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_54)))).Ref(); if linked_341 == nil { tmp9 = ifn_342.Invoke_O_O_O__O(arg_343, arg_344, arg_345) } else { tmp9 = linked_341.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_340, arg_343, arg_344, arg_345) }; p__6_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref()
				var tmp10 any; var root_369 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = m__1; var arg_373 any = p__6_2; if linked_370 == nil { tmp10 = ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { tmp10 = linked_370.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_369, arg_372, arg_373) }; if jrt.J2g_Truth(tmp10) { } else { var tmp11 any; var root_374 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_376 lang.IFn
					if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(); var arg_378 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_375 == nil { tmp11 = ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { tmp11 = linked_375.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) }
//line :87:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp11)))
				}
				var root_346 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = m__1; var arg_350 any = p__6_2; var arg_351 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_352 any = text__5; if linked_347 == nil { return ifn_348.Invoke_O_O_O_O__O(arg_349, arg_350, arg_351, arg_352) } else { return linked_347.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_346, arg_349, arg_350, arg_351, arg_352) } } else {
//line :70:1
					if A_arbace_j2g_embed_A_const_42 != nil {



















						var root_353 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = m__1; var arg_357 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_50, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(); var arg_358 any = text__5; if linked_354 == nil { return ifn_355.Invoke_O_O_O__O(arg_356, arg_357, arg_358) } else { return linked_354.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_353, arg_356, arg_357, arg_358) } } else {
//line :70:1
							return nil } } } }






func A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :77:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :77:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A) Invoke_O_O__O(self, src__1 any) any {
	var root_300 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var fnbody__332 any = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_New_O_O(t.F_p, t.F_rel); var tmp1 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__332); A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class = fncls__331d; tmp1 = fncls__331d } else { tmp1 = fncls__331 }; arg_303 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__332, tmp1, nil); var arg_304 any = src__1; var arg_305 any = t.F_pairs; if linked_301 == nil { return ifn_302.Invoke_O_O_O__O(arg_303, arg_304, arg_305) } else { return linked_301.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_300, arg_303, arg_304, arg_305) } }
//line :78:1
func A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :78:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :78:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A) Invoke_O_O_O__O(self, src__1, p__1991000052__2 any) any { var vec__1991000054__3 any = p__1991000052__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000054__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000054__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var root_317 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); var arg_321 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref(); if linked_318 == nil { tmp1 = ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { tmp1 = linked_318.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_317, arg_320, arg_321) } }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_322 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_324 lang.IFn
		if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var tmp3 any = t.F_rel; var arg_325 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_56, nil, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_41.GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(); var arg_326 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_323 == nil { tmp2 = ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { tmp2 = linked_323.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) }
//line :80:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp4 /*line :83:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp5 any; var root_306 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = src__1; var arg_310 any = A_arbace_j2g_embed_A_const_34; var arg_311 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); if linked_307 == nil { tmp5 = ifn_308.Invoke_O_O_O__O(arg_309, arg_310, arg_311) } else { tmp5 = linked_307.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_306, arg_309, arg_310, arg_311) }; var tmp6 any = tmp5; var tmp7 any; var root_312 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = src__1; var arg_316 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__6), int64(lang.RT_Count_O__I_NoInit(old__4)))).Ref(); if linked_313 == nil { tmp7 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp7 = linked_313.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp6, new__5, tmp7)).Ref() }















func A_arbace_j2g_embed_reify__1991000061_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_j2g_embed_reify__1991000061_A { t := &A_arbace_j2g_embed_reify__1991000061_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :99:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :99:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :99:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :99:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :99:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_j2g_embed_A_Init(); tmp1 = A_arbace_j2g_embed_A_const_49; return lang.Symbol_Cast(tmp1) }
//line :99:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :99:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_j2g_embed_reify__1991000061_A_New_IPersistentMap(m) }





func A_arbace_j2g_embed_read_all_A_New() *A_arbace_j2g_embed_read_all_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_j2g_embed_read_all_A) Ctor() {}
//line :105:1
func (t *A_arbace_j2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var root_410 any = A_arbace_j2g_embed_A_const_54.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_412 lang.IFn; if

	linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_55.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_embed_A_const_56; var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any = A_arbace_j2g_embed_A_const_57; var tmp5 any = A_arbace_j2g_embed_A_const_58.GetRawRoot__O(); var tmp6 any = A_arbace_j2g_embed_A_const_59; var tmp7 *lang.Compiler_AOTFn; var fnbody__424 any = A_arbace_j2g_embed_read_all_fn__1991000063_A_New(); var tmp8 *jrt.Class; var fncls__423 *jrt.Class = A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class; if

	fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class = fncls__423d; tmp8 = fncls__423d } else { tmp8 = fncls__423 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__424, tmp8, nil); arg_413 = /*line :107:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7.Ref()); if linked_411 == nil { ifn_412.Invoke_O__O(arg_413) } else { linked_411.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_410, arg_413) }; var tmp9 any; tmp11 := /*line :105:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any; var root_402 any = A_arbace_j2g_embed_A_const_50.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_404 lang.IFn





		if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = A_arbace_j2g_embed_A_const_51; var arg_406 any = r__2; if linked_403 == nil { f__6 = ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { f__6 = linked_403.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) }
		if lang.Util_Equiv_O_O__Z_NoInit(f__6, A_arbace_j2g_embed_A_const_52) { tmp9 = acc__5 } else { var tmp10 any; var root_425 any = A_arbace_j2g_embed_A_const_10.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = acc__5; var arg_429 any = f__6; if linked_426 == nil { tmp10 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { tmp10 = linked_426.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; acc__5 = tmp10; continue L1 }
//line :105:1
		break L1 } }; return nil }(); var root_407 any = A_arbace_j2g_embed_A_const_53.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_409 lang.IFn; if

	linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; if linked_408 == nil { ifn_409.Invoke__O() } else { linked_408.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_407) }; if /*line :105:1*/ tmp11 != nil { panic(tmp11) }; return tmp9 }



func A_arbace_j2g_embed_read_all_fn__1991000063_A_New() *A_arbace_j2g_embed_read_all_fn__1991000063_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_fn__1991000063_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000063_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000063_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_j2g_embed_class_like_QMARK__A_New() *A_arbace_j2g_embed_class_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Ctor() {}
//line :114:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_1); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)), int64(lang.RT_Count_O__I_NoInit(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_embed_package_like_QMARK__A_New() *A_arbace_j2g_embed_package_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_1))); if and__1927000168__auto____2 {
											var root_430 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any; var root_434 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = s__0; if linked_435 == nil { arg_433 = ifn_436.Invoke_O__O(arg_437) } else { arg_433 = linked_435.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if linked_431 == nil { return ifn_432.Invoke_O__O(arg_433) } else { return linked_431.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_430, arg_433) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_embed_names_A_New() *A_arbace_j2g_embed_names_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_j2g_embed_names_A) Ctor() {}
//line :121:1
func (t *A_arbace_j2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any; var root_438 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_440 lang.IFn; if



	linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_439 == nil { acc__2 = ifn_440.Invoke_O__O(arg_441) } else { acc__2 = linked_439.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_438, arg_441) }; var walk__3 any; var fnbody__684 any = /*line :121:1*/A_arbace_j2g_embed_names_walk__1991000068_A_New_O(acc__2); var tmp1 *jrt.Class; var fncls__683 *jrt.Class = A_arbace_j2g_embed_names_walk__1991000068_A_fn_class; if




	fncls__683 == nil { var fncls__683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__684); A_arbace_j2g_embed_names_walk__1991000068_A_fn_class = fncls__683d; tmp1 = fncls__683d } else { tmp1 = fncls__683 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__684, tmp1, nil); var seq_1991000092__4 any; var root_689 any = /*line :121:1*/A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_691 lang.IFn; if




















	linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any; var root_693 any = A_arbace_j2g_embed_A_const_75.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, A_arbace_j2g_embed_read_all_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = text__0; if linked_694 == nil { arg_692 = ifn_695.Invoke_O__O(arg_696) } else { arg_692 = linked_694.(*A_arbace_j2g_embed_read_all_A).Invoke_O_O__O(root_693, arg_696) }; if linked_690 == nil { seq_1991000092__4 = ifn_691.Invoke_O__O(arg_692) } else { seq_1991000092__4 = linked_690.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_689, arg_692) }; var chunk_1991000093__5 any; var count_1991000094__6 int64 = 0; var i_1991000095__7 int64 = 0; L1:
//line :121:1
	for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000095__7, count_1991000094__6) { var f__8 any = lang.Indexed_Cast(chunk_1991000093__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000095__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000095__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_697 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = seq_1991000092__4; if linked_698 == nil { temp__1927000414__auto____8 = ifn_699.Invoke_O__O(arg_700) } else { temp__1927000414__auto____8 = linked_698.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_697, arg_700) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1991000092__9 any = temp__1927000414__auto____8; var tmp2 any; var root_701 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = seq_1991000092__9; if linked_702 == nil { tmp2 = ifn_703.Invoke_O__O(arg_704) } else { tmp2 = linked_702.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_701, arg_704) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____10 any; var root_705 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = seq_1991000092__9; if linked_706 == nil { c__1927000678__auto____10 = ifn_707.Invoke_O__O(arg_708) } else { c__1927000678__auto____10 = linked_706.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_705, arg_708) }; var tmp3 any; var root_713 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq_1991000092__9; if linked_714 == nil { tmp3 = ifn_715.Invoke_O__O(arg_716) } else { tmp3 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_713, arg_716) }; seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = tmp3, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_709 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seq_1991000092__9; if linked_710 == nil { f__10 = ifn_711.Invoke_O__O(arg_712) } else { f__10 = linked_710.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_709, arg_712) }; lang.IFn_Cast(walk__3).Invoke_O__O(f__10); var tmp4 any; var root_717 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_1991000092__9; if linked_718 == nil { tmp4 = ifn_719.Invoke_O__O(arg_720) } else { tmp4 = linked_718.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_717, arg_720) }; seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = tmp4, nil, 0, 0; continue L1 } } }
//line :121:1
		break L1 }; var root_685 any =





















	A_arbace_j2g_embed_A_const_74.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = acc__2; if linked_686 == nil { return ifn_687.Invoke_O__O(arg_688) } else { return linked_686.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_685, arg_688) } }
//line :126:1
func A_arbace_j2g_embed_names_walk__1991000068_A_New_O(p0 any) *A_arbace_j2g_embed_names_walk__1991000068_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_walk__1991000068_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_j2g_embed_names_walk__1991000068_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :126:1
func (t *A_arbace_j2g_embed_names_walk__1991000068_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__1)
											if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											var tmp1 any; var root_442 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_444 lang.IFn
											if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = x__1; if linked_443 == nil { tmp1 = ifn_444.Invoke_O__O(arg_445) } else { tmp1 = linked_443.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_442, arg_445) }
//line :128:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any; var root_543 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = x__1; if linked_544 == nil { tmp3 = ifn_545.Invoke_O__O(arg_546) } else { tmp3 = linked_544.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_543, arg_546) }; and__1927000168__auto____2 = lang.Util_Identical_O_O__Z_NoInit(tmp3, nil); if and__1927000168__auto____2 { var root_547 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var root_551 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = x__1; if linked_552 == nil { arg_550 = ifn_553.Invoke_O__O(arg_554) } else { arg_550 = linked_552.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_551, arg_554) }; if linked_548 == nil { tmp2 = ifn_549.Invoke_O__O(arg_550) } else { tmp2 = linked_548.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_547, arg_550) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) {
			var root_555 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = t.F_acc; var arg_559 any; var root_560 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = x__1; if linked_561 == nil { arg_559 = ifn_562.Invoke_O__O(arg_563) } else { arg_559 = linked_561.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_560, arg_563) }; if linked_556 == nil { ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { linked_556.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_555, arg_558, arg_559) } }
		var tmp4 any; var and__1927000168__auto____2_2 any; var root_446 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = x__1; if linked_447 == nil { and__1927000168__auto____2_2 = ifn_448.Invoke_O__O(arg_449) } else { and__1927000168__auto____2_2 = linked_447.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_446, arg_449) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var root_450 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var root_454 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = x__1; if linked_455 == nil { arg_453 = ifn_456.Invoke_O__O(arg_457) } else { arg_453 = linked_455.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_454, arg_457) }; if linked_451 == nil { tmp4 = ifn_452.Invoke_O__O(arg_453) } else { tmp4 = linked_451.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_450, arg_453) } } else { tmp4 = and__1927000168__auto____2_2 }; if jrt.J2g_Truth(tmp4) {
			var root_458 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = t.F_acc; var arg_462 any; var root_463 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = x__1; if linked_464 == nil { arg_462 = ifn_465.Invoke_O__O(arg_466) } else { arg_462 = linked_464.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_463, arg_466) }; if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else {
//line :132:1
				return nil } } else {
//line :128:1
					var tmp5 any; var or__1927000174__auto____2 any; var root_467 any = A_arbace_j2g_embed_A_const_66.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_469 lang.IFn





					if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = x__1; if linked_468 == nil { or__1927000174__auto____2 = ifn_469.Invoke_O__O(arg_470) } else { or__1927000174__auto____2 = linked_468.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { var root_471 any = A_arbace_j2g_embed_A_const_67.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = x__1; if linked_472 == nil { tmp5 = ifn_473.Invoke_O__O(arg_474) } else { tmp5 = linked_472.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_471, arg_474) } }
//line :128:1
					if jrt.J2g_Truth(tmp5) {






						var tmp6 any; var and__1927000168__auto____2_3 any; var root_564 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any; var root_568 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = x__1; if linked_569 == nil { arg_567 = ifn_570.Invoke_O__O(arg_571) } else { arg_567 = linked_569.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_568, arg_571) }; if linked_565 == nil { and__1927000168__auto____2_3 = ifn_566.Invoke_O__O(arg_567) } else { and__1927000168__auto____2_3 = linked_565.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_564, arg_567) }; if jrt.J2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool; var tmp7 any; var root_572 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var root_576 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = x__1; if linked_577 == nil { arg_575 = ifn_578.Invoke_O__O(arg_579) } else { arg_575 = linked_577.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_576, arg_579) }; if linked_573 == nil { tmp7 = ifn_574.Invoke_O__O(arg_575) } else { tmp7 = linked_573.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_572, arg_575) }; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z_NoInit(tmp7, nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_580 any = A_arbace_j2g_embed_A_const_71.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, A_arbace_j2g_embed_package_like_QMARK__A_fn_class); var ifn_582 lang.IFn
							if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any; var root_584 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any; var root_588 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = x__1; if linked_589 == nil { arg_587 = ifn_590.Invoke_O__O(arg_591) } else { arg_587 = linked_589.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_588, arg_591) }; if linked_585 == nil { arg_583 = ifn_586.Invoke_O__O(arg_587) } else { arg_583 = linked_585.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_584, arg_587) }; if linked_581 == nil { and__1927000168__auto____4 = ifn_582.Invoke_O__O(arg_583) } else { and__1927000168__auto____4 = linked_581.(*A_arbace_j2g_embed_package_like_QMARK__A).Invoke_O_O__O(root_580, arg_583) }
//line :135:1
							if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_592 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_594 lang.IFn
								if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any; var root_596 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = x__1; if linked_597 == nil { arg_595 = ifn_598.Invoke_O__O(arg_599) } else { arg_595 = linked_597.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_596, arg_599) }; if linked_593 == nil { and__1927000168__auto____5 = ifn_594.Invoke_O__O(arg_595) } else { and__1927000168__auto____5 = linked_593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_592, arg_595) }
//line :135:1
								if jrt.J2g_Truth(and__1927000168__auto____5) {

									var root_600 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var arg_604 any; var root_605 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = x__1; if linked_606 == nil { arg_604 = ifn_607.Invoke_O__O(arg_608) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_605, arg_608) }; if linked_601 == nil { tmp6 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { tmp6 = linked_601.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_600, arg_603, arg_604) } } else {
//line :135:1
										tmp6 = and__1927000168__auto____5 } } else { tmp6 = and__1927000168__auto____4 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp6 = and__1927000168__auto____2_3 }; if jrt.J2g_Truth(tmp6) { var seq_1991000069__2 any; var root_609 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_611 lang.IFn


											if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any; var root_613 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = x__1; if linked_614 == nil { arg_612 = ifn_615.Invoke_O__O(arg_616) } else { arg_612 = linked_614.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_613, arg_616) }; if linked_610 == nil { seq_1991000069__2 = ifn_611.Invoke_O__O(arg_612) } else { seq_1991000069__2 = linked_610.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_609, arg_612) }
//line :135:1
											var chunk_1991000070__3 any; var count_1991000071__4 int64 = 0; var i_1991000072__5 int64 = 0; L1: for {


												if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000072__5, count_1991000071__4) { var c__6 any = lang.Indexed_Cast(chunk_1991000070__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000072__5)); var root_633 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = t.F_acc; var arg_637 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp9 any; var root_638 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = x__1; if linked_639 == nil { tmp9 = ifn_640.Invoke_O__O(arg_641) } else { tmp9 = linked_639.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_638, arg_641) }; arg_637 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, c__6)).Ref(); if linked_634 == nil { ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { linked_634.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_633, arg_636, arg_637) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000072__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_617 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = seq_1991000069__2; if linked_618 == nil { temp__1927000414__auto____6 = ifn_619.Invoke_O__O(arg_620) } else { temp__1927000414__auto____6 = linked_618.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_617, arg_620) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1991000069__7 any = temp__1927000414__auto____6; var tmp10 any; var root_621 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = seq_1991000069__7; if linked_622 == nil { tmp10 = ifn_623.Invoke_O__O(arg_624) } else { tmp10 = linked_622.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_621, arg_624) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____8 any; var root_625 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = seq_1991000069__7; if linked_626 == nil { c__1927000678__auto____8 = ifn_627.Invoke_O__O(arg_628) } else { c__1927000678__auto____8 = linked_626.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_625, arg_628) }; var tmp11 any; var root_642 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = seq_1991000069__7; if linked_643 == nil { tmp11 = ifn_644.Invoke_O__O(arg_645) } else { tmp11 = linked_643.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_642, arg_645) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = tmp11, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_629 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = seq_1991000069__7; if linked_630 == nil { c__8 = ifn_631.Invoke_O__O(arg_632) } else { c__8 = linked_630.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_629, arg_632) }; var root_646 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = t.F_acc; var arg_650 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp13 any; var root_651 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = x__1; if linked_652 == nil { tmp13 = ifn_653.Invoke_O__O(arg_654) } else { tmp13 = linked_652.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_651, arg_654) }; arg_650 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, c__8)).Ref(); if linked_647 == nil { ifn_648.Invoke_O_O__O(arg_649, arg_650) } else { linked_647.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_646, arg_649, arg_650) }; var tmp14 any; var root_655 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = seq_1991000069__7; if linked_656 == nil { tmp14 = ifn_657.Invoke_O__O(arg_658) } else { tmp14 = linked_656.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_655, arg_658) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = tmp14, nil, 0, 0; continue L1 } } }
//line :135:1
												break L1 } }
//line :128:1
						var seq_1991000073__2 any; var root_475 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_477 lang.IFn










						if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__1; if linked_476 == nil { seq_1991000073__2 = ifn_477.Invoke_O__O(arg_478) } else { seq_1991000073__2 = linked_476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_475, arg_478) }
//line :128:1
						var chunk_1991000074__3 any; var count_1991000075__4 int64 = 0; var i_1991000076__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000076__5, count_1991000075__4) { var y__6 any = lang.Indexed_Cast(chunk_1991000074__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000076__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000076__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_479 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1991000073__2; if linked_480 == nil { temp__1927000414__auto____6_2 = ifn_481.Invoke_O__O(arg_482) } else { temp__1927000414__auto____6_2 = linked_480.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_479, arg_482) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1991000073__7 any = temp__1927000414__auto____6_2; var tmp15 any; var root_483 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = seq_1991000073__7; if linked_484 == nil { tmp15 = ifn_485.Invoke_O__O(arg_486) } else { tmp15 = linked_484.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_483, arg_486) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____8_2 any; var root_487 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = seq_1991000073__7; if linked_488 == nil { c__1927000678__auto____8_2 = ifn_489.Invoke_O__O(arg_490) } else { c__1927000678__auto____8_2 = linked_488.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_487, arg_490) }; var tmp16 any; var root_659 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = seq_1991000073__7; if linked_660 == nil { tmp16 = ifn_661.Invoke_O__O(arg_662) } else { tmp16 = linked_660.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_659, arg_662) }; seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = tmp16, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_491 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = seq_1991000073__7; if linked_492 == nil { y__8 = ifn_493.Invoke_O__O(arg_494) } else { y__8 = linked_492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_491, arg_494) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp17 any; var root_663 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = seq_1991000073__7; if linked_664 == nil { tmp17 = ifn_665.Invoke_O__O(arg_666) } else { tmp17 = linked_664.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_663, arg_666) }; seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = tmp17, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :128:1
								var tmp18 any; var root_495 any = A_arbace_j2g_embed_A_const_68.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_497 lang.IFn











								if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = x__1; if linked_496 == nil { tmp18 = ifn_497.Invoke_O__O(arg_498) } else { tmp18 = linked_496.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_495, arg_498) }
//line :128:1
								if jrt.J2g_Truth(tmp18) { var seq_1991000077__2 any; var root_499 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_501 lang.IFn











									if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = x__1; if linked_500 == nil { seq_1991000077__2 = ifn_501.Invoke_O__O(arg_502) } else { seq_1991000077__2 = linked_500.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_499, arg_502) }
//line :128:1
									var chunk_1991000078__3 any; var count_1991000079__4 int64 = 0; var i_1991000080__5 int64 = 0; L3: for {











										if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000080__5, count_1991000079__4) { var vec__1991000081__6 any = lang.Indexed_Cast(chunk_1991000078__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000080__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000081__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000081__6, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000080__5); continue L3 } else { var temp__1927000414__auto____6_3 any; var root_503 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_1991000077__2; if linked_504 == nil { temp__1927000414__auto____6_3 = ifn_505.Invoke_O__O(arg_506) } else { temp__1927000414__auto____6_3 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1991000077__7 any = temp__1927000414__auto____6_3; var tmp19 any; var root_507 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_1991000077__7; if linked_508 == nil { tmp19 = ifn_509.Invoke_O__O(arg_510) } else { tmp19 = linked_508.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_507, arg_510) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____8_3 any; var root_511 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1991000077__7; if linked_512 == nil { c__1927000678__auto____8_3 = ifn_513.Invoke_O__O(arg_514) } else { c__1927000678__auto____8_3 = linked_512.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_511, arg_514) }; var tmp20 any; var root_667 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq_1991000077__7; if linked_668 == nil { tmp20 = ifn_669.Invoke_O__O(arg_670) } else { tmp20 = linked_668.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_667, arg_670) }; seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = tmp20, c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1991000084__8 any; var root_515 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = seq_1991000077__7; if linked_516 == nil { vec__1991000084__8 = ifn_517.Invoke_O__O(arg_518) } else { vec__1991000084__8 = linked_516.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_515, arg_518) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000084__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000084__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); var tmp21 any; var root_671 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = seq_1991000077__7; if linked_672 == nil { tmp21 = ifn_673.Invoke_O__O(arg_674) } else { tmp21 = linked_672.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_671, arg_674) }; seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = tmp21, nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :128:1
											var tmp22 any; var root_519 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_521 lang.IFn












											if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = x__1; if linked_520 == nil { tmp22 = ifn_521.Invoke_O__O(arg_522) } else { tmp22 = linked_520.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_519, arg_522) }
//line :128:1
											if jrt.J2g_Truth(tmp22) { var seq_1991000087__2 any; var root_523 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_525 lang.IFn












												if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = x__1; if linked_524 == nil { seq_1991000087__2 = ifn_525.Invoke_O__O(arg_526) } else { seq_1991000087__2 = linked_524.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_523, arg_526) }
//line :128:1
												var chunk_1991000088__3 any; var count_1991000089__4 int64 = 0; var i_1991000090__5 int64 = 0; L4: for {












													if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000090__5, count_1991000089__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1991000088__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000090__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000090__5); continue L4 } else { var temp__1927000414__auto____6_4 any; var root_527 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = seq_1991000087__2; if linked_528 == nil { temp__1927000414__auto____6_4 = ifn_529.Invoke_O__O(arg_530) } else { temp__1927000414__auto____6_4 = linked_528.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_527, arg_530) }; if jrt.J2g_Truth(temp__1927000414__auto____6_4) { var seq_1991000087__7 any = temp__1927000414__auto____6_4; var tmp23 any; var root_531 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = seq_1991000087__7; if linked_532 == nil { tmp23 = ifn_533.Invoke_O__O(arg_534) } else { tmp23 = linked_532.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_531, arg_534) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____8_4 any; var root_535 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = seq_1991000087__7; if linked_536 == nil { c__1927000678__auto____8_4 = ifn_537.Invoke_O__O(arg_538) } else { c__1927000678__auto____8_4 = linked_536.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_535, arg_538) }; var tmp24 any; var root_675 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = seq_1991000087__7; if linked_676 == nil { tmp24 = ifn_677.Invoke_O__O(arg_678) } else { tmp24 = linked_676.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_675, arg_678) }; seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = tmp24, c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var y__8_2 any; var root_539 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = seq_1991000087__7; if linked_540 == nil { y__8_2 = ifn_541.Invoke_O__O(arg_542) } else { y__8_2 = linked_540.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_539, arg_542) }; lang.IFn_Cast(self).Invoke_O__O(y__8_2); var tmp25 any; var root_679 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = seq_1991000087__7; if linked_680 == nil { tmp25 = ifn_681.Invoke_O__O(arg_682) } else { tmp25 = linked_680.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_679, arg_682) }; seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = tmp25, nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :128:1
														return nil } } } } }; /*line :126:1*/panic("j2g: unreachable") }





























func A_arbace_j2g_embed_cut_candidates_A_New() *A_arbace_j2g_embed_cut_candidates_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Ctor() {}
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var root_721 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any; var iter__1927001039__auto____2 any; var fnbody__838 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_New(); var tmp1 *jrt.Class; var fncls__837 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class; if fncls__837 == nil { var fncls__837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class = fncls__837d; tmp1 = fncls__837d } else { tmp1 = fncls__837 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__838, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_839 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var root_844 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var arg_848 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp5 any; var root_855 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; if linked_856 == nil { tmp5 = ifn_857.Invoke__O() } else { tmp5 = linked_856.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_855) }; var tmp6 any = tmp5; var tmp7 *lang.Compiler_AOTFn; var fnbody__863 any = A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_New(); var tmp8 *jrt.Class; var fncls__862 *jrt.Class = A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class; if fncls__862 == nil { var fncls__862d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class = fncls__862d; tmp8 = fncls__862d } else { tmp8 = fncls__862 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__863, tmp8, nil); arg_848 = tmp4.Invoke_O_O_O__O(tmp6, tmp7.Ref(), srcs__0); if linked_845 == nil { arg_842 = ifn_846.Invoke_O_O__O(arg_847, arg_848) } else { arg_842 = linked_845.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_844, arg_847, arg_848) }; var arg_843 any = A_arbace_j2g_embed_A_const_88.GetRawRoot__O(); if linked_840 == nil { tmp3 = ifn_841.Invoke_O_O__O(arg_842, arg_843) } else { tmp3 = linked_840.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_839, arg_842, arg_843) }; arg_724 = tmp2.Invoke_O__O(tmp3); if linked_722 == nil { return ifn_723.Invoke_O__O(arg_724) } else { return linked_722.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_721, arg_724) } }
//line :161:1
func A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_New() *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_fn__1991000112_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A) Ctor() {}
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A) Invoke_O_O__O(self, p__1991000111__1 any) any { var vec__1991000113__2 any = p__1991000111__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000113__2, lang.RT_IntCast_J__I_NoInit(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000113__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_858 any = A_arbace_j2g_embed_A_const_87.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, A_arbace_j2g_embed_names_A_fn_class); var ifn_860 lang.IFn; _ = ___3; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = text__4; if linked_859 == nil { return ifn_860.Invoke_O__O(arg_861) } else { return linked_859.(*A_arbace_j2g_embed_names_A).Invoke_O_O__O(root_858, arg_861) } }
//line :161:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_New() *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A) Ctor() {}
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A) Invoke_O_O__O(self, s__1991000098__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__836 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_New_O_O(s__1991000098__1, self); var tmp2 *jrt.Class; var fncls__835 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class; if fncls__835 == nil { var fncls__835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__836); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class = fncls__835d; tmp2 = fncls__835d } else { tmp2 = fncls__835 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__836, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :161:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A{}; t.Ctor_O_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A) Ctor_O_O(c__s__1991000098, c__iter__1991000097 any) { t.F_s__1991000098 = c__s__1991000098; t.F_iter__1991000097 = c__iter__1991000097 }
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A) Invoke_O__O(self any) any { { var s__1991000098__1 any; var t_ any = t.F_s__1991000098; t.F_s__1991000098 = nil; s__1991000098__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_725 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = s__1991000098__1; if linked_726 == nil { temp__1927000414__auto____2 = ifn_727.Invoke_O__O(arg_728) } else { temp__1927000414__auto____2 = linked_726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_725, arg_728) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000098__3 any = temp__1927000414__auto____2; var tmp1 any; var root_729 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = s__1991000098__3; if linked_730 == nil { tmp1 = ifn_731.Invoke_O__O(arg_732) } else { tmp1 = linked_730.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_729, arg_732) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_733 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = s__1991000098__3; if linked_734 == nil { c__1927001037__auto____4 = ifn_735.Invoke_O__O(arg_736) } else { c__1927001037__auto____4 = linked_734.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_733, arg_736) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000100__6 any; var root_737 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_738 == nil { b__1991000100__6 = ifn_739.Invoke_O__O(arg_740) } else { b__1991000100__6 = linked_738.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_737, arg_740) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__771 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_New_I_O_O(size__1927001038__auto____5, b__1991000100__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__770 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class; if fncls__770 == nil { var fncls__770d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__771); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class = fncls__770d; tmp3 = fncls__770d } else { tmp3 = fncls__770 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__771, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_772 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var root_777 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = b__1991000100__6; if linked_778 == nil { arg_775 = ifn_779.Invoke_O__O(arg_780) } else { arg_775 = linked_778.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_777, arg_780) }; var arg_776 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000097); var tmp5 any; var root_781 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = s__1991000098__3; if linked_782 == nil { tmp5 = ifn_783.Invoke_O__O(arg_784) } else { tmp5 = linked_782.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_781, arg_784) }; arg_776 = tmp4.Invoke_O__O(tmp5); if linked_773 == nil { return ifn_774.Invoke_O_O__O(arg_775, arg_776) } else { return linked_773.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_772, arg_775, arg_776) } } else { var root_785 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; var root_790 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = b__1991000100__6; if linked_791 == nil { arg_788 = ifn_792.Invoke_O__O(arg_793) } else { arg_788 = linked_791.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_790, arg_793) }; var arg_789 any; if linked_786 == nil { return ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { return linked_786.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) } } } else { var n__4 any; var root_794 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = s__1991000098__3; if linked_795 == nil { n__4 = ifn_796.Invoke_O__O(arg_797) } else { n__4 = linked_795.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_794, arg_797) }; var tmp6 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_798 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_800 lang.IFn

	if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = A_arbace_j2g_embed_A_const_78; var arg_802 any = n__4; if linked_799 == nil { or__1927000174__auto____5 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { or__1927000174__auto____5 = linked_799.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
		var root_803 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = A_arbace_j2g_embed_A_const_79; var arg_807 any = n__4; if linked_804 == nil { and__1927000168__auto____5 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { and__1927000168__auto____5 = linked_804.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) } }
//line :163:1
	if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_808 any = A_arbace_j2g_embed_A_const_80.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = A_arbace_j2g_embed_A_const_81; var arg_812 any = n__4; var arg_813 any; var fnbody__815 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_New_O(n__4); var tmp7 *jrt.Class; var fncls__814 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class; if fncls__814 == nil { var fncls__814d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__815); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class = fncls__814d; tmp7 = fncls__814d } else { tmp7 = fncls__814 }; arg_813 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__815, tmp7, nil); if linked_809 == nil { tmp6 = ifn_810.Invoke_O_O_O__O(arg_811, arg_812, arg_813) } else { tmp6 = linked_809.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_808, arg_811, arg_812, arg_813) } } else {
//line :163:1
			tmp6 = and__1927000168__auto____5 }
//line :161:1
	if jrt.J2g_Truth(tmp6) { var root_816 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_821 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_823 lang.IFn







		if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = n__4; var arg_825 any = Lit_1; var arg_826 any = Lit_7; if linked_822 == nil { arg_819 = ifn_823.Invoke_O_O_O__O(arg_824, arg_825, arg_826) } else { arg_819 = linked_822.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_821, arg_824, arg_825, arg_826) }
//line :161:1
		var arg_820 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000097); var tmp9 any; var root_827 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = s__1991000098__3; if linked_828 == nil { tmp9 = ifn_829.Invoke_O__O(arg_830) } else { tmp9 = linked_828.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_827, arg_830) }; arg_820 = tmp8.Invoke_O__O(tmp9); if linked_817 == nil { return ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { return linked_817.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) } } else { var tmp10 any; var root_831 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = s__1991000098__3; if linked_832 == nil { tmp10 = ifn_833.Invoke_O__O(arg_834) } else { tmp10 = linked_832.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_831, arg_834) }; s__1991000098__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :161:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1991000100, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000100 = c__b__1991000100; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :161:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A) Invoke_O__O(self any) any { { var i__1991000099__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000099__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000099__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_741 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_743 lang.IFn

	if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = A_arbace_j2g_embed_A_const_78; var arg_745 any = n__2; if linked_742 == nil { or__1927000174__auto____3 = ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { or__1927000174__auto____3 = linked_742.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
		var root_746 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = A_arbace_j2g_embed_A_const_79; var arg_750 any = n__2; if linked_747 == nil { and__1927000168__auto____3 = ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { and__1927000168__auto____3 = linked_747.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } }
//line :163:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {


		var root_751 any = A_arbace_j2g_embed_A_const_80.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = A_arbace_j2g_embed_A_const_81; var arg_755 any = n__2; var arg_756 any; var fnbody__758 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_New_O(n__2); var tmp3 *jrt.Class; var fncls__757 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class; if fncls__757 == nil { var fncls__757d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__758); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class = fncls__757d; tmp3 = fncls__757d } else { tmp3 = fncls__757 }; arg_756 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__758, tmp3, nil); if linked_752 == nil { tmp2 = ifn_753.Invoke_O_O_O__O(arg_754, arg_755, arg_756) } else { tmp2 = linked_752.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_751, arg_754, arg_755, arg_756) } } else {
//line :163:1
			tmp2 = and__1927000168__auto____3 }
//line :161:1
	if jrt.J2g_Truth(tmp2) { var root_759 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = t.F_b__1991000100; var arg_763 any; var root_764 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_766 lang.IFn







		if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = n__2; var arg_768 any = Lit_1; var arg_769 any = Lit_7; if linked_765 == nil { arg_763 = ifn_766.Invoke_O_O_O__O(arg_767, arg_768, arg_769) } else { arg_763 = linked_765.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_764, arg_767, arg_768, arg_769) }
//line :161:1
		if linked_760 == nil { ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { linked_760.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; i__1991000099__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000099__1); continue L1 } else { i__1991000099__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000099__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :166:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :166:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :166:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :166:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :166:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_j2g_embed_with_member_types_A_New() *A_arbace_j2g_embed_with_member_types_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_j2g_embed_with_member_types_A) Ctor() {}
//line :171:1
func (t *A_arbace_j2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var fnbody__897 any = A_arbace_j2g_embed_with_member_types_types__1991000118_A_New(); var tmp1 *jrt.Class; var fncls__896 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class; if




	fncls__896 == nil { var fncls__896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class = fncls__896d; tmp1 = fncls__896d } else { tmp1 = fncls__896 }; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__897, tmp1, nil); var elem__4 any; var fnbody__899 any = /*line :171:1*/A_arbace_j2g_embed_with_member_types_elem__1991000126_A_New(); var tmp2 *jrt.Class; var fncls__898 *jrt.Class = A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class; if








	fncls__898 == nil { var fncls__898d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class = fncls__898d; tmp2 = fncls__898d } else { tmp2 = fncls__898 }; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__899, tmp2, nil); var member_types__5 any; var fnbody__1026 any = /*line :171:1*/A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_New_O_O(elem__4, types__3); var tmp3 *jrt.Class; var fncls__1025 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class; if










	fncls__1025 == nil { var fncls__1025d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__1026); A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class = fncls__1025d; tmp3 = fncls__1025d } else { tmp3 = fncls__1025 }; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1026, tmp3, nil); var more__6 any; var iter__1927001039__auto____6 any; var fnbody__1145 any = /*line :171:1*/A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp4 *jrt.Class; var fncls__1144 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class; if




















	fncls__1144 == nil { var fncls__1144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1145); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class = fncls__1144d; tmp4 = fncls__1144d } else { tmp4 = fncls__1144 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1145, tmp4, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); var root_1146 any =




	A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var root_1150 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any; var root_1154 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = cands__0; var arg_1158 any = more__6; if linked_1155 == nil { arg_1153 = ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { arg_1153 = linked_1155.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) }; if linked_1151 == nil { arg_1149 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1149 = linked_1151.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1150, arg_1153) }; if linked_1147 == nil { return ifn_1148.Invoke_O__O(arg_1149) } else { return linked_1147.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1146, arg_1149) } }
//line :176:1
func A_arbace_j2g_embed_with_member_types_types__1991000118_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_83.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp3 *lang.Compiler_AOTFn; var fnbody__881 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_New(); var tmp4 *jrt.Class; var fncls__880 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class; if fncls__880 == nil { var fncls__880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class = fncls__880d; tmp4 = fncls__880d } else { tmp4 = fncls__880 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__881, tmp4, nil); var tmp5 any = tmp2.Invoke_O_O__O(tmp3.Ref(), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp6 any; var root_882 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_884 lang.IFn
	if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var fnbody__888 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_New(); var tmp7 *jrt.Class; var fncls__887 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class; if fncls__887 == nil { var fncls__887d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class = fncls__887d; tmp7 = fncls__887d } else { tmp7 = fncls__887 }; arg_885 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__888, tmp7, nil); var arg_886 any = jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref(); if linked_883 == nil { tmp6 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { tmp6 = linked_883.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }
//line :177:1
	var tmp8 any = tmp6; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp10 *lang.Compiler_AOTFn; var fnbody__895 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_New(); var tmp11 *jrt.Class
	var fncls__894 /*line :177:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class

	if fncls__894 == nil { var fncls__894d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class = fncls__894d; tmp11 = fncls__894d } else { tmp11 = fncls__894 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__895, tmp11, nil)
//line :177:1
	return tmp1.Invoke_O_O_O__O(tmp5, tmp8, tmp9.Invoke_O_O__O(tmp10.Ref(), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :177:1
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A) Invoke_O_O__O(self, m__1 any) any { var root_875 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(); var arg_879 any = jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref(); if linked_876 == nil { return ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { return linked_876.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) } }
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A) Ctor() {}
//line :178:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A) Ctor() {}
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_j2g_embed_with_member_types_elem__1991000126_A_New() *A_arbace_j2g_embed_with_member_types_elem__1991000126_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_elem__1991000126_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000126_A) Ctor() {}
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000126_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :182:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__907 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_New_O(n__1); var tmp2 *jrt.Class; var fncls__906 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class; if
														fncls__906 == nil { var fncls__906d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__907); A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class = fncls__906d; tmp2 = fncls__906d } else { tmp2 = fncls__906 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__907, tmp2, nil); temp__1927000414__auto____2 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var root_908 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_910 lang.IFn

		if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any; var root_912 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any; var root_916 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any; var iter__1927001039__auto____4 any; var fnbody__1019 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_New(); var tmp3 *jrt.Class; var fncls__1018 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class
		if fncls__1018 == nil { var fncls__1018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class = fncls__1018d; tmp3 = fncls__1018d } else { tmp3 = fncls__1018 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1019, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp5 any; var root_1020 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = t.F_elem; var arg_1024 any = lang.IFn_Cast(t.F_types).Invoke_O__O(c__3); if linked_1021 == nil { tmp5 = ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { tmp5 = linked_1021.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) }; arg_919 = tmp4.Invoke_O__O(tmp5)
//line :185:1
		if linked_917 == nil { arg_915 = ifn_918.Invoke_O__O(arg_919) } else { arg_915 = linked_917.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_916, arg_919) }; if linked_913 == nil { arg_911 = ifn_914.Invoke_O__O(arg_915) } else { arg_911 = linked_913.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_912, arg_915) }; if linked_909 == nil { return ifn_910.Invoke_O__O(arg_911) } else { return linked_909.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_908, arg_911) } } else {
//line :183:1
			return nil } }
//line :183:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_900 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var t_ any = t.F_n; t.F_n = nil; arg_903 = t_; var arg_904 any = Lit_7; var arg_905 any = Lit_1; if linked_901 == nil { tmp2 = ifn_902.Invoke_O_O_O__O(arg_903, arg_904, arg_905) } else { tmp2 = linked_901.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_900, arg_903, arg_904, arg_905) }; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_New() *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A) Ctor() {}
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A) Invoke_O_O__O(self, s__1991000132__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1017 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_New_O_O(s__1991000132__1, self); var tmp2 *jrt.Class; var fncls__1016 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class; if fncls__1016 == nil { var fncls__1016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__1017); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class = fncls__1016d; tmp2 = fncls__1016d } else { tmp2 = fncls__1016 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1017, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :186:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A{}; t.Ctor_O_O(p0, p1); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A) Ctor_O_O(c__s__1991000132, c__iter__1991000131 any) { t.F_s__1991000132 = c__s__1991000132; t.F_iter__1991000131 = c__iter__1991000131 }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A) Invoke_O__O(self any) any { { var s__1991000132__1 any; var t_ any = t.F_s__1991000132; t.F_s__1991000132 = nil; s__1991000132__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_920 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = s__1991000132__1; if linked_921 == nil { temp__1927000414__auto____2 = ifn_922.Invoke_O__O(arg_923) } else { temp__1927000414__auto____2 = linked_921.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_920, arg_923) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000132__3 any = temp__1927000414__auto____2; var tmp1 any; var root_924 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = s__1991000132__3; if linked_925 == nil { tmp1 = ifn_926.Invoke_O__O(arg_927) } else { tmp1 = linked_925.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_924, arg_927) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_928 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = s__1991000132__3; if linked_929 == nil { c__1927001037__auto____4 = ifn_930.Invoke_O__O(arg_931) } else { c__1927001037__auto____4 = linked_929.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_928, arg_931) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000134__6 any; var root_932 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_933 == nil { b__1991000134__6 = ifn_934.Invoke_O__O(arg_935) } else { b__1991000134__6 = linked_933.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_932, arg_935) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__957 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000134__6); var tmp3 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__957); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class = fncls__956d; tmp3 = fncls__956d } else { tmp3 = fncls__956 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__957, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_958 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_963 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = b__1991000134__6; if linked_964 == nil { arg_961 = ifn_965.Invoke_O__O(arg_966) } else { arg_961 = linked_964.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_963, arg_966) }; var arg_962 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000131); var tmp5 any; var root_967 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = s__1991000132__3; if linked_968 == nil { tmp5 = ifn_969.Invoke_O__O(arg_970) } else { tmp5 = linked_968.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_967, arg_970) }; arg_962 = tmp4.Invoke_O__O(tmp5); if linked_959 == nil { return ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { return linked_959.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) } } else { var root_971 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var root_976 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = b__1991000134__6; if linked_977 == nil { arg_974 = ifn_978.Invoke_O__O(arg_979) } else { arg_974 = linked_977.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_976, arg_979) }; var arg_975 any; if linked_972 == nil { return ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { return linked_972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } } else { var t__4 any; var root_980 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = s__1991000132__3; if linked_981 == nil { t__4 = ifn_982.Invoke_O__O(arg_983) } else { t__4 = linked_981.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_980, arg_983) }; var tmp6 any; var root_984 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_986 lang.IFn
																		if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref(); if linked_985 == nil { tmp6 = ifn_986.Invoke_O__O(arg_987) } else { tmp6 = linked_985.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_984, arg_987) }
//line :186:1
	if jrt.J2g_Truth(tmp6) { var tn__5 any; var root_988 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_990 lang.IFn

		if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(); var arg_992 any = Lit_1; var arg_993 any = Lit_7; if linked_989 == nil { tn__5 = ifn_990.Invoke_O_O_O__O(arg_991, arg_992, arg_993) } else { tn__5 = linked_989.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_988, arg_991, arg_992, arg_993) }
//line :186:1
		var tmp7 any; var and__1927000168__auto____6 any; var root_994 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_996 lang.IFn


		if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = A_arbace_j2g_embed_A_const_94; var arg_998 any = tn__5; if linked_995 == nil { and__1927000168__auto____6 = ifn_996.Invoke_O_O__O(arg_997, arg_998) } else { and__1927000168__auto____6 = linked_995.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_994, arg_997, arg_998) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
			tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :189:1
				tmp7 = and__1927000168__auto____6 }
//line :186:1
		if jrt.J2g_Truth(tmp7) { var root_999 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = tn__5; var arg_1003 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000131); var tmp9 any; var root_1004 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = s__1991000132__3; if linked_1005 == nil { tmp9 = ifn_1006.Invoke_O__O(arg_1007) } else { tmp9 = linked_1005.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1004, arg_1007) }; arg_1003 = tmp8.Invoke_O__O(tmp9); if linked_1000 == nil { return ifn_1001.Invoke_O_O__O(arg_1002, arg_1003) } else { return linked_1000.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_999, arg_1002, arg_1003) } } else { var tmp10 any; var root_1008 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = s__1991000132__3; if linked_1009 == nil { tmp10 = ifn_1010.Invoke_O__O(arg_1011) } else { tmp10 = linked_1009.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1008, arg_1011) }; s__1991000132__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1012 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = s__1991000132__3; if linked_1013 == nil { tmp11 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp11 = linked_1013.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1012, arg_1015) }; s__1991000132__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :186:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000134 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000134 = c__b__1991000134 }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A) Invoke_O__O(self any) any { { var i__1991000133__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000133__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000133__1)); var tmp2 any; var root_936 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_938 lang.IFn
																				if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref(); if linked_937 == nil { tmp2 = ifn_938.Invoke_O__O(arg_939) } else { tmp2 = linked_937.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_936, arg_939) }
//line :186:1
	if jrt.J2g_Truth(tmp2) { var tn__3 any; var root_940 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_942 lang.IFn

		if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(); var arg_944 any = Lit_1; var arg_945 any = Lit_7; if linked_941 == nil { tn__3 = ifn_942.Invoke_O_O_O__O(arg_943, arg_944, arg_945) } else { tn__3 = linked_941.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_940, arg_943, arg_944, arg_945) }
//line :186:1
		var tmp3 any; var and__1927000168__auto____4 any; var root_946 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_948 lang.IFn


		if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = A_arbace_j2g_embed_A_const_94; var arg_950 any = tn__3; if linked_947 == nil { and__1927000168__auto____4 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { and__1927000168__auto____4 = linked_947.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
			tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :189:1
				tmp3 = and__1927000168__auto____4 }
//line :186:1
		if jrt.J2g_Truth(tmp3) { var root_951 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = t.F_b__1991000134; var arg_955 any = tn__3; if linked_952 == nil { ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { linked_952.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }; i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } else { i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } } else { i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A) Invoke_O_O__O(self, s__1991000143__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1143 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1991000143__1, self); var tmp2 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__1143); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class = fncls__1142d; tmp2 = fncls__1142d } else { tmp2 = fncls__1142 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1143, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :192:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1991000143, c__iter__1991000142 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1991000143 = c__s__1991000143; t.F_iter__1991000142 = c__iter__1991000142 }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A) Invoke_O__O(self any) any { { var s__1991000143__1 any; var t_ any = t.F_s__1991000143; t.F_s__1991000143 = nil; s__1991000143__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1027 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = s__1991000143__1; if linked_1028 == nil { temp__1927000414__auto____2 = ifn_1029.Invoke_O__O(arg_1030) } else { temp__1927000414__auto____2 = linked_1028.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1027, arg_1030) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1031 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = xs__1927001018__auto____3; if linked_1032 == nil { n__4 = ifn_1033.Invoke_O__O(arg_1034) } else { n__4 = linked_1032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1031, arg_1034) }; var tmp1 any; var root_1035 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1037 lang.IFn
															if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4); if linked_1036 == nil { tmp1 = ifn_1037.Invoke_O__O(arg_1038) } else { tmp1 = linked_1036.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1035, arg_1038) }
//line :192:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1112 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_New_O(t.F_in_world_QMARK_); var tmp2 *jrt.Class; var fncls__1111 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class; if fncls__1111 == nil { var fncls__1111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__1112); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class = fncls__1111d; tmp2 = fncls__1111d } else { tmp2 = fncls__1111 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1112, tmp2, nil); var fs__1927001036__auto____6 any; var root_1113 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1117 any = A_arbace_j2g_embed_A_const_95.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A_fn_class); var ifn_1119 lang.IFn

		if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = A_arbace_j2g_embed_A_const_96; var arg_1121 any = n__4; var arg_1122 any; var fnbody__1124 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_New_O_O(n__4, t.F_member_types); var tmp5 *jrt.Class; var fncls__1123 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class; if fncls__1123 == nil { var fncls__1123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1124); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class = fncls__1123d; tmp5 = fncls__1123d } else { tmp5 = fncls__1123 }; arg_1122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1124, tmp5, nil); if linked_1118 == nil { tmp4 = ifn_1119.Invoke_O_O_O__O(arg_1120, arg_1121, arg_1122) } else { tmp4 = linked_1118.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A).Invoke_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122) }
//line :192:1
		arg_1116 = tmp3.Invoke_O__O(tmp4); if linked_1114 == nil { fs__1927001036__auto____6 = ifn_1115.Invoke_O__O(arg_1116) } else { fs__1927001036__auto____6 = linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1125 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = fs__1927001036__auto____6; var arg_1129 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000142); var tmp7 any; var root_1130 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = s__1991000143__1; if linked_1131 == nil { tmp7 = ifn_1132.Invoke_O__O(arg_1133) } else { tmp7 = linked_1131.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1130, arg_1133) }; arg_1129 = tmp6.Invoke_O__O(tmp7); if linked_1126 == nil { return ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { return linked_1126.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) } } else { var tmp8 any; var root_1134 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = s__1991000143__1; if linked_1135 == nil { tmp8 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp8 = linked_1135.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1134, arg_1137) }; s__1991000143__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1138 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = s__1991000143__1; if linked_1139 == nil { tmp9 = ifn_1140.Invoke_O__O(arg_1141) } else { tmp9 = linked_1139.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1138, arg_1141) }; s__1991000143__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :192:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A{}; t.Ctor_O(p0); return t }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A) Invoke_O_O__O(self, s__1991000145__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1110 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_New_O_O_O(t.F_in_world_QMARK_, s__1991000145__1, self); var tmp2 *jrt.Class; var fncls__1109 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class; if fncls__1109 == nil { var fncls__1109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1110); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class = fncls__1109d; tmp2 = fncls__1109d } else { tmp2 = fncls__1109 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1110, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :192:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1991000145, c__iter__1991000144 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1991000145 = c__s__1991000145; t.F_iter__1991000144 = c__iter__1991000144 }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A) Invoke_O__O(self any) any { { var s__1991000145__1 any; var t_ any = t.F_s__1991000145; t.F_s__1991000145 = nil; s__1991000145__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1039 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = s__1991000145__1; if linked_1040 == nil { temp__1927000414__auto____2 = ifn_1041.Invoke_O__O(arg_1042) } else { temp__1927000414__auto____2 = linked_1040.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1039, arg_1042) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000145__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1043 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = s__1991000145__3; if linked_1044 == nil { tmp1 = ifn_1045.Invoke_O__O(arg_1046) } else { tmp1 = linked_1044.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1043, arg_1046) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1047 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = s__1991000145__3; if linked_1048 == nil { c__1927001037__auto____4 = ifn_1049.Invoke_O__O(arg_1050) } else { c__1927001037__auto____4 = linked_1048.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1047, arg_1050) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000147__6 any; var root_1051 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1052 == nil { b__1991000147__6 = ifn_1053.Invoke_O__O(arg_1054) } else { b__1991000147__6 = linked_1052.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1051, arg_1054) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1065 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_New_O_O_I_O(b__1991000147__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1064 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class; if fncls__1064 == nil { var fncls__1064d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1065); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class = fncls__1064d; tmp3 = fncls__1064d } else { tmp3 = fncls__1064 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1065, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1066 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any; var root_1071 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = b__1991000147__6; if linked_1072 == nil { arg_1069 = ifn_1073.Invoke_O__O(arg_1074) } else { arg_1069 = linked_1072.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1071, arg_1074) }; var arg_1070 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000144); var tmp5 any; var root_1075 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = s__1991000145__3; if linked_1076 == nil { tmp5 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp5 = linked_1076.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1075, arg_1078) }; arg_1070 = tmp4.Invoke_O__O(tmp5); if linked_1067 == nil { return ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { return linked_1067.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) } } else { var root_1079 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var root_1084 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = b__1991000147__6; if linked_1085 == nil { arg_1082 = ifn_1086.Invoke_O__O(arg_1087) } else { arg_1082 = linked_1085.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1084, arg_1087) }; var arg_1083 any; if linked_1080 == nil { return ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { return linked_1080.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) } } } else { var tn__4 any; var root_1088 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = s__1991000145__3; if linked_1089 == nil { tn__4 = ifn_1090.Invoke_O__O(arg_1091) } else { tn__4 = linked_1089.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1088, arg_1091) }; var tmp6 any; var root_1092 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1094 lang.IFn


	if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4); if linked_1093 == nil { tmp6 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp6 = linked_1093.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1092, arg_1095) }
//line :192:1
	if jrt.J2g_Truth(tmp6) { var root_1096 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = tn__4; var arg_1100 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000144); var tmp8 any; var root_1101 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = s__1991000145__3; if linked_1102 == nil { tmp8 = ifn_1103.Invoke_O__O(arg_1104) } else { tmp8 = linked_1102.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1101, arg_1104) }; arg_1100 = tmp7.Invoke_O__O(tmp8); if linked_1097 == nil { return ifn_1098.Invoke_O_O__O(arg_1099, arg_1100) } else { return linked_1097.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1096, arg_1099, arg_1100) } } else { var tmp9 any; var root_1105 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = s__1991000145__3; if linked_1106 == nil { tmp9 = ifn_1107.Invoke_O__O(arg_1108) } else { tmp9 = linked_1106.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1105, arg_1108) }; s__1991000145__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :192:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A) Ctor_O_O_I_O(c__b__1991000147, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000147 = c__b__1991000147; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :192:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A) Invoke_O__O(self any) any { { var i__1991000146__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000146__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000146__1)); var tmp2 any; var root_1055 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1057 lang.IFn


	if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2); if linked_1056 == nil { tmp2 = ifn_1057.Invoke_O__O(arg_1058) } else { tmp2 = linked_1056.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1055, arg_1058) }
//line :192:1
	if jrt.J2g_Truth(tmp2) { var root_1059 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = t.F_b__1991000147; var arg_1063 any = tn__2; if linked_1060 == nil { ifn_1061.Invoke_O_O__O(arg_1062, arg_1063) } else { linked_1060.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1059, arg_1062, arg_1063) }; i__1991000146__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000146__1); continue L1 } else { i__1991000146__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000146__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :194:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :194:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_j2g_embed_data_A_New() *A_arbace_j2g_embed_data_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_j2g_embed_data_A) Ctor() {}
//line :202:1
func (t *A_arbace_j2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any; var root_1159 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1159, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1161 lang.IFn; if




	linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = dir__0; if linked_1160 == nil { base__2 = ifn_1161.Invoke_O__O(arg_1162) } else { base__2 = linked_1160.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1159, arg_1162) }; var root_1163 any =
	A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_1167 any; if
	jrt.File_Cast(base__2).IsDirectory__Z() { var iter__1927001039__auto____3 any; var fnbody__1256 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_New_O(base__2); var tmp1 *jrt.Class; var fncls__1255 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class
		if fncls__1255 == nil { var fncls__1255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__1256); A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class = fncls__1255d; tmp1 = fncls__1255d } else { tmp1 = fncls__1255 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1256, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_1257 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = base__2; if linked_1258 == nil { tmp3 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp3 = linked_1258.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1257, arg_1260) }; arg_1167 = tmp2.Invoke_O__O(tmp3) } else {
//line :209:1
			arg_1167 = nil }; if /*line :208:1*/ linked_1164 == nil { return ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { return linked_1164.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) } }

func A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_New_O(p0 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_A{}; t.Ctor_O(p0); return t }
//line :210:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :210:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A) Invoke_O_O__O(self, s__1991000162__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1254 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_New_O_O_O(s__1991000162__1, t.F_base, self); var tmp2 *jrt.Class; var fncls__1253 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class; if fncls__1253 == nil { var fncls__1253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__1254); A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class = fncls__1253d; tmp2 = fncls__1253d } else { tmp2 = fncls__1253 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1254, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :210:1
func A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :210:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A) Ctor_O_O_O(c__s__1991000162, c__base, c__iter__1991000161 any) { t.F_s__1991000162 = c__s__1991000162; t.F_base = c__base; t.F_iter__1991000161 = c__iter__1991000161 }
//line :210:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A) Invoke_O__O(self any) any { { var s__1991000162__1 any; var t_ any = t.F_s__1991000162; t.F_s__1991000162 = nil; s__1991000162__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1171 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = s__1991000162__1; if linked_1172 == nil { temp__1927000414__auto____2 = ifn_1173.Invoke_O__O(arg_1174) } else { temp__1927000414__auto____2 = linked_1172.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1171, arg_1174) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000162__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1175 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = s__1991000162__3; if linked_1176 == nil { tmp1 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp1 = linked_1176.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1175, arg_1178) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1179 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = s__1991000162__3; if linked_1180 == nil { c__1927001037__auto____4 = ifn_1181.Invoke_O__O(arg_1182) } else { c__1927001037__auto____4 = linked_1180.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1179, arg_1182) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000164__6 any; var root_1183 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1184 == nil { b__1991000164__6 = ifn_1185.Invoke_O__O(arg_1186) } else { b__1991000164__6 = linked_1184.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1183, arg_1186) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1203 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_New_O_O_I_O(t.F_base, b__1991000164__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1202 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class; if fncls__1202 == nil { var fncls__1202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__1203); A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class = fncls__1202d; tmp3 = fncls__1202d } else { tmp3 = fncls__1202 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1203, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1204 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any; var root_1209 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = b__1991000164__6; if linked_1210 == nil { arg_1207 = ifn_1211.Invoke_O__O(arg_1212) } else { arg_1207 = linked_1210.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1209, arg_1212) }; var arg_1208 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000161); var tmp5 any; var root_1213 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = s__1991000162__3; if linked_1214 == nil { tmp5 = ifn_1215.Invoke_O__O(arg_1216) } else { tmp5 = linked_1214.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1213, arg_1216) }; arg_1208 = tmp4.Invoke_O__O(tmp5); if linked_1205 == nil { return ifn_1206.Invoke_O_O__O(arg_1207, arg_1208) } else { return linked_1205.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1204, arg_1207, arg_1208) } } else { var root_1217 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any; var root_1222 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = b__1991000164__6; if linked_1223 == nil { arg_1220 = ifn_1224.Invoke_O__O(arg_1225) } else { arg_1220 = linked_1223.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1222, arg_1225) }; var arg_1221 any; if linked_1218 == nil { return ifn_1219.Invoke_O_O__O(arg_1220, arg_1221) } else { return linked_1218.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1217, arg_1220, arg_1221) } } } else { var f__4 any; var root_1226 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = s__1991000162__3; if linked_1227 == nil { f__4 = ifn_1228.Invoke_O__O(arg_1229) } else { f__4 = linked_1227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1226, arg_1229) }; if jrt.File_Cast(f__4).IsFile__Z() { var root_1230 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any; var tmp6 any; var root_1235 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1237 lang.IFn

	if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any; var root_1241 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_1242 == nil { arg_1238 = ifn_1243.Invoke_O__O(arg_1244) } else { arg_1238 = linked_1242.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1241, arg_1244) }; var arg_1239 any = jrt.File_separator.Ref(); var arg_1240 any = Lit_7; if linked_1236 == nil { tmp6 = ifn_1237.Invoke_O_O_O__O(arg_1238, arg_1239, arg_1240) } else { tmp6 = linked_1236.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1235, arg_1238, arg_1239, arg_1240) }
//line :210:1
	arg_1233 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, f__4); var arg_1234 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000161); var tmp8 any; var root_1245 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = s__1991000162__3; if linked_1246 == nil { tmp8 = ifn_1247.Invoke_O__O(arg_1248) } else { tmp8 = linked_1246.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1245, arg_1248) }; arg_1234 = tmp7.Invoke_O__O(tmp8); if linked_1231 == nil { return ifn_1232.Invoke_O_O__O(arg_1233, arg_1234) } else { return linked_1231.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1230, arg_1233, arg_1234) } } else { var tmp9 any; var root_1249 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = s__1991000162__3; if linked_1250 == nil { tmp9 = ifn_1251.Invoke_O__O(arg_1252) } else { tmp9 = linked_1250.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1249, arg_1252) }; s__1991000162__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :210:1
func A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :210:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A) Ctor_O_O_I_O(c__base, c__b__1991000164 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_base = c__base; t.F_b__1991000164 = c__b__1991000164; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :210:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A) Invoke_O__O(self any) any { { var i__1991000163__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000163__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000163__1)); if jrt.File_Cast(f__2).IsFile__Z() { var root_1187 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = t.F_b__1991000164; var arg_1191 any; var tmp2 any; var root_1192 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1194 lang.IFn

	if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any; var root_1198 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_1199 == nil { arg_1195 = ifn_1200.Invoke_O__O(arg_1201) } else { arg_1195 = linked_1199.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1198, arg_1201) }; var arg_1196 any = jrt.File_separator.Ref(); var arg_1197 any = Lit_7; if linked_1193 == nil { tmp2 = ifn_1194.Invoke_O_O_O__O(arg_1195, arg_1196, arg_1197) } else { tmp2 = linked_1193.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1192, arg_1195, arg_1196, arg_1197) }
//line :210:1
	arg_1191 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, f__2); if linked_1188 == nil { ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { linked_1188.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; i__1991000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000163__1); continue L1 } else { i__1991000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000163__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_user_resources_A_New() *A_arbace_j2g_embed_user_resources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_j2g_embed_user_resources_A) Ctor() {}
//line :214:1
func (t *A_arbace_j2g_embed_user_resources_A) Invoke_O_O_O__O(self, specs__0, taken__1 any) any { { var G__1991000175__3_ any = specs__0; var vec__1991000176__4 any = G__1991000175__3_; var seq__1991000177__5 any; var root_1261 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1263 lang.IFn







	if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = vec__1991000176__4; if linked_1262 == nil { seq__1991000177__5 = ifn_1263.Invoke_O__O(arg_1264) } else { seq__1991000177__5 = linked_1262.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1261, arg_1264) }
//line :214:1
	var first__1991000178__6 any; var root_1265 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1267 lang.IFn







	if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = seq__1991000177__5; if linked_1266 == nil { first__1991000178__6 = ifn_1267.Invoke_O__O(arg_1268) } else { first__1991000178__6 = linked_1266.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1265, arg_1268) }
//line :214:1
	var seq__1991000177__7 any; var root_1269 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1271 lang.IFn







	if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = seq__1991000177__5; if linked_1270 == nil { seq__1991000177__7 = ifn_1271.Invoke_O__O(arg_1272) } else { seq__1991000177__7 = linked_1270.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1269, arg_1272) }
//line :214:1
	var spec__8 any = first__1991000178__6; var more__9 any = seq__1991000177__7; var srcs__10 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var data__11 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var G__1991000175__12_ any = G__1991000175__3_; var srcs__13 any = srcs__10; var data__14 any = data__11; _ = spec__8; _ = more__9; L1: for { var vec__1991000179__15 any = G__1991000175__12_; var seq__1991000180__16 any; var root_1279 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1281 lang.IFn







		if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = vec__1991000179__15; if linked_1280 == nil { seq__1991000180__16 = ifn_1281.Invoke_O__O(arg_1282) } else { seq__1991000180__16 = linked_1280.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1279, arg_1282) }
//line :214:1
		var first__1991000181__17 any; var root_1283 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1285 lang.IFn







		if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = seq__1991000180__16; if linked_1284 == nil { first__1991000181__17 = ifn_1285.Invoke_O__O(arg_1286) } else { first__1991000181__17 = linked_1284.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1283, arg_1286) }
//line :214:1
		var seq__1991000180__18 any; var root_1287 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1289 lang.IFn







		if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = seq__1991000180__16; if linked_1288 == nil { seq__1991000180__18 = ifn_1289.Invoke_O__O(arg_1290) } else { seq__1991000180__18 = linked_1288.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1287, arg_1290) }
//line :214:1
		var spec__19 any = first__1991000181__17
		var more__20 any = seq__1991000180__18
		var srcs__21 any = srcs__13
		var data__22 any = data__14





		if lang.Util_Identical_O_O__Z_NoInit(spec__19, nil) { return lang.Tuple_Create_O_O__IPersistentVector(srcs__21, data__22) } else { var i__23 int32 = jrt.NN(jrt.String_Cast(spec__19)).LastIndexOf_String__I(Lit_66); var vec__1991000182__24 any


			if lang.Numbers_IsPos_J__Z_NoInit(int64(i__23)) { var tmp1 any; var root_1461 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = spec__19; var arg_1465 any = A_arbace_j2g_embed_A_const_34; var arg_1466 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__23).Ref(); if linked_1462 == nil { tmp1 = ifn_1463.Invoke_O_O_O__O(arg_1464, arg_1465, arg_1466) } else { tmp1 = linked_1462.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1461, arg_1464, arg_1465, arg_1466) }; var tmp2 any = tmp1; var tmp3 any; var root_1467 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = spec__19; var arg_1471 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__23))).Ref(); if linked_1468 == nil { tmp3 = ifn_1469.Invoke_O_O__O(arg_1470, arg_1471) } else { tmp3 = linked_1468.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1467, arg_1470, arg_1471) }; vec__1991000182__24 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) } else { vec__1991000182__24 = lang.Tuple_Create_O_O__IPersistentVector(spec__19, nil) }
//line :223:1
			var dir__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000182__24, lang.RT_IntCast_J__I_NoInit(0), nil); var prefix__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000182__24, lang.RT_IntCast_J__I_NoInit(1), nil); var base__27 any; var root_1291 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1291, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1293 lang.IFn



			if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = dir__25; if linked_1292 == nil { base__27 = ifn_1293.Invoke_O__O(arg_1294) } else { base__27 = linked_1292.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1291, arg_1294) }
//line :223:1
			var ___28 any; _ = ___28




			if jrt.File_Cast(base__27).IsDirectory__Z() { ___28 = nil } else { var tmp4 any; var root_1295 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1297 lang.IFn
				if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, spec__19, nil, dir__25)).Ref(); var arg_1299 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1296 == nil { tmp4 = ifn_1297.Invoke_O_O__O(arg_1298, arg_1299) } else { tmp4 = linked_1296.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1295, arg_1298, arg_1299) }
//line :228:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
//line :223:1
			var files__29 any; var iter__1927001039__auto____29 any; var fnbody__1411 any = A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A_New_O_O(base__27, prefix__26); var tmp5 *jrt.Class
			var fncls__1410 /*line :223:1*/*jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A_fn_class






			if fncls__1410 == nil { var fncls__1410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__1411); A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A_fn_class = fncls__1410d; tmp5 = fncls__1410d } else { tmp5 = fncls__1410 }; iter__1927001039__auto____29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1411, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____29); var tmp7 any; var root_1472 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any; var root_1476 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = base__27; if linked_1477 == nil { arg_1475 = ifn_1478.Invoke_O__O(arg_1479) } else { arg_1475 = linked_1477.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1476, arg_1479) }; if linked_1473 == nil { tmp7 = ifn_1474.Invoke_O__O(arg_1475) } else { tmp7 = linked_1473.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1472, arg_1475) }; files__29 = tmp6.Invoke_O__O(tmp7)
//line :223:1
			var vec__1991000185__30 any; var root_1412 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1414 lang.IFn










			if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any; var fnbody__1460 any = A_arbace_j2g_embed_user_resources_fn__1991000200_A_New_O_O(taken__1, spec__19); var tmp8 *jrt.Class; var fncls__1459 *jrt.Class = A_arbace_j2g_embed_user_resources_fn__1991000200_A_fn_class; if fncls__1459 == nil { var fncls__1459d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__1460); A_arbace_j2g_embed_user_resources_fn__1991000200_A_fn_class = fncls__1459d; tmp8 = fncls__1459d } else { tmp8 = fncls__1459 }; arg_1415 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1460, tmp8, nil); var arg_1416 any = lang.Tuple_Create_O_O__IPersistentVector(srcs__21, data__22); var arg_1417 any = files__29; if linked_1413 == nil { vec__1991000185__30 = ifn_1414.Invoke_O_O_O__O(arg_1415, arg_1416, arg_1417) } else { vec__1991000185__30 = linked_1413.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1412, arg_1415, arg_1416, arg_1417) }
//line :223:1
			var srcs__31 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000185__30, lang.RT_IntCast_J__I_NoInit(0), nil); var data__32 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000185__30, lang.RT_IntCast_J__I_NoInit(1), nil)

















			G__1991000175__12_, srcs__13, data__14 = more__20, srcs__31, data__32; continue L1 } } }; /*line :214:1*/panic("j2g: unreachable") }















func A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A) Ctor_O_O(c__base, c__prefix any) { t.F_base = c__base; t.F_prefix = c__prefix }
//line :230:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A) Invoke_O_O__O(self, s__1991000189__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1409 any = A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A_New_O_O_O_O(s__1991000189__1, t.F_base, t.F_prefix, self); var tmp2 *jrt.Class; var fncls__1408 *jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A_fn_class; if fncls__1408 == nil { var fncls__1408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__1409); A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A_fn_class = fncls__1408d; tmp2 = fncls__1408d } else { tmp2 = fncls__1408 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1409, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :230:1
func A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :230:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A) Ctor_O_O_O_O(c__s__1991000189, c__base, c__prefix, c__iter__1991000188 any) { t.F_s__1991000189 = c__s__1991000189; t.F_base = c__base; t.F_prefix = c__prefix; t.F_iter__1991000188 = c__iter__1991000188 }
//line :230:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A) Invoke_O__O(self any) any { { var s__1991000189__1 any; var t_ any = t.F_s__1991000189; t.F_s__1991000189 = nil; s__1991000189__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1300 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = s__1991000189__1; if linked_1301 == nil { temp__1927000414__auto____2 = ifn_1302.Invoke_O__O(arg_1303) } else { temp__1927000414__auto____2 = linked_1301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1300, arg_1303) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000189__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1304 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = s__1991000189__3; if linked_1305 == nil { tmp1 = ifn_1306.Invoke_O__O(arg_1307) } else { tmp1 = linked_1305.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1304, arg_1307) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1308 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = s__1991000189__3; if linked_1309 == nil { c__1927001037__auto____4 = ifn_1310.Invoke_O__O(arg_1311) } else { c__1927001037__auto____4 = linked_1309.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1308, arg_1311) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000191__6 any; var root_1312 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1313 == nil { b__1991000191__6 = ifn_1314.Invoke_O__O(arg_1315) } else { b__1991000191__6 = linked_1313.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1312, arg_1315) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1345 any = A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A_New_O_O_O_I_O(b__1991000191__6, t.F_base, t.F_prefix, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1344 *jrt.Class = A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A_fn_class; if fncls__1344 == nil { var fncls__1344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__1345); A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A_fn_class = fncls__1344d; tmp3 = fncls__1344d } else { tmp3 = fncls__1344 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1345, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1346 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any; var root_1351 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = b__1991000191__6; if linked_1352 == nil { arg_1349 = ifn_1353.Invoke_O__O(arg_1354) } else { arg_1349 = linked_1352.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1351, arg_1354) }; var arg_1350 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000188); var tmp5 any; var root_1355 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = s__1991000189__3; if linked_1356 == nil { tmp5 = ifn_1357.Invoke_O__O(arg_1358) } else { tmp5 = linked_1356.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1355, arg_1358) }; arg_1350 = tmp4.Invoke_O__O(tmp5); if linked_1347 == nil { return ifn_1348.Invoke_O_O__O(arg_1349, arg_1350) } else { return linked_1347.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1346, arg_1349, arg_1350) } } else { var root_1359 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var root_1364 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = b__1991000191__6; if linked_1365 == nil { arg_1362 = ifn_1366.Invoke_O__O(arg_1367) } else { arg_1362 = linked_1365.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1364, arg_1367) }; var arg_1363 any; if linked_1360 == nil { return ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { return linked_1360.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) } } } else { var f__4 any; var root_1368 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = s__1991000189__3; if linked_1369 == nil { f__4 = ifn_1370.Invoke_O__O(arg_1371) } else { f__4 = linked_1369.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1368, arg_1371) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()
															if and__1927000168__auto____5 { var root_1372 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any; var root_1376 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1380 any = Lit_1; if linked_1377 == nil { arg_1375 = ifn_1378.Invoke_O_O__O(arg_1379, arg_1380) } else { arg_1375 = linked_1377.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1376, arg_1379, arg_1380) }; if linked_1373 == nil { tmp6 = ifn_1374.Invoke_O__O(arg_1375) } else { tmp6 = linked_1373.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1372, arg_1375) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :230:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var root_1381 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1383 lang.IFn

		if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any; var root_1387 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_1388 == nil { arg_1384 = ifn_1389.Invoke_O__O(arg_1390) } else { arg_1384 = linked_1388.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1387, arg_1390) }; var arg_1385 any = jrt.File_separator.Ref(); var arg_1386 any = Lit_7; if linked_1382 == nil { rel__5 = ifn_1383.Invoke_O_O_O__O(arg_1384, arg_1385, arg_1386) } else { rel__5 = linked_1382.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1381, arg_1384, arg_1385, arg_1386) }
//line :230:1
		var root_1391 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any; var tmp7 any; var tmp8 any; var root_1396 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1398 lang.IFn


		if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = t.F_prefix; if linked_1397 == nil { tmp8 = ifn_1398.Invoke_O__O(arg_1399) } else { tmp8 = linked_1397.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1396, arg_1399) }; if jrt.J2g_Truth(tmp8) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, nil, rel__5)).Ref() } else { tmp7 = rel__5 }
//line :230:1
		arg_1394 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, f__4); var arg_1395 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1991000188); var tmp10 any; var root_1400 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = s__1991000189__3; if linked_1401 == nil { tmp10 = ifn_1402.Invoke_O__O(arg_1403) } else { tmp10 = linked_1401.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1400, arg_1403) }; arg_1395 = tmp9.Invoke_O__O(tmp10); if linked_1392 == nil { return ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { return linked_1392.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) } } else { var tmp11 any; var root_1404 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = s__1991000189__3; if linked_1405 == nil { tmp11 = ifn_1406.Invoke_O__O(arg_1407) } else { tmp11 = linked_1405.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1404, arg_1407) }; s__1991000189__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :230:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A) Ctor_O_O_O_I_O(c__b__1991000191, c__base, c__prefix any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000191 = c__b__1991000191; t.F_base = c__base; t.F_prefix = c__prefix; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :230:1
func (t *A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A) Invoke_O__O(self any) any { { var i__1991000190__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000190__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000190__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()
																	if and__1927000168__auto____3 { var root_1316 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any; var root_1320 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1324 any = Lit_1; if linked_1321 == nil { arg_1319 = ifn_1322.Invoke_O_O__O(arg_1323, arg_1324) } else { arg_1319 = linked_1321.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1320, arg_1323, arg_1324) }; if linked_1317 == nil { tmp2 = ifn_1318.Invoke_O__O(arg_1319) } else { tmp2 = linked_1317.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1316, arg_1319) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :230:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var root_1325 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1327 lang.IFn

		if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any; var root_1331 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_1332 == nil { arg_1328 = ifn_1333.Invoke_O__O(arg_1334) } else { arg_1328 = linked_1332.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1331, arg_1334) }; var arg_1329 any = jrt.File_separator.Ref(); var arg_1330 any = Lit_7; if linked_1326 == nil { rel__3 = ifn_1327.Invoke_O_O_O__O(arg_1328, arg_1329, arg_1330) } else { rel__3 = linked_1326.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1325, arg_1328, arg_1329, arg_1330) }
//line :230:1
		var root_1335 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = t.F_b__1991000191; var arg_1339 any; var tmp3 any; var tmp4 any; var root_1340 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1342 lang.IFn


		if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = t.F_prefix; if linked_1341 == nil { tmp4 = ifn_1342.Invoke_O__O(arg_1343) } else { tmp4 = linked_1341.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1340, arg_1343) }; if jrt.J2g_Truth(tmp4) { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, t.F_prefix, nil, rel__3)).Ref() } else { tmp3 = rel__3 }
//line :230:1
		arg_1339 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, f__2); if linked_1336 == nil { ifn_1337.Invoke_O_O__O(arg_1338, arg_1339) } else { linked_1336.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1335, arg_1338, arg_1339) }; i__1991000190__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000190__1); continue L1 } else { i__1991000190__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000190__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_user_resources_fn__1991000200_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_user_resources_fn__1991000200_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_user_resources_fn__1991000200_A{}; t.Ctor_O_O(p0, p1); return t }
//line :234:1
func (t *A_arbace_j2g_embed_user_resources_fn__1991000200_A) Ctor_O_O(c__taken, c__spec any) { t.F_taken = c__taken; t.F_spec = c__spec }
//line :234:1
func (t *A_arbace_j2g_embed_user_resources_fn__1991000200_A) Invoke_O_O_O__O(self, p__1991000198__1, p__1991000199__2 any) any { var vec__1991000201__3 any = p__1991000198__1; var srcs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000201__3, lang.RT_IntCast_J__I_NoInit(0), nil); var data__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000201__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1991000204__6 any = p__1991000199__2; var p__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000204__6, lang.RT_IntCast_J__I_NoInit(0), nil); var f__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000204__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____9 any; var root_1423 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1425 lang.IFn; if
																linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = t.F_taken; var arg_1427 any = p__7; if linked_1424 == nil { or__1927000174__auto____9 = ifn_1425.Invoke_O_O__O(arg_1426, arg_1427) } else { or__1927000174__auto____9 = linked_1424.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1423, arg_1426, arg_1427) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any; var root_1428 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = srcs__4; var arg_1432 any = p__7; if linked_1429 == nil { or__1927000174__auto____10 = ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { or__1927000174__auto____10 = linked_1429.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var root_1433 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = data__5; var arg_1437 any = p__7; if linked_1434 == nil { tmp1 = ifn_1435.Invoke_O_O__O(arg_1436, arg_1437) } else { tmp1 = linked_1434.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1433, arg_1436, arg_1437) } } }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1438 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1440 lang.IFn
																	if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_56, nil, Lit_71), jrt.RefArrayOf(jrt.Object_class, nil, t.F_spec, nil, p__7, nil)).Ref(); var arg_1442 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1439 == nil { tmp2 = ifn_1440.Invoke_O_O__O(arg_1441, arg_1442) } else { tmp2 = linked_1439.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1438, arg_1441, arg_1442) }
//line :235:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp3 any; var root_1418 any =

	A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = A_arbace_j2g_embed_A_const_97; var arg_1422 any = p__7; if linked_1419 == nil { tmp3 = ifn_1420.Invoke_O_O__O(arg_1421, arg_1422) } else { tmp3 = linked_1419.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1418, arg_1421, arg_1422) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_1443 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1445 lang.IFn
		if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = srcs__4; var arg_1447 any = p__7; var arg_1448 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__8); if linked_1444 == nil { tmp4 = ifn_1445.Invoke_O_O_O__O(arg_1446, arg_1447, arg_1448) } else { tmp4 = linked_1444.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1443, arg_1446, arg_1447, arg_1448) }
//line :237:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp4, data__5) } else { var tmp5 any; var root_1453 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1455 lang.IFn

			if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = data__5; var arg_1457 any = p__7; var arg_1458 any = f__8; if linked_1454 == nil { tmp5 = ifn_1455.Invoke_O_O_O__O(arg_1456, arg_1457, arg_1458) } else { tmp5 = linked_1454.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1453, arg_1456, arg_1457, arg_1458) }
//line :237:1
			return lang.Tuple_Create_O_O__IPersistentVector(srcs__4, tmp5) } }





func A_arbace_j2g_embed_package_loaders_A_New() *A_arbace_j2g_embed_package_loaders_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_j2g_embed_package_loaders_A) Ctor() {}
//line :243:1
func (t *A_arbace_j2g_embed_package_loaders_A) Invoke_O_O_O__O(self, dirs__0, taken__1 any) any {





	var root_1480 any = A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_1484 any; var iter__1927001039__auto____3 any; var fnbody__1680 any = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A_New_O(taken__1); var tmp1 *jrt.Class; var fncls__1679 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A_fn_class
	if fncls__1679 == nil { var fncls__1679d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__1680); A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A_fn_class = fncls__1679d; tmp1 = fncls__1679d } else { tmp1 = fncls__1679 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1680, tmp1, nil); arg_1484 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(dirs__0)
//line :249:1
	if linked_1481 == nil { return ifn_1482.Invoke_O_O__O(arg_1483, arg_1484) } else { return linked_1481.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1480, arg_1483, arg_1484) } }
func A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A_New_O(p0 any) *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A{}; t.Ctor_O(p0); return t }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A) Ctor_O(c__taken any) { t.F_taken = c__taken }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A) Invoke_O_O__O(self, s__1991000210__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1678 any = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A_New_O_O_O(self, t.F_taken, s__1991000210__1); var tmp2 *jrt.Class; var fncls__1677 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A_fn_class; if fncls__1677 == nil { var fncls__1677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1678); A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A_fn_class = fncls__1677d; tmp2 = fncls__1677d } else { tmp2 = fncls__1677 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1678, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :250:1
func A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A) Ctor_O_O_O(c__iter__1991000209, c__taken, c__s__1991000210 any) { t.F_iter__1991000209 = c__iter__1991000209; t.F_taken = c__taken; t.F_s__1991000210 = c__s__1991000210 }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A) Invoke_O__O(self any) any { { var s__1991000210__1 any; var t_ any = t.F_s__1991000210; t.F_s__1991000210 = nil; s__1991000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1488 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = s__1991000210__1; if linked_1489 == nil { temp__1927000414__auto____2 = ifn_1490.Invoke_O__O(arg_1491) } else { temp__1927000414__auto____2 = linked_1489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1488, arg_1491) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var dir__4 any; var root_1492 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = xs__1927001018__auto____3; if linked_1493 == nil { dir__4 = ifn_1494.Invoke_O__O(arg_1495) } else { dir__4 = linked_1493.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1492, arg_1495) }; var base__5 any; var root_1496 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1496, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1498 lang.IFn
															if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = dir__4; if linked_1497 == nil { base__5 = ifn_1498.Invoke_O__O(arg_1499) } else { base__5 = linked_1497.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1496, arg_1499) }
//line :250:1
	var iterys__1927001035__auto____6 any; var fnbody__1651 any = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A_New_O_O(t.F_taken, base__5); var tmp1 *jrt.Class; var fncls__1650 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A_fn_class; if fncls__1650 == nil { var fncls__1650d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1651); A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A_fn_class = fncls__1650d; tmp1 = fncls__1650d } else { tmp1 = fncls__1650 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1651, tmp1, nil); var fs__1927001036__auto____7 any; var root_1652 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp3 any; var root_1656 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1658 lang.IFn

	if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any; var root_1660 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = base__5; if linked_1661 == nil { arg_1659 = ifn_1662.Invoke_O__O(arg_1663) } else { arg_1659 = linked_1661.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1660, arg_1663) }; if linked_1657 == nil { tmp3 = ifn_1658.Invoke_O__O(arg_1659) } else { tmp3 = linked_1657.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1656, arg_1659) }
//line :250:1
	arg_1655 = tmp2.Invoke_O__O(tmp3); if linked_1653 == nil { fs__1927001036__auto____7 = ifn_1654.Invoke_O__O(arg_1655) } else { fs__1927001036__auto____7 = linked_1653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1652, arg_1655) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_1664 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = fs__1927001036__auto____7; var arg_1668 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000209); var tmp5 any; var root_1669 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = s__1991000210__1; if linked_1670 == nil { tmp5 = ifn_1671.Invoke_O__O(arg_1672) } else { tmp5 = linked_1670.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1669, arg_1672) }; arg_1668 = tmp4.Invoke_O__O(tmp5); if linked_1665 == nil { return ifn_1666.Invoke_O_O__O(arg_1667, arg_1668) } else { return linked_1665.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1664, arg_1667, arg_1668) } } else { var tmp6 any; var root_1673 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = s__1991000210__1; if linked_1674 == nil { tmp6 = ifn_1675.Invoke_O__O(arg_1676) } else { tmp6 = linked_1674.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1673, arg_1676) }; s__1991000210__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :250:1
func A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A{}; t.Ctor_O_O(p0, p1); return t }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A) Ctor_O_O(c__taken, c__base any) { t.F_taken = c__taken; t.F_base = c__base }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A) Invoke_O_O__O(self, s__1991000212__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1649 any = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A_New_O_O_O_O(t.F_taken, t.F_base, s__1991000212__1, self); var tmp2 *jrt.Class; var fncls__1648 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A_fn_class; if fncls__1648 == nil { var fncls__1648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__1649); A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A_fn_class = fncls__1648d; tmp2 = fncls__1648d } else { tmp2 = fncls__1648 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1649, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :250:1
func A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A) Ctor_O_O_O_O(c__taken, c__base, c__s__1991000212, c__iter__1991000211 any) { t.F_taken = c__taken; t.F_base = c__base; t.F_s__1991000212 = c__s__1991000212; t.F_iter__1991000211 = c__iter__1991000211 }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A) Invoke_O__O(self any) any { { var s__1991000212__1 any; var t_ any = t.F_s__1991000212; t.F_s__1991000212 = nil; s__1991000212__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1500 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = s__1991000212__1; if linked_1501 == nil { temp__1927000414__auto____2 = ifn_1502.Invoke_O__O(arg_1503) } else { temp__1927000414__auto____2 = linked_1501.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1500, arg_1503) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000212__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1504 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = s__1991000212__3; if linked_1505 == nil { tmp1 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp1 = linked_1505.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1504, arg_1507) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1508 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = s__1991000212__3; if linked_1509 == nil { c__1927001037__auto____4 = ifn_1510.Invoke_O__O(arg_1511) } else { c__1927001037__auto____4 = linked_1509.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1508, arg_1511) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000214__6 any; var root_1512 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1513 == nil { b__1991000214__6 = ifn_1514.Invoke_O__O(arg_1515) } else { b__1991000214__6 = linked_1513.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1512, arg_1515) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1563 any = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A_New_O_O_O_I_O(b__1991000214__6, t.F_taken, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1562 *jrt.Class = A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A_fn_class; if fncls__1562 == nil { var fncls__1562d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__1563); A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A_fn_class = fncls__1562d; tmp3 = fncls__1562d } else { tmp3 = fncls__1562 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1563, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1564 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any; var root_1569 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = b__1991000214__6; if linked_1570 == nil { arg_1567 = ifn_1571.Invoke_O__O(arg_1572) } else { arg_1567 = linked_1570.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1569, arg_1572) }; var arg_1568 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); var tmp5 any; var root_1573 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = s__1991000212__3; if linked_1574 == nil { tmp5 = ifn_1575.Invoke_O__O(arg_1576) } else { tmp5 = linked_1574.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1573, arg_1576) }; arg_1568 = tmp4.Invoke_O__O(tmp5); if linked_1565 == nil { return ifn_1566.Invoke_O_O__O(arg_1567, arg_1568) } else { return linked_1565.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1564, arg_1567, arg_1568) } } else { var root_1577 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any; var root_1582 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = b__1991000214__6; if linked_1583 == nil { arg_1580 = ifn_1584.Invoke_O__O(arg_1585) } else { arg_1580 = linked_1583.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1582, arg_1585) }; var arg_1581 any; if linked_1578 == nil { return ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { return linked_1578.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) } } } else { var f__4 any; var root_1586 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = s__1991000212__3; if linked_1587 == nil { f__4 = ifn_1588.Invoke_O__O(arg_1589) } else { f__4 = linked_1587.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1586, arg_1589) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()


	if and__1927000168__auto____5 { var root_1590 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1594 any = Lit_28; if linked_1591 == nil { tmp6 = ifn_1592.Invoke_O_O__O(arg_1593, arg_1594) } else { tmp6 = linked_1591.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1590, arg_1593, arg_1594) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :250:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var root_1595 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1597 lang.IFn



		if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any; var root_1601 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_1602 == nil { arg_1598 = ifn_1603.Invoke_O__O(arg_1604) } else { arg_1598 = linked_1602.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1601, arg_1604) }; var arg_1599 any = jrt.File_separator.Ref(); var arg_1600 any = Lit_7; if linked_1596 == nil { rel__5 = ifn_1597.Invoke_O_O_O__O(arg_1598, arg_1599, arg_1600) } else { rel__5 = linked_1596.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1595, arg_1598, arg_1599, arg_1600) }
//line :250:1
		var m__6 any; var root_1605 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1607 lang.IFn




		if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = A_arbace_j2g_embed_A_const_98; var arg_1609 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4); if linked_1606 == nil { m__6 = ifn_1607.Invoke_O_O__O(arg_1608, arg_1609) } else { m__6 = linked_1606.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1605, arg_1608, arg_1609) }
//line :250:1
		var tmp7 any
		var and__1927000168__auto____7 any = m__6




		if jrt.J2g_Truth(and__1927000168__auto____7) { var root_1614 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any; var root_1618 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = t.F_taken; var arg_1622 any = rel__5; if linked_1619 == nil { arg_1617 = ifn_1620.Invoke_O_O__O(arg_1621, arg_1622) } else { arg_1617 = linked_1619.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1618, arg_1621, arg_1622) }; if linked_1615 == nil { tmp7 = ifn_1616.Invoke_O__O(arg_1617) } else { tmp7 = linked_1615.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1614, arg_1617) } } else { tmp7 = and__1927000168__auto____7 }
//line :250:1
		if jrt.J2g_Truth(tmp7) { var root_1623 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any; var tmp8 *jrt.RefArray = jrt.ConstRefArray("[0,7,s43:;; j2g --java-namespaces: the Java package ns29:'s namespace, a no-op loader\ns74:;; (its classes are the program's; bin/arbace-go --build-program, RPS93).\ns4:(ns ns2:)\n", []*jrt.Class{jrt.String_class}); var tmp9 any; var root_1628 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1630 lang.IFn






			if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = m__6; if linked_1629 == nil { tmp9 = ifn_1630.Invoke_O__O(arg_1631) } else { tmp9 = linked_1629.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1628, arg_1631) }
//line :250:1
			var tmp10 any = tmp9; var tmp11 any; var root_1632 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1634 lang.IFn








			if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = m__6; if linked_1633 == nil { tmp11 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp11 = linked_1633.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1632, arg_1635) }
//line :250:1
			arg_1626 = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, nil, nil, tmp11, nil)).Ref()); var arg_1627 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); var tmp13 any; var root_1636 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = s__1991000212__3; if linked_1637 == nil { tmp13 = ifn_1638.Invoke_O__O(arg_1639) } else { tmp13 = linked_1637.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1636, arg_1639) }; arg_1627 = tmp12.Invoke_O__O(tmp13); if linked_1624 == nil { return ifn_1625.Invoke_O_O__O(arg_1626, arg_1627) } else { return linked_1624.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1623, arg_1626, arg_1627) } } else { var tmp14 any; var root_1640 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = s__1991000212__3; if linked_1641 == nil { tmp14 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp14 = linked_1641.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1640, arg_1643) }; s__1991000212__1 = tmp14; continue L1 } } else { var tmp15 any; var root_1644 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = s__1991000212__3; if linked_1645 == nil { tmp15 = ifn_1646.Invoke_O__O(arg_1647) } else { tmp15 = linked_1645.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1644, arg_1647) }; s__1991000212__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :250:1
func A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A) Ctor_O_O_O_I_O(c__b__1991000214, c__taken, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000214 = c__b__1991000214; t.F_taken = c__taken; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :250:1
func (t *A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A) Invoke_O__O(self any) any { { var i__1991000213__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000213__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000213__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()


	if and__1927000168__auto____3 { var root_1516 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1520 any = Lit_28; if linked_1517 == nil { tmp2 = ifn_1518.Invoke_O_O__O(arg_1519, arg_1520) } else { tmp2 = linked_1517.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1516, arg_1519, arg_1520) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :250:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var root_1521 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1523 lang.IFn



		if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any; var root_1527 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = jrt.File_Cast(t.F_base).ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_1528 == nil { arg_1524 = ifn_1529.Invoke_O__O(arg_1530) } else { arg_1524 = linked_1528.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1527, arg_1530) }; var arg_1525 any = jrt.File_separator.Ref(); var arg_1526 any = Lit_7; if linked_1522 == nil { rel__3 = ifn_1523.Invoke_O_O_O__O(arg_1524, arg_1525, arg_1526) } else { rel__3 = linked_1522.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1521, arg_1524, arg_1525, arg_1526) }
//line :250:1
		var m__4 any; var root_1531 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1533 lang.IFn




		if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = A_arbace_j2g_embed_A_const_98; var arg_1535 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2); if linked_1532 == nil { m__4 = ifn_1533.Invoke_O_O__O(arg_1534, arg_1535) } else { m__4 = linked_1532.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1531, arg_1534, arg_1535) }
//line :250:1
		var tmp3 any
		var and__1927000168__auto____5 any = m__4




		if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1540 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any; var root_1544 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = t.F_taken; var arg_1548 any = rel__3; if linked_1545 == nil { arg_1543 = ifn_1546.Invoke_O_O__O(arg_1547, arg_1548) } else { arg_1543 = linked_1545.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1544, arg_1547, arg_1548) }; if linked_1541 == nil { tmp3 = ifn_1542.Invoke_O__O(arg_1543) } else { tmp3 = linked_1541.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1540, arg_1543) } } else { tmp3 = and__1927000168__auto____5 }
//line :250:1
		if jrt.J2g_Truth(tmp3) { var root_1549 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = t.F_b__1991000214; var arg_1553 any; var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,7,s43:;; j2g --java-namespaces: the Java package ns29:'s namespace, a no-op loader\ns74:;; (its classes are the program's; bin/arbace-go --build-program, RPS93).\ns4:(ns ns2:)\n", []*jrt.Class{jrt.String_class}); var tmp5 any; var root_1554 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1556 lang.IFn






			if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = m__4; if linked_1555 == nil { tmp5 = ifn_1556.Invoke_O__O(arg_1557) } else { tmp5 = linked_1555.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1554, arg_1557) }
//line :250:1
			var tmp6 any = tmp5; var tmp7 any; var root_1558 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1560 lang.IFn








			if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = m__4; if linked_1559 == nil { tmp7 = ifn_1560.Invoke_O__O(arg_1561) } else { tmp7 = linked_1559.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1558, arg_1561) }
//line :250:1
			arg_1553 = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, nil, nil, tmp7, nil)).Ref()); if linked_1550 == nil { ifn_1551.Invoke_O_O__O(arg_1552, arg_1553) } else { linked_1550.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1549, arg_1552, arg_1553) }; i__1991000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000213__1); continue L1 } else { i__1991000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000213__1); continue L1 } } else { i__1991000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000213__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
























func A_arbace_j2g_embed_image_type_forms_A_New() *A_arbace_j2g_embed_image_type_forms_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Ctor() {}
//line :275:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any = A_arbace_j2g_embed_A_const_100; var files__3 any; var iter__1927001039__auto____3 any; var fnbody__1813 any = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A_New_O(prog_dir__0); var tmp1 *jrt.Class; var fncls__1812 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A_fn_class; if





	fncls__1812 == nil { var fncls__1812d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__1813); A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A_fn_class = fncls__1812d; tmp1 = fncls__1812d } else { tmp1 = fncls__1812 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1813, tmp1, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_j2g_embed_A_const_117); var types__4 any; var root_1814 any = /*line :275:1*/A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1816 lang.IFn; if












	linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var arg_1818 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp3 any; var root_1825 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; if linked_1826 == nil { tmp3 = ifn_1827.Invoke__O() } else { tmp3 = linked_1826.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_1825) }; var tmp4 any = tmp3; var tmp5 *lang.Compiler_AOTFn; var fnbody__1914 any = A_arbace_j2g_embed_image_type_forms_fn__1991000246_A_New_O(re__2); var tmp6 *jrt.Class; var fncls__1913 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000246_A_fn_class; if fncls__1913 == nil { var fncls__1913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__1914); A_arbace_j2g_embed_image_type_forms_fn__1991000246_A_fn_class = fncls__1913d; tmp6 = fncls__1913d } else { tmp6 = fncls__1913 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1914, tmp6, nil); arg_1818 = tmp2.Invoke_O_O_O__O(tmp4, tmp5.Ref(), files__3); if linked_1815 == nil { types__4 = ifn_1816.Invoke_O_O__O(arg_1817, arg_1818) } else { types__4 = linked_1815.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1814, arg_1817, arg_1818) }; var root_1915 any =



	A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_104, Lit_18, A_arbace_j2g_embed_A_const_105, A_arbace_j2g_embed_A_const_106)); var arg_1919 any; var iter__1927001039__auto____5 any; var fnbody__2119 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A_New(); var tmp7 *jrt.Class; var fncls__2118 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A_fn_class; if
	fncls__2118 == nil { var fncls__2118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A_fn_class = fncls__2118d; tmp7 = fncls__2118d } else { tmp7 = fncls__2118 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2119, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp9 any; var root_2120 any = A_arbace_j2g_embed_A_const_115.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_partition_all_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = A_arbace_j2g_embed_A_const_116; var arg_2124 any; var root_2125 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_2129 any; var root_2130 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = types__4; if linked_2131 == nil { arg_2129 = ifn_2132.Invoke_O__O(arg_2133) } else { arg_2129 = linked_2131.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2130, arg_2133) }; if linked_2126 == nil { arg_2124 = ifn_2127.Invoke_O_O__O(arg_2128, arg_2129) } else { arg_2124 = linked_2126.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2125, arg_2128, arg_2129) }; if linked_2121 == nil { tmp9 = ifn_2122.Invoke_O_O__O(arg_2123, arg_2124) } else { tmp9 = linked_2121.(*aot_arbace_core.A_arbace_core_partition_all_A).Invoke_O_O_O__O(root_2120, arg_2123, arg_2124) }; arg_1919 = tmp8.Invoke_O__O(tmp9); if /*line :292:1*/ linked_1916 == nil { return ifn_1917.Invoke_O_O__O(arg_1918, arg_1919) } else { return linked_1916.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1915, arg_1918, arg_1919) } }
//line :281:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A{}; t.Ctor_O(p0); return t }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A) Invoke_O_O__O(self, s__1991000227__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1811 any = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A_New_O_O_O(t.F_prog_dir, s__1991000227__1, self); var tmp2 *jrt.Class; var fncls__1810 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A_fn_class; if fncls__1810 == nil { var fncls__1810d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__1811); A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A_fn_class = fncls__1810d; tmp2 = fncls__1810d } else { tmp2 = fncls__1810 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1811, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :281:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A) Ctor_O_O_O(c__prog_dir, c__s__1991000227, c__iter__1991000226 any) { t.F_prog_dir = c__prog_dir; t.F_s__1991000227 = c__s__1991000227; t.F_iter__1991000226 = c__iter__1991000226 }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A) Invoke_O__O(self any) any { { var s__1991000227__1 any; var t_ any = t.F_s__1991000227; t.F_s__1991000227 = nil; s__1991000227__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1681 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = s__1991000227__1; if linked_1682 == nil { temp__1927000414__auto____2 = ifn_1683.Invoke_O__O(arg_1684) } else { temp__1927000414__auto____2 = linked_1682.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1681, arg_1684) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1991000234__4 any; var root_1685 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1685, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1687 lang.IFn; if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any = xs__1927001018__auto____3; if linked_1686 == nil { vec__1991000234__4 = ifn_1687.Invoke_O__O(arg_1688) } else { vec__1991000234__4 = linked_1686.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1685, arg_1688) }; var pkg__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000234__4, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000234__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dir__7 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_24, pkg__5); var iterys__1927001035__auto____8 any; var fnbody__1788 any = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A_New_O(alias__6); var tmp1 *jrt.Class; var fncls__1787 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A_fn_class; if fncls__1787 == nil { var fncls__1787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__1788); A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A_fn_class = fncls__1787d; tmp1 = fncls__1787d } else { tmp1 = fncls__1787 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1788, tmp1, nil); var fs__1927001036__auto____9 any; var root_1789 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp3 any; var root_1793 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1795 lang.IFn

	if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = jrt.File_Cast(dir__7).ListFiles__File1().Ref(); if linked_1794 == nil { tmp3 = ifn_1795.Invoke_O__O(arg_1796) } else { tmp3 = linked_1794.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1793, arg_1796) }
//line :281:1
	arg_1792 = tmp2.Invoke_O__O(tmp3); if linked_1790 == nil { fs__1927001036__auto____9 = ifn_1791.Invoke_O__O(arg_1792) } else { fs__1927001036__auto____9 = linked_1790.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1789, arg_1792) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_1797 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1799 lang.IFn; if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = fs__1927001036__auto____9; var arg_1801 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000226); var tmp5 any; var root_1802 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = s__1991000227__1; if linked_1803 == nil { tmp5 = ifn_1804.Invoke_O__O(arg_1805) } else { tmp5 = linked_1803.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1802, arg_1805) }; arg_1801 = tmp4.Invoke_O__O(tmp5); if linked_1798 == nil { return ifn_1799.Invoke_O_O__O(arg_1800, arg_1801) } else { return linked_1798.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1797, arg_1800, arg_1801) } } else { var tmp6 any; var root_1806 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1808 lang.IFn; if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = s__1991000227__1; if linked_1807 == nil { tmp6 = ifn_1808.Invoke_O__O(arg_1809) } else { tmp6 = linked_1807.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1806, arg_1809) }; s__1991000227__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :281:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A{}; t.Ctor_O(p0); return t }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A) Invoke_O_O__O(self, s__1991000229__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1786 any = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A_New_O_O_O(self, t.F_alias, s__1991000229__1); var tmp2 *jrt.Class; var fncls__1785 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A_fn_class; if fncls__1785 == nil { var fncls__1785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__1786); A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A_fn_class = fncls__1785d; tmp2 = fncls__1785d } else { tmp2 = fncls__1785 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1786, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :281:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A) Ctor_O_O_O(c__iter__1991000228, c__alias, c__s__1991000229 any) { t.F_iter__1991000228 = c__iter__1991000228; t.F_alias = c__alias; t.F_s__1991000229 = c__s__1991000229 }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A) Invoke_O__O(self any) any { { var s__1991000229__1 any; var t_ any = t.F_s__1991000229; t.F_s__1991000229 = nil; s__1991000229__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1695 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = s__1991000229__1; if linked_1696 == nil { temp__1927000414__auto____2 = ifn_1697.Invoke_O__O(arg_1698) } else { temp__1927000414__auto____2 = linked_1696.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1695, arg_1698) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000229__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1699 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = s__1991000229__3; if linked_1700 == nil { tmp1 = ifn_1701.Invoke_O__O(arg_1702) } else { tmp1 = linked_1700.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1699, arg_1702) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1703 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = s__1991000229__3; if linked_1704 == nil { c__1927001037__auto____4 = ifn_1705.Invoke_O__O(arg_1706) } else { c__1927001037__auto____4 = linked_1704.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1703, arg_1706) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000231__6 any; var root_1707 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1708 == nil { b__1991000231__6 = ifn_1709.Invoke_O__O(arg_1710) } else { b__1991000231__6 = linked_1708.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1707, arg_1710) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1731 any = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, b__1991000231__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1730 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A_fn_class; if fncls__1730 == nil { var fncls__1730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__1731); A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A_fn_class = fncls__1730d; tmp3 = fncls__1730d } else { tmp3 = fncls__1730 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1731, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1732 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any; var root_1737 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = b__1991000231__6; if linked_1738 == nil { arg_1735 = ifn_1739.Invoke_O__O(arg_1740) } else { arg_1735 = linked_1738.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1737, arg_1740) }; var arg_1736 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000228); var tmp5 any; var root_1741 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = s__1991000229__3; if linked_1742 == nil { tmp5 = ifn_1743.Invoke_O__O(arg_1744) } else { tmp5 = linked_1742.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1741, arg_1744) }; arg_1736 = tmp4.Invoke_O__O(tmp5); if linked_1733 == nil { return ifn_1734.Invoke_O_O__O(arg_1735, arg_1736) } else { return linked_1733.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1732, arg_1735, arg_1736) } } else { var root_1745 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1745, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1747 lang.IFn; if linked_1746 == nil { ifn_1747 = lang.IFn_Cast(root_1745) } else { ifn_1747 = nil }; var arg_1748 any; var root_1750 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = b__1991000231__6; if linked_1751 == nil { arg_1748 = ifn_1752.Invoke_O__O(arg_1753) } else { arg_1748 = linked_1751.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1750, arg_1753) }; var arg_1749 any; if linked_1746 == nil { return ifn_1747.Invoke_O_O__O(arg_1748, arg_1749) } else { return linked_1746.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1745, arg_1748, arg_1749) } } } else { var f__4 any; var root_1754 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = s__1991000229__3; if linked_1755 == nil { f__4 = ifn_1756.Invoke_O__O(arg_1757) } else { f__4 = linked_1755.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1754, arg_1757) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1758 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1762 any = Lit_28; if linked_1759 == nil { and__1927000168__auto____6 = ifn_1760.Invoke_O_O__O(arg_1761, arg_1762) } else { and__1927000168__auto____6 = linked_1759.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1758, arg_1761, arg_1762) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_1763 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any; var root_1767 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1769 lang.IFn; if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_1771 any = Lit_29; if linked_1768 == nil { arg_1766 = ifn_1769.Invoke_O_O__O(arg_1770, arg_1771) } else { arg_1766 = linked_1768.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1767, arg_1770, arg_1771) }; if linked_1764 == nil { tmp6 = ifn_1765.Invoke_O__O(arg_1766) } else { tmp6 = linked_1764.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1763, arg_1766) } } else {
//line :284:1
			tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :281:1
	if jrt.J2g_Truth(tmp6) { var root_1772 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1774 lang.IFn; if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4); var arg_1776 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000228); var tmp8 any; var root_1777 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = s__1991000229__3; if linked_1778 == nil { tmp8 = ifn_1779.Invoke_O__O(arg_1780) } else { tmp8 = linked_1778.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1777, arg_1780) }; arg_1776 = tmp7.Invoke_O__O(tmp8); if linked_1773 == nil { return ifn_1774.Invoke_O_O__O(arg_1775, arg_1776) } else { return linked_1773.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1772, arg_1775, arg_1776) } } else { var tmp9 any; var root_1781 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = s__1991000229__3; if linked_1782 == nil { tmp9 = ifn_1783.Invoke_O__O(arg_1784) } else { tmp9 = linked_1782.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1781, arg_1784) }; s__1991000229__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :281:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__b__1991000231, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000231 = c__b__1991000231; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :281:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A) Invoke_O__O(self any) any { { var i__1991000230__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000230__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000230__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1711 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1715 any = Lit_28; if linked_1712 == nil { and__1927000168__auto____4 = ifn_1713.Invoke_O_O__O(arg_1714, arg_1715) } else { and__1927000168__auto____4 = linked_1712.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1711, arg_1714, arg_1715) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1716 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any; var root_1720 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_1724 any = Lit_29; if linked_1721 == nil { arg_1719 = ifn_1722.Invoke_O_O__O(arg_1723, arg_1724) } else { arg_1719 = linked_1721.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1720, arg_1723, arg_1724) }; if linked_1717 == nil { tmp2 = ifn_1718.Invoke_O__O(arg_1719) } else { tmp2 = linked_1717.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1716, arg_1719) } } else {
//line :284:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :281:1
	if jrt.J2g_Truth(tmp2) { var root_1725 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = t.F_b__1991000231; var arg_1729 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2); if linked_1726 == nil { ifn_1727.Invoke_O_O__O(arg_1728, arg_1729) } else { linked_1726.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1725, arg_1728, arg_1729) }; i__1991000230__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000230__1); continue L1 } else { i__1991000230__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000230__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_embed_image_type_forms_fn__1991000246_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000246_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000246_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_A) Invoke_O_O__O(self, p__1991000245__1 any) any { var vec__1991000247__2 any = p__1991000245__1; var alias__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000247__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000247__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1828 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any; var iter__1927001039__auto____5 any; var fnbody__1903 any = A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A_New_O(alias__3); var tmp1 *jrt.Class; var fncls__1902 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A_fn_class; if fncls__1902 == nil { var fncls__1902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__1903); A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A_fn_class = fncls__1902d; tmp1 = fncls__1902d } else { tmp1 = fncls__1902 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1903, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp3 any; var root_1904 any = A_arbace_j2g_embed_A_const_102.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = t.F_re; var arg_1908 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4); if linked_1905 == nil { tmp3 = ifn_1906.Invoke_O_O__O(arg_1907, arg_1908) } else { tmp3 = linked_1905.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_1904, arg_1907, arg_1908) }; arg_1831 = tmp2.Invoke_O__O(tmp3); if linked_1829 == nil { return ifn_1830.Invoke_O__O(arg_1831) } else { return linked_1829.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1828, arg_1831) } }
//line :288:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A) Invoke_O_O__O(self, s__1991000251__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1901 any = A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A_New_O_O_O(t.F_alias, s__1991000251__1, self); var tmp2 *jrt.Class; var fncls__1900 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A_fn_class; if fncls__1900 == nil { var fncls__1900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__1901); A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A_fn_class = fncls__1900d; tmp2 = fncls__1900d } else { tmp2 = fncls__1900 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1901, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :288:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A) Ctor_O_O_O(c__alias, c__s__1991000251, c__iter__1991000250 any) { t.F_alias = c__alias; t.F_s__1991000251 = c__s__1991000251; t.F_iter__1991000250 = c__iter__1991000250 }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A) Invoke_O__O(self any) any { { var s__1991000251__1 any; var t_ any = t.F_s__1991000251; t.F_s__1991000251 = nil; s__1991000251__1 = t_; for { var temp__1927000414__auto____2 any; var root_1832 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = s__1991000251__1; if linked_1833 == nil { temp__1927000414__auto____2 = ifn_1834.Invoke_O__O(arg_1835) } else { temp__1927000414__auto____2 = linked_1833.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1832, arg_1835) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000251__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1836 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = s__1991000251__3; if linked_1837 == nil { tmp1 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp1 = linked_1837.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1836, arg_1839) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1840 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = s__1991000251__3; if linked_1841 == nil { c__1927001037__auto____4 = ifn_1842.Invoke_O__O(arg_1843) } else { c__1927001037__auto____4 = linked_1841.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1840, arg_1843) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000253__6 any; var root_1844 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1845 == nil { b__1991000253__6 = ifn_1846.Invoke_O__O(arg_1847) } else { b__1991000253__6 = linked_1845.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1844, arg_1847) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1859 any = A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, b__1991000253__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1858 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A_fn_class; if fncls__1858 == nil { var fncls__1858d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__1859); A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A_fn_class = fncls__1858d; tmp3 = fncls__1858d } else { tmp3 = fncls__1858 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1859, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1860 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any; var root_1865 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = b__1991000253__6; if linked_1866 == nil { arg_1863 = ifn_1867.Invoke_O__O(arg_1868) } else { arg_1863 = linked_1866.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1865, arg_1868) }; var arg_1864 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000250); var tmp5 any; var root_1869 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = s__1991000251__3; if linked_1870 == nil { tmp5 = ifn_1871.Invoke_O__O(arg_1872) } else { tmp5 = linked_1870.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1869, arg_1872) }; arg_1864 = tmp4.Invoke_O__O(tmp5); if linked_1861 == nil { return ifn_1862.Invoke_O_O__O(arg_1863, arg_1864) } else { return linked_1861.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1860, arg_1863, arg_1864) } } else { var root_1873 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any; var root_1878 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1880 lang.IFn; if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any = b__1991000253__6; if linked_1879 == nil { arg_1876 = ifn_1880.Invoke_O__O(arg_1881) } else { arg_1876 = linked_1879.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1878, arg_1881) }; var arg_1877 any; if linked_1874 == nil { return ifn_1875.Invoke_O_O__O(arg_1876, arg_1877) } else { return linked_1874.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1873, arg_1876, arg_1877) } } } else { var vec__1991000261__4 any; var root_1882 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1884 lang.IFn; if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any = s__1991000251__3; if linked_1883 == nil { vec__1991000261__4 = ifn_1884.Invoke_O__O(arg_1885) } else { vec__1991000261__4 = linked_1883.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1882, arg_1885) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000261__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000261__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1886 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1888 lang.IFn; _ = ___5; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any; var root_1891 any = A_arbace_j2g_embed_A_const_101.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = t.F_alias; var arg_1895 any = n__6; if linked_1892 == nil { arg_1889 = ifn_1893.Invoke_O_O__O(arg_1894, arg_1895) } else { arg_1889 = linked_1892.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1891, arg_1894, arg_1895) }; var arg_1890 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000250); var tmp7 any; var root_1896 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = s__1991000251__3; if linked_1897 == nil { tmp7 = ifn_1898.Invoke_O__O(arg_1899) } else { tmp7 = linked_1897.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1896, arg_1899) }; arg_1890 = tmp6.Invoke_O__O(tmp7); if linked_1887 == nil { return ifn_1888.Invoke_O_O__O(arg_1889, arg_1890) } else { return linked_1887.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1886, arg_1889, arg_1890) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :288:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__b__1991000253, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000253 = c__b__1991000253; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :288:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A) Invoke_O__O(self any) any { { var i__1991000252__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000252__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1991000257__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000252__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000257__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000257__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1848 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1850 lang.IFn; _ = ___3; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = t.F_b__1991000253; var arg_1852 any; var root_1853 any = A_arbace_j2g_embed_A_const_101.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = t.F_alias; var arg_1857 any = n__4; if linked_1854 == nil { arg_1852 = ifn_1855.Invoke_O_O__O(arg_1856, arg_1857) } else { arg_1852 = linked_1854.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1853, arg_1856, arg_1857) }; if linked_1849 == nil { ifn_1850.Invoke_O_O__O(arg_1851, arg_1852) } else { linked_1849.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1848, arg_1851, arg_1852) }; i__1991000252__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000252__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A) Ctor() {}
//line :293:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A) Invoke_O_O__O(self, s__1991000268__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2117 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A_New_O_O(s__1991000268__1, self); var tmp2 *jrt.Class; var fncls__2116 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A_fn_class; if fncls__2116 == nil { var fncls__2116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__2117); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A_fn_class = fncls__2116d; tmp2 = fncls__2116d } else { tmp2 = fncls__2116 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2117, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :293:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A{}; t.Ctor_O_O(p0, p1); return t }
//line :293:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A) Ctor_O_O(c__s__1991000268, c__iter__1991000267 any) { t.F_s__1991000268 = c__s__1991000268; t.F_iter__1991000267 = c__iter__1991000267 }
//line :293:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A) Invoke_O__O(self any) any { { var s__1991000268__1 any; var t_ any = t.F_s__1991000268; t.F_s__1991000268 = nil; s__1991000268__1 = t_; for { var temp__1927000414__auto____2 any; var root_1920 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any = s__1991000268__1; if linked_1921 == nil { temp__1927000414__auto____2 = ifn_1922.Invoke_O__O(arg_1923) } else { temp__1927000414__auto____2 = linked_1921.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1920, arg_1923) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000268__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1924 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = s__1991000268__3; if linked_1925 == nil { tmp1 = ifn_1926.Invoke_O__O(arg_1927) } else { tmp1 = linked_1925.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1924, arg_1927) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1928 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1930 lang.IFn; if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = s__1991000268__3; if linked_1929 == nil { c__1927001037__auto____4 = ifn_1930.Invoke_O__O(arg_1931) } else { c__1927001037__auto____4 = linked_1929.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1928, arg_1931) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000270__6 any; var root_1932 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1933 == nil { b__1991000270__6 = ifn_1934.Invoke_O__O(arg_1935) } else { b__1991000270__6 = linked_1933.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1932, arg_1935) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2011 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A_New_O_I_O(b__1991000270__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2010 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A_fn_class; if fncls__2010 == nil { var fncls__2010d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__2011); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A_fn_class = fncls__2010d; tmp3 = fncls__2010d } else { tmp3 = fncls__2010 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2011, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2012 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any; var root_2017 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = b__1991000270__6; if linked_2018 == nil { arg_2015 = ifn_2019.Invoke_O__O(arg_2020) } else { arg_2015 = linked_2018.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2017, arg_2020) }; var arg_2016 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000267); var tmp5 any; var root_2021 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = s__1991000268__3; if linked_2022 == nil { tmp5 = ifn_2023.Invoke_O__O(arg_2024) } else { tmp5 = linked_2022.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2021, arg_2024) }; arg_2016 = tmp4.Invoke_O__O(tmp5); if linked_2013 == nil { return ifn_2014.Invoke_O_O__O(arg_2015, arg_2016) } else { return linked_2013.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2012, arg_2015, arg_2016) } } else { var root_2025 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any; var root_2030 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2030, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2032 lang.IFn; if linked_2031 == nil { ifn_2032 = lang.IFn_Cast(root_2030) } else { ifn_2032 = nil }; var arg_2033 any = b__1991000270__6; if linked_2031 == nil { arg_2028 = ifn_2032.Invoke_O__O(arg_2033) } else { arg_2028 = linked_2031.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2030, arg_2033) }; var arg_2029 any; if linked_2026 == nil { return ifn_2027.Invoke_O_O__O(arg_2028, arg_2029) } else { return linked_2026.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2025, arg_2028, arg_2029) } } } else { var part__4 any; var root_2034 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_2035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2034, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2036 lang.IFn; if linked_2035 == nil { ifn_2036 = lang.IFn_Cast(root_2034) } else { ifn_2036 = nil }; var arg_2037 any = s__1991000268__3; if linked_2035 == nil { part__4 = ifn_2036.Invoke_O__O(arg_2037) } else { part__4 = linked_2035.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2034, arg_2037) }; var root_2038 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_107; var tmp8 any = A_arbace_j2g_embed_A_const_108; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_A_const_109; var tmp12 any; var root_2043 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2045 lang.IFn


	if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = A_arbace_j2g_embed_A_const_103.GetRawRoot__O(); var arg_2047 any = A_arbace_j2g_embed_A_const_110; var arg_2048 any = A_arbace_j2g_embed_A_const_114; var arg_2049 any; var iter__1927001039__auto____5 any; var fnbody__2111 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A_New(); var tmp13 *jrt.Class; var fncls__2110 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A_fn_class
	if fncls__2110 == nil { var fncls__2110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A_fn_class = fncls__2110d; tmp13 = fncls__2110d } else { tmp13 = fncls__2110 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2111, tmp13, nil); arg_2049 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(part__4)
//line :296:1
	if linked_2044 == nil { tmp12 = ifn_2045.Invoke_O_O_O_O__O(arg_2046, arg_2047, arg_2048, arg_2049) } else { tmp12 = linked_2044.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2043, arg_2046, arg_2047, arg_2048, arg_2049) }
//line :294:1
	arg_2041 = tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :293:1
	var arg_2042 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1991000267); var tmp15 any; var root_2112 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = s__1991000268__3; if linked_2113 == nil { tmp15 = ifn_2114.Invoke_O__O(arg_2115) } else { tmp15 = linked_2113.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2112, arg_2115) }; arg_2042 = tmp14.Invoke_O__O(tmp15); if linked_2039 == nil { return ifn_2040.Invoke_O_O__O(arg_2041, arg_2042) } else { return linked_2039.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2038, arg_2041, arg_2042) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :293:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :293:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A) Ctor_O_I_O(c__b__1991000270 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000270 = c__b__1991000270; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :293:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A) Invoke_O__O(self any) any { { var i__1991000269__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000269__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var part__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000269__1)); var root_1936 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1938 lang.IFn; if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = t.F_b__1991000270; var arg_1940 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_107; var tmp4 any = A_arbace_j2g_embed_A_const_108; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_109; var tmp8 any; var root_1941 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1943 lang.IFn


	if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = A_arbace_j2g_embed_A_const_103.GetRawRoot__O(); var arg_1945 any = A_arbace_j2g_embed_A_const_110; var arg_1946 any = A_arbace_j2g_embed_A_const_111; var arg_1947 any; var iter__1927001039__auto____3 any; var fnbody__2009 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A_New(); var tmp9 *jrt.Class; var fncls__2008 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A_fn_class
	if fncls__2008 == nil { var fncls__2008d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A_fn_class = fncls__2008d; tmp9 = fncls__2008d } else { tmp9 = fncls__2008 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2009, tmp9, nil); arg_1947 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(part__2)
//line :296:1
	if linked_1942 == nil { tmp8 = ifn_1943.Invoke_O_O_O_O__O(arg_1944, arg_1945, arg_1946, arg_1947) } else { tmp8 = linked_1942.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1941, arg_1944, arg_1945, arg_1946, arg_1947) }
//line :294:1
	arg_1940 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :293:1
	if linked_1937 == nil { ifn_1938.Invoke_O_O__O(arg_1939, arg_1940) } else { linked_1937.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1936, arg_1939, arg_1940) }; i__1991000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000269__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A) Invoke_O_O__O(self, s__1991000275__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2007 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A_New_O_O(s__1991000275__1, self); var tmp2 *jrt.Class; var fncls__2006 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A_fn_class; if fncls__2006 == nil { var fncls__2006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__2007); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A_fn_class = fncls__2006d; tmp2 = fncls__2006d } else { tmp2 = fncls__2006 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2007, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :297:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A{}; t.Ctor_O_O(p0, p1); return t }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A) Ctor_O_O(c__s__1991000275, c__iter__1991000274 any) { t.F_s__1991000275 = c__s__1991000275; t.F_iter__1991000274 = c__iter__1991000274 }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A) Invoke_O__O(self any) any { { var s__1991000275__1 any; var t_ any = t.F_s__1991000275; t.F_s__1991000275 = nil; s__1991000275__1 = t_; for { var temp__1927000414__auto____2 any; var root_1948 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = s__1991000275__1; if linked_1949 == nil { temp__1927000414__auto____2 = ifn_1950.Invoke_O__O(arg_1951) } else { temp__1927000414__auto____2 = linked_1949.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1948, arg_1951) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000275__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1952 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = s__1991000275__3; if linked_1953 == nil { tmp1 = ifn_1954.Invoke_O__O(arg_1955) } else { tmp1 = linked_1953.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1952, arg_1955) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1956 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1958 lang.IFn; if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = s__1991000275__3; if linked_1957 == nil { c__1927001037__auto____4 = ifn_1958.Invoke_O__O(arg_1959) } else { c__1927001037__auto____4 = linked_1957.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1956, arg_1959) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000277__6 any; var root_1960 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1961 == nil { b__1991000277__6 = ifn_1962.Invoke_O__O(arg_1963) } else { b__1991000277__6 = linked_1961.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1960, arg_1963) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1970 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000277__6); var tmp3 *jrt.Class; var fncls__1969 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A_fn_class; if fncls__1969 == nil { var fncls__1969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__1970); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A_fn_class = fncls__1969d; tmp3 = fncls__1969d } else { tmp3 = fncls__1969 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1970, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1971 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any; var root_1976 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = b__1991000277__6; if linked_1977 == nil { arg_1974 = ifn_1978.Invoke_O__O(arg_1979) } else { arg_1974 = linked_1977.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1976, arg_1979) }; var arg_1975 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000274); var tmp5 any; var root_1980 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = s__1991000275__3; if linked_1981 == nil { tmp5 = ifn_1982.Invoke_O__O(arg_1983) } else { tmp5 = linked_1981.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1980, arg_1983) }; arg_1975 = tmp4.Invoke_O__O(tmp5); if linked_1972 == nil { return ifn_1973.Invoke_O_O__O(arg_1974, arg_1975) } else { return linked_1972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1971, arg_1974, arg_1975) } } else { var root_1984 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any; var root_1989 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = b__1991000277__6; if linked_1990 == nil { arg_1987 = ifn_1991.Invoke_O__O(arg_1992) } else { arg_1987 = linked_1990.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1989, arg_1992) }; var arg_1988 any; if linked_1985 == nil { return ifn_1986.Invoke_O_O__O(arg_1987, arg_1988) } else { return linked_1985.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1984, arg_1987, arg_1988) } } } else { var t__4 any; var root_1993 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = s__1991000275__3; if linked_1994 == nil { t__4 = ifn_1995.Invoke_O__O(arg_1996) } else { t__4 = linked_1994.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1993, arg_1996) }; var root_1997 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_112; var arg_2000 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_113, t__4)); var arg_2001 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000274); var tmp9 any; var root_2002 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = s__1991000275__3; if linked_2003 == nil { tmp9 = ifn_2004.Invoke_O__O(arg_2005) } else { tmp9 = linked_2003.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2002, arg_2005) }; arg_2001 = tmp8.Invoke_O__O(tmp9); if linked_1998 == nil { return ifn_1999.Invoke_O_O__O(arg_2000, arg_2001) } else { return linked_1998.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1997, arg_2000, arg_2001) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :297:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000277 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000277 = c__b__1991000277 }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A) Invoke_O__O(self any) any { { var i__1991000276__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000276__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000276__1)); var root_1964 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = t.F_b__1991000277; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_112; var arg_1968 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_113, t__2)); if linked_1965 == nil { ifn_1966.Invoke_O_O__O(arg_1967, arg_1968) } else { linked_1965.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1964, arg_1967, arg_1968) }; i__1991000276__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000276__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :297:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A) Invoke_O_O__O(self, s__1991000286__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2109 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A_New_O_O(s__1991000286__1, self); var tmp2 *jrt.Class; var fncls__2108 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A_fn_class; if fncls__2108 == nil { var fncls__2108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__2109); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A_fn_class = fncls__2108d; tmp2 = fncls__2108d } else { tmp2 = fncls__2108 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2109, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :297:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A{}; t.Ctor_O_O(p0, p1); return t }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A) Ctor_O_O(c__s__1991000286, c__iter__1991000285 any) { t.F_s__1991000286 = c__s__1991000286; t.F_iter__1991000285 = c__iter__1991000285 }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A) Invoke_O__O(self any) any { { var s__1991000286__1 any; var t_ any = t.F_s__1991000286; t.F_s__1991000286 = nil; s__1991000286__1 = t_; for { var temp__1927000414__auto____2 any; var root_2050 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = s__1991000286__1; if linked_2051 == nil { temp__1927000414__auto____2 = ifn_2052.Invoke_O__O(arg_2053) } else { temp__1927000414__auto____2 = linked_2051.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2050, arg_2053) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000286__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2054 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = s__1991000286__3; if linked_2055 == nil { tmp1 = ifn_2056.Invoke_O__O(arg_2057) } else { tmp1 = linked_2055.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2054, arg_2057) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2058 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = s__1991000286__3; if linked_2059 == nil { c__1927001037__auto____4 = ifn_2060.Invoke_O__O(arg_2061) } else { c__1927001037__auto____4 = linked_2059.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2058, arg_2061) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000288__6 any; var root_2062 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2063 == nil { b__1991000288__6 = ifn_2064.Invoke_O__O(arg_2065) } else { b__1991000288__6 = linked_2063.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2062, arg_2065) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2072 any = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000288__6); var tmp3 *jrt.Class; var fncls__2071 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A_fn_class; if fncls__2071 == nil { var fncls__2071d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__2072); A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A_fn_class = fncls__2071d; tmp3 = fncls__2071d } else { tmp3 = fncls__2071 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2072, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2073 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2075 lang.IFn; if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any; var root_2078 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = b__1991000288__6; if linked_2079 == nil { arg_2076 = ifn_2080.Invoke_O__O(arg_2081) } else { arg_2076 = linked_2079.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2078, arg_2081) }; var arg_2077 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000285); var tmp5 any; var root_2082 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = s__1991000286__3; if linked_2083 == nil { tmp5 = ifn_2084.Invoke_O__O(arg_2085) } else { tmp5 = linked_2083.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2082, arg_2085) }; arg_2077 = tmp4.Invoke_O__O(tmp5); if linked_2074 == nil { return ifn_2075.Invoke_O_O__O(arg_2076, arg_2077) } else { return linked_2074.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2073, arg_2076, arg_2077) } } else { var root_2086 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var root_2091 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any = b__1991000288__6; if linked_2092 == nil { arg_2089 = ifn_2093.Invoke_O__O(arg_2094) } else { arg_2089 = linked_2092.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2091, arg_2094) }; var arg_2090 any; if linked_2087 == nil { return ifn_2088.Invoke_O_O__O(arg_2089, arg_2090) } else { return linked_2087.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2086, arg_2089, arg_2090) } } } else { var t__4 any; var root_2095 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = s__1991000286__3; if linked_2096 == nil { t__4 = ifn_2097.Invoke_O__O(arg_2098) } else { t__4 = linked_2096.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2095, arg_2098) }; var root_2099 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_112; var arg_2102 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_113, t__4)); var arg_2103 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000285); var tmp9 any; var root_2104 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = s__1991000286__3; if linked_2105 == nil { tmp9 = ifn_2106.Invoke_O__O(arg_2107) } else { tmp9 = linked_2105.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2104, arg_2107) }; arg_2103 = tmp8.Invoke_O__O(tmp9); if linked_2100 == nil { return ifn_2101.Invoke_O_O__O(arg_2102, arg_2103) } else { return linked_2100.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2099, arg_2102, arg_2103) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :297:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000288 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000288 = c__b__1991000288 }
//line :297:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A) Invoke_O__O(self any) any { { var i__1991000287__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000287__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000287__1)); var root_2066 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2068 lang.IFn; if linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var arg_2069 any = t.F_b__1991000288; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_112; var arg_2070 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_113, t__2)); if linked_2067 == nil { ifn_2068.Invoke_O_O__O(arg_2069, arg_2070) } else { linked_2067.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2066, arg_2069, arg_2070) }; i__1991000287__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000287__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
















































































































































































































































type A_arbace_j2g_embed_A struct{ jrt.Object }

var A_arbace_j2g_embed_A_const_pool *jrt.RefArray

var A_arbace_j2g_embed_A_const_0 *lang.Var

var A_arbace_j2g_embed_A_const_1 any

var A_arbace_j2g_embed_A_const_2 *lang.Var

var A_arbace_j2g_embed_A_const_3 any

var A_arbace_j2g_embed_A_const_4 any

var A_arbace_j2g_embed_A_const_5 any

var A_arbace_j2g_embed_A_const_6 any

var A_arbace_j2g_embed_A_const_7 *lang.Var

var A_arbace_j2g_embed_A_const_8 *lang.Var

var A_arbace_j2g_embed_A_const_9 *lang.Var

var A_arbace_j2g_embed_A_const_10 *lang.Var

var A_arbace_j2g_embed_A_const_11 any

var A_arbace_j2g_embed_A_const_12 *lang.Var

var A_arbace_j2g_embed_A_const_13 *lang.Var

var A_arbace_j2g_embed_A_const_14 *lang.Var

var A_arbace_j2g_embed_A_const_15 *lang.Var

var A_arbace_j2g_embed_A_const_16 *lang.Var

var A_arbace_j2g_embed_A_const_17 *lang.Var

var A_arbace_j2g_embed_A_const_18 *lang.Var

var A_arbace_j2g_embed_A_const_19 *lang.Var

var A_arbace_j2g_embed_A_const_20 *lang.Var

var A_arbace_j2g_embed_A_const_21 *lang.Var

var A_arbace_j2g_embed_A_const_22 *lang.Var

var A_arbace_j2g_embed_A_const_23 *lang.Var

var A_arbace_j2g_embed_A_const_24 *lang.Var

var A_arbace_j2g_embed_A_const_25 *lang.Var

var A_arbace_j2g_embed_A_const_26 *lang.Var

var A_arbace_j2g_embed_A_const_27 *lang.Var

var A_arbace_j2g_embed_A_const_28 *lang.Var

var A_arbace_j2g_embed_A_const_29 *lang.Var

var A_arbace_j2g_embed_A_const_30 *lang.Var

var A_arbace_j2g_embed_A_const_31 *lang.Var

var A_arbace_j2g_embed_A_const_32 *lang.Var

var A_arbace_j2g_embed_A_const_33 *lang.Var

var A_arbace_j2g_embed_A_const_34 any

var A_arbace_j2g_embed_A_const_35 *lang.Var

var A_arbace_j2g_embed_A_const_36 any

var A_arbace_j2g_embed_A_const_37 *lang.Var

var A_arbace_j2g_embed_A_const_38 *lang.Var

var A_arbace_j2g_embed_A_const_39 *lang.Var

var A_arbace_j2g_embed_A_const_40 *lang.Var

var A_arbace_j2g_embed_A_const_41 *lang.Var

var A_arbace_j2g_embed_A_const_42 *lang.Keyword

var A_arbace_j2g_embed_A_const_43 *lang.Var

var A_arbace_j2g_embed_A_const_44 *lang.Var

var A_arbace_j2g_embed_A_const_45 *lang.Var

var A_arbace_j2g_embed_A_const_46 *lang.Var

var A_arbace_j2g_embed_A_const_47 *lang.Var

var A_arbace_j2g_embed_A_const_48 *lang.Var

var A_arbace_j2g_embed_A_const_49 any

var A_arbace_j2g_embed_A_const_50 *lang.Var

var A_arbace_j2g_embed_A_const_51 any

var A_arbace_j2g_embed_A_const_52 *lang.Keyword

var A_arbace_j2g_embed_A_const_53 *lang.Var

var A_arbace_j2g_embed_A_const_54 *lang.Var

var A_arbace_j2g_embed_A_const_55 *lang.Var

var A_arbace_j2g_embed_A_const_56 *lang.Var

var A_arbace_j2g_embed_A_const_57 *lang.Var

var A_arbace_j2g_embed_A_const_58 *lang.Var

var A_arbace_j2g_embed_A_const_59 *lang.Var

var A_arbace_j2g_embed_A_const_60 *lang.Var

var A_arbace_j2g_embed_A_const_61 *lang.Var

var A_arbace_j2g_embed_A_const_62 *lang.Var

var A_arbace_j2g_embed_A_const_63 *lang.Var

var A_arbace_j2g_embed_A_const_64 *lang.Var

var A_arbace_j2g_embed_A_const_65 *lang.Var

var A_arbace_j2g_embed_A_const_66 *lang.Var

var A_arbace_j2g_embed_A_const_67 *lang.Var

var A_arbace_j2g_embed_A_const_68 *lang.Var

var A_arbace_j2g_embed_A_const_69 *lang.Var

var A_arbace_j2g_embed_A_const_70 *lang.Var

var A_arbace_j2g_embed_A_const_71 *lang.Var

var A_arbace_j2g_embed_A_const_72 *lang.Var

var A_arbace_j2g_embed_A_const_73 *lang.Var

var A_arbace_j2g_embed_A_const_74 *lang.Var

var A_arbace_j2g_embed_A_const_75 *lang.Var

var A_arbace_j2g_embed_A_const_76 *lang.Var

var A_arbace_j2g_embed_A_const_77 *lang.Var

var A_arbace_j2g_embed_A_const_78 any

var A_arbace_j2g_embed_A_const_79 any

var A_arbace_j2g_embed_A_const_80 *lang.Var

var A_arbace_j2g_embed_A_const_81 *lang.Keyword

var A_arbace_j2g_embed_A_const_82 *lang.Var

var A_arbace_j2g_embed_A_const_83 *lang.Var

var A_arbace_j2g_embed_A_const_84 *lang.Var

var A_arbace_j2g_embed_A_const_85 *lang.Var

var A_arbace_j2g_embed_A_const_86 *lang.Var

var A_arbace_j2g_embed_A_const_87 *lang.Var

var A_arbace_j2g_embed_A_const_88 *lang.Var

var A_arbace_j2g_embed_A_const_89 *lang.Var

var A_arbace_j2g_embed_A_const_90 *lang.Var

var A_arbace_j2g_embed_A_const_91 *lang.Var

var A_arbace_j2g_embed_A_const_92 *lang.Var

var A_arbace_j2g_embed_A_const_93 *lang.Var

var A_arbace_j2g_embed_A_const_94 any

var A_arbace_j2g_embed_A_const_95 *lang.Var

var A_arbace_j2g_embed_A_const_96 *lang.Keyword

var A_arbace_j2g_embed_A_const_97 any

var A_arbace_j2g_embed_A_const_98 any

var A_arbace_j2g_embed_A_const_99 *lang.Var

var A_arbace_j2g_embed_A_const_100 any

var A_arbace_j2g_embed_A_const_101 *lang.Var

var A_arbace_j2g_embed_A_const_102 *lang.Var

var A_arbace_j2g_embed_A_const_103 *lang.Var

var A_arbace_j2g_embed_A_const_104 any

var A_arbace_j2g_embed_A_const_105 *lang.Keyword

var A_arbace_j2g_embed_A_const_106 any

var A_arbace_j2g_embed_A_const_107 any

var A_arbace_j2g_embed_A_const_108 any

var A_arbace_j2g_embed_A_const_109 any

var A_arbace_j2g_embed_A_const_110 any

var A_arbace_j2g_embed_A_const_111 any

var A_arbace_j2g_embed_A_const_112 any

var A_arbace_j2g_embed_A_const_113 any

var A_arbace_j2g_embed_A_const_114 any

var A_arbace_j2g_embed_A_const_115 *lang.Var

var A_arbace_j2g_embed_A_const_116 any

var A_arbace_j2g_embed_A_const_117 any

var A_arbace_j2g_embed_A_init jrt.ClassInit

func A_arbace_j2g_embed_A_Init() { if !A_arbace_j2g_embed_A_init.Done() { A_arbace_j2g_embed_A_init.Run(A_arbace_j2g_embed_A_clinit) } }

func A_arbace_j2g_embed_A_clinit() { A_arbace_j2g_embed_A_clinit_p0(); A_arbace_j2g_embed_A_clinit_p1(); A_arbace_j2g_embed_A_clinit_p2(); A_arbace_j2g_embed_A_clinit_p3(); A_arbace_j2g_embed_A_clinit_p4(); A_arbace_j2g_embed_A_clinit_p5(); A_arbace_j2g_embed_A_clinit_p6(); A_arbace_j2g_embed_A_clinit_p7(); A_arbace_j2g_embed_A_clinit_p8(); A_arbace_j2g_embed_A_clinit_p9() }

func A_arbace_j2g_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 151); A_arbace_j2g_embed_A_const_0 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[33]); A_arbace_j2g_embed_A_const_1 = A_arbace_j2g_embed_A_const_pool.A[34]; A_arbace_j2g_embed_A_const_2 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[35]); A_arbace_j2g_embed_A_const_3 = A_arbace_j2g_embed_A_const_pool.A[36]; A_arbace_j2g_embed_A_const_4 = A_arbace_j2g_embed_A_const_pool.A[37]; A_arbace_j2g_embed_A_const_5 = A_arbace_j2g_embed_A_const_pool.A[38]; A_arbace_j2g_embed_A_const_6 = A_arbace_j2g_embed_A_const_pool.A[39]; A_arbace_j2g_embed_A_const_7 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[40]); A_arbace_j2g_embed_A_const_8 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[41]); A_arbace_j2g_embed_A_const_9 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[42]); A_arbace_j2g_embed_A_const_10 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[43]); A_arbace_j2g_embed_A_const_11 = A_arbace_j2g_embed_A_const_pool.A[44] }

func A_arbace_j2g_embed_A_clinit_p1() { A_arbace_j2g_embed_A_const_12 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[45]); A_arbace_j2g_embed_A_const_13 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[46]); A_arbace_j2g_embed_A_const_14 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[47]); A_arbace_j2g_embed_A_const_15 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[48]); A_arbace_j2g_embed_A_const_16 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[49]); A_arbace_j2g_embed_A_const_17 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[50]); A_arbace_j2g_embed_A_const_18 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[51]); A_arbace_j2g_embed_A_const_19 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[52]); A_arbace_j2g_embed_A_const_20 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[53]); A_arbace_j2g_embed_A_const_21 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[54]); A_arbace_j2g_embed_A_const_22 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[55]); A_arbace_j2g_embed_A_const_23 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[56]) }

func A_arbace_j2g_embed_A_clinit_p2() { A_arbace_j2g_embed_A_const_24 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[57]); A_arbace_j2g_embed_A_const_25 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[58]); A_arbace_j2g_embed_A_const_26 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[59]); A_arbace_j2g_embed_A_const_27 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[60]); A_arbace_j2g_embed_A_const_28 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[61]); A_arbace_j2g_embed_A_const_29 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[62]); A_arbace_j2g_embed_A_const_30 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[63]); A_arbace_j2g_embed_A_const_31 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[64]); A_arbace_j2g_embed_A_const_32 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[65]); A_arbace_j2g_embed_A_const_33 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[66]); A_arbace_j2g_embed_A_const_34 = A_arbace_j2g_embed_A_const_pool.A[67]; A_arbace_j2g_embed_A_const_35 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[68]) }

func A_arbace_j2g_embed_A_clinit_p3() { A_arbace_j2g_embed_A_const_36 = A_arbace_j2g_embed_A_const_pool.A[69]; A_arbace_j2g_embed_A_const_37 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[70]); A_arbace_j2g_embed_A_const_38 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[71]); A_arbace_j2g_embed_A_const_39 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[72]); A_arbace_j2g_embed_A_const_40 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[73]); A_arbace_j2g_embed_A_const_41 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[74]); A_arbace_j2g_embed_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[75]); A_arbace_j2g_embed_A_const_43 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[76]); A_arbace_j2g_embed_A_const_44 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[77]); A_arbace_j2g_embed_A_const_45 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[78]); A_arbace_j2g_embed_A_const_46 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[79]); A_arbace_j2g_embed_A_const_47 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[80]) }

func A_arbace_j2g_embed_A_clinit_p4() { A_arbace_j2g_embed_A_const_48 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[81]); A_arbace_j2g_embed_A_const_49 = A_arbace_j2g_embed_A_const_pool.A[82]; A_arbace_j2g_embed_A_const_50 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[83]); A_arbace_j2g_embed_A_const_51 = A_arbace_j2g_embed_A_const_pool.A[84]; A_arbace_j2g_embed_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[85]); A_arbace_j2g_embed_A_const_53 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[86]); A_arbace_j2g_embed_A_const_54 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[87]); A_arbace_j2g_embed_A_const_55 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[88]); A_arbace_j2g_embed_A_const_56 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[89]); A_arbace_j2g_embed_A_const_57 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[90]); A_arbace_j2g_embed_A_const_58 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[91]); A_arbace_j2g_embed_A_const_59 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[92]) }

func A_arbace_j2g_embed_A_clinit_p5() { A_arbace_j2g_embed_A_const_60 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[93]); A_arbace_j2g_embed_A_const_61 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[94]); A_arbace_j2g_embed_A_const_62 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[95]); A_arbace_j2g_embed_A_const_63 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[96]); A_arbace_j2g_embed_A_const_64 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[97]); A_arbace_j2g_embed_A_const_65 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[98]); A_arbace_j2g_embed_A_const_66 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[99]); A_arbace_j2g_embed_A_const_67 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[100]); A_arbace_j2g_embed_A_const_68 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[101]); A_arbace_j2g_embed_A_const_69 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[102]); A_arbace_j2g_embed_A_const_70 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[103]); A_arbace_j2g_embed_A_const_71 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[104]) }

func A_arbace_j2g_embed_A_clinit_p6() { A_arbace_j2g_embed_A_const_72 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[105]); A_arbace_j2g_embed_A_const_73 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[106]); A_arbace_j2g_embed_A_const_74 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[107]); A_arbace_j2g_embed_A_const_75 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[108]); A_arbace_j2g_embed_A_const_76 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[109]); A_arbace_j2g_embed_A_const_77 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[110]); A_arbace_j2g_embed_A_const_78 = A_arbace_j2g_embed_A_const_pool.A[111]; A_arbace_j2g_embed_A_const_79 = A_arbace_j2g_embed_A_const_pool.A[112]; A_arbace_j2g_embed_A_const_80 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[113]); A_arbace_j2g_embed_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[114]); A_arbace_j2g_embed_A_const_82 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[115]); A_arbace_j2g_embed_A_const_83 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[116]) }

func A_arbace_j2g_embed_A_clinit_p7() { A_arbace_j2g_embed_A_const_84 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[117]); A_arbace_j2g_embed_A_const_85 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[118]); A_arbace_j2g_embed_A_const_86 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[119]); A_arbace_j2g_embed_A_const_87 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[120]); A_arbace_j2g_embed_A_const_88 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[121]); A_arbace_j2g_embed_A_const_89 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[122]); A_arbace_j2g_embed_A_const_90 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[123]); A_arbace_j2g_embed_A_const_91 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[124]); A_arbace_j2g_embed_A_const_92 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[125]); A_arbace_j2g_embed_A_const_93 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[126]); A_arbace_j2g_embed_A_const_94 = A_arbace_j2g_embed_A_const_pool.A[127]; A_arbace_j2g_embed_A_const_95 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[128]) }

func A_arbace_j2g_embed_A_clinit_p8() { A_arbace_j2g_embed_A_const_96 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[129]); A_arbace_j2g_embed_A_const_97 = A_arbace_j2g_embed_A_const_pool.A[130]; A_arbace_j2g_embed_A_const_98 = A_arbace_j2g_embed_A_const_pool.A[131]; A_arbace_j2g_embed_A_const_99 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[132]); A_arbace_j2g_embed_A_const_100 = A_arbace_j2g_embed_A_const_pool.A[133]; A_arbace_j2g_embed_A_const_101 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[134]); A_arbace_j2g_embed_A_const_102 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[135]); A_arbace_j2g_embed_A_const_103 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[136]); A_arbace_j2g_embed_A_const_104 = A_arbace_j2g_embed_A_const_pool.A[137]; A_arbace_j2g_embed_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[138]); A_arbace_j2g_embed_A_const_106 = A_arbace_j2g_embed_A_const_pool.A[139]; A_arbace_j2g_embed_A_const_107 = A_arbace_j2g_embed_A_const_pool.A[140]; A_arbace_j2g_embed_A_const_108 = A_arbace_j2g_embed_A_const_pool.A[141]; A_arbace_j2g_embed_A_const_109 = A_arbace_j2g_embed_A_const_pool.A[142] }

func A_arbace_j2g_embed_A_clinit_p9() { A_arbace_j2g_embed_A_const_110 = A_arbace_j2g_embed_A_const_pool.A[143]; A_arbace_j2g_embed_A_const_111 = A_arbace_j2g_embed_A_const_pool.A[144]; A_arbace_j2g_embed_A_const_112 = A_arbace_j2g_embed_A_const_pool.A[145]; A_arbace_j2g_embed_A_const_113 = A_arbace_j2g_embed_A_const_pool.A[146]; A_arbace_j2g_embed_A_const_114 = A_arbace_j2g_embed_A_const_pool.A[147]; A_arbace_j2g_embed_A_const_115 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[148]); A_arbace_j2g_embed_A_const_116 = A_arbace_j2g_embed_A_const_pool.A[149]; A_arbace_j2g_embed_A_const_117 = A_arbace_j2g_embed_A_const_pool.A[150] }

func A_arbace_j2g_embed_A_New() *A_arbace_j2g_embed_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_A) Ctor() {}

func (t *A_arbace_j2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_A_class }

func (t *A_arbace_j2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_A); return ok }

func A_arbace_j2g_embed_A_Cast(x any) *A_arbace_j2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_A_class)) }; return v }



type A_arbace_j2g_embed_class_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_class_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_fn__1991000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A struct{ j2g_header uint64; F_s__1991000098, F_iter__1991000097 any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1991000100, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_data_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A struct{ j2g_header uint64; F_s__1991000162, F_base, F_iter__1991000161 any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A struct{ j2g_header uint64; F_base, F_b__1991000164 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000004_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000004_A_New() *A_arbace_j2g_embed_eval1991000004_A { t := &A_arbace_j2g_embed_eval1991000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000004_A_class }

func (t *A_arbace_j2g_embed_eval1991000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); return ok }

func A_arbace_j2g_embed_eval1991000004_A_Cast(x any) *A_arbace_j2g_embed_eval1991000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000004_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000008_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000008_A_New() *A_arbace_j2g_embed_eval1991000008_A { t := &A_arbace_j2g_embed_eval1991000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000008_A_class }

func (t *A_arbace_j2g_embed_eval1991000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); return ok }

func A_arbace_j2g_embed_eval1991000008_A_Cast(x any) *A_arbace_j2g_embed_eval1991000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000008_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000008_fn__1991000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000246_A struct{ j2g_header uint64; F_re any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000246_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A struct{ j2g_header uint64; F_alias, F_s__1991000251, F_iter__1991000250 any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_b__1991000253, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000246_iter__1991000250__1991000254_fn__1991000255_fn__1991000256_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A struct{ j2g_header uint64; F_prog_dir any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A struct{ j2g_header uint64; F_prog_dir, F_s__1991000227, F_iter__1991000226 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A struct{ j2g_header uint64; F_iter__1991000228, F_alias, F_s__1991000229 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_b__1991000231, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000226__1991000232_fn__1991000233_iter__1991000228__1991000237_fn__1991000238_fn__1991000239_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A struct{ j2g_header uint64; F_s__1991000268, F_iter__1991000267 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A struct{ j2g_header uint64; F_b__1991000270 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A struct{ j2g_header uint64; F_s__1991000275, F_iter__1991000274 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000277 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_fn__1991000273_iter__1991000274__1991000278_fn__1991000279_fn__1991000280_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A struct{ j2g_header uint64; F_s__1991000286, F_iter__1991000285 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000288 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000267__1991000271_fn__1991000272_iter__1991000285__1991000289_fn__1991000290_fn__1991000291_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_names_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_walk__1991000068_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_embed_names_walk__1991000068_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_loaders_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A struct{ j2g_header uint64; F_taken any }

var A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A struct{ j2g_header uint64; F_iter__1991000209, F_taken, F_s__1991000210 any }

var A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A struct{ j2g_header uint64; F_taken, F_base any }

var A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A struct{ j2g_header uint64; F_taken, F_base, F_s__1991000212, F_iter__1991000211 any }

var A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A struct{ j2g_header uint64; F_b__1991000214, F_taken, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_package_loaders_iter__1991000209__1991000215_fn__1991000216_iter__1991000211__1991000217_fn__1991000218_fn__1991000219_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_fn__1991000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class *jrt.Class



type A_arbace_j2g_embed_reify__1991000061_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_LispReader_Resolver() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_IObj() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_IMeta() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_reify__1991000061_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_reify__1991000061_A_class }

func (t *A_arbace_j2g_embed_reify__1991000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_reify__1991000061_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_reify__1991000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_reify__1991000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_reify__1991000061_A); return ok }

func A_arbace_j2g_embed_reify__1991000061_A_Cast(x any) *A_arbace_j2g_embed_reify__1991000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_reify__1991000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_reify__1991000061_A_class)) }; return v }



type A_arbace_j2g_embed_sources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A struct{ j2g_header uint64; F_p, F_pairs, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A struct{ j2g_header uint64; F_p, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A struct{ j2g_header uint64; F_also, F_base any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A struct{ j2g_header uint64; F_also, F_base, F_s__1991000019, F_iter__1991000018 any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A struct{ j2g_header uint64; F_also, F_base, F_b__1991000021 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A struct{ j2g_header uint64; F_vdir any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A struct{ j2g_header uint64; F_vdir, F_s__1991000037, F_iter__1991000036 any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A struct{ j2g_header uint64; F_b__1991000039, F_vdir any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_user_resources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_fn__1991000200_A struct{ j2g_header uint64; F_taken, F_spec any }

var A_arbace_j2g_embed_user_resources_fn__1991000200_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A struct{ j2g_header uint64; F_base, F_prefix any }

var A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A struct{ j2g_header uint64; F_s__1991000189, F_base, F_prefix, F_iter__1991000188 any }

var A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_A_fn_class *jrt.Class



type A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A struct{ j2g_header uint64; F_b__1991000191, F_base, F_prefix any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_user_resources_iter__1991000188__1991000192_fn__1991000193_fn__1991000194_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_elem__1991000126_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types, F_s__1991000143, F_iter__1991000142 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A struct{ j2g_header uint64; F_n, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A struct{ j2g_header uint64; F_in_world_QMARK_ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A struct{ j2g_header uint64; F_in_world_QMARK_, F_s__1991000145, F_iter__1991000144 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A struct{ j2g_header uint64; F_b__1991000147, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_A struct{ j2g_header uint64; F_elem, F_types any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A struct{ j2g_header uint64; F_s__1991000132, F_iter__1991000131 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000134 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class *jrt.Class
