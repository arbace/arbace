//line aot_arbace_j2g_embed.ae:1
package aot_arbace_j2g_embed

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_edge"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_New() *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed_A_const_1); lang.IFn_Cast(A_arbace_j2g_embed_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_3, A_arbace_j2g_embed_A_const_4, A_arbace_j2g_embed_A_const_5, A_arbace_j2g_embed_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_New() *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000008_fn__1991000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_embed_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_embed_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_embed_A_const_10.GetRawRoot__O(), A_arbace_j2g_embed_A_const_11) }
















































func A_arbace_j2g_embed_sources_A_New() *A_arbace_j2g_embed_sources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_j2g_embed_sources_A) Ctor() {}
//line :50:1
func (t *A_arbace_j2g_embed_sources_A) DoInvoke_O_O_O__O(self, root__0, p__1991000014__1 any) any { var vec__1991000015__3 any = p__1991000014__1; var also__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var base__5 any; var root_22 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_22, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_24 lang.IFn; if




	linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = root__0; var arg_26 any = Lit_40; if linked_23 == nil { base__5 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { base__5 = linked_23.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; var files__6 any; var iter__1927001039__auto____6 any; var tmp1 any = /*line :50:1*/A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_New_O_O(also__4, base__5); var tmp2 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class; if





	fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class = fncls__163d; tmp2 = fncls__163d } else { tmp2 = fncls__163 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp4 any; var root_381 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = base__5; if linked_382 == nil { tmp4 = ifn_383.Invoke_O__O(arg_384) } else { tmp4 = linked_382.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_381, arg_384) }; files__6 = tmp3.Invoke_O__O(tmp4); var vdir__7 any; var root_164 any = /*line :50:1*/A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_164, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_166 lang.IFn; if











	linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = root__0; var arg_168 any = A_arbace_j2g_embed_A_const_31.GetRawRoot__O(); if linked_165 == nil { vdir__7 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { vdir__7 = linked_165.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }; var variants__8 any; if
	jrt.NN(jrt.File_Cast(vdir__7)).IsDirectory__Z() { var iter__1927001039__auto____8 any; var tmp5 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_New_O(vdir__7); var tmp6 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class
		if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class = fncls__257d; tmp6 = fncls__257d } else { tmp6 = fncls__257 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp8 any; var root_385 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = vdir__7; if linked_386 == nil { tmp8 = ifn_387.Invoke_O__O(arg_388) } else { tmp8 = linked_386.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_385, arg_388) }; variants__8 = tmp7.Invoke_O__O(tmp8) } else {
//line :63:1
			variants__8 = nil }; var root_258 any =



	A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any; var tmp9 any = A_arbace_j2g_embed_sources_fn__1991000047_A_New(); var tmp10 *jrt.Class; var fncls__367 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class; if fncls__367 == nil { var fncls__367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class = fncls__367d; tmp10 = fncls__367d } else { tmp10 = fncls__367 }; arg_261 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_262 any; var root_368 any = A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_370 lang.IFn; if





















	linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_372 any = files__6; if linked_369 == nil { arg_262 = ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { arg_262 = linked_369.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_368, arg_371, arg_372) }; var arg_263 any; var root_376 any = /*line :67:1*/A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_378 lang.IFn; if






















	linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var arg_380 any = variants__8; if linked_377 == nil { arg_263 = ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { arg_263 = linked_377.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) }; if /*line :67:1*/ linked_259 == nil { return ifn_260.Invoke_O_O_O__O(arg_261, arg_262, arg_263) } else { return linked_259.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_258, arg_261, arg_262, arg_263) } }
//line :56:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A) Ctor_O_O(c__also, c__base any) { t.F_also = c__also; t.F_base = c__base }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A) Invoke_O_O__O(self, s__1991000019__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_New_O_O_O_O(t.F_also, t.F_base, s__1991000019__1, self); var tmp2 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class = fncls__162d; tmp2 = fncls__162d } else { tmp2 = fncls__162 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :56:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A) Ctor_O_O_O_O(c__also, c__base, c__s__1991000019, c__iter__1991000018 any) { t.F_also = c__also; t.F_base = c__base; t.F_s__1991000019 = c__s__1991000019; t.F_iter__1991000018 = c__iter__1991000018 }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A) Invoke_O__O(self any) any { { var s__1991000019__1 any; var t_ any = t.F_s__1991000019; t.F_s__1991000019 = nil; s__1991000019__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_27 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = s__1991000019__1; if linked_28 == nil { temp__1927000414__auto____2 = ifn_29.Invoke_O__O(arg_30) } else { temp__1927000414__auto____2 = linked_28.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_27, arg_30) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000019__3 any = temp__1927000414__auto____2; var tmp1 any; var root_31 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__1991000019__3; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_35 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__1991000019__3; if linked_36 == nil { c__1927001037__auto____4 = ifn_37.Invoke_O__O(arg_38) } else { c__1927001037__auto____4 = linked_36.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_35, arg_38) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000021__6 any; var root_39 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_40 == nil { b__1991000021__6 = ifn_41.Invoke_O__O(arg_42) } else { b__1991000021__6 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_39, arg_42) }; var tmp2 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_New_O_O_O_I_O(t.F_also, t.F_base, b__1991000021__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_84 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var root_89 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = b__1991000021__6; if linked_90 == nil { arg_87 = ifn_91.Invoke_O__O(arg_92) } else { arg_87 = linked_90.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_89, arg_92) }; var arg_88 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000018); var tmp5 any; var root_93 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = s__1991000019__3; if linked_94 == nil { tmp5 = ifn_95.Invoke_O__O(arg_96) } else { tmp5 = linked_94.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_93, arg_96) }; arg_88 = tmp4.Invoke_O__O(tmp5); if linked_85 == nil { return ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { return linked_85.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) } } else { var root_97 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var root_102 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = b__1991000021__6; if linked_103 == nil { arg_100 = ifn_104.Invoke_O__O(arg_105) } else { arg_100 = linked_103.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_102, arg_105) }; var arg_101 any; if linked_98 == nil { return ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { return linked_98.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) } } } else { var f__4 any; var root_106 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = s__1991000019__3; if linked_107 == nil { f__4 = ifn_108.Invoke_O__O(arg_109) } else { f__4 = linked_107.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_106, arg_109) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var root_110 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_114 any = Lit_28; if linked_111 == nil { tmp6 = ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { tmp6 = linked_111.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_110, arg_113, arg_114) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :56:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp8 any; var root_115 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_117 lang.IFn

		if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_116 == nil { tmp8 = ifn_117.Invoke_O__O(arg_118) } else { tmp8 = linked_116.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_115, arg_118) }; rel__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :56:1
		var tmp9 any; var or__1927000174__auto____6 any; var root_119 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_121 lang.IFn


		if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var tmp10 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_New_O(rel__5); var tmp11 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class = fncls__129d; tmp11 = fncls__129d } else { tmp11 = fncls__129 }; arg_122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_123 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_120 == nil { or__1927000174__auto____6 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { or__1927000174__auto____6 = linked_120.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else {
			var root_130 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var tmp12 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_New_O(rel__5); var tmp13 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class = fncls__140d; tmp13 = fncls__140d } else { tmp13 = fncls__140 }; arg_133 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_134 any = t.F_also; if linked_131 == nil { tmp9 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { tmp9 = linked_131.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) } }
//line :56:1
		if jrt.J2g_Truth(tmp9) { var root_141 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_145 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1991000018); var tmp15 any; var root_150 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = s__1991000019__3; if linked_151 == nil { tmp15 = ifn_152.Invoke_O__O(arg_153) } else { tmp15 = linked_151.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_150, arg_153) }; arg_145 = tmp14.Invoke_O__O(tmp15); if linked_142 == nil { return ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { return linked_142.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) } } else { var tmp16 any; var root_154 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__1991000019__3; if linked_155 == nil { tmp16 = ifn_156.Invoke_O__O(arg_157) } else { tmp16 = linked_155.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_154, arg_157) }; s__1991000019__1 = tmp16; continue L1 } } else { var tmp17 any; var root_158 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = s__1991000019__3; if linked_159 == nil { tmp17 = ifn_160.Invoke_O__O(arg_161) } else { tmp17 = linked_159.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_158, arg_161) }; s__1991000019__1 = tmp17; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :56:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A) Ctor_O_O_O_I_O(c__also, c__base, c__b__1991000021 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_also = c__also; t.F_base = c__base; t.F_b__1991000021 = c__b__1991000021; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :56:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A) Invoke_O__O(self any) any { { var i__1991000020__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000020__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000020__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var root_43 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_47 any = Lit_28; if linked_44 == nil { tmp2 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp2 = linked_44.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_43, arg_46, arg_47) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :56:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp4 any; var root_48 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_50 lang.IFn

		if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_49 == nil { tmp4 = ifn_50.Invoke_O__O(arg_51) } else { tmp4 = linked_49.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_48, arg_51) }; rel__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :56:1
		var tmp5 any; var or__1927000174__auto____4 any; var root_52 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_54 lang.IFn


		if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any; var tmp6 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_New_O(rel__3); var tmp7 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class = fncls__62d; tmp7 = fncls__62d } else { tmp7 = fncls__62 }; arg_55 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_56 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_53 == nil { or__1927000174__auto____4 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { or__1927000174__auto____4 = linked_53.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else {
			var root_63 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var tmp8 any = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_New_O(rel__3); var tmp9 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class = fncls__73d; tmp9 = fncls__73d } else { tmp9 = fncls__73 }; arg_66 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_67 any = t.F_also; if linked_64 == nil { tmp5 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { tmp5 = linked_64.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) } }
//line :56:1
		if jrt.J2g_Truth(tmp5) { var root_74 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = t.F_b__1991000021; var arg_78 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_75 == nil { ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { linked_75.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_74, arg_77, arg_78) }; i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } else { i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } } else { i__1991000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000020__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A{}; t.Ctor_O(p0); return t }
//line :59:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :59:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_57 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = t.F_rel; var arg_61 any = p1__1991000012_SHARP___1; if linked_58 == nil { return ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { return linked_58.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } }
//line :59:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A{}; t.Ctor_O(p0); return t }
//line :59:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :59:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_124 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = t.F_rel; var arg_128 any = p1__1991000012_SHARP___1; if linked_125 == nil { return ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { return linked_125.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } }
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A) Invoke_O_O__O(self, p1__1991000013_SHARP___1 any) any { var root_68 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = t.F_rel; var arg_72 any = p1__1991000013_SHARP___1; if linked_69 == nil { return ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { return linked_69.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_68, arg_71, arg_72) } }
//line :60:1
func A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :60:1
func (t *A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A) Invoke_O_O__O(self, p1__1991000013_SHARP___1 any) any { var root_135 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = t.F_rel; var arg_139 any = p1__1991000013_SHARP___1; if linked_136 == nil { return ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { return linked_136.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_135, arg_138, arg_139) } }



func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A{}; t.Ctor_O(p0); return t }
//line :64:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :64:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A) Invoke_O_O__O(self, s__1991000037__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_New_O_O_O(t.F_vdir, s__1991000037__1, self); var tmp2 *jrt.Class; var fncls__256 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class; if fncls__256 == nil { var fncls__256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class = fncls__256d; tmp2 = fncls__256d } else { tmp2 = fncls__256 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :64:1
func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :64:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A) Ctor_O_O_O(c__vdir, c__s__1991000037, c__iter__1991000036 any) { t.F_vdir = c__vdir; t.F_s__1991000037 = c__s__1991000037; t.F_iter__1991000036 = c__iter__1991000036 }
//line :64:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A) Invoke_O__O(self any) any { { var s__1991000037__1 any; var t_ any = t.F_s__1991000037; t.F_s__1991000037 = nil; s__1991000037__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_169 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__1991000037__1; if linked_170 == nil { temp__1927000414__auto____2 = ifn_171.Invoke_O__O(arg_172) } else { temp__1927000414__auto____2 = linked_170.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000037__3 any = temp__1927000414__auto____2; var tmp1 any; var root_173 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = s__1991000037__3; if linked_174 == nil { tmp1 = ifn_175.Invoke_O__O(arg_176) } else { tmp1 = linked_174.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_177 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = s__1991000037__3; if linked_178 == nil { c__1927001037__auto____4 = ifn_179.Invoke_O__O(arg_180) } else { c__1927001037__auto____4 = linked_178.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_177, arg_180) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000039__6 any; var root_181 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_182 == nil { b__1991000039__6 = ifn_183.Invoke_O__O(arg_184) } else { b__1991000039__6 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_181, arg_184) }; var tmp2 any = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_New_O_O_I_O(b__1991000039__6, t.F_vdir, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class = fncls__203d; tmp3 = fncls__203d } else { tmp3 = fncls__203 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_204 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var root_209 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = b__1991000039__6; if linked_210 == nil { arg_207 = ifn_211.Invoke_O__O(arg_212) } else { arg_207 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_209, arg_212) }; var arg_208 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000036); var tmp5 any; var root_213 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = s__1991000037__3; if linked_214 == nil { tmp5 = ifn_215.Invoke_O__O(arg_216) } else { tmp5 = linked_214.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_213, arg_216) }; arg_208 = tmp4.Invoke_O__O(tmp5); if linked_205 == nil { return ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { return linked_205.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } } else { var root_217 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var root_222 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = b__1991000039__6; if linked_223 == nil { arg_220 = ifn_224.Invoke_O__O(arg_225) } else { arg_220 = linked_223.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_222, arg_225) }; var arg_221 any; if linked_218 == nil { return ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { return linked_218.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) } } } else { var f__4 any; var root_226 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = s__1991000037__3; if linked_227 == nil { f__4 = ifn_228.Invoke_O__O(arg_229) } else { f__4 = linked_227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_226, arg_229) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var root_230 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_234 any = Lit_28; if linked_231 == nil { tmp6 = ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { tmp6 = linked_231.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_230, arg_233, arg_234) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :64:1
	if jrt.J2g_Truth(tmp6) { var root_235 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any; var tmp7 any; var root_240 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_242 lang.IFn

		if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_241 == nil { tmp7 = ifn_242.Invoke_O__O(arg_243) } else { tmp7 = linked_241.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_240, arg_243) }
//line :64:1
		arg_238 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_239 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000036); var tmp9 any; var root_248 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = s__1991000037__3; if linked_249 == nil { tmp9 = ifn_250.Invoke_O__O(arg_251) } else { tmp9 = linked_249.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_248, arg_251) }; arg_239 = tmp8.Invoke_O__O(tmp9); if linked_236 == nil { return ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { return linked_236.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_235, arg_238, arg_239) } } else { var tmp10 any; var root_252 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = s__1991000037__3; if linked_253 == nil { tmp10 = ifn_254.Invoke_O__O(arg_255) } else { tmp10 = linked_253.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_252, arg_255) }; s__1991000037__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :64:1
func A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :64:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A) Ctor_O_O_I_O(c__b__1991000039, c__vdir any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000039 = c__b__1991000039; t.F_vdir = c__vdir; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :64:1
func (t *A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A) Invoke_O__O(self any) any { { var i__1991000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000038__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var root_185 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_189 any = Lit_28; if linked_186 == nil { tmp2 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { tmp2 = linked_186.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_185, arg_188, arg_189) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :64:1
	if jrt.J2g_Truth(tmp2) { var root_190 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = t.F_b__1991000039; var arg_194 any; var tmp3 any; var root_195 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_197 lang.IFn

		if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_196 == nil { tmp3 = ifn_197.Invoke_O__O(arg_198) } else { tmp3 = linked_196.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_195, arg_198) }
//line :64:1
		arg_194 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_191 == nil { ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { linked_191.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; i__1991000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000038__1); continue L1 } else { i__1991000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_fn__1991000047_A_New() *A_arbace_j2g_embed_sources_fn__1991000047_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_A) Ctor() {}
//line :67:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_A) Invoke_O_O_O__O(self, m__1, p__1991000046__2 any) any { var vec__1991000048__3 any = p__1991000046__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000048__3, lang.RT_IntCast_J__I_NoInit(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000048__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_264 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_266 lang.IFn; if


	linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = rel__4; var arg_268 any = Lit_44; if linked_265 == nil { tmp1 = ifn_266.Invoke_O_O__O(arg_267, arg_268) } else { tmp1 = linked_265.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_264, arg_267, arg_268) }; if /*line :68:1*/ jrt.J2g_Truth(tmp1) { var p__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28); var tmp3 any; var root_269 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_271 lang.IFn


		if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = rel__4; var arg_273 any = A_arbace_j2g_embed_A_const_34; var arg_274 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_44)))).Ref(); if linked_270 == nil { tmp3 = ifn_271.Invoke_O_O_O__O(arg_272, arg_273, arg_274) } else { tmp3 = linked_270.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_269, arg_272, arg_273, arg_274) }; p__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
//line :68:1
		var pairs__7 any; var root_275 any = A_arbace_j2g_embed_A_const_35.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_277 lang.IFn



		if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = A_arbace_j2g_embed_A_const_36; var arg_279 any; var root_280 any = A_arbace_j2g_embed_A_const_37.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = text__5; if linked_281 == nil { arg_279 = ifn_282.Invoke_O__O(arg_283) } else { arg_279 = linked_281.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_280, arg_283) }; if linked_276 == nil { pairs__7 = ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { pairs__7 = linked_276.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) }
		var tmp4 any; var root_347 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = m__1; var arg_351 any = p__6; if linked_348 == nil { tmp4 = ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { tmp4 = linked_348.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_347, arg_350, arg_351) }; if jrt.J2g_Truth(tmp4) { } else { var tmp5 any; var root_352 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_354 lang.IFn
			if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(); var arg_356 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_353 == nil { tmp5 = ifn_354.Invoke_O_O__O(arg_355, arg_356) } else { tmp5 = linked_353.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_352, arg_355, arg_356) }
//line :73:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5)))
		}
		var root_284 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = m__1; var arg_288 any = p__6; var arg_289 any; var tmp6 any = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp7 *jrt.Class; var fncls__322 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class; if fncls__322 == nil { var fncls__322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class = fncls__322d; tmp7 = fncls__322d } else { tmp7 = fncls__322 }; arg_289 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_285 == nil { return ifn_286.Invoke_O_O_O__O(arg_287, arg_288, arg_289) } else { return linked_285.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_284, arg_287, arg_288, arg_289) } } else {
//line :68:1
			var tmp8 any; var root_323 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_325 lang.IFn














			if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = rel__4; var arg_327 any = Lit_49; if linked_324 == nil { tmp8 = ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { tmp8 = linked_324.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_323, arg_326, arg_327) }
//line :68:1
			if jrt.J2g_Truth(tmp8) { var p__6_2 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28); var tmp10 any; var root_328 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_330 lang.IFn















				if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = rel__4; var arg_332 any = A_arbace_j2g_embed_A_const_34; var arg_333 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_49)))).Ref(); if linked_329 == nil { tmp10 = ifn_330.Invoke_O_O_O__O(arg_331, arg_332, arg_333) } else { tmp10 = linked_329.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_328, arg_331, arg_332, arg_333) }; p__6_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil)).Ref()
				var tmp11 any; var root_357 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = m__1; var arg_361 any = p__6_2; if linked_358 == nil { tmp11 = ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { tmp11 = linked_358.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_357, arg_360, arg_361) }; if jrt.J2g_Truth(tmp11) { } else { var tmp12 any; var root_362 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_364 lang.IFn
					if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(); var arg_366 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_363 == nil { tmp12 = ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { tmp12 = linked_363.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) }
//line :85:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp12)))
				}
				var root_334 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = m__1; var arg_338 any = p__6_2; var arg_339 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_340 any = text__5; if linked_335 == nil { return ifn_336.Invoke_O_O_O_O__O(arg_337, arg_338, arg_339, arg_340) } else { return linked_335.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_334, arg_337, arg_338, arg_339, arg_340) } } else {
//line :68:1
					if A_arbace_j2g_embed_A_const_42 != nil {



















						var root_341 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = m__1; var arg_345 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(); var arg_346 any = text__5; if linked_342 == nil { return ifn_343.Invoke_O_O_O__O(arg_344, arg_345, arg_346) } else { return linked_342.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_341, arg_344, arg_345, arg_346) } } else {
//line :68:1
							return nil } } } }






func A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :75:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A) Invoke_O_O__O(self, src__1 any) any {
	var root_290 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var tmp1 any = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_New_O_O(t.F_p, t.F_rel); var tmp2 *jrt.Class; var fncls__321 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class; if fncls__321 == nil { var fncls__321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class = fncls__321d; tmp2 = fncls__321d } else { tmp2 = fncls__321 }; arg_293 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_294 any = src__1; var arg_295 any = t.F_pairs; if linked_291 == nil { return ifn_292.Invoke_O_O_O__O(arg_293, arg_294, arg_295) } else { return linked_291.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_290, arg_293, arg_294, arg_295) } }
//line :76:1
func A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :76:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :76:1
func (t *A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A) Invoke_O_O_O__O(self, src__1, p__1991000052__2 any) any { var vec__1991000054__3 any = p__1991000052__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000054__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000054__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var root_307 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); var arg_311 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref(); if linked_308 == nil { tmp1 = ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { tmp1 = linked_308.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_307, arg_310, arg_311) } }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_312 any = A_arbace_j2g_embed_A_const_40.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_314 lang.IFn
		if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var tmp3 any = t.F_rel; var arg_315 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_51, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_41.GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(); var arg_316 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_313 == nil { tmp2 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp2 = linked_313.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }
//line :78:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp4 /*line :81:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp5 any; var root_296 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = src__1; var arg_300 any = A_arbace_j2g_embed_A_const_34; var arg_301 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); if linked_297 == nil { tmp5 = ifn_298.Invoke_O_O_O__O(arg_299, arg_300, arg_301) } else { tmp5 = linked_297.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_296, arg_299, arg_300, arg_301) }; var tmp6 any = tmp5; var tmp7 any; var root_302 any = A_arbace_j2g_embed_A_const_33.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = src__1; var arg_306 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__6), int64(lang.RT_Count_O__I_NoInit(old__4)))).Ref(); if linked_303 == nil { tmp7 = ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { tmp7 = linked_303.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp6, new__5, tmp7)).Ref() }















func A_arbace_j2g_embed_reify__1991000061_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_j2g_embed_reify__1991000061_A { t := &A_arbace_j2g_embed_reify__1991000061_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :97:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :97:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :97:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :97:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :97:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_j2g_embed_A_Init(); tmp1 = A_arbace_j2g_embed_A_const_49; return lang.Symbol_Cast(tmp1) }
//line :97:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :97:1
func (t *A_arbace_j2g_embed_reify__1991000061_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_j2g_embed_reify__1991000061_A_New_IPersistentMap(m) }





func A_arbace_j2g_embed_read_all_A_New() *A_arbace_j2g_embed_read_all_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_embed_read_all_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var root_397 any = A_arbace_j2g_embed_A_const_54.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_399 lang.IFn; if

	linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_55.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_embed_A_const_56; var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any = A_arbace_j2g_embed_A_const_57; var tmp5 any = A_arbace_j2g_embed_A_const_58.GetRawRoot__O(); var tmp6 any = A_arbace_j2g_embed_A_const_59; var tmp7 any = A_arbace_j2g_embed_read_all_fn__1991000063_A_New(); var tmp8 *jrt.Class; var fncls__410 *jrt.Class = A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class; if

	fncls__410 == nil { var fncls__410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class = fncls__410d; tmp8 = fncls__410d } else { tmp8 = fncls__410 }; arg_400 = /*line :105:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); if linked_398 == nil { ifn_399.Invoke_O__O(arg_400) } else { linked_398.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_397, arg_400) }; var tmp9 any; tmp11 := /*line :103:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any; var root_389 any = A_arbace_j2g_embed_A_const_50.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_391 lang.IFn





		if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = A_arbace_j2g_embed_A_const_51; var arg_393 any = r__2; if linked_390 == nil { f__6 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { f__6 = linked_390.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }
		if lang.Util_Equiv_O_O__Z_NoInit(f__6, A_arbace_j2g_embed_A_const_52) { tmp9 = acc__5 } else { var tmp10 any; var root_411 any = A_arbace_j2g_embed_A_const_10.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = acc__5; var arg_415 any = f__6; if linked_412 == nil { tmp10 = ifn_413.Invoke_O_O__O(arg_414, arg_415) } else { tmp10 = linked_412.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_411, arg_414, arg_415) }; acc__5 = tmp10; continue L1 }
//line :103:1
		break L1 } }; return nil }(); var root_394 any = A_arbace_j2g_embed_A_const_53.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_396 lang.IFn; if

	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; if linked_395 == nil { ifn_396.Invoke__O() } else { linked_395.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_394) }; if /*line :103:1*/ tmp11 != nil { panic(tmp11) }; return tmp9 }



func A_arbace_j2g_embed_read_all_fn__1991000063_A_New() *A_arbace_j2g_embed_read_all_fn__1991000063_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_fn__1991000063_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000063_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000063_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_j2g_embed_class_like_QMARK__A_New() *A_arbace_j2g_embed_class_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_1); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)), int64(lang.RT_Count_O__I_NoInit(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_embed_package_like_QMARK__A_New() *A_arbace_j2g_embed_package_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_1))); if and__1927000168__auto____2 {
											var root_416 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var root_420 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = s__0; if linked_421 == nil { arg_419 = ifn_422.Invoke_O__O(arg_423) } else { arg_419 = linked_421.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_420, arg_423) }; if linked_417 == nil { return ifn_418.Invoke_O__O(arg_419) } else { return linked_417.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_416, arg_419) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_embed_names_A_New() *A_arbace_j2g_embed_names_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_j2g_embed_names_A) Ctor() {}
//line :119:1
func (t *A_arbace_j2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any; var root_424 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_426 lang.IFn; if



	linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_425 == nil { acc__2 = ifn_426.Invoke_O__O(arg_427) } else { acc__2 = linked_425.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_424, arg_427) }; var walk__3 any; var tmp1 any = /*line :119:1*/A_arbace_j2g_embed_names_walk__1991000068_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__669 *jrt.Class = A_arbace_j2g_embed_names_walk__1991000068_A_fn_class; if




	fncls__669 == nil { var fncls__669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_embed_names_walk__1991000068_A_fn_class = fncls__669d; tmp2 = fncls__669d } else { tmp2 = fncls__669 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var seq_1991000092__4 any; var root_674 any = /*line :119:1*/A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_676 lang.IFn; if




















	linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any; var root_678 any = A_arbace_j2g_embed_A_const_75.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_j2g_embed_read_all_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = text__0; if linked_679 == nil { arg_677 = ifn_680.Invoke_O__O(arg_681) } else { arg_677 = linked_679.(*A_arbace_j2g_embed_read_all_A).Invoke_O_O__O(root_678, arg_681) }; if linked_675 == nil { seq_1991000092__4 = ifn_676.Invoke_O__O(arg_677) } else { seq_1991000092__4 = linked_675.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_674, arg_677) }; var chunk_1991000093__5 any; var count_1991000094__6 int64 = 0; var i_1991000095__7 int64 = 0; L1:
//line :119:1
	for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000095__7, count_1991000094__6) { var f__8 any = lang.Indexed_Cast(chunk_1991000093__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000095__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000095__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_682 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = seq_1991000092__4; if linked_683 == nil { temp__1927000414__auto____8 = ifn_684.Invoke_O__O(arg_685) } else { temp__1927000414__auto____8 = linked_683.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1991000092__9 any = temp__1927000414__auto____8; var tmp3 any; var root_686 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = seq_1991000092__9; if linked_687 == nil { tmp3 = ifn_688.Invoke_O__O(arg_689) } else { tmp3 = linked_687.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_686, arg_689) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_690 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = seq_1991000092__9; if linked_691 == nil { c__1927000678__auto____10 = ifn_692.Invoke_O__O(arg_693) } else { c__1927000678__auto____10 = linked_691.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_690, arg_693) }; var tmp4 any; var root_698 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = seq_1991000092__9; if linked_699 == nil { tmp4 = ifn_700.Invoke_O__O(arg_701) } else { tmp4 = linked_699.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_698, arg_701) }; seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_694 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = seq_1991000092__9; if linked_695 == nil { f__10 = ifn_696.Invoke_O__O(arg_697) } else { f__10 = linked_695.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_694, arg_697) }; lang.IFn_Cast(walk__3).Invoke_O__O(f__10); var tmp5 any; var root_702 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = seq_1991000092__9; if linked_703 == nil { tmp5 = ifn_704.Invoke_O__O(arg_705) } else { tmp5 = linked_703.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_702, arg_705) }; seq_1991000092__4, chunk_1991000093__5, count_1991000094__6, i_1991000095__7 = tmp5, nil, 0, 0; continue L1 } } }
//line :119:1
		break L1 }; var root_670 any =





















	A_arbace_j2g_embed_A_const_74.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = acc__2; if linked_671 == nil { return ifn_672.Invoke_O__O(arg_673) } else { return linked_671.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_670, arg_673) } }
//line :124:1
func A_arbace_j2g_embed_names_walk__1991000068_A_New_O(p0 any) *A_arbace_j2g_embed_names_walk__1991000068_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_walk__1991000068_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_j2g_embed_names_walk__1991000068_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :124:1
func (t *A_arbace_j2g_embed_names_walk__1991000068_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__1)
											if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											var tmp1 any; var root_428 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_430 lang.IFn
											if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = x__1; if linked_429 == nil { tmp1 = ifn_430.Invoke_O__O(arg_431) } else { tmp1 = linked_429.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_428, arg_431) }
//line :126:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any; var root_529 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = x__1; if linked_530 == nil { tmp3 = ifn_531.Invoke_O__O(arg_532) } else { tmp3 = linked_530.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_529, arg_532) }; and__1927000168__auto____2 = lang.Util_Identical_O_O__Z_NoInit(tmp3, nil); if and__1927000168__auto____2 { var root_533 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any; var root_537 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = x__1; if linked_538 == nil { arg_536 = ifn_539.Invoke_O__O(arg_540) } else { arg_536 = linked_538.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_537, arg_540) }; if linked_534 == nil { tmp2 = ifn_535.Invoke_O__O(arg_536) } else { tmp2 = linked_534.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_533, arg_536) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) {
			var root_541 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = t.F_acc; var arg_545 any; var root_546 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = x__1; if linked_547 == nil { arg_545 = ifn_548.Invoke_O__O(arg_549) } else { arg_545 = linked_547.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_546, arg_549) }; if linked_542 == nil { ifn_543.Invoke_O_O__O(arg_544, arg_545) } else { linked_542.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_541, arg_544, arg_545) } }
		var tmp4 any; var and__1927000168__auto____2_2 any; var root_432 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = x__1; if linked_433 == nil { and__1927000168__auto____2_2 = ifn_434.Invoke_O__O(arg_435) } else { and__1927000168__auto____2_2 = linked_433.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_432, arg_435) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var root_436 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var root_440 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = x__1; if linked_441 == nil { arg_439 = ifn_442.Invoke_O__O(arg_443) } else { arg_439 = linked_441.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_440, arg_443) }; if linked_437 == nil { tmp4 = ifn_438.Invoke_O__O(arg_439) } else { tmp4 = linked_437.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_436, arg_439) } } else { tmp4 = and__1927000168__auto____2_2 }; if jrt.J2g_Truth(tmp4) {
			var root_444 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = t.F_acc; var arg_448 any; var root_449 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = x__1; if linked_450 == nil { arg_448 = ifn_451.Invoke_O__O(arg_452) } else { arg_448 = linked_450.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_449, arg_452) }; if linked_445 == nil { return ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { return linked_445.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_444, arg_447, arg_448) } } else {
//line :130:1
				return nil } } else {
//line :126:1
					var tmp5 any; var or__1927000174__auto____2 any; var root_453 any = A_arbace_j2g_embed_A_const_66.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_455 lang.IFn





					if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = x__1; if linked_454 == nil { or__1927000174__auto____2 = ifn_455.Invoke_O__O(arg_456) } else { or__1927000174__auto____2 = linked_454.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_453, arg_456) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { var root_457 any = A_arbace_j2g_embed_A_const_67.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = x__1; if linked_458 == nil { tmp5 = ifn_459.Invoke_O__O(arg_460) } else { tmp5 = linked_458.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_457, arg_460) } }
//line :126:1
					if jrt.J2g_Truth(tmp5) {






						var tmp6 any; var and__1927000168__auto____2_3 any; var root_550 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any; var root_554 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = x__1; if linked_555 == nil { arg_553 = ifn_556.Invoke_O__O(arg_557) } else { arg_553 = linked_555.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_554, arg_557) }; if linked_551 == nil { and__1927000168__auto____2_3 = ifn_552.Invoke_O__O(arg_553) } else { and__1927000168__auto____2_3 = linked_551.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_550, arg_553) }; if jrt.J2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool; var tmp7 any; var root_558 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any; var root_562 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = x__1; if linked_563 == nil { arg_561 = ifn_564.Invoke_O__O(arg_565) } else { arg_561 = linked_563.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_562, arg_565) }; if linked_559 == nil { tmp7 = ifn_560.Invoke_O__O(arg_561) } else { tmp7 = linked_559.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_558, arg_561) }; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z_NoInit(tmp7, nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_566 any = A_arbace_j2g_embed_A_const_71.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, A_arbace_j2g_embed_package_like_QMARK__A_fn_class); var ifn_568 lang.IFn
							if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var root_570 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any; var root_574 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = x__1; if linked_575 == nil { arg_573 = ifn_576.Invoke_O__O(arg_577) } else { arg_573 = linked_575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_574, arg_577) }; if linked_571 == nil { arg_569 = ifn_572.Invoke_O__O(arg_573) } else { arg_569 = linked_571.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_570, arg_573) }; if linked_567 == nil { and__1927000168__auto____4 = ifn_568.Invoke_O__O(arg_569) } else { and__1927000168__auto____4 = linked_567.(*A_arbace_j2g_embed_package_like_QMARK__A).Invoke_O_O__O(root_566, arg_569) }
//line :133:1
							if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_578 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_580 lang.IFn
								if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var root_582 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = x__1; if linked_583 == nil { arg_581 = ifn_584.Invoke_O__O(arg_585) } else { arg_581 = linked_583.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_582, arg_585) }; if linked_579 == nil { and__1927000168__auto____5 = ifn_580.Invoke_O__O(arg_581) } else { and__1927000168__auto____5 = linked_579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_578, arg_581) }
//line :133:1
								if jrt.J2g_Truth(and__1927000168__auto____5) {

									var root_586 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var arg_590 any; var root_591 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = x__1; if linked_592 == nil { arg_590 = ifn_593.Invoke_O__O(arg_594) } else { arg_590 = linked_592.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_591, arg_594) }; if linked_587 == nil { tmp6 = ifn_588.Invoke_O_O__O(arg_589, arg_590) } else { tmp6 = linked_587.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_586, arg_589, arg_590) } } else {
//line :133:1
										tmp6 = and__1927000168__auto____5 } } else { tmp6 = and__1927000168__auto____4 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp6 = and__1927000168__auto____2_3 }; if jrt.J2g_Truth(tmp6) { var seq_1991000069__2 any; var root_595 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_597 lang.IFn


											if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any; var root_599 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = x__1; if linked_600 == nil { arg_598 = ifn_601.Invoke_O__O(arg_602) } else { arg_598 = linked_600.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_599, arg_602) }; if linked_596 == nil { seq_1991000069__2 = ifn_597.Invoke_O__O(arg_598) } else { seq_1991000069__2 = linked_596.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_595, arg_598) }
//line :133:1
											var chunk_1991000070__3 any; var count_1991000071__4 int64 = 0; var i_1991000072__5 int64 = 0; L1: for {


												if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000072__5, count_1991000071__4) { var c__6 any = lang.Indexed_Cast(chunk_1991000070__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000072__5)); var root_619 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = t.F_acc; var arg_623 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp9 any; var root_624 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = x__1; if linked_625 == nil { tmp9 = ifn_626.Invoke_O__O(arg_627) } else { tmp9 = linked_625.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_624, arg_627) }; arg_623 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, c__6)).Ref(); if linked_620 == nil { ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { linked_620.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000072__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_603 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = seq_1991000069__2; if linked_604 == nil { temp__1927000414__auto____6 = ifn_605.Invoke_O__O(arg_606) } else { temp__1927000414__auto____6 = linked_604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_603, arg_606) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1991000069__7 any = temp__1927000414__auto____6; var tmp10 any; var root_607 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = seq_1991000069__7; if linked_608 == nil { tmp10 = ifn_609.Invoke_O__O(arg_610) } else { tmp10 = linked_608.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_607, arg_610) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____8 any; var root_611 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = seq_1991000069__7; if linked_612 == nil { c__1927000678__auto____8 = ifn_613.Invoke_O__O(arg_614) } else { c__1927000678__auto____8 = linked_612.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_611, arg_614) }; var tmp11 any; var root_628 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = seq_1991000069__7; if linked_629 == nil { tmp11 = ifn_630.Invoke_O__O(arg_631) } else { tmp11 = linked_629.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_628, arg_631) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = tmp11, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_615 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = seq_1991000069__7; if linked_616 == nil { c__8 = ifn_617.Invoke_O__O(arg_618) } else { c__8 = linked_616.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_615, arg_618) }; var root_632 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = t.F_acc; var arg_636 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp13 any; var root_637 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = x__1; if linked_638 == nil { tmp13 = ifn_639.Invoke_O__O(arg_640) } else { tmp13 = linked_638.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_637, arg_640) }; arg_636 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, c__8)).Ref(); if linked_633 == nil { ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { linked_633.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_632, arg_635, arg_636) }; var tmp14 any; var root_641 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = seq_1991000069__7; if linked_642 == nil { tmp14 = ifn_643.Invoke_O__O(arg_644) } else { tmp14 = linked_642.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_641, arg_644) }; seq_1991000069__2, chunk_1991000070__3, count_1991000071__4, i_1991000072__5 = tmp14, nil, 0, 0; continue L1 } } }
//line :133:1
												break L1 } }
//line :126:1
						var seq_1991000073__2 any; var root_461 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_463 lang.IFn










						if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = x__1; if linked_462 == nil { seq_1991000073__2 = ifn_463.Invoke_O__O(arg_464) } else { seq_1991000073__2 = linked_462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_461, arg_464) }
//line :126:1
						var chunk_1991000074__3 any; var count_1991000075__4 int64 = 0; var i_1991000076__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000076__5, count_1991000075__4) { var y__6 any = lang.Indexed_Cast(chunk_1991000074__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000076__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000076__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_465 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = seq_1991000073__2; if linked_466 == nil { temp__1927000414__auto____6_2 = ifn_467.Invoke_O__O(arg_468) } else { temp__1927000414__auto____6_2 = linked_466.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_465, arg_468) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1991000073__7 any = temp__1927000414__auto____6_2; var tmp15 any; var root_469 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = seq_1991000073__7; if linked_470 == nil { tmp15 = ifn_471.Invoke_O__O(arg_472) } else { tmp15 = linked_470.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_469, arg_472) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____8_2 any; var root_473 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = seq_1991000073__7; if linked_474 == nil { c__1927000678__auto____8_2 = ifn_475.Invoke_O__O(arg_476) } else { c__1927000678__auto____8_2 = linked_474.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_473, arg_476) }; var tmp16 any; var root_645 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = seq_1991000073__7; if linked_646 == nil { tmp16 = ifn_647.Invoke_O__O(arg_648) } else { tmp16 = linked_646.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_645, arg_648) }; seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = tmp16, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_477 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = seq_1991000073__7; if linked_478 == nil { y__8 = ifn_479.Invoke_O__O(arg_480) } else { y__8 = linked_478.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_477, arg_480) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp17 any; var root_649 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = seq_1991000073__7; if linked_650 == nil { tmp17 = ifn_651.Invoke_O__O(arg_652) } else { tmp17 = linked_650.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_649, arg_652) }; seq_1991000073__2, chunk_1991000074__3, count_1991000075__4, i_1991000076__5 = tmp17, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :126:1
								var tmp18 any; var root_481 any = A_arbace_j2g_embed_A_const_68.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_483 lang.IFn











								if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = x__1; if linked_482 == nil { tmp18 = ifn_483.Invoke_O__O(arg_484) } else { tmp18 = linked_482.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_481, arg_484) }
//line :126:1
								if jrt.J2g_Truth(tmp18) { var seq_1991000077__2 any; var root_485 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_487 lang.IFn











									if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = x__1; if linked_486 == nil { seq_1991000077__2 = ifn_487.Invoke_O__O(arg_488) } else { seq_1991000077__2 = linked_486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_485, arg_488) }
//line :126:1
									var chunk_1991000078__3 any; var count_1991000079__4 int64 = 0; var i_1991000080__5 int64 = 0; L3: for {











										if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000080__5, count_1991000079__4) { var vec__1991000081__6 any = lang.Indexed_Cast(chunk_1991000078__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000080__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000081__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000081__6, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000080__5); continue L3 } else { var temp__1927000414__auto____6_3 any; var root_489 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = seq_1991000077__2; if linked_490 == nil { temp__1927000414__auto____6_3 = ifn_491.Invoke_O__O(arg_492) } else { temp__1927000414__auto____6_3 = linked_490.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_489, arg_492) }; if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1991000077__7 any = temp__1927000414__auto____6_3; var tmp19 any; var root_493 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = seq_1991000077__7; if linked_494 == nil { tmp19 = ifn_495.Invoke_O__O(arg_496) } else { tmp19 = linked_494.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_493, arg_496) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____8_3 any; var root_497 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = seq_1991000077__7; if linked_498 == nil { c__1927000678__auto____8_3 = ifn_499.Invoke_O__O(arg_500) } else { c__1927000678__auto____8_3 = linked_498.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_497, arg_500) }; var tmp20 any; var root_653 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = seq_1991000077__7; if linked_654 == nil { tmp20 = ifn_655.Invoke_O__O(arg_656) } else { tmp20 = linked_654.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_653, arg_656) }; seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = tmp20, c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1991000084__8 any; var root_501 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = seq_1991000077__7; if linked_502 == nil { vec__1991000084__8 = ifn_503.Invoke_O__O(arg_504) } else { vec__1991000084__8 = linked_502.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_501, arg_504) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000084__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000084__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); var tmp21 any; var root_657 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq_1991000077__7; if linked_658 == nil { tmp21 = ifn_659.Invoke_O__O(arg_660) } else { tmp21 = linked_658.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_657, arg_660) }; seq_1991000077__2, chunk_1991000078__3, count_1991000079__4, i_1991000080__5 = tmp21, nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :126:1
											var tmp22 any; var root_505 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_507 lang.IFn












											if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = x__1; if linked_506 == nil { tmp22 = ifn_507.Invoke_O__O(arg_508) } else { tmp22 = linked_506.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_505, arg_508) }
//line :126:1
											if jrt.J2g_Truth(tmp22) { var seq_1991000087__2 any; var root_509 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_511 lang.IFn












												if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = x__1; if linked_510 == nil { seq_1991000087__2 = ifn_511.Invoke_O__O(arg_512) } else { seq_1991000087__2 = linked_510.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_509, arg_512) }
//line :126:1
												var chunk_1991000088__3 any; var count_1991000089__4 int64 = 0; var i_1991000090__5 int64 = 0; L4: for {












													if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000090__5, count_1991000089__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1991000088__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000090__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000090__5); continue L4 } else { var temp__1927000414__auto____6_4 any; var root_513 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = seq_1991000087__2; if linked_514 == nil { temp__1927000414__auto____6_4 = ifn_515.Invoke_O__O(arg_516) } else { temp__1927000414__auto____6_4 = linked_514.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_513, arg_516) }; if jrt.J2g_Truth(temp__1927000414__auto____6_4) { var seq_1991000087__7 any = temp__1927000414__auto____6_4; var tmp23 any; var root_517 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = seq_1991000087__7; if linked_518 == nil { tmp23 = ifn_519.Invoke_O__O(arg_520) } else { tmp23 = linked_518.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_517, arg_520) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____8_4 any; var root_521 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = seq_1991000087__7; if linked_522 == nil { c__1927000678__auto____8_4 = ifn_523.Invoke_O__O(arg_524) } else { c__1927000678__auto____8_4 = linked_522.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_521, arg_524) }; var tmp24 any; var root_661 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq_1991000087__7; if linked_662 == nil { tmp24 = ifn_663.Invoke_O__O(arg_664) } else { tmp24 = linked_662.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_661, arg_664) }; seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = tmp24, c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var y__8_2 any; var root_525 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = seq_1991000087__7; if linked_526 == nil { y__8_2 = ifn_527.Invoke_O__O(arg_528) } else { y__8_2 = linked_526.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_525, arg_528) }; lang.IFn_Cast(self).Invoke_O__O(y__8_2); var tmp25 any; var root_665 any = A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1991000087__7; if linked_666 == nil { tmp25 = ifn_667.Invoke_O__O(arg_668) } else { tmp25 = linked_666.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_665, arg_668) }; seq_1991000087__2, chunk_1991000088__3, count_1991000089__4, i_1991000090__5 = tmp25, nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :126:1
														return nil } } } } }; /*line :124:1*/panic("j2g: unreachable") }





























func A_arbace_j2g_embed_cut_candidates_A_New() *A_arbace_j2g_embed_cut_candidates_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Ctor() {}
//line :154:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var root_706 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_New(); var tmp2 *jrt.Class; var fncls__818 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class; if fncls__818 == nil { var fncls__818d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class = fncls__818d; tmp2 = fncls__818d } else { tmp2 = fncls__818 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_819 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any; var root_824 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var arg_828 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp6 any; var root_835 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; if linked_836 == nil { tmp6 = ifn_837.Invoke__O() } else { tmp6 = linked_836.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_835) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_New(); var tmp9 *jrt.Class; var fncls__842 *jrt.Class = A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class; if fncls__842 == nil { var fncls__842d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class = fncls__842d; tmp9 = fncls__842d } else { tmp9 = fncls__842 }; arg_828 = tmp5.Invoke_O_O_O__O(tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), srcs__0); if linked_825 == nil { arg_822 = ifn_826.Invoke_O_O__O(arg_827, arg_828) } else { arg_822 = linked_825.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_824, arg_827, arg_828) }; var arg_823 any = A_arbace_j2g_embed_A_const_88.GetRawRoot__O(); if linked_820 == nil { tmp4 = ifn_821.Invoke_O_O__O(arg_822, arg_823) } else { tmp4 = linked_820.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_819, arg_822, arg_823) }; arg_709 = tmp3.Invoke_O__O(tmp4); if linked_707 == nil { return ifn_708.Invoke_O__O(arg_709) } else { return linked_707.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_706, arg_709) } }
//line :159:1
func A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_New() *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_fn__1991000112_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A) Ctor() {}
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000112_A) Invoke_O_O__O(self, p__1991000111__1 any) any { var vec__1991000113__2 any = p__1991000111__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000113__2, lang.RT_IntCast_J__I_NoInit(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000113__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_838 any = A_arbace_j2g_embed_A_const_87.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, A_arbace_j2g_embed_names_A_fn_class); var ifn_840 lang.IFn; _ = ___3; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = text__4; if linked_839 == nil { return ifn_840.Invoke_O__O(arg_841) } else { return linked_839.(*A_arbace_j2g_embed_names_A).Invoke_O_O__O(root_838, arg_841) } }
//line :159:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_New() *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A) Ctor() {}
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A) Invoke_O_O__O(self, s__1991000098__1 any) any { var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_New_O_O(s__1991000098__1, self); var tmp2 *jrt.Class; var fncls__817 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class; if fncls__817 == nil { var fncls__817d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class = fncls__817d; tmp2 = fncls__817d } else { tmp2 = fncls__817 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :159:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A{}; t.Ctor_O_O(p0, p1); return t }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A) Ctor_O_O(c__s__1991000098, c__iter__1991000097 any) { t.F_s__1991000098 = c__s__1991000098; t.F_iter__1991000097 = c__iter__1991000097 }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A) Invoke_O__O(self any) any { { var s__1991000098__1 any; var t_ any = t.F_s__1991000098; t.F_s__1991000098 = nil; s__1991000098__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_710 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = s__1991000098__1; if linked_711 == nil { temp__1927000414__auto____2 = ifn_712.Invoke_O__O(arg_713) } else { temp__1927000414__auto____2 = linked_711.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_710, arg_713) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000098__3 any = temp__1927000414__auto____2; var tmp1 any; var root_714 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = s__1991000098__3; if linked_715 == nil { tmp1 = ifn_716.Invoke_O__O(arg_717) } else { tmp1 = linked_715.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_714, arg_717) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_718 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = s__1991000098__3; if linked_719 == nil { c__1927001037__auto____4 = ifn_720.Invoke_O__O(arg_721) } else { c__1927001037__auto____4 = linked_719.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_718, arg_721) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000100__6 any; var root_722 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_723 == nil { b__1991000100__6 = ifn_724.Invoke_O__O(arg_725) } else { b__1991000100__6 = linked_723.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_722, arg_725) }; var tmp2 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_New_I_O_O(size__1927001038__auto____5, b__1991000100__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__754 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class; if fncls__754 == nil { var fncls__754d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class = fncls__754d; tmp3 = fncls__754d } else { tmp3 = fncls__754 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_755 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any; var root_760 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = b__1991000100__6; if linked_761 == nil { arg_758 = ifn_762.Invoke_O__O(arg_763) } else { arg_758 = linked_761.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_760, arg_763) }; var arg_759 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000097); var tmp5 any; var root_764 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = s__1991000098__3; if linked_765 == nil { tmp5 = ifn_766.Invoke_O__O(arg_767) } else { tmp5 = linked_765.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_764, arg_767) }; arg_759 = tmp4.Invoke_O__O(tmp5); if linked_756 == nil { return ifn_757.Invoke_O_O__O(arg_758, arg_759) } else { return linked_756.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_755, arg_758, arg_759) } } else { var root_768 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any; var root_773 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = b__1991000100__6; if linked_774 == nil { arg_771 = ifn_775.Invoke_O__O(arg_776) } else { arg_771 = linked_774.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_773, arg_776) }; var arg_772 any; if linked_769 == nil { return ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { return linked_769.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) } } } else { var n__4 any; var root_777 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = s__1991000098__3; if linked_778 == nil { n__4 = ifn_779.Invoke_O__O(arg_780) } else { n__4 = linked_778.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_777, arg_780) }; var tmp6 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_781 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_783 lang.IFn
															if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = A_arbace_j2g_embed_A_const_78; var arg_785 any = n__4; if linked_782 == nil { or__1927000174__auto____5 = ifn_783.Invoke_O_O__O(arg_784, arg_785) } else { or__1927000174__auto____5 = linked_782.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_781, arg_784, arg_785) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
																var root_786 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = A_arbace_j2g_embed_A_const_79; var arg_790 any = n__4; if linked_787 == nil { and__1927000168__auto____5 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { and__1927000168__auto____5 = linked_787.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) } }
//line :160:1
	if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_791 any = A_arbace_j2g_embed_A_const_80.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = A_arbace_j2g_embed_A_const_81; var arg_795 any = n__4; var arg_796 any; var tmp7 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_New_O(n__4); var tmp8 *jrt.Class; var fncls__797 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class; if fncls__797 == nil { var fncls__797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class = fncls__797d; tmp8 = fncls__797d } else { tmp8 = fncls__797 }; arg_796 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_792 == nil { tmp6 = ifn_793.Invoke_O_O_O__O(arg_794, arg_795, arg_796) } else { tmp6 = linked_792.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_791, arg_794, arg_795, arg_796) } } else {
//line :160:1
			tmp6 = and__1927000168__auto____5 }
//line :159:1
	if jrt.J2g_Truth(tmp6) { var root_798 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var root_803 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_805 lang.IFn






		if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = n__4; var arg_807 any = Lit_1; var arg_808 any = Lit_7; if linked_804 == nil { arg_801 = ifn_805.Invoke_O_O_O__O(arg_806, arg_807, arg_808) } else { arg_801 = linked_804.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_803, arg_806, arg_807, arg_808) }
//line :159:1
		var arg_802 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1991000097); var tmp10 any; var root_809 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = s__1991000098__3; if linked_810 == nil { tmp10 = ifn_811.Invoke_O__O(arg_812) } else { tmp10 = linked_810.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_809, arg_812) }; arg_802 = tmp9.Invoke_O__O(tmp10); if linked_799 == nil { return ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { return linked_799.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) } } else { var tmp11 any; var root_813 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = s__1991000098__3; if linked_814 == nil { tmp11 = ifn_815.Invoke_O__O(arg_816) } else { tmp11 = linked_814.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_813, arg_816) }; s__1991000098__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :159:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1991000100, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000100 = c__b__1991000100; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :159:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A) Invoke_O__O(self any) any { { var i__1991000099__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000099__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000099__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_726 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_728 lang.IFn
																	if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = A_arbace_j2g_embed_A_const_78; var arg_730 any = n__2; if linked_727 == nil { or__1927000174__auto____3 = ifn_728.Invoke_O_O__O(arg_729, arg_730) } else { or__1927000174__auto____3 = linked_727.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_726, arg_729, arg_730) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
																		var root_731 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = A_arbace_j2g_embed_A_const_79; var arg_735 any = n__2; if linked_732 == nil { and__1927000168__auto____3 = ifn_733.Invoke_O_O__O(arg_734, arg_735) } else { and__1927000168__auto____3 = linked_732.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_731, arg_734, arg_735) } }
//line :160:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {


		var root_736 any = A_arbace_j2g_embed_A_const_80.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = A_arbace_j2g_embed_A_const_81; var arg_740 any = n__2; var arg_741 any; var tmp3 any = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_New_O(n__2); var tmp4 *jrt.Class; var fncls__742 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class; if fncls__742 == nil { var fncls__742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class = fncls__742d; tmp4 = fncls__742d } else { tmp4 = fncls__742 }; arg_741 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_737 == nil { tmp2 = ifn_738.Invoke_O_O_O__O(arg_739, arg_740, arg_741) } else { tmp2 = linked_737.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_736, arg_739, arg_740, arg_741) } } else {
//line :160:1
			tmp2 = and__1927000168__auto____3 }
//line :159:1
	if jrt.J2g_Truth(tmp2) { var root_743 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = t.F_b__1991000100; var arg_747 any; var root_748 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_750 lang.IFn






		if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = n__2; var arg_752 any = Lit_1; var arg_753 any = Lit_7; if linked_749 == nil { arg_747 = ifn_750.Invoke_O_O_O__O(arg_751, arg_752, arg_753) } else { arg_747 = linked_749.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_748, arg_751, arg_752, arg_753) }
//line :159:1
		if linked_744 == nil { ifn_745.Invoke_O_O__O(arg_746, arg_747) } else { linked_744.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_743, arg_746, arg_747) }; i__1991000099__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000099__1); continue L1 } else { i__1991000099__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000099__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :163:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :163:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :163:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :163:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :163:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_j2g_embed_with_member_types_A_New() *A_arbace_j2g_embed_with_member_types_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_j2g_embed_with_member_types_A) Ctor() {}
//line :168:1
func (t *A_arbace_j2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_types__1991000118_A_New(); var tmp2 *jrt.Class; var fncls__872 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class; if




	fncls__872 == nil { var fncls__872d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class = fncls__872d; tmp2 = fncls__872d } else { tmp2 = fncls__872 }; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var elem__4 any; var tmp3 any = /*line :168:1*/A_arbace_j2g_embed_with_member_types_elem__1991000126_A_New(); var tmp4 *jrt.Class; var fncls__873 *jrt.Class = A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class; if








	fncls__873 == nil { var fncls__873d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class = fncls__873d; tmp4 = fncls__873d } else { tmp4 = fncls__873 }; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var member_types__5 any; var tmp5 any = /*line :168:1*/A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_New_O_O(elem__4, types__3); var tmp6 *jrt.Class; var fncls__995 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class; if










	fncls__995 == nil { var fncls__995d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class = fncls__995d; tmp6 = fncls__995d } else { tmp6 = fncls__995 }; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var more__6 any; var iter__1927001039__auto____6 any; var tmp7 any = /*line :168:1*/A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp8 *jrt.Class; var fncls__1108 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class; if




















	fncls__1108 == nil { var fncls__1108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class = fncls__1108d; tmp8 = fncls__1108d } else { tmp8 = fncls__1108 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); var root_1109 any =




	A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any; var root_1113 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var root_1117 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = cands__0; var arg_1121 any = more__6; if linked_1118 == nil { arg_1116 = ifn_1119.Invoke_O_O__O(arg_1120, arg_1121) } else { arg_1116 = linked_1118.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1117, arg_1120, arg_1121) }; if linked_1114 == nil { arg_1112 = ifn_1115.Invoke_O__O(arg_1116) } else { arg_1112 = linked_1114.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1113, arg_1116) }; if linked_1110 == nil { return ifn_1111.Invoke_O__O(arg_1112) } else { return linked_1110.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1109, arg_1112) } }
//line :173:1
func A_arbace_j2g_embed_with_member_types_types__1991000118_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_83.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_New(); var tmp4 *jrt.Class; var fncls__859 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class; if fncls__859 == nil { var fncls__859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class = fncls__859d; tmp4 = fncls__859d } else { tmp4 = fncls__859 }; var tmp5 any = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp6 any; var root_860 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_862 lang.IFn
	if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var tmp7 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_New(); var tmp8 *jrt.Class; var fncls__865 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class; if fncls__865 == nil { var fncls__865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class = fncls__865d; tmp8 = fncls__865d } else { tmp8 = fncls__865 }; arg_863 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_864 any = jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref(); if linked_861 == nil { tmp6 = ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { tmp6 = linked_861.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) }
//line :174:1
	var tmp9 any = tmp6; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_New(); var tmp12 *jrt.Class
	var fncls__871 /*line :174:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class

	if fncls__871 == nil { var fncls__871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class = fncls__871d; tmp12 = fncls__871d } else { tmp12 = fncls__871 }
//line :174:1
	return tmp1.Invoke_O_O_O__O(tmp5, tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :174:1
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A) Ctor() {}
//line :174:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A) Invoke_O_O__O(self, m__1 any) any { var root_854 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(); var arg_858 any = jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref(); if linked_855 == nil { return ifn_856.Invoke_O_O__O(arg_857, arg_858) } else { return linked_855.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_854, arg_857, arg_858) } }
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A) Ctor() {}
//line :175:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_j2g_embed_with_member_types_elem__1991000126_A_New() *A_arbace_j2g_embed_with_member_types_elem__1991000126_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_elem__1991000126_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000126_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000126_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_New_O(n__1); var tmp2 *jrt.Class; var fncls__880 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class; if
														fncls__880 == nil { var fncls__880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class = fncls__880d; tmp2 = fncls__880d } else { tmp2 = fncls__880 }; temp__1927000414__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var root_881 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_883 lang.IFn

		if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_885 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any; var root_889 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_New(); var tmp4 *jrt.Class; var fncls__989 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class
		if fncls__989 == nil { var fncls__989d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class = fncls__989d; tmp4 = fncls__989d } else { tmp4 = fncls__989 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp6 any; var root_990 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = t.F_elem; var arg_994 any = lang.IFn_Cast(t.F_types).Invoke_O__O(c__3); if linked_991 == nil { tmp6 = ifn_992.Invoke_O_O__O(arg_993, arg_994) } else { tmp6 = linked_991.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_990, arg_993, arg_994) }; arg_892 = tmp5.Invoke_O__O(tmp6)
//line :182:1
		if linked_890 == nil { arg_888 = ifn_891.Invoke_O__O(arg_892) } else { arg_888 = linked_890.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_889, arg_892) }; if linked_886 == nil { arg_884 = ifn_887.Invoke_O__O(arg_888) } else { arg_884 = linked_886.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_885, arg_888) }; if linked_882 == nil { return ifn_883.Invoke_O__O(arg_884) } else { return linked_882.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_881, arg_884) } } else {
//line :180:1
			return nil } }
//line :180:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_874 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any; var t_ any = t.F_n; t.F_n = nil; arg_877 = t_; var arg_878 any = Lit_7; var arg_879 any = Lit_1; if linked_875 == nil { tmp2 = ifn_876.Invoke_O_O_O__O(arg_877, arg_878, arg_879) } else { tmp2 = linked_875.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_874, arg_877, arg_878, arg_879) }; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_New() *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A) Ctor() {}
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A) Invoke_O_O__O(self, s__1991000132__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_New_O_O(s__1991000132__1, self); var tmp2 *jrt.Class; var fncls__988 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class; if fncls__988 == nil { var fncls__988d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class = fncls__988d; tmp2 = fncls__988d } else { tmp2 = fncls__988 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :183:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A{}; t.Ctor_O_O(p0, p1); return t }
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A) Ctor_O_O(c__s__1991000132, c__iter__1991000131 any) { t.F_s__1991000132 = c__s__1991000132; t.F_iter__1991000131 = c__iter__1991000131 }
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A) Invoke_O__O(self any) any { { var s__1991000132__1 any; var t_ any = t.F_s__1991000132; t.F_s__1991000132 = nil; s__1991000132__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_893 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = s__1991000132__1; if linked_894 == nil { temp__1927000414__auto____2 = ifn_895.Invoke_O__O(arg_896) } else { temp__1927000414__auto____2 = linked_894.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_893, arg_896) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000132__3 any = temp__1927000414__auto____2; var tmp1 any; var root_897 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = s__1991000132__3; if linked_898 == nil { tmp1 = ifn_899.Invoke_O__O(arg_900) } else { tmp1 = linked_898.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_897, arg_900) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_901 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = s__1991000132__3; if linked_902 == nil { c__1927001037__auto____4 = ifn_903.Invoke_O__O(arg_904) } else { c__1927001037__auto____4 = linked_902.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_901, arg_904) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000134__6 any; var root_905 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_906 == nil { b__1991000134__6 = ifn_907.Invoke_O__O(arg_908) } else { b__1991000134__6 = linked_906.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_905, arg_908) }; var tmp2 any = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000134__6); var tmp3 *jrt.Class; var fncls__929 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class; if fncls__929 == nil { var fncls__929d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class = fncls__929d; tmp3 = fncls__929d } else { tmp3 = fncls__929 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_930 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any; var root_935 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = b__1991000134__6; if linked_936 == nil { arg_933 = ifn_937.Invoke_O__O(arg_938) } else { arg_933 = linked_936.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_935, arg_938) }; var arg_934 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000131); var tmp5 any; var root_939 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = s__1991000132__3; if linked_940 == nil { tmp5 = ifn_941.Invoke_O__O(arg_942) } else { tmp5 = linked_940.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_939, arg_942) }; arg_934 = tmp4.Invoke_O__O(tmp5); if linked_931 == nil { return ifn_932.Invoke_O_O__O(arg_933, arg_934) } else { return linked_931.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_930, arg_933, arg_934) } } else { var root_943 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any; var root_948 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = b__1991000134__6; if linked_949 == nil { arg_946 = ifn_950.Invoke_O__O(arg_951) } else { arg_946 = linked_949.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_948, arg_951) }; var arg_947 any; if linked_944 == nil { return ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { return linked_944.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_943, arg_946, arg_947) } } } else { var t__4 any; var root_952 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = s__1991000132__3; if linked_953 == nil { t__4 = ifn_954.Invoke_O__O(arg_955) } else { t__4 = linked_953.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_952, arg_955) }; var tmp6 any; var root_956 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_958 lang.IFn
																		if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref(); if linked_957 == nil { tmp6 = ifn_958.Invoke_O__O(arg_959) } else { tmp6 = linked_957.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_956, arg_959) }
//line :183:1
	if jrt.J2g_Truth(tmp6) { var tn__5 any; var root_960 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_962 lang.IFn

		if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(); var arg_964 any = Lit_1; var arg_965 any = Lit_7; if linked_961 == nil { tn__5 = ifn_962.Invoke_O_O_O__O(arg_963, arg_964, arg_965) } else { tn__5 = linked_961.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_960, arg_963, arg_964, arg_965) }
//line :183:1
		var tmp7 any; var and__1927000168__auto____6 any; var root_966 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_968 lang.IFn


		if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = A_arbace_j2g_embed_A_const_94; var arg_970 any = tn__5; if linked_967 == nil { and__1927000168__auto____6 = ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { and__1927000168__auto____6 = linked_967.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
			tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :186:1
				tmp7 = and__1927000168__auto____6 }
//line :183:1
		if jrt.J2g_Truth(tmp7) { var root_971 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = tn__5; var arg_975 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000131); var tmp9 any; var root_976 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = s__1991000132__3; if linked_977 == nil { tmp9 = ifn_978.Invoke_O__O(arg_979) } else { tmp9 = linked_977.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_976, arg_979) }; arg_975 = tmp8.Invoke_O__O(tmp9); if linked_972 == nil { return ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { return linked_972.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } else { var tmp10 any; var root_980 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = s__1991000132__3; if linked_981 == nil { tmp10 = ifn_982.Invoke_O__O(arg_983) } else { tmp10 = linked_981.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_980, arg_983) }; s__1991000132__1 = tmp10; continue L1 } } else { var tmp11 any; var root_984 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = s__1991000132__3; if linked_985 == nil { tmp11 = ifn_986.Invoke_O__O(arg_987) } else { tmp11 = linked_985.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_984, arg_987) }; s__1991000132__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :183:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000134 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000134 = c__b__1991000134 }
//line :183:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A) Invoke_O__O(self any) any { { var i__1991000133__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000133__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000133__1)); var tmp2 any; var root_909 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_911 lang.IFn
																				if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref(); if linked_910 == nil { tmp2 = ifn_911.Invoke_O__O(arg_912) } else { tmp2 = linked_910.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_909, arg_912) }
//line :183:1
	if jrt.J2g_Truth(tmp2) { var tn__3 any; var root_913 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_915 lang.IFn

		if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(); var arg_917 any = Lit_1; var arg_918 any = Lit_7; if linked_914 == nil { tn__3 = ifn_915.Invoke_O_O_O__O(arg_916, arg_917, arg_918) } else { tn__3 = linked_914.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_913, arg_916, arg_917, arg_918) }
//line :183:1
		var tmp3 any; var and__1927000168__auto____4 any; var root_919 any = A_arbace_j2g_embed_A_const_77.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_921 lang.IFn


		if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = A_arbace_j2g_embed_A_const_94; var arg_923 any = tn__3; if linked_920 == nil { and__1927000168__auto____4 = ifn_921.Invoke_O_O__O(arg_922, arg_923) } else { and__1927000168__auto____4 = linked_920.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_919, arg_922, arg_923) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
			tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :186:1
				tmp3 = and__1927000168__auto____4 }
//line :183:1
		if jrt.J2g_Truth(tmp3) { var root_924 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = t.F_b__1991000134; var arg_928 any = tn__3; if linked_925 == nil { ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { linked_925.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_924, arg_927, arg_928) }; i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } else { i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } } else { i__1991000133__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000133__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A) Invoke_O_O__O(self, s__1991000143__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1991000143__1, self); var tmp2 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class; if fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class = fncls__1107d; tmp2 = fncls__1107d } else { tmp2 = fncls__1107 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :189:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1991000143, c__iter__1991000142 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1991000143 = c__s__1991000143; t.F_iter__1991000142 = c__iter__1991000142 }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A) Invoke_O__O(self any) any { { var s__1991000143__1 any; var t_ any = t.F_s__1991000143; t.F_s__1991000143 = nil; s__1991000143__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_996 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = s__1991000143__1; if linked_997 == nil { temp__1927000414__auto____2 = ifn_998.Invoke_O__O(arg_999) } else { temp__1927000414__auto____2 = linked_997.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_996, arg_999) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1000 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = xs__1927001018__auto____3; if linked_1001 == nil { n__4 = ifn_1002.Invoke_O__O(arg_1003) } else { n__4 = linked_1001.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1000, arg_1003) }; var tmp1 any; var root_1004 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1006 lang.IFn
															if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4); if linked_1005 == nil { tmp1 = ifn_1006.Invoke_O__O(arg_1007) } else { tmp1 = linked_1005.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1004, arg_1007) }
//line :189:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_New_O(t.F_in_world_QMARK_); var tmp3 *jrt.Class; var fncls__1078 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class; if fncls__1078 == nil { var fncls__1078d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class = fncls__1078d; tmp3 = fncls__1078d } else { tmp3 = fncls__1078 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1079 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var root_1083 any = A_arbace_j2g_embed_A_const_95.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A_fn_class); var ifn_1085 lang.IFn

		if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = A_arbace_j2g_embed_A_const_96; var arg_1087 any = n__4; var arg_1088 any; var tmp6 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_New_O_O(n__4, t.F_member_types); var tmp7 *jrt.Class; var fncls__1089 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class; if fncls__1089 == nil { var fncls__1089d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class = fncls__1089d; tmp7 = fncls__1089d } else { tmp7 = fncls__1089 }; arg_1088 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_1084 == nil { tmp5 = ifn_1085.Invoke_O_O_O__O(arg_1086, arg_1087, arg_1088) } else { tmp5 = linked_1084.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A).Invoke_O_O_O_O__O(root_1083, arg_1086, arg_1087, arg_1088) }
//line :189:1
		arg_1082 = tmp4.Invoke_O__O(tmp5); if linked_1080 == nil { fs__1927001036__auto____6 = ifn_1081.Invoke_O__O(arg_1082) } else { fs__1927001036__auto____6 = linked_1080.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1079, arg_1082) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1090 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = fs__1927001036__auto____6; var arg_1094 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000142); var tmp9 any; var root_1095 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = s__1991000143__1; if linked_1096 == nil { tmp9 = ifn_1097.Invoke_O__O(arg_1098) } else { tmp9 = linked_1096.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1095, arg_1098) }; arg_1094 = tmp8.Invoke_O__O(tmp9); if linked_1091 == nil { return ifn_1092.Invoke_O_O__O(arg_1093, arg_1094) } else { return linked_1091.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1090, arg_1093, arg_1094) } } else { var tmp10 any; var root_1099 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = s__1991000143__1; if linked_1100 == nil { tmp10 = ifn_1101.Invoke_O__O(arg_1102) } else { tmp10 = linked_1100.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1099, arg_1102) }; s__1991000143__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1103 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = s__1991000143__1; if linked_1104 == nil { tmp11 = ifn_1105.Invoke_O__O(arg_1106) } else { tmp11 = linked_1104.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1103, arg_1106) }; s__1991000143__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :189:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A) Invoke_O_O__O(self, s__1991000145__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_New_O_O_O(t.F_in_world_QMARK_, s__1991000145__1, self); var tmp2 *jrt.Class; var fncls__1077 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class; if fncls__1077 == nil { var fncls__1077d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class = fncls__1077d; tmp2 = fncls__1077d } else { tmp2 = fncls__1077 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :189:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1991000145, c__iter__1991000144 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1991000145 = c__s__1991000145; t.F_iter__1991000144 = c__iter__1991000144 }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A) Invoke_O__O(self any) any { { var s__1991000145__1 any; var t_ any = t.F_s__1991000145; t.F_s__1991000145 = nil; s__1991000145__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1008 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = s__1991000145__1; if linked_1009 == nil { temp__1927000414__auto____2 = ifn_1010.Invoke_O__O(arg_1011) } else { temp__1927000414__auto____2 = linked_1009.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1008, arg_1011) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000145__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1012 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = s__1991000145__3; if linked_1013 == nil { tmp1 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp1 = linked_1013.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1012, arg_1015) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1016 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = s__1991000145__3; if linked_1017 == nil { c__1927001037__auto____4 = ifn_1018.Invoke_O__O(arg_1019) } else { c__1927001037__auto____4 = linked_1017.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1016, arg_1019) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000147__6 any; var root_1020 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1021 == nil { b__1991000147__6 = ifn_1022.Invoke_O__O(arg_1023) } else { b__1991000147__6 = linked_1021.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1020, arg_1023) }; var tmp2 any = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_New_O_O_I_O(b__1991000147__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1033 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class; if fncls__1033 == nil { var fncls__1033d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class = fncls__1033d; tmp3 = fncls__1033d } else { tmp3 = fncls__1033 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1034 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any; var root_1039 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = b__1991000147__6; if linked_1040 == nil { arg_1037 = ifn_1041.Invoke_O__O(arg_1042) } else { arg_1037 = linked_1040.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1039, arg_1042) }; var arg_1038 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000144); var tmp5 any; var root_1043 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = s__1991000145__3; if linked_1044 == nil { tmp5 = ifn_1045.Invoke_O__O(arg_1046) } else { tmp5 = linked_1044.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1043, arg_1046) }; arg_1038 = tmp4.Invoke_O__O(tmp5); if linked_1035 == nil { return ifn_1036.Invoke_O_O__O(arg_1037, arg_1038) } else { return linked_1035.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1034, arg_1037, arg_1038) } } else { var root_1047 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any; var root_1052 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = b__1991000147__6; if linked_1053 == nil { arg_1050 = ifn_1054.Invoke_O__O(arg_1055) } else { arg_1050 = linked_1053.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1052, arg_1055) }; var arg_1051 any; if linked_1048 == nil { return ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { return linked_1048.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) } } } else { var tn__4 any; var root_1056 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = s__1991000145__3; if linked_1057 == nil { tn__4 = ifn_1058.Invoke_O__O(arg_1059) } else { tn__4 = linked_1057.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1056, arg_1059) }; var tmp6 any; var root_1060 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1062 lang.IFn


	if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4); if linked_1061 == nil { tmp6 = ifn_1062.Invoke_O__O(arg_1063) } else { tmp6 = linked_1061.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1060, arg_1063) }
//line :189:1
	if jrt.J2g_Truth(tmp6) { var root_1064 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = tn__4; var arg_1068 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000144); var tmp8 any; var root_1069 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = s__1991000145__3; if linked_1070 == nil { tmp8 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp8 = linked_1070.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1069, arg_1072) }; arg_1068 = tmp7.Invoke_O__O(tmp8); if linked_1065 == nil { return ifn_1066.Invoke_O_O__O(arg_1067, arg_1068) } else { return linked_1065.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1064, arg_1067, arg_1068) } } else { var tmp9 any; var root_1073 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = s__1991000145__3; if linked_1074 == nil { tmp9 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp9 = linked_1074.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1073, arg_1076) }; s__1991000145__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :189:1
func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A) Ctor_O_O_I_O(c__b__1991000147, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000147 = c__b__1991000147; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :189:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A) Invoke_O__O(self any) any { { var i__1991000146__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000146__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000146__1)); var tmp2 any; var root_1024 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1026 lang.IFn


	if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2); if linked_1025 == nil { tmp2 = ifn_1026.Invoke_O__O(arg_1027) } else { tmp2 = linked_1025.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1024, arg_1027) }
//line :189:1
	if jrt.J2g_Truth(tmp2) { var root_1028 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = t.F_b__1991000147; var arg_1032 any = tn__2; if linked_1029 == nil { ifn_1030.Invoke_O_O__O(arg_1031, arg_1032) } else { linked_1029.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1028, arg_1031, arg_1032) }; i__1991000146__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000146__1); continue L1 } else { i__1991000146__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000146__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :191:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :191:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_j2g_embed_data_A_New() *A_arbace_j2g_embed_data_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_embed_data_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any; var root_1122 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1122, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1124 lang.IFn; if




	linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = dir__0; if linked_1123 == nil { base__2 = ifn_1124.Invoke_O__O(arg_1125) } else { base__2 = linked_1123.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1122, arg_1125) }; var root_1126 any =
	A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke__O(); var arg_1130 any; if
	jrt.NN(jrt.File_Cast(base__2)).IsDirectory__Z() { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_New_O(base__2); var tmp2 *jrt.Class; var fncls__1216 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class
		if fncls__1216 == nil { var fncls__1216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class = fncls__1216d; tmp2 = fncls__1216d } else { tmp2 = fncls__1216 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1217 any = A_arbace_j2g_embed_A_const_48.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = base__2; if linked_1218 == nil { tmp4 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp4 = linked_1218.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1217, arg_1220) }; arg_1130 = tmp3.Invoke_O__O(tmp4) } else {
//line :206:1
			arg_1130 = nil }; if /*line :205:1*/ linked_1127 == nil { return ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { return linked_1127.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) } }

func A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_New_O(p0 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_A{}; t.Ctor_O(p0); return t }
//line :207:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :207:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_A) Invoke_O_O__O(self, s__1991000162__1 any) any { var tmp1 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_New_O_O_O(s__1991000162__1, t.F_base, self); var tmp2 *jrt.Class; var fncls__1215 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class; if fncls__1215 == nil { var fncls__1215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class = fncls__1215d; tmp2 = fncls__1215d } else { tmp2 = fncls__1215 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :207:1
func A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :207:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A) Ctor_O_O_O(c__s__1991000162, c__base, c__iter__1991000161 any) { t.F_s__1991000162 = c__s__1991000162; t.F_base = c__base; t.F_iter__1991000161 = c__iter__1991000161 }
//line :207:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A) Invoke_O__O(self any) any { { var s__1991000162__1 any; var t_ any = t.F_s__1991000162; t.F_s__1991000162 = nil; s__1991000162__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1134 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = s__1991000162__1; if linked_1135 == nil { temp__1927000414__auto____2 = ifn_1136.Invoke_O__O(arg_1137) } else { temp__1927000414__auto____2 = linked_1135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1134, arg_1137) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000162__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1138 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = s__1991000162__3; if linked_1139 == nil { tmp1 = ifn_1140.Invoke_O__O(arg_1141) } else { tmp1 = linked_1139.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1138, arg_1141) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1142 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = s__1991000162__3; if linked_1143 == nil { c__1927001037__auto____4 = ifn_1144.Invoke_O__O(arg_1145) } else { c__1927001037__auto____4 = linked_1143.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1142, arg_1145) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000164__6 any; var root_1146 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1147 == nil { b__1991000164__6 = ifn_1148.Invoke_O__O(arg_1149) } else { b__1991000164__6 = linked_1147.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1146, arg_1149) }; var tmp2 any = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_New_O_O_I_O(t.F_base, b__1991000164__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1165 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class; if fncls__1165 == nil { var fncls__1165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class = fncls__1165d; tmp3 = fncls__1165d } else { tmp3 = fncls__1165 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1166 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any; var root_1171 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = b__1991000164__6; if linked_1172 == nil { arg_1169 = ifn_1173.Invoke_O__O(arg_1174) } else { arg_1169 = linked_1172.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1171, arg_1174) }; var arg_1170 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000161); var tmp5 any; var root_1175 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = s__1991000162__3; if linked_1176 == nil { tmp5 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp5 = linked_1176.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1175, arg_1178) }; arg_1170 = tmp4.Invoke_O__O(tmp5); if linked_1167 == nil { return ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { return linked_1167.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) } } else { var root_1179 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any; var root_1184 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = b__1991000164__6; if linked_1185 == nil { arg_1182 = ifn_1186.Invoke_O__O(arg_1187) } else { arg_1182 = linked_1185.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1184, arg_1187) }; var arg_1183 any; if linked_1180 == nil { return ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { return linked_1180.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) } } } else { var f__4 any; var root_1188 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = s__1991000162__3; if linked_1189 == nil { f__4 = ifn_1190.Invoke_O__O(arg_1191) } else { f__4 = linked_1189.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1188, arg_1191) }; if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var root_1192 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any; var tmp6 any; var root_1197 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1199 lang.IFn

	if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any; var root_1203 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_1204 == nil { arg_1200 = ifn_1205.Invoke_O__O(arg_1206) } else { arg_1200 = linked_1204.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1203, arg_1206) }; var arg_1201 any = jrt.File_separator.Ref(); var arg_1202 any = Lit_7; if linked_1198 == nil { tmp6 = ifn_1199.Invoke_O_O_O__O(arg_1200, arg_1201, arg_1202) } else { tmp6 = linked_1198.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1197, arg_1200, arg_1201, arg_1202) }
//line :207:1
	arg_1195 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, f__4); var arg_1196 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000161); var tmp8 any; var root_1207 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = s__1991000162__3; if linked_1208 == nil { tmp8 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp8 = linked_1208.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1207, arg_1210) }; arg_1196 = tmp7.Invoke_O__O(tmp8); if linked_1193 == nil { return ifn_1194.Invoke_O_O__O(arg_1195, arg_1196) } else { return linked_1193.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1192, arg_1195, arg_1196) } } else { var tmp9 any; var root_1211 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = s__1991000162__3; if linked_1212 == nil { tmp9 = ifn_1213.Invoke_O__O(arg_1214) } else { tmp9 = linked_1212.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1211, arg_1214) }; s__1991000162__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :207:1
func A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :207:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A) Ctor_O_O_I_O(c__base, c__b__1991000164 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_base = c__base; t.F_b__1991000164 = c__b__1991000164; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :207:1
func (t *A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A) Invoke_O__O(self any) any { { var i__1991000163__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000163__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000163__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var root_1150 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = t.F_b__1991000164; var arg_1154 any; var tmp2 any; var root_1155 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1157 lang.IFn

	if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any; var root_1161 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_1162 == nil { arg_1158 = ifn_1163.Invoke_O__O(arg_1164) } else { arg_1158 = linked_1162.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1161, arg_1164) }; var arg_1159 any = jrt.File_separator.Ref(); var arg_1160 any = Lit_7; if linked_1156 == nil { tmp2 = ifn_1157.Invoke_O_O_O__O(arg_1158, arg_1159, arg_1160) } else { tmp2 = linked_1156.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1155, arg_1158, arg_1159, arg_1160) }
//line :207:1
	arg_1154 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, f__2); if linked_1151 == nil { ifn_1152.Invoke_O_O__O(arg_1153, arg_1154) } else { linked_1151.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1150, arg_1153, arg_1154) }; i__1991000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000163__1); continue L1 } else { i__1991000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000163__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_j2g_embed_image_type_forms_A_New() *A_arbace_j2g_embed_image_type_forms_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Ctor() {}
//line :225:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any = A_arbace_j2g_embed_A_const_97; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A_New_O(prog_dir__0); var tmp2 *jrt.Class; var fncls__1348 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A_fn_class; if





	fncls__1348 == nil { var fncls__1348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A_fn_class = fncls__1348d; tmp2 = fncls__1348d } else { tmp2 = fncls__1348 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_j2g_embed_A_const_114); var types__4 any; var root_1349 any = /*line :225:1*/A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1351 lang.IFn; if












	linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var arg_1353 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp4 any; var root_1360 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; if linked_1361 == nil { tmp4 = ifn_1362.Invoke__O() } else { tmp4 = linked_1361.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_1360) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_j2g_embed_image_type_forms_fn__1991000192_A_New_O(re__2); var tmp7 *jrt.Class; var fncls__1445 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000192_A_fn_class; if fncls__1445 == nil { var fncls__1445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_embed_image_type_forms_fn__1991000192_A_fn_class = fncls__1445d; tmp7 = fncls__1445d } else { tmp7 = fncls__1445 }; arg_1353 = tmp3.Invoke_O_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), files__3); if linked_1350 == nil { types__4 = ifn_1351.Invoke_O_O__O(arg_1352, arg_1353) } else { types__4 = linked_1350.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1349, arg_1352, arg_1353) }; var root_1446 any =



	A_arbace_j2g_embed_A_const_45.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_101, Lit_18, A_arbace_j2g_embed_A_const_102, A_arbace_j2g_embed_A_const_103)); var arg_1450 any; var iter__1927001039__auto____5 any; var tmp8 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A_New(); var tmp9 *jrt.Class; var fncls__1641 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A_fn_class; if
	fncls__1641 == nil { var fncls__1641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A_fn_class = fncls__1641d; tmp9 = fncls__1641d } else { tmp9 = fncls__1641 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp11 any; var root_1642 any = A_arbace_j2g_embed_A_const_112.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_partition_all_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = A_arbace_j2g_embed_A_const_113; var arg_1646 any; var root_1647 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_1651 any; var root_1652 any = A_arbace_j2g_embed_A_const_93.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = types__4; if linked_1653 == nil { arg_1651 = ifn_1654.Invoke_O__O(arg_1655) } else { arg_1651 = linked_1653.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1652, arg_1655) }; if linked_1648 == nil { arg_1646 = ifn_1649.Invoke_O_O__O(arg_1650, arg_1651) } else { arg_1646 = linked_1648.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1647, arg_1650, arg_1651) }; if linked_1643 == nil { tmp11 = ifn_1644.Invoke_O_O__O(arg_1645, arg_1646) } else { tmp11 = linked_1643.(*aot_arbace_core.A_arbace_core_partition_all_A).Invoke_O_O_O__O(root_1642, arg_1645, arg_1646) }; arg_1450 = tmp10.Invoke_O__O(tmp11); if /*line :242:1*/ linked_1447 == nil { return ifn_1448.Invoke_O_O__O(arg_1449, arg_1450) } else { return linked_1447.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1446, arg_1449, arg_1450) } }
//line :231:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A) Invoke_O_O__O(self, s__1991000173__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A_New_O_O_O(t.F_prog_dir, s__1991000173__1, self); var tmp2 *jrt.Class; var fncls__1347 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A_fn_class; if fncls__1347 == nil { var fncls__1347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A_fn_class = fncls__1347d; tmp2 = fncls__1347d } else { tmp2 = fncls__1347 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :231:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A) Ctor_O_O_O(c__prog_dir, c__s__1991000173, c__iter__1991000172 any) { t.F_prog_dir = c__prog_dir; t.F_s__1991000173 = c__s__1991000173; t.F_iter__1991000172 = c__iter__1991000172 }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A) Invoke_O__O(self any) any { { var s__1991000173__1 any; var t_ any = t.F_s__1991000173; t.F_s__1991000173 = nil; s__1991000173__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1221 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = s__1991000173__1; if linked_1222 == nil { temp__1927000414__auto____2 = ifn_1223.Invoke_O__O(arg_1224) } else { temp__1927000414__auto____2 = linked_1222.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1221, arg_1224) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1991000180__4 any; var root_1225 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = xs__1927001018__auto____3; if linked_1226 == nil { vec__1991000180__4 = ifn_1227.Invoke_O__O(arg_1228) } else { vec__1991000180__4 = linked_1226.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1225, arg_1228) }; var pkg__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000180__4, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000180__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dir__7 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_24, pkg__5); var iterys__1927001035__auto____8 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A_New_O(alias__6); var tmp2 *jrt.Class; var fncls__1325 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A_fn_class; if fncls__1325 == nil { var fncls__1325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A_fn_class = fncls__1325d; tmp2 = fncls__1325d } else { tmp2 = fncls__1325 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____9 any; var root_1326 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp4 any; var root_1330 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1332 lang.IFn

	if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = jrt.NN(jrt.File_Cast(dir__7)).ListFiles__File1().Ref(); if linked_1331 == nil { tmp4 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp4 = linked_1331.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1330, arg_1333) }
//line :231:1
	arg_1329 = tmp3.Invoke_O__O(tmp4); if linked_1327 == nil { fs__1927001036__auto____9 = ifn_1328.Invoke_O__O(arg_1329) } else { fs__1927001036__auto____9 = linked_1327.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1326, arg_1329) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_1334 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = fs__1927001036__auto____9; var arg_1338 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1991000172); var tmp6 any; var root_1339 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = s__1991000173__1; if linked_1340 == nil { tmp6 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp6 = linked_1340.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1339, arg_1342) }; arg_1338 = tmp5.Invoke_O__O(tmp6); if linked_1335 == nil { return ifn_1336.Invoke_O_O__O(arg_1337, arg_1338) } else { return linked_1335.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1334, arg_1337, arg_1338) } } else { var tmp7 any; var root_1343 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = s__1991000173__1; if linked_1344 == nil { tmp7 = ifn_1345.Invoke_O__O(arg_1346) } else { tmp7 = linked_1344.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1343, arg_1346) }; s__1991000173__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :231:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A) Invoke_O_O__O(self, s__1991000175__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A_New_O_O_O(t.F_alias, s__1991000175__1, self); var tmp2 *jrt.Class; var fncls__1324 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A_fn_class; if fncls__1324 == nil { var fncls__1324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A_fn_class = fncls__1324d; tmp2 = fncls__1324d } else { tmp2 = fncls__1324 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :231:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A) Ctor_O_O_O(c__alias, c__s__1991000175, c__iter__1991000174 any) { t.F_alias = c__alias; t.F_s__1991000175 = c__s__1991000175; t.F_iter__1991000174 = c__iter__1991000174 }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A) Invoke_O__O(self any) any { { var s__1991000175__1 any; var t_ any = t.F_s__1991000175; t.F_s__1991000175 = nil; s__1991000175__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1235 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = s__1991000175__1; if linked_1236 == nil { temp__1927000414__auto____2 = ifn_1237.Invoke_O__O(arg_1238) } else { temp__1927000414__auto____2 = linked_1236.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1235, arg_1238) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000175__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1239 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1239, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1241 lang.IFn; if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; var arg_1242 any = s__1991000175__3; if linked_1240 == nil { tmp1 = ifn_1241.Invoke_O__O(arg_1242) } else { tmp1 = linked_1240.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1239, arg_1242) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1243 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = s__1991000175__3; if linked_1244 == nil { c__1927001037__auto____4 = ifn_1245.Invoke_O__O(arg_1246) } else { c__1927001037__auto____4 = linked_1244.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1243, arg_1246) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000177__6 any; var root_1247 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1248 == nil { b__1991000177__6 = ifn_1249.Invoke_O__O(arg_1250) } else { b__1991000177__6 = linked_1248.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1247, arg_1250) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, b__1991000177__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1270 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A_fn_class; if fncls__1270 == nil { var fncls__1270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A_fn_class = fncls__1270d; tmp3 = fncls__1270d } else { tmp3 = fncls__1270 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1271 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any; var root_1276 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = b__1991000177__6; if linked_1277 == nil { arg_1274 = ifn_1278.Invoke_O__O(arg_1279) } else { arg_1274 = linked_1277.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1276, arg_1279) }; var arg_1275 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000174); var tmp5 any; var root_1280 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = s__1991000175__3; if linked_1281 == nil { tmp5 = ifn_1282.Invoke_O__O(arg_1283) } else { tmp5 = linked_1281.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1280, arg_1283) }; arg_1275 = tmp4.Invoke_O__O(tmp5); if linked_1272 == nil { return ifn_1273.Invoke_O_O__O(arg_1274, arg_1275) } else { return linked_1272.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1271, arg_1274, arg_1275) } } else { var root_1284 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any; var root_1289 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = b__1991000177__6; if linked_1290 == nil { arg_1287 = ifn_1291.Invoke_O__O(arg_1292) } else { arg_1287 = linked_1290.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1289, arg_1292) }; var arg_1288 any; if linked_1285 == nil { return ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { return linked_1285.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) } } } else { var f__4 any; var root_1293 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = s__1991000175__3; if linked_1294 == nil { f__4 = ifn_1295.Invoke_O__O(arg_1296) } else { f__4 = linked_1294.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1293, arg_1296) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1297 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1301 any = Lit_28; if linked_1298 == nil { and__1927000168__auto____6 = ifn_1299.Invoke_O_O__O(arg_1300, arg_1301) } else { and__1927000168__auto____6 = linked_1298.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1297, arg_1300, arg_1301) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_1302 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1306 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1310 any = Lit_29; if linked_1307 == nil { arg_1305 = ifn_1308.Invoke_O_O__O(arg_1309, arg_1310) } else { arg_1305 = linked_1307.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1306, arg_1309, arg_1310) }; if linked_1303 == nil { tmp6 = ifn_1304.Invoke_O__O(arg_1305) } else { tmp6 = linked_1303.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1302, arg_1305) } } else {
//line :234:1
			tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :231:1
	if jrt.J2g_Truth(tmp6) { var root_1311 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4); var arg_1315 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000174); var tmp8 any; var root_1316 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = s__1991000175__3; if linked_1317 == nil { tmp8 = ifn_1318.Invoke_O__O(arg_1319) } else { tmp8 = linked_1317.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1316, arg_1319) }; arg_1315 = tmp7.Invoke_O__O(tmp8); if linked_1312 == nil { return ifn_1313.Invoke_O_O__O(arg_1314, arg_1315) } else { return linked_1312.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1311, arg_1314, arg_1315) } } else { var tmp9 any; var root_1320 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = s__1991000175__3; if linked_1321 == nil { tmp9 = ifn_1322.Invoke_O__O(arg_1323) } else { tmp9 = linked_1321.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1320, arg_1323) }; s__1991000175__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :231:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__b__1991000177, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000177 = c__b__1991000177; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :231:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A) Invoke_O__O(self any) any { { var i__1991000176__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000176__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000176__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1251 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1255 any = Lit_28; if linked_1252 == nil { and__1927000168__auto____4 = ifn_1253.Invoke_O_O__O(arg_1254, arg_1255) } else { and__1927000168__auto____4 = linked_1252.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1251, arg_1254, arg_1255) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1256 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any; var root_1260 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1264 any = Lit_29; if linked_1261 == nil { arg_1259 = ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { arg_1259 = linked_1261.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) }; if linked_1257 == nil { tmp2 = ifn_1258.Invoke_O__O(arg_1259) } else { tmp2 = linked_1257.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1256, arg_1259) } } else {
//line :234:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :231:1
	if jrt.J2g_Truth(tmp2) { var root_1265 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = t.F_b__1991000177; var arg_1269 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2); if linked_1266 == nil { ifn_1267.Invoke_O_O__O(arg_1268, arg_1269) } else { linked_1266.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1265, arg_1268, arg_1269) }; i__1991000176__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000176__1); continue L1 } else { i__1991000176__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000176__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_embed_image_type_forms_fn__1991000192_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000192_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000192_A{}; t.Ctor_O(p0); return t }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_A) Invoke_O_O__O(self, p__1991000191__1 any) any { var vec__1991000193__2 any = p__1991000191__1; var alias__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000193__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000193__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1363 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A_New_O(alias__3); var tmp2 *jrt.Class; var fncls__1435 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A_fn_class; if fncls__1435 == nil { var fncls__1435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A_fn_class = fncls__1435d; tmp2 = fncls__1435d } else { tmp2 = fncls__1435 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp4 any; var root_1436 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = t.F_re; var arg_1440 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O__O(f__4); if linked_1437 == nil { tmp4 = ifn_1438.Invoke_O_O__O(arg_1439, arg_1440) } else { tmp4 = linked_1437.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_1436, arg_1439, arg_1440) }; arg_1366 = tmp3.Invoke_O__O(tmp4); if linked_1364 == nil { return ifn_1365.Invoke_O__O(arg_1366) } else { return linked_1364.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1363, arg_1366) } }
//line :238:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A{}; t.Ctor_O(p0); return t }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A) Invoke_O_O__O(self, s__1991000197__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A_New_O_O_O(t.F_alias, s__1991000197__1, self); var tmp2 *jrt.Class; var fncls__1434 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A_fn_class; if fncls__1434 == nil { var fncls__1434d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A_fn_class = fncls__1434d; tmp2 = fncls__1434d } else { tmp2 = fncls__1434 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :238:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A) Ctor_O_O_O(c__alias, c__s__1991000197, c__iter__1991000196 any) { t.F_alias = c__alias; t.F_s__1991000197 = c__s__1991000197; t.F_iter__1991000196 = c__iter__1991000196 }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A) Invoke_O__O(self any) any { { var s__1991000197__1 any; var t_ any = t.F_s__1991000197; t.F_s__1991000197 = nil; s__1991000197__1 = t_; for { var temp__1927000414__auto____2 any; var root_1367 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = s__1991000197__1; if linked_1368 == nil { temp__1927000414__auto____2 = ifn_1369.Invoke_O__O(arg_1370) } else { temp__1927000414__auto____2 = linked_1368.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1367, arg_1370) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000197__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1371 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = s__1991000197__3; if linked_1372 == nil { tmp1 = ifn_1373.Invoke_O__O(arg_1374) } else { tmp1 = linked_1372.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1371, arg_1374) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1375 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = s__1991000197__3; if linked_1376 == nil { c__1927001037__auto____4 = ifn_1377.Invoke_O__O(arg_1378) } else { c__1927001037__auto____4 = linked_1376.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1375, arg_1378) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000199__6 any; var root_1379 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1380 == nil { b__1991000199__6 = ifn_1381.Invoke_O__O(arg_1382) } else { b__1991000199__6 = linked_1380.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1379, arg_1382) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, b__1991000199__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1393 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A_fn_class; if fncls__1393 == nil { var fncls__1393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A_fn_class = fncls__1393d; tmp3 = fncls__1393d } else { tmp3 = fncls__1393 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1394 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any; var root_1399 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = b__1991000199__6; if linked_1400 == nil { arg_1397 = ifn_1401.Invoke_O__O(arg_1402) } else { arg_1397 = linked_1400.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1399, arg_1402) }; var arg_1398 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000196); var tmp5 any; var root_1403 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = s__1991000197__3; if linked_1404 == nil { tmp5 = ifn_1405.Invoke_O__O(arg_1406) } else { tmp5 = linked_1404.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1403, arg_1406) }; arg_1398 = tmp4.Invoke_O__O(tmp5); if linked_1395 == nil { return ifn_1396.Invoke_O_O__O(arg_1397, arg_1398) } else { return linked_1395.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1394, arg_1397, arg_1398) } } else { var root_1407 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any; var root_1412 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = b__1991000199__6; if linked_1413 == nil { arg_1410 = ifn_1414.Invoke_O__O(arg_1415) } else { arg_1410 = linked_1413.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1412, arg_1415) }; var arg_1411 any; if linked_1408 == nil { return ifn_1409.Invoke_O_O__O(arg_1410, arg_1411) } else { return linked_1408.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1407, arg_1410, arg_1411) } } } else { var vec__1991000207__4 any; var root_1416 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = s__1991000197__3; if linked_1417 == nil { vec__1991000207__4 = ifn_1418.Invoke_O__O(arg_1419) } else { vec__1991000207__4 = linked_1417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1416, arg_1419) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000207__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000207__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1420 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1422 lang.IFn; _ = ___5; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any; var root_1425 any = A_arbace_j2g_embed_A_const_98.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = t.F_alias; var arg_1429 any = n__6; if linked_1426 == nil { arg_1423 = ifn_1427.Invoke_O_O__O(arg_1428, arg_1429) } else { arg_1423 = linked_1426.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1425, arg_1428, arg_1429) }; var arg_1424 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000196); var tmp7 any; var root_1430 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = s__1991000197__3; if linked_1431 == nil { tmp7 = ifn_1432.Invoke_O__O(arg_1433) } else { tmp7 = linked_1431.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1430, arg_1433) }; arg_1424 = tmp6.Invoke_O__O(tmp7); if linked_1421 == nil { return ifn_1422.Invoke_O_O__O(arg_1423, arg_1424) } else { return linked_1421.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1420, arg_1423, arg_1424) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :238:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__b__1991000199, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000199 = c__b__1991000199; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :238:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A) Invoke_O__O(self any) any { { var i__1991000198__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000198__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1991000203__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000198__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000203__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000203__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1383 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1385 lang.IFn; _ = ___3; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = t.F_b__1991000199; var arg_1387 any; var root_1388 any = A_arbace_j2g_embed_A_const_98.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = t.F_alias; var arg_1392 any = n__4; if linked_1389 == nil { arg_1387 = ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { arg_1387 = linked_1389.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) }; if linked_1384 == nil { ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { linked_1384.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }; i__1991000198__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000198__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A) Ctor() {}
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A) Invoke_O_O__O(self, s__1991000214__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A_New_O_O(s__1991000214__1, self); var tmp2 *jrt.Class; var fncls__1640 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A_fn_class; if fncls__1640 == nil { var fncls__1640d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A_fn_class = fncls__1640d; tmp2 = fncls__1640d } else { tmp2 = fncls__1640 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :243:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A{}; t.Ctor_O_O(p0, p1); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A) Ctor_O_O(c__s__1991000214, c__iter__1991000213 any) { t.F_s__1991000214 = c__s__1991000214; t.F_iter__1991000213 = c__iter__1991000213 }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A) Invoke_O__O(self any) any { { var s__1991000214__1 any; var t_ any = t.F_s__1991000214; t.F_s__1991000214 = nil; s__1991000214__1 = t_; for { var temp__1927000414__auto____2 any; var root_1451 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = s__1991000214__1; if linked_1452 == nil { temp__1927000414__auto____2 = ifn_1453.Invoke_O__O(arg_1454) } else { temp__1927000414__auto____2 = linked_1452.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1451, arg_1454) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000214__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1455 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = s__1991000214__3; if linked_1456 == nil { tmp1 = ifn_1457.Invoke_O__O(arg_1458) } else { tmp1 = linked_1456.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1455, arg_1458) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1459 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = s__1991000214__3; if linked_1460 == nil { c__1927001037__auto____4 = ifn_1461.Invoke_O__O(arg_1462) } else { c__1927001037__auto____4 = linked_1460.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1459, arg_1462) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000216__6 any; var root_1463 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1464 == nil { b__1991000216__6 = ifn_1465.Invoke_O__O(arg_1466) } else { b__1991000216__6 = linked_1464.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1463, arg_1466) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A_New_O_I_O(b__1991000216__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1538 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A_fn_class; if fncls__1538 == nil { var fncls__1538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A_fn_class = fncls__1538d; tmp3 = fncls__1538d } else { tmp3 = fncls__1538 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1539 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any; var root_1544 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = b__1991000216__6; if linked_1545 == nil { arg_1542 = ifn_1546.Invoke_O__O(arg_1547) } else { arg_1542 = linked_1545.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1544, arg_1547) }; var arg_1543 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000213); var tmp5 any; var root_1548 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = s__1991000214__3; if linked_1549 == nil { tmp5 = ifn_1550.Invoke_O__O(arg_1551) } else { tmp5 = linked_1549.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1548, arg_1551) }; arg_1543 = tmp4.Invoke_O__O(tmp5); if linked_1540 == nil { return ifn_1541.Invoke_O_O__O(arg_1542, arg_1543) } else { return linked_1540.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1539, arg_1542, arg_1543) } } else { var root_1552 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any; var root_1557 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = b__1991000216__6; if linked_1558 == nil { arg_1555 = ifn_1559.Invoke_O__O(arg_1560) } else { arg_1555 = linked_1558.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1557, arg_1560) }; var arg_1556 any; if linked_1553 == nil { return ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { return linked_1553.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) } } } else { var part__4 any; var root_1561 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = s__1991000214__3; if linked_1562 == nil { part__4 = ifn_1563.Invoke_O__O(arg_1564) } else { part__4 = linked_1562.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1561, arg_1564) }; var root_1565 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_104; var tmp8 any = A_arbace_j2g_embed_A_const_105; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_A_const_106; var tmp12 any; var root_1570 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1572 lang.IFn


	if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = A_arbace_j2g_embed_A_const_100.GetRawRoot__O(); var arg_1574 any = A_arbace_j2g_embed_A_const_107; var arg_1575 any = A_arbace_j2g_embed_A_const_111; var arg_1576 any; var iter__1927001039__auto____5 any; var tmp13 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A_New(); var tmp14 *jrt.Class; var fncls__1635 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A_fn_class
	if fncls__1635 == nil { var fncls__1635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A_fn_class = fncls__1635d; tmp14 = fncls__1635d } else { tmp14 = fncls__1635 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_1576 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(part__4)
//line :246:1
	if linked_1571 == nil { tmp12 = ifn_1572.Invoke_O_O_O_O__O(arg_1573, arg_1574, arg_1575, arg_1576) } else { tmp12 = linked_1571.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1570, arg_1573, arg_1574, arg_1575, arg_1576) }
//line :244:1
	arg_1568 = tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :243:1
	var arg_1569 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1991000213); var tmp16 any; var root_1636 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = s__1991000214__3; if linked_1637 == nil { tmp16 = ifn_1638.Invoke_O__O(arg_1639) } else { tmp16 = linked_1637.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1636, arg_1639) }; arg_1569 = tmp15.Invoke_O__O(tmp16); if linked_1566 == nil { return ifn_1567.Invoke_O_O__O(arg_1568, arg_1569) } else { return linked_1566.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1565, arg_1568, arg_1569) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :243:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A) Ctor_O_I_O(c__b__1991000216 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000216 = c__b__1991000216; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :243:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A) Invoke_O__O(self any) any { { var i__1991000215__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000215__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var part__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000215__1)); var root_1467 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = t.F_b__1991000216; var arg_1471 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_104; var tmp4 any = A_arbace_j2g_embed_A_const_105; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_106; var tmp8 any; var root_1472 any = A_arbace_j2g_embed_A_const_84.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1472, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1474 lang.IFn


	if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = A_arbace_j2g_embed_A_const_100.GetRawRoot__O(); var arg_1476 any = A_arbace_j2g_embed_A_const_107; var arg_1477 any = A_arbace_j2g_embed_A_const_108; var arg_1478 any; var iter__1927001039__auto____3 any; var tmp9 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A_New(); var tmp10 *jrt.Class; var fncls__1537 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A_fn_class
	if fncls__1537 == nil { var fncls__1537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A_fn_class = fncls__1537d; tmp10 = fncls__1537d } else { tmp10 = fncls__1537 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_1478 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(part__2)
//line :246:1
	if linked_1473 == nil { tmp8 = ifn_1474.Invoke_O_O_O_O__O(arg_1475, arg_1476, arg_1477, arg_1478) } else { tmp8 = linked_1473.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1472, arg_1475, arg_1476, arg_1477, arg_1478) }
//line :244:1
	arg_1471 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :243:1
	if linked_1468 == nil { ifn_1469.Invoke_O_O__O(arg_1470, arg_1471) } else { linked_1468.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1467, arg_1470, arg_1471) }; i__1991000215__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000215__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A) Ctor() {}
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A) Invoke_O_O__O(self, s__1991000221__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A_New_O_O(s__1991000221__1, self); var tmp2 *jrt.Class; var fncls__1536 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A_fn_class; if fncls__1536 == nil { var fncls__1536d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A_fn_class = fncls__1536d; tmp2 = fncls__1536d } else { tmp2 = fncls__1536 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :247:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A{}; t.Ctor_O_O(p0, p1); return t }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A) Ctor_O_O(c__s__1991000221, c__iter__1991000220 any) { t.F_s__1991000221 = c__s__1991000221; t.F_iter__1991000220 = c__iter__1991000220 }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A) Invoke_O__O(self any) any { { var s__1991000221__1 any; var t_ any = t.F_s__1991000221; t.F_s__1991000221 = nil; s__1991000221__1 = t_; for { var temp__1927000414__auto____2 any; var root_1479 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = s__1991000221__1; if linked_1480 == nil { temp__1927000414__auto____2 = ifn_1481.Invoke_O__O(arg_1482) } else { temp__1927000414__auto____2 = linked_1480.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1479, arg_1482) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000221__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1483 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = s__1991000221__3; if linked_1484 == nil { tmp1 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp1 = linked_1484.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1483, arg_1486) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1487 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = s__1991000221__3; if linked_1488 == nil { c__1927001037__auto____4 = ifn_1489.Invoke_O__O(arg_1490) } else { c__1927001037__auto____4 = linked_1488.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1487, arg_1490) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000223__6 any; var root_1491 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1492 == nil { b__1991000223__6 = ifn_1493.Invoke_O__O(arg_1494) } else { b__1991000223__6 = linked_1492.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1491, arg_1494) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000223__6); var tmp3 *jrt.Class; var fncls__1500 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_fn_class; if fncls__1500 == nil { var fncls__1500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_fn_class = fncls__1500d; tmp3 = fncls__1500d } else { tmp3 = fncls__1500 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1501 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any; var root_1506 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = b__1991000223__6; if linked_1507 == nil { arg_1504 = ifn_1508.Invoke_O__O(arg_1509) } else { arg_1504 = linked_1507.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1506, arg_1509) }; var arg_1505 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000220); var tmp5 any; var root_1510 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = s__1991000221__3; if linked_1511 == nil { tmp5 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp5 = linked_1511.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1510, arg_1513) }; arg_1505 = tmp4.Invoke_O__O(tmp5); if linked_1502 == nil { return ifn_1503.Invoke_O_O__O(arg_1504, arg_1505) } else { return linked_1502.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1501, arg_1504, arg_1505) } } else { var root_1514 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any; var root_1519 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any = b__1991000223__6; if linked_1520 == nil { arg_1517 = ifn_1521.Invoke_O__O(arg_1522) } else { arg_1517 = linked_1520.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1519, arg_1522) }; var arg_1518 any; if linked_1515 == nil { return ifn_1516.Invoke_O_O__O(arg_1517, arg_1518) } else { return linked_1515.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1514, arg_1517, arg_1518) } } } else { var t__4 any; var root_1523 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = s__1991000221__3; if linked_1524 == nil { t__4 = ifn_1525.Invoke_O__O(arg_1526) } else { t__4 = linked_1524.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1523, arg_1526) }; var root_1527 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_109; var arg_1530 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_110, t__4)); var arg_1531 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000220); var tmp9 any; var root_1532 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = s__1991000221__3; if linked_1533 == nil { tmp9 = ifn_1534.Invoke_O__O(arg_1535) } else { tmp9 = linked_1533.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1532, arg_1535) }; arg_1531 = tmp8.Invoke_O__O(tmp9); if linked_1528 == nil { return ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { return linked_1528.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :247:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000223 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000223 = c__b__1991000223 }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A) Invoke_O__O(self any) any { { var i__1991000222__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000222__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000222__1)); var root_1495 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = t.F_b__1991000223; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_109; var arg_1499 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_110, t__2)); if linked_1496 == nil { ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { linked_1496.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) }; i__1991000222__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000222__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :247:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A) Ctor() {}
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A) Invoke_O_O__O(self, s__1991000232__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A_New_O_O(s__1991000232__1, self); var tmp2 *jrt.Class; var fncls__1634 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A_fn_class; if fncls__1634 == nil { var fncls__1634d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A_fn_class = fncls__1634d; tmp2 = fncls__1634d } else { tmp2 = fncls__1634 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :247:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A{}; t.Ctor_O_O(p0, p1); return t }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A) Ctor_O_O(c__s__1991000232, c__iter__1991000231 any) { t.F_s__1991000232 = c__s__1991000232; t.F_iter__1991000231 = c__iter__1991000231 }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A) Invoke_O__O(self any) any { { var s__1991000232__1 any; var t_ any = t.F_s__1991000232; t.F_s__1991000232 = nil; s__1991000232__1 = t_; for { var temp__1927000414__auto____2 any; var root_1577 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = s__1991000232__1; if linked_1578 == nil { temp__1927000414__auto____2 = ifn_1579.Invoke_O__O(arg_1580) } else { temp__1927000414__auto____2 = linked_1578.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1577, arg_1580) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000232__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1581 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = s__1991000232__3; if linked_1582 == nil { tmp1 = ifn_1583.Invoke_O__O(arg_1584) } else { tmp1 = linked_1582.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1581, arg_1584) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1585 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = s__1991000232__3; if linked_1586 == nil { c__1927001037__auto____4 = ifn_1587.Invoke_O__O(arg_1588) } else { c__1927001037__auto____4 = linked_1586.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1585, arg_1588) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000234__6 any; var root_1589 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1590 == nil { b__1991000234__6 = ifn_1591.Invoke_O__O(arg_1592) } else { b__1991000234__6 = linked_1590.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1589, arg_1592) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1991000234__6); var tmp3 *jrt.Class; var fncls__1598 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A_fn_class; if fncls__1598 == nil { var fncls__1598d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A_fn_class = fncls__1598d; tmp3 = fncls__1598d } else { tmp3 = fncls__1598 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1599 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any; var root_1604 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = b__1991000234__6; if linked_1605 == nil { arg_1602 = ifn_1606.Invoke_O__O(arg_1607) } else { arg_1602 = linked_1605.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1604, arg_1607) }; var arg_1603 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000231); var tmp5 any; var root_1608 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = s__1991000232__3; if linked_1609 == nil { tmp5 = ifn_1610.Invoke_O__O(arg_1611) } else { tmp5 = linked_1609.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1608, arg_1611) }; arg_1603 = tmp4.Invoke_O__O(tmp5); if linked_1600 == nil { return ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { return linked_1600.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) } } else { var root_1612 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any; var root_1617 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = b__1991000234__6; if linked_1618 == nil { arg_1615 = ifn_1619.Invoke_O__O(arg_1620) } else { arg_1615 = linked_1618.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1617, arg_1620) }; var arg_1616 any; if linked_1613 == nil { return ifn_1614.Invoke_O_O__O(arg_1615, arg_1616) } else { return linked_1613.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1612, arg_1615, arg_1616) } } } else { var t__4 any; var root_1621 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = s__1991000232__3; if linked_1622 == nil { t__4 = ifn_1623.Invoke_O__O(arg_1624) } else { t__4 = linked_1622.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1621, arg_1624) }; var root_1625 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_109; var arg_1628 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_110, t__4)); var arg_1629 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000231); var tmp9 any; var root_1630 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = s__1991000232__3; if linked_1631 == nil { tmp9 = ifn_1632.Invoke_O__O(arg_1633) } else { tmp9 = linked_1631.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1630, arg_1633) }; arg_1629 = tmp8.Invoke_O__O(tmp9); if linked_1626 == nil { return ifn_1627.Invoke_O_O__O(arg_1628, arg_1629) } else { return linked_1626.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1625, arg_1628, arg_1629) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :247:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000234 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000234 = c__b__1991000234 }
//line :247:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A) Invoke_O__O(self any) any { { var i__1991000233__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000233__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000233__1)); var root_1593 any = A_arbace_j2g_embed_A_const_23.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = t.F_b__1991000234; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_109; var arg_1597 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_110, t__2)); if linked_1594 == nil { ifn_1595.Invoke_O_O__O(arg_1596, arg_1597) } else { linked_1594.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1593, arg_1596, arg_1597) }; i__1991000233__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000233__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






























































































































































































































type A_arbace_j2g_embed_A struct{ jrt.Object }

var A_arbace_j2g_embed_A_const_pool *jrt.RefArray

var A_arbace_j2g_embed_A_const_0 *lang.Var

var A_arbace_j2g_embed_A_const_1 any

var A_arbace_j2g_embed_A_const_2 *lang.Var

var A_arbace_j2g_embed_A_const_3 any

var A_arbace_j2g_embed_A_const_4 any

var A_arbace_j2g_embed_A_const_5 any

var A_arbace_j2g_embed_A_const_6 any

var A_arbace_j2g_embed_A_const_7 *lang.Var

var A_arbace_j2g_embed_A_const_8 *lang.Var

var A_arbace_j2g_embed_A_const_9 *lang.Var

var A_arbace_j2g_embed_A_const_10 *lang.Var

var A_arbace_j2g_embed_A_const_11 any

var A_arbace_j2g_embed_A_const_12 *lang.Var

var A_arbace_j2g_embed_A_const_13 *lang.Var

var A_arbace_j2g_embed_A_const_14 *lang.Var

var A_arbace_j2g_embed_A_const_15 *lang.Var

var A_arbace_j2g_embed_A_const_16 *lang.Var

var A_arbace_j2g_embed_A_const_17 *lang.Var

var A_arbace_j2g_embed_A_const_18 *lang.Var

var A_arbace_j2g_embed_A_const_19 *lang.Var

var A_arbace_j2g_embed_A_const_20 *lang.Var

var A_arbace_j2g_embed_A_const_21 *lang.Var

var A_arbace_j2g_embed_A_const_22 *lang.Var

var A_arbace_j2g_embed_A_const_23 *lang.Var

var A_arbace_j2g_embed_A_const_24 *lang.Var

var A_arbace_j2g_embed_A_const_25 *lang.Var

var A_arbace_j2g_embed_A_const_26 *lang.Var

var A_arbace_j2g_embed_A_const_27 *lang.Var

var A_arbace_j2g_embed_A_const_28 *lang.Var

var A_arbace_j2g_embed_A_const_29 *lang.Var

var A_arbace_j2g_embed_A_const_30 *lang.Var

var A_arbace_j2g_embed_A_const_31 *lang.Var

var A_arbace_j2g_embed_A_const_32 *lang.Var

var A_arbace_j2g_embed_A_const_33 *lang.Var

var A_arbace_j2g_embed_A_const_34 any

var A_arbace_j2g_embed_A_const_35 *lang.Var

var A_arbace_j2g_embed_A_const_36 any

var A_arbace_j2g_embed_A_const_37 *lang.Var

var A_arbace_j2g_embed_A_const_38 *lang.Var

var A_arbace_j2g_embed_A_const_39 *lang.Var

var A_arbace_j2g_embed_A_const_40 *lang.Var

var A_arbace_j2g_embed_A_const_41 *lang.Var

var A_arbace_j2g_embed_A_const_42 *lang.Keyword

var A_arbace_j2g_embed_A_const_43 *lang.Var

var A_arbace_j2g_embed_A_const_44 *lang.Var

var A_arbace_j2g_embed_A_const_45 *lang.Var

var A_arbace_j2g_embed_A_const_46 *lang.Var

var A_arbace_j2g_embed_A_const_47 *lang.Var

var A_arbace_j2g_embed_A_const_48 *lang.Var

var A_arbace_j2g_embed_A_const_49 any

var A_arbace_j2g_embed_A_const_50 *lang.Var

var A_arbace_j2g_embed_A_const_51 any

var A_arbace_j2g_embed_A_const_52 *lang.Keyword

var A_arbace_j2g_embed_A_const_53 *lang.Var

var A_arbace_j2g_embed_A_const_54 *lang.Var

var A_arbace_j2g_embed_A_const_55 *lang.Var

var A_arbace_j2g_embed_A_const_56 *lang.Var

var A_arbace_j2g_embed_A_const_57 *lang.Var

var A_arbace_j2g_embed_A_const_58 *lang.Var

var A_arbace_j2g_embed_A_const_59 *lang.Var

var A_arbace_j2g_embed_A_const_60 *lang.Var

var A_arbace_j2g_embed_A_const_61 *lang.Var

var A_arbace_j2g_embed_A_const_62 *lang.Var

var A_arbace_j2g_embed_A_const_63 *lang.Var

var A_arbace_j2g_embed_A_const_64 *lang.Var

var A_arbace_j2g_embed_A_const_65 *lang.Var

var A_arbace_j2g_embed_A_const_66 *lang.Var

var A_arbace_j2g_embed_A_const_67 *lang.Var

var A_arbace_j2g_embed_A_const_68 *lang.Var

var A_arbace_j2g_embed_A_const_69 *lang.Var

var A_arbace_j2g_embed_A_const_70 *lang.Var

var A_arbace_j2g_embed_A_const_71 *lang.Var

var A_arbace_j2g_embed_A_const_72 *lang.Var

var A_arbace_j2g_embed_A_const_73 *lang.Var

var A_arbace_j2g_embed_A_const_74 *lang.Var

var A_arbace_j2g_embed_A_const_75 *lang.Var

var A_arbace_j2g_embed_A_const_76 *lang.Var

var A_arbace_j2g_embed_A_const_77 *lang.Var

var A_arbace_j2g_embed_A_const_78 any

var A_arbace_j2g_embed_A_const_79 any

var A_arbace_j2g_embed_A_const_80 *lang.Var

var A_arbace_j2g_embed_A_const_81 *lang.Keyword

var A_arbace_j2g_embed_A_const_82 *lang.Var

var A_arbace_j2g_embed_A_const_83 *lang.Var

var A_arbace_j2g_embed_A_const_84 *lang.Var

var A_arbace_j2g_embed_A_const_85 *lang.Var

var A_arbace_j2g_embed_A_const_86 *lang.Var

var A_arbace_j2g_embed_A_const_87 *lang.Var

var A_arbace_j2g_embed_A_const_88 *lang.Var

var A_arbace_j2g_embed_A_const_89 *lang.Var

var A_arbace_j2g_embed_A_const_90 *lang.Var

var A_arbace_j2g_embed_A_const_91 *lang.Var

var A_arbace_j2g_embed_A_const_92 *lang.Var

var A_arbace_j2g_embed_A_const_93 *lang.Var

var A_arbace_j2g_embed_A_const_94 any

var A_arbace_j2g_embed_A_const_95 *lang.Var

var A_arbace_j2g_embed_A_const_96 *lang.Keyword

var A_arbace_j2g_embed_A_const_97 any

var A_arbace_j2g_embed_A_const_98 *lang.Var

var A_arbace_j2g_embed_A_const_99 *lang.Var

var A_arbace_j2g_embed_A_const_100 *lang.Var

var A_arbace_j2g_embed_A_const_101 any

var A_arbace_j2g_embed_A_const_102 *lang.Keyword

var A_arbace_j2g_embed_A_const_103 any

var A_arbace_j2g_embed_A_const_104 any

var A_arbace_j2g_embed_A_const_105 any

var A_arbace_j2g_embed_A_const_106 any

var A_arbace_j2g_embed_A_const_107 any

var A_arbace_j2g_embed_A_const_108 any

var A_arbace_j2g_embed_A_const_109 any

var A_arbace_j2g_embed_A_const_110 any

var A_arbace_j2g_embed_A_const_111 any

var A_arbace_j2g_embed_A_const_112 *lang.Var

var A_arbace_j2g_embed_A_const_113 any

var A_arbace_j2g_embed_A_const_114 any

var A_arbace_j2g_embed_A_init jrt.ClassInit

func A_arbace_j2g_embed_A_Init() { if !A_arbace_j2g_embed_A_init.Done() { A_arbace_j2g_embed_A_init.Run(A_arbace_j2g_embed_A_clinit) } }

func A_arbace_j2g_embed_A_clinit() { A_arbace_j2g_embed_A_clinit_p0(); A_arbace_j2g_embed_A_clinit_p1(); A_arbace_j2g_embed_A_clinit_p2(); A_arbace_j2g_embed_A_clinit_p3(); A_arbace_j2g_embed_A_clinit_p4(); A_arbace_j2g_embed_A_clinit_p5(); A_arbace_j2g_embed_A_clinit_p6(); A_arbace_j2g_embed_A_clinit_p7(); A_arbace_j2g_embed_A_clinit_p8(); A_arbace_j2g_embed_A_clinit_p9() }

func A_arbace_j2g_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 148); A_arbace_j2g_embed_A_const_0 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[33]); A_arbace_j2g_embed_A_const_1 = A_arbace_j2g_embed_A_const_pool.A[34]; A_arbace_j2g_embed_A_const_2 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[35]); A_arbace_j2g_embed_A_const_3 = A_arbace_j2g_embed_A_const_pool.A[36]; A_arbace_j2g_embed_A_const_4 = A_arbace_j2g_embed_A_const_pool.A[37]; A_arbace_j2g_embed_A_const_5 = A_arbace_j2g_embed_A_const_pool.A[38]; A_arbace_j2g_embed_A_const_6 = A_arbace_j2g_embed_A_const_pool.A[39]; A_arbace_j2g_embed_A_const_7 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[40]); A_arbace_j2g_embed_A_const_8 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[41]); A_arbace_j2g_embed_A_const_9 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[42]); A_arbace_j2g_embed_A_const_10 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[43]); A_arbace_j2g_embed_A_const_11 = A_arbace_j2g_embed_A_const_pool.A[44] }

func A_arbace_j2g_embed_A_clinit_p1() { A_arbace_j2g_embed_A_const_12 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[45]); A_arbace_j2g_embed_A_const_13 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[46]); A_arbace_j2g_embed_A_const_14 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[47]); A_arbace_j2g_embed_A_const_15 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[48]); A_arbace_j2g_embed_A_const_16 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[49]); A_arbace_j2g_embed_A_const_17 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[50]); A_arbace_j2g_embed_A_const_18 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[51]); A_arbace_j2g_embed_A_const_19 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[52]); A_arbace_j2g_embed_A_const_20 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[53]); A_arbace_j2g_embed_A_const_21 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[54]); A_arbace_j2g_embed_A_const_22 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[55]); A_arbace_j2g_embed_A_const_23 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[56]) }

func A_arbace_j2g_embed_A_clinit_p2() { A_arbace_j2g_embed_A_const_24 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[57]); A_arbace_j2g_embed_A_const_25 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[58]); A_arbace_j2g_embed_A_const_26 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[59]); A_arbace_j2g_embed_A_const_27 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[60]); A_arbace_j2g_embed_A_const_28 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[61]); A_arbace_j2g_embed_A_const_29 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[62]); A_arbace_j2g_embed_A_const_30 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[63]); A_arbace_j2g_embed_A_const_31 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[64]); A_arbace_j2g_embed_A_const_32 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[65]); A_arbace_j2g_embed_A_const_33 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[66]); A_arbace_j2g_embed_A_const_34 = A_arbace_j2g_embed_A_const_pool.A[67]; A_arbace_j2g_embed_A_const_35 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[68]) }

func A_arbace_j2g_embed_A_clinit_p3() { A_arbace_j2g_embed_A_const_36 = A_arbace_j2g_embed_A_const_pool.A[69]; A_arbace_j2g_embed_A_const_37 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[70]); A_arbace_j2g_embed_A_const_38 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[71]); A_arbace_j2g_embed_A_const_39 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[72]); A_arbace_j2g_embed_A_const_40 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[73]); A_arbace_j2g_embed_A_const_41 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[74]); A_arbace_j2g_embed_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[75]); A_arbace_j2g_embed_A_const_43 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[76]); A_arbace_j2g_embed_A_const_44 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[77]); A_arbace_j2g_embed_A_const_45 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[78]); A_arbace_j2g_embed_A_const_46 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[79]); A_arbace_j2g_embed_A_const_47 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[80]) }

func A_arbace_j2g_embed_A_clinit_p4() { A_arbace_j2g_embed_A_const_48 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[81]); A_arbace_j2g_embed_A_const_49 = A_arbace_j2g_embed_A_const_pool.A[82]; A_arbace_j2g_embed_A_const_50 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[83]); A_arbace_j2g_embed_A_const_51 = A_arbace_j2g_embed_A_const_pool.A[84]; A_arbace_j2g_embed_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[85]); A_arbace_j2g_embed_A_const_53 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[86]); A_arbace_j2g_embed_A_const_54 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[87]); A_arbace_j2g_embed_A_const_55 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[88]); A_arbace_j2g_embed_A_const_56 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[89]); A_arbace_j2g_embed_A_const_57 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[90]); A_arbace_j2g_embed_A_const_58 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[91]); A_arbace_j2g_embed_A_const_59 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[92]) }

func A_arbace_j2g_embed_A_clinit_p5() { A_arbace_j2g_embed_A_const_60 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[93]); A_arbace_j2g_embed_A_const_61 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[94]); A_arbace_j2g_embed_A_const_62 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[95]); A_arbace_j2g_embed_A_const_63 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[96]); A_arbace_j2g_embed_A_const_64 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[97]); A_arbace_j2g_embed_A_const_65 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[98]); A_arbace_j2g_embed_A_const_66 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[99]); A_arbace_j2g_embed_A_const_67 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[100]); A_arbace_j2g_embed_A_const_68 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[101]); A_arbace_j2g_embed_A_const_69 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[102]); A_arbace_j2g_embed_A_const_70 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[103]); A_arbace_j2g_embed_A_const_71 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[104]) }

func A_arbace_j2g_embed_A_clinit_p6() { A_arbace_j2g_embed_A_const_72 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[105]); A_arbace_j2g_embed_A_const_73 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[106]); A_arbace_j2g_embed_A_const_74 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[107]); A_arbace_j2g_embed_A_const_75 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[108]); A_arbace_j2g_embed_A_const_76 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[109]); A_arbace_j2g_embed_A_const_77 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[110]); A_arbace_j2g_embed_A_const_78 = A_arbace_j2g_embed_A_const_pool.A[111]; A_arbace_j2g_embed_A_const_79 = A_arbace_j2g_embed_A_const_pool.A[112]; A_arbace_j2g_embed_A_const_80 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[113]); A_arbace_j2g_embed_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[114]); A_arbace_j2g_embed_A_const_82 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[115]); A_arbace_j2g_embed_A_const_83 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[116]) }

func A_arbace_j2g_embed_A_clinit_p7() { A_arbace_j2g_embed_A_const_84 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[117]); A_arbace_j2g_embed_A_const_85 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[118]); A_arbace_j2g_embed_A_const_86 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[119]); A_arbace_j2g_embed_A_const_87 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[120]); A_arbace_j2g_embed_A_const_88 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[121]); A_arbace_j2g_embed_A_const_89 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[122]); A_arbace_j2g_embed_A_const_90 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[123]); A_arbace_j2g_embed_A_const_91 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[124]); A_arbace_j2g_embed_A_const_92 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[125]); A_arbace_j2g_embed_A_const_93 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[126]); A_arbace_j2g_embed_A_const_94 = A_arbace_j2g_embed_A_const_pool.A[127]; A_arbace_j2g_embed_A_const_95 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[128]) }

func A_arbace_j2g_embed_A_clinit_p8() { A_arbace_j2g_embed_A_const_96 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[129]); A_arbace_j2g_embed_A_const_97 = A_arbace_j2g_embed_A_const_pool.A[130]; A_arbace_j2g_embed_A_const_98 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[131]); A_arbace_j2g_embed_A_const_99 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[132]); A_arbace_j2g_embed_A_const_100 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[133]); A_arbace_j2g_embed_A_const_101 = A_arbace_j2g_embed_A_const_pool.A[134]; A_arbace_j2g_embed_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[135]); A_arbace_j2g_embed_A_const_103 = A_arbace_j2g_embed_A_const_pool.A[136]; A_arbace_j2g_embed_A_const_104 = A_arbace_j2g_embed_A_const_pool.A[137]; A_arbace_j2g_embed_A_const_105 = A_arbace_j2g_embed_A_const_pool.A[138]; A_arbace_j2g_embed_A_const_106 = A_arbace_j2g_embed_A_const_pool.A[139]; A_arbace_j2g_embed_A_const_107 = A_arbace_j2g_embed_A_const_pool.A[140]; A_arbace_j2g_embed_A_const_108 = A_arbace_j2g_embed_A_const_pool.A[141]; A_arbace_j2g_embed_A_const_109 = A_arbace_j2g_embed_A_const_pool.A[142] }

func A_arbace_j2g_embed_A_clinit_p9() { A_arbace_j2g_embed_A_const_110 = A_arbace_j2g_embed_A_const_pool.A[143]; A_arbace_j2g_embed_A_const_111 = A_arbace_j2g_embed_A_const_pool.A[144]; A_arbace_j2g_embed_A_const_112 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[145]); A_arbace_j2g_embed_A_const_113 = A_arbace_j2g_embed_A_const_pool.A[146]; A_arbace_j2g_embed_A_const_114 = A_arbace_j2g_embed_A_const_pool.A[147] }

func A_arbace_j2g_embed_A_New() *A_arbace_j2g_embed_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_A) Ctor() {}

func (t *A_arbace_j2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_A_class }

func (t *A_arbace_j2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_A); return ok }

func A_arbace_j2g_embed_A_Cast(x any) *A_arbace_j2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_A_class)) }; return v }



type A_arbace_j2g_embed_class_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_class_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_fn__1991000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_fn__1991000112_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A struct{ j2g_header uint64; F_s__1991000098, F_iter__1991000097 any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1991000100, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000103_fn__1991000104_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000097__1991000101_fn__1991000102_fn__1991000107_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_data_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A struct{ j2g_header uint64; F_s__1991000162, F_base, F_iter__1991000161 any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A struct{ j2g_header uint64; F_base, F_b__1991000164 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_data_iter__1991000161__1991000165_fn__1991000166_fn__1991000167_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000004_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000004_A_New() *A_arbace_j2g_embed_eval1991000004_A { t := &A_arbace_j2g_embed_eval1991000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000004_A_class }

func (t *A_arbace_j2g_embed_eval1991000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); return ok }

func A_arbace_j2g_embed_eval1991000004_A_Cast(x any) *A_arbace_j2g_embed_eval1991000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000004_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000008_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000008_A_New() *A_arbace_j2g_embed_eval1991000008_A { t := &A_arbace_j2g_embed_eval1991000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000008_A_class }

func (t *A_arbace_j2g_embed_eval1991000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); return ok }

func A_arbace_j2g_embed_eval1991000008_A_Cast(x any) *A_arbace_j2g_embed_eval1991000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000008_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000008_fn__1991000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000192_A struct{ j2g_header uint64; F_re any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000192_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A struct{ j2g_header uint64; F_alias, F_s__1991000197, F_iter__1991000196 any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_b__1991000199, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000192_iter__1991000196__1991000200_fn__1991000201_fn__1991000202_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A struct{ j2g_header uint64; F_prog_dir any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A struct{ j2g_header uint64; F_prog_dir, F_s__1991000173, F_iter__1991000172 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A struct{ j2g_header uint64; F_alias, F_s__1991000175, F_iter__1991000174 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_b__1991000177, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000172__1991000178_fn__1991000179_iter__1991000174__1991000183_fn__1991000184_fn__1991000185_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A struct{ j2g_header uint64; F_s__1991000214, F_iter__1991000213 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A struct{ j2g_header uint64; F_b__1991000216 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A struct{ j2g_header uint64; F_s__1991000221, F_iter__1991000220 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000223 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_fn__1991000219_iter__1991000220__1991000224_fn__1991000225_fn__1991000226_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A struct{ j2g_header uint64; F_s__1991000232, F_iter__1991000231 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000234 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000213__1991000217_fn__1991000218_iter__1991000231__1991000235_fn__1991000236_fn__1991000237_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_names_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_walk__1991000068_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_embed_names_walk__1991000068_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_fn__1991000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_fn__1991000063_A_fn_class *jrt.Class



type A_arbace_j2g_embed_reify__1991000061_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_LispReader_Resolver() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_IObj() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Is_IMeta() {}

func (t *A_arbace_j2g_embed_reify__1991000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_reify__1991000061_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_reify__1991000061_A_class }

func (t *A_arbace_j2g_embed_reify__1991000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_reify__1991000061_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_reify__1991000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_reify__1991000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_reify__1991000061_A); return ok }

func A_arbace_j2g_embed_reify__1991000061_A_Cast(x any) *A_arbace_j2g_embed_reify__1991000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_reify__1991000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_reify__1991000061_A_class)) }; return v }



type A_arbace_j2g_embed_sources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_fn__1991000047_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A struct{ j2g_header uint64; F_p, F_pairs, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A struct{ j2g_header uint64; F_p, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000047_fn__1991000051_fn__1991000053_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A struct{ j2g_header uint64; F_also, F_base any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A struct{ j2g_header uint64; F_also, F_base, F_s__1991000019, F_iter__1991000018 any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A struct{ j2g_header uint64; F_also, F_base, F_b__1991000021 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000025_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000024_fn__1991000027_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000030_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000018__1991000022_fn__1991000023_fn__1991000032_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A struct{ j2g_header uint64; F_vdir any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A struct{ j2g_header uint64; F_vdir, F_s__1991000037, F_iter__1991000036 any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A struct{ j2g_header uint64; F_b__1991000039, F_vdir any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000036__1991000040_fn__1991000041_fn__1991000042_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_elem__1991000126_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_elem__1991000126_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types, F_s__1991000143, F_iter__1991000142 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A struct{ j2g_header uint64; F_n, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_fn__1991000156_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A struct{ j2g_header uint64; F_in_world_QMARK_ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A struct{ j2g_header uint64; F_in_world_QMARK_, F_s__1991000145, F_iter__1991000144 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A struct{ j2g_header uint64; F_b__1991000147, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000142__1991000148_fn__1991000149_iter__1991000144__1991000150_fn__1991000151_fn__1991000152_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_A struct{ j2g_header uint64; F_elem, F_types any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_fn__1991000129_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A struct{ j2g_header uint64; F_s__1991000132, F_iter__1991000131 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000134 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000128_iter__1991000131__1991000135_fn__1991000136_fn__1991000137_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000119_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000121_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000118_fn__1991000123_A_fn_class *jrt.Class
