//line aot_arbace_j2g_embed.ae:1
package aot_arbace_j2g_embed

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_New() *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed_A_const_2); lang.IFn_Cast(A_arbace_j2g_embed_A_const_1.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_3, A_arbace_j2g_embed_A_const_4, A_arbace_j2g_embed_A_const_5, A_arbace_j2g_embed_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_New() *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000008_fn__1991000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed_A_const_11), A_arbace_j2g_embed_A_const_9.GetRawRoot__O(), A_arbace_j2g_embed_A_const_10) }









































func A_arbace_j2g_embed_sources_A_New() *A_arbace_j2g_embed_sources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_j2g_embed_sources_A) Ctor() {}
//line :43:1
func (t *A_arbace_j2g_embed_sources_A) Invoke_O_O__O(self, root__0 any) any { var base__2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O__O(root__0, Lit_40); var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_New_O(base__2); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class; if



	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_31.GetRawRoot__O()).Invoke_O__O(base__2)); var vdir__4 any = /*line :43:1*/lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O__O(root__0, A_arbace_j2g_embed_A_const_32.GetRawRoot__O()); var variants__5 any; if









	jrt.NN(jrt.File_Cast(vdir__4)).IsDirectory__Z() { var iter__1927001039__auto____5 any; var tmp3 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_New_O(vdir__4); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class
		if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); variants__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_31.GetRawRoot__O()).Invoke_O__O(vdir__4)) } else {
//line :53:1
			variants__5 = nil }; var tmp5 lang.IFn =



	lang.IFn_Cast(A_arbace_j2g_embed_A_const_30.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_embed_sources_fn__1991000038_A_New(); var tmp7 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class = fncls__11d; tmp7 = fncls__11d } else { tmp7 = fncls__11 }; return tmp5.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_j2g_embed_A_const_45.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_47.GetRawRoot__O()).Invoke__O(), files__3), lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_25.GetRawRoot__O(), variants__5)) }
//line :47:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A{}; t.Ctor_O(p0); return t }
//line :47:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :47:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A) Invoke_O_O__O(self, s__1991000014__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_New_O_O_O(t.F_base, s__1991000014__1, self); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :47:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A) Ctor_O_O_O(c__base, c__s__1991000014, c__iter__1991000013 any) { t.F_base = c__base; t.F_s__1991000014 = c__s__1991000014; t.F_iter__1991000013 = c__iter__1991000013 }
//line :47:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A) Invoke_O__O(self any) any { { var s__1991000014__1 any; var t_ any = t.F_s__1991000014; t.F_s__1991000014 = nil; s__1991000014__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000014__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000014__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000014__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000014__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000016__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_New_O_O_I_O(b__1991000016__6, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000013); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000016__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000014__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000016__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000014__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_28) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :47:1
	if jrt.J2g_Truth(tmp4) { var rel__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())))).Ref(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_19.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_New_O(rel__5); var tmp7 *jrt.Class
		var fncls__3 /*line :47:1*/*jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class


		if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class = fncls__3d; tmp7 = fncls__3d } else { tmp7 = fncls__3 }
//line :47:1
		if jrt.J2g_Truth(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), A_arbace_j2g_embed_A_const_21.GetRawRoot__O())) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000013); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000014__3))) } else { s__1991000014__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000014__3); continue L1 } } else { s__1991000014__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000014__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :47:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :47:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A) Ctor_O_O_I_O(c__b__1991000016, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000016 = c__b__1991000016; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :47:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A) Invoke_O__O(self any) any { { var i__1991000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000015__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_28) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :47:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())))).Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_19.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_New_O(rel__3); var tmp5 *jrt.Class
		var fncls__1 /*line :47:1*/*jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class


		if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }
//line :47:1
		if jrt.J2g_Truth(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_j2g_embed_A_const_21.GetRawRoot__O())) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp7 any = t.F_b__1991000016; tmp6.Invoke_O_O__O(tmp7, lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2))); i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } else { i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } } else { i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A{}; t.Ctor_O(p0); return t }
//line :50:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :50:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_20.GetRawRoot__O()).Invoke_O_O__O(t.F_rel, p1__1991000012_SHARP___1) }
//line :50:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A{}; t.Ctor_O(p0); return t }
//line :50:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :50:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_20.GetRawRoot__O()).Invoke_O_O__O(t.F_rel, p1__1991000012_SHARP___1) }



func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A{}; t.Ctor_O(p0); return t }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A) Invoke_O_O__O(self, s__1991000028__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_New_O_O_O(t.F_vdir, s__1991000028__1, self); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :54:1
func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A) Ctor_O_O_O(c__vdir, c__s__1991000028, c__iter__1991000027 any) { t.F_vdir = c__vdir; t.F_s__1991000028 = c__s__1991000028; t.F_iter__1991000027 = c__iter__1991000027 }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A) Invoke_O__O(self any) any { { var s__1991000028__1 any; var t_ any = t.F_s__1991000028; t.F_s__1991000028 = nil; s__1991000028__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000028__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000028__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000028__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000028__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000030__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_New_O_O_I_O(t.F_vdir, b__1991000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000027); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000030__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000028__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000030__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000028__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_28) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :54:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1991000027); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())), lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000028__3))) } else { s__1991000028__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000028__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :54:1
func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A) Ctor_O_O_I_O(c__vdir, c__b__1991000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_vdir = c__vdir; t.F_b__1991000030 = c__b__1991000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A) Invoke_O__O(self any) any { { var i__1991000029__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000029__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_28) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :54:1
	if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp4 any = t.F_b__1991000030; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())), lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2))); i__1991000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000029__1); continue L1 } else { i__1991000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000029__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_fn__1991000038_A_New() *A_arbace_j2g_embed_sources_fn__1991000038_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_A) Ctor() {}
//line :57:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_A) Invoke_O_O_O__O(self, m__1, p__1991000037__2 any) any { var vec__1991000039__3 any = p__1991000037__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000039__3, lang.RT_IntCast_J__I_NoInit(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000039__3, lang.RT_IntCast_J__I_NoInit(1), nil); if
														jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(rel__4, Lit_44)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_embed_A_const_38; var p__6 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, nil, tmp1.Invoke_O_O_O__O(rel__4, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_44)))).Ref()), nil)).Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_34.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_embed_A_const_39; var pairs__7 any = tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_embed_A_const_40.GetRawRoot__O()).Invoke_O__O(text__5))




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_41.GetRawRoot__O()).Invoke_O_O__O(m__1, p__6)) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_j2g_embed_A_const_42.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()))))
		}
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_35.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp7 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class = fncls__10d; tmp7 = fncls__10d } else { tmp7 = fncls__10 }; return tmp5.Invoke_O_O_O__O(m__1, p__6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)) } else {
//line :58:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(rel__4, Lit_49)) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_33.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_embed_A_const_38; var p__6_2 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O_O_O__O(rel__4, tmp9, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_49)))).Ref()), nil)).Ref()
















				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_41.GetRawRoot__O()).Invoke_O_O__O(m__1, p__6_2)) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_j2g_embed_A_const_42.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()))))
				}
				return lang.IFn_Cast(A_arbace_j2g_embed_A_const_35.GetRawRoot__O()).Invoke_O_O_O_O__O(m__1, p__6_2, A_arbace_j2g_embed_A_const_18.GetRawRoot__O(), text__5) } else {
//line :58:1
					if A_arbace_j2g_embed_A_const_36 != nil {



















						return lang.IFn_Cast(A_arbace_j2g_embed_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(m__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(), text__5) } else {
//line :58:1
							return nil } } } }






func A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :65:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :65:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A) Invoke_O_O__O(self, src__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_30.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_New_O_O(t.F_p, t.F_rel); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), src__1, t.F_pairs) }
//line :66:1
func A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :66:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A) Invoke_O_O_O__O(self, src__1, p__1991000043__2 any) any { var vec__1991000045__3 any = p__1991000043__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000045__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000045__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_43.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref()) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = t.F_rel; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_j2g_embed_A_const_42.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_51, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_44.GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(), lang.PersistentArrayMap_EMPTY.Ref())))) }; var tmp3 lang.IFn =


	lang.IFn_Cast(A_arbace_j2g_embed_A_const_33.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_embed_A_const_38; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, nil), jrt.RefArrayOf(jrt.Object_class, tmp3.Invoke_O_O_O__O(src__1, tmp4, jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref()), new__5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_33.GetRawRoot__O()).Invoke_O_O__O(src__1, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__6), int64(lang.RT_Count_O__I_NoInit(old__4)))).Ref()))).Ref() }















func A_arbace_j2g_embed_reify__1991000052_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_j2g_embed_reify__1991000052_A { t := &A_arbace_j2g_embed_reify__1991000052_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :87:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :87:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :87:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :87:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :87:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_j2g_embed_A_Init(); tmp1 = A_arbace_j2g_embed_A_const_48; return lang.Symbol_Cast(tmp1) }
//line :87:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :87:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_j2g_embed_reify__1991000052_A_New_IPersistentMap(m) }





func A_arbace_j2g_embed_read_all_A_New() *A_arbace_j2g_embed_read_all_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_embed_read_all_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_52.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_53.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_54; var tmp4 any = jrt.Boolean_FALSE.Ref(); var tmp5 any = A_arbace_j2g_embed_A_const_55; var tmp6 any = A_arbace_j2g_embed_A_const_56.GetRawRoot__O(); var tmp7 any = A_arbace_j2g_embed_A_const_57; var tmp8 any = A_arbace_j2g_embed_read_all_fn__1991000054_A_New(); var tmp9 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class; if



	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class = fncls__12d; tmp9 = fncls__12d } else { tmp9 = fncls__12 }; /*line :95:1*/tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil))); var tmp10 any; tmp11 := /*line :93:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_58, r__2)






		if lang.Util_Equiv_O_O__Z_NoInit(f__6, A_arbace_j2g_embed_A_const_50) { tmp10 = acc__5 } else { acc__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_9.GetRawRoot__O()).Invoke_O_O__O(acc__5, f__6); continue L1 }
//line :93:1
		break L1 } }; return nil }();

	lang.IFn_Cast(A_arbace_j2g_embed_A_const_51.GetRawRoot__O()).Invoke__O(); if /*line :93:1*/ tmp11 != nil { panic(tmp11) }; return tmp10 }



func A_arbace_j2g_embed_read_all_fn__1991000054_A_New() *A_arbace_j2g_embed_read_all_fn__1991000054_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_fn__1991000054_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000054_A) Ctor() {}
//line :97:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000054_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_j2g_embed_class_like_QMARK__A_New() *A_arbace_j2g_embed_class_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Ctor() {}
//line :102:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_1); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)), int64(lang.RT_Count_O__I_NoInit(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_embed_package_like_QMARK__A_New() *A_arbace_j2g_embed_package_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Ctor() {}
//line :106:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_1))); if and__1927000168__auto____2 {
											return lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_60.GetRawRoot__O()).Invoke_O__O(s__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_embed_names_A_New() *A_arbace_j2g_embed_names_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_embed_names_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.PersistentHashSet_EMPTY.Ref()); var walk__3 any; var tmp1 any = A_arbace_j2g_embed_names_walk__1991000059_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_embed_names_walk__1991000059_A_fn_class; if




	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_embed_names_walk__1991000059_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var seq_1991000083__4 any = /*line :109:1*/lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_74.GetRawRoot__O()).Invoke_O__O(text__0)); var chunk_1991000084__5 any; var count_1991000085__6 int64 = 0; var i_1991000086__7 int64 = 0; L1: for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000086__7, count_1991000085__6) { var f__8 any = lang.Indexed_Cast(chunk_1991000084__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000086__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000086__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1991000083__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1991000083__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1991000083__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1991000083__9); seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1991000083__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1991000083__9); lang.IFn_Cast(walk__3).Invoke_O__O(f__10); seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1991000083__9), nil, 0, 0; continue L1 } } }
//line :109:1
		break L1 }; return /*line :131:1*/ lang.IFn_Cast(A_arbace_j2g_embed_A_const_73.GetRawRoot__O()).Invoke_O__O(acc__2) }
//line :114:1
func A_arbace_j2g_embed_names_walk__1991000059_A_New_O(p0 any) *A_arbace_j2g_embed_names_walk__1991000059_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_walk__1991000059_A{}; t.Ctor_O(p0); return t }
//line :114:1
func (t *A_arbace_j2g_embed_names_walk__1991000059_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :114:1
func (t *A_arbace_j2g_embed_names_walk__1991000059_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__1)
											if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_62.GetRawRoot__O()).Invoke_O__O(x__1)) {

		var tmp1 any; var and__1927000168__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_j2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1), nil); if and__1927000168__auto____2 { tmp1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_69.GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_64.GetRawRoot__O()); var tmp3 any = t.F_acc; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_69.GetRawRoot__O()).Invoke_O__O(x__1)) }
		var tmp4 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.J2g_Truth(and__1927000168__auto____2_2) { tmp4 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp4 = and__1927000168__auto____2_2 }; if jrt.J2g_Truth(tmp4) {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_64.GetRawRoot__O()); var tmp6 any = t.F_acc; return tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_j2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :120:1
				return nil } } else {
//line :116:1
					var tmp7 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_65.GetRawRoot__O()).Invoke_O__O(x__1)





					if jrt.J2g_Truth(or__1927000174__auto____2) { tmp7 = or__1927000174__auto____2 } else { tmp7 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_66.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :116:1
					if jrt.J2g_Truth(tmp7) {






						var tmp8 any; var and__1927000168__auto____2_3 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_62.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1)); if jrt.J2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_j2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1)), nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_70.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1))); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(x__1)); if jrt.J2g_Truth(and__1927000168__auto____5) {

							tmp8 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_71.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_62.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :123:1
								tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 } } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp8 = and__1927000168__auto____2_3 }; if jrt.J2g_Truth(tmp8) { var seq_1991000060__2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(x__1)); var chunk_1991000061__3 any; var count_1991000062__4 int64 = 0; var i_1991000063__5 int64 = 0; L1: for {


									if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000063__5, count_1991000062__4) { var c__6 any = lang.Indexed_Cast(chunk_1991000061__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000063__5)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_64.GetRawRoot__O()); var tmp10 any = t.F_acc; tmp9.Invoke_O_O__O(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1), nil, c__6)).Ref()); seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000063__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1991000060__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1991000060__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1991000060__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1991000060__7); seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1991000060__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1991000060__7); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_64.GetRawRoot__O()); var tmp12 any = t.F_acc; tmp11.Invoke_O_O__O(tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1), nil, c__8)).Ref()); seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1991000060__7), nil, 0, 0; continue L1 } } }
//line :123:1
									break L1 } }
//line :116:1
						var seq_1991000064__2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1); var chunk_1991000065__3 any; var count_1991000066__4 int64 = 0; var i_1991000067__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000067__5, count_1991000066__4) { var y__6 any = lang.Indexed_Cast(chunk_1991000065__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000067__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000067__5); continue L2 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1991000064__2); if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1991000064__7 any = temp__1927000414__auto____6_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1991000064__7)) { var c__1927000678__auto____8_2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1991000064__7); seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1991000064__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1991000064__7); lang.IFn_Cast(self).Invoke_O__O(y__8); seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1991000064__7), nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :116:1
								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_67.GetRawRoot__O()).Invoke_O__O(x__1)) { var seq_1991000068__2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1); var chunk_1991000069__3 any; var count_1991000070__4 int64 = 0; var i_1991000071__5 int64 = 0; L3: for {











									if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000071__5, count_1991000070__4) { var vec__1991000072__6 any = lang.Indexed_Cast(chunk_1991000069__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000071__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000072__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000072__6, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000071__5); continue L3 } else { var temp__1927000414__auto____6_3 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1991000068__2); if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1991000068__7 any = temp__1927000414__auto____6_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1991000068__7)) { var c__1927000678__auto____8_3 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1991000068__7); seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1991000068__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1991000075__8 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1991000068__7); var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000075__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000075__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1991000068__7), nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :116:1
										if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_68.GetRawRoot__O()).Invoke_O__O(x__1)) { var seq_1991000078__2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1); var chunk_1991000079__3 any; var count_1991000080__4 int64 = 0; var i_1991000081__5 int64 = 0; L4: for {












											if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000081__5, count_1991000080__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1991000079__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000081__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000081__5); continue L4 } else { var temp__1927000414__auto____6_4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1991000078__2); if jrt.J2g_Truth(temp__1927000414__auto____6_4) { var seq_1991000078__7 any = temp__1927000414__auto____6_4; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1991000078__7)) { var c__1927000678__auto____8_4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1991000078__7); seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1991000078__7), c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var y__8_2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1991000078__7); lang.IFn_Cast(self).Invoke_O__O(y__8_2); seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1991000078__7), nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :116:1
												return nil } } } } }; /*line :114:1*/panic("j2g: unreachable") }





























func A_arbace_j2g_embed_cut_candidates_A_New() *A_arbace_j2g_embed_cut_candidates_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_75.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_82.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_83.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_86.GetRawRoot__O()).Invoke__O(); var tmp11 any = A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_New(); var tmp12 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class = fncls__19d; tmp12 = fncls__19d } else { tmp12 = fncls__19 }; tmp2 = tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O_O__O(tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), srcs__0)), A_arbace_j2g_embed_A_const_84.GetRawRoot__O())); return tmp1.Invoke_O__O(tmp2) }
//line :149:1
func A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_New() *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_fn__1991000103_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A) Ctor() {}
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A) Invoke_O_O__O(self, p__1991000102__1 any) any { var vec__1991000104__2 any = p__1991000102__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000104__2, lang.RT_IntCast_J__I_NoInit(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000104__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; return lang.IFn_Cast(A_arbace_j2g_embed_A_const_87.GetRawRoot__O()).Invoke_O__O(text__4) }
//line :149:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_New() *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A) Ctor() {}
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A) Invoke_O_O__O(self, s__1991000089__1 any) any { var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_New_O_O(s__1991000089__1, self); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :149:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A) Ctor_O_O(c__s__1991000089, c__iter__1991000088 any) { t.F_s__1991000089 = c__s__1991000089; t.F_iter__1991000088 = c__iter__1991000088 }
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A) Invoke_O__O(self any) any { { var s__1991000089__1 any; var t_ any = t.F_s__1991000089; t.F_s__1991000089 = nil; s__1991000089__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000089__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000089__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000089__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000091__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_New_O_I_O(b__1991000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000088); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000091__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000089__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000091__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000089__3); var tmp4 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_78, n__4)
															if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
																and__1927000168__auto____5 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_79, n__4) }
//line :150:1
	if jrt.J2g_Truth(and__1927000168__auto____5) {


		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_77.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_embed_A_const_80; var tmp7 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_New_O(n__4); var tmp8 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class = fncls__16d; tmp8 = fncls__16d } else { tmp8 = fncls__16 }; tmp4 = tmp5.Invoke_O_O_O__O(tmp6, n__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {
//line :150:1
			tmp4 = and__1927000168__auto____5 }
//line :149:1
	if jrt.J2g_Truth(tmp4) { var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1991000088); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(n__4, Lit_1, Lit_7), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000089__3))) } else { s__1991000089__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000089__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :149:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A) Ctor_O_I_O(c__b__1991000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000091 = c__b__1991000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :149:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A) Invoke_O__O(self any) any { { var i__1991000090__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000090__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_78, n__2)
																	if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
																		and__1927000168__auto____3 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_79, n__2) }
//line :150:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {


		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_embed_A_const_80; var tmp5 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_New_O(n__2); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; tmp2 = tmp3.Invoke_O_O_O__O(tmp4, n__2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) } else {
//line :150:1
			tmp2 = and__1927000168__auto____3 }
//line :149:1
	if jrt.J2g_Truth(tmp2) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp8 any = t.F_b__1991000091; tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_j2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(n__2, Lit_1, Lit_7)); i__1991000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000090__1); continue L1 } else { i__1991000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000090__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :153:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :153:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :153:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :153:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :153:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_j2g_embed_with_member_types_A_New() *A_arbace_j2g_embed_with_member_types_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_j2g_embed_with_member_types_A) Ctor() {}
//line :158:1
func (t *A_arbace_j2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_types__1991000109_A_New(); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class; if




	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var elem__4 any; var tmp3 any = /*line :158:1*/A_arbace_j2g_embed_with_member_types_elem__1991000117_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class; if








	fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var member_types__5 any; var tmp5 any = /*line :158:1*/A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_New_O_O(elem__4, types__3); var tmp6 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class; if










	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class = fncls__29d; tmp6 = fncls__29d } else { tmp6 = fncls__29 }; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var more__6 any; var iter__1927001039__auto____6 any; var tmp7 any = /*line :158:1*/A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp8 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class; if




















	fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class = fncls__35d; tmp8 = fncls__35d } else { tmp8 = fncls__35 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); return /*line :184:1*/ lang.IFn_Cast(A_arbace_j2g_embed_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_82.GetRawRoot__O()).Invoke_O_O__O(cands__0, more__6))) }
//line :163:1
func A_arbace_j2g_embed_with_member_types_types__1991000109_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_A) Ctor() {}
//line :163:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_82.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_88.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_New(); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; var tmp5 any = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_New(); var tmp8 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class
	if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class = fncls__21d; tmp8 = fncls__21d } else { tmp8 = fncls__21 }
//line :164:1
	var tmp9 any = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_88.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_New(); var tmp12 *jrt.Class
	var fncls__22 /*line :164:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class

	if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class = fncls__22d; tmp12 = fncls__22d } else { tmp12 = fncls__22 }
//line :164:1
	return tmp1.Invoke_O_O_O__O(tmp5, tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :164:1
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A) Invoke_O_O__O(self, m__1 any) any { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(), jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref()) }
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A) Ctor() {}
//line :165:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A) Ctor() {}
//line :166:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_j2g_embed_with_member_types_elem__1991000117_A_New() *A_arbace_j2g_embed_with_member_types_elem__1991000117_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_elem__1991000117_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000117_A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000117_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :169:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_New_O(n__1); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class; if
														fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; temp__1927000414__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_90.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_91.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_92.GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____4 any; var tmp7 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_New(); var tmp8 *jrt.Class
															var fncls__28 /*line :170:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class


		if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class = fncls__28d; tmp8 = fncls__28d } else { tmp8 = fncls__28 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_89.GetRawRoot__O()); var tmp10 any = t.F_elem; tmp6 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(t.F_types).Invoke_O__O(c__3)))
//line :172:1
		return tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) } else {
//line :170:1
			return nil } }
//line :170:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A{}; t.Ctor_O(p0); return t }
//line :170:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :170:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_81.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(jrt.String_Cast(tmp2.Invoke_O_O_O__O(tmp3, Lit_7, Lit_1)), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_New() *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A) Invoke_O_O__O(self, s__1991000123__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_New_O_O(s__1991000123__1, self); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :173:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A) Ctor_O_O(c__s__1991000123, c__iter__1991000122 any) { t.F_s__1991000123 = c__s__1991000123; t.F_iter__1991000122 = c__iter__1991000122 }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A) Invoke_O__O(self any) any { { var s__1991000123__1 any; var t_ any = t.F_s__1991000123; t.F_s__1991000123 = nil; s__1991000123__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000123__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000123__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000123__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000123__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000125__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_New_O_I_O(b__1991000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000122); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000125__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000123__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000125__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000123__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref())) { var tn__5 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(), Lit_1, Lit_7); var tmp4 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_93, tn__5)


	if jrt.J2g_Truth(and__1927000168__auto____6) {
		tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :176:1
			tmp4 = and__1927000168__auto____6 }
//line :173:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1991000122); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tn__5, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000123__3))) } else { s__1991000123__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000123__3); continue L1 } } else { s__1991000123__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000123__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :173:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A) Ctor_O_I_O(c__b__1991000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000125 = c__b__1991000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A) Invoke_O__O(self any) any { { var i__1991000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000124__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref())) { var tn__3 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(), Lit_1, Lit_7); var tmp2 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_93, tn__3)


	if jrt.J2g_Truth(and__1927000168__auto____4) {
		tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :176:1
			tmp2 = and__1927000168__auto____4 }
//line :173:1
	if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1991000125, tn__3); i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } else { i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } } else { i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A) Invoke_O_O__O(self, s__1991000134__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1991000134__1, self); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :179:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1991000134, c__iter__1991000133 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1991000134 = c__s__1991000134; t.F_iter__1991000133 = c__iter__1991000133 }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A) Invoke_O__O(self any) any { { var s__1991000134__1 any; var t_ any = t.F_s__1991000134; t.F_s__1991000134 = nil; s__1991000134__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000134__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4))) { var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_New_O(t.F_in_world_QMARK_); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_94.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_embed_A_const_95; var tmp7 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_New_O_O(n__4, t.F_member_types); var tmp8 *jrt.Class
															var fncls__33 /*line :179:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class

	if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class = fncls__33d; tmp8 = fncls__33d } else { tmp8 = fncls__33 }
//line :179:1
	fs__1927001036__auto____6 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp6, n__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1991000133); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_82.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000134__1))) } else { s__1991000134__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000134__1); continue L1 } } else { s__1991000134__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000134__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :179:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A{}; t.Ctor_O(p0); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A) Invoke_O_O__O(self, s__1991000136__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_New_O_O_O(t.F_in_world_QMARK_, s__1991000136__1, self); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :179:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1991000136, c__iter__1991000135 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1991000136 = c__s__1991000136; t.F_iter__1991000135 = c__iter__1991000135 }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A) Invoke_O__O(self any) any { { var s__1991000136__1 any; var t_ any = t.F_s__1991000136; t.F_s__1991000136 = nil; s__1991000136__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000136__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000136__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000136__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000136__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000138__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_New_O_O_I_O(b__1991000138__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000135); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000138__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000136__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000138__6), nil) } } else { var tn__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000136__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000135); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tn__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000136__3))) } else { s__1991000136__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000136__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :179:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A) Ctor_O_O_I_O(c__b__1991000138, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000138 = c__b__1991000138; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :179:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A) Invoke_O__O(self any) any { { var i__1991000137__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000137__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2))) { lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1991000138, tn__2); i__1991000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000137__1); continue L1 } else { i__1991000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000137__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :181:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :181:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_j2g_embed_data_A_New() *A_arbace_j2g_embed_data_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_embed_data_A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O__O(dir__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_45.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_47.GetRawRoot__O()).Invoke__O(); var tmp3 any; if






	jrt.NN(jrt.File_Cast(base__2)).IsDirectory__Z() { var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_New_O(base__2); var tmp5 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class
		if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class = fncls__38d; tmp5 = fncls__38d } else { tmp5 = fncls__38 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_31.GetRawRoot__O()).Invoke_O__O(base__2)) } else {
//line :196:1
			tmp3 = nil }; return /*line :195:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3) }

func A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_New_O(p0 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_A{}; t.Ctor_O(p0); return t }
//line :197:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :197:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A) Invoke_O_O__O(self, s__1991000153__1 any) any { var tmp1 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_New_O_O_O(t.F_base, s__1991000153__1, self); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :197:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A) Ctor_O_O_O(c__base, c__s__1991000153, c__iter__1991000152 any) { t.F_base = c__base; t.F_s__1991000153 = c__s__1991000153; t.F_iter__1991000152 = c__iter__1991000152 }
//line :197:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A) Invoke_O__O(self any) any { { var s__1991000153__1 any; var t_ any = t.F_s__1991000153; t.F_s__1991000153 = nil; s__1991000153__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000153__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000153__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000153__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000153__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000155__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_New_O_I_O_O(t.F_base, size__1927001038__auto____5, b__1991000155__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000152); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000155__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000153__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000155__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000153__3); if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000152); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())), jrt.File_separator.Ref(), Lit_7), f__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000153__3))) } else { s__1991000153__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000153__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :197:1
func A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :197:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A) Ctor_O_I_O_O(c__base any, c__size__1927001038__auto__ int32, c__b__1991000155, c__c__1927001037__auto__ any) { t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000155 = c__b__1991000155; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :197:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A) Invoke_O__O(self any) any { { var i__1991000154__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000154__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1991000155; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())), jrt.File_separator.Ref(), Lit_7), f__2)); i__1991000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000154__1); continue L1 } else { i__1991000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000154__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_j2g_embed_image_type_forms_A_New() *A_arbace_j2g_embed_image_type_forms_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Ctor() {}
//line :215:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any = A_arbace_j2g_embed_A_const_96; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_New_O(prog_dir__0); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class; if





	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_j2g_embed_A_const_97); var types__4 any; var tmp3 lang.IFn = /*line :215:1*/lang.IFn_Cast(A_arbace_j2g_embed_A_const_83.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_85.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_86.GetRawRoot__O()).Invoke__O(); var tmp7 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_New_O(re__2); var tmp8 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class; if












	fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class = fncls__47d; tmp8 = fncls__47d } else { tmp8 = fncls__47 }; types__4 = tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O_O__O(tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), files__3)); var tmp9 lang.IFn =



	lang.IFn_Cast(A_arbace_j2g_embed_A_const_45.GetRawRoot__O()); var tmp10 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_108, Lit_18, A_arbace_j2g_embed_A_const_109, A_arbace_j2g_embed_A_const_110)); var tmp11 any; var iter__1927001039__auto____5 any; var tmp12 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_New(); var tmp13 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class; if
	fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class = fncls__56d; tmp13 = fncls__56d } else { tmp13 = fncls__56 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_111.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_embed_A_const_112; tmp11 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_j2g_embed_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_18.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_embed_A_const_92.GetRawRoot__O()).Invoke_O__O(types__4)))); return /*line :232:1*/ tmp9.Invoke_O_O__O(tmp10, tmp11) }
//line :221:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A{}; t.Ctor_O(p0); return t }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A) Invoke_O_O__O(self, s__1991000164__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_New_O_O_O(t.F_prog_dir, s__1991000164__1, self); var tmp2 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class = fncls__42d; tmp2 = fncls__42d } else { tmp2 = fncls__42 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :221:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A) Ctor_O_O_O(c__prog_dir, c__s__1991000164, c__iter__1991000163 any) { t.F_prog_dir = c__prog_dir; t.F_s__1991000164 = c__s__1991000164; t.F_iter__1991000163 = c__iter__1991000163 }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A) Invoke_O__O(self any) any { { var s__1991000164__1 any; var t_ any = t.F_s__1991000164; t.F_s__1991000164 = nil; s__1991000164__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000164__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1991000171__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var pkg__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000171__4, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000171__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dir__7 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_24, pkg__5); var iterys__1927001035__auto____8 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_New_O(alias__6); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____9 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_91.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(dir__7)).ListFiles__File1().Ref()))); if jrt.J2g_Truth(fs__1927001036__auto____9) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000163); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_82.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____9, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000164__1))) } else { s__1991000164__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000164__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :221:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A{}; t.Ctor_O(p0); return t }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A) Invoke_O_O__O(self, s__1991000166__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_New_O_O_O(t.F_alias, s__1991000166__1, self); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :221:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A) Ctor_O_O_O(c__alias, c__s__1991000166, c__iter__1991000165 any) { t.F_alias = c__alias; t.F_s__1991000166 = c__s__1991000166; t.F_iter__1991000165 = c__iter__1991000165 }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A) Invoke_O__O(self any) any { { var s__1991000166__1 any; var t_ any = t.F_s__1991000166; t.F_s__1991000166 = nil; s__1991000166__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000166__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000166__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000166__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000166__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000168__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, c__1927001037__auto____4, b__1991000168__6); var tmp2 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class = fncls__39d; tmp2 = fncls__39d } else { tmp2 = fncls__39 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000165); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000168__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000166__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000168__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000166__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_28); if jrt.J2g_Truth(and__1927000168__auto____6) {
		tmp4 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_29)) } else {
//line :224:1
			tmp4 = and__1927000168__auto____6 } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :221:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1991000165); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000166__3))) } else { s__1991000166__1 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000166__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :221:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000168 any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000168 = c__b__1991000168 }
//line :221:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A) Invoke_O__O(self any) any { { var i__1991000167__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000167__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_28); if jrt.J2g_Truth(and__1927000168__auto____4) {
		tmp2 = lang.IFn_Cast(A_arbace_j2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_29)) } else {
//line :224:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :221:1
	if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp4 any = t.F_b__1991000168; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2)); i__1991000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000167__1); continue L1 } else { i__1991000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000167__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_A{}; t.Ctor_O(p0); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A) Invoke_O_O__O(self, p__1991000182__1 any) any { var vec__1991000184__2 any = p__1991000182__1; var alias__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000184__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000184__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_90.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____5 any; var tmp3 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_New_O(alias__3); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp6 any = t.F_re; tmp2 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4))); return tmp1.Invoke_O__O(tmp2) }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A{}; t.Ctor_O(p0); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A) Invoke_O_O__O(self, s__1991000188__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_New_O_O_O(t.F_alias, s__1991000188__1, self); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A) Ctor_O_O_O(c__alias, c__s__1991000188, c__iter__1991000187 any) { t.F_alias = c__alias; t.F_s__1991000188 = c__s__1991000188; t.F_iter__1991000187 = c__iter__1991000187 }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A) Invoke_O__O(self any) any { { var s__1991000188__1 any; var t_ any = t.F_s__1991000188; t.F_s__1991000188 = nil; s__1991000188__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000188__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000188__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000188__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000188__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000190__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_New_O_O_I_O(t.F_alias, b__1991000190__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000187); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000190__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000188__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000190__6), nil) } } else { var vec__1991000198__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000188__3); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000198__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000198__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000187); _ = ___5; return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_98.GetRawRoot__O()).Invoke_O_O__O(t.F_alias, n__6), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000188__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A) Ctor_O_O_I_O(c__alias, c__b__1991000190 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_b__1991000190 = c__b__1991000190; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A) Invoke_O__O(self any) any { { var i__1991000189__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000189__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1991000194__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000189__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000194__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000194__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1991000190; _ = ___3; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_98.GetRawRoot__O()).Invoke_O_O__O(t.F_alias, n__4)); i__1991000189__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000189__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A) Ctor() {}
//line :233:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A) Invoke_O_O__O(self, s__1991000205__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_New_O_O(s__1991000205__1, self); var tmp2 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class = fncls__55d; tmp2 = fncls__55d } else { tmp2 = fncls__55 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :233:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A{}; t.Ctor_O_O(p0, p1); return t }
//line :233:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A) Ctor_O_O(c__s__1991000205, c__iter__1991000204 any) { t.F_s__1991000205 = c__s__1991000205; t.F_iter__1991000204 = c__iter__1991000204 }
//line :233:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A) Invoke_O__O(self any) any { { var s__1991000205__1 any; var t_ any = t.F_s__1991000205; t.F_s__1991000205 = nil; s__1991000205__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000205__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000205__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000205__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000205__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000207__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_New_O_I_O(b__1991000207__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class = fncls__51d; tmp2 = fncls__51d } else { tmp2 = fncls__51 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000204); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000207__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000205__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000207__6), nil) } } else { var part__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000205__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_embed_A_const_101; var tmp7 any = A_arbace_j2g_embed_A_const_102; var tmp8 any = lang.PersistentVector_EMPTY.Ref(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_embed_A_const_103; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_83.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_embed_A_const_100.GetRawRoot__O(); var tmp13 any = A_arbace_j2g_embed_A_const_104; var tmp14 any = A_arbace_j2g_embed_A_const_105; var tmp15 any; var iter__1927001039__auto____5 any; var tmp16 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_New(); var tmp17 *jrt.Class
															var fncls__54 /*line :233:1*/*jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class



	if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class = fncls__54d; tmp17 = fncls__54d } else { tmp17 = fncls__54 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); tmp15 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(part__4)
//line :233:1
	var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__1991000204); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, tmp15))), tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000205__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :233:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :233:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A) Ctor_O_I_O(c__b__1991000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000207 = c__b__1991000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :233:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A) Invoke_O__O(self any) any { { var i__1991000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var part__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000206__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1991000207; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_embed_A_const_101; var tmp6 any = A_arbace_j2g_embed_A_const_102; var tmp7 any = lang.PersistentVector_EMPTY.Ref(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_embed_A_const_103; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_83.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_A_const_100.GetRawRoot__O(); var tmp12 any = A_arbace_j2g_embed_A_const_104; var tmp13 any = A_arbace_j2g_embed_A_const_105; var tmp14 any; var iter__1927001039__auto____3 any; var tmp15 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_New(); var tmp16 *jrt.Class
																	var fncls__50 /*line :233:1*/*jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class



	if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class = fncls__50d; tmp16 = fncls__50d } else { tmp16 = fncls__50 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(part__2)
//line :233:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp12, tmp13, tmp14)))); i__1991000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A) Ctor() {}
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A) Invoke_O_O__O(self, s__1991000212__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_New_O_O(s__1991000212__1, self); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :237:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A{}; t.Ctor_O_O(p0, p1); return t }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A) Ctor_O_O(c__s__1991000212, c__iter__1991000211 any) { t.F_s__1991000212 = c__s__1991000212; t.F_iter__1991000211 = c__iter__1991000211 }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A) Invoke_O__O(self any) any { { var s__1991000212__1 any; var t_ any = t.F_s__1991000212; t.F_s__1991000212 = nil; s__1991000212__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000212__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000212__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000212__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000212__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000214__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_New_O_I_O(b__1991000214__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000214__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000212__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000214__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000212__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_embed_A_const_106; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_107, t__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000212__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :237:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A) Ctor_O_I_O(c__b__1991000214 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000214 = c__b__1991000214; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A) Invoke_O__O(self any) any { { var i__1991000213__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000213__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000213__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1991000214; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_embed_A_const_106; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_107, t__2))); i__1991000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000213__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :237:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A) Ctor() {}
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A) Invoke_O_O__O(self, s__1991000223__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_New_O_O(s__1991000223__1, self); var tmp2 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class = fncls__53d; tmp2 = fncls__53d } else { tmp2 = fncls__53 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :237:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A{}; t.Ctor_O_O(p0, p1); return t }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A) Ctor_O_O(c__s__1991000223, c__iter__1991000222 any) { t.F_s__1991000223 = c__s__1991000223; t.F_iter__1991000222 = c__iter__1991000222 }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A) Invoke_O__O(self any) any { { var s__1991000223__1 any; var t_ any = t.F_s__1991000223; t.F_s__1991000223 = nil; s__1991000223__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1991000223__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000223__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1991000223__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1991000223__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000225__6 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_New_O_I_O(b__1991000225__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1991000222); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000225__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1991000223__3))) } else { return lang.IFn_Cast(A_arbace_j2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1991000225__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1991000223__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_embed_A_const_106; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000222); return lang.IFn_Cast(A_arbace_j2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_107, t__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1991000223__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :237:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A) Ctor_O_I_O(c__b__1991000225 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000225 = c__b__1991000225; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :237:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A) Invoke_O__O(self any) any { { var i__1991000224__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000224__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000224__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1991000225; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_embed_A_const_106; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_107, t__2))); i__1991000224__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000224__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





















































































































































































































type A_arbace_j2g_embed_A struct{ jrt.Object }

var A_arbace_j2g_embed_A_const_pool *jrt.RefArray

var A_arbace_j2g_embed_A_const_0 *lang.Var

var A_arbace_j2g_embed_A_const_1 *lang.Var

var A_arbace_j2g_embed_A_const_2 any

var A_arbace_j2g_embed_A_const_3 any

var A_arbace_j2g_embed_A_const_4 any

var A_arbace_j2g_embed_A_const_5 any

var A_arbace_j2g_embed_A_const_6 any

var A_arbace_j2g_embed_A_const_7 *lang.Var

var A_arbace_j2g_embed_A_const_8 *lang.Var

var A_arbace_j2g_embed_A_const_9 *lang.Var

var A_arbace_j2g_embed_A_const_10 any

var A_arbace_j2g_embed_A_const_11 *lang.Var

var A_arbace_j2g_embed_A_const_12 *lang.Var

var A_arbace_j2g_embed_A_const_13 *lang.Var

var A_arbace_j2g_embed_A_const_14 *lang.Var

var A_arbace_j2g_embed_A_const_15 *lang.Var

var A_arbace_j2g_embed_A_const_16 *lang.Var

var A_arbace_j2g_embed_A_const_17 *lang.Var

var A_arbace_j2g_embed_A_const_18 *lang.Var

var A_arbace_j2g_embed_A_const_19 *lang.Var

var A_arbace_j2g_embed_A_const_20 *lang.Var

var A_arbace_j2g_embed_A_const_21 *lang.Var

var A_arbace_j2g_embed_A_const_22 *lang.Var

var A_arbace_j2g_embed_A_const_23 *lang.Var

var A_arbace_j2g_embed_A_const_24 *lang.Var

var A_arbace_j2g_embed_A_const_25 *lang.Var

var A_arbace_j2g_embed_A_const_26 *lang.Var

var A_arbace_j2g_embed_A_const_27 *lang.Var

var A_arbace_j2g_embed_A_const_28 *lang.Var

var A_arbace_j2g_embed_A_const_29 *lang.Var

var A_arbace_j2g_embed_A_const_30 *lang.Var

var A_arbace_j2g_embed_A_const_31 *lang.Var

var A_arbace_j2g_embed_A_const_32 *lang.Var

var A_arbace_j2g_embed_A_const_33 *lang.Var

var A_arbace_j2g_embed_A_const_34 *lang.Var

var A_arbace_j2g_embed_A_const_35 *lang.Var

var A_arbace_j2g_embed_A_const_36 *lang.Keyword

var A_arbace_j2g_embed_A_const_37 *lang.Var

var A_arbace_j2g_embed_A_const_38 any

var A_arbace_j2g_embed_A_const_39 any

var A_arbace_j2g_embed_A_const_40 *lang.Var

var A_arbace_j2g_embed_A_const_41 *lang.Var

var A_arbace_j2g_embed_A_const_42 *lang.Var

var A_arbace_j2g_embed_A_const_43 *lang.Var

var A_arbace_j2g_embed_A_const_44 *lang.Var

var A_arbace_j2g_embed_A_const_45 *lang.Var

var A_arbace_j2g_embed_A_const_46 *lang.Var

var A_arbace_j2g_embed_A_const_47 *lang.Var

var A_arbace_j2g_embed_A_const_48 any

var A_arbace_j2g_embed_A_const_49 *lang.Var

var A_arbace_j2g_embed_A_const_50 *lang.Keyword

var A_arbace_j2g_embed_A_const_51 *lang.Var

var A_arbace_j2g_embed_A_const_52 *lang.Var

var A_arbace_j2g_embed_A_const_53 *lang.Var

var A_arbace_j2g_embed_A_const_54 *lang.Var

var A_arbace_j2g_embed_A_const_55 *lang.Var

var A_arbace_j2g_embed_A_const_56 *lang.Var

var A_arbace_j2g_embed_A_const_57 *lang.Var

var A_arbace_j2g_embed_A_const_58 any

var A_arbace_j2g_embed_A_const_59 *lang.Var

var A_arbace_j2g_embed_A_const_60 *lang.Var

var A_arbace_j2g_embed_A_const_61 *lang.Var

var A_arbace_j2g_embed_A_const_62 *lang.Var

var A_arbace_j2g_embed_A_const_63 *lang.Var

var A_arbace_j2g_embed_A_const_64 *lang.Var

var A_arbace_j2g_embed_A_const_65 *lang.Var

var A_arbace_j2g_embed_A_const_66 *lang.Var

var A_arbace_j2g_embed_A_const_67 *lang.Var

var A_arbace_j2g_embed_A_const_68 *lang.Var

var A_arbace_j2g_embed_A_const_69 *lang.Var

var A_arbace_j2g_embed_A_const_70 *lang.Var

var A_arbace_j2g_embed_A_const_71 *lang.Var

var A_arbace_j2g_embed_A_const_72 *lang.Var

var A_arbace_j2g_embed_A_const_73 *lang.Var

var A_arbace_j2g_embed_A_const_74 *lang.Var

var A_arbace_j2g_embed_A_const_75 *lang.Var

var A_arbace_j2g_embed_A_const_76 *lang.Var

var A_arbace_j2g_embed_A_const_77 *lang.Var

var A_arbace_j2g_embed_A_const_78 any

var A_arbace_j2g_embed_A_const_79 any

var A_arbace_j2g_embed_A_const_80 *lang.Keyword

var A_arbace_j2g_embed_A_const_81 *lang.Var

var A_arbace_j2g_embed_A_const_82 *lang.Var

var A_arbace_j2g_embed_A_const_83 *lang.Var

var A_arbace_j2g_embed_A_const_84 *lang.Var

var A_arbace_j2g_embed_A_const_85 *lang.Var

var A_arbace_j2g_embed_A_const_86 *lang.Var

var A_arbace_j2g_embed_A_const_87 *lang.Var

var A_arbace_j2g_embed_A_const_88 *lang.Var

var A_arbace_j2g_embed_A_const_89 *lang.Var

var A_arbace_j2g_embed_A_const_90 *lang.Var

var A_arbace_j2g_embed_A_const_91 *lang.Var

var A_arbace_j2g_embed_A_const_92 *lang.Var

var A_arbace_j2g_embed_A_const_93 any

var A_arbace_j2g_embed_A_const_94 *lang.Var

var A_arbace_j2g_embed_A_const_95 *lang.Keyword

var A_arbace_j2g_embed_A_const_96 any

var A_arbace_j2g_embed_A_const_97 any

var A_arbace_j2g_embed_A_const_98 *lang.Var

var A_arbace_j2g_embed_A_const_99 *lang.Var

var A_arbace_j2g_embed_A_const_100 *lang.Var

var A_arbace_j2g_embed_A_const_101 any

var A_arbace_j2g_embed_A_const_102 any

var A_arbace_j2g_embed_A_const_103 any

var A_arbace_j2g_embed_A_const_104 any

var A_arbace_j2g_embed_A_const_105 any

var A_arbace_j2g_embed_A_const_106 any

var A_arbace_j2g_embed_A_const_107 any

var A_arbace_j2g_embed_A_const_108 any

var A_arbace_j2g_embed_A_const_109 *lang.Keyword

var A_arbace_j2g_embed_A_const_110 any

var A_arbace_j2g_embed_A_const_111 *lang.Var

var A_arbace_j2g_embed_A_const_112 any

var A_arbace_j2g_embed_A_init jrt.ClassInit

func A_arbace_j2g_embed_A_Init() { if !A_arbace_j2g_embed_A_init.Done() { A_arbace_j2g_embed_A_init.Run(A_arbace_j2g_embed_A_clinit) } }

func A_arbace_j2g_embed_A_clinit() { A_arbace_j2g_embed_A_clinit_p0(); A_arbace_j2g_embed_A_clinit_p1(); A_arbace_j2g_embed_A_clinit_p2(); A_arbace_j2g_embed_A_clinit_p3(); A_arbace_j2g_embed_A_clinit_p4(); A_arbace_j2g_embed_A_clinit_p5(); A_arbace_j2g_embed_A_clinit_p6(); A_arbace_j2g_embed_A_clinit_p7(); A_arbace_j2g_embed_A_clinit_p8(); A_arbace_j2g_embed_A_clinit_p9() }

func A_arbace_j2g_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 146); A_arbace_j2g_embed_A_const_0 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[33]); A_arbace_j2g_embed_A_const_1 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[34]); A_arbace_j2g_embed_A_const_2 = A_arbace_j2g_embed_A_const_pool.A[35]; A_arbace_j2g_embed_A_const_3 = A_arbace_j2g_embed_A_const_pool.A[36]; A_arbace_j2g_embed_A_const_4 = A_arbace_j2g_embed_A_const_pool.A[37]; A_arbace_j2g_embed_A_const_5 = A_arbace_j2g_embed_A_const_pool.A[38]; A_arbace_j2g_embed_A_const_6 = A_arbace_j2g_embed_A_const_pool.A[39]; A_arbace_j2g_embed_A_const_7 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[40]); A_arbace_j2g_embed_A_const_8 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[41]); A_arbace_j2g_embed_A_const_9 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[42]); A_arbace_j2g_embed_A_const_10 = A_arbace_j2g_embed_A_const_pool.A[43]; A_arbace_j2g_embed_A_const_11 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[44]) }

func A_arbace_j2g_embed_A_clinit_p1() { A_arbace_j2g_embed_A_const_12 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[45]); A_arbace_j2g_embed_A_const_13 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[46]); A_arbace_j2g_embed_A_const_14 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[47]); A_arbace_j2g_embed_A_const_15 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[48]); A_arbace_j2g_embed_A_const_16 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[49]); A_arbace_j2g_embed_A_const_17 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[50]); A_arbace_j2g_embed_A_const_18 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[51]); A_arbace_j2g_embed_A_const_19 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[52]); A_arbace_j2g_embed_A_const_20 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[53]); A_arbace_j2g_embed_A_const_21 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[54]); A_arbace_j2g_embed_A_const_22 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[55]); A_arbace_j2g_embed_A_const_23 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[56]) }

func A_arbace_j2g_embed_A_clinit_p2() { A_arbace_j2g_embed_A_const_24 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[57]); A_arbace_j2g_embed_A_const_25 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[58]); A_arbace_j2g_embed_A_const_26 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[59]); A_arbace_j2g_embed_A_const_27 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[60]); A_arbace_j2g_embed_A_const_28 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[61]); A_arbace_j2g_embed_A_const_29 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[62]); A_arbace_j2g_embed_A_const_30 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[63]); A_arbace_j2g_embed_A_const_31 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[64]); A_arbace_j2g_embed_A_const_32 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[65]); A_arbace_j2g_embed_A_const_33 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[66]); A_arbace_j2g_embed_A_const_34 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[67]); A_arbace_j2g_embed_A_const_35 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[68]) }

func A_arbace_j2g_embed_A_clinit_p3() { A_arbace_j2g_embed_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[69]); A_arbace_j2g_embed_A_const_37 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[70]); A_arbace_j2g_embed_A_const_38 = A_arbace_j2g_embed_A_const_pool.A[71]; A_arbace_j2g_embed_A_const_39 = A_arbace_j2g_embed_A_const_pool.A[72]; A_arbace_j2g_embed_A_const_40 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[73]); A_arbace_j2g_embed_A_const_41 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[74]); A_arbace_j2g_embed_A_const_42 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[75]); A_arbace_j2g_embed_A_const_43 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[76]); A_arbace_j2g_embed_A_const_44 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[77]); A_arbace_j2g_embed_A_const_45 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[78]); A_arbace_j2g_embed_A_const_46 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[79]); A_arbace_j2g_embed_A_const_47 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[80]) }

func A_arbace_j2g_embed_A_clinit_p4() { A_arbace_j2g_embed_A_const_48 = A_arbace_j2g_embed_A_const_pool.A[81]; A_arbace_j2g_embed_A_const_49 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[82]); A_arbace_j2g_embed_A_const_50 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[83]); A_arbace_j2g_embed_A_const_51 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[84]); A_arbace_j2g_embed_A_const_52 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[85]); A_arbace_j2g_embed_A_const_53 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[86]); A_arbace_j2g_embed_A_const_54 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[87]); A_arbace_j2g_embed_A_const_55 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[88]); A_arbace_j2g_embed_A_const_56 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[89]); A_arbace_j2g_embed_A_const_57 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[90]); A_arbace_j2g_embed_A_const_58 = A_arbace_j2g_embed_A_const_pool.A[91]; A_arbace_j2g_embed_A_const_59 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[92]) }

func A_arbace_j2g_embed_A_clinit_p5() { A_arbace_j2g_embed_A_const_60 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[93]); A_arbace_j2g_embed_A_const_61 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[94]); A_arbace_j2g_embed_A_const_62 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[95]); A_arbace_j2g_embed_A_const_63 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[96]); A_arbace_j2g_embed_A_const_64 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[97]); A_arbace_j2g_embed_A_const_65 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[98]); A_arbace_j2g_embed_A_const_66 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[99]); A_arbace_j2g_embed_A_const_67 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[100]); A_arbace_j2g_embed_A_const_68 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[101]); A_arbace_j2g_embed_A_const_69 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[102]); A_arbace_j2g_embed_A_const_70 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[103]); A_arbace_j2g_embed_A_const_71 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[104]) }

func A_arbace_j2g_embed_A_clinit_p6() { A_arbace_j2g_embed_A_const_72 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[105]); A_arbace_j2g_embed_A_const_73 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[106]); A_arbace_j2g_embed_A_const_74 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[107]); A_arbace_j2g_embed_A_const_75 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[108]); A_arbace_j2g_embed_A_const_76 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[109]); A_arbace_j2g_embed_A_const_77 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[110]); A_arbace_j2g_embed_A_const_78 = A_arbace_j2g_embed_A_const_pool.A[111]; A_arbace_j2g_embed_A_const_79 = A_arbace_j2g_embed_A_const_pool.A[112]; A_arbace_j2g_embed_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[113]); A_arbace_j2g_embed_A_const_81 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[114]); A_arbace_j2g_embed_A_const_82 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[115]); A_arbace_j2g_embed_A_const_83 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[116]) }

func A_arbace_j2g_embed_A_clinit_p7() { A_arbace_j2g_embed_A_const_84 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[117]); A_arbace_j2g_embed_A_const_85 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[118]); A_arbace_j2g_embed_A_const_86 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[119]); A_arbace_j2g_embed_A_const_87 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[120]); A_arbace_j2g_embed_A_const_88 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[121]); A_arbace_j2g_embed_A_const_89 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[122]); A_arbace_j2g_embed_A_const_90 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[123]); A_arbace_j2g_embed_A_const_91 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[124]); A_arbace_j2g_embed_A_const_92 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[125]); A_arbace_j2g_embed_A_const_93 = A_arbace_j2g_embed_A_const_pool.A[126]; A_arbace_j2g_embed_A_const_94 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[127]); A_arbace_j2g_embed_A_const_95 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[128]) }

func A_arbace_j2g_embed_A_clinit_p8() { A_arbace_j2g_embed_A_const_96 = A_arbace_j2g_embed_A_const_pool.A[129]; A_arbace_j2g_embed_A_const_97 = A_arbace_j2g_embed_A_const_pool.A[130]; A_arbace_j2g_embed_A_const_98 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[131]); A_arbace_j2g_embed_A_const_99 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[132]); A_arbace_j2g_embed_A_const_100 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[133]); A_arbace_j2g_embed_A_const_101 = A_arbace_j2g_embed_A_const_pool.A[134]; A_arbace_j2g_embed_A_const_102 = A_arbace_j2g_embed_A_const_pool.A[135]; A_arbace_j2g_embed_A_const_103 = A_arbace_j2g_embed_A_const_pool.A[136]; A_arbace_j2g_embed_A_const_104 = A_arbace_j2g_embed_A_const_pool.A[137]; A_arbace_j2g_embed_A_const_105 = A_arbace_j2g_embed_A_const_pool.A[138]; A_arbace_j2g_embed_A_const_106 = A_arbace_j2g_embed_A_const_pool.A[139]; A_arbace_j2g_embed_A_const_107 = A_arbace_j2g_embed_A_const_pool.A[140]; A_arbace_j2g_embed_A_const_108 = A_arbace_j2g_embed_A_const_pool.A[141]; A_arbace_j2g_embed_A_const_109 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[142]) }

func A_arbace_j2g_embed_A_clinit_p9() { A_arbace_j2g_embed_A_const_110 = A_arbace_j2g_embed_A_const_pool.A[143]; A_arbace_j2g_embed_A_const_111 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[144]); A_arbace_j2g_embed_A_const_112 = A_arbace_j2g_embed_A_const_pool.A[145] }

func A_arbace_j2g_embed_A_New() *A_arbace_j2g_embed_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_A) Ctor() {}

func (t *A_arbace_j2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_A_class }

func (t *A_arbace_j2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_A); return ok }

func A_arbace_j2g_embed_A_Cast(x any) *A_arbace_j2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_A_class)) }; return v }



type A_arbace_j2g_embed_class_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_class_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_fn__1991000103_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A struct{ j2g_header uint64; F_s__1991000089, F_iter__1991000088 any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A struct{ j2g_header uint64; F_b__1991000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_data_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A struct{ j2g_header uint64; F_base, F_s__1991000153, F_iter__1991000152 any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A struct{ j2g_header uint64; F_base any; F_size__1927001038__auto__ int32; F_b__1991000155, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000004_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000004_A_New() *A_arbace_j2g_embed_eval1991000004_A { t := &A_arbace_j2g_embed_eval1991000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000004_A_class }

func (t *A_arbace_j2g_embed_eval1991000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); return ok }

func A_arbace_j2g_embed_eval1991000004_A_Cast(x any) *A_arbace_j2g_embed_eval1991000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000004_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000008_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000008_A_New() *A_arbace_j2g_embed_eval1991000008_A { t := &A_arbace_j2g_embed_eval1991000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000008_A_class }

func (t *A_arbace_j2g_embed_eval1991000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); return ok }

func A_arbace_j2g_embed_eval1991000008_A_Cast(x any) *A_arbace_j2g_embed_eval1991000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000008_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000008_fn__1991000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_A struct{ j2g_header uint64; F_re any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A struct{ j2g_header uint64; F_alias, F_s__1991000188, F_iter__1991000187 any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A struct{ j2g_header uint64; F_alias, F_b__1991000190 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A struct{ j2g_header uint64; F_prog_dir any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A struct{ j2g_header uint64; F_prog_dir, F_s__1991000164, F_iter__1991000163 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A struct{ j2g_header uint64; F_alias, F_s__1991000166, F_iter__1991000165 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000168 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A struct{ j2g_header uint64; F_s__1991000205, F_iter__1991000204 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A struct{ j2g_header uint64; F_b__1991000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A struct{ j2g_header uint64; F_s__1991000212, F_iter__1991000211 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A struct{ j2g_header uint64; F_b__1991000214 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A struct{ j2g_header uint64; F_s__1991000223, F_iter__1991000222 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A struct{ j2g_header uint64; F_b__1991000225 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_names_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_walk__1991000059_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_embed_names_walk__1991000059_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_fn__1991000054_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class *jrt.Class



type A_arbace_j2g_embed_reify__1991000052_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_LispReader_Resolver() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_IObj() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_IMeta() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_reify__1991000052_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_reify__1991000052_A_class }

func (t *A_arbace_j2g_embed_reify__1991000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_reify__1991000052_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_reify__1991000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_reify__1991000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_reify__1991000052_A); return ok }

func A_arbace_j2g_embed_reify__1991000052_A_Cast(x any) *A_arbace_j2g_embed_reify__1991000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_reify__1991000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_reify__1991000052_A_class)) }; return v }



type A_arbace_j2g_embed_sources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A struct{ j2g_header uint64; F_p, F_pairs, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A struct{ j2g_header uint64; F_p, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A struct{ j2g_header uint64; F_base, F_s__1991000014, F_iter__1991000013 any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A struct{ j2g_header uint64; F_b__1991000016, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A struct{ j2g_header uint64; F_vdir any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A struct{ j2g_header uint64; F_vdir, F_s__1991000028, F_iter__1991000027 any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A struct{ j2g_header uint64; F_vdir, F_b__1991000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_elem__1991000117_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types, F_s__1991000134, F_iter__1991000133 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A struct{ j2g_header uint64; F_n, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A struct{ j2g_header uint64; F_in_world_QMARK_ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A struct{ j2g_header uint64; F_in_world_QMARK_, F_s__1991000136, F_iter__1991000135 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A struct{ j2g_header uint64; F_b__1991000138, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_A struct{ j2g_header uint64; F_elem, F_types any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A struct{ j2g_header uint64; F_s__1991000123, F_iter__1991000122 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A struct{ j2g_header uint64; F_b__1991000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class *jrt.Class
