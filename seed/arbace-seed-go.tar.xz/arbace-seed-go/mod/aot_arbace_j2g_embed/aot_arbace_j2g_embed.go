//line aot_arbace_j2g_embed.ae:1
package aot_arbace_j2g_embed

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_edge"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_New() *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed_A_const_1); lang.IFn_Cast(A_arbace_j2g_embed_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_3, A_arbace_j2g_embed_A_const_4, A_arbace_j2g_embed_A_const_5, A_arbace_j2g_embed_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_New() *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_eval1991000008_fn__1991000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_embed_eval1991000008_fn__1991000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_embed_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_embed_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_embed_A_const_10.GetRawRoot__O(), A_arbace_j2g_embed_A_const_11) }
















































func A_arbace_j2g_embed_sources_A_New() *A_arbace_j2g_embed_sources_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_j2g_embed_sources_A) Ctor() {}
//line :50:1
func (t *A_arbace_j2g_embed_sources_A) Invoke_O_O__O(self, root__0 any) any { var base__2 any; var root_22 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_22, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_24 lang.IFn; if


	linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = root__0; var arg_26 any = Lit_40; if linked_23 == nil { base__2 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { base__2 = linked_23.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = /*line :50:1*/A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_New_O(base__2); var tmp2 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class; if



	fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class = fncls__141d; tmp2 = fncls__141d } else { tmp2 = fncls__141 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_359 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = base__2; if linked_360 == nil { tmp4 = ifn_361.Invoke_O__O(arg_362) } else { tmp4 = linked_360.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_359, arg_362) }; files__3 = tmp3.Invoke_O__O(tmp4); var vdir__4 any; var root_142 any = /*line :50:1*/A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_142, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_144 lang.IFn; if








	linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = root__0; var arg_146 any = A_arbace_j2g_embed_A_const_30.GetRawRoot__O(); if linked_143 == nil { vdir__4 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { vdir__4 = linked_143.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) }; var variants__5 any; if
	jrt.NN(jrt.File_Cast(vdir__4)).IsDirectory__Z() { var iter__1927001039__auto____5 any; var tmp5 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_New_O(vdir__4); var tmp6 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class
		if fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class = fncls__235d; tmp6 = fncls__235d } else { tmp6 = fncls__235 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp8 any; var root_363 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = vdir__4; if linked_364 == nil { tmp8 = ifn_365.Invoke_O__O(arg_366) } else { tmp8 = linked_364.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_363, arg_366) }; variants__5 = tmp7.Invoke_O__O(tmp8) } else {
//line :60:1
			variants__5 = nil }; var root_236 any =



	A_arbace_j2g_embed_A_const_31.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var tmp9 any = A_arbace_j2g_embed_sources_fn__1991000038_A_New(); var tmp10 *jrt.Class; var fncls__345 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class; if fncls__345 == nil { var fncls__345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class = fncls__345d; tmp10 = fncls__345d } else { tmp10 = fncls__345 }; arg_239 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_240 any; var root_346 any = A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_348 lang.IFn; if





















	linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_45.GetRawRoot__O()).Invoke__O(); var arg_350 any = files__3; if linked_347 == nil { arg_240 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { arg_240 = linked_347.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) }; var arg_241 any; var root_354 any = /*line :64:1*/A_arbace_j2g_embed_A_const_46.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_356 lang.IFn; if






















	linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var arg_358 any = variants__5; if linked_355 == nil { arg_241 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { arg_241 = linked_355.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }; if /*line :64:1*/ linked_237 == nil { return ifn_238.Invoke_O_O_O__O(arg_239, arg_240, arg_241) } else { return linked_237.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_236, arg_239, arg_240, arg_241) } }
//line :54:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A{}; t.Ctor_O(p0); return t }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A) Invoke_O_O__O(self, s__1991000014__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_New_O_O_O(t.F_base, s__1991000014__1, self); var tmp2 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class = fncls__140d; tmp2 = fncls__140d } else { tmp2 = fncls__140 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :54:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A) Ctor_O_O_O(c__base, c__s__1991000014, c__iter__1991000013 any) { t.F_base = c__base; t.F_s__1991000014 = c__s__1991000014; t.F_iter__1991000013 = c__iter__1991000013 }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A) Invoke_O__O(self any) any { { var s__1991000014__1 any; var t_ any = t.F_s__1991000014; t.F_s__1991000014 = nil; s__1991000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_27 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = s__1991000014__1; if linked_28 == nil { temp__1927000414__auto____2 = ifn_29.Invoke_O__O(arg_30) } else { temp__1927000414__auto____2 = linked_28.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_27, arg_30) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_31 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__1991000014__3; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_35 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__1991000014__3; if linked_36 == nil { c__1927001037__auto____4 = ifn_37.Invoke_O__O(arg_38) } else { c__1927001037__auto____4 = linked_36.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_35, arg_38) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000016__6 any; var root_39 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_40 == nil { b__1991000016__6 = ifn_41.Invoke_O__O(arg_42) } else { b__1991000016__6 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_39, arg_42) }; var tmp2 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_New_O_O_I_O(b__1991000016__6, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_73 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var root_78 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = b__1991000016__6; if linked_79 == nil { arg_76 = ifn_80.Invoke_O__O(arg_81) } else { arg_76 = linked_79.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_78, arg_81) }; var arg_77 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000013); var tmp5 any; var root_82 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = s__1991000014__3; if linked_83 == nil { tmp5 = ifn_84.Invoke_O__O(arg_85) } else { tmp5 = linked_83.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_82, arg_85) }; arg_77 = tmp4.Invoke_O__O(tmp5); if linked_74 == nil { return ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { return linked_74.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) } } else { var root_86 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_91 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = b__1991000016__6; if linked_92 == nil { arg_89 = ifn_93.Invoke_O__O(arg_94) } else { arg_89 = linked_92.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_91, arg_94) }; var arg_90 any; if linked_87 == nil { return ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { return linked_87.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_86, arg_89, arg_90) } } } else { var f__4 any; var root_95 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = s__1991000014__3; if linked_96 == nil { f__4 = ifn_97.Invoke_O__O(arg_98) } else { f__4 = linked_96.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_95, arg_98) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var root_99 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_103 any = Lit_28; if linked_100 == nil { tmp6 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { tmp6 = linked_100.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_99, arg_102, arg_103) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :54:1
	if jrt.J2g_Truth(tmp6) { var rel__5 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp8 any; var root_104 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_106 lang.IFn

		if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_105 == nil { tmp8 = ifn_106.Invoke_O__O(arg_107) } else { tmp8 = linked_105.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_104, arg_107) }; rel__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :54:1
		var tmp9 any; var root_108 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_110 lang.IFn


		if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var tmp10 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_New_O(rel__5); var tmp11 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class = fncls__118d; tmp11 = fncls__118d } else { tmp11 = fncls__118 }; arg_111 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_112 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_109 == nil { tmp9 = ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { tmp9 = linked_109.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_108, arg_111, arg_112) }
//line :54:1
		if jrt.J2g_Truth(tmp9) { var root_119 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_123 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1991000013); var tmp13 any; var root_128 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = s__1991000014__3; if linked_129 == nil { tmp13 = ifn_130.Invoke_O__O(arg_131) } else { tmp13 = linked_129.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_128, arg_131) }; arg_123 = tmp12.Invoke_O__O(tmp13); if linked_120 == nil { return ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { return linked_120.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) } } else { var tmp14 any; var root_132 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__1991000014__3; if linked_133 == nil { tmp14 = ifn_134.Invoke_O__O(arg_135) } else { tmp14 = linked_133.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_132, arg_135) }; s__1991000014__1 = tmp14; continue L1 } } else { var tmp15 any; var root_136 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = s__1991000014__3; if linked_137 == nil { tmp15 = ifn_138.Invoke_O__O(arg_139) } else { tmp15 = linked_137.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_136, arg_139) }; s__1991000014__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :54:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A) Ctor_O_O_I_O(c__b__1991000016, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000016 = c__b__1991000016; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :54:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A) Invoke_O__O(self any) any { { var i__1991000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000015__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var root_43 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_47 any = Lit_28; if linked_44 == nil { tmp2 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp2 = linked_44.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_43, arg_46, arg_47) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :54:1
	if jrt.J2g_Truth(tmp2) { var rel__3 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp4 any; var root_48 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_50 lang.IFn

		if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_49 == nil { tmp4 = ifn_50.Invoke_O__O(arg_51) } else { tmp4 = linked_49.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_48, arg_51) }; rel__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :54:1
		var tmp5 any; var root_52 any = A_arbace_j2g_embed_A_const_19.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_54 lang.IFn


		if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any; var tmp6 any = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_New_O(rel__3); var tmp7 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class = fncls__62d; tmp7 = fncls__62d } else { tmp7 = fncls__62 }; arg_55 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_56 any = A_arbace_j2g_embed_A_const_21.GetRawRoot__O(); if linked_53 == nil { tmp5 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { tmp5 = linked_53.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }
//line :54:1
		if jrt.J2g_Truth(tmp5) { var root_63 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = t.F_b__1991000016; var arg_67 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_64 == nil { ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { linked_64.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } else { i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } } else { i__1991000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000015__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A{}; t.Ctor_O(p0); return t }
//line :57:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :57:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_57 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = t.F_rel; var arg_61 any = p1__1991000012_SHARP___1; if linked_58 == nil { return ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { return linked_58.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } }
//line :57:1
func A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A{}; t.Ctor_O(p0); return t }
//line :57:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :57:1
func (t *A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A) Invoke_O_O__O(self, p1__1991000012_SHARP___1 any) any { var root_113 any = A_arbace_j2g_embed_A_const_20.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = t.F_rel; var arg_117 any = p1__1991000012_SHARP___1; if linked_114 == nil { return ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { return linked_114.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_113, arg_116, arg_117) } }



func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_New_O(p0 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A) Invoke_O_O__O(self, s__1991000028__1 any) any { var tmp1 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_New_O_O_O(t.F_vdir, s__1991000028__1, self); var tmp2 *jrt.Class; var fncls__234 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class; if fncls__234 == nil { var fncls__234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class = fncls__234d; tmp2 = fncls__234d } else { tmp2 = fncls__234 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :61:1
func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A) Ctor_O_O_O(c__vdir, c__s__1991000028, c__iter__1991000027 any) { t.F_vdir = c__vdir; t.F_s__1991000028 = c__s__1991000028; t.F_iter__1991000027 = c__iter__1991000027 }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A) Invoke_O__O(self any) any { { var s__1991000028__1 any; var t_ any = t.F_s__1991000028; t.F_s__1991000028 = nil; s__1991000028__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_147 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = s__1991000028__1; if linked_148 == nil { temp__1927000414__auto____2 = ifn_149.Invoke_O__O(arg_150) } else { temp__1927000414__auto____2 = linked_148.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_147, arg_150) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000028__3 any = temp__1927000414__auto____2; var tmp1 any; var root_151 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__1991000028__3; if linked_152 == nil { tmp1 = ifn_153.Invoke_O__O(arg_154) } else { tmp1 = linked_152.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_155 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__1991000028__3; if linked_156 == nil { c__1927001037__auto____4 = ifn_157.Invoke_O__O(arg_158) } else { c__1927001037__auto____4 = linked_156.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_155, arg_158) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000030__6 any; var root_159 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_160 == nil { b__1991000030__6 = ifn_161.Invoke_O__O(arg_162) } else { b__1991000030__6 = linked_160.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_159, arg_162) }; var tmp2 any = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_New_O_O_I_O(t.F_vdir, b__1991000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class = fncls__181d; tmp3 = fncls__181d } else { tmp3 = fncls__181 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_182 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_187 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = b__1991000030__6; if linked_188 == nil { arg_185 = ifn_189.Invoke_O__O(arg_190) } else { arg_185 = linked_188.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_187, arg_190) }; var arg_186 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000027); var tmp5 any; var root_191 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = s__1991000028__3; if linked_192 == nil { tmp5 = ifn_193.Invoke_O__O(arg_194) } else { tmp5 = linked_192.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_191, arg_194) }; arg_186 = tmp4.Invoke_O__O(tmp5); if linked_183 == nil { return ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { return linked_183.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) } } else { var root_195 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_200 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = b__1991000030__6; if linked_201 == nil { arg_198 = ifn_202.Invoke_O__O(arg_203) } else { arg_198 = linked_201.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_200, arg_203) }; var arg_199 any; if linked_196 == nil { return ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { return linked_196.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) } } } else { var f__4 any; var root_204 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = s__1991000028__3; if linked_205 == nil { f__4 = ifn_206.Invoke_O__O(arg_207) } else { f__4 = linked_205.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_204, arg_207) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var root_208 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_212 any = Lit_28; if linked_209 == nil { tmp6 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { tmp6 = linked_209.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_208, arg_211, arg_212) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :61:1
	if jrt.J2g_Truth(tmp6) { var root_213 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any; var tmp7 any; var root_218 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_220 lang.IFn

		if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_219 == nil { tmp7 = ifn_220.Invoke_O__O(arg_221) } else { tmp7 = linked_219.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_218, arg_221) }
//line :61:1
		arg_216 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)); var arg_217 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000027); var tmp9 any; var root_226 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = s__1991000028__3; if linked_227 == nil { tmp9 = ifn_228.Invoke_O__O(arg_229) } else { tmp9 = linked_227.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_226, arg_229) }; arg_217 = tmp8.Invoke_O__O(tmp9); if linked_214 == nil { return ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { return linked_214.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) } } else { var tmp10 any; var root_230 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = s__1991000028__3; if linked_231 == nil { tmp10 = ifn_232.Invoke_O__O(arg_233) } else { tmp10 = linked_231.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_230, arg_233) }; s__1991000028__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :61:1
func A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A) Ctor_O_O_I_O(c__vdir, c__b__1991000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_vdir = c__vdir; t.F_b__1991000030 = c__b__1991000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :61:1
func (t *A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A) Invoke_O__O(self any) any { { var i__1991000029__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000029__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var root_163 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_167 any = Lit_28; if linked_164 == nil { tmp2 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { tmp2 = linked_164.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_163, arg_166, arg_167) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :61:1
	if jrt.J2g_Truth(tmp2) { var root_168 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = t.F_b__1991000030; var arg_172 any; var tmp3 any; var root_173 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_175 lang.IFn

		if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_174 == nil { tmp3 = ifn_175.Invoke_O__O(arg_176) } else { tmp3 = linked_174.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_173, arg_176) }
//line :61:1
		arg_172 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2)); if linked_169 == nil { ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { linked_169.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) }; i__1991000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000029__1); continue L1 } else { i__1991000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000029__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_embed_sources_fn__1991000038_A_New() *A_arbace_j2g_embed_sources_fn__1991000038_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_A) Ctor() {}
//line :64:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_A) Invoke_O_O_O__O(self, m__1, p__1991000037__2 any) any { var vec__1991000039__3 any = p__1991000037__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000039__3, lang.RT_IntCast_J__I_NoInit(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000039__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_242 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_244 lang.IFn; if


	linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = rel__4; var arg_246 any = Lit_44; if linked_243 == nil { tmp1 = ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { tmp1 = linked_243.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_242, arg_245, arg_246) }; if /*line :65:1*/ jrt.J2g_Truth(tmp1) { var p__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28); var tmp3 any; var root_247 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_249 lang.IFn


		if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = rel__4; var arg_251 any = A_arbace_j2g_embed_A_const_33; var arg_252 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_44)))).Ref(); if linked_248 == nil { tmp3 = ifn_249.Invoke_O_O_O__O(arg_250, arg_251, arg_252) } else { tmp3 = linked_248.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_247, arg_250, arg_251, arg_252) }; p__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
//line :65:1
		var pairs__7 any; var root_253 any = A_arbace_j2g_embed_A_const_34.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_255 lang.IFn



		if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = A_arbace_j2g_embed_A_const_35; var arg_257 any; var root_258 any = A_arbace_j2g_embed_A_const_36.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = text__5; if linked_259 == nil { arg_257 = ifn_260.Invoke_O__O(arg_261) } else { arg_257 = linked_259.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_258, arg_261) }; if linked_254 == nil { pairs__7 = ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { pairs__7 = linked_254.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) }
		var tmp4 any; var root_325 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = m__1; var arg_329 any = p__6; if linked_326 == nil { tmp4 = ifn_327.Invoke_O_O__O(arg_328, arg_329) } else { tmp4 = linked_326.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_325, arg_328, arg_329) }; if jrt.J2g_Truth(tmp4) { } else { var tmp5 any; var root_330 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_332 lang.IFn
			if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(); var arg_334 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_331 == nil { tmp5 = ifn_332.Invoke_O_O__O(arg_333, arg_334) } else { tmp5 = linked_331.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_330, arg_333, arg_334) }
//line :70:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5)))
		}
		var root_262 any = A_arbace_j2g_embed_A_const_37.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = m__1; var arg_266 any = p__6; var arg_267 any; var tmp6 any = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp7 *jrt.Class; var fncls__300 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class; if fncls__300 == nil { var fncls__300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class = fncls__300d; tmp7 = fncls__300d } else { tmp7 = fncls__300 }; arg_267 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_263 == nil { return ifn_264.Invoke_O_O_O__O(arg_265, arg_266, arg_267) } else { return linked_263.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_262, arg_265, arg_266, arg_267) } } else {
//line :65:1
			var tmp8 any; var root_301 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_303 lang.IFn














			if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = rel__4; var arg_305 any = Lit_49; if linked_302 == nil { tmp8 = ifn_303.Invoke_O_O__O(arg_304, arg_305) } else { tmp8 = linked_302.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_301, arg_304, arg_305) }
//line :65:1
			if jrt.J2g_Truth(tmp8) { var p__6_2 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28); var tmp10 any; var root_306 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_308 lang.IFn















				if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = rel__4; var arg_310 any = A_arbace_j2g_embed_A_const_33; var arg_311 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rel__4)), int64(lang.RT_Count_O__I_NoInit(Lit_49)))).Ref(); if linked_307 == nil { tmp10 = ifn_308.Invoke_O_O_O__O(arg_309, arg_310, arg_311) } else { tmp10 = linked_307.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_306, arg_309, arg_310, arg_311) }; p__6_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil)).Ref()
				var tmp11 any; var root_335 any = A_arbace_j2g_embed_A_const_43.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = m__1; var arg_339 any = p__6_2; if linked_336 == nil { tmp11 = ifn_337.Invoke_O_O__O(arg_338, arg_339) } else { tmp11 = linked_336.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_335, arg_338, arg_339) }; if jrt.J2g_Truth(tmp11) { } else { var tmp12 any; var root_340 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_342 lang.IFn
					if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(); var arg_344 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_341 == nil { tmp12 = ifn_342.Invoke_O_O__O(arg_343, arg_344) } else { tmp12 = linked_341.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_340, arg_343, arg_344) }
//line :82:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp12)))
				}
				var root_312 any = A_arbace_j2g_embed_A_const_37.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = m__1; var arg_316 any = p__6_2; var arg_317 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_318 any = text__5; if linked_313 == nil { return ifn_314.Invoke_O_O_O_O__O(arg_315, arg_316, arg_317, arg_318) } else { return linked_313.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_312, arg_315, arg_316, arg_317, arg_318) } } else {
//line :65:1
					if A_arbace_j2g_embed_A_const_41 != nil {



















						var root_319 any = A_arbace_j2g_embed_A_const_42.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = m__1; var arg_323 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(); var arg_324 any = text__5; if linked_320 == nil { return ifn_321.Invoke_O_O_O__O(arg_322, arg_323, arg_324) } else { return linked_320.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_319, arg_322, arg_323, arg_324) } } else {
//line :65:1
							return nil } } } }






func A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :72:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :72:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A) Invoke_O_O__O(self, src__1 any) any {
	var root_268 any = A_arbace_j2g_embed_A_const_31.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any; var tmp1 any = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_New_O_O(t.F_p, t.F_rel); var tmp2 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class = fncls__299d; tmp2 = fncls__299d } else { tmp2 = fncls__299 }; arg_271 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_272 any = src__1; var arg_273 any = t.F_pairs; if linked_269 == nil { return ifn_270.Invoke_O_O_O__O(arg_271, arg_272, arg_273) } else { return linked_269.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_268, arg_271, arg_272, arg_273) } }
//line :73:1
func A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :73:1
func (t *A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A) Invoke_O_O_O__O(self, src__1, p__1991000043__2 any) any { var vec__1991000045__3 any = p__1991000043__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000045__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000045__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var root_285 any = A_arbace_j2g_embed_A_const_38.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); var arg_289 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref(); if linked_286 == nil { tmp1 = ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { tmp1 = linked_286.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_285, arg_288, arg_289) } }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_290 any = A_arbace_j2g_embed_A_const_39.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_292 lang.IFn
		if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var tmp3 any = t.F_rel; var arg_293 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_51, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, lang.IFn_Cast(A_arbace_j2g_embed_A_const_40.GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(); var arg_294 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_291 == nil { tmp2 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { tmp2 = linked_291.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }
//line :75:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp4 /*line :78:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp5 any; var root_274 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = src__1; var arg_278 any = A_arbace_j2g_embed_A_const_33; var arg_279 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__6).Ref(); if linked_275 == nil { tmp5 = ifn_276.Invoke_O_O_O__O(arg_277, arg_278, arg_279) } else { tmp5 = linked_275.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_274, arg_277, arg_278, arg_279) }; var tmp6 any = tmp5; var tmp7 any; var root_280 any = A_arbace_j2g_embed_A_const_32.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = src__1; var arg_284 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__6), int64(lang.RT_Count_O__I_NoInit(old__4)))).Ref(); if linked_281 == nil { tmp7 = ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { tmp7 = linked_281.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp6, new__5, tmp7)).Ref() }















func A_arbace_j2g_embed_reify__1991000052_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_j2g_embed_reify__1991000052_A { t := &A_arbace_j2g_embed_reify__1991000052_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :94:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :94:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :94:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :94:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :94:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_j2g_embed_A_Init(); tmp1 = A_arbace_j2g_embed_A_const_48; return lang.Symbol_Cast(tmp1) }
//line :94:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :94:1
func (t *A_arbace_j2g_embed_reify__1991000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_j2g_embed_reify__1991000052_A_New_IPersistentMap(m) }





func A_arbace_j2g_embed_read_all_A_New() *A_arbace_j2g_embed_read_all_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_embed_read_all_A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var root_375 any = A_arbace_j2g_embed_A_const_53.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_377 lang.IFn; if

	linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_embed_A_const_55; var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any = A_arbace_j2g_embed_A_const_56; var tmp5 any = A_arbace_j2g_embed_A_const_57.GetRawRoot__O(); var tmp6 any = A_arbace_j2g_embed_A_const_58; var tmp7 any = A_arbace_j2g_embed_read_all_fn__1991000054_A_New(); var tmp8 *jrt.Class; var fncls__388 *jrt.Class = A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class; if

	fncls__388 == nil { var fncls__388d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class = fncls__388d; tmp8 = fncls__388d } else { tmp8 = fncls__388 }; arg_378 = /*line :102:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); if linked_376 == nil { ifn_377.Invoke_O__O(arg_378) } else { linked_376.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_375, arg_378) }; var tmp9 any; tmp11 := /*line :100:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any; var root_367 any = A_arbace_j2g_embed_A_const_49.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_369 lang.IFn





		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = A_arbace_j2g_embed_A_const_50; var arg_371 any = r__2; if linked_368 == nil { f__6 = ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { f__6 = linked_368.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) }
		if lang.Util_Equiv_O_O__Z_NoInit(f__6, A_arbace_j2g_embed_A_const_51) { tmp9 = acc__5 } else { var tmp10 any; var root_389 any = A_arbace_j2g_embed_A_const_10.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = acc__5; var arg_393 any = f__6; if linked_390 == nil { tmp10 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { tmp10 = linked_390.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }; acc__5 = tmp10; continue L1 }
//line :100:1
		break L1 } }; return nil }(); var root_372 any = A_arbace_j2g_embed_A_const_52.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_374 lang.IFn; if

	linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; if linked_373 == nil { ifn_374.Invoke__O() } else { linked_373.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_372) }; if /*line :100:1*/ tmp11 != nil { panic(tmp11) }; return tmp9 }



func A_arbace_j2g_embed_read_all_fn__1991000054_A_New() *A_arbace_j2g_embed_read_all_fn__1991000054_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_read_all_fn__1991000054_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000054_A) Ctor() {}
//line :104:1
func (t *A_arbace_j2g_embed_read_all_fn__1991000054_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_j2g_embed_class_like_QMARK__A_New() *A_arbace_j2g_embed_class_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_1); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)), int64(lang.RT_Count_O__I_NoInit(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

func A_arbace_j2g_embed_package_like_QMARK__A_New() *A_arbace_j2g_embed_package_like_QMARK__A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_1))); if and__1927000168__auto____2 {
											var root_394 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any; var root_398 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = s__0; if linked_399 == nil { arg_397 = ifn_400.Invoke_O__O(arg_401) } else { arg_397 = linked_399.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_398, arg_401) }; if linked_395 == nil { return ifn_396.Invoke_O__O(arg_397) } else { return linked_395.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_394, arg_397) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_embed_names_A_New() *A_arbace_j2g_embed_names_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_embed_names_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any; var root_402 any = A_arbace_j2g_embed_A_const_61.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_404 lang.IFn; if



	linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_403 == nil { acc__2 = ifn_404.Invoke_O__O(arg_405) } else { acc__2 = linked_403.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_402, arg_405) }; var walk__3 any; var tmp1 any = /*line :116:1*/A_arbace_j2g_embed_names_walk__1991000059_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__647 *jrt.Class = A_arbace_j2g_embed_names_walk__1991000059_A_fn_class; if




	fncls__647 == nil { var fncls__647d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_embed_names_walk__1991000059_A_fn_class = fncls__647d; tmp2 = fncls__647d } else { tmp2 = fncls__647 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var seq_1991000083__4 any; var root_652 any = /*line :116:1*/A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_654 lang.IFn; if




















	linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any; var root_656 any = A_arbace_j2g_embed_A_const_74.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_j2g_embed_read_all_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = text__0; if linked_657 == nil { arg_655 = ifn_658.Invoke_O__O(arg_659) } else { arg_655 = linked_657.(*A_arbace_j2g_embed_read_all_A).Invoke_O_O__O(root_656, arg_659) }; if linked_653 == nil { seq_1991000083__4 = ifn_654.Invoke_O__O(arg_655) } else { seq_1991000083__4 = linked_653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_652, arg_655) }; var chunk_1991000084__5 any; var count_1991000085__6 int64 = 0; var i_1991000086__7 int64 = 0; L1:
//line :116:1
	for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000086__7, count_1991000085__6) { var f__8 any = lang.Indexed_Cast(chunk_1991000084__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000086__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000086__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_660 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = seq_1991000083__4; if linked_661 == nil { temp__1927000414__auto____8 = ifn_662.Invoke_O__O(arg_663) } else { temp__1927000414__auto____8 = linked_661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_660, arg_663) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1991000083__9 any = temp__1927000414__auto____8; var tmp3 any; var root_664 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = seq_1991000083__9; if linked_665 == nil { tmp3 = ifn_666.Invoke_O__O(arg_667) } else { tmp3 = linked_665.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_664, arg_667) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_668 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = seq_1991000083__9; if linked_669 == nil { c__1927000678__auto____10 = ifn_670.Invoke_O__O(arg_671) } else { c__1927000678__auto____10 = linked_669.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_668, arg_671) }; var tmp4 any; var root_676 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = seq_1991000083__9; if linked_677 == nil { tmp4 = ifn_678.Invoke_O__O(arg_679) } else { tmp4 = linked_677.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_676, arg_679) }; seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_672 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = seq_1991000083__9; if linked_673 == nil { f__10 = ifn_674.Invoke_O__O(arg_675) } else { f__10 = linked_673.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_672, arg_675) }; lang.IFn_Cast(walk__3).Invoke_O__O(f__10); var tmp5 any; var root_680 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = seq_1991000083__9; if linked_681 == nil { tmp5 = ifn_682.Invoke_O__O(arg_683) } else { tmp5 = linked_681.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_680, arg_683) }; seq_1991000083__4, chunk_1991000084__5, count_1991000085__6, i_1991000086__7 = tmp5, nil, 0, 0; continue L1 } } }
//line :116:1
		break L1 }; var root_648 any =





















	A_arbace_j2g_embed_A_const_73.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = acc__2; if linked_649 == nil { return ifn_650.Invoke_O__O(arg_651) } else { return linked_649.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_648, arg_651) } }
//line :121:1
func A_arbace_j2g_embed_names_walk__1991000059_A_New_O(p0 any) *A_arbace_j2g_embed_names_walk__1991000059_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_names_walk__1991000059_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_j2g_embed_names_walk__1991000059_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :121:1
func (t *A_arbace_j2g_embed_names_walk__1991000059_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__1)
											if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											var tmp1 any; var root_406 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_408 lang.IFn
											if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = x__1; if linked_407 == nil { tmp1 = ifn_408.Invoke_O__O(arg_409) } else { tmp1 = linked_407.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_406, arg_409) }
//line :123:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any; var root_507 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = x__1; if linked_508 == nil { tmp3 = ifn_509.Invoke_O__O(arg_510) } else { tmp3 = linked_508.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_507, arg_510) }; and__1927000168__auto____2 = lang.Util_Identical_O_O__Z_NoInit(tmp3, nil); if and__1927000168__auto____2 { var root_511 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_515 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = x__1; if linked_516 == nil { arg_514 = ifn_517.Invoke_O__O(arg_518) } else { arg_514 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; if linked_512 == nil { tmp2 = ifn_513.Invoke_O__O(arg_514) } else { tmp2 = linked_512.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_511, arg_514) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) {
			var root_519 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = t.F_acc; var arg_523 any; var root_524 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = x__1; if linked_525 == nil { arg_523 = ifn_526.Invoke_O__O(arg_527) } else { arg_523 = linked_525.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_524, arg_527) }; if linked_520 == nil { ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { linked_520.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_519, arg_522, arg_523) } }
		var tmp4 any; var and__1927000168__auto____2_2 any; var root_410 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = x__1; if linked_411 == nil { and__1927000168__auto____2_2 = ifn_412.Invoke_O__O(arg_413) } else { and__1927000168__auto____2_2 = linked_411.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_410, arg_413) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var root_414 any = A_arbace_j2g_embed_A_const_60.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, A_arbace_j2g_embed_class_like_QMARK__A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any; var root_418 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = x__1; if linked_419 == nil { arg_417 = ifn_420.Invoke_O__O(arg_421) } else { arg_417 = linked_419.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_418, arg_421) }; if linked_415 == nil { tmp4 = ifn_416.Invoke_O__O(arg_417) } else { tmp4 = linked_415.(*A_arbace_j2g_embed_class_like_QMARK__A).Invoke_O_O__O(root_414, arg_417) } } else { tmp4 = and__1927000168__auto____2_2 }; if jrt.J2g_Truth(tmp4) {
			var root_422 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = t.F_acc; var arg_426 any; var root_427 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = x__1; if linked_428 == nil { arg_426 = ifn_429.Invoke_O__O(arg_430) } else { arg_426 = linked_428.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_427, arg_430) }; if linked_423 == nil { return ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { return linked_423.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_422, arg_425, arg_426) } } else {
//line :127:1
				return nil } } else {
//line :123:1
					var tmp5 any; var or__1927000174__auto____2 any; var root_431 any = A_arbace_j2g_embed_A_const_65.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_433 lang.IFn





					if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = x__1; if linked_432 == nil { or__1927000174__auto____2 = ifn_433.Invoke_O__O(arg_434) } else { or__1927000174__auto____2 = linked_432.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_431, arg_434) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { var root_435 any = A_arbace_j2g_embed_A_const_66.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = x__1; if linked_436 == nil { tmp5 = ifn_437.Invoke_O__O(arg_438) } else { tmp5 = linked_436.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_435, arg_438) } }
//line :123:1
					if jrt.J2g_Truth(tmp5) {






						var tmp6 any; var and__1927000168__auto____2_3 any; var root_528 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var root_532 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = x__1; if linked_533 == nil { arg_531 = ifn_534.Invoke_O__O(arg_535) } else { arg_531 = linked_533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_532, arg_535) }; if linked_529 == nil { and__1927000168__auto____2_3 = ifn_530.Invoke_O__O(arg_531) } else { and__1927000168__auto____2_3 = linked_529.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_528, arg_531) }; if jrt.J2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool; var tmp7 any; var root_536 any = A_arbace_j2g_embed_A_const_63.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any; var root_540 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = x__1; if linked_541 == nil { arg_539 = ifn_542.Invoke_O__O(arg_543) } else { arg_539 = linked_541.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_540, arg_543) }; if linked_537 == nil { tmp7 = ifn_538.Invoke_O__O(arg_539) } else { tmp7 = linked_537.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_536, arg_539) }; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z_NoInit(tmp7, nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_544 any = A_arbace_j2g_embed_A_const_70.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_j2g_embed_package_like_QMARK__A_fn_class); var ifn_546 lang.IFn
							if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any; var root_548 any = A_arbace_j2g_embed_A_const_69.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var root_552 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = x__1; if linked_553 == nil { arg_551 = ifn_554.Invoke_O__O(arg_555) } else { arg_551 = linked_553.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_552, arg_555) }; if linked_549 == nil { arg_547 = ifn_550.Invoke_O__O(arg_551) } else { arg_547 = linked_549.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_548, arg_551) }; if linked_545 == nil { and__1927000168__auto____4 = ifn_546.Invoke_O__O(arg_547) } else { and__1927000168__auto____4 = linked_545.(*A_arbace_j2g_embed_package_like_QMARK__A).Invoke_O_O__O(root_544, arg_547) }
//line :130:1
							if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_556 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_558 lang.IFn
								if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any; var root_560 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = x__1; if linked_561 == nil { arg_559 = ifn_562.Invoke_O__O(arg_563) } else { arg_559 = linked_561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_560, arg_563) }; if linked_557 == nil { and__1927000168__auto____5 = ifn_558.Invoke_O__O(arg_559) } else { and__1927000168__auto____5 = linked_557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_556, arg_559) }
//line :130:1
								if jrt.J2g_Truth(and__1927000168__auto____5) {

									var root_564 any = A_arbace_j2g_embed_A_const_71.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = A_arbace_j2g_embed_A_const_62.GetRawRoot__O(); var arg_568 any; var root_569 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = x__1; if linked_570 == nil { arg_568 = ifn_571.Invoke_O__O(arg_572) } else { arg_568 = linked_570.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_569, arg_572) }; if linked_565 == nil { tmp6 = ifn_566.Invoke_O_O__O(arg_567, arg_568) } else { tmp6 = linked_565.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_564, arg_567, arg_568) } } else {
//line :130:1
										tmp6 = and__1927000168__auto____5 } } else { tmp6 = and__1927000168__auto____4 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp6 = and__1927000168__auto____2_3 }; if jrt.J2g_Truth(tmp6) { var seq_1991000060__2 any; var root_573 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_575 lang.IFn


											if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var root_577 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = x__1; if linked_578 == nil { arg_576 = ifn_579.Invoke_O__O(arg_580) } else { arg_576 = linked_578.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_577, arg_580) }; if linked_574 == nil { seq_1991000060__2 = ifn_575.Invoke_O__O(arg_576) } else { seq_1991000060__2 = linked_574.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_573, arg_576) }
//line :130:1
											var chunk_1991000061__3 any; var count_1991000062__4 int64 = 0; var i_1991000063__5 int64 = 0; L1: for {


												if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000063__5, count_1991000062__4) { var c__6 any = lang.Indexed_Cast(chunk_1991000061__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000063__5)); var root_597 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = t.F_acc; var arg_601 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp9 any; var root_602 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = x__1; if linked_603 == nil { tmp9 = ifn_604.Invoke_O__O(arg_605) } else { tmp9 = linked_603.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_602, arg_605) }; arg_601 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, c__6)).Ref(); if linked_598 == nil { ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { linked_598.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }; seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000063__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_581 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = seq_1991000060__2; if linked_582 == nil { temp__1927000414__auto____6 = ifn_583.Invoke_O__O(arg_584) } else { temp__1927000414__auto____6 = linked_582.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1991000060__7 any = temp__1927000414__auto____6; var tmp10 any; var root_585 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = seq_1991000060__7; if linked_586 == nil { tmp10 = ifn_587.Invoke_O__O(arg_588) } else { tmp10 = linked_586.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____8 any; var root_589 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = seq_1991000060__7; if linked_590 == nil { c__1927000678__auto____8 = ifn_591.Invoke_O__O(arg_592) } else { c__1927000678__auto____8 = linked_590.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_589, arg_592) }; var tmp11 any; var root_606 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1991000060__7; if linked_607 == nil { tmp11 = ifn_608.Invoke_O__O(arg_609) } else { tmp11 = linked_607.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_606, arg_609) }; seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = tmp11, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_593 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = seq_1991000060__7; if linked_594 == nil { c__8 = ifn_595.Invoke_O__O(arg_596) } else { c__8 = linked_594.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_593, arg_596) }; var root_610 any = A_arbace_j2g_embed_A_const_64.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = t.F_acc; var arg_614 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil); var tmp13 any; var root_615 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = x__1; if linked_616 == nil { tmp13 = ifn_617.Invoke_O__O(arg_618) } else { tmp13 = linked_616.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_615, arg_618) }; arg_614 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, c__8)).Ref(); if linked_611 == nil { ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { linked_611.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }; var tmp14 any; var root_619 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = seq_1991000060__7; if linked_620 == nil { tmp14 = ifn_621.Invoke_O__O(arg_622) } else { tmp14 = linked_620.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_619, arg_622) }; seq_1991000060__2, chunk_1991000061__3, count_1991000062__4, i_1991000063__5 = tmp14, nil, 0, 0; continue L1 } } }
//line :130:1
												break L1 } }
//line :123:1
						var seq_1991000064__2 any; var root_439 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn










						if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = x__1; if linked_440 == nil { seq_1991000064__2 = ifn_441.Invoke_O__O(arg_442) } else { seq_1991000064__2 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }
//line :123:1
						var chunk_1991000065__3 any; var count_1991000066__4 int64 = 0; var i_1991000067__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000067__5, count_1991000066__4) { var y__6 any = lang.Indexed_Cast(chunk_1991000065__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000067__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000067__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_443 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_1991000064__2; if linked_444 == nil { temp__1927000414__auto____6_2 = ifn_445.Invoke_O__O(arg_446) } else { temp__1927000414__auto____6_2 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1991000064__7 any = temp__1927000414__auto____6_2; var tmp15 any; var root_447 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_1991000064__7; if linked_448 == nil { tmp15 = ifn_449.Invoke_O__O(arg_450) } else { tmp15 = linked_448.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_447, arg_450) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____8_2 any; var root_451 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = seq_1991000064__7; if linked_452 == nil { c__1927000678__auto____8_2 = ifn_453.Invoke_O__O(arg_454) } else { c__1927000678__auto____8_2 = linked_452.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_451, arg_454) }; var tmp16 any; var root_623 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = seq_1991000064__7; if linked_624 == nil { tmp16 = ifn_625.Invoke_O__O(arg_626) } else { tmp16 = linked_624.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_623, arg_626) }; seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = tmp16, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_455 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = seq_1991000064__7; if linked_456 == nil { y__8 = ifn_457.Invoke_O__O(arg_458) } else { y__8 = linked_456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_455, arg_458) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp17 any; var root_627 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = seq_1991000064__7; if linked_628 == nil { tmp17 = ifn_629.Invoke_O__O(arg_630) } else { tmp17 = linked_628.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_627, arg_630) }; seq_1991000064__2, chunk_1991000065__3, count_1991000066__4, i_1991000067__5 = tmp17, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :123:1
								var tmp18 any; var root_459 any = A_arbace_j2g_embed_A_const_67.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_461 lang.IFn











								if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = x__1; if linked_460 == nil { tmp18 = ifn_461.Invoke_O__O(arg_462) } else { tmp18 = linked_460.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_459, arg_462) }
//line :123:1
								if jrt.J2g_Truth(tmp18) { var seq_1991000068__2 any; var root_463 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_465 lang.IFn











									if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = x__1; if linked_464 == nil { seq_1991000068__2 = ifn_465.Invoke_O__O(arg_466) } else { seq_1991000068__2 = linked_464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_463, arg_466) }
//line :123:1
									var chunk_1991000069__3 any; var count_1991000070__4 int64 = 0; var i_1991000071__5 int64 = 0; L3: for {











										if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000071__5, count_1991000070__4) { var vec__1991000072__6 any = lang.Indexed_Cast(chunk_1991000069__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000071__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000072__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000072__6, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000071__5); continue L3 } else { var temp__1927000414__auto____6_3 any; var root_467 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = seq_1991000068__2; if linked_468 == nil { temp__1927000414__auto____6_3 = ifn_469.Invoke_O__O(arg_470) } else { temp__1927000414__auto____6_3 = linked_468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1991000068__7 any = temp__1927000414__auto____6_3; var tmp19 any; var root_471 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq_1991000068__7; if linked_472 == nil { tmp19 = ifn_473.Invoke_O__O(arg_474) } else { tmp19 = linked_472.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_471, arg_474) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____8_3 any; var root_475 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = seq_1991000068__7; if linked_476 == nil { c__1927000678__auto____8_3 = ifn_477.Invoke_O__O(arg_478) } else { c__1927000678__auto____8_3 = linked_476.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_475, arg_478) }; var tmp20 any; var root_631 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = seq_1991000068__7; if linked_632 == nil { tmp20 = ifn_633.Invoke_O__O(arg_634) } else { tmp20 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_631, arg_634) }; seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = tmp20, c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1991000075__8 any; var root_479 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1991000068__7; if linked_480 == nil { vec__1991000075__8 = ifn_481.Invoke_O__O(arg_482) } else { vec__1991000075__8 = linked_480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_479, arg_482) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000075__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000075__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); var tmp21 any; var root_635 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = seq_1991000068__7; if linked_636 == nil { tmp21 = ifn_637.Invoke_O__O(arg_638) } else { tmp21 = linked_636.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_635, arg_638) }; seq_1991000068__2, chunk_1991000069__3, count_1991000070__4, i_1991000071__5 = tmp21, nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :123:1
											var tmp22 any; var root_483 any = A_arbace_j2g_embed_A_const_68.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_485 lang.IFn












											if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = x__1; if linked_484 == nil { tmp22 = ifn_485.Invoke_O__O(arg_486) } else { tmp22 = linked_484.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_483, arg_486) }
//line :123:1
											if jrt.J2g_Truth(tmp22) { var seq_1991000078__2 any; var root_487 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_489 lang.IFn












												if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = x__1; if linked_488 == nil { seq_1991000078__2 = ifn_489.Invoke_O__O(arg_490) } else { seq_1991000078__2 = linked_488.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_487, arg_490) }
//line :123:1
												var chunk_1991000079__3 any; var count_1991000080__4 int64 = 0; var i_1991000081__5 int64 = 0; L4: for {












													if lang.Numbers_Lt_J_J__Z_NoInit(i_1991000081__5, count_1991000080__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1991000079__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1991000081__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1991000081__5); continue L4 } else { var temp__1927000414__auto____6_4 any; var root_491 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = seq_1991000078__2; if linked_492 == nil { temp__1927000414__auto____6_4 = ifn_493.Invoke_O__O(arg_494) } else { temp__1927000414__auto____6_4 = linked_492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_491, arg_494) }; if jrt.J2g_Truth(temp__1927000414__auto____6_4) { var seq_1991000078__7 any = temp__1927000414__auto____6_4; var tmp23 any; var root_495 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = seq_1991000078__7; if linked_496 == nil { tmp23 = ifn_497.Invoke_O__O(arg_498) } else { tmp23 = linked_496.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_495, arg_498) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____8_4 any; var root_499 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = seq_1991000078__7; if linked_500 == nil { c__1927000678__auto____8_4 = ifn_501.Invoke_O__O(arg_502) } else { c__1927000678__auto____8_4 = linked_500.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_499, arg_502) }; var tmp24 any; var root_639 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = seq_1991000078__7; if linked_640 == nil { tmp24 = ifn_641.Invoke_O__O(arg_642) } else { tmp24 = linked_640.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_639, arg_642) }; seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = tmp24, c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var y__8_2 any; var root_503 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_1991000078__7; if linked_504 == nil { y__8_2 = ifn_505.Invoke_O__O(arg_506) } else { y__8_2 = linked_504.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_503, arg_506) }; lang.IFn_Cast(self).Invoke_O__O(y__8_2); var tmp25 any; var root_643 any = A_arbace_j2g_embed_A_const_72.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = seq_1991000078__7; if linked_644 == nil { tmp25 = ifn_645.Invoke_O__O(arg_646) } else { tmp25 = linked_644.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_643, arg_646) }; seq_1991000078__2, chunk_1991000079__3, count_1991000080__4, i_1991000081__5 = tmp25, nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :123:1
														return nil } } } } }; /*line :121:1*/panic("j2g: unreachable") }





























func A_arbace_j2g_embed_cut_candidates_A_New() *A_arbace_j2g_embed_cut_candidates_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Ctor() {}
//line :151:1
func (t *A_arbace_j2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var root_684 any = A_arbace_j2g_embed_A_const_75.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_New(); var tmp2 *jrt.Class; var fncls__796 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class; if fncls__796 == nil { var fncls__796d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class = fncls__796d; tmp2 = fncls__796d } else { tmp2 = fncls__796 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_797 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any; var root_802 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var arg_806 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_84.GetRawRoot__O()); var tmp6 any; var root_813 any = A_arbace_j2g_embed_A_const_85.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; if linked_814 == nil { tmp6 = ifn_815.Invoke__O() } else { tmp6 = linked_814.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_813) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_New(); var tmp9 *jrt.Class; var fncls__820 *jrt.Class = A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class; if fncls__820 == nil { var fncls__820d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class = fncls__820d; tmp9 = fncls__820d } else { tmp9 = fncls__820 }; arg_806 = tmp5.Invoke_O_O_O__O(tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), srcs__0); if linked_803 == nil { arg_800 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { arg_800 = linked_803.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; var arg_801 any = A_arbace_j2g_embed_A_const_87.GetRawRoot__O(); if linked_798 == nil { tmp4 = ifn_799.Invoke_O_O__O(arg_800, arg_801) } else { tmp4 = linked_798.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_797, arg_800, arg_801) }; arg_687 = tmp3.Invoke_O__O(tmp4); if linked_685 == nil { return ifn_686.Invoke_O__O(arg_687) } else { return linked_685.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_684, arg_687) } }
//line :156:1
func A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_New() *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_fn__1991000103_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A) Ctor() {}
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_fn__1991000103_A) Invoke_O_O__O(self, p__1991000102__1 any) any { var vec__1991000104__2 any = p__1991000102__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000104__2, lang.RT_IntCast_J__I_NoInit(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000104__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_816 any = A_arbace_j2g_embed_A_const_86.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_j2g_embed_names_A_fn_class); var ifn_818 lang.IFn; _ = ___3; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = text__4; if linked_817 == nil { return ifn_818.Invoke_O__O(arg_819) } else { return linked_817.(*A_arbace_j2g_embed_names_A).Invoke_O_O__O(root_816, arg_819) } }
//line :156:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_New() *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A) Ctor() {}
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A) Invoke_O_O__O(self, s__1991000089__1 any) any { var tmp1 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_New_O_O(s__1991000089__1, self); var tmp2 *jrt.Class; var fncls__795 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class; if fncls__795 == nil { var fncls__795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class = fncls__795d; tmp2 = fncls__795d } else { tmp2 = fncls__795 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :156:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A) Ctor_O_O(c__s__1991000089, c__iter__1991000088 any) { t.F_s__1991000089 = c__s__1991000089; t.F_iter__1991000088 = c__iter__1991000088 }
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A) Invoke_O__O(self any) any { { var s__1991000089__1 any; var t_ any = t.F_s__1991000089; t.F_s__1991000089 = nil; s__1991000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_688 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = s__1991000089__1; if linked_689 == nil { temp__1927000414__auto____2 = ifn_690.Invoke_O__O(arg_691) } else { temp__1927000414__auto____2 = linked_689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_688, arg_691) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000089__3 any = temp__1927000414__auto____2; var tmp1 any; var root_692 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = s__1991000089__3; if linked_693 == nil { tmp1 = ifn_694.Invoke_O__O(arg_695) } else { tmp1 = linked_693.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_692, arg_695) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_696 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = s__1991000089__3; if linked_697 == nil { c__1927001037__auto____4 = ifn_698.Invoke_O__O(arg_699) } else { c__1927001037__auto____4 = linked_697.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_696, arg_699) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000091__6 any; var root_700 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_701 == nil { b__1991000091__6 = ifn_702.Invoke_O__O(arg_703) } else { b__1991000091__6 = linked_701.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_700, arg_703) }; var tmp2 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_New_O_I_O(b__1991000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__732 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class; if fncls__732 == nil { var fncls__732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class = fncls__732d; tmp3 = fncls__732d } else { tmp3 = fncls__732 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_733 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any; var root_738 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = b__1991000091__6; if linked_739 == nil { arg_736 = ifn_740.Invoke_O__O(arg_741) } else { arg_736 = linked_739.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_738, arg_741) }; var arg_737 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000088); var tmp5 any; var root_742 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = s__1991000089__3; if linked_743 == nil { tmp5 = ifn_744.Invoke_O__O(arg_745) } else { tmp5 = linked_743.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_742, arg_745) }; arg_737 = tmp4.Invoke_O__O(tmp5); if linked_734 == nil { return ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { return linked_734.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_733, arg_736, arg_737) } } else { var root_746 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var root_751 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = b__1991000091__6; if linked_752 == nil { arg_749 = ifn_753.Invoke_O__O(arg_754) } else { arg_749 = linked_752.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_751, arg_754) }; var arg_750 any; if linked_747 == nil { return ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { return linked_747.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } } } else { var n__4 any; var root_755 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = s__1991000089__3; if linked_756 == nil { n__4 = ifn_757.Invoke_O__O(arg_758) } else { n__4 = linked_756.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_755, arg_758) }; var tmp6 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_759 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_761 lang.IFn
															if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = A_arbace_j2g_embed_A_const_77; var arg_763 any = n__4; if linked_760 == nil { or__1927000174__auto____5 = ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { or__1927000174__auto____5 = linked_760.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
																var root_764 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = A_arbace_j2g_embed_A_const_78; var arg_768 any = n__4; if linked_765 == nil { and__1927000168__auto____5 = ifn_766.Invoke_O_O__O(arg_767, arg_768) } else { and__1927000168__auto____5 = linked_765.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_764, arg_767, arg_768) } }
//line :157:1
	if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_769 any = A_arbace_j2g_embed_A_const_79.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = A_arbace_j2g_embed_A_const_80; var arg_773 any = n__4; var arg_774 any; var tmp7 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_New_O(n__4); var tmp8 *jrt.Class; var fncls__775 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class; if fncls__775 == nil { var fncls__775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class = fncls__775d; tmp8 = fncls__775d } else { tmp8 = fncls__775 }; arg_774 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_770 == nil { tmp6 = ifn_771.Invoke_O_O_O__O(arg_772, arg_773, arg_774) } else { tmp6 = linked_770.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_769, arg_772, arg_773, arg_774) } } else {
//line :157:1
			tmp6 = and__1927000168__auto____5 }
//line :156:1
	if jrt.J2g_Truth(tmp6) { var root_776 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var root_781 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_783 lang.IFn






		if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = n__4; var arg_785 any = Lit_1; var arg_786 any = Lit_7; if linked_782 == nil { arg_779 = ifn_783.Invoke_O_O_O__O(arg_784, arg_785, arg_786) } else { arg_779 = linked_782.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_781, arg_784, arg_785, arg_786) }
//line :156:1
		var arg_780 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1991000088); var tmp10 any; var root_787 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = s__1991000089__3; if linked_788 == nil { tmp10 = ifn_789.Invoke_O__O(arg_790) } else { tmp10 = linked_788.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_787, arg_790) }; arg_780 = tmp9.Invoke_O__O(tmp10); if linked_777 == nil { return ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { return linked_777.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) } } else { var tmp11 any; var root_791 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = s__1991000089__3; if linked_792 == nil { tmp11 = ifn_793.Invoke_O__O(arg_794) } else { tmp11 = linked_792.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_791, arg_794) }; s__1991000089__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :156:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A) Ctor_O_I_O(c__b__1991000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000091 = c__b__1991000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :156:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A) Invoke_O__O(self any) any { { var i__1991000090__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000090__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_704 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_706 lang.IFn
																	if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = A_arbace_j2g_embed_A_const_77; var arg_708 any = n__2; if linked_705 == nil { or__1927000174__auto____3 = ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { or__1927000174__auto____3 = linked_705.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
																		var root_709 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = A_arbace_j2g_embed_A_const_78; var arg_713 any = n__2; if linked_710 == nil { and__1927000168__auto____3 = ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { and__1927000168__auto____3 = linked_710.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) } }
//line :157:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {


		var root_714 any = A_arbace_j2g_embed_A_const_79.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_j2g_embed_A_const_80; var arg_718 any = n__2; var arg_719 any; var tmp3 any = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_New_O(n__2); var tmp4 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class = fncls__720d; tmp4 = fncls__720d } else { tmp4 = fncls__720 }; arg_719 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_715 == nil { tmp2 = ifn_716.Invoke_O_O_O__O(arg_717, arg_718, arg_719) } else { tmp2 = linked_715.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(root_714, arg_717, arg_718, arg_719) } } else {
//line :157:1
			tmp2 = and__1927000168__auto____3 }
//line :156:1
	if jrt.J2g_Truth(tmp2) { var root_721 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = t.F_b__1991000091; var arg_725 any; var root_726 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_728 lang.IFn






		if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = n__2; var arg_730 any = Lit_1; var arg_731 any = Lit_7; if linked_727 == nil { arg_725 = ifn_728.Invoke_O_O_O__O(arg_729, arg_730, arg_731) } else { arg_725 = linked_727.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_726, arg_729, arg_730, arg_731) }
//line :156:1
		if linked_722 == nil { ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { linked_722.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) }; i__1991000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000090__1); continue L1 } else { i__1991000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000090__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :160:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :160:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :160:1
func A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_New_O(p0 any) *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :160:1
func (t *A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :160:1
		tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_j2g_embed_with_member_types_A_New() *A_arbace_j2g_embed_with_member_types_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_j2g_embed_with_member_types_A) Ctor() {}
//line :165:1
func (t *A_arbace_j2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_types__1991000109_A_New(); var tmp2 *jrt.Class; var fncls__850 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class; if




	fncls__850 == nil { var fncls__850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class = fncls__850d; tmp2 = fncls__850d } else { tmp2 = fncls__850 }; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var elem__4 any; var tmp3 any = /*line :165:1*/A_arbace_j2g_embed_with_member_types_elem__1991000117_A_New(); var tmp4 *jrt.Class; var fncls__851 *jrt.Class = A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class; if








	fncls__851 == nil { var fncls__851d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class = fncls__851d; tmp4 = fncls__851d } else { tmp4 = fncls__851 }; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var member_types__5 any; var tmp5 any = /*line :165:1*/A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_New_O_O(elem__4, types__3); var tmp6 *jrt.Class; var fncls__973 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class; if










	fncls__973 == nil { var fncls__973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class = fncls__973d; tmp6 = fncls__973d } else { tmp6 = fncls__973 }; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var more__6 any; var iter__1927001039__auto____6 any; var tmp7 any = /*line :165:1*/A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp8 *jrt.Class; var fncls__1086 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class; if




















	fncls__1086 == nil { var fncls__1086d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class = fncls__1086d; tmp8 = fncls__1086d } else { tmp8 = fncls__1086 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); var root_1087 any =




	A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any; var root_1091 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var root_1095 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = cands__0; var arg_1099 any = more__6; if linked_1096 == nil { arg_1094 = ifn_1097.Invoke_O_O__O(arg_1098, arg_1099) } else { arg_1094 = linked_1096.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1095, arg_1098, arg_1099) }; if linked_1092 == nil { arg_1090 = ifn_1093.Invoke_O__O(arg_1094) } else { arg_1090 = linked_1092.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1091, arg_1094) }; if linked_1088 == nil { return ifn_1089.Invoke_O__O(arg_1090) } else { return linked_1088.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1087, arg_1090) } }
//line :170:1
func A_arbace_j2g_embed_with_member_types_types__1991000109_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_A) Ctor() {}
//line :170:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_82.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_88.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_New(); var tmp4 *jrt.Class; var fncls__837 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class; if fncls__837 == nil { var fncls__837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class = fncls__837d; tmp4 = fncls__837d } else { tmp4 = fncls__837 }; var tmp5 any = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp6 any; var root_838 any = A_arbace_j2g_embed_A_const_89.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_840 lang.IFn
	if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any; var tmp7 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_New(); var tmp8 *jrt.Class; var fncls__843 *jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class; if fncls__843 == nil { var fncls__843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class = fncls__843d; tmp8 = fncls__843d } else { tmp8 = fncls__843 }; arg_841 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_842 any = jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref(); if linked_839 == nil { tmp6 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { tmp6 = linked_839.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }
//line :171:1
	var tmp9 any = tmp6; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_88.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_New(); var tmp12 *jrt.Class
	var fncls__849 /*line :171:1*/*jrt.Class = A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class

	if fncls__849 == nil { var fncls__849d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class = fncls__849d; tmp12 = fncls__849d } else { tmp12 = fncls__849 }
//line :171:1
	return tmp1.Invoke_O_O_O__O(tmp5, tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :171:1
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A) Ctor() {}
//line :171:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A) Invoke_O_O__O(self, m__1 any) any { var root_832 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(); var arg_836 any = jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref(); if linked_833 == nil { return ifn_834.Invoke_O_O__O(arg_835, arg_836) } else { return linked_833.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_832, arg_835, arg_836) } }
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_New() *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_j2g_embed_with_member_types_elem__1991000117_A_New() *A_arbace_j2g_embed_with_member_types_elem__1991000117_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_elem__1991000117_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000117_A) Ctor() {}
//line :174:1
func (t *A_arbace_j2g_embed_with_member_types_elem__1991000117_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :176:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_New_O(n__1); var tmp2 *jrt.Class; var fncls__858 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class; if
														fncls__858 == nil { var fncls__858d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class = fncls__858d; tmp2 = fncls__858d } else { tmp2 = fncls__858 }; temp__1927000414__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var root_859 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_861 lang.IFn

		if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any; var root_863 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_865 lang.IFn; if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any; var root_867 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_New(); var tmp4 *jrt.Class; var fncls__967 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class
		if fncls__967 == nil { var fncls__967d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class = fncls__967d; tmp4 = fncls__967d } else { tmp4 = fncls__967 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp6 any; var root_968 any = A_arbace_j2g_embed_A_const_89.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = t.F_elem; var arg_972 any = lang.IFn_Cast(t.F_types).Invoke_O__O(c__3); if linked_969 == nil { tmp6 = ifn_970.Invoke_O_O__O(arg_971, arg_972) } else { tmp6 = linked_969.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_968, arg_971, arg_972) }; arg_870 = tmp5.Invoke_O__O(tmp6)
//line :179:1
		if linked_868 == nil { arg_866 = ifn_869.Invoke_O__O(arg_870) } else { arg_866 = linked_868.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_867, arg_870) }; if linked_864 == nil { arg_862 = ifn_865.Invoke_O__O(arg_866) } else { arg_862 = linked_864.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_863, arg_866) }; if linked_860 == nil { return ifn_861.Invoke_O__O(arg_862) } else { return linked_860.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_859, arg_862) } } else {
//line :177:1
			return nil } }
//line :177:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :177:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_852 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var t_ any = t.F_n; t.F_n = nil; arg_855 = t_; var arg_856 any = Lit_7; var arg_857 any = Lit_1; if linked_853 == nil { tmp2 = ifn_854.Invoke_O_O_O__O(arg_855, arg_856, arg_857) } else { tmp2 = linked_853.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_852, arg_855, arg_856, arg_857) }; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_New() *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A) Ctor() {}
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A) Invoke_O_O__O(self, s__1991000123__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_New_O_O(s__1991000123__1, self); var tmp2 *jrt.Class; var fncls__966 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class; if fncls__966 == nil { var fncls__966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class = fncls__966d; tmp2 = fncls__966d } else { tmp2 = fncls__966 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :180:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A) Ctor_O_O(c__s__1991000123, c__iter__1991000122 any) { t.F_s__1991000123 = c__s__1991000123; t.F_iter__1991000122 = c__iter__1991000122 }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A) Invoke_O__O(self any) any { { var s__1991000123__1 any; var t_ any = t.F_s__1991000123; t.F_s__1991000123 = nil; s__1991000123__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_871 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = s__1991000123__1; if linked_872 == nil { temp__1927000414__auto____2 = ifn_873.Invoke_O__O(arg_874) } else { temp__1927000414__auto____2 = linked_872.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_871, arg_874) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_875 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = s__1991000123__3; if linked_876 == nil { tmp1 = ifn_877.Invoke_O__O(arg_878) } else { tmp1 = linked_876.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_875, arg_878) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_879 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = s__1991000123__3; if linked_880 == nil { c__1927001037__auto____4 = ifn_881.Invoke_O__O(arg_882) } else { c__1927001037__auto____4 = linked_880.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_879, arg_882) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000125__6 any; var root_883 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_884 == nil { b__1991000125__6 = ifn_885.Invoke_O__O(arg_886) } else { b__1991000125__6 = linked_884.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_883, arg_886) }; var tmp2 any = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_New_O_I_O(b__1991000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__907 *jrt.Class = A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class; if fncls__907 == nil { var fncls__907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class = fncls__907d; tmp3 = fncls__907d } else { tmp3 = fncls__907 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_908 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any; var root_913 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = b__1991000125__6; if linked_914 == nil { arg_911 = ifn_915.Invoke_O__O(arg_916) } else { arg_911 = linked_914.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_913, arg_916) }; var arg_912 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000122); var tmp5 any; var root_917 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = s__1991000123__3; if linked_918 == nil { tmp5 = ifn_919.Invoke_O__O(arg_920) } else { tmp5 = linked_918.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_917, arg_920) }; arg_912 = tmp4.Invoke_O__O(tmp5); if linked_909 == nil { return ifn_910.Invoke_O_O__O(arg_911, arg_912) } else { return linked_909.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_908, arg_911, arg_912) } } else { var root_921 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any; var root_926 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = b__1991000125__6; if linked_927 == nil { arg_924 = ifn_928.Invoke_O__O(arg_929) } else { arg_924 = linked_927.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_926, arg_929) }; var arg_925 any; if linked_922 == nil { return ifn_923.Invoke_O_O__O(arg_924, arg_925) } else { return linked_922.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_921, arg_924, arg_925) } } } else { var t__4 any; var root_930 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = s__1991000123__3; if linked_931 == nil { t__4 = ifn_932.Invoke_O__O(arg_933) } else { t__4 = linked_931.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_930, arg_933) }; var tmp6 any; var root_934 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_936 lang.IFn
																		if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref(); if linked_935 == nil { tmp6 = ifn_936.Invoke_O__O(arg_937) } else { tmp6 = linked_935.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_934, arg_937) }
//line :180:1
	if jrt.J2g_Truth(tmp6) { var tn__5 any; var root_938 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_940 lang.IFn

		if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(); var arg_942 any = Lit_1; var arg_943 any = Lit_7; if linked_939 == nil { tn__5 = ifn_940.Invoke_O_O_O__O(arg_941, arg_942, arg_943) } else { tn__5 = linked_939.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_938, arg_941, arg_942, arg_943) }
//line :180:1
		var tmp7 any; var and__1927000168__auto____6 any; var root_944 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_946 lang.IFn


		if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = A_arbace_j2g_embed_A_const_93; var arg_948 any = tn__5; if linked_945 == nil { and__1927000168__auto____6 = ifn_946.Invoke_O_O__O(arg_947, arg_948) } else { and__1927000168__auto____6 = linked_945.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_944, arg_947, arg_948) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
			tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :183:1
				tmp7 = and__1927000168__auto____6 }
//line :180:1
		if jrt.J2g_Truth(tmp7) { var root_949 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = tn__5; var arg_953 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000122); var tmp9 any; var root_954 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = s__1991000123__3; if linked_955 == nil { tmp9 = ifn_956.Invoke_O__O(arg_957) } else { tmp9 = linked_955.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_954, arg_957) }; arg_953 = tmp8.Invoke_O__O(tmp9); if linked_950 == nil { return ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { return linked_950.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) } } else { var tmp10 any; var root_958 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = s__1991000123__3; if linked_959 == nil { tmp10 = ifn_960.Invoke_O__O(arg_961) } else { tmp10 = linked_959.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_958, arg_961) }; s__1991000123__1 = tmp10; continue L1 } } else { var tmp11 any; var root_962 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = s__1991000123__3; if linked_963 == nil { tmp11 = ifn_964.Invoke_O__O(arg_965) } else { tmp11 = linked_963.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_962, arg_965) }; s__1991000123__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :180:1
func A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A) Ctor_O_I_O(c__b__1991000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000125 = c__b__1991000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :180:1
func (t *A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A) Invoke_O__O(self any) any { { var i__1991000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000124__1)); var tmp2 any; var root_887 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_889 lang.IFn
																				if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref(); if linked_888 == nil { tmp2 = ifn_889.Invoke_O__O(arg_890) } else { tmp2 = linked_888.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_887, arg_890) }
//line :180:1
	if jrt.J2g_Truth(tmp2) { var tn__3 any; var root_891 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_893 lang.IFn

		if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(); var arg_895 any = Lit_1; var arg_896 any = Lit_7; if linked_892 == nil { tn__3 = ifn_893.Invoke_O_O_O__O(arg_894, arg_895, arg_896) } else { tn__3 = linked_892.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_891, arg_894, arg_895, arg_896) }
//line :180:1
		var tmp3 any; var and__1927000168__auto____4 any; var root_897 any = A_arbace_j2g_embed_A_const_76.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_899 lang.IFn


		if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = A_arbace_j2g_embed_A_const_93; var arg_901 any = tn__3; if linked_898 == nil { and__1927000168__auto____4 = ifn_899.Invoke_O_O__O(arg_900, arg_901) } else { and__1927000168__auto____4 = linked_898.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_897, arg_900, arg_901) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
			tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :183:1
				tmp3 = and__1927000168__auto____4 }
//line :180:1
		if jrt.J2g_Truth(tmp3) { var root_902 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = t.F_b__1991000125; var arg_906 any = tn__3; if linked_903 == nil { ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { linked_903.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) }; i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } else { i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } } else { i__1991000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000124__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A) Invoke_O_O__O(self, s__1991000134__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1991000134__1, self); var tmp2 *jrt.Class; var fncls__1085 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class; if fncls__1085 == nil { var fncls__1085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class = fncls__1085d; tmp2 = fncls__1085d } else { tmp2 = fncls__1085 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :186:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1991000134, c__iter__1991000133 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1991000134 = c__s__1991000134; t.F_iter__1991000133 = c__iter__1991000133 }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A) Invoke_O__O(self any) any { { var s__1991000134__1 any; var t_ any = t.F_s__1991000134; t.F_s__1991000134 = nil; s__1991000134__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_974 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = s__1991000134__1; if linked_975 == nil { temp__1927000414__auto____2 = ifn_976.Invoke_O__O(arg_977) } else { temp__1927000414__auto____2 = linked_975.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_974, arg_977) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_978 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = xs__1927001018__auto____3; if linked_979 == nil { n__4 = ifn_980.Invoke_O__O(arg_981) } else { n__4 = linked_979.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_978, arg_981) }; var tmp1 any; var root_982 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_984 lang.IFn
															if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4); if linked_983 == nil { tmp1 = ifn_984.Invoke_O__O(arg_985) } else { tmp1 = linked_983.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_982, arg_985) }
//line :186:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_New_O(t.F_in_world_QMARK_); var tmp3 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class = fncls__1056d; tmp3 = fncls__1056d } else { tmp3 = fncls__1056 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1057 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var root_1061 any = A_arbace_j2g_embed_A_const_94.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A_fn_class); var ifn_1063 lang.IFn

		if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = A_arbace_j2g_embed_A_const_95; var arg_1065 any = n__4; var arg_1066 any; var tmp6 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_New_O_O(n__4, t.F_member_types); var tmp7 *jrt.Class; var fncls__1067 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class; if fncls__1067 == nil { var fncls__1067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class = fncls__1067d; tmp7 = fncls__1067d } else { tmp7 = fncls__1067 }; arg_1066 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_1062 == nil { tmp5 = ifn_1063.Invoke_O_O_O__O(arg_1064, arg_1065, arg_1066) } else { tmp5 = linked_1062.(*aot_arbace_j2g_edge.A_arbace_j2g_edge_jvm_A).Invoke_O_O_O_O__O(root_1061, arg_1064, arg_1065, arg_1066) }
//line :186:1
		arg_1060 = tmp4.Invoke_O__O(tmp5); if linked_1058 == nil { fs__1927001036__auto____6 = ifn_1059.Invoke_O__O(arg_1060) } else { fs__1927001036__auto____6 = linked_1058.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1057, arg_1060) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1068 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = fs__1927001036__auto____6; var arg_1072 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000133); var tmp9 any; var root_1073 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = s__1991000134__1; if linked_1074 == nil { tmp9 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp9 = linked_1074.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1073, arg_1076) }; arg_1072 = tmp8.Invoke_O__O(tmp9); if linked_1069 == nil { return ifn_1070.Invoke_O_O__O(arg_1071, arg_1072) } else { return linked_1069.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1068, arg_1071, arg_1072) } } else { var tmp10 any; var root_1077 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = s__1991000134__1; if linked_1078 == nil { tmp10 = ifn_1079.Invoke_O__O(arg_1080) } else { tmp10 = linked_1078.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1077, arg_1080) }; s__1991000134__1 = tmp10; continue L1 } } else { var tmp11 any; var root_1081 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = s__1991000134__1; if linked_1082 == nil { tmp11 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp11 = linked_1082.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1081, arg_1084) }; s__1991000134__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :186:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_New_O(p0 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A) Invoke_O_O__O(self, s__1991000136__1 any) any { var tmp1 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_New_O_O_O(t.F_in_world_QMARK_, s__1991000136__1, self); var tmp2 *jrt.Class; var fncls__1055 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class; if fncls__1055 == nil { var fncls__1055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class = fncls__1055d; tmp2 = fncls__1055d } else { tmp2 = fncls__1055 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :186:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1991000136, c__iter__1991000135 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1991000136 = c__s__1991000136; t.F_iter__1991000135 = c__iter__1991000135 }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A) Invoke_O__O(self any) any { { var s__1991000136__1 any; var t_ any = t.F_s__1991000136; t.F_s__1991000136 = nil; s__1991000136__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_986 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = s__1991000136__1; if linked_987 == nil { temp__1927000414__auto____2 = ifn_988.Invoke_O__O(arg_989) } else { temp__1927000414__auto____2 = linked_987.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_986, arg_989) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000136__3 any = temp__1927000414__auto____2; var tmp1 any; var root_990 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = s__1991000136__3; if linked_991 == nil { tmp1 = ifn_992.Invoke_O__O(arg_993) } else { tmp1 = linked_991.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_990, arg_993) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_994 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = s__1991000136__3; if linked_995 == nil { c__1927001037__auto____4 = ifn_996.Invoke_O__O(arg_997) } else { c__1927001037__auto____4 = linked_995.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_994, arg_997) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000138__6 any; var root_998 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_999 == nil { b__1991000138__6 = ifn_1000.Invoke_O__O(arg_1001) } else { b__1991000138__6 = linked_999.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_998, arg_1001) }; var tmp2 any = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_New_O_O_I_O(b__1991000138__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class = fncls__1011d; tmp3 = fncls__1011d } else { tmp3 = fncls__1011 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1012 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any; var root_1017 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = b__1991000138__6; if linked_1018 == nil { arg_1015 = ifn_1019.Invoke_O__O(arg_1020) } else { arg_1015 = linked_1018.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1017, arg_1020) }; var arg_1016 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000135); var tmp5 any; var root_1021 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = s__1991000136__3; if linked_1022 == nil { tmp5 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp5 = linked_1022.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1021, arg_1024) }; arg_1016 = tmp4.Invoke_O__O(tmp5); if linked_1013 == nil { return ifn_1014.Invoke_O_O__O(arg_1015, arg_1016) } else { return linked_1013.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1012, arg_1015, arg_1016) } } else { var root_1025 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any; var root_1030 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = b__1991000138__6; if linked_1031 == nil { arg_1028 = ifn_1032.Invoke_O__O(arg_1033) } else { arg_1028 = linked_1031.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1030, arg_1033) }; var arg_1029 any; if linked_1026 == nil { return ifn_1027.Invoke_O_O__O(arg_1028, arg_1029) } else { return linked_1026.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1025, arg_1028, arg_1029) } } } else { var tn__4 any; var root_1034 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = s__1991000136__3; if linked_1035 == nil { tn__4 = ifn_1036.Invoke_O__O(arg_1037) } else { tn__4 = linked_1035.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1034, arg_1037) }; var tmp6 any; var root_1038 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1040 lang.IFn


	if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4); if linked_1039 == nil { tmp6 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp6 = linked_1039.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1038, arg_1041) }
//line :186:1
	if jrt.J2g_Truth(tmp6) { var root_1042 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = tn__4; var arg_1046 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000135); var tmp8 any; var root_1047 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = s__1991000136__3; if linked_1048 == nil { tmp8 = ifn_1049.Invoke_O__O(arg_1050) } else { tmp8 = linked_1048.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1047, arg_1050) }; arg_1046 = tmp7.Invoke_O__O(tmp8); if linked_1043 == nil { return ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { return linked_1043.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) } } else { var tmp9 any; var root_1051 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = s__1991000136__3; if linked_1052 == nil { tmp9 = ifn_1053.Invoke_O__O(arg_1054) } else { tmp9 = linked_1052.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1051, arg_1054) }; s__1991000136__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :186:1
func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A) Ctor_O_O_I_O(c__b__1991000138, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000138 = c__b__1991000138; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :186:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A) Invoke_O__O(self any) any { { var i__1991000137__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000137__1)); var tmp2 any; var root_1002 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1004 lang.IFn


	if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2); if linked_1003 == nil { tmp2 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp2 = linked_1003.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1002, arg_1005) }
//line :186:1
	if jrt.J2g_Truth(tmp2) { var root_1006 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = t.F_b__1991000138; var arg_1010 any = tn__2; if linked_1007 == nil { ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { linked_1007.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) }; i__1991000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000137__1); continue L1 } else { i__1991000137__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000137__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :188:1
func (t *A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_j2g_embed_data_A_New() *A_arbace_j2g_embed_data_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_j2g_embed_data_A) Ctor() {}
//line :196:1
func (t *A_arbace_j2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any; var root_1100 any = A_arbace_j2g_embed_A_const_12.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1100, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1102 lang.IFn; if




	linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = dir__0; if linked_1101 == nil { base__2 = ifn_1102.Invoke_O__O(arg_1103) } else { base__2 = linked_1101.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1100, arg_1103) }; var root_1104 any =
	A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_45.GetRawRoot__O()).Invoke__O(); var arg_1108 any; if
	jrt.NN(jrt.File_Cast(base__2)).IsDirectory__Z() { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_New_O(base__2); var tmp2 *jrt.Class; var fncls__1194 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class
		if fncls__1194 == nil { var fncls__1194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class = fncls__1194d; tmp2 = fncls__1194d } else { tmp2 = fncls__1194 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1195 any = A_arbace_j2g_embed_A_const_47.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = base__2; if linked_1196 == nil { tmp4 = ifn_1197.Invoke_O__O(arg_1198) } else { tmp4 = linked_1196.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_1195, arg_1198) }; arg_1108 = tmp3.Invoke_O__O(tmp4) } else {
//line :203:1
			arg_1108 = nil }; if /*line :202:1*/ linked_1105 == nil { return ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { return linked_1105.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) } }

func A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_New_O(p0 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_A{}; t.Ctor_O(p0); return t }
//line :204:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :204:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_A) Invoke_O_O__O(self, s__1991000153__1 any) any { var tmp1 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_New_O_O_O(t.F_base, s__1991000153__1, self); var tmp2 *jrt.Class; var fncls__1193 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class; if fncls__1193 == nil { var fncls__1193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class = fncls__1193d; tmp2 = fncls__1193d } else { tmp2 = fncls__1193 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :204:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A) Ctor_O_O_O(c__base, c__s__1991000153, c__iter__1991000152 any) { t.F_base = c__base; t.F_s__1991000153 = c__s__1991000153; t.F_iter__1991000152 = c__iter__1991000152 }
//line :204:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A) Invoke_O__O(self any) any { { var s__1991000153__1 any; var t_ any = t.F_s__1991000153; t.F_s__1991000153 = nil; s__1991000153__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1112 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = s__1991000153__1; if linked_1113 == nil { temp__1927000414__auto____2 = ifn_1114.Invoke_O__O(arg_1115) } else { temp__1927000414__auto____2 = linked_1113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1112, arg_1115) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000153__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1116 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = s__1991000153__3; if linked_1117 == nil { tmp1 = ifn_1118.Invoke_O__O(arg_1119) } else { tmp1 = linked_1117.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1116, arg_1119) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1120 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = s__1991000153__3; if linked_1121 == nil { c__1927001037__auto____4 = ifn_1122.Invoke_O__O(arg_1123) } else { c__1927001037__auto____4 = linked_1121.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1120, arg_1123) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000155__6 any; var root_1124 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1125 == nil { b__1991000155__6 = ifn_1126.Invoke_O__O(arg_1127) } else { b__1991000155__6 = linked_1125.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1124, arg_1127) }; var tmp2 any = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_New_O_I_O_O(t.F_base, size__1927001038__auto____5, b__1991000155__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1143 *jrt.Class = A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class; if fncls__1143 == nil { var fncls__1143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class = fncls__1143d; tmp3 = fncls__1143d } else { tmp3 = fncls__1143 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1144 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any; var root_1149 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = b__1991000155__6; if linked_1150 == nil { arg_1147 = ifn_1151.Invoke_O__O(arg_1152) } else { arg_1147 = linked_1150.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1149, arg_1152) }; var arg_1148 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000152); var tmp5 any; var root_1153 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = s__1991000153__3; if linked_1154 == nil { tmp5 = ifn_1155.Invoke_O__O(arg_1156) } else { tmp5 = linked_1154.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1153, arg_1156) }; arg_1148 = tmp4.Invoke_O__O(tmp5); if linked_1145 == nil { return ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { return linked_1145.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) } } else { var root_1157 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any; var root_1162 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = b__1991000155__6; if linked_1163 == nil { arg_1160 = ifn_1164.Invoke_O__O(arg_1165) } else { arg_1160 = linked_1163.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1162, arg_1165) }; var arg_1161 any; if linked_1158 == nil { return ifn_1159.Invoke_O_O__O(arg_1160, arg_1161) } else { return linked_1158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1157, arg_1160, arg_1161) } } } else { var f__4 any; var root_1166 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = s__1991000153__3; if linked_1167 == nil { f__4 = ifn_1168.Invoke_O__O(arg_1169) } else { f__4 = linked_1167.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1166, arg_1169) }; if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var root_1170 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any; var tmp6 any; var root_1175 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1177 lang.IFn

	if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any; var root_1181 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_1182 == nil { arg_1178 = ifn_1183.Invoke_O__O(arg_1184) } else { arg_1178 = linked_1182.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1181, arg_1184) }; var arg_1179 any = jrt.File_separator.Ref(); var arg_1180 any = Lit_7; if linked_1176 == nil { tmp6 = ifn_1177.Invoke_O_O_O__O(arg_1178, arg_1179, arg_1180) } else { tmp6 = linked_1176.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1175, arg_1178, arg_1179, arg_1180) }
//line :204:1
	arg_1173 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, f__4); var arg_1174 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000152); var tmp8 any; var root_1185 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = s__1991000153__3; if linked_1186 == nil { tmp8 = ifn_1187.Invoke_O__O(arg_1188) } else { tmp8 = linked_1186.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1185, arg_1188) }; arg_1174 = tmp7.Invoke_O__O(tmp8); if linked_1171 == nil { return ifn_1172.Invoke_O_O__O(arg_1173, arg_1174) } else { return linked_1171.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1170, arg_1173, arg_1174) } } else { var tmp9 any; var root_1189 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = s__1991000153__3; if linked_1190 == nil { tmp9 = ifn_1191.Invoke_O__O(arg_1192) } else { tmp9 = linked_1190.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1189, arg_1192) }; s__1991000153__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :204:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A) Ctor_O_I_O_O(c__base any, c__size__1927001038__auto__ int32, c__b__1991000155, c__c__1927001037__auto__ any) { t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1991000155 = c__b__1991000155; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :204:1
func (t *A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A) Invoke_O__O(self any) any { { var i__1991000154__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000154__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var root_1128 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = t.F_b__1991000155; var arg_1132 any; var tmp2 any; var root_1133 any = A_arbace_j2g_embed_A_const_81.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1135 lang.IFn

	if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any; var root_1139 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_1140 == nil { arg_1136 = ifn_1141.Invoke_O__O(arg_1142) } else { arg_1136 = linked_1140.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1139, arg_1142) }; var arg_1137 any = jrt.File_separator.Ref(); var arg_1138 any = Lit_7; if linked_1134 == nil { tmp2 = ifn_1135.Invoke_O_O_O__O(arg_1136, arg_1137, arg_1138) } else { tmp2 = linked_1134.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1133, arg_1136, arg_1137, arg_1138) }
//line :204:1
	arg_1132 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, f__2); if linked_1129 == nil { ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { linked_1129.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) }; i__1991000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000154__1); continue L1 } else { i__1991000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000154__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_j2g_embed_image_type_forms_A_New() *A_arbace_j2g_embed_image_type_forms_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Ctor() {}
//line :222:1
func (t *A_arbace_j2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any = A_arbace_j2g_embed_A_const_96; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_New_O(prog_dir__0); var tmp2 *jrt.Class; var fncls__1326 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class; if





	fncls__1326 == nil { var fncls__1326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class = fncls__1326d; tmp2 = fncls__1326d } else { tmp2 = fncls__1326 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_j2g_embed_A_const_113); var types__4 any; var root_1327 any = /*line :222:1*/A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1329 lang.IFn; if












	linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var arg_1331 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_84.GetRawRoot__O()); var tmp4 any; var root_1338 any = A_arbace_j2g_embed_A_const_85.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; if linked_1339 == nil { tmp4 = ifn_1340.Invoke__O() } else { tmp4 = linked_1339.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_1338) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_New_O(re__2); var tmp7 *jrt.Class; var fncls__1423 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class; if fncls__1423 == nil { var fncls__1423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class = fncls__1423d; tmp7 = fncls__1423d } else { tmp7 = fncls__1423 }; arg_1331 = tmp3.Invoke_O_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), files__3); if linked_1328 == nil { types__4 = ifn_1329.Invoke_O_O__O(arg_1330, arg_1331) } else { types__4 = linked_1328.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1327, arg_1330, arg_1331) }; var root_1424 any =



	A_arbace_j2g_embed_A_const_44.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_embed_A_const_100, Lit_18, A_arbace_j2g_embed_A_const_101, A_arbace_j2g_embed_A_const_102)); var arg_1428 any; var iter__1927001039__auto____5 any; var tmp8 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_New(); var tmp9 *jrt.Class; var fncls__1619 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class; if
	fncls__1619 == nil { var fncls__1619d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class = fncls__1619d; tmp9 = fncls__1619d } else { tmp9 = fncls__1619 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp11 any; var root_1620 any = A_arbace_j2g_embed_A_const_111.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_partition_all_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = A_arbace_j2g_embed_A_const_112; var arg_1624 any; var root_1625 any = A_arbace_j2g_embed_A_const_46.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = A_arbace_j2g_embed_A_const_18.GetRawRoot__O(); var arg_1629 any; var root_1630 any = A_arbace_j2g_embed_A_const_92.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = types__4; if linked_1631 == nil { arg_1629 = ifn_1632.Invoke_O__O(arg_1633) } else { arg_1629 = linked_1631.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1630, arg_1633) }; if linked_1626 == nil { arg_1624 = ifn_1627.Invoke_O_O__O(arg_1628, arg_1629) } else { arg_1624 = linked_1626.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1625, arg_1628, arg_1629) }; if linked_1621 == nil { tmp11 = ifn_1622.Invoke_O_O__O(arg_1623, arg_1624) } else { tmp11 = linked_1621.(*aot_arbace_core.A_arbace_core_partition_all_A).Invoke_O_O_O__O(root_1620, arg_1623, arg_1624) }; arg_1428 = tmp10.Invoke_O__O(tmp11); if /*line :239:1*/ linked_1425 == nil { return ifn_1426.Invoke_O_O__O(arg_1427, arg_1428) } else { return linked_1425.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1424, arg_1427, arg_1428) } }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A{}; t.Ctor_O(p0); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A) Invoke_O_O__O(self, s__1991000164__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_New_O_O_O(t.F_prog_dir, s__1991000164__1, self); var tmp2 *jrt.Class; var fncls__1325 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class; if fncls__1325 == nil { var fncls__1325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class = fncls__1325d; tmp2 = fncls__1325d } else { tmp2 = fncls__1325 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A) Ctor_O_O_O(c__prog_dir, c__s__1991000164, c__iter__1991000163 any) { t.F_prog_dir = c__prog_dir; t.F_s__1991000164 = c__s__1991000164; t.F_iter__1991000163 = c__iter__1991000163 }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A) Invoke_O__O(self any) any { { var s__1991000164__1 any; var t_ any = t.F_s__1991000164; t.F_s__1991000164 = nil; s__1991000164__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1199 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = s__1991000164__1; if linked_1200 == nil { temp__1927000414__auto____2 = ifn_1201.Invoke_O__O(arg_1202) } else { temp__1927000414__auto____2 = linked_1200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1199, arg_1202) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1991000171__4 any; var root_1203 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = xs__1927001018__auto____3; if linked_1204 == nil { vec__1991000171__4 = ifn_1205.Invoke_O__O(arg_1206) } else { vec__1991000171__4 = linked_1204.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1203, arg_1206) }; var pkg__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000171__4, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000171__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dir__7 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_24, pkg__5); var iterys__1927001035__auto____8 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_New_O(alias__6); var tmp2 *jrt.Class; var fncls__1303 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class; if fncls__1303 == nil { var fncls__1303d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class = fncls__1303d; tmp2 = fncls__1303d } else { tmp2 = fncls__1303 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____9 any; var root_1304 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp4 any; var root_1308 any = A_arbace_j2g_embed_A_const_91.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1310 lang.IFn

	if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = jrt.NN(jrt.File_Cast(dir__7)).ListFiles__File1().Ref(); if linked_1309 == nil { tmp4 = ifn_1310.Invoke_O__O(arg_1311) } else { tmp4 = linked_1309.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1308, arg_1311) }
//line :228:1
	arg_1307 = tmp3.Invoke_O__O(tmp4); if linked_1305 == nil { fs__1927001036__auto____9 = ifn_1306.Invoke_O__O(arg_1307) } else { fs__1927001036__auto____9 = linked_1305.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1304, arg_1307) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_1312 any = A_arbace_j2g_embed_A_const_82.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = fs__1927001036__auto____9; var arg_1316 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1991000163); var tmp6 any; var root_1317 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = s__1991000164__1; if linked_1318 == nil { tmp6 = ifn_1319.Invoke_O__O(arg_1320) } else { tmp6 = linked_1318.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1317, arg_1320) }; arg_1316 = tmp5.Invoke_O__O(tmp6); if linked_1313 == nil { return ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { return linked_1313.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) } } else { var tmp7 any; var root_1321 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = s__1991000164__1; if linked_1322 == nil { tmp7 = ifn_1323.Invoke_O__O(arg_1324) } else { tmp7 = linked_1322.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1321, arg_1324) }; s__1991000164__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A{}; t.Ctor_O(p0); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A) Invoke_O_O__O(self, s__1991000166__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_New_O_O_O(t.F_alias, s__1991000166__1, self); var tmp2 *jrt.Class; var fncls__1302 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class; if fncls__1302 == nil { var fncls__1302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class = fncls__1302d; tmp2 = fncls__1302d } else { tmp2 = fncls__1302 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A) Ctor_O_O_O(c__alias, c__s__1991000166, c__iter__1991000165 any) { t.F_alias = c__alias; t.F_s__1991000166 = c__s__1991000166; t.F_iter__1991000165 = c__iter__1991000165 }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A) Invoke_O__O(self any) any { { var s__1991000166__1 any; var t_ any = t.F_s__1991000166; t.F_s__1991000166 = nil; s__1991000166__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1213 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = s__1991000166__1; if linked_1214 == nil { temp__1927000414__auto____2 = ifn_1215.Invoke_O__O(arg_1216) } else { temp__1927000414__auto____2 = linked_1214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1213, arg_1216) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000166__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1217 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = s__1991000166__3; if linked_1218 == nil { tmp1 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp1 = linked_1218.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1217, arg_1220) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1221 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = s__1991000166__3; if linked_1222 == nil { c__1927001037__auto____4 = ifn_1223.Invoke_O__O(arg_1224) } else { c__1927001037__auto____4 = linked_1222.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1221, arg_1224) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000168__6 any; var root_1225 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1226 == nil { b__1991000168__6 = ifn_1227.Invoke_O__O(arg_1228) } else { b__1991000168__6 = linked_1226.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1225, arg_1228) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_New_O_I_O_O(t.F_alias, size__1927001038__auto____5, c__1927001037__auto____4, b__1991000168__6); var tmp3 *jrt.Class; var fncls__1248 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class; if fncls__1248 == nil { var fncls__1248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class = fncls__1248d; tmp3 = fncls__1248d } else { tmp3 = fncls__1248 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1249 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any; var root_1254 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = b__1991000168__6; if linked_1255 == nil { arg_1252 = ifn_1256.Invoke_O__O(arg_1257) } else { arg_1252 = linked_1255.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1254, arg_1257) }; var arg_1253 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000165); var tmp5 any; var root_1258 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = s__1991000166__3; if linked_1259 == nil { tmp5 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp5 = linked_1259.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1258, arg_1261) }; arg_1253 = tmp4.Invoke_O__O(tmp5); if linked_1250 == nil { return ifn_1251.Invoke_O_O__O(arg_1252, arg_1253) } else { return linked_1250.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1249, arg_1252, arg_1253) } } else { var root_1262 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any; var root_1267 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = b__1991000168__6; if linked_1268 == nil { arg_1265 = ifn_1269.Invoke_O__O(arg_1270) } else { arg_1265 = linked_1268.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1267, arg_1270) }; var arg_1266 any; if linked_1263 == nil { return ifn_1264.Invoke_O_O__O(arg_1265, arg_1266) } else { return linked_1263.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1262, arg_1265, arg_1266) } } } else { var f__4 any; var root_1271 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = s__1991000166__3; if linked_1272 == nil { f__4 = ifn_1273.Invoke_O__O(arg_1274) } else { f__4 = linked_1272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1271, arg_1274) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1275 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1279 any = Lit_28; if linked_1276 == nil { and__1927000168__auto____6 = ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { and__1927000168__auto____6 = linked_1276.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_1280 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any; var root_1284 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_1288 any = Lit_29; if linked_1285 == nil { arg_1283 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { arg_1283 = linked_1285.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) }; if linked_1281 == nil { tmp6 = ifn_1282.Invoke_O__O(arg_1283) } else { tmp6 = linked_1281.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1280, arg_1283) } } else {
//line :231:1
			tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :228:1
	if jrt.J2g_Truth(tmp6) { var root_1289 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4); var arg_1293 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1991000165); var tmp8 any; var root_1294 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = s__1991000166__3; if linked_1295 == nil { tmp8 = ifn_1296.Invoke_O__O(arg_1297) } else { tmp8 = linked_1295.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1294, arg_1297) }; arg_1293 = tmp7.Invoke_O__O(tmp8); if linked_1290 == nil { return ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { return linked_1290.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) } } else { var tmp9 any; var root_1298 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = s__1991000166__3; if linked_1299 == nil { tmp9 = ifn_1300.Invoke_O__O(arg_1301) } else { tmp9 = linked_1299.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1298, arg_1301) }; s__1991000166__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :228:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A) Ctor_O_I_O_O(c__alias any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1991000168 any) { t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1991000168 = c__b__1991000168 }
//line :228:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A) Invoke_O__O(self any) any { { var i__1991000167__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000167__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1229 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1233 any = Lit_28; if linked_1230 == nil { and__1927000168__auto____4 = ifn_1231.Invoke_O_O__O(arg_1232, arg_1233) } else { and__1927000168__auto____4 = linked_1230.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1229, arg_1232, arg_1233) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1234 any = A_arbace_j2g_embed_A_const_59.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any; var root_1238 any = A_arbace_j2g_embed_A_const_17.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_1242 any = Lit_29; if linked_1239 == nil { arg_1237 = ifn_1240.Invoke_O_O__O(arg_1241, arg_1242) } else { arg_1237 = linked_1239.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1238, arg_1241, arg_1242) }; if linked_1235 == nil { tmp2 = ifn_1236.Invoke_O__O(arg_1237) } else { tmp2 = linked_1235.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1234, arg_1237) } } else {
//line :231:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :228:1
	if jrt.J2g_Truth(tmp2) { var root_1243 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = t.F_b__1991000168; var arg_1247 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2); if linked_1244 == nil { ifn_1245.Invoke_O_O__O(arg_1246, arg_1247) } else { linked_1244.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1243, arg_1246, arg_1247) }; i__1991000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000167__1); continue L1 } else { i__1991000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000167__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_A) Invoke_O_O__O(self, p__1991000182__1 any) any { var vec__1991000184__2 any = p__1991000182__1; var alias__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000184__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000184__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1341 any = A_arbace_j2g_embed_A_const_90.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_New_O(alias__3); var tmp2 *jrt.Class; var fncls__1413 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class; if fncls__1413 == nil { var fncls__1413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class = fncls__1413d; tmp2 = fncls__1413d } else { tmp2 = fncls__1413 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp4 any; var root_1414 any = A_arbace_j2g_embed_A_const_98.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = t.F_re; var arg_1418 any = lang.IFn_Cast(A_arbace_j2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4); if linked_1415 == nil { tmp4 = ifn_1416.Invoke_O_O__O(arg_1417, arg_1418) } else { tmp4 = linked_1415.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_1414, arg_1417, arg_1418) }; arg_1344 = tmp3.Invoke_O__O(tmp4); if linked_1342 == nil { return ifn_1343.Invoke_O__O(arg_1344) } else { return linked_1342.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1341, arg_1344) } }
//line :235:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_New_O(p0 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A) Invoke_O_O__O(self, s__1991000188__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_New_O_O_O(t.F_alias, s__1991000188__1, self); var tmp2 *jrt.Class; var fncls__1412 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class; if fncls__1412 == nil { var fncls__1412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class = fncls__1412d; tmp2 = fncls__1412d } else { tmp2 = fncls__1412 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :235:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A) Ctor_O_O_O(c__alias, c__s__1991000188, c__iter__1991000187 any) { t.F_alias = c__alias; t.F_s__1991000188 = c__s__1991000188; t.F_iter__1991000187 = c__iter__1991000187 }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A) Invoke_O__O(self any) any { { var s__1991000188__1 any; var t_ any = t.F_s__1991000188; t.F_s__1991000188 = nil; s__1991000188__1 = t_; for { var temp__1927000414__auto____2 any; var root_1345 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = s__1991000188__1; if linked_1346 == nil { temp__1927000414__auto____2 = ifn_1347.Invoke_O__O(arg_1348) } else { temp__1927000414__auto____2 = linked_1346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1345, arg_1348) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000188__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1349 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = s__1991000188__3; if linked_1350 == nil { tmp1 = ifn_1351.Invoke_O__O(arg_1352) } else { tmp1 = linked_1350.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1349, arg_1352) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1353 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = s__1991000188__3; if linked_1354 == nil { c__1927001037__auto____4 = ifn_1355.Invoke_O__O(arg_1356) } else { c__1927001037__auto____4 = linked_1354.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1353, arg_1356) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000190__6 any; var root_1357 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1358 == nil { b__1991000190__6 = ifn_1359.Invoke_O__O(arg_1360) } else { b__1991000190__6 = linked_1358.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1357, arg_1360) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_New_O_O_I_O(t.F_alias, b__1991000190__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1371 *jrt.Class = A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class; if fncls__1371 == nil { var fncls__1371d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class = fncls__1371d; tmp3 = fncls__1371d } else { tmp3 = fncls__1371 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1372 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any; var root_1377 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = b__1991000190__6; if linked_1378 == nil { arg_1375 = ifn_1379.Invoke_O__O(arg_1380) } else { arg_1375 = linked_1378.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1377, arg_1380) }; var arg_1376 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000187); var tmp5 any; var root_1381 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = s__1991000188__3; if linked_1382 == nil { tmp5 = ifn_1383.Invoke_O__O(arg_1384) } else { tmp5 = linked_1382.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1381, arg_1384) }; arg_1376 = tmp4.Invoke_O__O(tmp5); if linked_1373 == nil { return ifn_1374.Invoke_O_O__O(arg_1375, arg_1376) } else { return linked_1373.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1372, arg_1375, arg_1376) } } else { var root_1385 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any; var root_1390 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = b__1991000190__6; if linked_1391 == nil { arg_1388 = ifn_1392.Invoke_O__O(arg_1393) } else { arg_1388 = linked_1391.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1390, arg_1393) }; var arg_1389 any; if linked_1386 == nil { return ifn_1387.Invoke_O_O__O(arg_1388, arg_1389) } else { return linked_1386.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1385, arg_1388, arg_1389) } } } else { var vec__1991000198__4 any; var root_1394 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = s__1991000188__3; if linked_1395 == nil { vec__1991000198__4 = ifn_1396.Invoke_O__O(arg_1397) } else { vec__1991000198__4 = linked_1395.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1394, arg_1397) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000198__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000198__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1398 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1400 lang.IFn; _ = ___5; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any; var root_1403 any = A_arbace_j2g_embed_A_const_97.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = t.F_alias; var arg_1407 any = n__6; if linked_1404 == nil { arg_1401 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { arg_1401 = linked_1404.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }; var arg_1402 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1991000187); var tmp7 any; var root_1408 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = s__1991000188__3; if linked_1409 == nil { tmp7 = ifn_1410.Invoke_O__O(arg_1411) } else { tmp7 = linked_1409.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1408, arg_1411) }; arg_1402 = tmp6.Invoke_O__O(tmp7); if linked_1399 == nil { return ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { return linked_1399.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :235:1
func A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A) Ctor_O_O_I_O(c__alias, c__b__1991000190 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_b__1991000190 = c__b__1991000190; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :235:1
func (t *A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A) Invoke_O__O(self any) any { { var i__1991000189__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000189__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1991000194__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000189__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000194__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1991000194__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1361 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1363 lang.IFn; _ = ___3; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = t.F_b__1991000190; var arg_1365 any; var root_1366 any = A_arbace_j2g_embed_A_const_97.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = t.F_alias; var arg_1370 any = n__4; if linked_1367 == nil { arg_1365 = ifn_1368.Invoke_O_O__O(arg_1369, arg_1370) } else { arg_1365 = linked_1367.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1366, arg_1369, arg_1370) }; if linked_1362 == nil { ifn_1363.Invoke_O_O__O(arg_1364, arg_1365) } else { linked_1362.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1361, arg_1364, arg_1365) }; i__1991000189__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000189__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A) Invoke_O_O__O(self, s__1991000205__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_New_O_O(s__1991000205__1, self); var tmp2 *jrt.Class; var fncls__1618 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class; if fncls__1618 == nil { var fncls__1618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class = fncls__1618d; tmp2 = fncls__1618d } else { tmp2 = fncls__1618 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :240:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A{}; t.Ctor_O_O(p0, p1); return t }
//line :240:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A) Ctor_O_O(c__s__1991000205, c__iter__1991000204 any) { t.F_s__1991000205 = c__s__1991000205; t.F_iter__1991000204 = c__iter__1991000204 }
//line :240:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A) Invoke_O__O(self any) any { { var s__1991000205__1 any; var t_ any = t.F_s__1991000205; t.F_s__1991000205 = nil; s__1991000205__1 = t_; for { var temp__1927000414__auto____2 any; var root_1429 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = s__1991000205__1; if linked_1430 == nil { temp__1927000414__auto____2 = ifn_1431.Invoke_O__O(arg_1432) } else { temp__1927000414__auto____2 = linked_1430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1429, arg_1432) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1433 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = s__1991000205__3; if linked_1434 == nil { tmp1 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp1 = linked_1434.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1433, arg_1436) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1437 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = s__1991000205__3; if linked_1438 == nil { c__1927001037__auto____4 = ifn_1439.Invoke_O__O(arg_1440) } else { c__1927001037__auto____4 = linked_1438.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1437, arg_1440) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000207__6 any; var root_1441 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1442 == nil { b__1991000207__6 = ifn_1443.Invoke_O__O(arg_1444) } else { b__1991000207__6 = linked_1442.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1441, arg_1444) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_New_O_I_O(b__1991000207__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1516 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class; if fncls__1516 == nil { var fncls__1516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class = fncls__1516d; tmp3 = fncls__1516d } else { tmp3 = fncls__1516 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1517 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any; var root_1522 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = b__1991000207__6; if linked_1523 == nil { arg_1520 = ifn_1524.Invoke_O__O(arg_1525) } else { arg_1520 = linked_1523.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1522, arg_1525) }; var arg_1521 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000204); var tmp5 any; var root_1526 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = s__1991000205__3; if linked_1527 == nil { tmp5 = ifn_1528.Invoke_O__O(arg_1529) } else { tmp5 = linked_1527.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1526, arg_1529) }; arg_1521 = tmp4.Invoke_O__O(tmp5); if linked_1518 == nil { return ifn_1519.Invoke_O_O__O(arg_1520, arg_1521) } else { return linked_1518.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1517, arg_1520, arg_1521) } } else { var root_1530 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any; var root_1535 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = b__1991000207__6; if linked_1536 == nil { arg_1533 = ifn_1537.Invoke_O__O(arg_1538) } else { arg_1533 = linked_1536.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1535, arg_1538) }; var arg_1534 any; if linked_1531 == nil { return ifn_1532.Invoke_O_O__O(arg_1533, arg_1534) } else { return linked_1531.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1530, arg_1533, arg_1534) } } } else { var part__4 any; var root_1539 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = s__1991000205__3; if linked_1540 == nil { part__4 = ifn_1541.Invoke_O__O(arg_1542) } else { part__4 = linked_1540.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1539, arg_1542) }; var root_1543 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_103; var tmp8 any = A_arbace_j2g_embed_A_const_104; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_embed_A_const_105; var tmp12 any; var root_1548 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1550 lang.IFn


	if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var arg_1552 any = A_arbace_j2g_embed_A_const_106; var arg_1553 any = A_arbace_j2g_embed_A_const_110; var arg_1554 any; var iter__1927001039__auto____5 any; var tmp13 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_New(); var tmp14 *jrt.Class; var fncls__1613 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class
	if fncls__1613 == nil { var fncls__1613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class = fncls__1613d; tmp14 = fncls__1613d } else { tmp14 = fncls__1613 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_1554 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(part__4)
//line :243:1
	if linked_1549 == nil { tmp12 = ifn_1550.Invoke_O_O_O_O__O(arg_1551, arg_1552, arg_1553, arg_1554) } else { tmp12 = linked_1549.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1548, arg_1551, arg_1552, arg_1553, arg_1554) }
//line :241:1
	arg_1546 = tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12))
//line :240:1
	var arg_1547 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1991000204); var tmp16 any; var root_1614 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = s__1991000205__3; if linked_1615 == nil { tmp16 = ifn_1616.Invoke_O__O(arg_1617) } else { tmp16 = linked_1615.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1614, arg_1617) }; arg_1547 = tmp15.Invoke_O__O(tmp16); if linked_1544 == nil { return ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { return linked_1544.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :240:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :240:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A) Ctor_O_I_O(c__b__1991000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000207 = c__b__1991000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :240:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A) Invoke_O__O(self any) any { { var i__1991000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var part__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000206__1)); var root_1445 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = t.F_b__1991000207; var arg_1449 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_103; var tmp4 any = A_arbace_j2g_embed_A_const_104; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_105; var tmp8 any; var root_1450 any = A_arbace_j2g_embed_A_const_83.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1452 lang.IFn


	if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = A_arbace_j2g_embed_A_const_99.GetRawRoot__O(); var arg_1454 any = A_arbace_j2g_embed_A_const_106; var arg_1455 any = A_arbace_j2g_embed_A_const_107; var arg_1456 any; var iter__1927001039__auto____3 any; var tmp9 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_New(); var tmp10 *jrt.Class; var fncls__1515 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class
	if fncls__1515 == nil { var fncls__1515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class = fncls__1515d; tmp10 = fncls__1515d } else { tmp10 = fncls__1515 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_1456 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(part__2)
//line :243:1
	if linked_1451 == nil { tmp8 = ifn_1452.Invoke_O_O_O_O__O(arg_1453, arg_1454, arg_1455, arg_1456) } else { tmp8 = linked_1451.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1450, arg_1453, arg_1454, arg_1455, arg_1456) }
//line :241:1
	arg_1449 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))
//line :240:1
	if linked_1446 == nil { ifn_1447.Invoke_O_O__O(arg_1448, arg_1449) } else { linked_1446.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1445, arg_1448, arg_1449) }; i__1991000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A) Ctor() {}
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A) Invoke_O_O__O(self, s__1991000212__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_New_O_O(s__1991000212__1, self); var tmp2 *jrt.Class; var fncls__1514 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class; if fncls__1514 == nil { var fncls__1514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class = fncls__1514d; tmp2 = fncls__1514d } else { tmp2 = fncls__1514 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :244:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A{}; t.Ctor_O_O(p0, p1); return t }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A) Ctor_O_O(c__s__1991000212, c__iter__1991000211 any) { t.F_s__1991000212 = c__s__1991000212; t.F_iter__1991000211 = c__iter__1991000211 }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A) Invoke_O__O(self any) any { { var s__1991000212__1 any; var t_ any = t.F_s__1991000212; t.F_s__1991000212 = nil; s__1991000212__1 = t_; for { var temp__1927000414__auto____2 any; var root_1457 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = s__1991000212__1; if linked_1458 == nil { temp__1927000414__auto____2 = ifn_1459.Invoke_O__O(arg_1460) } else { temp__1927000414__auto____2 = linked_1458.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1457, arg_1460) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000212__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1461 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = s__1991000212__3; if linked_1462 == nil { tmp1 = ifn_1463.Invoke_O__O(arg_1464) } else { tmp1 = linked_1462.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1461, arg_1464) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1465 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = s__1991000212__3; if linked_1466 == nil { c__1927001037__auto____4 = ifn_1467.Invoke_O__O(arg_1468) } else { c__1927001037__auto____4 = linked_1466.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1465, arg_1468) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000214__6 any; var root_1469 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1470 == nil { b__1991000214__6 = ifn_1471.Invoke_O__O(arg_1472) } else { b__1991000214__6 = linked_1470.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1469, arg_1472) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_New_O_I_O(b__1991000214__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1478 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class; if fncls__1478 == nil { var fncls__1478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class = fncls__1478d; tmp3 = fncls__1478d } else { tmp3 = fncls__1478 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1479 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any; var root_1484 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = b__1991000214__6; if linked_1485 == nil { arg_1482 = ifn_1486.Invoke_O__O(arg_1487) } else { arg_1482 = linked_1485.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1484, arg_1487) }; var arg_1483 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); var tmp5 any; var root_1488 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = s__1991000212__3; if linked_1489 == nil { tmp5 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp5 = linked_1489.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1488, arg_1491) }; arg_1483 = tmp4.Invoke_O__O(tmp5); if linked_1480 == nil { return ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { return linked_1480.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) } } else { var root_1492 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any; var root_1497 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = b__1991000214__6; if linked_1498 == nil { arg_1495 = ifn_1499.Invoke_O__O(arg_1500) } else { arg_1495 = linked_1498.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1497, arg_1500) }; var arg_1496 any; if linked_1493 == nil { return ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { return linked_1493.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) } } } else { var t__4 any; var root_1501 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = s__1991000212__3; if linked_1502 == nil { t__4 = ifn_1503.Invoke_O__O(arg_1504) } else { t__4 = linked_1502.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1501, arg_1504) }; var root_1505 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_108; var arg_1508 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__4)); var arg_1509 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000211); var tmp9 any; var root_1510 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = s__1991000212__3; if linked_1511 == nil { tmp9 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp9 = linked_1511.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1510, arg_1513) }; arg_1509 = tmp8.Invoke_O__O(tmp9); if linked_1506 == nil { return ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { return linked_1506.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :244:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A) Ctor_O_I_O(c__b__1991000214 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000214 = c__b__1991000214; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A) Invoke_O__O(self any) any { { var i__1991000213__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000213__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000213__1)); var root_1473 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = t.F_b__1991000214; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_108; var arg_1477 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__2)); if linked_1474 == nil { ifn_1475.Invoke_O_O__O(arg_1476, arg_1477) } else { linked_1474.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1473, arg_1476, arg_1477) }; i__1991000213__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000213__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :244:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_New() *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A) Ctor() {}
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A) Invoke_O_O__O(self, s__1991000223__1 any) any { var tmp1 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_New_O_O(s__1991000223__1, self); var tmp2 *jrt.Class; var fncls__1612 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class; if fncls__1612 == nil { var fncls__1612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class = fncls__1612d; tmp2 = fncls__1612d } else { tmp2 = fncls__1612 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :244:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_New_O_O(p0, p1 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A{}; t.Ctor_O_O(p0, p1); return t }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A) Ctor_O_O(c__s__1991000223, c__iter__1991000222 any) { t.F_s__1991000223 = c__s__1991000223; t.F_iter__1991000222 = c__iter__1991000222 }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A) Invoke_O__O(self any) any { { var s__1991000223__1 any; var t_ any = t.F_s__1991000223; t.F_s__1991000223 = nil; s__1991000223__1 = t_; for { var temp__1927000414__auto____2 any; var root_1555 any = A_arbace_j2g_embed_A_const_13.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = s__1991000223__1; if linked_1556 == nil { temp__1927000414__auto____2 = ifn_1557.Invoke_O__O(arg_1558) } else { temp__1927000414__auto____2 = linked_1556.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1555, arg_1558) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1991000223__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1559 any = A_arbace_j2g_embed_A_const_14.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = s__1991000223__3; if linked_1560 == nil { tmp1 = ifn_1561.Invoke_O__O(arg_1562) } else { tmp1 = linked_1560.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1559, arg_1562) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1563 any = A_arbace_j2g_embed_A_const_15.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = s__1991000223__3; if linked_1564 == nil { c__1927001037__auto____4 = ifn_1565.Invoke_O__O(arg_1566) } else { c__1927001037__auto____4 = linked_1564.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1563, arg_1566) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1991000225__6 any; var root_1567 any = A_arbace_j2g_embed_A_const_16.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1568 == nil { b__1991000225__6 = ifn_1569.Invoke_O__O(arg_1570) } else { b__1991000225__6 = linked_1568.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1567, arg_1570) }; var tmp2 any = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_New_O_I_O(b__1991000225__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1576 *jrt.Class = A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class; if fncls__1576 == nil { var fncls__1576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class = fncls__1576d; tmp3 = fncls__1576d } else { tmp3 = fncls__1576 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1577 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any; var root_1582 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = b__1991000225__6; if linked_1583 == nil { arg_1580 = ifn_1584.Invoke_O__O(arg_1585) } else { arg_1580 = linked_1583.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1582, arg_1585) }; var arg_1581 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1991000222); var tmp5 any; var root_1586 any = A_arbace_j2g_embed_A_const_26.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = s__1991000223__3; if linked_1587 == nil { tmp5 = ifn_1588.Invoke_O__O(arg_1589) } else { tmp5 = linked_1587.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1586, arg_1589) }; arg_1581 = tmp4.Invoke_O__O(tmp5); if linked_1578 == nil { return ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { return linked_1578.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) } } else { var root_1590 any = A_arbace_j2g_embed_A_const_24.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any; var root_1595 any = A_arbace_j2g_embed_A_const_25.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = b__1991000225__6; if linked_1596 == nil { arg_1593 = ifn_1597.Invoke_O__O(arg_1598) } else { arg_1593 = linked_1596.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1595, arg_1598) }; var arg_1594 any; if linked_1591 == nil { return ifn_1592.Invoke_O_O__O(arg_1593, arg_1594) } else { return linked_1591.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1590, arg_1593, arg_1594) } } } else { var t__4 any; var root_1599 any = A_arbace_j2g_embed_A_const_27.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = s__1991000223__3; if linked_1600 == nil { t__4 = ifn_1601.Invoke_O__O(arg_1602) } else { t__4 = linked_1600.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1599, arg_1602) }; var root_1603 any = A_arbace_j2g_embed_A_const_28.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_embed_A_const_108; var arg_1606 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__4)); var arg_1607 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1991000222); var tmp9 any; var root_1608 any = A_arbace_j2g_embed_A_const_29.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = s__1991000223__3; if linked_1609 == nil { tmp9 = ifn_1610.Invoke_O__O(arg_1611) } else { tmp9 = linked_1609.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1608, arg_1611) }; arg_1607 = tmp8.Invoke_O__O(tmp9); if linked_1604 == nil { return ifn_1605.Invoke_O_O__O(arg_1606, arg_1607) } else { return linked_1604.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1603, arg_1606, arg_1607) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :244:1
func A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A) Ctor_O_I_O(c__b__1991000225 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1991000225 = c__b__1991000225; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :244:1
func (t *A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A) Invoke_O__O(self any) any { { var i__1991000224__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1991000224__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1991000224__1)); var root_1571 any = A_arbace_j2g_embed_A_const_22.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = t.F_b__1991000225; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_embed_A_const_108; var arg_1575 any = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_embed_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_embed_A_const_109, t__2)); if linked_1572 == nil { ifn_1573.Invoke_O_O__O(arg_1574, arg_1575) } else { linked_1572.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1571, arg_1574, arg_1575) }; i__1991000224__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1991000224__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





















































































































































































































type A_arbace_j2g_embed_A struct{ jrt.Object }

var A_arbace_j2g_embed_A_const_pool *jrt.RefArray

var A_arbace_j2g_embed_A_const_0 *lang.Var

var A_arbace_j2g_embed_A_const_1 any

var A_arbace_j2g_embed_A_const_2 *lang.Var

var A_arbace_j2g_embed_A_const_3 any

var A_arbace_j2g_embed_A_const_4 any

var A_arbace_j2g_embed_A_const_5 any

var A_arbace_j2g_embed_A_const_6 any

var A_arbace_j2g_embed_A_const_7 *lang.Var

var A_arbace_j2g_embed_A_const_8 *lang.Var

var A_arbace_j2g_embed_A_const_9 *lang.Var

var A_arbace_j2g_embed_A_const_10 *lang.Var

var A_arbace_j2g_embed_A_const_11 any

var A_arbace_j2g_embed_A_const_12 *lang.Var

var A_arbace_j2g_embed_A_const_13 *lang.Var

var A_arbace_j2g_embed_A_const_14 *lang.Var

var A_arbace_j2g_embed_A_const_15 *lang.Var

var A_arbace_j2g_embed_A_const_16 *lang.Var

var A_arbace_j2g_embed_A_const_17 *lang.Var

var A_arbace_j2g_embed_A_const_18 *lang.Var

var A_arbace_j2g_embed_A_const_19 *lang.Var

var A_arbace_j2g_embed_A_const_20 *lang.Var

var A_arbace_j2g_embed_A_const_21 *lang.Var

var A_arbace_j2g_embed_A_const_22 *lang.Var

var A_arbace_j2g_embed_A_const_23 *lang.Var

var A_arbace_j2g_embed_A_const_24 *lang.Var

var A_arbace_j2g_embed_A_const_25 *lang.Var

var A_arbace_j2g_embed_A_const_26 *lang.Var

var A_arbace_j2g_embed_A_const_27 *lang.Var

var A_arbace_j2g_embed_A_const_28 *lang.Var

var A_arbace_j2g_embed_A_const_29 *lang.Var

var A_arbace_j2g_embed_A_const_30 *lang.Var

var A_arbace_j2g_embed_A_const_31 *lang.Var

var A_arbace_j2g_embed_A_const_32 *lang.Var

var A_arbace_j2g_embed_A_const_33 any

var A_arbace_j2g_embed_A_const_34 *lang.Var

var A_arbace_j2g_embed_A_const_35 any

var A_arbace_j2g_embed_A_const_36 *lang.Var

var A_arbace_j2g_embed_A_const_37 *lang.Var

var A_arbace_j2g_embed_A_const_38 *lang.Var

var A_arbace_j2g_embed_A_const_39 *lang.Var

var A_arbace_j2g_embed_A_const_40 *lang.Var

var A_arbace_j2g_embed_A_const_41 *lang.Keyword

var A_arbace_j2g_embed_A_const_42 *lang.Var

var A_arbace_j2g_embed_A_const_43 *lang.Var

var A_arbace_j2g_embed_A_const_44 *lang.Var

var A_arbace_j2g_embed_A_const_45 *lang.Var

var A_arbace_j2g_embed_A_const_46 *lang.Var

var A_arbace_j2g_embed_A_const_47 *lang.Var

var A_arbace_j2g_embed_A_const_48 any

var A_arbace_j2g_embed_A_const_49 *lang.Var

var A_arbace_j2g_embed_A_const_50 any

var A_arbace_j2g_embed_A_const_51 *lang.Keyword

var A_arbace_j2g_embed_A_const_52 *lang.Var

var A_arbace_j2g_embed_A_const_53 *lang.Var

var A_arbace_j2g_embed_A_const_54 *lang.Var

var A_arbace_j2g_embed_A_const_55 *lang.Var

var A_arbace_j2g_embed_A_const_56 *lang.Var

var A_arbace_j2g_embed_A_const_57 *lang.Var

var A_arbace_j2g_embed_A_const_58 *lang.Var

var A_arbace_j2g_embed_A_const_59 *lang.Var

var A_arbace_j2g_embed_A_const_60 *lang.Var

var A_arbace_j2g_embed_A_const_61 *lang.Var

var A_arbace_j2g_embed_A_const_62 *lang.Var

var A_arbace_j2g_embed_A_const_63 *lang.Var

var A_arbace_j2g_embed_A_const_64 *lang.Var

var A_arbace_j2g_embed_A_const_65 *lang.Var

var A_arbace_j2g_embed_A_const_66 *lang.Var

var A_arbace_j2g_embed_A_const_67 *lang.Var

var A_arbace_j2g_embed_A_const_68 *lang.Var

var A_arbace_j2g_embed_A_const_69 *lang.Var

var A_arbace_j2g_embed_A_const_70 *lang.Var

var A_arbace_j2g_embed_A_const_71 *lang.Var

var A_arbace_j2g_embed_A_const_72 *lang.Var

var A_arbace_j2g_embed_A_const_73 *lang.Var

var A_arbace_j2g_embed_A_const_74 *lang.Var

var A_arbace_j2g_embed_A_const_75 *lang.Var

var A_arbace_j2g_embed_A_const_76 *lang.Var

var A_arbace_j2g_embed_A_const_77 any

var A_arbace_j2g_embed_A_const_78 any

var A_arbace_j2g_embed_A_const_79 *lang.Var

var A_arbace_j2g_embed_A_const_80 *lang.Keyword

var A_arbace_j2g_embed_A_const_81 *lang.Var

var A_arbace_j2g_embed_A_const_82 *lang.Var

var A_arbace_j2g_embed_A_const_83 *lang.Var

var A_arbace_j2g_embed_A_const_84 *lang.Var

var A_arbace_j2g_embed_A_const_85 *lang.Var

var A_arbace_j2g_embed_A_const_86 *lang.Var

var A_arbace_j2g_embed_A_const_87 *lang.Var

var A_arbace_j2g_embed_A_const_88 *lang.Var

var A_arbace_j2g_embed_A_const_89 *lang.Var

var A_arbace_j2g_embed_A_const_90 *lang.Var

var A_arbace_j2g_embed_A_const_91 *lang.Var

var A_arbace_j2g_embed_A_const_92 *lang.Var

var A_arbace_j2g_embed_A_const_93 any

var A_arbace_j2g_embed_A_const_94 *lang.Var

var A_arbace_j2g_embed_A_const_95 *lang.Keyword

var A_arbace_j2g_embed_A_const_96 any

var A_arbace_j2g_embed_A_const_97 *lang.Var

var A_arbace_j2g_embed_A_const_98 *lang.Var

var A_arbace_j2g_embed_A_const_99 *lang.Var

var A_arbace_j2g_embed_A_const_100 any

var A_arbace_j2g_embed_A_const_101 *lang.Keyword

var A_arbace_j2g_embed_A_const_102 any

var A_arbace_j2g_embed_A_const_103 any

var A_arbace_j2g_embed_A_const_104 any

var A_arbace_j2g_embed_A_const_105 any

var A_arbace_j2g_embed_A_const_106 any

var A_arbace_j2g_embed_A_const_107 any

var A_arbace_j2g_embed_A_const_108 any

var A_arbace_j2g_embed_A_const_109 any

var A_arbace_j2g_embed_A_const_110 any

var A_arbace_j2g_embed_A_const_111 *lang.Var

var A_arbace_j2g_embed_A_const_112 any

var A_arbace_j2g_embed_A_const_113 any

var A_arbace_j2g_embed_A_init jrt.ClassInit

func A_arbace_j2g_embed_A_Init() { if !A_arbace_j2g_embed_A_init.Done() { A_arbace_j2g_embed_A_init.Run(A_arbace_j2g_embed_A_clinit) } }

func A_arbace_j2g_embed_A_clinit() { A_arbace_j2g_embed_A_clinit_p0(); A_arbace_j2g_embed_A_clinit_p1(); A_arbace_j2g_embed_A_clinit_p2(); A_arbace_j2g_embed_A_clinit_p3(); A_arbace_j2g_embed_A_clinit_p4(); A_arbace_j2g_embed_A_clinit_p5(); A_arbace_j2g_embed_A_clinit_p6(); A_arbace_j2g_embed_A_clinit_p7(); A_arbace_j2g_embed_A_clinit_p8(); A_arbace_j2g_embed_A_clinit_p9() }

func A_arbace_j2g_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 147); A_arbace_j2g_embed_A_const_0 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[33]); A_arbace_j2g_embed_A_const_1 = A_arbace_j2g_embed_A_const_pool.A[34]; A_arbace_j2g_embed_A_const_2 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[35]); A_arbace_j2g_embed_A_const_3 = A_arbace_j2g_embed_A_const_pool.A[36]; A_arbace_j2g_embed_A_const_4 = A_arbace_j2g_embed_A_const_pool.A[37]; A_arbace_j2g_embed_A_const_5 = A_arbace_j2g_embed_A_const_pool.A[38]; A_arbace_j2g_embed_A_const_6 = A_arbace_j2g_embed_A_const_pool.A[39]; A_arbace_j2g_embed_A_const_7 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[40]); A_arbace_j2g_embed_A_const_8 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[41]); A_arbace_j2g_embed_A_const_9 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[42]); A_arbace_j2g_embed_A_const_10 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[43]); A_arbace_j2g_embed_A_const_11 = A_arbace_j2g_embed_A_const_pool.A[44] }

func A_arbace_j2g_embed_A_clinit_p1() { A_arbace_j2g_embed_A_const_12 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[45]); A_arbace_j2g_embed_A_const_13 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[46]); A_arbace_j2g_embed_A_const_14 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[47]); A_arbace_j2g_embed_A_const_15 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[48]); A_arbace_j2g_embed_A_const_16 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[49]); A_arbace_j2g_embed_A_const_17 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[50]); A_arbace_j2g_embed_A_const_18 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[51]); A_arbace_j2g_embed_A_const_19 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[52]); A_arbace_j2g_embed_A_const_20 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[53]); A_arbace_j2g_embed_A_const_21 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[54]); A_arbace_j2g_embed_A_const_22 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[55]); A_arbace_j2g_embed_A_const_23 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[56]) }

func A_arbace_j2g_embed_A_clinit_p2() { A_arbace_j2g_embed_A_const_24 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[57]); A_arbace_j2g_embed_A_const_25 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[58]); A_arbace_j2g_embed_A_const_26 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[59]); A_arbace_j2g_embed_A_const_27 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[60]); A_arbace_j2g_embed_A_const_28 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[61]); A_arbace_j2g_embed_A_const_29 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[62]); A_arbace_j2g_embed_A_const_30 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[63]); A_arbace_j2g_embed_A_const_31 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[64]); A_arbace_j2g_embed_A_const_32 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[65]); A_arbace_j2g_embed_A_const_33 = A_arbace_j2g_embed_A_const_pool.A[66]; A_arbace_j2g_embed_A_const_34 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[67]); A_arbace_j2g_embed_A_const_35 = A_arbace_j2g_embed_A_const_pool.A[68] }

func A_arbace_j2g_embed_A_clinit_p3() { A_arbace_j2g_embed_A_const_36 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[69]); A_arbace_j2g_embed_A_const_37 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[70]); A_arbace_j2g_embed_A_const_38 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[71]); A_arbace_j2g_embed_A_const_39 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[72]); A_arbace_j2g_embed_A_const_40 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[73]); A_arbace_j2g_embed_A_const_41 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[74]); A_arbace_j2g_embed_A_const_42 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[75]); A_arbace_j2g_embed_A_const_43 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[76]); A_arbace_j2g_embed_A_const_44 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[77]); A_arbace_j2g_embed_A_const_45 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[78]); A_arbace_j2g_embed_A_const_46 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[79]); A_arbace_j2g_embed_A_const_47 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[80]) }

func A_arbace_j2g_embed_A_clinit_p4() { A_arbace_j2g_embed_A_const_48 = A_arbace_j2g_embed_A_const_pool.A[81]; A_arbace_j2g_embed_A_const_49 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[82]); A_arbace_j2g_embed_A_const_50 = A_arbace_j2g_embed_A_const_pool.A[83]; A_arbace_j2g_embed_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[84]); A_arbace_j2g_embed_A_const_52 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[85]); A_arbace_j2g_embed_A_const_53 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[86]); A_arbace_j2g_embed_A_const_54 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[87]); A_arbace_j2g_embed_A_const_55 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[88]); A_arbace_j2g_embed_A_const_56 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[89]); A_arbace_j2g_embed_A_const_57 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[90]); A_arbace_j2g_embed_A_const_58 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[91]); A_arbace_j2g_embed_A_const_59 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[92]) }

func A_arbace_j2g_embed_A_clinit_p5() { A_arbace_j2g_embed_A_const_60 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[93]); A_arbace_j2g_embed_A_const_61 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[94]); A_arbace_j2g_embed_A_const_62 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[95]); A_arbace_j2g_embed_A_const_63 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[96]); A_arbace_j2g_embed_A_const_64 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[97]); A_arbace_j2g_embed_A_const_65 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[98]); A_arbace_j2g_embed_A_const_66 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[99]); A_arbace_j2g_embed_A_const_67 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[100]); A_arbace_j2g_embed_A_const_68 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[101]); A_arbace_j2g_embed_A_const_69 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[102]); A_arbace_j2g_embed_A_const_70 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[103]); A_arbace_j2g_embed_A_const_71 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[104]) }

func A_arbace_j2g_embed_A_clinit_p6() { A_arbace_j2g_embed_A_const_72 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[105]); A_arbace_j2g_embed_A_const_73 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[106]); A_arbace_j2g_embed_A_const_74 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[107]); A_arbace_j2g_embed_A_const_75 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[108]); A_arbace_j2g_embed_A_const_76 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[109]); A_arbace_j2g_embed_A_const_77 = A_arbace_j2g_embed_A_const_pool.A[110]; A_arbace_j2g_embed_A_const_78 = A_arbace_j2g_embed_A_const_pool.A[111]; A_arbace_j2g_embed_A_const_79 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[112]); A_arbace_j2g_embed_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[113]); A_arbace_j2g_embed_A_const_81 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[114]); A_arbace_j2g_embed_A_const_82 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[115]); A_arbace_j2g_embed_A_const_83 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[116]) }

func A_arbace_j2g_embed_A_clinit_p7() { A_arbace_j2g_embed_A_const_84 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[117]); A_arbace_j2g_embed_A_const_85 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[118]); A_arbace_j2g_embed_A_const_86 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[119]); A_arbace_j2g_embed_A_const_87 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[120]); A_arbace_j2g_embed_A_const_88 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[121]); A_arbace_j2g_embed_A_const_89 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[122]); A_arbace_j2g_embed_A_const_90 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[123]); A_arbace_j2g_embed_A_const_91 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[124]); A_arbace_j2g_embed_A_const_92 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[125]); A_arbace_j2g_embed_A_const_93 = A_arbace_j2g_embed_A_const_pool.A[126]; A_arbace_j2g_embed_A_const_94 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[127]); A_arbace_j2g_embed_A_const_95 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[128]) }

func A_arbace_j2g_embed_A_clinit_p8() { A_arbace_j2g_embed_A_const_96 = A_arbace_j2g_embed_A_const_pool.A[129]; A_arbace_j2g_embed_A_const_97 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[130]); A_arbace_j2g_embed_A_const_98 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[131]); A_arbace_j2g_embed_A_const_99 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[132]); A_arbace_j2g_embed_A_const_100 = A_arbace_j2g_embed_A_const_pool.A[133]; A_arbace_j2g_embed_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_embed_A_const_pool.A[134]); A_arbace_j2g_embed_A_const_102 = A_arbace_j2g_embed_A_const_pool.A[135]; A_arbace_j2g_embed_A_const_103 = A_arbace_j2g_embed_A_const_pool.A[136]; A_arbace_j2g_embed_A_const_104 = A_arbace_j2g_embed_A_const_pool.A[137]; A_arbace_j2g_embed_A_const_105 = A_arbace_j2g_embed_A_const_pool.A[138]; A_arbace_j2g_embed_A_const_106 = A_arbace_j2g_embed_A_const_pool.A[139]; A_arbace_j2g_embed_A_const_107 = A_arbace_j2g_embed_A_const_pool.A[140]; A_arbace_j2g_embed_A_const_108 = A_arbace_j2g_embed_A_const_pool.A[141]; A_arbace_j2g_embed_A_const_109 = A_arbace_j2g_embed_A_const_pool.A[142] }

func A_arbace_j2g_embed_A_clinit_p9() { A_arbace_j2g_embed_A_const_110 = A_arbace_j2g_embed_A_const_pool.A[143]; A_arbace_j2g_embed_A_const_111 = lang.Var_Cast(A_arbace_j2g_embed_A_const_pool.A[144]); A_arbace_j2g_embed_A_const_112 = A_arbace_j2g_embed_A_const_pool.A[145]; A_arbace_j2g_embed_A_const_113 = A_arbace_j2g_embed_A_const_pool.A[146] }

func A_arbace_j2g_embed_A_New() *A_arbace_j2g_embed_A { A_arbace_j2g_embed_A_Init(); t := &A_arbace_j2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_A) Ctor() {}

func (t *A_arbace_j2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_A_class }

func (t *A_arbace_j2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_A); return ok }

func A_arbace_j2g_embed_A_Cast(x any) *A_arbace_j2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_A_class)) }; return v }



type A_arbace_j2g_embed_class_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_class_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_fn__1991000103_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_fn__1991000103_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A struct{ j2g_header uint64; F_s__1991000089, F_iter__1991000088 any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A struct{ j2g_header uint64; F_b__1991000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000094_fn__1991000095_A_fn_class *jrt.Class



type A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_cut_candidates_iter__1991000088__1991000092_fn__1991000093_fn__1991000098_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_data_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A struct{ j2g_header uint64; F_base, F_s__1991000153, F_iter__1991000152 any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_A_fn_class *jrt.Class



type A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A struct{ j2g_header uint64; F_base any; F_size__1927001038__auto__ int32; F_b__1991000155, F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_data_iter__1991000152__1991000156_fn__1991000157_fn__1991000158_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000004_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000004_A_New() *A_arbace_j2g_embed_eval1991000004_A { t := &A_arbace_j2g_embed_eval1991000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000004_A_class }

func (t *A_arbace_j2g_embed_eval1991000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); return ok }

func A_arbace_j2g_embed_eval1991000004_A_Cast(x any) *A_arbace_j2g_embed_eval1991000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000004_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class *jrt.Class



type A_arbace_j2g_embed_eval1991000008_A struct{ jrt.Object }

func A_arbace_j2g_embed_eval1991000008_A_New() *A_arbace_j2g_embed_eval1991000008_A { t := &A_arbace_j2g_embed_eval1991000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) Ctor() {}

func (t *A_arbace_j2g_embed_eval1991000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_eval1991000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_eval1991000008_A_class }

func (t *A_arbace_j2g_embed_eval1991000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_eval1991000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_eval1991000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); return ok }

func A_arbace_j2g_embed_eval1991000008_A_Cast(x any) *A_arbace_j2g_embed_eval1991000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_eval1991000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_eval1991000008_A_class)) }; return v }



type A_arbace_j2g_embed_eval1991000008_fn__1991000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_A struct{ j2g_header uint64; F_re any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A struct{ j2g_header uint64; F_alias, F_s__1991000188, F_iter__1991000187 any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A struct{ j2g_header uint64; F_alias, F_b__1991000190 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_fn__1991000183_iter__1991000187__1991000191_fn__1991000192_fn__1991000193_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A struct{ j2g_header uint64; F_prog_dir any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A struct{ j2g_header uint64; F_prog_dir, F_s__1991000164, F_iter__1991000163 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A struct{ j2g_header uint64; F_alias any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A struct{ j2g_header uint64; F_alias, F_s__1991000166, F_iter__1991000165 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A struct{ j2g_header uint64; F_alias any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1991000168 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000163__1991000169_fn__1991000170_iter__1991000165__1991000174_fn__1991000175_fn__1991000176_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A struct{ j2g_header uint64; F_s__1991000205, F_iter__1991000204 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A struct{ j2g_header uint64; F_b__1991000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A struct{ j2g_header uint64; F_s__1991000212, F_iter__1991000211 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A struct{ j2g_header uint64; F_b__1991000214 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_fn__1991000210_iter__1991000211__1991000215_fn__1991000216_fn__1991000217_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A struct{ j2g_header uint64; F_s__1991000223, F_iter__1991000222 any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_A_fn_class *jrt.Class



type A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A struct{ j2g_header uint64; F_b__1991000225 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_image_type_forms_iter__1991000204__1991000208_fn__1991000209_iter__1991000222__1991000226_fn__1991000227_fn__1991000228_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_names_A_fn_class *jrt.Class



type A_arbace_j2g_embed_names_walk__1991000059_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_embed_names_walk__1991000059_A_fn_class *jrt.Class



type A_arbace_j2g_embed_package_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_package_like_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_A_fn_class *jrt.Class



type A_arbace_j2g_embed_read_all_fn__1991000054_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_read_all_fn__1991000054_A_fn_class *jrt.Class



type A_arbace_j2g_embed_reify__1991000052_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_LispReader_Resolver() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_IObj() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Is_IMeta() {}

func (t *A_arbace_j2g_embed_reify__1991000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed_reify__1991000052_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed_reify__1991000052_A_class }

func (t *A_arbace_j2g_embed_reify__1991000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed_reify__1991000052_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed_reify__1991000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed_reify__1991000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed_reify__1991000052_A); return ok }

func A_arbace_j2g_embed_reify__1991000052_A_Cast(x any) *A_arbace_j2g_embed_reify__1991000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed_reify__1991000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed_reify__1991000052_A_class)) }; return v }



type A_arbace_j2g_embed_sources_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_sources_fn__1991000038_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A struct{ j2g_header uint64; F_p, F_pairs, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A struct{ j2g_header uint64; F_p, F_rel any }

var A_arbace_j2g_embed_sources_fn__1991000038_fn__1991000042_fn__1991000044_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A struct{ j2g_header uint64; F_base, F_s__1991000014, F_iter__1991000013 any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A struct{ j2g_header uint64; F_b__1991000016, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000019_fn__1991000020_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A struct{ j2g_header uint64; F_rel any }

var A_arbace_j2g_embed_sources_iter__1991000013__1991000017_fn__1991000018_fn__1991000023_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A struct{ j2g_header uint64; F_vdir any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A struct{ j2g_header uint64; F_vdir, F_s__1991000028, F_iter__1991000027 any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_A_fn_class *jrt.Class



type A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A struct{ j2g_header uint64; F_vdir, F_b__1991000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_sources_iter__1991000027__1991000031_fn__1991000032_fn__1991000033_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_elem__1991000117_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_elem__1991000117_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A struct{ j2g_header uint64; F_in_world_QMARK_, F_member_types, F_s__1991000134, F_iter__1991000133 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A struct{ j2g_header uint64; F_n, F_member_types any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_fn__1991000147_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A struct{ j2g_header uint64; F_in_world_QMARK_ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A struct{ j2g_header uint64; F_in_world_QMARK_, F_s__1991000136, F_iter__1991000135 any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A struct{ j2g_header uint64; F_b__1991000138, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_iter__1991000133__1991000139_fn__1991000140_iter__1991000135__1991000141_fn__1991000142_fn__1991000143_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_A struct{ j2g_header uint64; F_elem, F_types any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_fn__1991000120_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A struct{ j2g_header uint64; F_s__1991000123, F_iter__1991000122 any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A struct{ j2g_header uint64; F_b__1991000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_embed_with_member_types_member_types__1991000119_iter__1991000122__1991000126_fn__1991000127_fn__1991000128_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000110_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000112_A_fn_class *jrt.Class



type A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A struct{ j2g_header uint64 }

var A_arbace_j2g_embed_with_member_types_types__1991000109_fn__1991000114_A_fn_class *jrt.Class
