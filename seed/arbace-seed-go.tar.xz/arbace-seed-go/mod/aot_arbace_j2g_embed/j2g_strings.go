//line j2g_strings.ae:1
package aot_arbace_j2g_embed

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn15,arbace.j2g.edgeyn4,edgeyn16,arbace.j2g.modelyn1,mkn3,dockn4,elseyn4,userkn3,eofks16,arbace.j2g.embed3,eofkn9,read-condkn5,allowkn6,existskn12,member-typesys2,go4,filekn7,importsyn7,reflectyn3,jrtyn4,langys2,go4,funcyn4,inityn18,registerImageTypesyn3,lityn5,sliceys7,reflect4,Typekn4,linekn6,columnys7,reflect6,TypeOfv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.embedm2,R10,s773,bin/j2g --program: the namespaces' sources the executable embeds (J2G-SPEC §10.3, §10.6;\n  doc/go/EVAL-NOTES.md, \"Loading\"), and the classes they name that are outside the closed\n  world (registered as cut classes, so that imports and hints resolve).\n\n  The embedded tree is arbace/**/*.ae less the JVM-side tools (repr/java, j2g's and the class\n  forms' JVM-only parts), the runtime's Java forms (arbace/lang, compiled into the program), and\n  the namespaces the Go build leaves out (JAVA-SURFACE.md decision 6, B1-PLAN.md D6). The Go build's namespace\n  variants, arbace/lang/go/ns/P.ae, replace arbace/P.ae; arbace/lang/go/ns/P.after.ae is\n  appended to it; arbace/lang/go/ns/P.subst.ae, a vector [old new ...] of strings, replaces\n  each old (found exactly once) in it.v14,arbace.java.io4,filev11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv13,arbace.string10,ends-with?v11,arbace.core3,strv11,arbace.core8,not-any?v13,arbace.string12,starts-with?v16,arbace.j2g.embed8,excludedv11,arbace.core4,somev11,arbace.core12,chunk-appendv11,arbace.core5,slurpv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv16,arbace.j2g.embed12,variants-dirv11,arbace.core6,reducev11,arbace.core4,subsl0,v11,arbace.core9,partitionl2,v11,arbace.core11,read-stringv11,arbace.core6,updatev11,arbace.core4,not=v11,arbace.core7,ex-infov11,arbace.core6,pr-strR11,v11,arbace.core5,assocv11,arbace.core9,contains?v11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core7,sort-byv11,arbace.core8,file-seqR12,v11,arbace.core4,readm4,R13,R14,R15,R16,R14,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core17,*reader-resolver*v16,arbace.j2g.embed8,resolverv11,arbace.core24,*default-data-reader-fn*v11,arbace.core3,notv16,arbace.j2g.embed11,class-like?v11,arbace.core9,transientv11,arbace.core7,symbol?v11,arbace.core9,namespacev11,arbace.core5,conj!v11,arbace.core4,seq?v11,arbace.core7,vector?v11,arbace.core4,map?v11,arbace.core4,set?v11,arbace.core4,namev16,arbace.j2g.embed13,package-like?v11,arbace.core6,every?v11,arbace.core4,nextv11,arbace.core11,persistent!v16,arbace.j2g.embed8,read-allv11,arbace.core3,setv11,arbace.core7,re-findp51,^(java|javax|jdk|sun|org\\.xml\\.sax|org\\.w3c\\.dom)\\.p15,^arbace\\.lang\\.v15,arbace.j2g.edge4,jvm?R17,v13,arbace.string7,replacev11,arbace.core6,concatv11,arbace.core5,applyv16,arbace.j2g.model8,par-mapvv16,arbace.j2g.model4,jobsv16,arbace.j2g.embed5,namesv16,arbace.j2g.embed12,library-cutsv11,arbace.core6,mapcatv11,arbace.core3,mapv11,arbace.core3,vecv11,arbace.core4,sortv11,arbace.core8,distinctp46,^(java|javax|jdk|sun|org/xml/sax|org/w3c/dom)/v15,arbace.j2g.edge3,jvmR18,p16,\\.(ae|clj|cljc)$p22,(?m)^\\(ns\\s+([^\\s()]+)v11,arbace.core6,secondp73,\\(go/type ([A-Z][A-Za-z0-9_]*)\\s+(?:\\\"(?:[^\\\"\\\\]|\\\\.)*\\\"\\s+)?\\(struct[ )]v11,arbace.core6,symbolv11,arbace.core6,re-seqv11,arbace.core4,listR19,R20,V3,V2,R21,s7,reflectV2,R22,s10,arbace/jrtV2,R23,s11,arbace/langR24,R25,R26,R27,ML2,R28,R29,m4,R30,i312,R31,i43,R32,R27,ML2,R28,R29,m4,R30,i312,R31,i43,v11,arbace.core13,partition-alll128,V2,V2,s4,langs4,langV2,s3,jrts3,jrt")

var Lit_1 *jrt.String = jrt.Intern(".")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.embed$cut_candidates$iter__1991000097__1991000101")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.embed$cut_candidates$fn__1991000112")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.embed$cut_candidates$iter__1991000097__1991000101$fn__1991000102")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.embed$cut_candidates$iter__1991000097__1991000101$fn__1991000102$fn__1991000103")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.embed$cut_candidates$iter__1991000097__1991000101$fn__1991000102$fn__1991000107")

var Lit_7 *jrt.String = jrt.Intern("/")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.embed$cut_candidates$iter__1991000097__1991000101$fn__1991000102$fn__1991000103$fn__1991000104")

var Lit_9 *jrt.String = jrt.Intern("arbace.j2g.embed$data$iter__1991000161__1991000165")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.embed$data$iter__1991000161__1991000165$fn__1991000166")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.embed$data$iter__1991000161__1991000165$fn__1991000166$fn__1991000167")

var Lit_12 *jrt.String = jrt.Intern("java.io.File")

var Lit_13 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_14 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_15 *jrt.String = jrt.Intern("arbace.lang.LispReader$Resolver")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000226__1991000232")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$fn__1991000246")

var Lit_18 *jrt.String = jrt.Intern("image_types.go")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$fn__1991000246$iter__1991000250__1991000254")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$fn__1991000246$iter__1991000250__1991000254$fn__1991000255")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$fn__1991000246$iter__1991000250__1991000254$fn__1991000255$fn__1991000256")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000226__1991000232$fn__1991000233")

var Lit_24 *jrt.String = jrt.Intern("go/arbace")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000226__1991000232$fn__1991000233$iter__1991000228__1991000237")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000226__1991000232$fn__1991000233$iter__1991000228__1991000237$fn__1991000238")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000226__1991000232$fn__1991000233$iter__1991000228__1991000237$fn__1991000238$fn__1991000239")

var Lit_28 *jrt.String = jrt.Intern(".ae")

var Lit_29 *jrt.String = jrt.Intern("_test.ae")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272$fn__1991000273")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272$iter__1991000285__1991000289")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272$fn__1991000273$iter__1991000274__1991000278")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272$fn__1991000273$iter__1991000274__1991000278$fn__1991000279")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272$fn__1991000273$iter__1991000274__1991000278$fn__1991000279$fn__1991000280")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272$iter__1991000285__1991000289$fn__1991000290")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms$iter__1991000267__1991000271$fn__1991000272$iter__1991000285__1991000289$fn__1991000290$fn__1991000291")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.embed$names$walk__1991000068")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.embed$package_loaders$iter__1991000209__1991000215")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.embed$package_loaders$iter__1991000209__1991000215$fn__1991000216")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.embed$package_loaders$iter__1991000209__1991000215$fn__1991000216$iter__1991000211__1991000217")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.embed$package_loaders$iter__1991000209__1991000215$fn__1991000216$iter__1991000211__1991000217$fn__1991000218")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.embed$package_loaders$iter__1991000209__1991000215$fn__1991000216$iter__1991000211__1991000217$fn__1991000218$fn__1991000219")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.embed$read_all$fn__1991000063")

var Lit_45 *jrt.String = jrt.Intern("arbace")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000018__1991000022")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000036__1991000040")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$fn__1991000047")

var Lit_49 *jrt.String = jrt.Intern(".subst.ae")

var Lit_50 *jrt.String = jrt.Intern("arbace/")

var Lit_51 *jrt.String = jrt.Intern("j2g: namespace variant ")

var Lit_52 *jrt.String = jrt.Intern(": no ")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$fn__1991000047$fn__1991000051")

var Lit_54 *jrt.String = jrt.Intern(".after.ae")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$fn__1991000047$fn__1991000051$fn__1991000053")

var Lit_56 *jrt.String = jrt.Intern(": ")

var Lit_57 *jrt.String = jrt.Intern(" not found exactly once in ")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000018__1991000022$fn__1991000023")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000018__1991000022$fn__1991000023$fn__1991000024")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000018__1991000022$fn__1991000023$fn__1991000030")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000018__1991000022$fn__1991000023$fn__1991000032")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000018__1991000022$fn__1991000023$fn__1991000024$fn__1991000025")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000018__1991000022$fn__1991000023$fn__1991000024$fn__1991000027")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000036__1991000040$fn__1991000041")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.embed$sources$iter__1991000036__1991000040$fn__1991000041$fn__1991000042")

var Lit_66 *jrt.String = jrt.Intern("=")

var Lit_67 *jrt.String = jrt.Intern("j2g: --resources ")

var Lit_68 *jrt.String = jrt.Intern(": no directory ")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.embed$user_resources$iter__1991000188__1991000192")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.embed$user_resources$fn__1991000200")

var Lit_71 *jrt.String = jrt.Intern(" is embedded already")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.embed$user_resources$iter__1991000188__1991000192$fn__1991000193")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.embed$user_resources$iter__1991000188__1991000192$fn__1991000193$fn__1991000194")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$types__1991000118")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$elem__1991000126")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$member_types__1991000128")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$iter__1991000142__1991000148")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$iter__1991000142__1991000148$fn__1991000149")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$iter__1991000142__1991000148$fn__1991000149$iter__1991000144__1991000150")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$iter__1991000142__1991000148$fn__1991000149$fn__1991000156")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$iter__1991000142__1991000148$fn__1991000149$iter__1991000144__1991000150$fn__1991000151")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$iter__1991000142__1991000148$fn__1991000149$iter__1991000144__1991000150$fn__1991000151$fn__1991000152")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$member_types__1991000128$fn__1991000129")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$member_types__1991000128$iter__1991000131__1991000135")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$member_types__1991000128$iter__1991000131__1991000135$fn__1991000136")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$member_types__1991000128$iter__1991000131__1991000135$fn__1991000136$fn__1991000137")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$types__1991000118$fn__1991000119")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$types__1991000118$fn__1991000121")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types$types__1991000118$fn__1991000123")

var Lit_90 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn8,arglistsyn4,rootyn1,&yn4,alsokn7,privateyn4,textkn3,tagyn6,Stringyn4,srcsyn5,candsyn9,in-world?yn3,diryn5,specsyn5,takenyn4,dirsyn8,prog-dirv11,arbace.core5,in-nsMyn16,arbace.j2g.embedm2,R0,s773,bin/j2g --program: the namespaces' sources the executable embeds (J2G-SPEC §10.3, §10.6;\n  doc/go/EVAL-NOTES.md, \"Loading\"), and the classes they name that are outside the closed\n  world (registered as cut classes, so that imports and hints resolve).\n\n  The embedded tree is arbace/**/*.ae less the JVM-side tools (repr/java, j2g's and the class\n  forms' JVM-only parts), the runtime's Java forms (arbace/lang, compiled into the program), and\n  the namespaces the Go build leaves out (JAVA-SURFACE.md decision 6, B1-PLAN.md D6). The Go build's namespace\n  variants, arbace/lang/go/ns/P.ae, replace arbace/P.ae; arbace/lang/go/ns/P.after.ae is\n  appended to it; arbace/lang/go/ns/P.subst.ae, a vector [old new ...] of strings, replaces\n  each old (found exactly once) in it.m2,R0,s773,bin/j2g --program: the namespaces' sources the executable embeds (J2G-SPEC §10.3, §10.6;\n  doc/go/EVAL-NOTES.md, \"Loading\"), and the classes they name that are outside the closed\n  world (registered as cut classes, so that imports and hints resolve).\n\n  The embedded tree is arbace/**/*.ae less the JVM-side tools (repr/java, j2g's and the class\n  forms' JVM-only parts), the runtime's Java forms (arbace/lang, compiled into the program), and\n  the namespaces the Go build leaves out (JAVA-SURFACE.md decision 6, B1-PLAN.md D6). The Go build's namespace\n  variants, arbace/lang/go/ns/P.ae, replace arbace/P.ae; arbace/lang/go/ns/P.after.ae is\n  appended to it; arbace/lang/go/ns/P.subst.ae, a vector [old new ...] of strings, replaces\n  each old (found exactly once) in it.R1,v16,arbace.j2g.embed8,excludedV30,s21,arbace/classes/jvm.aes19,arbace/repr/java.aes17,arbace/repr/java/s17,arbace/j2g/jvm.aes12,arbace/lang/s22,arbace/repr/haskell.aes20,arbace/repr/haskell/s19,arbace/repr/rust.aes17,arbace/repr/rust/s20,arbace/repr/ocaml.aes18,arbace/repr/ocaml/s21,arbace/repr/scheme.aes19,arbace/repr/scheme/s14,arbace/scheme/s21,arbace/repr/python.aes19,arbace/repr/python/s16,arbace/python.aes14,arbace/python/s18,arbace/repr/cpp.aes16,arbace/repr/cpp/s19,arbace/repr/llvm.aes17,arbace/repr/llvm/s11,arbace/cpp/s18,arbace/go/table.aes14,arbace/lang.aes15,arbace/java/apis19,arbace/repl/deps.aes17,arbace/java/basiss18,arbace/tools/deps/s27,arbace/instant_timestamp.aem8,R2,i19,R3,i1,R4,s19,arbace/j2g/embed.aeR0,s39,Resource paths (prefixes) not embedded.v16,arbace.j2g.embed12,variants-dirm6,R2,i66,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed7,sourcesm10,R5,L1,V3,R6,R7,V1,R8,R0,s245,The embedded sources: {resource-path text}, from the checkout at root; the excluded paths that\n  begin with one of `also` (j2g --embed: javac's tool embeds repr/java's reader,\n  doc/classes/JAVA-FRONTEND-SURVEY.md, \"As built: JN4\") embedded too.R2,i68,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed8,resolverm10,R9,TR2,i113,R3,i1,R4,s19,arbace/j2g/embed.aeR0,s82,Reads ::kw and `sym without the namespaces' aliases (only class names are wanted).v16,arbace.j2g.embed8,read-allm10,R9,TR5,L1,V1,R10,R2,i121,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed11,class-like?m10,R9,TR5,L1,V1,Myn1,sm2,R11,R12,R2,i130,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed13,package-like?m10,R9,TR5,L1,V1,Myn1,sm2,R11,R12,R2,i134,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed5,namesm10,R5,L1,V1,R10,R0,s150,The class names (binary, dotted) the forms of text mention: qualified symbols, the\n  namespace of a qualified symbol, and import lists (pkg Name ...).R2,i137,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed12,library-cutsV4,s21,java.util.jar.JarFiles22,java.util.jar.JarEntrys18,java.io.FileReaders26,java.text.SimpleDateFormatm8,R2,i161,R3,i1,R4,s19,arbace/j2g/embed.aeR0,s582,Classes outside the world that libraries loaded from ARBACE_PATH import, cut as those the\n  embedded sources name are: Clojure's suite's test.generative runner requires\n  clojure.tools.namespace.find and clojure.java.classpath, which import java.util.jar's JarFile\n  and JarEntry and java.io.FileReader (the runner then lists no jars, and reads no files through\n  them); clojure.tools.reader names java.text.SimpleDateFormat (its #inst reader's formatter).\n  (java.net.URLClassLoader, which clojure.java.classpath extends, is in the world since\n  JRT-NOTES.md's \"Resources by URL\".)v16,arbace.j2g.embed14,cut-candidatesm10,R5,L1,V1,R13,R0,s228,The classes the sources name that exist on this JVM (the edge's :exists), from the JDK or arbace.lang\n  (not the classes the namespaces define themselves: deftype, defrecord, definterface), as\n  internal names; and library-cuts.R2,i172,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed17,with-member-typesm10,R5,L1,V2,R14,R15,R0,s226,The cut candidates (internal names) and the JDK classes their public members name that are\n  outside the world (in-world?), one level deep: the cut classes' member tables then name them\n  (Files/createTempFile returns a Path).R2,i187,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed4,datam10,R5,L1,V1,R16,R0,s261,The resource data the executable embeds besides the sources (JRT-NOTES.md, \"The JDK's\n  resource data\"): the files under dir (bin/jrt-convert's .tmp/jrt/data: uniName.dat, ICU's\n  normalization data), {resource-path File}, sorted; empty when dir does not exist.R2,i218,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed14,user-resourcesm10,R5,L1,V2,R17,R18,R0,s551,j2g --resources (bin/arbace-go --build-program, REAP7): a user's program's directories, each\n  DIR or DIR=PREFIX, embedded as directories of the class path: every file under DIR (but those\n  whose name begins with a dot) at its path relative to DIR, after PREFIX/ when given. [srcs\n  data]: the sources (.ae, .clj, .cljc), {resource-path text}, which join the embedded sources,\n  and the other files, {resource-path File}, which join the resource data. A path that taken\n  (the program's own sources and data) or another DIR holds already is an error.R2,i230,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed15,package-loadersm10,R5,L1,V2,R19,R18,R0,s372,j2g --java-namespaces (bin/arbace-go --build-program, REAP7b, RPS93 (c)): the namespaces of\n  the Java packages under each DIR (SPEC.md §9.2: a package's file, its first form (ns P)),\n  {path text}, each a no-op loader (ns P) at its path: the package's classes are the program's,\n  so that a (require 'P) written at the REPL works unchanged. A path taken is left as it is.R2,i259,R3,i1,R4,s19,arbace/j2g/embed.aev16,arbace.j2g.embed11,image-formsm8,R2,i282,R3,i1,R4,s19,arbace/j2g/embed.aeR0,s76,The image's encoding: Go forms of the main package, copied into the program.v16,arbace.j2g.embed12,rlwrap-formsV2,s36,go/arbace/cmd/arbace/rlwrap_linux.aes36,go/arbace/cmd/arbace/rlwrap_other.aem8,R2,i286,R3,i1,R4,s19,arbace/j2g/embed.aeR0,s185,The interactive REPL under rlwrap (EXEC-NOTES.md, \"Line editing: rlwrap\"): Go forms of the\n  main package, copied into the program, Linux's and the other systems' (an empty execRlwrap).v16,arbace.j2g.embed16,image-type-formsm10,R5,L1,V1,R20,R0,s232,The main package's table of the program's struct types (image_types.go): every exported,\n  non-generic struct type of arbace/lang and arbace/jrt, as declared by the forms under\n  prog-dir, registered by name for the image's decoder.R2,i291,R3,i1,R4,s19,arbace/j2g/embed.ae")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.embed$eval1991000004$loading__1927001464__auto____1991000005")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.embed$eval1991000008$fn__1991000009")

var Lit_93 *jrt.String = jrt.Intern("arbace/lang/go/ns")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.embed$sources")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.embed$read_all")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.embed$class_like_QMARK_")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.embed$package_like_QMARK_")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.embed$names")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.embed$cut_candidates")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.embed$with_member_types")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.embed$data")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.embed$user_resources")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.embed$package_loaders")

var Lit_104 *jrt.String = jrt.Intern("go/arbace/cmd/arbace/image.ae")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.embed$image_type_forms")
