//line aot_arbace_j2g_embed__init.ae:1
package aot_arbace_j2g_embed

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_embed__init_A_Unit0__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_embed__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_embed__init_A_const_1) }
//line :1:1
func A_arbace_j2g_embed__init_A_Unit1__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_embed__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_embed__init_A_Unit2__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_j2g_embed_eval1991000004_loading__1927001464__auto____1991000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_embed__init_A_Unit3__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_embed__init_A_const_1)).Equals_O__Z(A_arbace_j2g_embed__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_j2g_embed_eval1991000008_fn__1991000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_embed__init_A_Load__O() any { A_arbace_j2g_embed__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_embed__init_A_Unit0__O(); A_arbace_j2g_embed__init_A_Unit1__O(); A_arbace_j2g_embed__init_A_Unit2__O(); A_arbace_j2g_embed__init_A_Unit3__O(); A_arbace_j2g_embed__init_A_Unit4__O(); A_arbace_j2g_embed__init_A_Unit5__O(); A_arbace_j2g_embed__init_A_Unit6__O(); A_arbace_j2g_embed__init_A_Unit7__O(); A_arbace_j2g_embed__init_A_Unit8__O(); A_arbace_j2g_embed__init_A_Unit9__O(); A_arbace_j2g_embed__init_A_Unit10__O(); A_arbace_j2g_embed__init_A_Unit11__O(); A_arbace_j2g_embed__init_A_Unit12__O(); A_arbace_j2g_embed__init_A_Unit13__O(); A_arbace_j2g_embed__init_A_Unit14__O(); A_arbace_j2g_embed__init_A_Unit15__O(); A_arbace_j2g_embed__init_A_Unit16__O(); A_arbace_j2g_embed__init_A_Unit17__O(); A_arbace_j2g_embed__init_A_Unit18__O(); A_arbace_j2g_embed__init_A_Unit19__O(); A_arbace_j2g_embed__init_A_Unit20__O(); return nil }













func A_arbace_j2g_embed__init_A_Unit4__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); A_arbace_j2g_embed__init_A_const_4.BindRoot_O__V(A_arbace_j2g_embed__init_A_const_5); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_6)); return A_arbace_j2g_embed__init_A_const_4 }






























func A_arbace_j2g_embed__init_A_Unit5__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_j2g_embed__init_A_const_7.BindRoot_O__V(Lit_93); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_8)); return A_arbace_j2g_embed__init_A_const_7 }

func A_arbace_j2g_embed__init_A_Unit6__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_9; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__6 any = A_arbace_j2g_embed_sources_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_embed_sources_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, true, nil); A_arbace_j2g_embed_sources_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__6, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_10)); return A_arbace_j2g_embed__init_A_const_9 }












































func A_arbace_j2g_embed__init_A_Unit7__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_11; tmp1.BindRoot_O__V(A_arbace_j2g_embed_reify__1991000061_A_New_IPersistentMap(nil)); var tmp2 *lang.Var = A_arbace_j2g_embed__init_A_const_11; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_12)); return A_arbace_j2g_embed__init_A_const_11 }







func A_arbace_j2g_embed__init_A_Unit8__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_embed_read_all_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_embed_read_all_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, nil); A_arbace_j2g_embed_read_all_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_14)); return A_arbace_j2g_embed__init_A_const_13 }








func A_arbace_j2g_embed__init_A_Unit9__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_embed_class_like_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_embed_class_like_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, nil); A_arbace_j2g_embed_class_like_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_16)); return A_arbace_j2g_embed__init_A_const_15 }



func A_arbace_j2g_embed__init_A_Unit10__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_embed_package_like_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_embed_package_like_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); A_arbace_j2g_embed_package_like_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_18)); return A_arbace_j2g_embed__init_A_const_17 }


func A_arbace_j2g_embed__init_A_Unit11__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_embed_names_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_embed_names_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_j2g_embed_names_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_20)); return A_arbace_j2g_embed__init_A_const_19 }























func A_arbace_j2g_embed__init_A_Unit12__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); A_arbace_j2g_embed__init_A_const_21.BindRoot_O__V(A_arbace_j2g_embed__init_A_const_22); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_23)); return A_arbace_j2g_embed__init_A_const_21 }










func A_arbace_j2g_embed__init_A_Unit13__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_embed_cut_candidates_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_embed_cut_candidates_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_j2g_embed_cut_candidates_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_25)); return A_arbace_j2g_embed__init_A_const_24 }














func A_arbace_j2g_embed__init_A_Unit14__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_embed_with_member_types_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_embed_with_member_types_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, nil); A_arbace_j2g_embed_with_member_types_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_27)); return A_arbace_j2g_embed__init_A_const_26 }






























func A_arbace_j2g_embed__init_A_Unit15__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_embed_data_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_embed_data_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, nil); A_arbace_j2g_embed_data_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_29)); return A_arbace_j2g_embed__init_A_const_28 }











func A_arbace_j2g_embed__init_A_Unit16__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_embed_user_resources_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_embed_user_resources_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_j2g_embed_user_resources_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_31)); return A_arbace_j2g_embed__init_A_const_30 }




























func A_arbace_j2g_embed__init_A_Unit17__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_embed_package_loaders_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_embed_package_loaders_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, nil); A_arbace_j2g_embed_package_loaders_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_33)); return A_arbace_j2g_embed__init_A_const_32 }






















func A_arbace_j2g_embed__init_A_Unit18__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(266, 1); A_arbace_j2g_embed__init_A_const_34.BindRoot_O__V(Lit_104); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_35)); return A_arbace_j2g_embed__init_A_const_34 }



func A_arbace_j2g_embed__init_A_Unit19__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); A_arbace_j2g_embed__init_A_const_36.BindRoot_O__V(A_arbace_j2g_embed__init_A_const_37); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_38)); return A_arbace_j2g_embed__init_A_const_36 }




func A_arbace_j2g_embed__init_A_Unit20__O() any { A_arbace_j2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_j2g_embed__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_embed_image_type_forms_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_embed_image_type_forms_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_j2g_embed_image_type_forms_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_embed__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_embed__init_A_const_40)); return A_arbace_j2g_embed__init_A_const_39 }



type A_arbace_j2g_embed__init_A struct{ jrt.Object }

var A_arbace_j2g_embed__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_embed__init_A_const_0 *lang.Var

var A_arbace_j2g_embed__init_A_const_1 any

var A_arbace_j2g_embed__init_A_const_2 any

var A_arbace_j2g_embed__init_A_const_3 any

var A_arbace_j2g_embed__init_A_const_4 *lang.Var

var A_arbace_j2g_embed__init_A_const_5 any

var A_arbace_j2g_embed__init_A_const_6 any

var A_arbace_j2g_embed__init_A_const_7 *lang.Var

var A_arbace_j2g_embed__init_A_const_8 any

var A_arbace_j2g_embed__init_A_const_9 *lang.Var

var A_arbace_j2g_embed__init_A_const_10 any

var A_arbace_j2g_embed__init_A_const_11 *lang.Var

var A_arbace_j2g_embed__init_A_const_12 any

var A_arbace_j2g_embed__init_A_const_13 *lang.Var

var A_arbace_j2g_embed__init_A_const_14 any

var A_arbace_j2g_embed__init_A_const_15 *lang.Var

var A_arbace_j2g_embed__init_A_const_16 any

var A_arbace_j2g_embed__init_A_const_17 *lang.Var

var A_arbace_j2g_embed__init_A_const_18 any

var A_arbace_j2g_embed__init_A_const_19 *lang.Var

var A_arbace_j2g_embed__init_A_const_20 any

var A_arbace_j2g_embed__init_A_const_21 *lang.Var

var A_arbace_j2g_embed__init_A_const_22 any

var A_arbace_j2g_embed__init_A_const_23 any

var A_arbace_j2g_embed__init_A_const_24 *lang.Var

var A_arbace_j2g_embed__init_A_const_25 any

var A_arbace_j2g_embed__init_A_const_26 *lang.Var

var A_arbace_j2g_embed__init_A_const_27 any

var A_arbace_j2g_embed__init_A_const_28 *lang.Var

var A_arbace_j2g_embed__init_A_const_29 any

var A_arbace_j2g_embed__init_A_const_30 *lang.Var

var A_arbace_j2g_embed__init_A_const_31 any

var A_arbace_j2g_embed__init_A_const_32 *lang.Var

var A_arbace_j2g_embed__init_A_const_33 any

var A_arbace_j2g_embed__init_A_const_34 *lang.Var

var A_arbace_j2g_embed__init_A_const_35 any

var A_arbace_j2g_embed__init_A_const_36 *lang.Var

var A_arbace_j2g_embed__init_A_const_37 any

var A_arbace_j2g_embed__init_A_const_38 any

var A_arbace_j2g_embed__init_A_const_39 *lang.Var

var A_arbace_j2g_embed__init_A_const_40 any

var A_arbace_j2g_embed__init_A_init jrt.ClassInit

func A_arbace_j2g_embed__init_A_Init() { if !A_arbace_j2g_embed__init_A_init.Done() { A_arbace_j2g_embed__init_A_init.Run(A_arbace_j2g_embed__init_A_clinit) } }

func A_arbace_j2g_embed__init_A_clinit() { A_arbace_j2g_embed__init_A_clinit_p0(); A_arbace_j2g_embed__init_A_clinit_p1(); A_arbace_j2g_embed__init_A_clinit_p2(); A_arbace_j2g_embed__init_A_clinit_p3() }

func A_arbace_j2g_embed__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_embed__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_90, 62); A_arbace_j2g_embed__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[21]); A_arbace_j2g_embed__init_A_const_1 = A_arbace_j2g_embed__init_A_const_pool.A[22]; A_arbace_j2g_embed__init_A_const_2 = A_arbace_j2g_embed__init_A_const_pool.A[23]; A_arbace_j2g_embed__init_A_const_3 = A_arbace_j2g_embed__init_A_const_pool.A[24]; A_arbace_j2g_embed__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[25]); A_arbace_j2g_embed__init_A_const_5 = A_arbace_j2g_embed__init_A_const_pool.A[26]; A_arbace_j2g_embed__init_A_const_6 = A_arbace_j2g_embed__init_A_const_pool.A[27]; A_arbace_j2g_embed__init_A_const_7 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[28]); A_arbace_j2g_embed__init_A_const_8 = A_arbace_j2g_embed__init_A_const_pool.A[29]; A_arbace_j2g_embed__init_A_const_9 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[30]); A_arbace_j2g_embed__init_A_const_10 = A_arbace_j2g_embed__init_A_const_pool.A[31]; A_arbace_j2g_embed__init_A_const_11 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[32]); A_arbace_j2g_embed__init_A_const_12 = A_arbace_j2g_embed__init_A_const_pool.A[33] }

func A_arbace_j2g_embed__init_A_clinit_p1() { A_arbace_j2g_embed__init_A_const_13 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[34]); A_arbace_j2g_embed__init_A_const_14 = A_arbace_j2g_embed__init_A_const_pool.A[35]; A_arbace_j2g_embed__init_A_const_15 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[36]); A_arbace_j2g_embed__init_A_const_16 = A_arbace_j2g_embed__init_A_const_pool.A[37]; A_arbace_j2g_embed__init_A_const_17 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[38]); A_arbace_j2g_embed__init_A_const_18 = A_arbace_j2g_embed__init_A_const_pool.A[39]; A_arbace_j2g_embed__init_A_const_19 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[40]); A_arbace_j2g_embed__init_A_const_20 = A_arbace_j2g_embed__init_A_const_pool.A[41]; A_arbace_j2g_embed__init_A_const_21 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[42]); A_arbace_j2g_embed__init_A_const_22 = A_arbace_j2g_embed__init_A_const_pool.A[43]; A_arbace_j2g_embed__init_A_const_23 = A_arbace_j2g_embed__init_A_const_pool.A[44]; A_arbace_j2g_embed__init_A_const_24 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[45]); A_arbace_j2g_embed__init_A_const_25 = A_arbace_j2g_embed__init_A_const_pool.A[46] }

func A_arbace_j2g_embed__init_A_clinit_p2() { A_arbace_j2g_embed__init_A_const_26 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[47]); A_arbace_j2g_embed__init_A_const_27 = A_arbace_j2g_embed__init_A_const_pool.A[48]; A_arbace_j2g_embed__init_A_const_28 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[49]); A_arbace_j2g_embed__init_A_const_29 = A_arbace_j2g_embed__init_A_const_pool.A[50]; A_arbace_j2g_embed__init_A_const_30 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[51]); A_arbace_j2g_embed__init_A_const_31 = A_arbace_j2g_embed__init_A_const_pool.A[52]; A_arbace_j2g_embed__init_A_const_32 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[53]); A_arbace_j2g_embed__init_A_const_33 = A_arbace_j2g_embed__init_A_const_pool.A[54]; A_arbace_j2g_embed__init_A_const_34 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[55]); A_arbace_j2g_embed__init_A_const_35 = A_arbace_j2g_embed__init_A_const_pool.A[56]; A_arbace_j2g_embed__init_A_const_36 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[57]); A_arbace_j2g_embed__init_A_const_37 = A_arbace_j2g_embed__init_A_const_pool.A[58]; A_arbace_j2g_embed__init_A_const_38 = A_arbace_j2g_embed__init_A_const_pool.A[59] }

func A_arbace_j2g_embed__init_A_clinit_p3() { A_arbace_j2g_embed__init_A_const_39 = lang.Var_Cast(A_arbace_j2g_embed__init_A_const_pool.A[60]); A_arbace_j2g_embed__init_A_const_40 = A_arbace_j2g_embed__init_A_const_pool.A[61] }

func A_arbace_j2g_embed__init_A_New() *A_arbace_j2g_embed__init_A { A_arbace_j2g_embed__init_A_Init(); t := &A_arbace_j2g_embed__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_embed__init_A) Ctor() {}

func (t *A_arbace_j2g_embed__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_embed__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_embed__init_A_class }

func (t *A_arbace_j2g_embed__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_embed__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_embed__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_embed__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_embed__init_A); return ok }

func A_arbace_j2g_embed__init_A_Cast(x any) *A_arbace_j2g_embed__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_embed__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_embed__init_A_class)) }; return v }
