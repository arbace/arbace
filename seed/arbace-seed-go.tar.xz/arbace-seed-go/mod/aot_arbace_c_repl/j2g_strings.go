//line j2g_strings.ae:1
package aot_arbace_c_repl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.repr.ckn2,asyn2,rcyn18,arbace.repr.c.hostyn4,hostyn12,arbace.c.runyn3,runyn13,arbace.c.muslyn4,muslyn16,arbace.c.runtimeyn2,rtyn13,arbace.stringyn3,stryn11,arbace.corekn3,docys1,c4,defnys1,c4,enumys1,c5,unionys1,c6,structys1,c7,declareys1,c7,typedefys1,c3,varkn3,stdkn3,c23kn5,formskn5,unitskn5,errorks1,c7,includeys1,c7,includeys16,arbace.c.cinterp9,run-nodesyn16,arbace.c.cinterpkn7,cinterpkn5,cirunkn6,errorsks1,c4,unitkn2,okkn6,statuskn5,classkn7,messageks1,c7,refusedkn4,textv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,v11,arbace.core5,referR13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.c.replm2,R14,s1050,ci's REPL state (doc/C23-SURVEY.md §6.6, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §4): a translation\n  unit is a namespace, its C forms the declarations typed or loaded into it (arbace.c's macros c/file,\n  c/include, c/defn, c/var, c/declare, c/typedef, c/struct, c/union, c/enum, c/group, c/static-assert); a\n  declaration of a name already declared replaces it (a redefinition: the next run calls the new\n  definition, every call going through the function's cell); (c/include \"<stdio.h>\") reads the header in\n  the unit's context with repr/c and enters musl's declarations; (c/run-main 'c.letters) checks the REPL's\n  units, links them with musl, builds and runs main in the program mode: exit and abort end the run, not\n  the REPL, whose result is the status.\n\n  The back end is *run-nodes*: on the executable built with ci, arbace.lang.CInterp's natives (the program\n  loaded into ci's back end in the process, the heavy list's); on the light path (stage 0), tools/cirun run\n  as a process over the node program's text, its output the REPL's.v18,arbace.repr.c.host9,load-hostv13,arbace.c.repl4,rootv16,arbace.c.runtime7,libraryv13,arbace.c.repl5,host*v11,arbace.core4,seq?v11,arbace.core5,firstR15,v11,arbace.core6,secondv11,arbace.core7,symbol?v11,arbace.core4,nameR16,R17,R18,R19,R20,R21,v13,arbace.c.repl9,decl-namev11,arbace.core6,symbolv11,arbace.core3,strv11,arbace.core5,swap!v13,arbace.c.repl5,unitsv11,arbace.core6,updateR22,R23,R24,R25,v11,arbace.core12,keep-indexedv11,arbace.core5,assocv11,arbace.core10,drop-whilev11,arbace.core4,not=C14,java.lang.Mathv11,arbace.core4,hashv11,arbace.core4,spitv18,arbace.repr.c.host11,file-configv13,arbace.repr.c6,read-cv18,arbace.repr.c.host6,configR26,v11,arbace.core7,ex-infov13,arbace.string4,joinR27,v11,arbace.core5,mergev11,arbace.core4,intov11,arbace.core6,filterR28,v11,arbace.core4,restv11,arbace.core5,slurpv11,arbace.core5,printv11,arbace.core5,flushv11,arbace.core7,resolveR29,R30,v13,arbace.c.repl17,cinterp-run-nodesv13,arbace.c.repl15,light-run-nodesR31,R32,v11,arbace.core3,vecv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv12,arbace.c.run10,check-readv13,arbace.c.repl9,unit-readR33,v11,arbace.core4,takel3,R34,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core7,sort-byv11,arbace.core3,keyv12,arbace.c.run5,nodesv11,arbace.core19,pop-thread-bindingsR35,R36,v13,arbace.c.repl11,*run-nodes*R37,R38,R39,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv12,arbace.c.run6,*musl*v13,arbace.c.repl4,lib*R40,v11,arbace.core3,mapv11,arbace.core6,dissocv11,arbace.core4,nextv11,arbace.core7,printlnv13,arbace.c.repl7,backendv11,arbace.core15,shutdown-agentsv11,arbace.core5,*out*v11,arbace.core5,*err*")

var Lit_1 *jrt.String = jrt.Intern("backend")

var Lit_2 *jrt.String = jrt.Intern("run-nodes")

var Lit_3 *jrt.String = jrt.Intern("a.out")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.repl$_main$fn__1787000072")

var Lit_5 *jrt.String = jrt.Intern("usage: arbace.c.repl run-nodes FILE [ARG...] | backend")

var Lit_6 *jrt.String = jrt.Intern(" ")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.repl$declare_BANG_$fn__1787000023")

var Lit_8 *jrt.String = jrt.Intern("arbace.c.repl$declare_BANG_$fn__1787000023$fn__1787000024")

var Lit_9 *jrt.String = jrt.Intern("arbace.c.repl$file_BANG_$fn__1787000030")

var Lit_10 *jrt.String = jrt.Intern("arbace.c.repl$file_BANG_$fn__1787000032")

var Lit_11 *jrt.String = jrt.Intern("/test/c/host")

var Lit_12 *jrt.String = jrt.Intern("/ci-repl")

var Lit_13 *jrt.String = jrt.Intern("TMPDIR")

var Lit_14 *jrt.String = jrt.Intern("/.tmp/tmp")

var Lit_15 *jrt.String = jrt.Intern("include-")

var Lit_16 *jrt.String = jrt.Intern(".c")

var Lit_17 *jrt.String = jrt.Intern("abs")

var Lit_18 *jrt.String = jrt.Intern("#include ")

var Lit_19 *jrt.String = jrt.Intern("\n")

var Lit_20 *jrt.String = jrt.Intern("-std=")

var Lit_21 *jrt.String = jrt.Intern("c/include: ")

var Lit_22 *jrt.String = jrt.Intern("; ")

var Lit_23 *jrt.String = jrt.Intern("arbace.c.repl$include_BANG_$fn__1787000036")

var Lit_24 *jrt.String = jrt.Intern("arbace.c.repl$include_BANG_$fn__1787000036$fn__1787000037")

var Lit_25 *jrt.String = jrt.Intern("ci-repl")

var Lit_26 *jrt.String = jrt.Intern(".nodes")

var Lit_27 *jrt.String = jrt.Intern("CIRUN")

var Lit_28 *jrt.String = jrt.Intern("/.tmp/ci/cirun")

var Lit_29 *jrt.String = jrt.Intern("ARBACE_ROOT")

var Lit_30 *jrt.String = jrt.Intern("user.dir")

var Lit_31 *jrt.String = jrt.Intern("arbace.c.repl$run_main$iter__1787000048__1787000052")

var Lit_32 *jrt.String = jrt.Intern("arbace.c.repl$run_main$fn__1787000064")

var Lit_33 *jrt.String = jrt.Intern("c/run-main: refused (")

var Lit_34 *jrt.String = jrt.Intern("): ")

var Lit_35 *jrt.String = jrt.Intern("arbace.c.repl$run_main$iter__1787000048__1787000052$fn__1787000053")

var Lit_36 *jrt.String = jrt.Intern("arbace.c.repl$run_main$iter__1787000048__1787000052$fn__1787000053$fn__1787000054")

var Lit_37 *jrt.String = jrt.Intern("c/run-main: ")

var Lit_38 *jrt.String = jrt.Intern(": ")

var Lit_39 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn16,java.lang.Stringyn1,fyn2,nsyn6,Stringyn1,uyn4,argvkn7,dynamicyn1,&yn4,argsv11,arbace.core5,in-nsMyn13,arbace.c.replm2,R0,s1050,ci's REPL state (doc/C23-SURVEY.md §6.6, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §4): a translation\n  unit is a namespace, its C forms the declarations typed or loaded into it (arbace.c's macros c/file,\n  c/include, c/defn, c/var, c/declare, c/typedef, c/struct, c/union, c/enum, c/group, c/static-assert); a\n  declaration of a name already declared replaces it (a redefinition: the next run calls the new\n  definition, every call going through the function's cell); (c/include \"<stdio.h>\") reads the header in\n  the unit's context with repr/c and enters musl's declarations; (c/run-main 'c.letters) checks the REPL's\n  units, links them with musl, builds and runs main in the program mode: exit and abort end the run, not\n  the REPL, whose result is the status.\n\n  The back end is *run-nodes*: on the executable built with ci, arbace.lang.CInterp's natives (the program\n  loaded into ci's back end in the process, the heavy list's); on the light path (stage 0), tools/cirun run\n  as a process over the node program's text, its output the REPL's.m2,R0,s1050,ci's REPL state (doc/C23-SURVEY.md §6.6, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §4): a translation\n  unit is a namespace, its C forms the declarations typed or loaded into it (arbace.c's macros c/file,\n  c/include, c/defn, c/var, c/declare, c/typedef, c/struct, c/union, c/enum, c/group, c/static-assert); a\n  declaration of a name already declared replaces it (a redefinition: the next run calls the new\n  definition, every call going through the function's cell); (c/include \"<stdio.h>\") reads the header in\n  the unit's context with repr/c and enters musl's declarations; (c/run-main 'c.letters) checks the REPL's\n  units, links them with musl, builds and runs main in the program mode: exit and abort end the run, not\n  the REPL, whose result is the status.\n\n  The back end is *run-nodes*: on the executable built with ci, arbace.lang.CInterp's natives (the program\n  loaded into ci's back end in the process, the heavy list's); on the light path (stage 0), tools/cirun run\n  as a process over the node program's text, its output the REPL's.R1,v11,arbace.core20,*warn-on-reflection*v13,arbace.c.repl5,unitsm8,R0,s74,The REPL's units: {ns {:std :forms [form ...] :units {header-unit read}}}.R2,i23,R3,i1,R4,s16,arbace/c/repl.aev11,arbace.core4,atomm8,R0,s74,The REPL's units: {ns {:std :forms [form ...] :units {header-unit read}}}.R2,i23,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl4,rootm10,R5,TR6,L1,MV0,m2,R7,R8,R2,i25,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl5,host*m8,R5,TR2,i27,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl4,lib*m8,R5,TR2,i28,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl9,decl-namem12,R5,TR6,L1,V1,R9,R0,s64,The name a top-level C form declares (for redefinition), or nil.R2,i30,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl8,declare!m10,R6,L1,V2,R9,R10,R0,s118,A declaration form entered into the unit `ns` (replacing an earlier one of the same name and kind); the\n  unit's name.R2,i39,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl5,file!m10,R6,L1,V2,R9,R10,R0,s40,c/file at the REPL: the unit's standard.R2,i52,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl8,include!m10,R6,L1,V2,Myn4,specm2,R7,R11,R10,R0,s157,(c/include \"<stdio.h>\") at the REPL: the header read by repr/c in the unit's standard, its header units\n  and a c/include form of each entered into the unit.R2,i59,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl9,unit-readm12,R5,TR6,L1,V1,R12,R0,s39,A REPL unit as a read: {:forms :units}.R2,i80,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl15,light-run-nodesm10,R6,L1,V2,Myn4,textm2,R7,R11,R13,R0,s206,The light path's back end: tools/cirun over the node program's text, the REPL's output its output; argv[0] is the\n  program's name, which cirun itself supplies (\"a.out\"), so only the rest are its arguments.R2,i85,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl17,cinterp-run-nodesm8,R5,TR2,i102,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl11,*run-nodes*m10,R14,TR2,i108,R3,i1,R4,s16,arbace/c/repl.aeR0,s161,The back end: (fn [node-program-text argv] status): arbace.lang.CInterp's on an executable built with ci (C9), else the\n  light path's, tools/cirun as a process.v13,arbace.c.repl7,backendm10,R6,L1,V0,R0,s101,Which back end *run-nodes* is by default: :cinterp (in process) or :cirun (the light path's process).R2,i113,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl8,run-mainm10,R6,L1,V3,R10,R15,R16,R0,s155,(c/run-main 'c.letters & args): the REPL's units checked, linked with musl, built, main run in the program\n  mode (exit and abort end the run): its status.R2,i118,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl11,reset-unit!m10,R6,L1,V1,R10,R0,s22,Forgets the unit `ns`.R2,i133,R3,i1,R4,s16,arbace/c/repl.aev13,arbace.c.repl5,-mainm10,R6,L1,V2,R15,R16,R0,s259,arbace -m arbace.c.repl run-nodes FILE [ARG...]: the node program in FILE run by the default back end with the arguments\n  (argv[0] \"a.out\"), its status the exit status (bin/lib/ci/check with CI_EXE, one process a program); backend: prints\n  cinterp or cirun.R2,i139,R3,i1,R4,s16,arbace/c/repl.ae")

var Lit_40 *jrt.String = jrt.Intern("arbace.c.repl$eval1787000004$loading__1927001464__auto____1787000005")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.repl$eval1787000008$fn__1787000009")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.repl$root")

var Lit_43 *jrt.String = jrt.Intern("arbace.c.repl$fn__1787000017")

var Lit_44 *jrt.String = jrt.Intern("arbace.c.repl$fn__1787000019")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.repl$decl_name")

var Lit_46 *jrt.String = jrt.Intern("arbace.c.repl$declare_BANG_")

var Lit_47 *jrt.String = jrt.Intern("arbace.c.repl$file_BANG_")

var Lit_48 *jrt.String = jrt.Intern("arbace.c.repl$include_BANG_")

var Lit_49 *jrt.String = jrt.Intern("arbace.c.repl$unit_read")

var Lit_50 *jrt.String = jrt.Intern("arbace.c.repl$light_run_nodes")

var Lit_51 *jrt.String = jrt.Intern("arbace.c.repl$fn__1787000043")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.repl$fn__1787000045")

var Lit_53 *jrt.String = jrt.Intern("arbace.c.repl$backend")

var Lit_54 *jrt.String = jrt.Intern("arbace.c.repl$run_main")

var Lit_55 *jrt.String = jrt.Intern("arbace.c.repl$reset_unit_BANG_")

var Lit_56 *jrt.String = jrt.Intern("arbace.c.repl$_main")
