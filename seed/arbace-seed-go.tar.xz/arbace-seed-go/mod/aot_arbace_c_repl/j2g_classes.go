//line j2g_classes.ae:1
package aot_arbace_c_repl

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c_repl__main_A_class, Name: "arbace.c.repl$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl__main_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl__main_fn__1787000072_A_class, Name: "arbace.c.repl$_main$fn__1787000072", Modifiers: 25, Simple: "fn__1787000072", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl__main_fn__1787000072_A", Source: "repl.ae", Declaring: &A_arbace_c_repl__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_backend_A_class, Name: "arbace.c.repl$backend", Modifiers: 25, Simple: "backend", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_backend_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_decl_name_A_class, Name: "arbace.c.repl$decl_name", Modifiers: 25, Simple: "decl_name", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_decl_name_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_declare_BANG__A_class, Name: "arbace.c.repl$declare_BANG_", Modifiers: 25, Simple: "declare_BANG_", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_declare_BANG__A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_declare_BANG__fn__1787000023_A_class, Name: "arbace.c.repl$declare_BANG_$fn__1787000023", Modifiers: 25, Simple: "fn__1787000023", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_declare_BANG__fn__1787000023_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_declare_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_class, Name: "arbace.c.repl$declare_BANG_$fn__1787000023$fn__1787000024", Modifiers: 25, Simple: "fn__1787000024", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_declare_BANG__fn__1787000023_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A_class, Name: "arbace.c.repl$eval1787000004$loading__1927001464__auto____1787000005", Modifiers: 25, Simple: "loading__1927001464__auto____1787000005", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_eval1787000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_eval1787000008_fn__1787000009_A_class, Name: "arbace.c.repl$eval1787000008$fn__1787000009", Modifiers: 25, Simple: "fn__1787000009", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_eval1787000008_fn__1787000009_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_eval1787000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_file_BANG__A_class, Name: "arbace.c.repl$file_BANG_", Modifiers: 25, Simple: "file_BANG_", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_file_BANG__A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_file_BANG__fn__1787000030_A_class, Name: "arbace.c.repl$file_BANG_$fn__1787000030", Modifiers: 25, Simple: "fn__1787000030", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_file_BANG__fn__1787000030_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_file_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_file_BANG__fn__1787000032_A_class, Name: "arbace.c.repl$file_BANG_$fn__1787000032", Modifiers: 25, Simple: "fn__1787000032", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_file_BANG__fn__1787000032_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_file_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_fn__1787000017_A_class, Name: "arbace.c.repl$fn__1787000017", Modifiers: 25, Simple: "fn__1787000017", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_fn__1787000017_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_fn__1787000019_A_class, Name: "arbace.c.repl$fn__1787000019", Modifiers: 25, Simple: "fn__1787000019", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_fn__1787000019_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_fn__1787000043_A_class, Name: "arbace.c.repl$fn__1787000043", Modifiers: 25, Simple: "fn__1787000043", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_fn__1787000043_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_fn__1787000045_A_class, Name: "arbace.c.repl$fn__1787000045", Modifiers: 25, Simple: "fn__1787000045", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_fn__1787000045_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_include_BANG__A_class, Name: "arbace.c.repl$include_BANG_", Modifiers: 25, Simple: "include_BANG_", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_include_BANG__A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_include_BANG__fn__1787000036_A_class, Name: "arbace.c.repl$include_BANG_$fn__1787000036", Modifiers: 25, Simple: "fn__1787000036", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_include_BANG__fn__1787000036_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_include_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_class, Name: "arbace.c.repl$include_BANG_$fn__1787000036$fn__1787000037", Modifiers: 25, Simple: "fn__1787000037", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_include_BANG__fn__1787000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_light_run_nodes_A_class, Name: "arbace.c.repl$light_run_nodes", Modifiers: 25, Simple: "light_run_nodes", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_light_run_nodes_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_reset_unit_BANG__A_class, Name: "arbace.c.repl$reset_unit_BANG_", Modifiers: 25, Simple: "reset_unit_BANG_", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_reset_unit_BANG__A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_root_A_class, Name: "arbace.c.repl$root", Modifiers: 25, Simple: "root", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_root_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_run_main_A_class, Name: "arbace.c.repl$run_main", Modifiers: 25, Simple: "run_main", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_run_main_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_run_main_fn__1787000064_A_class, Name: "arbace.c.repl$run_main$fn__1787000064", Modifiers: 25, Simple: "fn__1787000064", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_run_main_fn__1787000064_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_run_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_class, Name: "arbace.c.repl$run_main$iter__1787000048__1787000052", Modifiers: 25, Simple: "iter__1787000048__1787000052", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_run_main_iter__1787000048__1787000052_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_run_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_class, Name: "arbace.c.repl$run_main$iter__1787000048__1787000052$fn__1787000053", Modifiers: 25, Simple: "fn__1787000053", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_class, Name: "arbace.c.repl$run_main$iter__1787000048__1787000052$fn__1787000053$fn__1787000054", Modifiers: 25, Simple: "fn__1787000054", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_unit_read_A_class, Name: "arbace.c.repl$unit_read", Modifiers: 25, Simple: "unit_read", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_unit_read_A", Source: "repl.ae", Declaring: &A_arbace_c_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c_repl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_repl_A_New()}; return nil }

var A_arbace_c_repl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_repl_A_new}

var A_arbace_c_repl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.repl", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_A"})

func init() { i := A_arbace_c_repl_A_class.Info(); i.IsInstance = A_arbace_c_repl_A_InstanceOf; i.Init = A_arbace_c_repl_A_Init; i.Table = A_arbace_c_repl_A_members }

var A_arbace_c_repl__main_A_class *jrt.Class

var A_arbace_c_repl__main_fn__1787000072_A_class *jrt.Class

var A_arbace_c_repl_backend_A_class *jrt.Class

var A_arbace_c_repl_decl_name_A_class *jrt.Class

var A_arbace_c_repl_declare_BANG__A_class *jrt.Class

var A_arbace_c_repl_declare_BANG__fn__1787000023_A_class *jrt.Class

var A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_class *jrt.Class

func A_arbace_c_repl_eval1787000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_repl_eval1787000004_A_New()}; return nil }

var A_arbace_c_repl_eval1787000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_repl_eval1787000004_A_new}

var A_arbace_c_repl_eval1787000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.repl$eval1787000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_repl_A_class, Simple: "eval1787000004", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_eval1787000004_A"})

func init() { i := A_arbace_c_repl_eval1787000004_A_class.Info(); i.IsInstance = A_arbace_c_repl_eval1787000004_A_InstanceOf; i.Table = A_arbace_c_repl_eval1787000004_A_members }

var A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A_class *jrt.Class

func A_arbace_c_repl_eval1787000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_repl_eval1787000008_A_New()}; return nil }

var A_arbace_c_repl_eval1787000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_repl_eval1787000008_A_new}

var A_arbace_c_repl_eval1787000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.repl$eval1787000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_repl_A_class, Simple: "eval1787000008", Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl_eval1787000008_A"})

func init() { i := A_arbace_c_repl_eval1787000008_A_class.Info(); i.IsInstance = A_arbace_c_repl_eval1787000008_A_InstanceOf; i.Table = A_arbace_c_repl_eval1787000008_A_members }

var A_arbace_c_repl_eval1787000008_fn__1787000009_A_class *jrt.Class

var A_arbace_c_repl_file_BANG__A_class *jrt.Class

var A_arbace_c_repl_file_BANG__fn__1787000030_A_class *jrt.Class

var A_arbace_c_repl_file_BANG__fn__1787000032_A_class *jrt.Class

var A_arbace_c_repl_fn__1787000017_A_class *jrt.Class

var A_arbace_c_repl_fn__1787000019_A_class *jrt.Class

var A_arbace_c_repl_fn__1787000043_A_class *jrt.Class

var A_arbace_c_repl_fn__1787000045_A_class *jrt.Class

var A_arbace_c_repl_include_BANG__A_class *jrt.Class

var A_arbace_c_repl_include_BANG__fn__1787000036_A_class *jrt.Class

var A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_class *jrt.Class

var A_arbace_c_repl_light_run_nodes_A_class *jrt.Class

var A_arbace_c_repl_reset_unit_BANG__A_class *jrt.Class

var A_arbace_c_repl_root_A_class *jrt.Class

var A_arbace_c_repl_run_main_A_class *jrt.Class

var A_arbace_c_repl_run_main_fn__1787000064_A_class *jrt.Class

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_class *jrt.Class

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_class *jrt.Class

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_class *jrt.Class

var A_arbace_c_repl_unit_read_A_class *jrt.Class

func A_arbace_c_repl__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c_repl__init_A_Load__O()}; return nil }

func A_arbace_c_repl__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_repl__init_A_New()}; return nil }

var A_arbace_c_repl__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c_repl__init_A_invoke, New: A_arbace_c_repl__init_A_new}

var A_arbace_c_repl__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.repl__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_repl.A_arbace_c_repl__init_A", Source: "repl.ae"})

func init() { i := A_arbace_c_repl__init_A_class.Info(); i.IsInstance = A_arbace_c_repl__init_A_InstanceOf; i.Init = A_arbace_c_repl__init_A_Init; i.Table = A_arbace_c_repl__init_A_members }
