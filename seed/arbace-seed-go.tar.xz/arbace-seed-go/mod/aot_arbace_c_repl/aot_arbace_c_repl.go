//line aot_arbace_c_repl.ae:1
package aot_arbace_c_repl

import (
	"arbace/aot_arbace_c_musl"
	"arbace/aot_arbace_c_run"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_c"
	"arbace/aot_arbace_repr_c_host"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A_New() *A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_repl_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_c_repl_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_c_repl_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_c_repl_A_const_1, A_arbace_c_repl_A_const_2, A_arbace_c_repl_A_const_3, A_arbace_c_repl_A_const_4, A_arbace_c_repl_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_repl_eval1787000008_fn__1787000009_A_New() *A_arbace_c_repl_eval1787000008_fn__1787000009_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_eval1787000008_fn__1787000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_repl_eval1787000008_fn__1787000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_repl_eval1787000008_fn__1787000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_c_repl_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_repl_A_const_11.GetRawRoot__O(), A_arbace_c_repl_A_const_12) }






















func A_arbace_c_repl_root_A_New() *A_arbace_c_repl_root_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_root_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_c_repl_root_A) Ctor() {}
//line :24:1
func (t *A_arbace_c_repl_root_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any = jrt.System_Getenv_String__String(Lit_29).Ref(); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { return jrt.System_GetProperty_String__String(Lit_30).Ref() } }

func A_arbace_c_repl_fn__1787000017_A_New() *A_arbace_c_repl_fn__1787000017_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000017_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_c_repl_fn__1787000017_A) Ctor() {}
//line :26:1
func (t *A_arbace_c_repl_fn__1787000017_A) Invoke_O__O(self any) any { var root_23 any = A_arbace_c_repl_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_11); var tmp2 any; var root_27 any = A_arbace_c_repl_A_const_14.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, A_arbace_c_repl_root_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; if linked_28 == nil { tmp2 = ifn_29.Invoke__O() } else { tmp2 = linked_28.(*A_arbace_c_repl_root_A).Invoke_O__O(root_27) }; arg_26 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref(); if linked_24 == nil { return ifn_25.Invoke_O__O(arg_26) } else { return linked_24.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A).Invoke_O_O__O(root_23, arg_26) } }
func A_arbace_c_repl_fn__1787000019_A_New() *A_arbace_c_repl_fn__1787000019_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000019_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c_repl_fn__1787000019_A) Ctor() {}
//line :27:1
func (t *A_arbace_c_repl_fn__1787000019_A) Invoke_O__O(self any) any { var root_30 any = A_arbace_c_repl_A_const_15.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_c_musl.A_arbace_c_musl_library_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var root_35 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = A_arbace_c_repl_A_const_16.GetRawRoot__O(); if linked_36 == nil { arg_33 = ifn_37.Invoke_O__O(arg_38) } else { arg_33 = linked_36.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_35, arg_38) }; var arg_34 any; var root_39 any = A_arbace_c_repl_A_const_14.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, A_arbace_c_repl_root_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; if linked_40 == nil { arg_34 = ifn_41.Invoke__O() } else { arg_34 = linked_40.(*A_arbace_c_repl_root_A).Invoke_O__O(root_39) }; if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_c_musl.A_arbace_c_musl_library_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }

func A_arbace_c_repl_decl_name_A_New() *A_arbace_c_repl_decl_name_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_decl_name_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_c_repl_decl_name_A) Ctor() {}
//line :29:1
func (t *A_arbace_c_repl_decl_name_A) Invoke_O_O__O(self, f__0 any) any {


	var tmp1 any; var root_42 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = f__0; if linked_43 == nil { tmp1 = ifn_44.Invoke_O__O(arg_45) } else { tmp1 = linked_43.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_42, arg_45) }; if jrt.J2g_Truth(tmp1) { var G__1787000021__2_ any; var root_46 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_48 lang.IFn
		if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = f__0; if linked_47 == nil { G__1787000021__2_ = ifn_48.Invoke_O__O(arg_49) } else { G__1787000021__2_ = linked_47.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_46, arg_49) }; switch lang.Util_Hash_O__I_NoInit(G__1787000021__2_) >> 11 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_19) { var n__3 any; var root_51 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_53 lang.IFn
			if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = f__0; if linked_52 == nil { n__3 = ifn_53.Invoke_O__O(arg_54) } else { n__3 = linked_52.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_51, arg_54) }; var tmp2 any; var root_55 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = n__3; if linked_56 == nil { tmp2 = ifn_57.Invoke_O__O(arg_58) } else { tmp2 = linked_56.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_55, arg_58) }; if jrt.J2g_Truth(tmp2) { var root_59 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = n__3; if linked_60 == nil { return ifn_61.Invoke_O__O(arg_62) } else { return linked_60.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_59, arg_62) } } else { var tmp3 any; var root_63 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = n__3; if linked_64 == nil { tmp3 = ifn_65.Invoke_O__O(arg_66) } else { tmp3 = linked_64.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_63, arg_66) }; if jrt.J2g_Truth(tmp3) { var root_67 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = n__3; if linked_68 == nil { return ifn_69.Invoke_O__O(arg_70) } else { return linked_68.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_67, arg_70) } } else { return nil } } }
//line :33:1
		case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_23) { var n__3_2 any; var root_71 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_73 lang.IFn

			if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = f__0; if linked_72 == nil { n__3_2 = ifn_73.Invoke_O__O(arg_74) } else { n__3_2 = linked_72.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_71, arg_74) }; var tmp4 any; var root_75 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = n__3_2; if linked_76 == nil { tmp4 = ifn_77.Invoke_O__O(arg_78) } else { tmp4 = linked_76.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_75, arg_78) }; if jrt.J2g_Truth(tmp4) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil); var tmp6 any; var root_79 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = f__0; if linked_80 == nil { tmp6 = ifn_81.Invoke_O__O(arg_82) } else { tmp6 = linked_80.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_79, arg_82) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil, n__3_2)).Ref() } else { return nil } }
//line :33:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_24) { var n__3_3 any; var root_83 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_85 lang.IFn

			if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = f__0; if linked_84 == nil { n__3_3 = ifn_85.Invoke_O__O(arg_86) } else { n__3_3 = linked_84.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_83, arg_86) }; var tmp7 any; var root_87 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = n__3_3; if linked_88 == nil { tmp7 = ifn_89.Invoke_O__O(arg_90) } else { tmp7 = linked_88.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(tmp7) { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil); var tmp9 any; var root_91 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = f__0; if linked_92 == nil { tmp9 = ifn_93.Invoke_O__O(arg_94) } else { tmp9 = linked_92.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_91, arg_94) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, n__3_3)).Ref() } else { return nil } }
//line :33:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_25) { var n__3_4 any; var root_95 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_97 lang.IFn

			if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = f__0; if linked_96 == nil { n__3_4 = ifn_97.Invoke_O__O(arg_98) } else { n__3_4 = linked_96.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_95, arg_98) }; var tmp10 any; var root_99 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = n__3_4; if linked_100 == nil { tmp10 = ifn_101.Invoke_O__O(arg_102) } else { tmp10 = linked_100.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_99, arg_102) }; if jrt.J2g_Truth(tmp10) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil); var tmp12 any; var root_103 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = f__0; if linked_104 == nil { tmp12 = ifn_105.Invoke_O__O(arg_106) } else { tmp12 = linked_104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_103, arg_106) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, n__3_4)).Ref() } else { return nil } }
//line :33:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_26) { var n__3_5 any; var root_107 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_109 lang.IFn
			if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = f__0; if linked_108 == nil { n__3_5 = ifn_109.Invoke_O__O(arg_110) } else { n__3_5 = linked_108.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_107, arg_110) }; var tmp13 any; var root_111 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = n__3_5; if linked_112 == nil { tmp13 = ifn_113.Invoke_O__O(arg_114) } else { tmp13 = linked_112.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(tmp13) { var root_115 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = n__3_5; if linked_116 == nil { return ifn_117.Invoke_O__O(arg_118) } else { return linked_116.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_115, arg_118) } } else { var tmp14 any; var root_119 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = n__3_5; if linked_120 == nil { tmp14 = ifn_121.Invoke_O__O(arg_122) } else { tmp14 = linked_120.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_119, arg_122) }; if jrt.J2g_Truth(tmp14) { var root_123 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = n__3_5; if linked_124 == nil { return ifn_125.Invoke_O__O(arg_126) } else { return linked_124.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_123, arg_126) } } else { return nil } } }
//line :33:1
		case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_27) { var n__3_6 any; var root_127 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_129 lang.IFn
			if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = f__0; if linked_128 == nil { n__3_6 = ifn_129.Invoke_O__O(arg_130) } else { n__3_6 = linked_128.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_127, arg_130) }; var tmp15 any; var root_131 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = n__3_6; if linked_132 == nil { tmp15 = ifn_133.Invoke_O__O(arg_134) } else { tmp15 = linked_132.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_131, arg_134) }; if jrt.J2g_Truth(tmp15) { var root_135 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = n__3_6; if linked_136 == nil { return ifn_137.Invoke_O__O(arg_138) } else { return linked_136.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_135, arg_138) } } else { var tmp16 any; var root_139 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = n__3_6; if linked_140 == nil { tmp16 = ifn_141.Invoke_O__O(arg_142) } else { tmp16 = linked_140.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_139, arg_142) }; if jrt.J2g_Truth(tmp16) { var root_143 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = n__3_6; if linked_144 == nil { return ifn_145.Invoke_O__O(arg_146) } else { return linked_144.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_143, arg_146) } } else { return nil } } }
//line :33:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_28) { var n__3_7 any; var root_147 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_149 lang.IFn
			if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = f__0; if linked_148 == nil { n__3_7 = ifn_149.Invoke_O__O(arg_150) } else { n__3_7 = linked_148.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_147, arg_150) }; var tmp17 any; var root_151 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = n__3_7; if linked_152 == nil { tmp17 = ifn_153.Invoke_O__O(arg_154) } else { tmp17 = linked_152.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp17) { var root_155 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = n__3_7; if linked_156 == nil { return ifn_157.Invoke_O__O(arg_158) } else { return linked_156.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_155, arg_158) } } else { var tmp18 any; var root_159 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = n__3_7; if linked_160 == nil { tmp18 = ifn_161.Invoke_O__O(arg_162) } else { tmp18 = linked_160.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_159, arg_162) }; if jrt.J2g_Truth(tmp18) { var root_163 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = n__3_7; if linked_164 == nil { return ifn_165.Invoke_O__O(arg_166) } else { return linked_164.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_163, arg_166) } } else { return nil } } }
//line :33:1
		default:}; return nil } else {
//line :32:1
			return nil
		}
}



func A_arbace_c_repl_declare_BANG__A_New() *A_arbace_c_repl_declare_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_declare_BANG__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_c_repl_declare_BANG__A) Ctor() {}
//line :38:1
func (t *A_arbace_c_repl_declare_BANG__A) Invoke_O_O_O__O(self, f__0, ns__1 any) any { var n__3 any; var root_167 any = A_arbace_c_repl_A_const_29.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, A_arbace_c_repl_decl_name_A_fn_class); var ifn_169 lang.IFn; if



	linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = f__0; if linked_168 == nil { n__3 = ifn_169.Invoke_O__O(arg_170) } else { n__3 = linked_168.(*A_arbace_c_repl_decl_name_A).Invoke_O_O__O(root_167, arg_170) }; var root_188 any =
	A_arbace_c_repl_A_const_32.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = A_arbace_c_repl_A_const_33.GetRawRoot__O(); var arg_192 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var arg_193 any = ns__1; var arg_194 any; var fnbody__236 any = A_arbace_c_repl_declare_BANG__fn__1787000023_A_New_O_O(f__0, n__3); var tmp1 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_c_repl_declare_BANG__fn__1787000023_A_fn_class; if
	fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__236); A_arbace_c_repl_declare_BANG__fn__1787000023_A_fn_class = fncls__235d; tmp1 = fncls__235d } else { tmp1 = fncls__235 }; arg_194 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__236, tmp1, nil); if /*line :43:1*/ linked_189 == nil { ifn_190.Invoke_O_O_O_O__O(arg_191, arg_192, arg_193, arg_194) } else { linked_189.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_188, arg_191, arg_192, arg_193, arg_194) }; var root_171 any =





	A_arbace_c_repl_A_const_30.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var root_176 any = A_arbace_c_repl_A_const_31.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = ns__1; if linked_177 == nil { arg_174 = ifn_178.Invoke_O__O(arg_179) } else { arg_174 = linked_177.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_176, arg_179) }; var arg_175 any; var or__1927000174__auto____4 any = n__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_175 = or__1927000174__auto____4 } else { var root_180 any = A_arbace_c_repl_A_const_31.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any; var root_184 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = f__0; if linked_185 == nil { arg_183 = ifn_186.Invoke_O__O(arg_187) } else { arg_183 = linked_185.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_184, arg_187) }; if linked_181 == nil { arg_175 = ifn_182.Invoke_O__O(arg_183) } else { arg_175 = linked_181.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_180, arg_183) } }; if linked_172 == nil { return ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { return linked_172.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) } }
//line :44:1
func A_arbace_c_repl_declare_BANG__fn__1787000023_A_New_O_O(p0, p1 any) *A_arbace_c_repl_declare_BANG__fn__1787000023_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_declare_BANG__fn__1787000023_A{}; t.Ctor_O_O(p0, p1); return t }
//line :44:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_A) Ctor_O_O(c__f, c__n any) { t.F_f = c__f; t.F_n = c__n }
//line :44:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_A) Invoke_O_O__O(self, u__1 any) any { var u__2 any; var or__1927000174__auto____2 any = u__1; if
												jrt.J2g_Truth(or__1927000174__auto____2) { u__2 = or__1927000174__auto____2 } else { u__2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_35, A_arbace_c_repl_A_const_36, A_arbace_c_repl_A_const_37, lang.PersistentVector_EMPTY.Ref(), A_arbace_c_repl_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())) }; var fs__3 any = /*line :44:1*/A_arbace_c_repl_A_const_37.Invoke_O__O(u__2); var i__4 any; if


	jrt.J2g_Truth(t.F_n) { var root_195 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_199 any = A_arbace_c_repl_A_const_39.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var fnbody__217 any = A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_New_O_O(t.F_f, t.F_n); var tmp1 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__217); A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_fn_class = fncls__216d; tmp1 = fncls__216d } else { tmp1 = fncls__216 }; arg_202 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__217, tmp1, nil); var arg_203 any = fs__3; if linked_200 == nil { arg_198 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { arg_198 = linked_200.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; if linked_196 == nil { i__4 = ifn_197.Invoke_O__O(arg_198) } else { i__4 = linked_196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_195, arg_198) } } else { i__4 = nil }; var root_218 any =
	A_arbace_c_repl_A_const_40.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = u__2; var arg_222 any = A_arbace_c_repl_A_const_37; var arg_223 any; if jrt.J2g_Truth(i__4) { var root_224 any = A_arbace_c_repl_A_const_40.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = fs__3; var arg_228 any = i__4; var arg_229 any = t.F_f; if linked_225 == nil { arg_223 = ifn_226.Invoke_O_O_O__O(arg_227, arg_228, arg_229) } else { arg_223 = linked_225.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_224, arg_227, arg_228, arg_229) } } else { var root_230 any = A_arbace_c_repl_A_const_11.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = fs__3; var arg_234 any = t.F_f; if linked_231 == nil { arg_223 = ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { arg_223 = linked_231.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) } }; if linked_219 == nil { return ifn_220.Invoke_O_O_O__O(arg_221, arg_222, arg_223) } else { return linked_219.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_218, arg_221, arg_222, arg_223) } }
//line :47:1
func A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_New_O_O(p0, p1 any) *A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A{}; t.Ctor_O_O(p0, p1); return t }
//line :47:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A) Ctor_O_O(c__f, c__n any) { t.F_f = c__f; t.F_n = c__n }
//line :47:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A) Invoke_O_O_O__O(self, i__1, g__2 any) any { var tmp1 bool; var and__1927000168__auto____3 bool; var tmp2 any = t.F_n; var tmp3 any; var root_204 any = A_arbace_c_repl_A_const_29.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_c_repl_decl_name_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = g__2; if linked_205 == nil { tmp3 = ifn_206.Invoke_O__O(arg_207) } else { tmp3 = linked_205.(*A_arbace_c_repl_decl_name_A).Invoke_O_O__O(root_204, arg_207) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____3 { var tmp4 any; var root_208 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = g__2; if linked_209 == nil { tmp4 = ifn_210.Invoke_O__O(arg_211) } else { tmp4 = linked_209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_208, arg_211) }; var tmp5 any = tmp4; var tmp6 any; var root_212 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = t.F_f; if linked_213 == nil { tmp6 = ifn_214.Invoke_O__O(arg_215) } else { tmp6 = linked_213.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_212, arg_215) }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { return i__1 } else { return nil } }



func A_arbace_c_repl_file_BANG__A_New() *A_arbace_c_repl_file_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_file_BANG__A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_c_repl_file_BANG__A) Ctor() {}
//line :51:1
func (t *A_arbace_c_repl_file_BANG__A) Invoke_O_O_O__O(self, f__0, ns__1 any) any { var std__3 any; var root_237 any = A_arbace_c_repl_A_const_20.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_239 lang.IFn; if


	linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any; var root_241 any = A_arbace_c_repl_A_const_41.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any; var fnbody__252 any = A_arbace_c_repl_file_BANG__fn__1787000030_A_New(); var tmp1 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_c_repl_file_BANG__fn__1787000030_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_c_repl_file_BANG__fn__1787000030_A_fn_class = fncls__251d; tmp1 = fncls__251d } else { tmp1 = fncls__251 }; arg_244 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp1, nil); var arg_245 any = f__0; if linked_242 == nil { arg_240 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { arg_240 = linked_242.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }; if linked_238 == nil { std__3 = ifn_239.Invoke_O__O(arg_240) } else { std__3 = linked_238.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_237, arg_240) }; var root_253 any =
	A_arbace_c_repl_A_const_32.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = A_arbace_c_repl_A_const_33.GetRawRoot__O(); var arg_257 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var arg_258 any = ns__1; var arg_259 any; var fnbody__267 any = A_arbace_c_repl_file_BANG__fn__1787000032_A_New_O(std__3); var tmp2 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_c_repl_file_BANG__fn__1787000032_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__267); A_arbace_c_repl_file_BANG__fn__1787000032_A_fn_class = fncls__266d; tmp2 = fncls__266d } else { tmp2 = fncls__266 }; arg_259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__267, tmp2, nil); if linked_254 == nil { ifn_255.Invoke_O_O_O_O__O(arg_256, arg_257, arg_258, arg_259) } else { linked_254.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_253, arg_256, arg_257, arg_258, arg_259) }; return ns__1 }
//line :54:1
func A_arbace_c_repl_file_BANG__fn__1787000030_A_New() *A_arbace_c_repl_file_BANG__fn__1787000030_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_file_BANG__fn__1787000030_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000030_A) Ctor() {}
//line :54:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000030_A) Invoke_O_O__O(self, p1__1787000028_SHARP___1 any) any { var root_246 any = A_arbace_c_repl_A_const_42.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = p1__1787000028_SHARP___1; var arg_250 any = A_arbace_c_repl_A_const_35; if linked_247 == nil { return ifn_248.Invoke_O_O__O(arg_249, arg_250) } else { return linked_247.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_246, arg_249, arg_250) } }
func A_arbace_c_repl_file_BANG__fn__1787000032_A_New_O(p0 any) *A_arbace_c_repl_file_BANG__fn__1787000032_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_file_BANG__fn__1787000032_A{}; t.Ctor_O(p0); return t }
//line :55:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000032_A) Ctor_O(c__std any) { t.F_std = c__std }
//line :55:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000032_A) Invoke_O_O__O(self, p1__1787000029_SHARP___1 any) any { var root_260 any = A_arbace_c_repl_A_const_40.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var or__1927000174__auto____2 any = p1__1787000029_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_263 = or__1927000174__auto____2 } else { arg_263 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_37, lang.PersistentVector_EMPTY.Ref(), A_arbace_c_repl_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())) }; var arg_264 any = A_arbace_c_repl_A_const_35; var arg_265 any; var or__1927000174__auto____2_2 any = t.F_std; if jrt.J2g_Truth(or__1927000174__auto____2_2) { arg_265 = or__1927000174__auto____2_2 } else { arg_265 = A_arbace_c_repl_A_const_36 }; if linked_261 == nil { return ifn_262.Invoke_O_O_O__O(arg_263, arg_264, arg_265) } else { return linked_261.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_260, arg_263, arg_264, arg_265) } }


func A_arbace_c_repl_include_BANG__A_New() *A_arbace_c_repl_include_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_include_BANG__A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_c_repl_include_BANG__A) Ctor() {}
//line :58:1
func (t *A_arbace_c_repl_include_BANG__A) Invoke_O_O_O__O(self, spec__0, ns__1 any) any { var u__3 any; var tmp1 any; var root_268 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_270 lang.IFn; if



	linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = A_arbace_c_repl_A_const_33.GetRawRoot__O(); if linked_269 == nil { tmp1 = ifn_270.Invoke_O__O(arg_271) } else { tmp1 = linked_269.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_268, arg_271) }; u__3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns__1); var std__4 any; var root_272 any = /*line :58:1*/A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_274 lang.IFn; if




	linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any; var or__1927000174__auto____4 any = A_arbace_c_repl_A_const_35.Invoke_O__O(u__3); if jrt.J2g_Truth(or__1927000174__auto____4) { arg_275 = or__1927000174__auto____4 } else { arg_275 = A_arbace_c_repl_A_const_36 }; if linked_273 == nil { std__4 = ifn_274.Invoke_O__O(arg_275) } else { std__4 = linked_273.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_272, arg_275) }; var dir__5 any; var tmp2 /*line :58:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12); var tmp3 any; var or__1927000174__auto____7 any = jrt.System_Getenv_String__String(Lit_13).Ref(); if





	jrt.J2g_Truth(or__1927000174__auto____7) { tmp3 = or__1927000174__auto____7 } else { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_14); var tmp5 any; var root_276 any = A_arbace_c_repl_A_const_14.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, A_arbace_c_repl_root_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; if linked_277 == nil { tmp5 = ifn_278.Invoke__O() } else { tmp5 = linked_277.(*A_arbace_c_repl_root_A).Invoke_O__O(root_276) }; tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil)).Ref() }; dir__5 = /*line :58:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil))); var ___6 bool = jrt.File_Cast(dir__5).Mkdirs__Z(); var f__7 any; var tmp6 jrt.File_I = jrt.File_Cast(dir__5); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp8 *jrt.Class = A_arbace_c_repl_A_const_43; var tmp9 any; var root_279 any = A_arbace_c_repl_A_const_44.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_hash_A_fn_class); var ifn_281 lang.IFn; _ = ___6; if







	linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = spec__0; if linked_280 == nil { tmp9 = ifn_281.Invoke_O__O(arg_282) } else { tmp9 = linked_280.(*aot_arbace_core.A_arbace_core_hash_A).Invoke_O_O__O(root_279, arg_282) }; f__7 = /*line :58:1*/jrt.File_New_File_String(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp8, Lit_17, jrt.RefArrayOf(jrt.Object_class, tmp9)), nil))); var ___8 any = lang.IFn_Cast(A_arbace_c_repl_A_const_45.GetRawRoot__O()).Invoke_O_O__O(f__7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, spec__0, nil)).Ref()); var fc__9 any; var root_288 any = A_arbace_c_repl_A_const_46.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_290 lang.IFn; _ = ___8; if









	linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, std__4)).Ref()); var arg_292 any = std__4; if linked_289 == nil { fc__9 = ifn_290.Invoke_O_O__O(arg_291, arg_292) } else { fc__9 = linked_289.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_288, arg_291, arg_292) }; var rd__10 any; var root_293 any = /*line :58:1*/A_arbace_c_repl_A_const_47.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_repr_c.A_arbace_repr_c_read_c_A_fn_class); var ifn_295 lang.IFn; if










	linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any; var root_300 any = A_arbace_c_repl_A_const_48.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var root_306 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = A_arbace_c_repl_A_const_16.GetRawRoot__O(); if linked_307 == nil { arg_303 = ifn_308.Invoke_O__O(arg_309) } else { arg_303 = linked_307.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_306, arg_309) }; var arg_304 any = fc__9; var arg_305 any = jrt.File_Cast(dir__5).GetPath__String().Ref(); if linked_301 == nil { arg_296 = ifn_302.Invoke_O_O_O__O(arg_303, arg_304, arg_305) } else { arg_296 = linked_301.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A).Invoke_O_O_O_O__O(root_300, arg_303, arg_304, arg_305) }; var arg_297 any = fc__9; var arg_298 any = jrt.File_Cast(f__7).GetAbsolutePath__String().Ref(); var arg_299 any = jrt.Boolean_FALSE.Ref(); if linked_294 == nil { rd__10 = ifn_295.Invoke_O_O_O_O__O(arg_296, arg_297, arg_298, arg_299) } else { rd__10 = linked_294.(*aot_arbace_repr_c.A_arbace_repr_c_read_c_A).Invoke_O_O_O_O_O__O(root_293, arg_296, arg_297, arg_298, arg_299) }; if
	jrt.J2g_Truth(A_arbace_c_repl_A_const_49.Invoke_O__O(rd__10)) { var tmp10 any; var root_310 any = A_arbace_c_repl_A_const_50.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil); var tmp12 any; var root_315 any = A_arbace_c_repl_A_const_51.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = Lit_22; var arg_319 any = A_arbace_c_repl_A_const_49.Invoke_O__O(rd__10); if linked_316 == nil { tmp12 = ifn_317.Invoke_O_O__O(arg_318, arg_319) } else { tmp12 = linked_316.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_315, arg_318, arg_319) }; arg_313 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); var arg_314 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_52, spec__0)); if linked_311 == nil { tmp10 = ifn_312.Invoke_O_O__O(arg_313, arg_314) } else { tmp10 = linked_311.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_310, arg_313, arg_314) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) }; var root_320 any =
	A_arbace_c_repl_A_const_32.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_c_repl_A_const_33.GetRawRoot__O(); var arg_324 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var arg_325 any = ns__1; var arg_326 any; var fnbody__357 any = A_arbace_c_repl_include_BANG__fn__1787000036_A_New_O(rd__10); var tmp13 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_c_repl_include_BANG__fn__1787000036_A_fn_class; if
	fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__357); A_arbace_c_repl_include_BANG__fn__1787000036_A_fn_class = fncls__356d; tmp13 = fncls__356d } else { tmp13 = fncls__356 }; arg_326 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__357, tmp13, nil); if /*line :71:1*/ linked_321 == nil { ifn_322.Invoke_O_O_O_O__O(arg_323, arg_324, arg_325, arg_326) } else { linked_321.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_320, arg_323, arg_324, arg_325, arg_326) }; return spec__0 }
func A_arbace_c_repl_include_BANG__fn__1787000036_A_New_O(p0 any) *A_arbace_c_repl_include_BANG__fn__1787000036_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_include_BANG__fn__1787000036_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_A) Ctor_O(c__rd any) { t.F_rd = c__rd }
//line :72:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_A) Invoke_O_O__O(self, u__1 any) any { var u__2 any; var or__1927000174__auto____2 any = u__1; if
												jrt.J2g_Truth(or__1927000174__auto____2) { u__2 = or__1927000174__auto____2 } else { u__2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_35, A_arbace_c_repl_A_const_36, A_arbace_c_repl_A_const_37, lang.PersistentVector_EMPTY.Ref(), A_arbace_c_repl_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())) }; var root_327 any =


	A_arbace_c_repl_A_const_34.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any; var root_334 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_336 lang.IFn; if /*line :75:1*/ linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = u__2; var arg_338 any = A_arbace_c_repl_A_const_38; var arg_339 any = A_arbace_c_repl_A_const_53.GetRawRoot__O(); var arg_340 any = A_arbace_c_repl_A_const_38.Invoke_O__O(t.F_rd); if linked_335 == nil { arg_330 = ifn_336.Invoke_O_O_O_O__O(arg_337, arg_338, arg_339, arg_340) } else { arg_330 = linked_335.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_334, arg_337, arg_338, arg_339, arg_340) }; var arg_331 any = A_arbace_c_repl_A_const_37; var arg_332 any =
	A_arbace_c_repl_A_const_54.GetRawRoot__O(); var arg_333 any; var root_341 any = A_arbace_c_repl_A_const_55.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any; var fnbody__355 any = A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_New(); var tmp1 *jrt.Class; var fncls__354 *jrt.Class = A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_fn_class; if fncls__354 == nil { var fncls__354d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_fn_class = fncls__354d; tmp1 = fncls__354d } else { tmp1 = fncls__354 }; arg_344 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__355, tmp1, nil); var arg_345 any = A_arbace_c_repl_A_const_37.Invoke_O__O(t.F_rd); if linked_342 == nil { arg_333 = ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { arg_333 = linked_342.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_341, arg_344, arg_345) }; if linked_328 == nil { return ifn_329.Invoke_O_O_O_O__O(arg_330, arg_331, arg_332, arg_333) } else { return linked_328.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_327, arg_330, arg_331, arg_332, arg_333) } }
//line :76:1
func A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_New() *A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A) Ctor() {}
//line :76:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A) Invoke_O_O__O(self, p1__1787000035_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_346 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = p1__1787000035_SHARP___1; if linked_347 == nil { and__1927000168__auto____2 = ifn_348.Invoke_O__O(arg_349) } else { and__1927000168__auto____2 = linked_347.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_c_repl_A_const_56; var tmp2 any; var root_350 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = p1__1787000035_SHARP___1; if linked_351 == nil { tmp2 = ifn_352.Invoke_O__O(arg_353) } else { tmp2 = linked_351.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_350, arg_353) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }


func A_arbace_c_repl_unit_read_A_New() *A_arbace_c_repl_unit_read_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_unit_read_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_c_repl_unit_read_A) Ctor() {}
//line :79:1
func (t *A_arbace_c_repl_unit_read_A) Invoke_O_O__O(self, u__0 any) any { var tmp1 any = A_arbace_c_repl_A_const_37; var tmp2 any = A_arbace_c_repl_A_const_37.Invoke_O__O(u__0); var tmp3 any = A_arbace_c_repl_A_const_38; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, A_arbace_c_repl_A_const_38.Invoke_O__O(u__0))) }




func A_arbace_c_repl_light_run_nodes_A_New() *A_arbace_c_repl_light_run_nodes_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_light_run_nodes_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_c_repl_light_run_nodes_A) Ctor() {}
//line :84:1
func (t *A_arbace_c_repl_light_run_nodes_A) Invoke_O_O_O__O(self, text__0, argv__1 any) any { var f__3 any = jrt.File_CreateTempFile_String_String__File_NoInit(Lit_25, Lit_26); var cirun__4 any; var or__1927000174__auto____4 any = jrt.System_Getenv_String__String(Lit_27).Ref(); if




	jrt.J2g_Truth(or__1927000174__auto____4) { cirun__4 = or__1927000174__auto____4 } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28); var tmp2 any; var root_358 any = A_arbace_c_repl_A_const_14.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_c_repl_root_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; if linked_359 == nil { tmp2 = ifn_360.Invoke__O() } else { tmp2 = linked_359.(*A_arbace_c_repl_root_A).Invoke_O__O(root_358) }; cirun__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() }; var tmp3 any; tmp5 := /*line :84:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






		lang.IFn_Cast(A_arbace_c_repl_A_const_45.GetRawRoot__O()).Invoke_O_O__O(f__3, text__0)
//line :84:1
		{ var pb__7 any; var tmp4 any; var root_361 any = A_arbace_c_repl_A_const_54.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_363 lang.IFn







			if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = lang.Tuple_Create_O_O__IPersistentVector(cirun__4, jrt.File_Cast(f__3).GetPath__String().Ref()); var arg_365 any; var root_366 any = A_arbace_c_repl_A_const_57.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = argv__1; if linked_367 == nil { arg_365 = ifn_368.Invoke_O__O(arg_369) } else { arg_365 = linked_367.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_366, arg_369) }; if linked_362 == nil { tmp4 = ifn_363.Invoke_O_O__O(arg_364, arg_365) } else { tmp4 = linked_362.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_361, arg_364, arg_365) }
//line :84:1
			pb__7 = jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp4)); var ___8 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__7)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()).Ref(); var p__9 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__7)).Start__Process(); var out__10 any = lang.IFn_Cast(A_arbace_c_repl_A_const_58.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(p__9).GetInputStream__InputStream()); var st__11 int32 = jrt.Process_Cast(p__9).WaitFor__I(); _ = ___8












			lang.IFn_Cast(A_arbace_c_repl_A_const_59.GetRawRoot__O()).Invoke_O__O(out__10); var root_383 any = A_arbace_c_repl_A_const_60.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; if linked_384 == nil { ifn_385.Invoke__O() } else { linked_384.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_383) }
//line :84:1
			tmp3 = jrt.Integer_ValueOf_I__Integer_NoInit(st__11).Ref() }; return nil }();














	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__3).Delete__Z()); if /*line :84:1*/ tmp5 != nil { panic(tmp5) }; return tmp3 }


















func A_arbace_c_repl_fn__1787000043_A_New() *A_arbace_c_repl_fn__1787000043_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000043_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_c_repl_fn__1787000043_A) Ctor() {}
//line :103:1
func (t *A_arbace_c_repl_fn__1787000043_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_repl_A_const_63)
									{ var root_386 any = A_arbace_c_repl_A_const_61.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = A_arbace_c_repl_A_const_62; if linked_387 == nil { tmp1 = ifn_388.Invoke_O__O(arg_389) } else { tmp1 = linked_387.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_386, arg_389) } }
//line :103:1
	return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }






func A_arbace_c_repl_fn__1787000045_A_New() *A_arbace_c_repl_fn__1787000045_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000045_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_c_repl_fn__1787000045_A) Ctor() {}
//line :110:1
func (t *A_arbace_c_repl_fn__1787000045_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_394 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = A_arbace_c_repl_A_const_64.GetRawRoot__O(); if linked_395 == nil { or__1927000174__auto____1 = ifn_396.Invoke_O__O(arg_397) } else { or__1927000174__auto____1 = linked_395.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_394, arg_397) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { return A_arbace_c_repl_A_const_65.GetRawRoot__O() } }

func A_arbace_c_repl_backend_A_New() *A_arbace_c_repl_backend_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_backend_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_c_repl_backend_A) Ctor() {}
//line :112:1
func (t *A_arbace_c_repl_backend_A) Invoke_O__O(self any) any {


	var tmp1 any; var root_398 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = A_arbace_c_repl_A_const_64.GetRawRoot__O(); if linked_399 == nil { tmp1 = ifn_400.Invoke_O__O(arg_401) } else { tmp1 = linked_399.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_398, arg_401) }; if jrt.J2g_Truth(tmp1) { return A_arbace_c_repl_A_const_66 } else { return A_arbace_c_repl_A_const_67
	} }
func A_arbace_c_repl_run_main_A_New() *A_arbace_c_repl_run_main_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_c_repl_run_main_A) Ctor() {}
//line :117:1
func (t *A_arbace_c_repl_run_main_A) DoInvoke_O_O_O__O(self, ns__0, args__1 any) any { var us__3 any; var root_402 any = A_arbace_c_repl_A_const_68.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_404 lang.IFn; if



	linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var iter__1927001039__auto____3 any; var fnbody__559 any = A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_New(); var tmp1 *jrt.Class; var fncls__558 *jrt.Class = A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_fn_class; if fncls__558 == nil { var fncls__558d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_fn_class = fncls__558d; tmp1 = fncls__558d } else { tmp1 = fncls__558 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__559, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_560 any = A_arbace_c_repl_A_const_84.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = A_arbace_c_repl_A_const_85.GetRawRoot__O(); var arg_564 any; var root_565 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = A_arbace_c_repl_A_const_33.GetRawRoot__O(); if linked_566 == nil { arg_564 = ifn_567.Invoke_O__O(arg_568) } else { arg_564 = linked_566.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_565, arg_568) }; if linked_561 == nil { tmp3 = ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { tmp3 = linked_561.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) }; arg_405 = tmp2.Invoke_O__O(tmp3); if linked_403 == nil { us__3 = ifn_404.Invoke_O__O(arg_405) } else { us__3 = linked_403.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_402, arg_405) }; var r__4 any; var root_587 any = /*line :117:1*/A_arbace_c_repl_A_const_94.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_589 lang.IFn; if









	linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_95.GetRawRoot__O()); var tmp5 any = A_arbace_c_repl_A_const_96; var tmp6 any; var root_596 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = A_arbace_c_repl_A_const_97.GetRawRoot__O(); if linked_597 == nil { tmp6 = ifn_598.Invoke_O__O(arg_599) } else { tmp6 = linked_597.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_596, arg_599) }; arg_590 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_588 == nil { ifn_589.Invoke_O__O(arg_590) } else { linked_588.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_587, arg_590) }; var tmp7 *lang.Compiler_AOTFn; var fnbody__577 any = A_arbace_c_repl_run_main_fn__1787000064_A_New_O(us__3); var tmp8 *jrt.Class; var fncls__576 *jrt.Class = A_arbace_c_repl_run_main_fn__1787000064_A_fn_class; if fncls__576 == nil { var fncls__576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__577); A_arbace_c_repl_run_main_fn__1787000064_A_fn_class = fncls__576d; tmp8 = fncls__576d } else { tmp8 = fncls__576 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__577, tmp8, nil); r__4 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O(); var tmp9 any = A_arbace_c_repl_A_const_88; if
	lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_c_repl_A_const_89.Invoke_O__O(r__4)) {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_90.Get__O()); var tmp11 any = A_arbace_c_repl_A_const_98.Invoke_O__O(r__4); var tmp12 any; var root_600 any = A_arbace_c_repl_A_const_68.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any; var root_604 any = A_arbace_c_repl_A_const_99.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = A_arbace_c_repl_A_const_31.GetRawRoot__O(); var arg_608 any; var root_609 any = A_arbace_c_repl_A_const_83.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any; var root_614 any = A_arbace_c_repl_A_const_31.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = ns__0; if linked_615 == nil { arg_612 = ifn_616.Invoke_O__O(arg_617) } else { arg_612 = linked_615.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_614, arg_617) }; var arg_613 any = args__1; if linked_610 == nil { arg_608 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { arg_608 = linked_610.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }; if linked_605 == nil { arg_603 = ifn_606.Invoke_O_O__O(arg_607, arg_608) } else { arg_603 = linked_605.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_604, arg_607, arg_608) }; if linked_601 == nil { tmp12 = ifn_602.Invoke_O__O(arg_603) } else { tmp12 = linked_601.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_600, arg_603) }; return tmp10.Invoke_O_O__O(tmp11, tmp12) } else {
//line :128:1
			var tmp13 any; var root_578 any = A_arbace_c_repl_A_const_50.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_580 lang.IFn

			if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_33, nil, Lit_34, nil); var tmp15 any; var root_583 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = A_arbace_c_repl_A_const_91.Invoke_O__O(r__4); if linked_584 == nil { tmp15 = ifn_585.Invoke_O__O(arg_586) } else { tmp15 = linked_584.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_583, arg_586) }; arg_581 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, nil, A_arbace_c_repl_A_const_92.Invoke_O__O(r__4))).Ref(); var tmp16 any = A_arbace_c_repl_A_const_93; var arg_582 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, A_arbace_c_repl_A_const_91.Invoke_O__O(r__4))); if linked_579 == nil { tmp13 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { tmp13 = linked_579.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) }
//line :128:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp13))) } }
//line :121:1
func A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_New() *A_arbace_c_repl_run_main_iter__1787000048__1787000052_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_iter__1787000048__1787000052_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_A) Ctor() {}
//line :121:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_A) Invoke_O_O__O(self, s__1787000049__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__557 any = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_New_O_O(self, s__1787000049__1); var tmp2 *jrt.Class; var fncls__556 *jrt.Class = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_fn_class; if fncls__556 == nil { var fncls__556d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__557); A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_fn_class = fncls__556d; tmp2 = fncls__556d } else { tmp2 = fncls__556 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__557, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :121:1
func A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_New_O_O(p0, p1 any) *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :121:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A) Ctor_O_O(c__iter__1787000048, c__s__1787000049 any) { t.F_iter__1787000048 = c__iter__1787000048; t.F_s__1787000049 = c__s__1787000049 }
//line :121:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A) Invoke_O__O(self any) any { { var s__1787000049__1 any; var t_ any = t.F_s__1787000049; t.F_s__1787000049 = nil; s__1787000049__1 = t_; for { var temp__1927000414__auto____2 any; var root_406 any = A_arbace_c_repl_A_const_69.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = s__1787000049__1; if linked_407 == nil { temp__1927000414__auto____2 = ifn_408.Invoke_O__O(arg_409) } else { temp__1927000414__auto____2 = linked_407.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_406, arg_409) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1787000049__3 any = temp__1927000414__auto____2; var tmp1 any; var root_410 any = A_arbace_c_repl_A_const_70.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = s__1787000049__3; if linked_411 == nil { tmp1 = ifn_412.Invoke_O__O(arg_413) } else { tmp1 = linked_411.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_410, arg_413) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_414 any = A_arbace_c_repl_A_const_71.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = s__1787000049__3; if linked_415 == nil { c__1927001037__auto____4 = ifn_416.Invoke_O__O(arg_417) } else { c__1927001037__auto____4 = linked_415.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_414, arg_417) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1787000051__6 any; var root_418 any = A_arbace_c_repl_A_const_72.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_419 == nil { b__1787000051__6 = ifn_420.Invoke_O__O(arg_421) } else { b__1787000051__6 = linked_419.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_418, arg_421) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__474 any = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_New_I_O_O(size__1927001038__auto____5, b__1787000051__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__473 *jrt.Class = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_fn_class; if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__474); A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_fn_class = fncls__473d; tmp3 = fncls__473d } else { tmp3 = fncls__473 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__474, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_475 any = A_arbace_c_repl_A_const_80.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any; var root_480 any = A_arbace_c_repl_A_const_81.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = b__1787000051__6; if linked_481 == nil { arg_478 = ifn_482.Invoke_O__O(arg_483) } else { arg_478 = linked_481.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_480, arg_483) }; var arg_479 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1787000048); var tmp5 any; var root_484 any = A_arbace_c_repl_A_const_82.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = s__1787000049__3; if linked_485 == nil { tmp5 = ifn_486.Invoke_O__O(arg_487) } else { tmp5 = linked_485.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_484, arg_487) }; arg_479 = tmp4.Invoke_O__O(tmp5); if linked_476 == nil { return ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { return linked_476.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) } } else { var root_488 any = A_arbace_c_repl_A_const_80.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any; var root_493 any = A_arbace_c_repl_A_const_81.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = b__1787000051__6; if linked_494 == nil { arg_491 = ifn_495.Invoke_O__O(arg_496) } else { arg_491 = linked_494.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_493, arg_496) }; var arg_492 any; if linked_489 == nil { return ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { return linked_489.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) } } } else { var vec__1787000059__4 any; var root_497 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = s__1787000049__3; if linked_498 == nil { vec__1787000059__4 = ifn_499.Invoke_O__O(arg_500) } else { vec__1787000059__4 = linked_498.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_497, arg_500) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000059__4, lang.RT_IntCast_J__I_NoInit(0), nil); var u__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000059__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_501 any = A_arbace_c_repl_A_const_83.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any; var fc__7 any; var root_506 any = A_arbace_c_repl_A_const_46.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_508 lang.IFn
														if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp7 any; var root_511 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var or__1927000174__auto____9 any = A_arbace_c_repl_A_const_35.Invoke_O__O(u__6); if jrt.J2g_Truth(or__1927000174__auto____9) { arg_514 = or__1927000174__auto____9 } else { arg_514 = A_arbace_c_repl_A_const_36 }; if linked_512 == nil { tmp7 = ifn_513.Invoke_O__O(arg_514) } else { tmp7 = linked_512.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_511, arg_514) }; arg_509 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref()); var arg_510 any; var root_515 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any; var or__1927000174__auto____7 any = A_arbace_c_repl_A_const_35.Invoke_O__O(u__6); if jrt.J2g_Truth(or__1927000174__auto____7) { arg_518 = or__1927000174__auto____7 } else { arg_518 = A_arbace_c_repl_A_const_36 }; if linked_516 == nil { arg_510 = ifn_517.Invoke_O__O(arg_518) } else { arg_510 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; if linked_507 == nil { fc__7 = ifn_508.Invoke_O_O__O(arg_509, arg_510) } else { fc__7 = linked_507.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_506, arg_509, arg_510) }
//line :121:1
	var cu__8 any; var root_519 any = A_arbace_c_repl_A_const_74.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_c_run.A_arbace_c_run_check_read_A_fn_class); var ifn_521 lang.IFn

	if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var root_525 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = A_arbace_c_repl_A_const_16.GetRawRoot__O(); if linked_526 == nil { arg_522 = ifn_527.Invoke_O__O(arg_528) } else { arg_522 = linked_526.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_525, arg_528) }; var arg_523 any = fc__7; var arg_524 any; var root_529 any = A_arbace_c_repl_A_const_75.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, A_arbace_c_repl_unit_read_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = u__6; if linked_530 == nil { arg_524 = ifn_531.Invoke_O__O(arg_532) } else { arg_524 = linked_530.(*A_arbace_c_repl_unit_read_A).Invoke_O_O__O(root_529, arg_532) }; if linked_520 == nil { cu__8 = ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { cu__8 = linked_520.(*aot_arbace_c_run.A_arbace_c_run_check_read_A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) }
	var tmp8 any; var root_533 any = A_arbace_c_repl_A_const_69.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = A_arbace_c_repl_A_const_76.Invoke_O__O(cu__8); if linked_534 == nil { tmp8 = ifn_535.Invoke_O__O(arg_536) } else { tmp8 = linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_537 any = A_arbace_c_repl_A_const_50.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_539 lang.IFn
		if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_38, nil); var tmp11 any; var root_542 any = A_arbace_c_repl_A_const_51.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = Lit_22; var arg_546 any; var root_547 any = A_arbace_c_repl_A_const_77.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = A_arbace_c_repl_A_const_78; var arg_551 any = A_arbace_c_repl_A_const_76.Invoke_O__O(cu__8); if linked_548 == nil { arg_546 = ifn_549.Invoke_O_O__O(arg_550, arg_551) } else { arg_546 = linked_548.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_547, arg_550, arg_551) }; if linked_543 == nil { tmp11 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { tmp11 = linked_543.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) }; arg_540 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, n__5, nil, tmp11)).Ref(); var arg_541 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_79, n__5)); if linked_538 == nil { tmp9 = ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { tmp9 = linked_538.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) }
//line :124:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) }
//line :121:1
	arg_504 = cu__8; var arg_505 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1787000048); var tmp13 any; var root_552 any = A_arbace_c_repl_A_const_57.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = s__1787000049__3; if linked_553 == nil { tmp13 = ifn_554.Invoke_O__O(arg_555) } else { tmp13 = linked_553.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_552, arg_555) }; arg_505 = tmp12.Invoke_O__O(tmp13); if linked_502 == nil { return ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { return linked_502.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :121:1
func A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :121:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1787000051, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1787000051 = c__b__1787000051; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :121:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A) Invoke_O__O(self any) any { { var i__1787000050__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1787000050__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1787000055__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1787000050__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000055__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000055__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_422 any = A_arbace_c_repl_A_const_73.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = t.F_b__1787000051; var arg_426 any; var fc__5 any; var root_427 any = A_arbace_c_repl_A_const_46.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_429 lang.IFn
																if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp3 any; var root_432 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any; var or__1927000174__auto____7 any = A_arbace_c_repl_A_const_35.Invoke_O__O(u__4); if jrt.J2g_Truth(or__1927000174__auto____7) { arg_435 = or__1927000174__auto____7 } else { arg_435 = A_arbace_c_repl_A_const_36 }; if linked_433 == nil { tmp3 = ifn_434.Invoke_O__O(arg_435) } else { tmp3 = linked_433.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_432, arg_435) }; arg_430 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref()); var arg_431 any; var root_436 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var or__1927000174__auto____5 any = A_arbace_c_repl_A_const_35.Invoke_O__O(u__4); if jrt.J2g_Truth(or__1927000174__auto____5) { arg_439 = or__1927000174__auto____5 } else { arg_439 = A_arbace_c_repl_A_const_36 }; if linked_437 == nil { arg_431 = ifn_438.Invoke_O__O(arg_439) } else { arg_431 = linked_437.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_436, arg_439) }; if linked_428 == nil { fc__5 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { fc__5 = linked_428.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }
//line :121:1
	var cu__6 any; var root_440 any = A_arbace_c_repl_A_const_74.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_c_run.A_arbace_c_run_check_read_A_fn_class); var ifn_442 lang.IFn

	if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any; var root_446 any = A_arbace_c_repl_A_const_9.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = A_arbace_c_repl_A_const_16.GetRawRoot__O(); if linked_447 == nil { arg_443 = ifn_448.Invoke_O__O(arg_449) } else { arg_443 = linked_447.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_446, arg_449) }; var arg_444 any = fc__5; var arg_445 any; var root_450 any = A_arbace_c_repl_A_const_75.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_c_repl_unit_read_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = u__4; if linked_451 == nil { arg_445 = ifn_452.Invoke_O__O(arg_453) } else { arg_445 = linked_451.(*A_arbace_c_repl_unit_read_A).Invoke_O_O__O(root_450, arg_453) }; if linked_441 == nil { cu__6 = ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { cu__6 = linked_441.(*aot_arbace_c_run.A_arbace_c_run_check_read_A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445) }
	var tmp4 any; var root_454 any = A_arbace_c_repl_A_const_69.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = A_arbace_c_repl_A_const_76.Invoke_O__O(cu__6); if linked_455 == nil { tmp4 = ifn_456.Invoke_O__O(arg_457) } else { tmp4 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_458 any = A_arbace_c_repl_A_const_50.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_460 lang.IFn
		if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_38, nil); var tmp7 any; var root_463 any = A_arbace_c_repl_A_const_51.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = Lit_22; var arg_467 any; var root_468 any = A_arbace_c_repl_A_const_77.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = A_arbace_c_repl_A_const_78; var arg_472 any = A_arbace_c_repl_A_const_76.Invoke_O__O(cu__6); if linked_469 == nil { arg_467 = ifn_470.Invoke_O_O__O(arg_471, arg_472) } else { arg_467 = linked_469.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_468, arg_471, arg_472) }; if linked_464 == nil { tmp7 = ifn_465.Invoke_O_O__O(arg_466, arg_467) } else { tmp7 = linked_464.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_463, arg_466, arg_467) }; arg_461 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__3, nil, tmp7)).Ref(); var arg_462 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_79, n__3)); if linked_459 == nil { tmp5 = ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { tmp5 = linked_459.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }
//line :124:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp5))) }
//line :121:1
	arg_426 = cu__6; if linked_423 == nil { ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { linked_423.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) }; i__1787000050__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1787000050__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_c_repl_run_main_fn__1787000064_A_New_O(p0 any) *A_arbace_c_repl_run_main_fn__1787000064_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_fn__1787000064_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_c_repl_run_main_fn__1787000064_A) Ctor_O(c__us any) { t.F_us = c__us }
//line :127:1
func (t *A_arbace_c_repl_run_main_fn__1787000064_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_569 any = A_arbace_c_repl_A_const_86.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_c_run.A_arbace_c_run_nodes_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any; var t_ any = t.F_us; t.F_us = nil; arg_572 = t_; if linked_570 == nil { tmp1 = ifn_571.Invoke_O__O(arg_572) } else { tmp1 = linked_570.(*aot_arbace_c_run.A_arbace_c_run_nodes_A).Invoke_O_O__O(root_569, arg_572) } }; return nil }(); var root_573 any = A_arbace_c_repl_A_const_87.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; if linked_574 == nil { ifn_575.Invoke__O() } else { linked_574.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_573) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_c_repl_reset_unit_BANG__A_New() *A_arbace_c_repl_reset_unit_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_reset_unit_BANG__A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_c_repl_reset_unit_BANG__A) Ctor() {}
//line :132:1
func (t *A_arbace_c_repl_reset_unit_BANG__A) Invoke_O_O__O(self, ns__0 any) any {


	var root_618 any = A_arbace_c_repl_A_const_32.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = A_arbace_c_repl_A_const_33.GetRawRoot__O(); var arg_622 any = A_arbace_c_repl_A_const_100.GetRawRoot__O(); var arg_623 any = ns__0; if linked_619 == nil { ifn_620.Invoke_O_O_O__O(arg_621, arg_622, arg_623) } else { linked_619.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_618, arg_621, arg_622, arg_623) }
//line :132:1
	return nil
}




func A_arbace_c_repl__main_A_New() *A_arbace_c_repl__main_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl__main_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_c_repl__main_A) Ctor() {}
//line :138:1
func (t *A_arbace_c_repl__main_A) DoInvoke_O_O__O(self, args__0 any) any { var G__1787000068__2_ any; var root_624 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_626 lang.IFn; if




	linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = args__0; if linked_625 == nil { G__1787000068__2_ = ifn_626.Invoke_O__O(arg_627) } else { G__1787000068__2_ = linked_625.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_624, arg_627) }; switch lang.Util_Hash_O__I_NoInit(G__1787000068__2_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000068__2_, Lit_1) {





		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_102.GetRawRoot__O()); var tmp2 any; var root_653 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any; var root_657 any = A_arbace_c_repl_A_const_103.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_c_repl_backend_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; if linked_658 == nil { arg_656 = ifn_659.Invoke__O() } else { arg_656 = linked_658.(*A_arbace_c_repl_backend_A).Invoke_O__O(root_657) }; if linked_654 == nil { tmp2 = ifn_655.Invoke_O__O(arg_656) } else { tmp2 = linked_654.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_653, arg_656) }; tmp1.Invoke_O__O(tmp2); var root_660 any = A_arbace_c_repl_A_const_104.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; if linked_661 == nil { ifn_662.Invoke__O() } else { linked_661.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_660) }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :143:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000068__2_, Lit_2) { var vec__1787000069__3 any = args__0; var seq__1787000070__4 any; var root_629 any = A_arbace_c_repl_A_const_69.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_631 lang.IFn
		if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = vec__1787000069__3; if linked_630 == nil { seq__1787000070__4 = ifn_631.Invoke_O__O(arg_632) } else { seq__1787000070__4 = linked_630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_629, arg_632) }
//line :143:1
		var first__1787000071__5 any; var root_633 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_635 lang.IFn
		if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = seq__1787000070__4; if linked_634 == nil { first__1787000071__5 = ifn_635.Invoke_O__O(arg_636) } else { first__1787000071__5 = linked_634.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_633, arg_636) }
//line :143:1
		var seq__1787000070__6 any; var root_637 any = A_arbace_c_repl_A_const_101.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_639 lang.IFn
		if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = seq__1787000070__4; if linked_638 == nil { seq__1787000070__6 = ifn_639.Invoke_O__O(arg_640) } else { seq__1787000070__6 = linked_638.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_637, arg_640) }
//line :143:1
		var ___7 any = first__1787000071__5; var first__1787000071__8 any; var root_641 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_643 lang.IFn; _ = ___7
		if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = seq__1787000070__6; if linked_642 == nil { first__1787000071__8 = ifn_643.Invoke_O__O(arg_644) } else { first__1787000071__8 = linked_642.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_641, arg_644) }
//line :143:1
		var seq__1787000070__9 any; var root_645 any = A_arbace_c_repl_A_const_101.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_647 lang.IFn
		if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = seq__1787000070__6; if linked_646 == nil { seq__1787000070__9 = ifn_647.Invoke_O__O(arg_648) } else { seq__1787000070__9 = linked_646.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_645, arg_648) }
//line :143:1
		var f__10 any = first__1787000071__8; var more__11 any = seq__1787000070__9; var st__12 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_90.Get__O()); var tmp4 any = lang.IFn_Cast(A_arbace_c_repl_A_const_58.GetRawRoot__O()).Invoke_O__O(f__10); var tmp5 any; var root_667 any = A_arbace_c_repl_A_const_68.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_669 lang.IFn

		if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any; var root_671 any = A_arbace_c_repl_A_const_83.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = Lit_3; var arg_675 any = more__11; if linked_672 == nil { arg_670 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { arg_670 = linked_672.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; if linked_668 == nil { tmp5 = ifn_669.Invoke_O__O(arg_670) } else { tmp5 = linked_668.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_667, arg_670) }; st__12 = tmp3.Invoke_O_O__O(tmp4, tmp5)
		var root_676 any = A_arbace_c_repl_A_const_60.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; if linked_677 == nil { ifn_678.Invoke__O() } else { linked_677.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_676) }
		var root_679 any = A_arbace_c_repl_A_const_104.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; if linked_680 == nil { ifn_681.Invoke__O() } else { linked_680.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_679) }
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(st__12)); return nil }
//line :143:1
	default:}; var root_691 any =






	A_arbace_c_repl_A_const_94.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_95.GetRawRoot__O()); var tmp7 any = A_arbace_c_repl_A_const_105; var arg_694 any = tmp6.Invoke_O_O__O(tmp7, A_arbace_c_repl_A_const_106.Get__O()); if linked_692 == nil { ifn_693.Invoke_O__O(arg_694) } else { linked_692.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_691, arg_694) }; var tmp8 *lang.Compiler_AOTFn; var fnbody__690 any = A_arbace_c_repl__main_fn__1787000072_A_New(); var tmp9 *jrt.Class; var fncls__689 *jrt.Class = A_arbace_c_repl__main_fn__1787000072_A_fn_class; if fncls__689 == nil { var fncls__689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c_repl__main_fn__1787000072_A_fn_class = fncls__689d; tmp9 = fncls__689d } else { tmp9 = fncls__689 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__690, tmp9, nil); Up_Compiler_AOTFn_IFn(tmp8).Invoke__O();
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :150:1
func A_arbace_c_repl__main_fn__1787000072_A_New() *A_arbace_c_repl__main_fn__1787000072_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl__main_fn__1787000072_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_c_repl__main_fn__1787000072_A) Ctor() {}
//line :150:1
func (t *A_arbace_c_repl__main_fn__1787000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_c_repl_A_const_102.GetRawRoot__O()).Invoke_O__O(Lit_5); return nil }(); var root_686 any = A_arbace_c_repl_A_const_87.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; if linked_687 == nil { ifn_688.Invoke__O() } else { linked_687.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_686) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }































type A_arbace_c_repl_A struct{ jrt.Object }

var A_arbace_c_repl_A_const_pool *jrt.RefArray

var A_arbace_c_repl_A_const_0 *lang.Var

var A_arbace_c_repl_A_const_1 any

var A_arbace_c_repl_A_const_2 any

var A_arbace_c_repl_A_const_3 any

var A_arbace_c_repl_A_const_4 any

var A_arbace_c_repl_A_const_5 any

var A_arbace_c_repl_A_const_6 *lang.Var

var A_arbace_c_repl_A_const_7 any

var A_arbace_c_repl_A_const_8 *lang.Var

var A_arbace_c_repl_A_const_9 *lang.Var

var A_arbace_c_repl_A_const_10 *lang.Var

var A_arbace_c_repl_A_const_11 *lang.Var

var A_arbace_c_repl_A_const_12 any

var A_arbace_c_repl_A_const_13 *lang.Var

var A_arbace_c_repl_A_const_14 *lang.Var

var A_arbace_c_repl_A_const_15 *lang.Var

var A_arbace_c_repl_A_const_16 *lang.Var

var A_arbace_c_repl_A_const_17 *lang.Var

var A_arbace_c_repl_A_const_18 *lang.Var

var A_arbace_c_repl_A_const_19 any

var A_arbace_c_repl_A_const_20 *lang.Var

var A_arbace_c_repl_A_const_21 *lang.Var

var A_arbace_c_repl_A_const_22 *lang.Var

var A_arbace_c_repl_A_const_23 any

var A_arbace_c_repl_A_const_24 any

var A_arbace_c_repl_A_const_25 any

var A_arbace_c_repl_A_const_26 any

var A_arbace_c_repl_A_const_27 any

var A_arbace_c_repl_A_const_28 any

var A_arbace_c_repl_A_const_29 *lang.Var

var A_arbace_c_repl_A_const_30 *lang.Var

var A_arbace_c_repl_A_const_31 *lang.Var

var A_arbace_c_repl_A_const_32 *lang.Var

var A_arbace_c_repl_A_const_33 *lang.Var

var A_arbace_c_repl_A_const_34 *lang.Var

var A_arbace_c_repl_A_const_35 *lang.Keyword

var A_arbace_c_repl_A_const_36 *lang.Keyword

var A_arbace_c_repl_A_const_37 *lang.Keyword

var A_arbace_c_repl_A_const_38 *lang.Keyword

var A_arbace_c_repl_A_const_39 *lang.Var

var A_arbace_c_repl_A_const_40 *lang.Var

var A_arbace_c_repl_A_const_41 *lang.Var

var A_arbace_c_repl_A_const_42 *lang.Var

var A_arbace_c_repl_A_const_43 *jrt.Class

var A_arbace_c_repl_A_const_44 *lang.Var

var A_arbace_c_repl_A_const_45 *lang.Var

var A_arbace_c_repl_A_const_46 *lang.Var

var A_arbace_c_repl_A_const_47 *lang.Var

var A_arbace_c_repl_A_const_48 *lang.Var

var A_arbace_c_repl_A_const_49 *lang.Keyword

var A_arbace_c_repl_A_const_50 *lang.Var

var A_arbace_c_repl_A_const_51 *lang.Var

var A_arbace_c_repl_A_const_52 *lang.Keyword

var A_arbace_c_repl_A_const_53 *lang.Var

var A_arbace_c_repl_A_const_54 *lang.Var

var A_arbace_c_repl_A_const_55 *lang.Var

var A_arbace_c_repl_A_const_56 any

var A_arbace_c_repl_A_const_57 *lang.Var

var A_arbace_c_repl_A_const_58 *lang.Var

var A_arbace_c_repl_A_const_59 *lang.Var

var A_arbace_c_repl_A_const_60 *lang.Var

var A_arbace_c_repl_A_const_61 *lang.Var

var A_arbace_c_repl_A_const_62 any

var A_arbace_c_repl_A_const_63 any

var A_arbace_c_repl_A_const_64 *lang.Var

var A_arbace_c_repl_A_const_65 *lang.Var

var A_arbace_c_repl_A_const_66 *lang.Keyword

var A_arbace_c_repl_A_const_67 *lang.Keyword

var A_arbace_c_repl_A_const_68 *lang.Var

var A_arbace_c_repl_A_const_69 *lang.Var

var A_arbace_c_repl_A_const_70 *lang.Var

var A_arbace_c_repl_A_const_71 *lang.Var

var A_arbace_c_repl_A_const_72 *lang.Var

var A_arbace_c_repl_A_const_73 *lang.Var

var A_arbace_c_repl_A_const_74 *lang.Var

var A_arbace_c_repl_A_const_75 *lang.Var

var A_arbace_c_repl_A_const_76 *lang.Keyword

var A_arbace_c_repl_A_const_77 *lang.Var

var A_arbace_c_repl_A_const_78 any

var A_arbace_c_repl_A_const_79 *lang.Keyword

var A_arbace_c_repl_A_const_80 *lang.Var

var A_arbace_c_repl_A_const_81 *lang.Var

var A_arbace_c_repl_A_const_82 *lang.Var

var A_arbace_c_repl_A_const_83 *lang.Var

var A_arbace_c_repl_A_const_84 *lang.Var

var A_arbace_c_repl_A_const_85 *lang.Var

var A_arbace_c_repl_A_const_86 *lang.Var

var A_arbace_c_repl_A_const_87 *lang.Var

var A_arbace_c_repl_A_const_88 *lang.Keyword

var A_arbace_c_repl_A_const_89 *lang.Keyword

var A_arbace_c_repl_A_const_90 *lang.Var

var A_arbace_c_repl_A_const_91 *lang.Keyword

var A_arbace_c_repl_A_const_92 *lang.Keyword

var A_arbace_c_repl_A_const_93 *lang.Keyword

var A_arbace_c_repl_A_const_94 *lang.Var

var A_arbace_c_repl_A_const_95 *lang.Var

var A_arbace_c_repl_A_const_96 *lang.Var

var A_arbace_c_repl_A_const_97 *lang.Var

var A_arbace_c_repl_A_const_98 *lang.Keyword

var A_arbace_c_repl_A_const_99 *lang.Var

var A_arbace_c_repl_A_const_100 *lang.Var

var A_arbace_c_repl_A_const_101 *lang.Var

var A_arbace_c_repl_A_const_102 *lang.Var

var A_arbace_c_repl_A_const_103 *lang.Var

var A_arbace_c_repl_A_const_104 *lang.Var

var A_arbace_c_repl_A_const_105 *lang.Var

var A_arbace_c_repl_A_const_106 *lang.Var

var A_arbace_c_repl_A_init jrt.ClassInit

func A_arbace_c_repl_A_Init() { if !A_arbace_c_repl_A_init.Done() { A_arbace_c_repl_A_init.Run(A_arbace_c_repl_A_clinit) } }

func A_arbace_c_repl_A_clinit() { A_arbace_c_repl_A_clinit_p0(); A_arbace_c_repl_A_clinit_p1(); A_arbace_c_repl_A_clinit_p2(); A_arbace_c_repl_A_clinit_p3(); A_arbace_c_repl_A_clinit_p4(); A_arbace_c_repl_A_clinit_p5(); A_arbace_c_repl_A_clinit_p6(); A_arbace_c_repl_A_clinit_p7(); A_arbace_c_repl_A_clinit_p8() }

func A_arbace_c_repl_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 146); A_arbace_c_repl_A_const_0 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[39]); A_arbace_c_repl_A_const_1 = A_arbace_c_repl_A_const_pool.A[40]; A_arbace_c_repl_A_const_2 = A_arbace_c_repl_A_const_pool.A[41]; A_arbace_c_repl_A_const_3 = A_arbace_c_repl_A_const_pool.A[42]; A_arbace_c_repl_A_const_4 = A_arbace_c_repl_A_const_pool.A[43]; A_arbace_c_repl_A_const_5 = A_arbace_c_repl_A_const_pool.A[44]; A_arbace_c_repl_A_const_6 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[45]); A_arbace_c_repl_A_const_7 = A_arbace_c_repl_A_const_pool.A[46]; A_arbace_c_repl_A_const_8 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[47]); A_arbace_c_repl_A_const_9 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[48]); A_arbace_c_repl_A_const_10 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[49]); A_arbace_c_repl_A_const_11 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[50]); A_arbace_c_repl_A_const_12 = A_arbace_c_repl_A_const_pool.A[51] }

func A_arbace_c_repl_A_clinit_p1() { A_arbace_c_repl_A_const_13 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[52]); A_arbace_c_repl_A_const_14 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[53]); A_arbace_c_repl_A_const_15 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[54]); A_arbace_c_repl_A_const_16 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[55]); A_arbace_c_repl_A_const_17 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[56]); A_arbace_c_repl_A_const_18 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[57]); A_arbace_c_repl_A_const_19 = A_arbace_c_repl_A_const_pool.A[58]; A_arbace_c_repl_A_const_20 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[59]); A_arbace_c_repl_A_const_21 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[60]); A_arbace_c_repl_A_const_22 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[61]); A_arbace_c_repl_A_const_23 = A_arbace_c_repl_A_const_pool.A[62]; A_arbace_c_repl_A_const_24 = A_arbace_c_repl_A_const_pool.A[63]; A_arbace_c_repl_A_const_25 = A_arbace_c_repl_A_const_pool.A[64] }

func A_arbace_c_repl_A_clinit_p2() { A_arbace_c_repl_A_const_26 = A_arbace_c_repl_A_const_pool.A[65]; A_arbace_c_repl_A_const_27 = A_arbace_c_repl_A_const_pool.A[66]; A_arbace_c_repl_A_const_28 = A_arbace_c_repl_A_const_pool.A[67]; A_arbace_c_repl_A_const_29 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[68]); A_arbace_c_repl_A_const_30 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[69]); A_arbace_c_repl_A_const_31 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[70]); A_arbace_c_repl_A_const_32 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[71]); A_arbace_c_repl_A_const_33 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[72]); A_arbace_c_repl_A_const_34 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[73]); A_arbace_c_repl_A_const_35 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[74]); A_arbace_c_repl_A_const_36 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[75]); A_arbace_c_repl_A_const_37 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[76]) }

func A_arbace_c_repl_A_clinit_p3() { A_arbace_c_repl_A_const_38 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[77]); A_arbace_c_repl_A_const_39 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[78]); A_arbace_c_repl_A_const_40 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[79]); A_arbace_c_repl_A_const_41 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[80]); A_arbace_c_repl_A_const_42 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[81]); A_arbace_c_repl_A_const_43 = jrt.Class_Cast(A_arbace_c_repl_A_const_pool.A[82]); A_arbace_c_repl_A_const_44 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[83]); A_arbace_c_repl_A_const_45 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[84]); A_arbace_c_repl_A_const_46 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[85]); A_arbace_c_repl_A_const_47 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[86]); A_arbace_c_repl_A_const_48 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[87]); A_arbace_c_repl_A_const_49 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[88]) }

func A_arbace_c_repl_A_clinit_p4() { A_arbace_c_repl_A_const_50 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[89]); A_arbace_c_repl_A_const_51 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[90]); A_arbace_c_repl_A_const_52 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[91]); A_arbace_c_repl_A_const_53 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[92]); A_arbace_c_repl_A_const_54 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[93]); A_arbace_c_repl_A_const_55 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[94]); A_arbace_c_repl_A_const_56 = A_arbace_c_repl_A_const_pool.A[95]; A_arbace_c_repl_A_const_57 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[96]); A_arbace_c_repl_A_const_58 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[97]); A_arbace_c_repl_A_const_59 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[98]); A_arbace_c_repl_A_const_60 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[99]); A_arbace_c_repl_A_const_61 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[100]) }

func A_arbace_c_repl_A_clinit_p5() { A_arbace_c_repl_A_const_62 = A_arbace_c_repl_A_const_pool.A[101]; A_arbace_c_repl_A_const_63 = A_arbace_c_repl_A_const_pool.A[102]; A_arbace_c_repl_A_const_64 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[103]); A_arbace_c_repl_A_const_65 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[104]); A_arbace_c_repl_A_const_66 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[105]); A_arbace_c_repl_A_const_67 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[106]); A_arbace_c_repl_A_const_68 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[107]); A_arbace_c_repl_A_const_69 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[108]); A_arbace_c_repl_A_const_70 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[109]); A_arbace_c_repl_A_const_71 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[110]); A_arbace_c_repl_A_const_72 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[111]); A_arbace_c_repl_A_const_73 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[112]) }

func A_arbace_c_repl_A_clinit_p6() { A_arbace_c_repl_A_const_74 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[113]); A_arbace_c_repl_A_const_75 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[114]); A_arbace_c_repl_A_const_76 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[115]); A_arbace_c_repl_A_const_77 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[116]); A_arbace_c_repl_A_const_78 = A_arbace_c_repl_A_const_pool.A[117]; A_arbace_c_repl_A_const_79 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[118]); A_arbace_c_repl_A_const_80 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[119]); A_arbace_c_repl_A_const_81 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[120]); A_arbace_c_repl_A_const_82 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[121]); A_arbace_c_repl_A_const_83 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[122]); A_arbace_c_repl_A_const_84 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[123]); A_arbace_c_repl_A_const_85 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[124]) }

func A_arbace_c_repl_A_clinit_p7() { A_arbace_c_repl_A_const_86 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[125]); A_arbace_c_repl_A_const_87 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[126]); A_arbace_c_repl_A_const_88 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[127]); A_arbace_c_repl_A_const_89 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[128]); A_arbace_c_repl_A_const_90 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[129]); A_arbace_c_repl_A_const_91 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[130]); A_arbace_c_repl_A_const_92 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[131]); A_arbace_c_repl_A_const_93 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[132]); A_arbace_c_repl_A_const_94 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[133]); A_arbace_c_repl_A_const_95 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[134]); A_arbace_c_repl_A_const_96 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[135]); A_arbace_c_repl_A_const_97 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[136]) }

func A_arbace_c_repl_A_clinit_p8() { A_arbace_c_repl_A_const_98 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[137]); A_arbace_c_repl_A_const_99 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[138]); A_arbace_c_repl_A_const_100 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[139]); A_arbace_c_repl_A_const_101 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[140]); A_arbace_c_repl_A_const_102 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[141]); A_arbace_c_repl_A_const_103 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[142]); A_arbace_c_repl_A_const_104 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[143]); A_arbace_c_repl_A_const_105 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[144]); A_arbace_c_repl_A_const_106 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[145]) }

func A_arbace_c_repl_A_New() *A_arbace_c_repl_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_c_repl_A) Ctor() {}

func (t *A_arbace_c_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_repl_A) GetClass__Class() *jrt.Class { return A_arbace_c_repl_A_class }

func (t *A_arbace_c_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_repl_A); return ok }

func A_arbace_c_repl_A_Cast(x any) *A_arbace_c_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_repl_A_class)) }; return v }



type A_arbace_c_repl__main_A struct{ j2g_header uint64 }

var A_arbace_c_repl__main_A_fn_class *jrt.Class



type A_arbace_c_repl__main_fn__1787000072_A struct{ j2g_header uint64 }

var A_arbace_c_repl__main_fn__1787000072_A_fn_class *jrt.Class



type A_arbace_c_repl_backend_A struct{ j2g_header uint64 }

var A_arbace_c_repl_backend_A_fn_class *jrt.Class



type A_arbace_c_repl_decl_name_A struct{ j2g_header uint64 }

var A_arbace_c_repl_decl_name_A_fn_class *jrt.Class



type A_arbace_c_repl_declare_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_declare_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_declare_BANG__fn__1787000023_A struct{ j2g_header uint64; F_f, F_n any }

var A_arbace_c_repl_declare_BANG__fn__1787000023_A_fn_class *jrt.Class



type A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A struct{ j2g_header uint64; F_f, F_n any }

var A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_fn_class *jrt.Class



type A_arbace_c_repl_eval1787000004_A struct{ jrt.Object }

func A_arbace_c_repl_eval1787000004_A_New() *A_arbace_c_repl_eval1787000004_A { t := &A_arbace_c_repl_eval1787000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_repl_eval1787000004_A) Ctor() {}

func (t *A_arbace_c_repl_eval1787000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_repl_eval1787000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_repl_eval1787000004_A_class }

func (t *A_arbace_c_repl_eval1787000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_repl_eval1787000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_repl_eval1787000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_repl_eval1787000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_repl_eval1787000004_A); return ok }

func A_arbace_c_repl_eval1787000004_A_Cast(x any) *A_arbace_c_repl_eval1787000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_repl_eval1787000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_repl_eval1787000004_A_class)) }; return v }



type A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A struct{ j2g_header uint64 }

var A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A_fn_class *jrt.Class



type A_arbace_c_repl_eval1787000008_A struct{ jrt.Object }

func A_arbace_c_repl_eval1787000008_A_New() *A_arbace_c_repl_eval1787000008_A { t := &A_arbace_c_repl_eval1787000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_repl_eval1787000008_A) Ctor() {}

func (t *A_arbace_c_repl_eval1787000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_repl_eval1787000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_repl_eval1787000008_A_class }

func (t *A_arbace_c_repl_eval1787000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_repl_eval1787000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_repl_eval1787000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_repl_eval1787000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_repl_eval1787000008_A); return ok }

func A_arbace_c_repl_eval1787000008_A_Cast(x any) *A_arbace_c_repl_eval1787000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_repl_eval1787000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_repl_eval1787000008_A_class)) }; return v }



type A_arbace_c_repl_eval1787000008_fn__1787000009_A struct{ j2g_header uint64 }

var A_arbace_c_repl_eval1787000008_fn__1787000009_A_fn_class *jrt.Class



type A_arbace_c_repl_file_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_file_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_file_BANG__fn__1787000030_A struct{ j2g_header uint64 }

var A_arbace_c_repl_file_BANG__fn__1787000030_A_fn_class *jrt.Class



type A_arbace_c_repl_file_BANG__fn__1787000032_A struct{ j2g_header uint64; F_std any }

var A_arbace_c_repl_file_BANG__fn__1787000032_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000017_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000017_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000019_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000019_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000043_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000043_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000045_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000045_A_fn_class *jrt.Class



type A_arbace_c_repl_include_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_include_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_include_BANG__fn__1787000036_A struct{ j2g_header uint64; F_rd any }

var A_arbace_c_repl_include_BANG__fn__1787000036_A_fn_class *jrt.Class



type A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A struct{ j2g_header uint64 }

var A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_fn_class *jrt.Class



type A_arbace_c_repl_light_run_nodes_A struct{ j2g_header uint64 }

var A_arbace_c_repl_light_run_nodes_A_fn_class *jrt.Class



type A_arbace_c_repl_reset_unit_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_reset_unit_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_root_A struct{ j2g_header uint64 }

var A_arbace_c_repl_root_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_A struct{ j2g_header uint64 }

var A_arbace_c_repl_run_main_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_fn__1787000064_A struct{ j2g_header uint64; F_us any }

var A_arbace_c_repl_run_main_fn__1787000064_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_iter__1787000048__1787000052_A struct{ j2g_header uint64 }

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A struct{ j2g_header uint64; F_iter__1787000048, F_s__1787000049 any }

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1787000051, F_c__1927001037__auto__ any }

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_fn_class *jrt.Class



type A_arbace_c_repl_unit_read_A struct{ j2g_header uint64 }

var A_arbace_c_repl_unit_read_A_fn_class *jrt.Class
