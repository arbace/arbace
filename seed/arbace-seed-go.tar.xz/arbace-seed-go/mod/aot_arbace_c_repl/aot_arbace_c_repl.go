//line aot_arbace_c_repl.ae:1
package aot_arbace_c_repl

import (
	"arbace/aot_arbace_c_run"
	"arbace/aot_arbace_c_runtime"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_c"
	"arbace/aot_arbace_repr_c_host"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A_New() *A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_repl_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c_repl_A_const_8); tmp2 = lang.IFn_Cast(A_arbace_c_repl_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_c_repl_A_const_1, A_arbace_c_repl_A_const_2, A_arbace_c_repl_A_const_3, A_arbace_c_repl_A_const_4, A_arbace_c_repl_A_const_5, A_arbace_c_repl_A_const_6); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_repl_eval1787000008_fn__1787000009_A_New() *A_arbace_c_repl_eval1787000008_fn__1787000009_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_eval1787000008_fn__1787000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_repl_eval1787000008_fn__1787000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_repl_eval1787000008_fn__1787000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_c_repl_A_const_11; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_20, arg_23) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_repl_A_const_12.GetRawRoot__O(), A_arbace_c_repl_A_const_13) }























func A_arbace_c_repl_root_A_New() *A_arbace_c_repl_root_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_root_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_c_repl_root_A) Ctor() {}
//line :25:1
func (t *A_arbace_c_repl_root_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any = jrt.System_Getenv_String__String(Lit_29).Ref(); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { return jrt.System_GetProperty_String__String(Lit_30).Ref() } }

func A_arbace_c_repl_fn__1787000017_A_New() *A_arbace_c_repl_fn__1787000017_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000017_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c_repl_fn__1787000017_A) Ctor() {}
//line :27:1
func (t *A_arbace_c_repl_fn__1787000017_A) Invoke_O__O(self any) any { var root_24 any = A_arbace_c_repl_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_11); var tmp2 any; var root_28 any = A_arbace_c_repl_A_const_15.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_c_repl_root_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; if linked_29 == nil { tmp2 = ifn_30.Invoke__O() } else { tmp2 = linked_29.(*A_arbace_c_repl_root_A).Invoke_O__O(root_28) }; arg_27 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref(); if linked_25 == nil { return ifn_26.Invoke_O__O(arg_27) } else { return linked_25.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A).Invoke_O_O__O(root_24, arg_27) } }
func A_arbace_c_repl_fn__1787000019_A_New() *A_arbace_c_repl_fn__1787000019_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000019_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_c_repl_fn__1787000019_A) Ctor() {}
//line :28:1
func (t *A_arbace_c_repl_fn__1787000019_A) Invoke_O__O(self any) any { var root_31 any = A_arbace_c_repl_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_c_runtime.A_arbace_c_runtime_library_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var root_36 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); if linked_37 == nil { arg_34 = ifn_38.Invoke_O__O(arg_39) } else { arg_34 = linked_37.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_36, arg_39) }; var arg_35 any; var root_40 any = A_arbace_c_repl_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, A_arbace_c_repl_root_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; if linked_41 == nil { arg_35 = ifn_42.Invoke__O() } else { arg_35 = linked_41.(*A_arbace_c_repl_root_A).Invoke_O__O(root_40) }; if linked_32 == nil { return ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { return linked_32.(*aot_arbace_c_runtime.A_arbace_c_runtime_library_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) } }

func A_arbace_c_repl_decl_name_A_New() *A_arbace_c_repl_decl_name_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_decl_name_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_c_repl_decl_name_A) Ctor() {}
//line :30:1
func (t *A_arbace_c_repl_decl_name_A) Invoke_O_O__O(self, f__0 any) any {


	var tmp1 any; var root_43 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = f__0; if linked_44 == nil { tmp1 = ifn_45.Invoke_O__O(arg_46) } else { tmp1 = linked_44.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_43, arg_46) }; if jrt.J2g_Truth(tmp1) { var G__1787000021__2_ any; var root_47 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_49 lang.IFn
		if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = f__0; if linked_48 == nil { G__1787000021__2_ = ifn_49.Invoke_O__O(arg_50) } else { G__1787000021__2_ = linked_48.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_47, arg_50) }; switch lang.Util_Hash_O__I_NoInit(G__1787000021__2_) >> 11 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_20) { var n__3 any; var root_52 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_54 lang.IFn
			if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = f__0; if linked_53 == nil { n__3 = ifn_54.Invoke_O__O(arg_55) } else { n__3 = linked_53.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_52, arg_55) }; var tmp2 any; var root_56 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = n__3; if linked_57 == nil { tmp2 = ifn_58.Invoke_O__O(arg_59) } else { tmp2 = linked_57.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_56, arg_59) }; if jrt.J2g_Truth(tmp2) { var root_60 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = n__3; if linked_61 == nil { return ifn_62.Invoke_O__O(arg_63) } else { return linked_61.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_60, arg_63) } } else { var tmp3 any; var root_64 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = n__3; if linked_65 == nil { tmp3 = ifn_66.Invoke_O__O(arg_67) } else { tmp3 = linked_65.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_64, arg_67) }; if jrt.J2g_Truth(tmp3) { var root_68 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = n__3; if linked_69 == nil { return ifn_70.Invoke_O__O(arg_71) } else { return linked_69.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_68, arg_71) } } else { return nil } } }
//line :34:1
		case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_24) { var n__3_2 any; var root_72 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_74 lang.IFn

			if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = f__0; if linked_73 == nil { n__3_2 = ifn_74.Invoke_O__O(arg_75) } else { n__3_2 = linked_73.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_72, arg_75) }; var tmp4 any; var root_76 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = n__3_2; if linked_77 == nil { tmp4 = ifn_78.Invoke_O__O(arg_79) } else { tmp4 = linked_77.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_76, arg_79) }; if jrt.J2g_Truth(tmp4) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil); var tmp6 any; var root_80 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = f__0; if linked_81 == nil { tmp6 = ifn_82.Invoke_O__O(arg_83) } else { tmp6 = linked_81.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_80, arg_83) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil, n__3_2)).Ref() } else { return nil } }
//line :34:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_25) { var n__3_3 any; var root_84 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_86 lang.IFn

			if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = f__0; if linked_85 == nil { n__3_3 = ifn_86.Invoke_O__O(arg_87) } else { n__3_3 = linked_85.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_84, arg_87) }; var tmp7 any; var root_88 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = n__3_3; if linked_89 == nil { tmp7 = ifn_90.Invoke_O__O(arg_91) } else { tmp7 = linked_89.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_88, arg_91) }; if jrt.J2g_Truth(tmp7) { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil); var tmp9 any; var root_92 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = f__0; if linked_93 == nil { tmp9 = ifn_94.Invoke_O__O(arg_95) } else { tmp9 = linked_93.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_92, arg_95) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, n__3_3)).Ref() } else { return nil } }
//line :34:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_26) { var n__3_4 any; var root_96 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_98 lang.IFn

			if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = f__0; if linked_97 == nil { n__3_4 = ifn_98.Invoke_O__O(arg_99) } else { n__3_4 = linked_97.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_96, arg_99) }; var tmp10 any; var root_100 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = n__3_4; if linked_101 == nil { tmp10 = ifn_102.Invoke_O__O(arg_103) } else { tmp10 = linked_101.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(tmp10) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil); var tmp12 any; var root_104 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = f__0; if linked_105 == nil { tmp12 = ifn_106.Invoke_O__O(arg_107) } else { tmp12 = linked_105.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_104, arg_107) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, n__3_4)).Ref() } else { return nil } }
//line :34:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_27) { var n__3_5 any; var root_108 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_110 lang.IFn
			if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = f__0; if linked_109 == nil { n__3_5 = ifn_110.Invoke_O__O(arg_111) } else { n__3_5 = linked_109.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_108, arg_111) }; var tmp13 any; var root_112 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = n__3_5; if linked_113 == nil { tmp13 = ifn_114.Invoke_O__O(arg_115) } else { tmp13 = linked_113.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(tmp13) { var root_116 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = n__3_5; if linked_117 == nil { return ifn_118.Invoke_O__O(arg_119) } else { return linked_117.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_116, arg_119) } } else { var tmp14 any; var root_120 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = n__3_5; if linked_121 == nil { tmp14 = ifn_122.Invoke_O__O(arg_123) } else { tmp14 = linked_121.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(tmp14) { var root_124 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = n__3_5; if linked_125 == nil { return ifn_126.Invoke_O__O(arg_127) } else { return linked_125.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_124, arg_127) } } else { return nil } } }
//line :34:1
		case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_28) { var n__3_6 any; var root_128 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_130 lang.IFn
			if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = f__0; if linked_129 == nil { n__3_6 = ifn_130.Invoke_O__O(arg_131) } else { n__3_6 = linked_129.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_128, arg_131) }; var tmp15 any; var root_132 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = n__3_6; if linked_133 == nil { tmp15 = ifn_134.Invoke_O__O(arg_135) } else { tmp15 = linked_133.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_132, arg_135) }; if jrt.J2g_Truth(tmp15) { var root_136 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = n__3_6; if linked_137 == nil { return ifn_138.Invoke_O__O(arg_139) } else { return linked_137.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_136, arg_139) } } else { var tmp16 any; var root_140 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = n__3_6; if linked_141 == nil { tmp16 = ifn_142.Invoke_O__O(arg_143) } else { tmp16 = linked_141.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp16) { var root_144 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = n__3_6; if linked_145 == nil { return ifn_146.Invoke_O__O(arg_147) } else { return linked_145.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_144, arg_147) } } else { return nil } } }
//line :34:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000021__2_, A_arbace_c_repl_A_const_29) { var n__3_7 any; var root_148 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_150 lang.IFn
			if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = f__0; if linked_149 == nil { n__3_7 = ifn_150.Invoke_O__O(arg_151) } else { n__3_7 = linked_149.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_148, arg_151) }; var tmp17 any; var root_152 any = A_arbace_c_repl_A_const_22.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = n__3_7; if linked_153 == nil { tmp17 = ifn_154.Invoke_O__O(arg_155) } else { tmp17 = linked_153.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_152, arg_155) }; if jrt.J2g_Truth(tmp17) { var root_156 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = n__3_7; if linked_157 == nil { return ifn_158.Invoke_O__O(arg_159) } else { return linked_157.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_156, arg_159) } } else { var tmp18 any; var root_160 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = n__3_7; if linked_161 == nil { tmp18 = ifn_162.Invoke_O__O(arg_163) } else { tmp18 = linked_161.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(tmp18) { var root_164 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = n__3_7; if linked_165 == nil { return ifn_166.Invoke_O__O(arg_167) } else { return linked_165.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_164, arg_167) } } else { return nil } } }
//line :34:1
		default:}; return nil } else {
//line :33:1
			return nil
		}
}



func A_arbace_c_repl_declare_BANG__A_New() *A_arbace_c_repl_declare_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_declare_BANG__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_c_repl_declare_BANG__A) Ctor() {}
//line :39:1
func (t *A_arbace_c_repl_declare_BANG__A) Invoke_O_O_O__O(self, f__0, ns__1 any) any { var n__3 any; var root_168 any = A_arbace_c_repl_A_const_30.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_c_repl_decl_name_A_fn_class); var ifn_170 lang.IFn; if



	linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = f__0; if linked_169 == nil { n__3 = ifn_170.Invoke_O__O(arg_171) } else { n__3 = linked_169.(*A_arbace_c_repl_decl_name_A).Invoke_O_O__O(root_168, arg_171) }; var root_189 any =
	A_arbace_c_repl_A_const_33.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var arg_193 any = A_arbace_c_repl_A_const_35.GetRawRoot__O(); var arg_194 any = ns__1; var arg_195 any; var fnbody__237 any = A_arbace_c_repl_declare_BANG__fn__1787000023_A_New_O_O(f__0, n__3); var tmp1 *jrt.Class; var fncls__236 *jrt.Class = A_arbace_c_repl_declare_BANG__fn__1787000023_A_fn_class; if
	fncls__236 == nil { var fncls__236d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__237); A_arbace_c_repl_declare_BANG__fn__1787000023_A_fn_class = fncls__236d; tmp1 = fncls__236d } else { tmp1 = fncls__236 }; arg_195 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__237, tmp1, nil); if /*line :44:1*/ linked_190 == nil { ifn_191.Invoke_O_O_O_O__O(arg_192, arg_193, arg_194, arg_195) } else { linked_190.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_189, arg_192, arg_193, arg_194, arg_195) }; var root_172 any =





	A_arbace_c_repl_A_const_31.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any; var root_177 any = A_arbace_c_repl_A_const_32.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = ns__1; if linked_178 == nil { arg_175 = ifn_179.Invoke_O__O(arg_180) } else { arg_175 = linked_178.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_177, arg_180) }; var arg_176 any; var or__1927000174__auto____4 any = n__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_176 = or__1927000174__auto____4 } else { var root_181 any = A_arbace_c_repl_A_const_32.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any; var root_185 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = f__0; if linked_186 == nil { arg_184 = ifn_187.Invoke_O__O(arg_188) } else { arg_184 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; if linked_182 == nil { arg_176 = ifn_183.Invoke_O__O(arg_184) } else { arg_176 = linked_182.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_181, arg_184) } }; if linked_173 == nil { return ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { return linked_173.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) } }
//line :45:1
func A_arbace_c_repl_declare_BANG__fn__1787000023_A_New_O_O(p0, p1 any) *A_arbace_c_repl_declare_BANG__fn__1787000023_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_declare_BANG__fn__1787000023_A{}; t.Ctor_O_O(p0, p1); return t }
//line :45:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_A) Ctor_O_O(c__f, c__n any) { t.F_f = c__f; t.F_n = c__n }
//line :45:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_A) Invoke_O_O__O(self, u__1 any) any { var u__2 any; var or__1927000174__auto____2 any = u__1; if
												jrt.J2g_Truth(or__1927000174__auto____2) { u__2 = or__1927000174__auto____2 } else { u__2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_36, A_arbace_c_repl_A_const_37, A_arbace_c_repl_A_const_38, lang.PersistentVector_EMPTY.Ref(), A_arbace_c_repl_A_const_39, lang.PersistentArrayMap_EMPTY.Ref())) }; var fs__3 any = /*line :45:1*/A_arbace_c_repl_A_const_38.Invoke_O__O(u__2); var i__4 any; if


	jrt.J2g_Truth(t.F_n) { var root_196 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var root_200 any = A_arbace_c_repl_A_const_40.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var fnbody__218 any = A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_New_O_O(t.F_f, t.F_n); var tmp1 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_fn_class; if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__218); A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_fn_class = fncls__217d; tmp1 = fncls__217d } else { tmp1 = fncls__217 }; arg_203 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__218, tmp1, nil); var arg_204 any = fs__3; if linked_201 == nil { arg_199 = ifn_202.Invoke_O_O__O(arg_203, arg_204) } else { arg_199 = linked_201.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_200, arg_203, arg_204) }; if linked_197 == nil { i__4 = ifn_198.Invoke_O__O(arg_199) } else { i__4 = linked_197.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_196, arg_199) } } else { i__4 = nil }; var root_219 any =
	A_arbace_c_repl_A_const_41.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = u__2; var arg_223 any = A_arbace_c_repl_A_const_38; var arg_224 any; if jrt.J2g_Truth(i__4) { var root_225 any = A_arbace_c_repl_A_const_41.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = fs__3; var arg_229 any = i__4; var arg_230 any = t.F_f; if linked_226 == nil { arg_224 = ifn_227.Invoke_O_O_O__O(arg_228, arg_229, arg_230) } else { arg_224 = linked_226.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_225, arg_228, arg_229, arg_230) } } else { var root_231 any = A_arbace_c_repl_A_const_12.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = fs__3; var arg_235 any = t.F_f; if linked_232 == nil { arg_224 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { arg_224 = linked_232.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) } }; if linked_220 == nil { return ifn_221.Invoke_O_O_O__O(arg_222, arg_223, arg_224) } else { return linked_220.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_219, arg_222, arg_223, arg_224) } }
//line :48:1
func A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_New_O_O(p0, p1 any) *A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A{}; t.Ctor_O_O(p0, p1); return t }
//line :48:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A) Ctor_O_O(c__f, c__n any) { t.F_f = c__f; t.F_n = c__n }
//line :48:1
func (t *A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A) Invoke_O_O_O__O(self, i__1, g__2 any) any { var tmp1 bool; var and__1927000168__auto____3 bool; var tmp2 any = t.F_n; var tmp3 any; var root_205 any = A_arbace_c_repl_A_const_30.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, A_arbace_c_repl_decl_name_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = g__2; if linked_206 == nil { tmp3 = ifn_207.Invoke_O__O(arg_208) } else { tmp3 = linked_206.(*A_arbace_c_repl_decl_name_A).Invoke_O_O__O(root_205, arg_208) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____3 { var tmp4 any; var root_209 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = g__2; if linked_210 == nil { tmp4 = ifn_211.Invoke_O__O(arg_212) } else { tmp4 = linked_210.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_209, arg_212) }; var tmp5 any = tmp4; var tmp6 any; var root_213 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = t.F_f; if linked_214 == nil { tmp6 = ifn_215.Invoke_O__O(arg_216) } else { tmp6 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { return i__1 } else { return nil } }



func A_arbace_c_repl_file_BANG__A_New() *A_arbace_c_repl_file_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_file_BANG__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_c_repl_file_BANG__A) Ctor() {}
//line :52:1
func (t *A_arbace_c_repl_file_BANG__A) Invoke_O_O_O__O(self, f__0, ns__1 any) any { var std__3 any; var root_238 any = A_arbace_c_repl_A_const_21.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_240 lang.IFn; if


	linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_c_repl_A_const_42.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any; var fnbody__253 any = A_arbace_c_repl_file_BANG__fn__1787000030_A_New(); var tmp1 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_c_repl_file_BANG__fn__1787000030_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_c_repl_file_BANG__fn__1787000030_A_fn_class = fncls__252d; tmp1 = fncls__252d } else { tmp1 = fncls__252 }; arg_245 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__253, tmp1, nil); var arg_246 any = f__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { arg_241 = linked_243.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) }; if linked_239 == nil { std__3 = ifn_240.Invoke_O__O(arg_241) } else { std__3 = linked_239.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_238, arg_241) }; var root_254 any =
	A_arbace_c_repl_A_const_33.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var arg_258 any = A_arbace_c_repl_A_const_35.GetRawRoot__O(); var arg_259 any = ns__1; var arg_260 any; var fnbody__268 any = A_arbace_c_repl_file_BANG__fn__1787000032_A_New_O(std__3); var tmp2 *jrt.Class; var fncls__267 *jrt.Class = A_arbace_c_repl_file_BANG__fn__1787000032_A_fn_class; if fncls__267 == nil { var fncls__267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__268); A_arbace_c_repl_file_BANG__fn__1787000032_A_fn_class = fncls__267d; tmp2 = fncls__267d } else { tmp2 = fncls__267 }; arg_260 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__268, tmp2, nil); if linked_255 == nil { ifn_256.Invoke_O_O_O_O__O(arg_257, arg_258, arg_259, arg_260) } else { linked_255.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_254, arg_257, arg_258, arg_259, arg_260) }; return ns__1 }
//line :55:1
func A_arbace_c_repl_file_BANG__fn__1787000030_A_New() *A_arbace_c_repl_file_BANG__fn__1787000030_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_file_BANG__fn__1787000030_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000030_A) Ctor() {}
//line :55:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000030_A) Invoke_O_O__O(self, p1__1787000028_SHARP___1 any) any { var root_247 any = A_arbace_c_repl_A_const_43.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = p1__1787000028_SHARP___1; var arg_251 any = A_arbace_c_repl_A_const_36; if linked_248 == nil { return ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { return linked_248.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_247, arg_250, arg_251) } }
func A_arbace_c_repl_file_BANG__fn__1787000032_A_New_O(p0 any) *A_arbace_c_repl_file_BANG__fn__1787000032_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_file_BANG__fn__1787000032_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000032_A) Ctor_O(c__std any) { t.F_std = c__std }
//line :56:1
func (t *A_arbace_c_repl_file_BANG__fn__1787000032_A) Invoke_O_O__O(self, p1__1787000029_SHARP___1 any) any { var root_261 any = A_arbace_c_repl_A_const_41.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var or__1927000174__auto____2 any = p1__1787000029_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_264 = or__1927000174__auto____2 } else { arg_264 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_38, lang.PersistentVector_EMPTY.Ref(), A_arbace_c_repl_A_const_39, lang.PersistentArrayMap_EMPTY.Ref())) }; var arg_265 any = A_arbace_c_repl_A_const_36; var arg_266 any; var or__1927000174__auto____2_2 any = t.F_std; if jrt.J2g_Truth(or__1927000174__auto____2_2) { arg_266 = or__1927000174__auto____2_2 } else { arg_266 = A_arbace_c_repl_A_const_37 }; if linked_262 == nil { return ifn_263.Invoke_O_O_O__O(arg_264, arg_265, arg_266) } else { return linked_262.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_261, arg_264, arg_265, arg_266) } }


func A_arbace_c_repl_include_BANG__A_New() *A_arbace_c_repl_include_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_include_BANG__A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_c_repl_include_BANG__A) Ctor() {}
//line :59:1
func (t *A_arbace_c_repl_include_BANG__A) Invoke_O_O_O__O(self, spec__0, ns__1 any) any { var u__3 any; var tmp1 any; var root_269 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_271 lang.IFn; if



	linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); if linked_270 == nil { tmp1 = ifn_271.Invoke_O__O(arg_272) } else { tmp1 = linked_270.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_269, arg_272) }; u__3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns__1); var std__4 any; var root_273 any = /*line :59:1*/A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_275 lang.IFn; if




	linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any; var or__1927000174__auto____4 any = A_arbace_c_repl_A_const_36.Invoke_O__O(u__3); if jrt.J2g_Truth(or__1927000174__auto____4) { arg_276 = or__1927000174__auto____4 } else { arg_276 = A_arbace_c_repl_A_const_37 }; if linked_274 == nil { std__4 = ifn_275.Invoke_O__O(arg_276) } else { std__4 = linked_274.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_273, arg_276) }; var dir__5 any; var tmp2 /*line :59:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12); var tmp3 any; var or__1927000174__auto____7 any = jrt.System_Getenv_String__String(Lit_13).Ref(); if





	jrt.J2g_Truth(or__1927000174__auto____7) { tmp3 = or__1927000174__auto____7 } else { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_14); var tmp5 any; var root_277 any = A_arbace_c_repl_A_const_15.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_c_repl_root_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; if linked_278 == nil { tmp5 = ifn_279.Invoke__O() } else { tmp5 = linked_278.(*A_arbace_c_repl_root_A).Invoke_O__O(root_277) }; tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil)).Ref() }; dir__5 = /*line :59:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil))); var ___6 bool = jrt.File_Cast(dir__5).Mkdirs__Z(); var f__7 any; var tmp6 jrt.File_I = jrt.File_Cast(dir__5); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp8 *jrt.Class = A_arbace_c_repl_A_const_44; var tmp9 any; var root_280 any = A_arbace_c_repl_A_const_45.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_hash_A_fn_class); var ifn_282 lang.IFn; _ = ___6; if







	linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = spec__0; if linked_281 == nil { tmp9 = ifn_282.Invoke_O__O(arg_283) } else { tmp9 = linked_281.(*aot_arbace_core.A_arbace_core_hash_A).Invoke_O_O__O(root_280, arg_283) }; f__7 = /*line :59:1*/jrt.File_New_File_String(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp8, Lit_17, jrt.RefArrayOf(jrt.Object_class, tmp9)), nil))); var ___8 any = lang.IFn_Cast(A_arbace_c_repl_A_const_46.GetRawRoot__O()).Invoke_O_O__O(f__7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, spec__0, nil)).Ref()); var fc__9 any; var root_289 any = A_arbace_c_repl_A_const_47.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_291 lang.IFn; _ = ___8; if









	linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, std__4)).Ref()); var arg_293 any = std__4; if linked_290 == nil { fc__9 = ifn_291.Invoke_O_O__O(arg_292, arg_293) } else { fc__9 = linked_290.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_289, arg_292, arg_293) }; var rd__10 any; var root_294 any = /*line :59:1*/A_arbace_c_repl_A_const_48.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_repr_c.A_arbace_repr_c_read_c_A_fn_class); var ifn_296 lang.IFn; if










	linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any; var root_301 any = A_arbace_c_repl_A_const_49.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any; var root_307 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); if linked_308 == nil { arg_304 = ifn_309.Invoke_O__O(arg_310) } else { arg_304 = linked_308.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_307, arg_310) }; var arg_305 any = fc__9; var arg_306 any = jrt.File_Cast(dir__5).GetPath__String().Ref(); if linked_302 == nil { arg_297 = ifn_303.Invoke_O_O_O__O(arg_304, arg_305, arg_306) } else { arg_297 = linked_302.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A).Invoke_O_O_O_O__O(root_301, arg_304, arg_305, arg_306) }; var arg_298 any = fc__9; var arg_299 any = jrt.File_Cast(f__7).GetAbsolutePath__String().Ref(); var arg_300 any = jrt.Boolean_FALSE.Ref(); if linked_295 == nil { rd__10 = ifn_296.Invoke_O_O_O_O__O(arg_297, arg_298, arg_299, arg_300) } else { rd__10 = linked_295.(*aot_arbace_repr_c.A_arbace_repr_c_read_c_A).Invoke_O_O_O_O_O__O(root_294, arg_297, arg_298, arg_299, arg_300) }; if
	jrt.J2g_Truth(A_arbace_c_repl_A_const_50.Invoke_O__O(rd__10)) { var tmp10 any; var root_311 any = A_arbace_c_repl_A_const_51.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil); var tmp12 any; var root_316 any = A_arbace_c_repl_A_const_52.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = Lit_22; var arg_320 any = A_arbace_c_repl_A_const_50.Invoke_O__O(rd__10); if linked_317 == nil { tmp12 = ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { tmp12 = linked_317.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_316, arg_319, arg_320) }; arg_314 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); var arg_315 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_53, spec__0)); if linked_312 == nil { tmp10 = ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { tmp10 = linked_312.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_311, arg_314, arg_315) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) }; var root_321 any =
	A_arbace_c_repl_A_const_33.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var arg_325 any = A_arbace_c_repl_A_const_35.GetRawRoot__O(); var arg_326 any = ns__1; var arg_327 any; var fnbody__358 any = A_arbace_c_repl_include_BANG__fn__1787000036_A_New_O(rd__10); var tmp13 *jrt.Class; var fncls__357 *jrt.Class = A_arbace_c_repl_include_BANG__fn__1787000036_A_fn_class; if
	fncls__357 == nil { var fncls__357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__358); A_arbace_c_repl_include_BANG__fn__1787000036_A_fn_class = fncls__357d; tmp13 = fncls__357d } else { tmp13 = fncls__357 }; arg_327 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__358, tmp13, nil); if /*line :72:1*/ linked_322 == nil { ifn_323.Invoke_O_O_O_O__O(arg_324, arg_325, arg_326, arg_327) } else { linked_322.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_321, arg_324, arg_325, arg_326, arg_327) }; return spec__0 }
func A_arbace_c_repl_include_BANG__fn__1787000036_A_New_O(p0 any) *A_arbace_c_repl_include_BANG__fn__1787000036_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_include_BANG__fn__1787000036_A{}; t.Ctor_O(p0); return t }
//line :73:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_A) Ctor_O(c__rd any) { t.F_rd = c__rd }
//line :73:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_A) Invoke_O_O__O(self, u__1 any) any { var u__2 any; var or__1927000174__auto____2 any = u__1; if
												jrt.J2g_Truth(or__1927000174__auto____2) { u__2 = or__1927000174__auto____2 } else { u__2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_36, A_arbace_c_repl_A_const_37, A_arbace_c_repl_A_const_38, lang.PersistentVector_EMPTY.Ref(), A_arbace_c_repl_A_const_39, lang.PersistentArrayMap_EMPTY.Ref())) }; var root_328 any =


	A_arbace_c_repl_A_const_35.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var root_335 any = A_arbace_c_repl_A_const_35.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_337 lang.IFn; if /*line :76:1*/ linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = u__2; var arg_339 any = A_arbace_c_repl_A_const_39; var arg_340 any = A_arbace_c_repl_A_const_54.GetRawRoot__O(); var arg_341 any = A_arbace_c_repl_A_const_39.Invoke_O__O(t.F_rd); if linked_336 == nil { arg_331 = ifn_337.Invoke_O_O_O_O__O(arg_338, arg_339, arg_340, arg_341) } else { arg_331 = linked_336.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_335, arg_338, arg_339, arg_340, arg_341) }; var arg_332 any = A_arbace_c_repl_A_const_38; var arg_333 any =
	A_arbace_c_repl_A_const_55.GetRawRoot__O(); var arg_334 any; var root_342 any = A_arbace_c_repl_A_const_56.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any; var fnbody__356 any = A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_New(); var tmp1 *jrt.Class; var fncls__355 *jrt.Class = A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_fn_class; if fncls__355 == nil { var fncls__355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_fn_class = fncls__355d; tmp1 = fncls__355d } else { tmp1 = fncls__355 }; arg_345 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__356, tmp1, nil); var arg_346 any = A_arbace_c_repl_A_const_38.Invoke_O__O(t.F_rd); if linked_343 == nil { arg_334 = ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { arg_334 = linked_343.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) }; if linked_329 == nil { return ifn_330.Invoke_O_O_O_O__O(arg_331, arg_332, arg_333, arg_334) } else { return linked_329.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_328, arg_331, arg_332, arg_333, arg_334) } }
//line :77:1
func A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_New() *A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A) Ctor() {}
//line :77:1
func (t *A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A) Invoke_O_O__O(self, p1__1787000035_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_347 any = A_arbace_c_repl_A_const_18.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = p1__1787000035_SHARP___1; if linked_348 == nil { and__1927000168__auto____2 = ifn_349.Invoke_O__O(arg_350) } else { and__1927000168__auto____2 = linked_348.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_347, arg_350) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_c_repl_A_const_57; var tmp2 any; var root_351 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = p1__1787000035_SHARP___1; if linked_352 == nil { tmp2 = ifn_353.Invoke_O__O(arg_354) } else { tmp2 = linked_352.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_351, arg_354) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }


func A_arbace_c_repl_unit_read_A_New() *A_arbace_c_repl_unit_read_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_unit_read_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_c_repl_unit_read_A) Ctor() {}
//line :80:1
func (t *A_arbace_c_repl_unit_read_A) Invoke_O_O__O(self, u__0 any) any { var tmp1 any = A_arbace_c_repl_A_const_38; var tmp2 any = A_arbace_c_repl_A_const_38.Invoke_O__O(u__0); var tmp3 any = A_arbace_c_repl_A_const_39; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, A_arbace_c_repl_A_const_39.Invoke_O__O(u__0))) }




func A_arbace_c_repl_light_run_nodes_A_New() *A_arbace_c_repl_light_run_nodes_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_light_run_nodes_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_c_repl_light_run_nodes_A) Ctor() {}
//line :85:1
func (t *A_arbace_c_repl_light_run_nodes_A) Invoke_O_O_O__O(self, text__0, argv__1 any) any { var f__3 any = jrt.File_CreateTempFile_String_String__File_NoInit(Lit_25, Lit_26); var cirun__4 any; var or__1927000174__auto____4 any = jrt.System_Getenv_String__String(Lit_27).Ref(); if




	jrt.J2g_Truth(or__1927000174__auto____4) { cirun__4 = or__1927000174__auto____4 } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28); var tmp2 any; var root_359 any = A_arbace_c_repl_A_const_15.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_c_repl_root_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; if linked_360 == nil { tmp2 = ifn_361.Invoke__O() } else { tmp2 = linked_360.(*A_arbace_c_repl_root_A).Invoke_O__O(root_359) }; cirun__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() }; var tmp3 any; tmp5 := /*line :85:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






		lang.IFn_Cast(A_arbace_c_repl_A_const_46.GetRawRoot__O()).Invoke_O_O__O(f__3, text__0)
//line :85:1
		{ var pb__7 any; var tmp4 any; var root_362 any = A_arbace_c_repl_A_const_55.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_364 lang.IFn







			if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = lang.Tuple_Create_O_O__IPersistentVector(cirun__4, jrt.File_Cast(f__3).GetPath__String().Ref()); var arg_366 any; var root_367 any = A_arbace_c_repl_A_const_58.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = argv__1; if linked_368 == nil { arg_366 = ifn_369.Invoke_O__O(arg_370) } else { arg_366 = linked_368.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_367, arg_370) }; if linked_363 == nil { tmp4 = ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { tmp4 = linked_363.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) }
//line :85:1
			pb__7 = jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp4)); var ___8 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__7)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()).Ref(); var p__9 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__7)).Start__Process(); var out__10 any = lang.IFn_Cast(A_arbace_c_repl_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(p__9).GetInputStream__InputStream()); var st__11 int32 = jrt.Process_Cast(p__9).WaitFor__I(); _ = ___8












			lang.IFn_Cast(A_arbace_c_repl_A_const_60.GetRawRoot__O()).Invoke_O__O(out__10); var root_384 any = A_arbace_c_repl_A_const_61.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; if linked_385 == nil { ifn_386.Invoke__O() } else { linked_385.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_384) }
//line :85:1
			tmp3 = jrt.Integer_ValueOf_I__Integer_NoInit(st__11).Ref() }; return nil }();














	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__3).Delete__Z()); if /*line :85:1*/ tmp5 != nil { panic(tmp5) }; return tmp3 }


















func A_arbace_c_repl_fn__1787000043_A_New() *A_arbace_c_repl_fn__1787000043_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000043_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_c_repl_fn__1787000043_A) Ctor() {}
//line :104:1
func (t *A_arbace_c_repl_fn__1787000043_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_repl_A_const_64)
									{ var root_387 any = A_arbace_c_repl_A_const_62.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = A_arbace_c_repl_A_const_63; if linked_388 == nil { tmp1 = ifn_389.Invoke_O__O(arg_390) } else { tmp1 = linked_388.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_387, arg_390) } }
//line :104:1
	return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }






func A_arbace_c_repl_fn__1787000045_A_New() *A_arbace_c_repl_fn__1787000045_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_fn__1787000045_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_c_repl_fn__1787000045_A) Ctor() {}
//line :111:1
func (t *A_arbace_c_repl_fn__1787000045_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_395 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = A_arbace_c_repl_A_const_65.GetRawRoot__O(); if linked_396 == nil { or__1927000174__auto____1 = ifn_397.Invoke_O__O(arg_398) } else { or__1927000174__auto____1 = linked_396.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_395, arg_398) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { return A_arbace_c_repl_A_const_66.GetRawRoot__O() } }

func A_arbace_c_repl_backend_A_New() *A_arbace_c_repl_backend_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_backend_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_c_repl_backend_A) Ctor() {}
//line :113:1
func (t *A_arbace_c_repl_backend_A) Invoke_O__O(self any) any {


	var tmp1 any; var root_399 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = A_arbace_c_repl_A_const_65.GetRawRoot__O(); if linked_400 == nil { tmp1 = ifn_401.Invoke_O__O(arg_402) } else { tmp1 = linked_400.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_399, arg_402) }; if jrt.J2g_Truth(tmp1) { return A_arbace_c_repl_A_const_67 } else { return A_arbace_c_repl_A_const_68
	} }
func A_arbace_c_repl_run_main_A_New() *A_arbace_c_repl_run_main_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_c_repl_run_main_A) Ctor() {}
//line :118:1
func (t *A_arbace_c_repl_run_main_A) DoInvoke_O_O_O__O(self, ns__0, args__1 any) any { var us__3 any; var root_403 any = A_arbace_c_repl_A_const_69.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_405 lang.IFn; if



	linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var iter__1927001039__auto____3 any; var fnbody__560 any = A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_New(); var tmp1 *jrt.Class; var fncls__559 *jrt.Class = A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_fn_class; if fncls__559 == nil { var fncls__559d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_fn_class = fncls__559d; tmp1 = fncls__559d } else { tmp1 = fncls__559 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__560, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_561 any = A_arbace_c_repl_A_const_85.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = A_arbace_c_repl_A_const_86.GetRawRoot__O(); var arg_565 any; var root_566 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); if linked_567 == nil { arg_565 = ifn_568.Invoke_O__O(arg_569) } else { arg_565 = linked_567.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_566, arg_569) }; if linked_562 == nil { tmp3 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { tmp3 = linked_562.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; arg_406 = tmp2.Invoke_O__O(tmp3); if linked_404 == nil { us__3 = ifn_405.Invoke_O__O(arg_406) } else { us__3 = linked_404.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_403, arg_406) }; var r__4 any; var root_588 any = /*line :118:1*/A_arbace_c_repl_A_const_95.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_590 lang.IFn; if









	linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_96.GetRawRoot__O()); var tmp5 any = A_arbace_c_repl_A_const_97; var tmp6 any; var root_597 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = A_arbace_c_repl_A_const_98.GetRawRoot__O(); if linked_598 == nil { tmp6 = ifn_599.Invoke_O__O(arg_600) } else { tmp6 = linked_598.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_597, arg_600) }; arg_591 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_589 == nil { ifn_590.Invoke_O__O(arg_591) } else { linked_589.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_588, arg_591) }; var tmp7 *lang.Compiler_AOTFn; var fnbody__578 any = A_arbace_c_repl_run_main_fn__1787000064_A_New_O(us__3); var tmp8 *jrt.Class; var fncls__577 *jrt.Class = A_arbace_c_repl_run_main_fn__1787000064_A_fn_class; if fncls__577 == nil { var fncls__577d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__578); A_arbace_c_repl_run_main_fn__1787000064_A_fn_class = fncls__577d; tmp8 = fncls__577d } else { tmp8 = fncls__577 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__578, tmp8, nil); r__4 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O(); var tmp9 any = A_arbace_c_repl_A_const_89; if
	lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_c_repl_A_const_90.Invoke_O__O(r__4)) {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_91.Get__O()); var tmp11 any = A_arbace_c_repl_A_const_99.Invoke_O__O(r__4); var tmp12 any; var root_601 any = A_arbace_c_repl_A_const_69.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any; var root_605 any = A_arbace_c_repl_A_const_100.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = A_arbace_c_repl_A_const_32.GetRawRoot__O(); var arg_609 any; var root_610 any = A_arbace_c_repl_A_const_84.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var root_615 any = A_arbace_c_repl_A_const_32.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = ns__0; if linked_616 == nil { arg_613 = ifn_617.Invoke_O__O(arg_618) } else { arg_613 = linked_616.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_615, arg_618) }; var arg_614 any = args__1; if linked_611 == nil { arg_609 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { arg_609 = linked_611.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }; if linked_606 == nil { arg_604 = ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) }; if linked_602 == nil { tmp12 = ifn_603.Invoke_O__O(arg_604) } else { tmp12 = linked_602.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_601, arg_604) }; return tmp10.Invoke_O_O__O(tmp11, tmp12) } else {
//line :129:1
			var tmp13 any; var root_579 any = A_arbace_c_repl_A_const_51.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_581 lang.IFn

			if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_33, nil, Lit_34, nil); var tmp15 any; var root_584 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = A_arbace_c_repl_A_const_92.Invoke_O__O(r__4); if linked_585 == nil { tmp15 = ifn_586.Invoke_O__O(arg_587) } else { tmp15 = linked_585.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_584, arg_587) }; arg_582 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, nil, A_arbace_c_repl_A_const_93.Invoke_O__O(r__4))).Ref(); var tmp16 any = A_arbace_c_repl_A_const_94; var arg_583 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, A_arbace_c_repl_A_const_92.Invoke_O__O(r__4))); if linked_580 == nil { tmp13 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { tmp13 = linked_580.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_579, arg_582, arg_583) }
//line :129:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp13))) } }
//line :122:1
func A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_New() *A_arbace_c_repl_run_main_iter__1787000048__1787000052_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_iter__1787000048__1787000052_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_A) Ctor() {}
//line :122:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_A) Invoke_O_O__O(self, s__1787000049__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__558 any = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_New_O_O(self, s__1787000049__1); var tmp2 *jrt.Class; var fncls__557 *jrt.Class = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_fn_class; if fncls__557 == nil { var fncls__557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__558); A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_fn_class = fncls__557d; tmp2 = fncls__557d } else { tmp2 = fncls__557 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__558, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :122:1
func A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_New_O_O(p0, p1 any) *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A) Ctor_O_O(c__iter__1787000048, c__s__1787000049 any) { t.F_iter__1787000048 = c__iter__1787000048; t.F_s__1787000049 = c__s__1787000049 }
//line :122:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A) Invoke_O__O(self any) any { { var s__1787000049__1 any; var t_ any = t.F_s__1787000049; t.F_s__1787000049 = nil; s__1787000049__1 = t_; for { var temp__1927000414__auto____2 any; var root_407 any = A_arbace_c_repl_A_const_70.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = s__1787000049__1; if linked_408 == nil { temp__1927000414__auto____2 = ifn_409.Invoke_O__O(arg_410) } else { temp__1927000414__auto____2 = linked_408.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_407, arg_410) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1787000049__3 any = temp__1927000414__auto____2; var tmp1 any; var root_411 any = A_arbace_c_repl_A_const_71.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = s__1787000049__3; if linked_412 == nil { tmp1 = ifn_413.Invoke_O__O(arg_414) } else { tmp1 = linked_412.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_411, arg_414) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_415 any = A_arbace_c_repl_A_const_72.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = s__1787000049__3; if linked_416 == nil { c__1927001037__auto____4 = ifn_417.Invoke_O__O(arg_418) } else { c__1927001037__auto____4 = linked_416.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_415, arg_418) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1787000051__6 any; var root_419 any = A_arbace_c_repl_A_const_73.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_420 == nil { b__1787000051__6 = ifn_421.Invoke_O__O(arg_422) } else { b__1787000051__6 = linked_420.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_419, arg_422) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__475 any = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_New_I_O_O(size__1927001038__auto____5, b__1787000051__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__475); A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_fn_class = fncls__474d; tmp3 = fncls__474d } else { tmp3 = fncls__474 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__475, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_476 any = A_arbace_c_repl_A_const_81.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_481 any = A_arbace_c_repl_A_const_82.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = b__1787000051__6; if linked_482 == nil { arg_479 = ifn_483.Invoke_O__O(arg_484) } else { arg_479 = linked_482.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_481, arg_484) }; var arg_480 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1787000048); var tmp5 any; var root_485 any = A_arbace_c_repl_A_const_83.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__1787000049__3; if linked_486 == nil { tmp5 = ifn_487.Invoke_O__O(arg_488) } else { tmp5 = linked_486.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_485, arg_488) }; arg_480 = tmp4.Invoke_O__O(tmp5); if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) } } else { var root_489 any = A_arbace_c_repl_A_const_81.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any; var root_494 any = A_arbace_c_repl_A_const_82.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = b__1787000051__6; if linked_495 == nil { arg_492 = ifn_496.Invoke_O__O(arg_497) } else { arg_492 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_494, arg_497) }; var arg_493 any; if linked_490 == nil { return ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { return linked_490.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) } } } else { var vec__1787000059__4 any; var root_498 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__1787000049__3; if linked_499 == nil { vec__1787000059__4 = ifn_500.Invoke_O__O(arg_501) } else { vec__1787000059__4 = linked_499.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_498, arg_501) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000059__4, lang.RT_IntCast_J__I_NoInit(0), nil); var u__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000059__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_502 any = A_arbace_c_repl_A_const_84.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any; var fc__7 any; var root_507 any = A_arbace_c_repl_A_const_47.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_509 lang.IFn
														if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp7 any; var root_512 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any; var or__1927000174__auto____9 any = A_arbace_c_repl_A_const_36.Invoke_O__O(u__6); if jrt.J2g_Truth(or__1927000174__auto____9) { arg_515 = or__1927000174__auto____9 } else { arg_515 = A_arbace_c_repl_A_const_37 }; if linked_513 == nil { tmp7 = ifn_514.Invoke_O__O(arg_515) } else { tmp7 = linked_513.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_512, arg_515) }; arg_510 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref()); var arg_511 any; var root_516 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var or__1927000174__auto____7 any = A_arbace_c_repl_A_const_36.Invoke_O__O(u__6); if jrt.J2g_Truth(or__1927000174__auto____7) { arg_519 = or__1927000174__auto____7 } else { arg_519 = A_arbace_c_repl_A_const_37 }; if linked_517 == nil { arg_511 = ifn_518.Invoke_O__O(arg_519) } else { arg_511 = linked_517.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_516, arg_519) }; if linked_508 == nil { fc__7 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { fc__7 = linked_508.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }
//line :122:1
	var cu__8 any; var root_520 any = A_arbace_c_repl_A_const_75.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_c_run.A_arbace_c_run_check_read_A_fn_class); var ifn_522 lang.IFn

	if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var root_526 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); if linked_527 == nil { arg_523 = ifn_528.Invoke_O__O(arg_529) } else { arg_523 = linked_527.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_526, arg_529) }; var arg_524 any = fc__7; var arg_525 any; var root_530 any = A_arbace_c_repl_A_const_76.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, A_arbace_c_repl_unit_read_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = u__6; if linked_531 == nil { arg_525 = ifn_532.Invoke_O__O(arg_533) } else { arg_525 = linked_531.(*A_arbace_c_repl_unit_read_A).Invoke_O_O__O(root_530, arg_533) }; if linked_521 == nil { cu__8 = ifn_522.Invoke_O_O_O__O(arg_523, arg_524, arg_525) } else { cu__8 = linked_521.(*aot_arbace_c_run.A_arbace_c_run_check_read_A).Invoke_O_O_O_O__O(root_520, arg_523, arg_524, arg_525) }
	var tmp8 any; var root_534 any = A_arbace_c_repl_A_const_70.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = A_arbace_c_repl_A_const_77.Invoke_O__O(cu__8); if linked_535 == nil { tmp8 = ifn_536.Invoke_O__O(arg_537) } else { tmp8 = linked_535.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_534, arg_537) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_538 any = A_arbace_c_repl_A_const_51.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_540 lang.IFn
		if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_38, nil); var tmp11 any; var root_543 any = A_arbace_c_repl_A_const_52.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = Lit_22; var arg_547 any; var root_548 any = A_arbace_c_repl_A_const_78.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = A_arbace_c_repl_A_const_79; var arg_552 any = A_arbace_c_repl_A_const_77.Invoke_O__O(cu__8); if linked_549 == nil { arg_547 = ifn_550.Invoke_O_O__O(arg_551, arg_552) } else { arg_547 = linked_549.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_548, arg_551, arg_552) }; if linked_544 == nil { tmp11 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { tmp11 = linked_544.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; arg_541 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, n__5, nil, tmp11)).Ref(); var arg_542 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_80, n__5)); if linked_539 == nil { tmp9 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { tmp9 = linked_539.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }
//line :125:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) }
//line :122:1
	arg_505 = cu__8; var arg_506 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1787000048); var tmp13 any; var root_553 any = A_arbace_c_repl_A_const_58.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = s__1787000049__3; if linked_554 == nil { tmp13 = ifn_555.Invoke_O__O(arg_556) } else { tmp13 = linked_554.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_553, arg_556) }; arg_506 = tmp12.Invoke_O__O(tmp13); if linked_503 == nil { return ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { return linked_503.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :122:1
func A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :122:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1787000051, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1787000051 = c__b__1787000051; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :122:1
func (t *A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A) Invoke_O__O(self any) any { { var i__1787000050__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1787000050__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1787000055__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1787000050__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000055__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1787000055__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_423 any = A_arbace_c_repl_A_const_74.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = t.F_b__1787000051; var arg_427 any; var fc__5 any; var root_428 any = A_arbace_c_repl_A_const_47.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_430 lang.IFn
																if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp3 any; var root_433 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any; var or__1927000174__auto____7 any = A_arbace_c_repl_A_const_36.Invoke_O__O(u__4); if jrt.J2g_Truth(or__1927000174__auto____7) { arg_436 = or__1927000174__auto____7 } else { arg_436 = A_arbace_c_repl_A_const_37 }; if linked_434 == nil { tmp3 = ifn_435.Invoke_O__O(arg_436) } else { tmp3 = linked_434.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_433, arg_436) }; arg_431 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref()); var arg_432 any; var root_437 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any; var or__1927000174__auto____5 any = A_arbace_c_repl_A_const_36.Invoke_O__O(u__4); if jrt.J2g_Truth(or__1927000174__auto____5) { arg_440 = or__1927000174__auto____5 } else { arg_440 = A_arbace_c_repl_A_const_37 }; if linked_438 == nil { arg_432 = ifn_439.Invoke_O__O(arg_440) } else { arg_432 = linked_438.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_437, arg_440) }; if linked_429 == nil { fc__5 = ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { fc__5 = linked_429.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) }
//line :122:1
	var cu__6 any; var root_441 any = A_arbace_c_repl_A_const_75.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_c_run.A_arbace_c_run_check_read_A_fn_class); var ifn_443 lang.IFn

	if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var root_447 any = A_arbace_c_repl_A_const_10.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = A_arbace_c_repl_A_const_17.GetRawRoot__O(); if linked_448 == nil { arg_444 = ifn_449.Invoke_O__O(arg_450) } else { arg_444 = linked_448.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_447, arg_450) }; var arg_445 any = fc__5; var arg_446 any; var root_451 any = A_arbace_c_repl_A_const_76.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, A_arbace_c_repl_unit_read_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = u__4; if linked_452 == nil { arg_446 = ifn_453.Invoke_O__O(arg_454) } else { arg_446 = linked_452.(*A_arbace_c_repl_unit_read_A).Invoke_O_O__O(root_451, arg_454) }; if linked_442 == nil { cu__6 = ifn_443.Invoke_O_O_O__O(arg_444, arg_445, arg_446) } else { cu__6 = linked_442.(*aot_arbace_c_run.A_arbace_c_run_check_read_A).Invoke_O_O_O_O__O(root_441, arg_444, arg_445, arg_446) }
	var tmp4 any; var root_455 any = A_arbace_c_repl_A_const_70.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = A_arbace_c_repl_A_const_77.Invoke_O__O(cu__6); if linked_456 == nil { tmp4 = ifn_457.Invoke_O__O(arg_458) } else { tmp4 = linked_456.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_455, arg_458) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_459 any = A_arbace_c_repl_A_const_51.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_461 lang.IFn
		if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_38, nil); var tmp7 any; var root_464 any = A_arbace_c_repl_A_const_52.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = Lit_22; var arg_468 any; var root_469 any = A_arbace_c_repl_A_const_78.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = A_arbace_c_repl_A_const_79; var arg_473 any = A_arbace_c_repl_A_const_77.Invoke_O__O(cu__6); if linked_470 == nil { arg_468 = ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { arg_468 = linked_470.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) }; if linked_465 == nil { tmp7 = ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { tmp7 = linked_465.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_464, arg_467, arg_468) }; arg_462 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__3, nil, tmp7)).Ref(); var arg_463 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_repl_A_const_80, n__3)); if linked_460 == nil { tmp5 = ifn_461.Invoke_O_O__O(arg_462, arg_463) } else { tmp5 = linked_460.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_459, arg_462, arg_463) }
//line :125:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp5))) }
//line :122:1
	arg_427 = cu__6; if linked_424 == nil { ifn_425.Invoke_O_O__O(arg_426, arg_427) } else { linked_424.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_423, arg_426, arg_427) }; i__1787000050__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1787000050__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_c_repl_run_main_fn__1787000064_A_New_O(p0 any) *A_arbace_c_repl_run_main_fn__1787000064_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_run_main_fn__1787000064_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_c_repl_run_main_fn__1787000064_A) Ctor_O(c__us any) { t.F_us = c__us }
//line :128:1
func (t *A_arbace_c_repl_run_main_fn__1787000064_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_570 any = A_arbace_c_repl_A_const_87.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_c_run.A_arbace_c_run_nodes_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any; var t_ any = t.F_us; t.F_us = nil; arg_573 = t_; if linked_571 == nil { tmp1 = ifn_572.Invoke_O__O(arg_573) } else { tmp1 = linked_571.(*aot_arbace_c_run.A_arbace_c_run_nodes_A).Invoke_O_O__O(root_570, arg_573) } }; return nil }(); var root_574 any = A_arbace_c_repl_A_const_88.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; if linked_575 == nil { ifn_576.Invoke__O() } else { linked_575.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_574) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_c_repl_reset_unit_BANG__A_New() *A_arbace_c_repl_reset_unit_BANG__A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_reset_unit_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_c_repl_reset_unit_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_c_repl_reset_unit_BANG__A) Invoke_O_O__O(self, ns__0 any) any {


	var root_619 any = A_arbace_c_repl_A_const_33.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = A_arbace_c_repl_A_const_34.GetRawRoot__O(); var arg_623 any = A_arbace_c_repl_A_const_101.GetRawRoot__O(); var arg_624 any = ns__0; if linked_620 == nil { ifn_621.Invoke_O_O_O__O(arg_622, arg_623, arg_624) } else { linked_620.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_619, arg_622, arg_623, arg_624) }
//line :133:1
	return nil
}




func A_arbace_c_repl__main_A_New() *A_arbace_c_repl__main_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl__main_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_c_repl__main_A) Ctor() {}
//line :139:1
func (t *A_arbace_c_repl__main_A) DoInvoke_O_O__O(self, args__0 any) any { var G__1787000068__2_ any; var root_625 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_627 lang.IFn; if




	linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = args__0; if linked_626 == nil { G__1787000068__2_ = ifn_627.Invoke_O__O(arg_628) } else { G__1787000068__2_ = linked_626.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_625, arg_628) }; switch lang.Util_Hash_O__I_NoInit(G__1787000068__2_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000068__2_, Lit_1) {





		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_103.GetRawRoot__O()); var tmp2 any; var root_654 any = A_arbace_c_repl_A_const_23.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any; var root_658 any = A_arbace_c_repl_A_const_104.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, A_arbace_c_repl_backend_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; if linked_659 == nil { arg_657 = ifn_660.Invoke__O() } else { arg_657 = linked_659.(*A_arbace_c_repl_backend_A).Invoke_O__O(root_658) }; if linked_655 == nil { tmp2 = ifn_656.Invoke_O__O(arg_657) } else { tmp2 = linked_655.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_654, arg_657) }; tmp1.Invoke_O__O(tmp2); var root_661 any = A_arbace_c_repl_A_const_105.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; if linked_662 == nil { ifn_663.Invoke__O() } else { linked_662.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_661) }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :144:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1787000068__2_, Lit_2) { var vec__1787000069__3 any = args__0; var seq__1787000070__4 any; var root_630 any = A_arbace_c_repl_A_const_70.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_632 lang.IFn
		if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = vec__1787000069__3; if linked_631 == nil { seq__1787000070__4 = ifn_632.Invoke_O__O(arg_633) } else { seq__1787000070__4 = linked_631.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_630, arg_633) }
//line :144:1
		var first__1787000071__5 any; var root_634 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_636 lang.IFn
		if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = seq__1787000070__4; if linked_635 == nil { first__1787000071__5 = ifn_636.Invoke_O__O(arg_637) } else { first__1787000071__5 = linked_635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_634, arg_637) }
//line :144:1
		var seq__1787000070__6 any; var root_638 any = A_arbace_c_repl_A_const_102.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_640 lang.IFn
		if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = seq__1787000070__4; if linked_639 == nil { seq__1787000070__6 = ifn_640.Invoke_O__O(arg_641) } else { seq__1787000070__6 = linked_639.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_638, arg_641) }
//line :144:1
		var ___7 any = first__1787000071__5; var first__1787000071__8 any; var root_642 any = A_arbace_c_repl_A_const_19.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_644 lang.IFn; _ = ___7
		if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = seq__1787000070__6; if linked_643 == nil { first__1787000071__8 = ifn_644.Invoke_O__O(arg_645) } else { first__1787000071__8 = linked_643.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_642, arg_645) }
//line :144:1
		var seq__1787000070__9 any; var root_646 any = A_arbace_c_repl_A_const_102.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_648 lang.IFn
		if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = seq__1787000070__6; if linked_647 == nil { seq__1787000070__9 = ifn_648.Invoke_O__O(arg_649) } else { seq__1787000070__9 = linked_647.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_646, arg_649) }
//line :144:1
		var f__10 any = first__1787000071__8; var more__11 any = seq__1787000070__9; var st__12 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_91.Get__O()); var tmp4 any = lang.IFn_Cast(A_arbace_c_repl_A_const_59.GetRawRoot__O()).Invoke_O__O(f__10); var tmp5 any; var root_668 any = A_arbace_c_repl_A_const_69.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_670 lang.IFn

		if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any; var root_672 any = A_arbace_c_repl_A_const_84.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = Lit_3; var arg_676 any = more__11; if linked_673 == nil { arg_671 = ifn_674.Invoke_O_O__O(arg_675, arg_676) } else { arg_671 = linked_673.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_672, arg_675, arg_676) }; if linked_669 == nil { tmp5 = ifn_670.Invoke_O__O(arg_671) } else { tmp5 = linked_669.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_668, arg_671) }; st__12 = tmp3.Invoke_O_O__O(tmp4, tmp5)
		var root_677 any = A_arbace_c_repl_A_const_61.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; if linked_678 == nil { ifn_679.Invoke__O() } else { linked_678.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_677) }
		var root_680 any = A_arbace_c_repl_A_const_105.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; if linked_681 == nil { ifn_682.Invoke__O() } else { linked_681.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_680) }
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(st__12)); return nil }
//line :144:1
	default:}; var root_692 any =






	A_arbace_c_repl_A_const_95.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_repl_A_const_96.GetRawRoot__O()); var tmp7 any = A_arbace_c_repl_A_const_106; var arg_695 any = tmp6.Invoke_O_O__O(tmp7, A_arbace_c_repl_A_const_107.Get__O()); if linked_693 == nil { ifn_694.Invoke_O__O(arg_695) } else { linked_693.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_692, arg_695) }; var tmp8 *lang.Compiler_AOTFn; var fnbody__691 any = A_arbace_c_repl__main_fn__1787000072_A_New(); var tmp9 *jrt.Class; var fncls__690 *jrt.Class = A_arbace_c_repl__main_fn__1787000072_A_fn_class; if fncls__690 == nil { var fncls__690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c_repl__main_fn__1787000072_A_fn_class = fncls__690d; tmp9 = fncls__690d } else { tmp9 = fncls__690 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__691, tmp9, nil); Up_Compiler_AOTFn_IFn(tmp8).Invoke__O();
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :151:1
func A_arbace_c_repl__main_fn__1787000072_A_New() *A_arbace_c_repl__main_fn__1787000072_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl__main_fn__1787000072_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_c_repl__main_fn__1787000072_A) Ctor() {}
//line :151:1
func (t *A_arbace_c_repl__main_fn__1787000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_c_repl_A_const_103.GetRawRoot__O()).Invoke_O__O(Lit_5); return nil }(); var root_687 any = A_arbace_c_repl_A_const_88.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; if linked_688 == nil { ifn_689.Invoke__O() } else { linked_688.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_687) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }































type A_arbace_c_repl_A struct{ jrt.Object }

var A_arbace_c_repl_A_const_pool *jrt.RefArray

var A_arbace_c_repl_A_const_0 *lang.Var

var A_arbace_c_repl_A_const_1 any

var A_arbace_c_repl_A_const_2 any

var A_arbace_c_repl_A_const_3 any

var A_arbace_c_repl_A_const_4 any

var A_arbace_c_repl_A_const_5 any

var A_arbace_c_repl_A_const_6 any

var A_arbace_c_repl_A_const_7 *lang.Var

var A_arbace_c_repl_A_const_8 any

var A_arbace_c_repl_A_const_9 *lang.Var

var A_arbace_c_repl_A_const_10 *lang.Var

var A_arbace_c_repl_A_const_11 *lang.Var

var A_arbace_c_repl_A_const_12 *lang.Var

var A_arbace_c_repl_A_const_13 any

var A_arbace_c_repl_A_const_14 *lang.Var

var A_arbace_c_repl_A_const_15 *lang.Var

var A_arbace_c_repl_A_const_16 *lang.Var

var A_arbace_c_repl_A_const_17 *lang.Var

var A_arbace_c_repl_A_const_18 *lang.Var

var A_arbace_c_repl_A_const_19 *lang.Var

var A_arbace_c_repl_A_const_20 any

var A_arbace_c_repl_A_const_21 *lang.Var

var A_arbace_c_repl_A_const_22 *lang.Var

var A_arbace_c_repl_A_const_23 *lang.Var

var A_arbace_c_repl_A_const_24 any

var A_arbace_c_repl_A_const_25 any

var A_arbace_c_repl_A_const_26 any

var A_arbace_c_repl_A_const_27 any

var A_arbace_c_repl_A_const_28 any

var A_arbace_c_repl_A_const_29 any

var A_arbace_c_repl_A_const_30 *lang.Var

var A_arbace_c_repl_A_const_31 *lang.Var

var A_arbace_c_repl_A_const_32 *lang.Var

var A_arbace_c_repl_A_const_33 *lang.Var

var A_arbace_c_repl_A_const_34 *lang.Var

var A_arbace_c_repl_A_const_35 *lang.Var

var A_arbace_c_repl_A_const_36 *lang.Keyword

var A_arbace_c_repl_A_const_37 *lang.Keyword

var A_arbace_c_repl_A_const_38 *lang.Keyword

var A_arbace_c_repl_A_const_39 *lang.Keyword

var A_arbace_c_repl_A_const_40 *lang.Var

var A_arbace_c_repl_A_const_41 *lang.Var

var A_arbace_c_repl_A_const_42 *lang.Var

var A_arbace_c_repl_A_const_43 *lang.Var

var A_arbace_c_repl_A_const_44 *jrt.Class

var A_arbace_c_repl_A_const_45 *lang.Var

var A_arbace_c_repl_A_const_46 *lang.Var

var A_arbace_c_repl_A_const_47 *lang.Var

var A_arbace_c_repl_A_const_48 *lang.Var

var A_arbace_c_repl_A_const_49 *lang.Var

var A_arbace_c_repl_A_const_50 *lang.Keyword

var A_arbace_c_repl_A_const_51 *lang.Var

var A_arbace_c_repl_A_const_52 *lang.Var

var A_arbace_c_repl_A_const_53 *lang.Keyword

var A_arbace_c_repl_A_const_54 *lang.Var

var A_arbace_c_repl_A_const_55 *lang.Var

var A_arbace_c_repl_A_const_56 *lang.Var

var A_arbace_c_repl_A_const_57 any

var A_arbace_c_repl_A_const_58 *lang.Var

var A_arbace_c_repl_A_const_59 *lang.Var

var A_arbace_c_repl_A_const_60 *lang.Var

var A_arbace_c_repl_A_const_61 *lang.Var

var A_arbace_c_repl_A_const_62 *lang.Var

var A_arbace_c_repl_A_const_63 any

var A_arbace_c_repl_A_const_64 any

var A_arbace_c_repl_A_const_65 *lang.Var

var A_arbace_c_repl_A_const_66 *lang.Var

var A_arbace_c_repl_A_const_67 *lang.Keyword

var A_arbace_c_repl_A_const_68 *lang.Keyword

var A_arbace_c_repl_A_const_69 *lang.Var

var A_arbace_c_repl_A_const_70 *lang.Var

var A_arbace_c_repl_A_const_71 *lang.Var

var A_arbace_c_repl_A_const_72 *lang.Var

var A_arbace_c_repl_A_const_73 *lang.Var

var A_arbace_c_repl_A_const_74 *lang.Var

var A_arbace_c_repl_A_const_75 *lang.Var

var A_arbace_c_repl_A_const_76 *lang.Var

var A_arbace_c_repl_A_const_77 *lang.Keyword

var A_arbace_c_repl_A_const_78 *lang.Var

var A_arbace_c_repl_A_const_79 any

var A_arbace_c_repl_A_const_80 *lang.Keyword

var A_arbace_c_repl_A_const_81 *lang.Var

var A_arbace_c_repl_A_const_82 *lang.Var

var A_arbace_c_repl_A_const_83 *lang.Var

var A_arbace_c_repl_A_const_84 *lang.Var

var A_arbace_c_repl_A_const_85 *lang.Var

var A_arbace_c_repl_A_const_86 *lang.Var

var A_arbace_c_repl_A_const_87 *lang.Var

var A_arbace_c_repl_A_const_88 *lang.Var

var A_arbace_c_repl_A_const_89 *lang.Keyword

var A_arbace_c_repl_A_const_90 *lang.Keyword

var A_arbace_c_repl_A_const_91 *lang.Var

var A_arbace_c_repl_A_const_92 *lang.Keyword

var A_arbace_c_repl_A_const_93 *lang.Keyword

var A_arbace_c_repl_A_const_94 *lang.Keyword

var A_arbace_c_repl_A_const_95 *lang.Var

var A_arbace_c_repl_A_const_96 *lang.Var

var A_arbace_c_repl_A_const_97 *lang.Var

var A_arbace_c_repl_A_const_98 *lang.Var

var A_arbace_c_repl_A_const_99 *lang.Keyword

var A_arbace_c_repl_A_const_100 *lang.Var

var A_arbace_c_repl_A_const_101 *lang.Var

var A_arbace_c_repl_A_const_102 *lang.Var

var A_arbace_c_repl_A_const_103 *lang.Var

var A_arbace_c_repl_A_const_104 *lang.Var

var A_arbace_c_repl_A_const_105 *lang.Var

var A_arbace_c_repl_A_const_106 *lang.Var

var A_arbace_c_repl_A_const_107 *lang.Var

var A_arbace_c_repl_A_init jrt.ClassInit

func A_arbace_c_repl_A_Init() { if !A_arbace_c_repl_A_init.Done() { A_arbace_c_repl_A_init.Run(A_arbace_c_repl_A_clinit) } }

func A_arbace_c_repl_A_clinit() { A_arbace_c_repl_A_clinit_p0(); A_arbace_c_repl_A_clinit_p1(); A_arbace_c_repl_A_clinit_p2(); A_arbace_c_repl_A_clinit_p3(); A_arbace_c_repl_A_clinit_p4(); A_arbace_c_repl_A_clinit_p5(); A_arbace_c_repl_A_clinit_p6(); A_arbace_c_repl_A_clinit_p7(); A_arbace_c_repl_A_clinit_p8() }

func A_arbace_c_repl_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 149); A_arbace_c_repl_A_const_0 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[41]); A_arbace_c_repl_A_const_1 = A_arbace_c_repl_A_const_pool.A[42]; A_arbace_c_repl_A_const_2 = A_arbace_c_repl_A_const_pool.A[43]; A_arbace_c_repl_A_const_3 = A_arbace_c_repl_A_const_pool.A[44]; A_arbace_c_repl_A_const_4 = A_arbace_c_repl_A_const_pool.A[45]; A_arbace_c_repl_A_const_5 = A_arbace_c_repl_A_const_pool.A[46]; A_arbace_c_repl_A_const_6 = A_arbace_c_repl_A_const_pool.A[47]; A_arbace_c_repl_A_const_7 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[48]); A_arbace_c_repl_A_const_8 = A_arbace_c_repl_A_const_pool.A[49]; A_arbace_c_repl_A_const_9 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[50]); A_arbace_c_repl_A_const_10 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[51]); A_arbace_c_repl_A_const_11 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[52]); A_arbace_c_repl_A_const_12 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[53]) }

func A_arbace_c_repl_A_clinit_p1() { A_arbace_c_repl_A_const_13 = A_arbace_c_repl_A_const_pool.A[54]; A_arbace_c_repl_A_const_14 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[55]); A_arbace_c_repl_A_const_15 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[56]); A_arbace_c_repl_A_const_16 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[57]); A_arbace_c_repl_A_const_17 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[58]); A_arbace_c_repl_A_const_18 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[59]); A_arbace_c_repl_A_const_19 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[60]); A_arbace_c_repl_A_const_20 = A_arbace_c_repl_A_const_pool.A[61]; A_arbace_c_repl_A_const_21 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[62]); A_arbace_c_repl_A_const_22 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[63]); A_arbace_c_repl_A_const_23 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[64]); A_arbace_c_repl_A_const_24 = A_arbace_c_repl_A_const_pool.A[65]; A_arbace_c_repl_A_const_25 = A_arbace_c_repl_A_const_pool.A[66] }

func A_arbace_c_repl_A_clinit_p2() { A_arbace_c_repl_A_const_26 = A_arbace_c_repl_A_const_pool.A[67]; A_arbace_c_repl_A_const_27 = A_arbace_c_repl_A_const_pool.A[68]; A_arbace_c_repl_A_const_28 = A_arbace_c_repl_A_const_pool.A[69]; A_arbace_c_repl_A_const_29 = A_arbace_c_repl_A_const_pool.A[70]; A_arbace_c_repl_A_const_30 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[71]); A_arbace_c_repl_A_const_31 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[72]); A_arbace_c_repl_A_const_32 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[73]); A_arbace_c_repl_A_const_33 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[74]); A_arbace_c_repl_A_const_34 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[75]); A_arbace_c_repl_A_const_35 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[76]); A_arbace_c_repl_A_const_36 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[77]); A_arbace_c_repl_A_const_37 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[78]); A_arbace_c_repl_A_const_38 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[79]) }

func A_arbace_c_repl_A_clinit_p3() { A_arbace_c_repl_A_const_39 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[80]); A_arbace_c_repl_A_const_40 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[81]); A_arbace_c_repl_A_const_41 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[82]); A_arbace_c_repl_A_const_42 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[83]); A_arbace_c_repl_A_const_43 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[84]); A_arbace_c_repl_A_const_44 = jrt.Class_Cast(A_arbace_c_repl_A_const_pool.A[85]); A_arbace_c_repl_A_const_45 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[86]); A_arbace_c_repl_A_const_46 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[87]); A_arbace_c_repl_A_const_47 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[88]); A_arbace_c_repl_A_const_48 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[89]); A_arbace_c_repl_A_const_49 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[90]); A_arbace_c_repl_A_const_50 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[91]) }

func A_arbace_c_repl_A_clinit_p4() { A_arbace_c_repl_A_const_51 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[92]); A_arbace_c_repl_A_const_52 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[93]); A_arbace_c_repl_A_const_53 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[94]); A_arbace_c_repl_A_const_54 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[95]); A_arbace_c_repl_A_const_55 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[96]); A_arbace_c_repl_A_const_56 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[97]); A_arbace_c_repl_A_const_57 = A_arbace_c_repl_A_const_pool.A[98]; A_arbace_c_repl_A_const_58 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[99]); A_arbace_c_repl_A_const_59 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[100]); A_arbace_c_repl_A_const_60 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[101]); A_arbace_c_repl_A_const_61 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[102]); A_arbace_c_repl_A_const_62 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[103]) }

func A_arbace_c_repl_A_clinit_p5() { A_arbace_c_repl_A_const_63 = A_arbace_c_repl_A_const_pool.A[104]; A_arbace_c_repl_A_const_64 = A_arbace_c_repl_A_const_pool.A[105]; A_arbace_c_repl_A_const_65 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[106]); A_arbace_c_repl_A_const_66 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[107]); A_arbace_c_repl_A_const_67 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[108]); A_arbace_c_repl_A_const_68 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[109]); A_arbace_c_repl_A_const_69 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[110]); A_arbace_c_repl_A_const_70 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[111]); A_arbace_c_repl_A_const_71 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[112]); A_arbace_c_repl_A_const_72 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[113]); A_arbace_c_repl_A_const_73 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[114]); A_arbace_c_repl_A_const_74 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[115]) }

func A_arbace_c_repl_A_clinit_p6() { A_arbace_c_repl_A_const_75 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[116]); A_arbace_c_repl_A_const_76 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[117]); A_arbace_c_repl_A_const_77 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[118]); A_arbace_c_repl_A_const_78 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[119]); A_arbace_c_repl_A_const_79 = A_arbace_c_repl_A_const_pool.A[120]; A_arbace_c_repl_A_const_80 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[121]); A_arbace_c_repl_A_const_81 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[122]); A_arbace_c_repl_A_const_82 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[123]); A_arbace_c_repl_A_const_83 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[124]); A_arbace_c_repl_A_const_84 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[125]); A_arbace_c_repl_A_const_85 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[126]); A_arbace_c_repl_A_const_86 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[127]) }

func A_arbace_c_repl_A_clinit_p7() { A_arbace_c_repl_A_const_87 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[128]); A_arbace_c_repl_A_const_88 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[129]); A_arbace_c_repl_A_const_89 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[130]); A_arbace_c_repl_A_const_90 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[131]); A_arbace_c_repl_A_const_91 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[132]); A_arbace_c_repl_A_const_92 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[133]); A_arbace_c_repl_A_const_93 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[134]); A_arbace_c_repl_A_const_94 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[135]); A_arbace_c_repl_A_const_95 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[136]); A_arbace_c_repl_A_const_96 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[137]); A_arbace_c_repl_A_const_97 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[138]); A_arbace_c_repl_A_const_98 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[139]) }

func A_arbace_c_repl_A_clinit_p8() { A_arbace_c_repl_A_const_99 = lang.Keyword_Cast(A_arbace_c_repl_A_const_pool.A[140]); A_arbace_c_repl_A_const_100 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[141]); A_arbace_c_repl_A_const_101 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[142]); A_arbace_c_repl_A_const_102 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[143]); A_arbace_c_repl_A_const_103 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[144]); A_arbace_c_repl_A_const_104 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[145]); A_arbace_c_repl_A_const_105 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[146]); A_arbace_c_repl_A_const_106 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[147]); A_arbace_c_repl_A_const_107 = lang.Var_Cast(A_arbace_c_repl_A_const_pool.A[148]) }

func A_arbace_c_repl_A_New() *A_arbace_c_repl_A { A_arbace_c_repl_A_Init(); t := &A_arbace_c_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_c_repl_A) Ctor() {}

func (t *A_arbace_c_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_repl_A) GetClass__Class() *jrt.Class { return A_arbace_c_repl_A_class }

func (t *A_arbace_c_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_repl_A); return ok }

func A_arbace_c_repl_A_Cast(x any) *A_arbace_c_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_repl_A_class)) }; return v }



type A_arbace_c_repl__main_A struct{ j2g_header uint64 }

var A_arbace_c_repl__main_A_fn_class *jrt.Class



type A_arbace_c_repl__main_fn__1787000072_A struct{ j2g_header uint64 }

var A_arbace_c_repl__main_fn__1787000072_A_fn_class *jrt.Class



type A_arbace_c_repl_backend_A struct{ j2g_header uint64 }

var A_arbace_c_repl_backend_A_fn_class *jrt.Class



type A_arbace_c_repl_decl_name_A struct{ j2g_header uint64 }

var A_arbace_c_repl_decl_name_A_fn_class *jrt.Class



type A_arbace_c_repl_declare_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_declare_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_declare_BANG__fn__1787000023_A struct{ j2g_header uint64; F_f, F_n any }

var A_arbace_c_repl_declare_BANG__fn__1787000023_A_fn_class *jrt.Class



type A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A struct{ j2g_header uint64; F_f, F_n any }

var A_arbace_c_repl_declare_BANG__fn__1787000023_fn__1787000024_A_fn_class *jrt.Class



type A_arbace_c_repl_eval1787000004_A struct{ jrt.Object }

func A_arbace_c_repl_eval1787000004_A_New() *A_arbace_c_repl_eval1787000004_A { t := &A_arbace_c_repl_eval1787000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_repl_eval1787000004_A) Ctor() {}

func (t *A_arbace_c_repl_eval1787000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_repl_eval1787000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_repl_eval1787000004_A_class }

func (t *A_arbace_c_repl_eval1787000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_repl_eval1787000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_repl_eval1787000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_repl_eval1787000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_repl_eval1787000004_A); return ok }

func A_arbace_c_repl_eval1787000004_A_Cast(x any) *A_arbace_c_repl_eval1787000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_repl_eval1787000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_repl_eval1787000004_A_class)) }; return v }



type A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A struct{ j2g_header uint64 }

var A_arbace_c_repl_eval1787000004_loading__1927001464__auto____1787000005_A_fn_class *jrt.Class



type A_arbace_c_repl_eval1787000008_A struct{ jrt.Object }

func A_arbace_c_repl_eval1787000008_A_New() *A_arbace_c_repl_eval1787000008_A { t := &A_arbace_c_repl_eval1787000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_repl_eval1787000008_A) Ctor() {}

func (t *A_arbace_c_repl_eval1787000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_repl_eval1787000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_repl_eval1787000008_A_class }

func (t *A_arbace_c_repl_eval1787000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_repl_eval1787000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_repl_eval1787000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_repl_eval1787000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_repl_eval1787000008_A); return ok }

func A_arbace_c_repl_eval1787000008_A_Cast(x any) *A_arbace_c_repl_eval1787000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_repl_eval1787000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_repl_eval1787000008_A_class)) }; return v }



type A_arbace_c_repl_eval1787000008_fn__1787000009_A struct{ j2g_header uint64 }

var A_arbace_c_repl_eval1787000008_fn__1787000009_A_fn_class *jrt.Class



type A_arbace_c_repl_file_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_file_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_file_BANG__fn__1787000030_A struct{ j2g_header uint64 }

var A_arbace_c_repl_file_BANG__fn__1787000030_A_fn_class *jrt.Class



type A_arbace_c_repl_file_BANG__fn__1787000032_A struct{ j2g_header uint64; F_std any }

var A_arbace_c_repl_file_BANG__fn__1787000032_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000017_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000017_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000019_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000019_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000043_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000043_A_fn_class *jrt.Class



type A_arbace_c_repl_fn__1787000045_A struct{ j2g_header uint64 }

var A_arbace_c_repl_fn__1787000045_A_fn_class *jrt.Class



type A_arbace_c_repl_include_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_include_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_include_BANG__fn__1787000036_A struct{ j2g_header uint64; F_rd any }

var A_arbace_c_repl_include_BANG__fn__1787000036_A_fn_class *jrt.Class



type A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A struct{ j2g_header uint64 }

var A_arbace_c_repl_include_BANG__fn__1787000036_fn__1787000037_A_fn_class *jrt.Class



type A_arbace_c_repl_light_run_nodes_A struct{ j2g_header uint64 }

var A_arbace_c_repl_light_run_nodes_A_fn_class *jrt.Class



type A_arbace_c_repl_reset_unit_BANG__A struct{ j2g_header uint64 }

var A_arbace_c_repl_reset_unit_BANG__A_fn_class *jrt.Class



type A_arbace_c_repl_root_A struct{ j2g_header uint64 }

var A_arbace_c_repl_root_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_A struct{ j2g_header uint64 }

var A_arbace_c_repl_run_main_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_fn__1787000064_A struct{ j2g_header uint64; F_us any }

var A_arbace_c_repl_run_main_fn__1787000064_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_iter__1787000048__1787000052_A struct{ j2g_header uint64 }

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A struct{ j2g_header uint64; F_iter__1787000048, F_s__1787000049 any }

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_A_fn_class *jrt.Class



type A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1787000051, F_c__1927001037__auto__ any }

var A_arbace_c_repl_run_main_iter__1787000048__1787000052_fn__1787000053_fn__1787000054_A_fn_class *jrt.Class



type A_arbace_c_repl_unit_read_A struct{ j2g_header uint64 }

var A_arbace_c_repl_unit_read_A_fn_class *jrt.Class
