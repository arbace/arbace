//line aot_arbace_pprint_print_table__init.ae:1
package aot_arbace_pprint_print_table

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_print_table__init_A_Load__O() any { A_arbace_pprint_print_table__init_A_Init(); A_arbace_pprint_print_table__init_A_Unit0__O(); A_arbace_pprint_print_table__init_A_Unit1__O(); return nil }



func A_arbace_pprint_print_table__init_A_Unit0__O() any { A_arbace_pprint_print_table__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_print_table__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_print_table__init_A_const_1) }

func A_arbace_pprint_print_table__init_A_Unit1__O() any { A_arbace_pprint_print_table__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); var tmp1 *lang.Var = A_arbace_pprint_print_table__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_print_table_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_print_table_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_print_table_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_print_table__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_print_table__init_A_const_3)); return A_arbace_pprint_print_table__init_A_const_2.Ref() }



type A_arbace_pprint_print_table__init_A struct{ jrt.Object }

var A_arbace_pprint_print_table__init_A_const_0 *lang.Var

var A_arbace_pprint_print_table__init_A_const_1 any

var A_arbace_pprint_print_table__init_A_const_2 *lang.Var

var A_arbace_pprint_print_table__init_A_const_3 any

var A_arbace_pprint_print_table__init_A_init jrt.ClassInit

func A_arbace_pprint_print_table__init_A_Init() { if !A_arbace_pprint_print_table__init_A_init.Done() { A_arbace_pprint_print_table__init_A_init.Run(A_arbace_pprint_print_table__init_A_clinit) } }

func A_arbace_pprint_print_table__init_A_clinit() { A_arbace_pprint_print_table__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_pprint_print_table__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_2).Ref(); A_arbace_pprint_print_table__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_2, Lit_3); A_arbace_pprint_print_table__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_14)) }

func A_arbace_pprint_print_table__init_A_New() *A_arbace_pprint_print_table__init_A { A_arbace_pprint_print_table__init_A_Init(); t := &A_arbace_pprint_print_table__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_print_table__init_A) Ctor() {}

func (t *A_arbace_pprint_print_table__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_print_table__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_print_table__init_A_class }

func (t *A_arbace_pprint_print_table__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_print_table__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_print_table__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_print_table__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_print_table__init_A); return ok }

func A_arbace_pprint_print_table__init_A_Cast(x any) *A_arbace_pprint_print_table__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_print_table__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_print_table__init_A_class)) }; return v }
