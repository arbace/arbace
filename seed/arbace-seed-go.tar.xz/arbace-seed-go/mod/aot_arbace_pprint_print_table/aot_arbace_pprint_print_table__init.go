//line aot_arbace_pprint_print_table__init.ae:1
package aot_arbace_pprint_print_table

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_print_table__init_A_Load__O() any { A_arbace_pprint_print_table__init_A_Init(); jrt.StartCheck(); A_arbace_pprint_print_table__init_A_Unit0__O(); A_arbace_pprint_print_table__init_A_Unit1__O(); return nil }



func A_arbace_pprint_print_table__init_A_Unit0__O() any { A_arbace_pprint_print_table__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_pprint_print_table__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_print_table__init_A_const_1) }

func A_arbace_pprint_print_table__init_A_Unit1__O() any { A_arbace_pprint_print_table__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); var tmp1 *lang.Var = A_arbace_pprint_print_table__init_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = aot_arbace_pprint.A_arbace_pprint_print_table_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_print_table_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); aot_arbace_pprint.A_arbace_pprint_print_table_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_print_table__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_print_table__init_A_const_3)); return A_arbace_pprint_print_table__init_A_const_2 }



type A_arbace_pprint_print_table__init_A struct{ jrt.Object }

var A_arbace_pprint_print_table__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_print_table__init_A_const_0 *lang.Var

var A_arbace_pprint_print_table__init_A_const_1 any

var A_arbace_pprint_print_table__init_A_const_2 *lang.Var

var A_arbace_pprint_print_table__init_A_const_3 any

var A_arbace_pprint_print_table__init_A_init jrt.ClassInit

func A_arbace_pprint_print_table__init_A_Init() { if !A_arbace_pprint_print_table__init_A_init.Done() { A_arbace_pprint_print_table__init_A_init.Run(A_arbace_pprint_print_table__init_A_clinit) } }

func A_arbace_pprint_print_table__init_A_clinit() { jrt.StartCheck(); A_arbace_pprint_print_table__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 13); A_arbace_pprint_print_table__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_print_table__init_A_const_pool.A[9]); A_arbace_pprint_print_table__init_A_const_1 = A_arbace_pprint_print_table__init_A_const_pool.A[10]; A_arbace_pprint_print_table__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_print_table__init_A_const_pool.A[11]); A_arbace_pprint_print_table__init_A_const_3 = A_arbace_pprint_print_table__init_A_const_pool.A[12] }

func A_arbace_pprint_print_table__init_A_New() *A_arbace_pprint_print_table__init_A { A_arbace_pprint_print_table__init_A_Init(); t := &A_arbace_pprint_print_table__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_print_table__init_A) Ctor() {}

func (t *A_arbace_pprint_print_table__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_print_table__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_print_table__init_A_class }

func (t *A_arbace_pprint_print_table__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_print_table__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_print_table__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_print_table__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_print_table__init_A); return ok }

func A_arbace_pprint_print_table__init_A_Cast(x any) *A_arbace_pprint_print_table__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_print_table__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_print_table__init_A_class)) }; return v }
