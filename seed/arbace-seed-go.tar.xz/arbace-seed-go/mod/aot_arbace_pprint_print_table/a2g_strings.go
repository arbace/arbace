//line a2g_strings.ae:1
package aot_arbace_pprint_print_table

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.pprintkn8,arglistsyn2,ksyn4,rowskn3,dockn5,addedkn4,linekn6,columnkn4,filev11,arbace.core5,in-nsR0,v13,arbace.pprint11,print-tablem12,R1,L2,V2,R2,R3,V1,R3,R4,s217,Prints a collection of maps in a textual table. Prints table headings\n   ks, and then a line of output for each row, corresponding to the keys\n   in ks. If ks are not specified, use the keys of the first item in rows.R5,s3,1.3R6,i11,R7,i1,R8,s28,arbace/pprint/print_table.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.pprint$print_table")
