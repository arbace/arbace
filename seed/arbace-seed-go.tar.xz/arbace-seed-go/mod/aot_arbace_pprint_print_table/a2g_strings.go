//line a2g_strings.ae:1
package aot_arbace_pprint_print_table

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_3 *jrt.String = jrt.Intern("print-table")

var Lit_4 *jrt.String = jrt.Intern("arglists")

var Lit_5 *jrt.String = jrt.Intern("ks")

var Lit_6 *jrt.String = jrt.Intern("rows")

var Lit_7 *jrt.String = jrt.Intern("doc")

var Lit_8 *jrt.String = jrt.Intern("Prints a collection of maps in a textual table. Prints table headings\n   ks, and then a line of output for each row, corresponding to the keys\n   in ks. If ks are not specified, use the keys of the first item in rows.")

var Lit_9 *jrt.String = jrt.Intern("added")

var Lit_10 *jrt.String = jrt.Intern("1.3")

var Lit_11 *jrt.String = jrt.Intern("line")

var Lit_12 *jrt.String = jrt.Intern("column")

var Lit_13 *jrt.String = jrt.Intern("file")

var Lit_14 *jrt.String = jrt.Intern("arbace/pprint/print_table.ae")
