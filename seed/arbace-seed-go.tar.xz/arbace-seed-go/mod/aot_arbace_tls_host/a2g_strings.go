//line a2g_strings.ae:1
package aot_arbace_tls_host

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.tls.host")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("arbace.tls's host layer: jdk.internal.jrt.TlsSocket.")

var Lit_8 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_9 *jrt.String = jrt.Intern("make-array")

var Lit_10 *jrt.String = jrt.Intern("java.lang.String")

var Lit_11 *jrt.String = jrt.Intern("roots")

var Lit_12 *jrt.String = jrt.Intern("handshake")

var Lit_13 *jrt.String = jrt.Intern("verify")

var Lit_14 *jrt.String = jrt.Intern("protocol")

var Lit_15 *jrt.String = jrt.Intern("cipher-suite")

var Lit_16 *jrt.String = jrt.Intern("application-protocol")

var Lit_17 *jrt.String = jrt.Intern("server-name")

var Lit_18 *jrt.String = jrt.Intern("seq")

var Lit_19 *jrt.String = jrt.Intern("arbace.tls.host$connect")

var Lit_20 *jrt.String = jrt.Intern("Read timed out")

var Lit_21 *jrt.String = jrt.Intern("arbace.tls.host$connect$fn__874000012")

var Lit_22 *jrt.String = jrt.Intern("arbace.tls.host$connect$fn__874000014")

var Lit_23 *jrt.String = jrt.Intern("arbace.tls.host$eval874000004$loading__1927001464__auto____874000005")

var Lit_24 *jrt.String = jrt.Intern("java.net.InetSocketAddress")

var Lit_25 *jrt.String = jrt.Intern("jdk.internal.jrt.HostNet")

var Lit_26 *jrt.String = jrt.Intern("jdk.internal.jrt.TlsSocket")

var Lit_27 *jrt.String = jrt.Intern("arbace.tls.host$eval874000008$fn__874000009")

var Lit_28 *jrt.String = jrt.Intern("arbace.tls.host$peer_certificates")

var Lit_29 *jrt.String = jrt.Intern("arbace.tls.host$session")

var Lit_30 *jrt.String = jrt.Intern("in-ns")

var Lit_31 *jrt.String = jrt.Intern("connect")

var Lit_32 *jrt.String = jrt.Intern("arglists")

var Lit_33 *jrt.String = jrt.Intern("host")

var Lit_34 *jrt.String = jrt.Intern("tag")

var Lit_35 *jrt.String = jrt.Intern("String")

var Lit_36 *jrt.String = jrt.Intern("port")

var Lit_37 *jrt.String = jrt.Intern("alpn")

var Lit_38 *jrt.String = jrt.Intern("bytes")

var Lit_39 *jrt.String = jrt.Intern("timeout")

var Lit_40 *jrt.String = jrt.Intern("A TlsSocket connected to host and port, the handshake made for server-name, alpn (the\n  protocols separated by commas, or nil), roots (PEM bytes, or nil: Mozilla's), waiting up to\n  timeout ms for each (0: no limit); or [kind message] for TLS's failures, kind :verify,\n  :handshake or :roots. The network's errors throw as java.net's.")

var Lit_41 *jrt.String = jrt.Intern("line")

var Lit_42 *jrt.String = jrt.Intern("column")

var Lit_43 *jrt.String = jrt.Intern("file")

var Lit_44 *jrt.String = jrt.Intern("arbace/tls/host.ae")

var Lit_45 *jrt.String = jrt.Intern("session")

var Lit_46 *jrt.String = jrt.Intern("s")

var Lit_47 *jrt.String = jrt.Intern("TlsSocket")

var Lit_48 *jrt.String = jrt.Intern("The session of TlsSocket s as a map (:application-protocol \"\" when none).")

var Lit_49 *jrt.String = jrt.Intern("peer-certificates")

var Lit_50 *jrt.String = jrt.Intern("The peer's certificates of TlsSocket s, DER, its own first.")
