//line aot_arbace_tls_host.ae:1
package aot_arbace_tls_host

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A_New() *A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A{}; t.Ctor(); return t }
//line :6:1
func (t *A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A) Ctor() {}
//line :6:1
func (t *A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_tls_host_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_tls_host_A_const_1); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_4)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_6)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :6:1
func A_arbace_tls_host_eval874000008_fn__874000009_A_New() *A_arbace_tls_host_eval874000008_fn__874000009_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_eval874000008_fn__874000009_A{}; t.Ctor(); return t }
//line :6:1
func (t *A_arbace_tls_host_eval874000008_fn__874000009_A) Ctor() {}
//line :6:1
func (t *A_arbace_tls_host_eval874000008_fn__874000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_tls_host_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_tls_host_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_tls_host_A_const_6), A_arbace_tls_host_A_const_4.GetRawRoot__O(), A_arbace_tls_host_A_const_5) }




func A_arbace_tls_host_connect_A_New() *A_arbace_tls_host_connect_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_connect_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_tls_host_connect_A) Ctor() {}
//line :11:1
func (t *A_arbace_tls_host_connect_A) Invoke_O_O_O_O_O_O_O__O(self, host__0, port__1, server_name__2, alpn__3, roots__4, timeout__5 any) any { var s__7 any = jrt.TlsSocket_New(); var tmp1 any = A_arbace_tls_host_connect_fn__874000012_A_New_O_O_O_O(host__0, s__7, timeout__5, port__1); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_tls_host_connect_fn__874000012_A_fn_class; if






	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_tls_host_connect_fn__874000012_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var err__8 any = /*line :11:1*/lang.IFn_Cast(A_arbace_tls_host_A_const_7.GetRawRoot__O()).Invoke_O_O__O(A_arbace_tls_host_A_const_8, A_arbace_tls_host_A_const_9); var r__9 any; var tmp3 any = A_arbace_tls_host_connect_fn__874000014_A_New_O_O_O_O_O_O(server_name__2, alpn__3, roots__4, s__7, timeout__5, err__8); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_tls_host_connect_fn__874000014_A_fn_class; if












	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_tls_host_connect_fn__874000014_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; r__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); if




	lang.Numbers_IsZero_O__Z(r__9) { return s__7 } else {

		jrt.Socket_Cast(s__7).Close__V()
//line :29:1
		var G__874000016__10_ int32 = lang.RT_IntCast_O__I(r__9)


		switch G__874000016__10_ { case -13: var tmp5 any = A_arbace_tls_host_A_const_10; return lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](err__8, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(0))); case -12: var tmp6 any = A_arbace_tls_host_A_const_11; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](err__8, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(0))); case -11: var tmp7 any = A_arbace_tls_host_A_const_12; return lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](err__8, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(0))); default:}; panic(jrt.Thrown(jrt.HostNet_Exception_I_String_String__IOException(lang.RT_IntCast_O__I(r__9), jrt.String_Cast(lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](err__8, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(0))), Lit_3))) } }
//line :18:1
func A_arbace_tls_host_connect_fn__874000012_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_tls_host_connect_fn__874000012_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_connect_fn__874000012_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :18:1
func (t *A_arbace_tls_host_connect_fn__874000012_A) Ctor_O_O_O_O(c__host, c__s, c__timeout, c__port any) { t.F_host = c__host; t.F_s = c__s; t.F_timeout = c__timeout; t.F_port = c__port }
//line :18:1
func (t *A_arbace_tls_host_connect_fn__874000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 jrt.Socket_I = jrt.Socket_Cast(t.F_s); var tmp3 any; var t_ any = t.F_host; t.F_host = nil; tmp3 = t_; var tmp4 *jrt.String = jrt.String_Cast(tmp3); var tmp5 any; var t__2 any = t.F_port; t.F_port = nil; tmp5 = t__2; var tmp6 jrt.SocketAddress_I = jrt.InetSocketAddress_New_String_I(tmp4, lang.RT_IntCast_O__I(tmp5)); var tmp7 any; var t__3 any = t.F_timeout; t.F_timeout = nil; tmp7 = t__3; tmp2.Connect_SocketAddress_I__V(tmp6, lang.RT_IntCast_O__I(tmp7)); tmp1 = nil }
//line :18:1
	return nil }(); if tmp8 != nil { if true { var t__3_2 jrt.Throwable_I = tmp8; var tmp9 any; var t__4 any = t.F_s


		t.F_s = nil; tmp9 = t__4; jrt.Socket_Cast(tmp9).Close__V()
//line :18:1
		panic(jrt.Thrown(t__3_2)) } }; return tmp1 }





func A_arbace_tls_host_connect_fn__874000014_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_tls_host_connect_fn__874000014_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_connect_fn__874000014_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :24:1
func (t *A_arbace_tls_host_connect_fn__874000014_A) Ctor_O_O_O_O_O_O(c__server_name, c__alpn, c__roots, c__s, c__timeout, c__err any) { t.F_server_name = c__server_name; t.F_alpn = c__alpn; t.F_roots = c__roots; t.F_s = c__s; t.F_timeout = c__timeout; t.F_err = c__err }
//line :24:1
func (t *A_arbace_tls_host_connect_fn__874000014_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 *jrt.TlsSocket = jrt.TlsSocket_Cast(t.F_s); var tmp3 any; var t_ any = t.F_server_name; t.F_server_name = nil; tmp3 = t_; var tmp4 *jrt.String = jrt.String_Cast(tmp3); var tmp5 any; var t__2 any = t.F_alpn; t.F_alpn = nil; tmp5 = t__2; var tmp6 *jrt.String = jrt.String_Cast(tmp5); var tmp7 any; var t__3 any = t.F_roots; t.F_roots = nil; tmp7 = t__3; var tmp8 *jrt.ByteArray = jrt.A2g_CastArray[*jrt.ByteArray](tmp7, jrt.Prim_byte.ArrayClass()); var tmp9 any; var t__4 any = t.F_timeout; t.F_timeout = nil; tmp9 = t__4; var tmp10 int32 = lang.RT_IntCast_O__I(tmp9); var tmp11 any; var t__5 any = t.F_err; t.F_err = nil; tmp11 = t__5; tmp1 = jrt.Integer_ValueOf_I__Integer(jrt.NN(tmp2).StartTls_String_String_B1_I_String1__I(tmp4, tmp6, tmp8, tmp10, jrt.A2g_CastArray[*jrt.RefArray](tmp11, jrt.String_class.ArrayClass()))).Ref() }
//line :24:1
	return nil }(); if tmp12 != nil { if true { var t__3_2 jrt.Throwable_I = tmp12; var tmp13 any; var t__6 any = t.F_s


		t.F_s = nil; tmp13 = t__6; jrt.Socket_Cast(tmp13).Close__V()
//line :24:1
		panic(jrt.Thrown(t__3_2)) } }; return tmp1 }













func A_arbace_tls_host_session_A_New() *A_arbace_tls_host_session_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_session_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_tls_host_session_A) Ctor() {}
//line :38:1
func (t *A_arbace_tls_host_session_A) Invoke_O_O__O(self, s__0 any) any { var info__2 any = jrt.NN(jrt.TlsSocket_Cast(s__0)).Session__String1().Ref(); if



	jrt.A2g_Truth(info__2) { var tmp1 any = A_arbace_tls_host_A_const_13; var tmp2 any = lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](info__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(0)); var tmp3 any = A_arbace_tls_host_A_const_14; var tmp4 any = lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](info__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(1)); var tmp5 any = A_arbace_tls_host_A_const_15; var tmp6 any = lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](info__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(2)); var tmp7 any = A_arbace_tls_host_A_const_16; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, lang.RT_Aget_O1_I__O(jrt.A2g_CastArray[*jrt.RefArray](info__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(3)))) } else { return nil } }



func A_arbace_tls_host_peer_certificates_A_New() *A_arbace_tls_host_peer_certificates_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_peer_certificates_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_tls_host_peer_certificates_A) Ctor() {}
//line :46:1
func (t *A_arbace_tls_host_peer_certificates_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.IFn_Cast(A_arbace_tls_host_A_const_17.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.TlsSocket_Cast(s__0)).PeerCertificates__B2().Ref())
}



type A_arbace_tls_host_A struct{ jrt.Object }

var A_arbace_tls_host_A_const_pool *jrt.RefArray

var A_arbace_tls_host_A_const_0 *lang.Var

var A_arbace_tls_host_A_const_1 any

var A_arbace_tls_host_A_const_2 *lang.Var

var A_arbace_tls_host_A_const_3 *lang.Var

var A_arbace_tls_host_A_const_4 *lang.Var

var A_arbace_tls_host_A_const_5 any

var A_arbace_tls_host_A_const_6 *lang.Var

var A_arbace_tls_host_A_const_7 *lang.Var

var A_arbace_tls_host_A_const_8 *jrt.Class

var A_arbace_tls_host_A_const_9 any

var A_arbace_tls_host_A_const_10 *lang.Keyword

var A_arbace_tls_host_A_const_11 *lang.Keyword

var A_arbace_tls_host_A_const_12 *lang.Keyword

var A_arbace_tls_host_A_const_13 *lang.Keyword

var A_arbace_tls_host_A_const_14 *lang.Keyword

var A_arbace_tls_host_A_const_15 *lang.Keyword

var A_arbace_tls_host_A_const_16 *lang.Keyword

var A_arbace_tls_host_A_const_17 *lang.Var

var A_arbace_tls_host_A_init jrt.ClassInit

func A_arbace_tls_host_A_Init() { if !A_arbace_tls_host_A_init.Done() { A_arbace_tls_host_A_init.Run(A_arbace_tls_host_A_clinit) } }

func A_arbace_tls_host_A_clinit() { A_arbace_tls_host_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 27); A_arbace_tls_host_A_const_0 = lang.Var_Cast(A_arbace_tls_host_A_const_pool.A[9]); A_arbace_tls_host_A_const_1 = A_arbace_tls_host_A_const_pool.A[10]; A_arbace_tls_host_A_const_2 = lang.Var_Cast(A_arbace_tls_host_A_const_pool.A[11]); A_arbace_tls_host_A_const_3 = lang.Var_Cast(A_arbace_tls_host_A_const_pool.A[12]); A_arbace_tls_host_A_const_4 = lang.Var_Cast(A_arbace_tls_host_A_const_pool.A[13]); A_arbace_tls_host_A_const_5 = A_arbace_tls_host_A_const_pool.A[14]; A_arbace_tls_host_A_const_6 = lang.Var_Cast(A_arbace_tls_host_A_const_pool.A[15]); A_arbace_tls_host_A_const_7 = lang.Var_Cast(A_arbace_tls_host_A_const_pool.A[16]); A_arbace_tls_host_A_const_8 = jrt.Class_Cast(A_arbace_tls_host_A_const_pool.A[17]); A_arbace_tls_host_A_const_9 = A_arbace_tls_host_A_const_pool.A[18]; A_arbace_tls_host_A_const_10 = lang.Keyword_Cast(A_arbace_tls_host_A_const_pool.A[19]); A_arbace_tls_host_A_const_11 = lang.Keyword_Cast(A_arbace_tls_host_A_const_pool.A[20]); A_arbace_tls_host_A_const_12 = lang.Keyword_Cast(A_arbace_tls_host_A_const_pool.A[21]); A_arbace_tls_host_A_const_13 = lang.Keyword_Cast(A_arbace_tls_host_A_const_pool.A[22]); A_arbace_tls_host_A_const_14 = lang.Keyword_Cast(A_arbace_tls_host_A_const_pool.A[23]); A_arbace_tls_host_A_const_15 = lang.Keyword_Cast(A_arbace_tls_host_A_const_pool.A[24]); A_arbace_tls_host_A_const_16 = lang.Keyword_Cast(A_arbace_tls_host_A_const_pool.A[25]); A_arbace_tls_host_A_const_17 = lang.Var_Cast(A_arbace_tls_host_A_const_pool.A[26]) }

func A_arbace_tls_host_A_New() *A_arbace_tls_host_A { A_arbace_tls_host_A_Init(); t := &A_arbace_tls_host_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_host_A) Ctor() {}

func (t *A_arbace_tls_host_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_host_A) GetClass__Class() *jrt.Class { return A_arbace_tls_host_A_class }

func (t *A_arbace_tls_host_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_host_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_host_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_host_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_host_A); return ok }

func A_arbace_tls_host_A_Cast(x any) *A_arbace_tls_host_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_host_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_host_A_class)) }; return v }



type A_arbace_tls_host_connect_A struct{ a2g_header uint64 }

var A_arbace_tls_host_connect_A_fn_class *jrt.Class



type A_arbace_tls_host_connect_fn__874000012_A struct{ a2g_header uint64; F_host, F_s, F_timeout, F_port any }

var A_arbace_tls_host_connect_fn__874000012_A_fn_class *jrt.Class



type A_arbace_tls_host_connect_fn__874000014_A struct{ a2g_header uint64; F_server_name, F_alpn, F_roots, F_s, F_timeout, F_err any }

var A_arbace_tls_host_connect_fn__874000014_A_fn_class *jrt.Class



type A_arbace_tls_host_eval874000004_A struct{ jrt.Object }

func A_arbace_tls_host_eval874000004_A_New() *A_arbace_tls_host_eval874000004_A { t := &A_arbace_tls_host_eval874000004_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_host_eval874000004_A) Ctor() {}

func (t *A_arbace_tls_host_eval874000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_host_eval874000004_A) GetClass__Class() *jrt.Class { return A_arbace_tls_host_eval874000004_A_class }

func (t *A_arbace_tls_host_eval874000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_host_eval874000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_host_eval874000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_host_eval874000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_host_eval874000004_A); return ok }

func A_arbace_tls_host_eval874000004_A_Cast(x any) *A_arbace_tls_host_eval874000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_host_eval874000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_host_eval874000004_A_class)) }; return v }



type A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A struct{ a2g_header uint64 }

var A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A_fn_class *jrt.Class



type A_arbace_tls_host_eval874000008_A struct{ jrt.Object }

func A_arbace_tls_host_eval874000008_A_New() *A_arbace_tls_host_eval874000008_A { t := &A_arbace_tls_host_eval874000008_A{}; t.Ctor(); return t }

func (t *A_arbace_tls_host_eval874000008_A) Ctor() {}

func (t *A_arbace_tls_host_eval874000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_tls_host_eval874000008_A) GetClass__Class() *jrt.Class { return A_arbace_tls_host_eval874000008_A_class }

func (t *A_arbace_tls_host_eval874000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_tls_host_eval874000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_tls_host_eval874000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_tls_host_eval874000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_tls_host_eval874000008_A); return ok }

func A_arbace_tls_host_eval874000008_A_Cast(x any) *A_arbace_tls_host_eval874000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_tls_host_eval874000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_tls_host_eval874000008_A_class)) }; return v }



type A_arbace_tls_host_eval874000008_fn__874000009_A struct{ a2g_header uint64 }

var A_arbace_tls_host_eval874000008_fn__874000009_A_fn_class *jrt.Class



type A_arbace_tls_host_peer_certificates_A struct{ a2g_header uint64 }

var A_arbace_tls_host_peer_certificates_A_fn_class *jrt.Class



type A_arbace_tls_host_session_A struct{ a2g_header uint64 }

var A_arbace_tls_host_session_A_fn_class *jrt.Class
