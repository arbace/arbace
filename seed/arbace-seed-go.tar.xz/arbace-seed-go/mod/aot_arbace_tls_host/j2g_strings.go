//line j2g_strings.ae:1
package aot_arbace_tls_host

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn5,rootskn9,handshakekn6,verifykn8,protocolkn12,cipher-suitekn20,application-protocolkn11,server-namev11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.tls.hostm2,R1,s52,arbace.tls's host layer: jdk.internal.jrt.TlsSocket.v11,arbace.core10,make-arrayC16,java.lang.Stringl1,R2,R3,R4,R5,R6,R7,R8,v11,arbace.core3,seq")

var Lit_1 *jrt.String = jrt.Intern("arbace.tls.host$connect$fn__874000012")

var Lit_2 *jrt.String = jrt.Intern("arbace.tls.host$connect$fn__874000014")

var Lit_3 *jrt.String = jrt.Intern("Read timed out")

var Lit_4 *jrt.String = jrt.Intern("java.net.InetSocketAddress")

var Lit_5 *jrt.String = jrt.Intern("jdk.internal.jrt.HostNet")

var Lit_6 *jrt.String = jrt.Intern("jdk.internal.jrt.TlsSocket")

var Lit_7 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringyn4,portyn5,bytesyn7,timeoutkn4,linekn6,columnkn4,fileyn9,TlsSocketv11,arbace.core5,in-nsMyn15,arbace.tls.hostm2,R0,s52,arbace.tls's host layer: jdk.internal.jrt.TlsSocket.m2,R0,s52,arbace.tls's host layer: jdk.internal.jrt.TlsSocket.R1,v15,arbace.tls.host7,connectm10,R2,L1,V6,Myn4,hostm2,R3,R4,R5,Myn11,server-namem2,R3,R4,Myn4,alpnm2,R3,R4,Myn5,rootsm2,R3,R6,R7,R0,s334,A TlsSocket connected to host and port, the handshake made for server-name, alpn (the\n  protocols separated by commas, or nil), roots (PEM bytes, or nil: Mozilla's), waiting up to\n  timeout ms for each (0: no limit); or [kind message] for TLS's failures, kind :verify,\n  :handshake or :roots. The network's errors throw as java.net's.R8,i11,R9,i1,R10,s18,arbace/tls/host.aev15,arbace.tls.host7,sessionm10,R2,L1,V1,Myn1,sm2,R3,R11,R0,s73,The session of TlsSocket s as a map (:application-protocol \"\" when none).R8,i38,R9,i1,R10,s18,arbace/tls/host.aev15,arbace.tls.host17,peer-certificatesm10,R2,L1,V1,Myn1,sm2,R3,R11,R0,s59,The peer's certificates of TlsSocket s, DER, its own first.R8,i46,R9,i1,R10,s18,arbace/tls/host.ae")

var Lit_8 *jrt.String = jrt.Intern("arbace.tls.host$eval874000004$loading__1927001464__auto____874000005")

var Lit_9 *jrt.String = jrt.Intern("arbace.tls.host$eval874000008$fn__874000009")

var Lit_10 *jrt.String = jrt.Intern("arbace.tls.host$connect")

var Lit_11 *jrt.String = jrt.Intern("arbace.tls.host$session")

var Lit_12 *jrt.String = jrt.Intern("arbace.tls.host$peer_certificates")
