//line j2g_up.ae:1
package aot_arbace_tls_host

import "arbace/lang"


func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }
