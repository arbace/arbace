//line j2g_classes.ae:1
package aot_arbace_tls_host

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_tls_host_connect_A_class, Name: "arbace.tls.host$connect", Modifiers: 25, Simple: "connect", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_connect_A", Source: "host.ae", Declaring: &A_arbace_tls_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF6_class}}, jrt.CodeDecl{Out: &A_arbace_tls_host_connect_fn__874000012_A_class, Name: "arbace.tls.host$connect$fn__874000012", Modifiers: 25, Simple: "fn__874000012", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_connect_fn__874000012_A", Source: "host.ae", Declaring: &A_arbace_tls_host_connect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_tls_host_connect_fn__874000014_A_class, Name: "arbace.tls.host$connect$fn__874000014", Modifiers: 25, Simple: "fn__874000014", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_connect_fn__874000014_A", Source: "host.ae", Declaring: &A_arbace_tls_host_connect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A_class, Name: "arbace.tls.host$eval874000004$loading__1927001464__auto____874000005", Modifiers: 25, Simple: "loading__1927001464__auto____874000005", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A", Source: "host.ae", Declaring: &A_arbace_tls_host_eval874000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_tls_host_eval874000008_fn__874000009_A_class, Name: "arbace.tls.host$eval874000008$fn__874000009", Modifiers: 25, Simple: "fn__874000009", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_eval874000008_fn__874000009_A", Source: "host.ae", Declaring: &A_arbace_tls_host_eval874000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_tls_host_peer_certificates_A_class, Name: "arbace.tls.host$peer_certificates", Modifiers: 25, Simple: "peer_certificates", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_peer_certificates_A", Source: "host.ae", Declaring: &A_arbace_tls_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_tls_host_session_A_class, Name: "arbace.tls.host$session", Modifiers: 25, Simple: "session", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_session_A", Source: "host.ae", Declaring: &A_arbace_tls_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_tls_host_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls_host_A_New()}; return nil }

var A_arbace_tls_host_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_tls_host_A_new}

var A_arbace_tls_host_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls.host", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_A"})

func init() { i := A_arbace_tls_host_A_class.Info(); i.IsInstance = A_arbace_tls_host_A_InstanceOf; i.Init = A_arbace_tls_host_A_Init; i.Table = A_arbace_tls_host_A_members }

var A_arbace_tls_host_connect_A_class *jrt.Class

var A_arbace_tls_host_connect_fn__874000012_A_class *jrt.Class

var A_arbace_tls_host_connect_fn__874000014_A_class *jrt.Class

func A_arbace_tls_host_eval874000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls_host_eval874000004_A_New()}; return nil }

var A_arbace_tls_host_eval874000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_tls_host_eval874000004_A_new}

var A_arbace_tls_host_eval874000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls.host$eval874000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_tls_host_A_class, Simple: "eval874000004", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_eval874000004_A"})

func init() { i := A_arbace_tls_host_eval874000004_A_class.Info(); i.IsInstance = A_arbace_tls_host_eval874000004_A_InstanceOf; i.Table = A_arbace_tls_host_eval874000004_A_members }

var A_arbace_tls_host_eval874000004_loading__1927001464__auto____874000005_A_class *jrt.Class

func A_arbace_tls_host_eval874000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls_host_eval874000008_A_New()}; return nil }

var A_arbace_tls_host_eval874000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_tls_host_eval874000008_A_new}

var A_arbace_tls_host_eval874000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls.host$eval874000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_tls_host_A_class, Simple: "eval874000008", Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host_eval874000008_A"})

func init() { i := A_arbace_tls_host_eval874000008_A_class.Info(); i.IsInstance = A_arbace_tls_host_eval874000008_A_InstanceOf; i.Table = A_arbace_tls_host_eval874000008_A_members }

var A_arbace_tls_host_eval874000008_fn__874000009_A_class *jrt.Class

var A_arbace_tls_host_peer_certificates_A_class *jrt.Class

var A_arbace_tls_host_session_A_class *jrt.Class

func A_arbace_tls_host__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_tls_host__init_A_Load__O()}; return nil }

func A_arbace_tls_host__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_tls_host__init_A_New()}; return nil }

var A_arbace_tls_host__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_tls_host__init_A_invoke, New: A_arbace_tls_host__init_A_new}

var A_arbace_tls_host__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.tls.host__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_tls_host.A_arbace_tls_host__init_A", Source: "host.ae"})

func init() { i := A_arbace_tls_host__init_A_class.Info(); i.IsInstance = A_arbace_tls_host__init_A_InstanceOf; i.Init = A_arbace_tls_host__init_A_Init; i.Table = A_arbace_tls_host__init_A_members }
