//line j2g_strings.ae:1
package aot_arbace_go_check_decl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,ekn5,referyn1,oyn5,oset!yn4,err!yn6,error!yn20,arbace.go.check.codeyn4,codeyn11,arbace.corekn3,dockn5,targskn6,originkn4,elsekn5,tuplekn9,interfacekn7,pointerkn5,arraykn4,typekn3,mapkn5,slicekn4,chankn4,funckn5,unionkn6,structkn3,allkn5,termskn10,comparablekn5,laterkn5,boundkn14,InvalidTypeArgkn5,canonkn3,idxkn8,verticeskn6,weightkn3,prekn3,lenkn3,objkn5,namedkn5,edgeskn3,dstkn3,srckn4,linekn4,filekn4,namekn5,localkn3,pkgkn7,ambientyn4,instkn9,decl-linekn20,InvalidInstanceCyclekn4,loopkn7,invalidkn7,tparamskn8,pkg-namekn10,underlyingkn15,NotAGenericTypekn17,WrongTypeArgCountkn5,substkn10,lazy-underkn8,rtparamskn2,idkn4,depskn4,refskn8,verifiedkn5,scopekn10,file-scopekn4,langkn5,fn-idkn4,kindkn4,pathkn9,pkg-levelkn4,declkn5,colorkn5,whitekn4,objskn15,InvalidInitDeclkn15,InvalidMainDeclkn13,DuplicateDeclkn3,tagkn3,valkn5,initskn15,MissingInitExprkn16,WrongAssignCountkn5,constkn4,formkn4,speckn4,iotakn4,initkn8,nil-initkn6,ninitskn6,nnameskn9,inheritedkn3,varkn5,multikn8,has-initkn3,lhskn11,type-paramskn9,type-formkn5,aliaskn13,tparams-countyn1,*ys2,go4,funckn9,sig-formskn6,methodkn9,recv-formkn4,basekn3,ptrkn12,generic-recvkn8,ptr-recvkn7,generickn11,InvalidRecvkn7,methodskn6,externkn15,MissingInitBodykn7,BadRecvkn5,declskn17,InvalidSyntaxTreekn10,decl-orderkn5,flagskn11,unsupportedks19,arbace.go.check.env11,unsupportedkn16,unsupported-lineks19,arbace.go.check.env4,linekn9,annotatedkn7,unknownkn8,constantkn4,modekn16,InvalidConstTypekn16,InvalidConstInitkn4,treekn2,opkn10,const-declkn5,valuekn8,var-declkn8,var-initkn3,rhsyn1,_kn9,resolvingkn23,DuplicateFieldAndMethodkn15,DuplicateMethodkn10,recv-namedkn6,bodieskn14,InvalidInitSigkn3,sigkn6,paramskn7,resultskn4,bodykn4,recvkn2,cxkn5,blackkn4,greykn15,generic-invalidkn16,InvalidInitCyclekn7,importskn12,BrokenImportkn8,importedkn3,dotkn13,scope-entrieskn5,nameskn11,import-objskn11,dot-importskn4,dotskn4,usedkn12,UnusedImportv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V5,R7,R1,R8,R9,V4,R10,R11,R12,R13,V3,R14,R1,R15,v11,arbace.core5,referR16,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn20,arbace.go.check.declm2,R17,s252,goi's checker: a package's declarations (doc/go/GOI-SPEC.md §3.4, §3.6, §3.7), after\n  go/types' resolver.go (collectObjects, packageObjects), decl.go (objDecl and its colouring,\n  constDecl, varDecl, typeDecl, funcDecl), validtype.go and initorder.go.v11,arbace.core6,empty?v11,arbace.core8,keyword?v21,arbace.go.check.types7,tparam?v21,arbace.go.check.types6,named?v21,arbace.go.check.types4,infov11,arbace.core3,seqR18,v11,arbace.core4,mapvv20,arbace.go.check.decl5,substv20,arbace.go.check.decl11,instantiateR19,R20,R21,v11,arbace.core4,intoV1,R21,v11,arbace.core3,mapv11,arbace.core4,restR22,R23,R24,v21,arbace.go.check.types12,sort-methodsv11,arbace.core6,updateR25,v20,arbace.go.check.decl10,subst-tsetR26,R27,R28,R29,R30,R31,v20,arbace.go.check.decl11,subst-termsR32,v21,arbace.go.check.types10,terms-normv11,arbace.core4,map?v21,arbace.go.check.types9,make-tsetR33,R34,v19,arbace.go.check.env6,*decl*R35,v11,arbace.core4,fnilv11,arbace.core5,mergev11,arbace.core6,zipmapR36,v21,arbace.go.check.types15,satisfies-causev19,arbace.go.check.env4,err!R37,v20,arbace.go.check.decl6,*mono*v11,arbace.core8,assoc-inR38,R39,R40,R41,l0,R42,l-1,R43,R44,R45,R46,R47,R48,R49,R50,R51,v19,arbace.go.check.env8,*gofile*v20,arbace.go.check.decl12,mono-vertex!v11,arbace.core3,notR52,v11,arbace.core4,not=R53,v20,arbace.go.check.code8,pkg-pathv11,arbace.core9,contains?R54,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv20,arbace.go.check.decl10,mono-edge!v20,arbace.go.check.decl14,tparam-vertex!l1,v19,arbace.go.check.env1,ov11,arbace.core10,chunk-restv11,arbace.core4,nextv20,arbace.go.check.decl19,local-named-vertex!v11,arbace.core4,seq?R55,v11,arbace.core3,vecv11,arbace.core5,nnextv11,arbace.core7,symbol?v20,arbace.go.check.code5,flinev19,arbace.go.check.env12,current-linev11,arbace.core11,map-indexedv11,arbace.core6,vectorv20,arbace.go.check.decl12,mono-assign!v11,arbace.core8,to-arrayv11,arbace.core10,drop-whilev19,arbace.go.check.env6,error!R56,R57,v11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv21,arbace.go.check.types8,type-strv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core6,reducev11,arbace.core7,reducedR58,v11,arbace.core5,assocv11,arbace.core7,vector?v11,arbace.core6,secondv11,arbace.core6,every?v21,arbace.go.check.types6,valid?v19,arbace.go.check.env6,*line*v20,arbace.go.check.decl6,later!v20,arbace.go.check.decl7,verify!v20,arbace.go.check.decl12,mono-record!v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv20,arbace.go.check.decl13,verify-later!R59,R60,v20,arbace.go.check.decl9,obj-decl!v20,arbace.go.check.decl9,instancesv21,arbace.go.check.types9,new-namedv11,arbace.core11,select-keysV5,R44,R51,R53,R61,R52,R62,V5,R44,R51,R53,R61,R52,v19,arbace.go.check.env8,generic!R63,R64,v21,arbace.go.check.types12,update-info!R65,R66,v21,arbace.go.check.types5,underv21,arbace.go.check.types10,deref-typeR67,v11,arbace.core9,volatile!R68,v21,arbace.go.check.types7,next-idR69,R70,R71,R72,R73,R74,R75,v19,arbace.go.check.env3,objR76,v19,arbace.go.check.env5,*pkg*R77,R78,R79,R80,R81,R82,v20,arbace.go.check.decl5,*ctx*R83,R84,v19,arbace.go.check.env9,scope-getR85,v19,arbace.go.check.env10,scope-put!v11,arbace.core7,string?v20,arbace.go.check.code9,head-namev20,arbace.go.check.decl6,group?v20,arbace.go.check.decl11,group-specsv20,arbace.go.check.decl11,target-listv11,arbace.core4,someR86,R87,v20,arbace.go.check.decl9,init-listR88,R89,R90,v20,arbace.go.check.code10,ident-namev20,arbace.go.check.decl8,new-declR91,R92,R93,R94,R95,R96,R97,R98,R99,v20,arbace.go.check.decl7,pkg-objv20,arbace.go.check.decl12,declare-pkg!R100,R101,R102,R103,v19,arbace.go.check.env10,*child-at*V1,nR104,R105,R106,R107,v19,arbace.go.check.env5,oset!R61,v20,arbace.go.check.code6,go-id?R108,v11,arbace.core4,namev11,arbace.core9,namespacev11,arbace.core4,dropl2,v20,arbace.go.check.decl12,collect-funcv11,arbace.core5,list*R109,v20,arbace.go.check.decl9,recv-baseR110,R111,R112,R113,R114,R115,R116,R117,R118,v20,arbace.go.check.code8,expr-strR119,R120,R121,R122,R123,v20,arbace.go.check.decl11,collect-varv20,arbace.go.check.decl12,collect-typeR124,v20,arbace.go.check.decl13,collect-constR108,v11,arbace.core7,vreset!R125,v11,arbace.core5,rangev20,arbace.go.check.code12,cycle-error!v20,arbace.go.check.code9,obj-entryv20,arbace.go.check.decl12,first-in-srcv20,arbace.go.check.decl6,*path*v11,arbace.core6,subvecv11,arbace.core6,filterS2,R91,R100,v20,arbace.go.check.decl12,cycle-error!v20,arbace.go.check.code8,cx-flagsR126,v19,arbace.go.check.env12,unsupported?R127,R128,v11,arbace.core7,ex-dataR129,R130,v20,arbace.go.check.decl9,with-declv20,arbace.go.check.code10,val-equal?v19,arbace.go.check.env9,verified!v19,arbace.go.check.env17,annotation-error!v11,arbace.core6,pr-strv20,arbace.go.check.code12,val-form-strR131,R132,v20,arbace.go.check.decl7,file-cxv20,arbace.go.check.code7,typexprv21,arbace.go.check.types11,const-type?v20,arbace.go.check.code9,val-constv20,arbace.go.check.code4,exprv20,arbace.go.check.code8,invalid?R133,R134,v20,arbace.go.check.code10,assignmentv20,arbace.go.check.decl11,verify-val!v19,arbace.go.check.env8,*errpos*R135,R136,v20,arbace.go.check.code11,operand-strR137,R138,R139,R140,R141,v20,arbace.go.check.code10,rhs-valuesR142,R143,v20,arbace.go.check.code8,init-varR144,v20,arbace.go.check.code12,tparam-scopev20,arbace.go.check.code17,valid-type-later!R145,v11,arbace.core3,setv21,arbace.go.check.types10,methods-ofR146,v21,arbace.go.check.types8,pointer?v21,arbace.go.check.types10,interface?R147,R148,R108,v11,arbace.core6,repeatv20,arbace.go.check.code9,signatureR149,v20,arbace.go.check.decl11,mono-canon!R150,R151,R152,R153,R154,R155,R156,R157,R158,v20,arbace.go.check.decl12,valid-cycle?v20,arbace.go.check.decl9,func-sig!v20,arbace.go.check.decl11,const-decl!v20,arbace.go.check.decl10,type-decl!v11,arbace.core6,removev20,arbace.go.check.decl9,var-decl!R159,S2,R91,R100,v20,arbace.go.check.code9,go-ident?v20,arbace.go.check.decl15,instance-under!v21,arbace.go.check.types9,exported?v20,arbace.go.check.code9,func-bodyS3,R29,R91,R100,S3,R29,R91,R100,v11,arbace.core10,comparatorv11,arbace.core7,sort-byv11,arbace.core4,disjv20,arbace.go.check.decl13,cycle-report!v20,arbace.go.check.decl9,find-pathR160,R161,R162,R163,R164,R165,R166,R167,R168,R169,v11,arbace.core6,formatv11,arbace.core6,concatR170,R171,")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.decl$check_body_BANG_$fn__1368000494")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_const$fn__1368000148")

var Lit_3 *jrt.String = jrt.Intern("missing init expr for const declaration")

var Lit_4 *jrt.String = jrt.Intern("missing init expr for %s")

var Lit_5 *jrt.String = jrt.Intern("extra init expr")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_file_BANG_$fn__1368000302")

var Lit_7 *jrt.String = jrt.Intern("go/func")

var Lit_8 *jrt.String = jrt.Intern("go/var")

var Lit_9 *jrt.String = jrt.Intern("go/type")

var Lit_10 *jrt.String = jrt.Intern("go/directive")

var Lit_11 *jrt.String = jrt.Intern("go/const")

var Lit_12 *jrt.String = jrt.Intern("go/method")

var Lit_13 *jrt.String = jrt.Intern("not a declaration: %s")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_file_BANG_$fn__1368000306")

var Lit_15 *jrt.String = jrt.Intern("method has no receiver")

var Lit_16 *jrt.String = jrt.Intern("invalid receiver type %s")

var Lit_17 *jrt.String = jrt.Intern("_")

var Lit_18 *jrt.String = jrt.Intern("init")

var Lit_19 *jrt.String = jrt.Intern("func init must have no type parameters")

var Lit_20 *jrt.String = jrt.Intern("func init must have a body")

var Lit_21 *jrt.String = jrt.Intern("main")

var Lit_22 *jrt.String = jrt.Intern("func main must have no type parameters")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_type$fn__1368000249")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_type$fn__1368000264")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_type$fn__1368000278")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000169")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000189")

var Lit_28 *jrt.String = jrt.Intern("zero")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000191__1368000195")

var Lit_30 *jrt.String = jrt.Intern("assignment mismatch: %d variables but %d values")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000210")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000230")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000232__1368000236")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000169$fn__1368000170")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000169$iter__1368000172__1368000176")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000169$iter__1368000172__1368000176$fn__1368000177")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000169$iter__1368000172__1368000176$fn__1368000177$fn__1368000178")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000210$fn__1368000211")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000210$iter__1368000213__1368000217")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000210$iter__1368000213__1368000217$fn__1368000218")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000210$iter__1368000213__1368000217$fn__1368000218$fn__1368000219")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000191__1368000195$fn__1368000196")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000191__1368000195$fn__1368000196$fn__1368000197")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000232__1368000236$fn__1368000237")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000232__1368000236$fn__1368000237$fn__1368000238")

var Lit_46 *jrt.String = jrt.Intern("invalid constant type %s")

var Lit_47 *jrt.String = jrt.Intern("nil is not constant")

var Lit_48 *jrt.String = jrt.Intern("%s is not constant")

var Lit_49 *jrt.String = jrt.Intern("constant declaration")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_$at__1368000602")

var Lit_51 *jrt.String = jrt.Intern("initialization cycle: ")

var Lit_52 *jrt.String = jrt.Intern(" refers to itself")

var Lit_53 *jrt.String = jrt.Intern("initialization cycle for ")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_$fn__1368000604")

var Lit_55 *jrt.String = jrt.Intern(":")

var Lit_56 *jrt.String = jrt.Intern(": ")

var Lit_57 *jrt.String = jrt.Intern("\n\t")

var Lit_58 *jrt.String = jrt.Intern(" refers to ")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_imports_BANG_$fn__1368000615")

var Lit_60 *jrt.String = jrt.Intern("could not import %s (no forms)")

var Lit_61 *jrt.String = jrt.Intern("could not import %s (%s)")

var Lit_62 *jrt.String = jrt.Intern("cannot import package as init - init must be a func")

var Lit_63 *jrt.String = jrt.Intern(".")

var Lit_64 *jrt.String = jrt.Intern("%s redeclared in this block")

var Lit_65 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_imports_BANG_$fn__1368000640")

var Lit_66 *jrt.String = jrt.Intern("cannot declare init - must be func")

var Lit_67 *jrt.String = jrt.Intern("cannot declare main - must be func")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.check.decl$direct_cycles_BANG_$fn__1368000473")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.check.decl$direct_cycles_BANG_$fn__1368000481")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.check.decl$direct_cycles_BANG_$fn__1368000473$fn__1368000474")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.check.decl$direct_cycles_BANG_$fn__1368000481$fn__1368000482")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$pkg_str__1368000663")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$iter__1368000665__1368000669")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$iter__1368000681__1368000685")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$fn__1368000708")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$iter__1368000665__1368000669$fn__1368000670")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$iter__1368000665__1368000669$fn__1368000670$fn__1368000671")

var Lit_78 *jrt.String = jrt.Intern("%s already declared through import of %s")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$iter__1368000681__1368000685$fn__1368000686")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_$iter__1368000681__1368000685$fn__1368000686$fn__1368000687")

var Lit_81 *jrt.String = jrt.Intern("%s already declared through dot-import of %s")

var Lit_82 *jrt.String = jrt.Intern("package %s (\"%s\")")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.check.decl$find_path$fn__1368000597")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.check.decl$find_path$fn__1368000599")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.check.decl$first_in_src$k__1368000320")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.check.decl$first_in_src$fn__1368000322")

var Lit_87 *jrt.String = jrt.Intern("cannot define new methods on non-local type %s")

var Lit_88 *jrt.String = jrt.Intern("func init must have no arguments and no return values")

var Lit_89 *jrt.String = jrt.Intern("func main must have no arguments and no return values")

var Lit_90 *jrt.String = jrt.Intern("values")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$deps_of__1368000502")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000506")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000508")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$add_BANG___1368000510")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000516")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000518")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000532")

var Lit_98 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000534")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000572")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$key__1368000578")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000580")

var Lit_102 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000586")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$deps_of__1368000502$fn__1368000503")

var Lit_104 *jrt.String = jrt.Intern("%s is not a generic type")

var Lit_105 *jrt.String = jrt.Intern("%s type arguments for type %s: have %d, want %d")

var Lit_106 *jrt.String = jrt.Intern("not enough")

var Lit_107 *jrt.String = jrt.Intern("too many")

var Lit_108 *jrt.String = jrt.Intern("get")

var Lit_109 *jrt.String = jrt.Intern("putIfAbsent")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.check.decl$instantiate$fn__1368000122")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_assign_BANG_$flow__1368000055")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_assign_BANG_$walk__1368000057")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_vertex_BANG_$fn__1368000044")

var Lit_114 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_$report_BANG___1368000096")

var Lit_115 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_$fn__1368000113")

var Lit_116 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_$report_BANG___1368000096$fn__1368000097")

var Lit_117 *jrt.String = jrt.Intern("instantiation cycle:")

var Lit_118 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_$report_BANG___1368000096$iter__1368000101__1368000105")

var Lit_119 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_$report_BANG___1368000096$fn__1368000097$fn__1368000098")

var Lit_120 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_$report_BANG___1368000096$iter__1368000101__1368000105$fn__1368000106")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_$report_BANG___1368000096$iter__1368000101__1368000105$fn__1368000106$fn__1368000107")

var Lit_122 *jrt.String = jrt.Intern(" implicitly parameterized by ")

var Lit_123 *jrt.String = jrt.Intern(" instantiated as ")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000448")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000451")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000451$fn__1368000452")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000451$fn__1368000452$fn__1368000454")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000451$fn__1368000452$fn__1368000456")

var Lit_129 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_method_bases_BANG_$base__1368000311")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_method_bases_BANG_$fn__1368000314")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.check.decl$run_later_BANG_$fn__1368000334")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000018")

var Lit_134 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000021")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000023")

var Lit_136 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000025")

var Lit_137 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000027")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000029")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.check.decl$subst_terms$fn__1368000033")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000378")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000380")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000386")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000388")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000390")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000392")

var Lit_146 *jrt.String = jrt.Intern("invalid receiver type ")

var Lit_147 *jrt.String = jrt.Intern(" (pointer or interface type)")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000392$fn__1368000397")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000392$fn__1368000399")

var Lit_150 *jrt.String = jrt.Intern("field and method with the same name ")

var Lit_151 *jrt.String = jrt.Intern("\"%s\" imported as %s and not used")

var Lit_152 *jrt.String = jrt.Intern("\"%s\" imported and not used")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_cycle_QMARK_$fn__1368000328")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_cycle_QMARK_$fn__1368000330")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.check.decl$var_decl_BANG_$fn__1368000362")

var Lit_156 *jrt.String = jrt.Intern("lit")

var Lit_157 *jrt.String = jrt.Intern("variable declaration")

var Lit_158 *jrt.String = jrt.Intern("%s")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.check.decl$verify_later_BANG_$fn__1368000119")

var Lit_160 *jrt.String = jrt.Intern(":val")

var Lit_161 *jrt.String = jrt.Intern("none")

var Lit_162 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn8,arglistsyn2,tyyn1,mkn7,privateyn5,termsyn2,tsyn1,fyn3,tpsyn5,targsyn5,extrakn7,dynamicyn4,mparyn4,tparyn1,kyn3,objyn5,namedyn3,dstyn3,srcyn1,wyn4,lineyn2,tpyn2,ntyn4,targyn1,gyn4,recvyn1,dyn2,fiyn4,kindyn2,nmyn4,formyn4,declyn1,&kn2,asyn4,moreyn1,xyn4,argsyn1,tyn1,iyn2,rfyn7,method?yn4,pathyn5,cycleyn2,nfyn1,nyn4,objsyn4,fromyn2,toyn4,seenyn5,_succyn1,pyn7,resolvev11,arbace.core5,in-nsMyn20,arbace.go.check.declm2,R0,s252,goi's checker: a package's declarations (doc/go/GOI-SPEC.md §3.4, §3.6, §3.7), after\n  go/types' resolver.go (collectObjects, packageObjects), decl.go (objDecl and its colouring,\n  constDecl, varDecl, typeDecl, funcDecl), validtype.go and initorder.go.m2,R0,s252,goi's checker: a package's declarations (doc/go/GOI-SPEC.md §3.4, §3.6, §3.7), after\n  go/types' resolver.go (collectObjects, packageObjects), decl.go (objDecl and its colouring,\n  constDecl, varDecl, typeDecl, funcDecl), validtype.go and initorder.go.R1,v20,arbace.go.check.decl5,substm8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,subst-termsm8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,subst-tsetm8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,instantiatem8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl13,cycle-report!m8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,obj-decl!m8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl13,verify-later!m8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L1,V2,R7,R8,R0,s51,Type ty with the type parameters of map m replaced.R3,i15,R4,i1,R5,s23,arbace/go/check/decl.aem10,R9,TR6,L1,V2,R10,R8,R3,i41,R4,i1,R5,s23,arbace/go/check/decl.aem10,R9,TR6,L1,V2,R11,R8,R3,i44,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl6,later!m10,R6,L1,V1,R12,R0,s61,Queues f for after the current declaration (go/types' later).R3,i47,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl7,verify!m10,R6,L1,V4,R12,R13,R14,R15,R0,s319,go/types' verify, true when the type arguments satisfy their constraints: else false, with\n  an error at form f for the first type argument of targs that does not\n  satisfy its type parameter's constraint (the constraints with the type arguments substituted,\n  and extra's: a generic method's receiver type parameters).R3,i52,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl6,*mono*m10,R16,TR3,i71,R4,i1,R5,s23,arbace/go/check/decl.aeR0,s220,The package's graph of type parameters' flows (go/types' monoGraph), a volatile\n  {:vertices [{:weight :pre :len :obj :named}] :edges [{:dst :src :weight :line :file :type}]\n  :canon {tparam tparam} :idx {object index}}.v20,arbace.go.check.decl11,mono-canon!m10,R6,L1,V2,R17,R18,R0,s80,go/types' recordCanon: a method's receiver type parameter stands for its type's.R3,i77,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,mono-vertex!m10,R9,TR6,L1,V3,R19,R20,R21,R3,i82,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,mono-edge!m10,R9,TR6,L1,V5,R22,R23,R24,R25,R7,R3,i89,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl14,tparam-vertex!m10,R9,TR6,L1,V1,R26,R3,i92,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl19,local-named-vertex!m12,R9,TR6,L1,V1,R27,R0,s154,go/types' localNamedVertex: a type declared in a generic function, parameterized by the type\n  parameters in scope where it is declared (:ambient), or -1.R3,i97,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,mono-assign!m12,R9,TR6,L1,V3,R25,R18,R28,R0,s78,go/types' assign: type argument targ flowing into type parameter tpar at line.R3,i111,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,mono-record!m12,R9,TR6,L1,V3,R12,R13,R14,R0,s155,go/types' recordInstance: the type arguments of an instantiation (form f; its explicit type\n  arguments' lines, else f's) flowing into its type parameters.R3,i136,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,monomorph!m10,R6,L1,V0,R0,s160,go/types' monomorph: an instantiation cycle (a path of flows through every vertex) reported\n  at its type parameter: \"instantiation cycle:\" and a line per flow.R3,i146,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L2,V3,R12,R13,R14,V4,R12,R13,R14,R15,R0,s141,Verifies the type arguments of an instantiation after the current declaration; satisfied, they\n  are recorded for the monomorphization check.R3,i186,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,instancesm8,R9,TR3,i196,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L1,V3,R12,R29,R14,R0,s87,The instance of generic named type g with type arguments targs (one per argument list).R3,i198,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl15,instance-under!m10,R6,L1,V1,R27,R0,s80,Completes an instance's underlying type (lazily: its origin may be in progress).R3,i232,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,subst-methodm10,R6,L1,V2,R30,R31,R0,s162,A method's data seen through recv, an instance of its generic type: its signature with the\n  receiver's type parameters replaced by the instance's type arguments.R3,i241,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl5,*ctx*m10,R16,TR3,i256,R4,i1,R5,s23,arbace/go/check/decl.aeR0,s167,The package's checking context: {:objs (volatile vector of objects in source order),\n  :methods (volatile {base-name [method-objs]}), :later (volatile vector of fns)}.v20,arbace.go.check.decl8,new-declm10,R9,TR6,L1,V1,R8,R3,i261,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl7,file-cxm12,R9,TR6,L1,V1,R32,R0,s54,The context of a package-level declaration in file fi.R3,i264,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl7,pkg-objm10,R9,TR6,L1,V7,R33,R34,R35,R32,R36,R37,m2,R38,R39,R3,i270,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,declare-pkg!m10,R9,TR6,L1,V3,R40,R34,R35,R3,i275,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl6,group?m10,R9,TR6,L1,V1,R41,R3,i289,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,group-specsm10,R9,TR6,L1,V1,R41,R3,i293,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,target-listm10,R9,TR6,L1,V1,R42,R3,i295,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,init-listm10,R9,TR6,L1,V1,R43,R3,i296,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl13,collect-constm10,R9,TR6,L1,V2,R12,R32,R3,i298,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,collect-varm10,R9,TR6,L1,V2,R12,R32,R3,i332,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,collect-typem10,R9,TR6,L1,V2,R12,R32,R3,i358,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,recv-basem12,R9,TR6,L1,V1,R44,R0,s134,The receiver base type name of a method's receiver form, and whether the receiver type\n  has type arguments (a generic type's method).R3,i379,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,collect-funcm10,R9,TR6,L1,V3,R12,R32,R45,R3,i390,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl13,collect-file!m10,R6,L1,V1,R32,R0,s65,Collects the package-level objects of a file's declaration forms.R3,i428,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl21,resolve-method-bases!m10,R6,L1,V0,R0,s108,go/types' resolveBaseTypeName: methods whose receiver names an alias go to the type the\n  alias chain names.R3,i443,R4,i1,R5,s23,arbace/go/check/decl.aem8,R2,TR3,i462,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl6,*path*m10,R16,TR3,i464,R4,i1,R5,s23,arbace/go/check/decl.aeR0,s47,The objects being declared (go/types' objPath).v20,arbace.go.check.decl12,first-in-srcm12,R9,TR6,L1,V1,R46,R0,s74,go/types' firstInSrc: the index of the object of path first in the source.R3,i466,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,cycle-error!m10,R9,TR6,L1,V1,R47,R3,i472,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,valid-cycle?m10,R9,TR6,L1,V1,R40,R3,i475,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,with-declm12,R9,TR6,L1,V2,R31,R12,R0,s77,Runs f with the declaration's context bound (its file, the decl for records).R3,i485,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,run-later!m10,R9,TR6,L1,V1,R31,R3,i498,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,verify-val!m12,R9,TR6,L1,V3,R48,R40,R49,R0,s57,Compares a package constant's value with its :val (§3.6).R3,i506,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,const-decl!m10,R9,TR6,L1,V2,R40,R31,R3,i518,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,var-decl!m10,R9,TR6,L1,V2,R40,R31,R3,i552,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,type-decl!m10,R9,TR6,L1,V2,R40,R31,R3,i573,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,func-sig!m12,R9,TR6,L1,V2,R40,R31,R0,s77,A function's or method's signature (funcDecl): its type set, the body queued.R3,i628,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L1,V1,R40,R0,s83,Checks the declaration of package-level object x when not done (go/types' objDecl).R3,i688,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl14,direct-cycles!m10,R6,L1,V1,R50,R0,s362,go/types' directCycles (cycles.go, go1.27): before the declarations are checked, a cycle of\n  package-level type declarations each naming the next (a defined type or an alias whose RHS\n  is a type name of the package scope) is reported (cycleError, from the type first in the\n  source) and the type that closes it made invalid (its object black, never declared).R3,i723,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl14,resolve-named!m10,R6,L1,V1,R27,R0,s75,Completes a named type's declaration when its underlying type is asked for.R3,i752,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,method-data!m10,R6,L1,V1,R8,R0,s83,The data of a method object, its declaration checked: {:name :pkg :type :ptr-recv}.R3,i760,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,check-body!m8,R6,L1,V1,R40,R3,i769,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,init-orderm10,R6,L1,V1,R50,R0,s77,go/types' InitOrder: the initializers in order, each its vector of variables.R3,i783,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,find-pathm12,R9,TR6,L1,V3,R51,R52,R53,R0,s153,go/types' findPath (initorder.go): a path of dependencies from object from to object to,\n  reversed (to first), or nil; the dependencies in source order.R3,i835,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L1,V2,R49,R54,R0,s144,go/types' reportCycle (initorder.go): the initialization cycle through n, a line per\n  reference at its object (\"\\n\\tFILE:LINE: a refers to b\").R3,i844,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,import-namem10,R9,TR6,L1,V1,R55,R3,i864,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl16,declare-imports!m10,R6,L1,V2,R32,R56,R0,s81,The file scope's imports: package objects, dot imports. resolve: path -> package.R3,i866,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl21,file-scope-conflicts!m10,R6,L1,V1,R32,R0,s140,go/types' resolver: a package-level object named as one of file fi's imports (or names a\n  dot import brings in) is an error, at the object.R3,i895,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl15,unused-imports!m8,R6,L1,V1,R32,R3,i912,R4,i1,R5,s23,arbace/go/check/decl.ae")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.check.decl$eval1368000004$loading__1927001464__auto____1368000005")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.check.decl$eval1368000008$fn__1368000009")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.check.decl$subst")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.check.decl$subst_terms")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.check.decl$subst_tset")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.check.decl$later_BANG_")

var Lit_169 *jrt.String = jrt.Intern("arbace.go.check.decl$verify_BANG_")

var Lit_170 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_canon_BANG_")

var Lit_171 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_vertex_BANG_")

var Lit_172 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_edge_BANG_")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.check.decl$tparam_vertex_BANG_")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.check.decl$local_named_vertex_BANG_")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_assign_BANG_")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.check.decl$mono_record_BANG_")

var Lit_177 *jrt.String = jrt.Intern("arbace.go.check.decl$monomorph_BANG_")

var Lit_178 *jrt.String = jrt.Intern("arbace.go.check.decl$verify_later_BANG_")

var Lit_179 *jrt.String = jrt.Intern("arbace.go.check.decl$instantiate")

var Lit_180 *jrt.String = jrt.Intern("arbace.go.check.decl$instance_under_BANG_")

var Lit_181 *jrt.String = jrt.Intern("arbace.go.check.decl$subst_method")

var Lit_182 *jrt.String = jrt.Intern("arbace.go.check.decl$new_decl")

var Lit_183 *jrt.String = jrt.Intern("arbace.go.check.decl$file_cx")

var Lit_184 *jrt.String = jrt.Intern("arbace.go.check.decl$pkg_obj")

var Lit_185 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_pkg_BANG_")

var Lit_186 *jrt.String = jrt.Intern("arbace.go.check.decl$group_QMARK_")

var Lit_187 *jrt.String = jrt.Intern("arbace.go.check.decl$group_specs")

var Lit_188 *jrt.String = jrt.Intern("arbace.go.check.decl$target_list")

var Lit_189 *jrt.String = jrt.Intern("arbace.go.check.decl$init_list")

var Lit_190 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_const")

var Lit_191 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var")

var Lit_192 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_type")

var Lit_193 *jrt.String = jrt.Intern("arbace.go.check.decl$recv_base")

var Lit_194 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_func")

var Lit_195 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_file_BANG_")

var Lit_196 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_method_bases_BANG_")

var Lit_197 *jrt.String = jrt.Intern("arbace.go.check.decl$first_in_src")

var Lit_198 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_error_BANG_")

var Lit_199 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_cycle_QMARK_")

var Lit_200 *jrt.String = jrt.Intern("arbace.go.check.decl$with_decl")

var Lit_201 *jrt.String = jrt.Intern("arbace.go.check.decl$run_later_BANG_")

var Lit_202 *jrt.String = jrt.Intern("arbace.go.check.decl$verify_val_BANG_")

var Lit_203 *jrt.String = jrt.Intern("arbace.go.check.decl$const_decl_BANG_")

var Lit_204 *jrt.String = jrt.Intern("arbace.go.check.decl$var_decl_BANG_")

var Lit_205 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_")

var Lit_206 *jrt.String = jrt.Intern("arbace.go.check.decl$func_sig_BANG_")

var Lit_207 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_")

var Lit_208 *jrt.String = jrt.Intern("arbace.go.check.decl$direct_cycles_BANG_")

var Lit_209 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_named_BANG_")

var Lit_210 *jrt.String = jrt.Intern("arbace.go.check.decl$method_data_BANG_")

var Lit_211 *jrt.String = jrt.Intern("arbace.go.check.decl$check_body_BANG_")

var Lit_212 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order")

var Lit_213 *jrt.String = jrt.Intern("arbace.go.check.decl$find_path")

var Lit_214 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_")

var Lit_215 *jrt.String = jrt.Intern("arbace.go.check.decl$import_name")

var Lit_216 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_imports_BANG_")

var Lit_217 *jrt.String = jrt.Intern("arbace.go.check.decl$file_scope_conflicts_BANG_")

var Lit_218 *jrt.String = jrt.Intern("arbace.go.check.decl$unused_imports_BANG_")
