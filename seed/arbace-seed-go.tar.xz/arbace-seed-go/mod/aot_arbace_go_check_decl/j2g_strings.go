//line j2g_strings.ae:1
package aot_arbace_go_check_decl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,ekn5,referyn1,oyn5,oset!yn4,err!yn6,error!yn20,arbace.go.check.codeyn4,codeyn11,arbace.corekn3,dockn5,targskn6,originkn4,elsekn3,mapkn4,chankn7,pointerkn6,structkn5,arraykn4,typekn4,funckn9,interfacekn5,tuplekn5,slicekn7,invalidkn7,tparamskn3,objkn4,namekn3,pkgkn8,pkg-namekn15,NotAGenericTypekn17,WrongTypeArgCountkn5,substkn10,lazy-underkn10,underlyingkn2,idkn4,depskn4,refskn8,verifiedkn5,scopekn10,file-scopekn4,langkn5,fn-idkn4,filekn4,kindkn4,pathkn9,pkg-levelkn4,linekn4,declkn5,colorkn5,whitekn4,objskn13,DuplicateDeclkn3,tagkn3,valkn5,initskn15,MissingInitExprkn16,WrongAssignCountkn5,constkn4,formkn4,speckn4,iotakn4,initkn6,ninitskn6,nnameskn9,inheritedkn3,varkn5,multikn8,has-initkn3,lhskn11,type-paramskn9,type-formkn5,aliaskn13,tparams-countyn1,*kn9,sig-formskn6,methodkn9,recv-formkn4,basekn3,ptrkn12,generic-recvkn8,ptr-recvkn7,generickn11,InvalidRecvkn7,methodskn15,InvalidInitDeclkn15,InvalidMainDeclkn5,declskn17,InvalidSyntaxTreekn10,decl-orderkn16,InvalidDeclCyclekn5,flagskn11,unsupportedks19,arbace.go.check.env11,unsupportedkn16,unsupported-lineks19,arbace.go.check.env4,linekn5,laterkn5,blockkn5,indexkn6,tparamkn9,annotatedkn7,unknownkn8,constantkn4,modekn16,InvalidConstTypekn16,InvalidConstInitkn4,treekn2,opkn10,const-declkn5,valuekn8,var-declkn8,var-initkn3,rhsyn1,_kn15,generic-invalidkn9,resolvingkn23,DuplicateFieldAndMethodkn15,DuplicateMethodkn10,recv-namedkn6,bodieskn14,InvalidInitSigkn3,sigkn6,paramskn7,resultskn4,bodykn5,namedkn4,recvkn2,cxkn6,externkn5,blackkn4,greykn16,InvalidInitCyclekn7,importskn12,BrokenImportkn8,importedkn3,dotkn13,scope-entrieskn5,nameskn11,import-objskn11,dot-importskn4,dotskn4,usedkn12,UnusedImportv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V5,R7,R1,R8,R9,V4,R10,R11,R12,R13,V3,R14,R1,R15,v11,arbace.core5,referR16,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn20,arbace.go.check.declm2,R17,s252,goi's checker: a package's declarations (doc/go/GOI-SPEC.md §3.4, §3.6, §3.7), after\n  go/types' resolver.go (collectObjects, packageObjects), decl.go (objDecl and its colouring,\n  constDecl, varDecl, typeDecl, funcDecl), validtype.go and initorder.go.v11,arbace.core6,empty?v11,arbace.core8,keyword?v21,arbace.go.check.types7,tparam?v21,arbace.go.check.types6,named?v21,arbace.go.check.types4,infov11,arbace.core3,seqR18,v11,arbace.core4,mapvv20,arbace.go.check.decl5,substv20,arbace.go.check.decl11,instantiateR19,R20,R21,R22,R23,R24,R25,v11,arbace.core6,updateR26,R27,R28,R29,v11,arbace.core4,intoV1,R29,v11,arbace.core3,mapv11,arbace.core4,restv21,arbace.go.check.types12,sort-methodsR30,v11,arbace.core3,notR31,R32,R33,v20,arbace.go.check.decl9,obj-decl!v11,arbace.core4,not=v20,arbace.go.check.decl9,instancesv21,arbace.go.check.types9,new-namedv11,arbace.core5,assocv11,arbace.core11,select-keysV4,R33,R34,R35,R36,v11,arbace.core6,zipmapv19,arbace.go.check.env8,generic!v19,arbace.go.check.env4,err!R37,v21,arbace.go.check.types8,type-strR38,R34,v21,arbace.go.check.types12,update-info!R39,R40,v21,arbace.go.check.types5,underR41,v21,arbace.go.check.types10,deref-typev19,arbace.go.check.env1,ov11,arbace.core9,volatile!R42,v21,arbace.go.check.types7,next-idR43,R44,R45,R46,R47,R48,R49,R50,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstv19,arbace.go.check.env3,objv11,arbace.core5,mergeR51,R35,v19,arbace.go.check.env5,*pkg*R52,R53,R54,v20,arbace.go.check.code5,flinev19,arbace.go.check.env6,*line*R55,R56,R57,R58,v20,arbace.go.check.decl5,*ctx*v19,arbace.go.check.env9,scope-getR59,v19,arbace.go.check.env10,scope-put!v11,arbace.core7,string?v11,arbace.core6,every?v11,arbace.core7,vector?v11,arbace.core3,vecv20,arbace.go.check.code9,head-namev20,arbace.go.check.decl6,group?v20,arbace.go.check.decl11,group-specsv20,arbace.go.check.decl11,target-listv11,arbace.core4,someR60,v11,arbace.core9,contains?R61,v11,arbace.core5,some?v20,arbace.go.check.decl9,init-listR62,R63,v11,arbace.core11,map-indexedv11,arbace.core6,vectorv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstR64,v20,arbace.go.check.code10,ident-namev20,arbace.go.check.decl8,new-declR65,R66,R67,R68,R69,R70,R71,R72,v20,arbace.go.check.decl7,pkg-objv20,arbace.go.check.decl12,declare-pkg!v11,arbace.core10,chunk-restR73,R74,R75,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core19,pop-thread-bindingsR76,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapR77,R78,R79,R80,v11,arbace.core6,secondv19,arbace.go.check.env5,oset!R36,v11,arbace.core7,symbol?v20,arbace.go.check.code6,go-id?v11,arbace.core4,seq?R81,v11,arbace.core4,namev11,arbace.core9,namespacev11,arbace.core4,dropl2,v20,arbace.go.check.decl9,recv-baseR82,R83,R84,R85,R86,R87,R88,R89,R90,v20,arbace.go.check.code8,expr-strR91,v11,arbace.core4,fnilR92,R93,R94,v19,arbace.go.check.env8,*gofile*v20,arbace.go.check.decl12,collect-funcv20,arbace.go.check.decl11,collect-varv20,arbace.go.check.decl12,collect-typeR95,v20,arbace.go.check.decl13,collect-constR81,v11,arbace.core7,vreset!v11,arbace.core6,reducev11,arbace.core7,sort-byR96,v19,arbace.go.check.env6,error!R97,v20,arbace.go.check.decl6,*path*v11,arbace.core6,subvecv11,arbace.core6,filterS2,R65,R73,v20,arbace.go.check.decl12,cycle-error!v19,arbace.go.check.env6,*decl*v20,arbace.go.check.code8,cx-flagsR98,v19,arbace.go.check.env12,unsupported?R99,R100,v11,arbace.core7,ex-dataR101,R102,R103,v20,arbace.go.check.decl9,with-declv19,arbace.go.check.env5,scopeR104,v21,arbace.go.check.types10,new-tparamR105,R106,v20,arbace.go.check.code10,val-equal?v19,arbace.go.check.env9,verified!v19,arbace.go.check.env17,annotation-error!v11,arbace.core6,pr-strv20,arbace.go.check.code12,val-form-strR107,R108,v20,arbace.go.check.decl7,file-cxv20,arbace.go.check.code7,typexprv21,arbace.go.check.types6,valid?v21,arbace.go.check.types11,const-type?v20,arbace.go.check.code9,val-constv20,arbace.go.check.code4,exprv20,arbace.go.check.code8,invalid?R109,R110,v20,arbace.go.check.code10,assignmentv20,arbace.go.check.decl11,verify-val!R111,R112,v20,arbace.go.check.code11,operand-strR113,R114,R115,R116,R117,v20,arbace.go.check.code10,rhs-valuesR118,R119,v20,arbace.go.check.code8,init-varR120,R121,v20,arbace.go.check.decl12,tparam-scopeR122,v11,arbace.core3,setv21,arbace.go.check.types10,methods-ofR123,v20,arbace.go.check.decl11,valid-type!v21,arbace.go.check.types8,pointer?v21,arbace.go.check.types10,interface?R124,R125,R81,v20,arbace.go.check.code9,signatureR126,R127,R128,R129,R130,R131,R132,R133,R134,R135,R136,R137,v20,arbace.go.check.decl12,valid-cycle?v20,arbace.go.check.decl9,func-sig!v20,arbace.go.check.decl11,const-decl!v20,arbace.go.check.decl10,type-decl!v11,arbace.core6,removev20,arbace.go.check.decl9,var-decl!S2,R65,R73,v20,arbace.go.check.decl15,instance-under!v21,arbace.go.check.types9,exported?v20,arbace.go.check.code9,func-bodyS3,R27,R65,R73,S3,R27,R65,R73,v11,arbace.core5,applyv11,arbace.core7,min-keyv11,arbace.core4,disjv20,arbace.go.check.decl13,cycle-report!v11,arbace.core4,peekv11,arbace.core3,popR138,R139,v11,arbace.core3,strR140,R141,R142,R143,R144,R145,R146,R147,R148,R149,v11,arbace.core6,format")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.decl$check_body_BANG_$fn__1368000355")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_const$fn__1368000058")

var Lit_3 *jrt.String = jrt.Intern("missing init expr for const declaration")

var Lit_4 *jrt.String = jrt.Intern("missing init expr for %s")

var Lit_5 *jrt.String = jrt.Intern("extra init expr")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_file_BANG_$fn__1368000196")

var Lit_7 *jrt.String = jrt.Intern("go/func")

var Lit_8 *jrt.String = jrt.Intern("go/var")

var Lit_9 *jrt.String = jrt.Intern("go/type")

var Lit_10 *jrt.String = jrt.Intern("go/directive")

var Lit_11 *jrt.String = jrt.Intern("go/const")

var Lit_12 *jrt.String = jrt.Intern("go/method")

var Lit_13 *jrt.String = jrt.Intern("not a declaration: %s")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_file_BANG_$fn__1368000200")

var Lit_15 *jrt.String = jrt.Intern("invalid receiver type %s")

var Lit_16 *jrt.String = jrt.Intern("_")

var Lit_17 *jrt.String = jrt.Intern("init")

var Lit_18 *jrt.String = jrt.Intern("func init must have no type parameters")

var Lit_19 *jrt.String = jrt.Intern("main")

var Lit_20 *jrt.String = jrt.Intern("func main must have no type parameters")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_type$fn__1368000159")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000079")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000099")

var Lit_24 *jrt.String = jrt.Intern("zero")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000101__1368000105")

var Lit_26 *jrt.String = jrt.Intern("assignment mismatch: %d variables but %d values")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000120")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000140")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000142__1368000146")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000079$fn__1368000080")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000079$iter__1368000082__1368000086")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000079$iter__1368000082__1368000086$fn__1368000087")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000079$iter__1368000082__1368000086$fn__1368000087$fn__1368000088")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000120$fn__1368000121")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000120$iter__1368000123__1368000127")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000120$iter__1368000123__1368000127$fn__1368000128")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$fn__1368000120$iter__1368000123__1368000127$fn__1368000128$fn__1368000129")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000101__1368000105$fn__1368000106")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000101__1368000105$fn__1368000106$fn__1368000107")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000142__1368000146$fn__1368000147")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var$iter__1368000142__1368000146$fn__1368000147$fn__1368000148")

var Lit_42 *jrt.String = jrt.Intern("invalid constant type %s")

var Lit_43 *jrt.String = jrt.Intern("%s is not constant")

var Lit_44 *jrt.String = jrt.Intern("constant declaration")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_error_BANG_$fn__1368000215")

var Lit_46 *jrt.String = jrt.Intern("invalid recursive type: ")

var Lit_47 *jrt.String = jrt.Intern(" refers to itself")

var Lit_48 *jrt.String = jrt.Intern("invalid recursive type ")

var Lit_49 *jrt.String = jrt.Intern("invalid cycle in declaration: ")

var Lit_50 *jrt.String = jrt.Intern("invalid cycle in declaration of ")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_$fn__1368000448")

var Lit_52 *jrt.String = jrt.Intern("initialization cycle: ")

var Lit_53 *jrt.String = jrt.Intern("initialization cycle for ")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_$fn__1368000448$fn__1368000452")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_$fn__1368000448$fn__1368000454")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_$fn__1368000448$fn__1368000456")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_imports_BANG_$fn__1368000468")

var Lit_58 *jrt.String = jrt.Intern("could not import %s (no forms)")

var Lit_59 *jrt.String = jrt.Intern(".")

var Lit_60 *jrt.String = jrt.Intern("%s redeclared in this block")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_imports_BANG_$fn__1368000493")

var Lit_62 *jrt.String = jrt.Intern("cannot define new methods on non-local type %s")

var Lit_63 *jrt.String = jrt.Intern("func init must have no arguments and no return values")

var Lit_64 *jrt.String = jrt.Intern("func main must have no arguments and no return values")

var Lit_65 *jrt.String = jrt.Intern("values")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$deps_of__1368000363")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000367")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000369")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$add_BANG___1368000371")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000377")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000379")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000393")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000395")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000433")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$fn__1368000439")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order$deps_of__1368000363$fn__1368000364")

var Lit_77 *jrt.String = jrt.Intern("%s is not a generic type")

var Lit_78 *jrt.String = jrt.Intern("%s type arguments for type %s: have %d, want %d")

var Lit_79 *jrt.String = jrt.Intern("not enough")

var Lit_80 *jrt.String = jrt.Intern("too many")

var Lit_81 *jrt.String = jrt.Intern("get")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.check.decl$instantiate$fn__1368000032")

var Lit_83 *jrt.String = jrt.Intern("putIfAbsent")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000330")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000333")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000333$fn__1368000334")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000333$fn__1368000334$fn__1368000336")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_$fn__1368000333$fn__1368000334$fn__1368000338")

var Lit_89 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_method_bases_BANG_$base__1368000205")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_method_bases_BANG_$fn__1368000208")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.check.decl$run_later_BANG_$fn__1368000227")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000018")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000021")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000023")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000025")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000027")

var Lit_98 *jrt.String = jrt.Intern("arbace.go.check.decl$subst$fn__1368000029")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.check.decl$tparam_scope$fn__1368000234")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000280")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000282")

var Lit_102 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000288")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000290")

var Lit_104 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000292")

var Lit_105 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000294")

var Lit_106 *jrt.String = jrt.Intern("invalid receiver type ")

var Lit_107 *jrt.String = jrt.Intern(" (pointer or interface type)")

var Lit_108 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000294$fn__1368000299")

var Lit_109 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_$fn__1368000294$fn__1368000301")

var Lit_110 *jrt.String = jrt.Intern("field and method with the same name ")

var Lit_111 *jrt.String = jrt.Intern("\"%s\" imported as %s and not used")

var Lit_112 *jrt.String = jrt.Intern("\"%s\" imported and not used")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_cycle_QMARK_$fn__1368000221")

var Lit_114 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_cycle_QMARK_$fn__1368000223")

var Lit_115 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_type_BANG_$walk__1368000263")

var Lit_116 *jrt.String = jrt.Intern("invalid recursive type: %s refers to itself")

var Lit_117 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_type_BANG_$walk__1368000263$fn__1368000264")

var Lit_118 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_type_BANG_$walk__1368000263$fn__1368000267")

var Lit_119 *jrt.String = jrt.Intern("arbace.go.check.decl$var_decl_BANG_$fn__1368000258")

var Lit_120 *jrt.String = jrt.Intern("lit")

var Lit_121 *jrt.String = jrt.Intern("variable declaration")

var Lit_122 *jrt.String = jrt.Intern(":val")

var Lit_123 *jrt.String = jrt.Intern("none")

var Lit_124 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn8,arglistsyn2,tyyn1,mkn7,privateyn1,fyn1,gyn5,targsyn2,ntyn4,recvyn1,dkn7,dynamicyn2,fiyn4,kindyn2,nmyn4,formyn4,declyn1,&kn2,asyn4,moreyn1,xyn4,argsyn1,tyn1,iyn2,rfyn7,method?yn5,cycleyn2,cxyn3,tpsyn2,nfyn1,nyn4,objsyn4,succyn1,pyn7,resolvev11,arbace.core5,in-nsMyn20,arbace.go.check.declm2,R0,s252,goi's checker: a package's declarations (doc/go/GOI-SPEC.md §3.4, §3.6, §3.7), after\n  go/types' resolver.go (collectObjects, packageObjects), decl.go (objDecl and its colouring,\n  constDecl, varDecl, typeDecl, funcDecl), validtype.go and initorder.go.m2,R0,s252,goi's checker: a package's declarations (doc/go/GOI-SPEC.md §3.4, §3.6, §3.7), after\n  go/types' resolver.go (collectObjects, packageObjects), decl.go (objDecl and its colouring,\n  constDecl, varDecl, typeDecl, funcDecl), validtype.go and initorder.go.R1,v20,arbace.go.check.decl5,substm8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,instantiatem8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl13,cycle-report!m8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,obj-decl!m8,R2,TR3,i13,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L1,V2,R7,R8,R0,s51,Type ty with the type parameters of map m replaced.R3,i15,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,instancesm8,R9,TR3,i40,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L1,V3,R10,R11,R12,R0,s87,The instance of generic named type g with type arguments targs (one per argument list).R3,i42,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl15,instance-under!m12,R9,TR6,L1,V1,R13,R0,s80,Completes an instance's underlying type (lazily: its origin may be in progress).R3,i65,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,subst-methodm10,R6,L1,V2,R14,R15,R0,s162,A method's data seen through recv, an instance of its generic type: its signature with the\n  receiver's type parameters replaced by the instance's type arguments.R3,i74,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl5,*ctx*m10,R16,TR3,i89,R4,i1,R5,s23,arbace/go/check/decl.aeR0,s167,The package's checking context: {:objs (volatile vector of objects in source order),\n  :methods (volatile {base-name [method-objs]}), :later (volatile vector of fns)}.v20,arbace.go.check.decl8,new-declm10,R9,TR6,L1,V1,R8,R3,i94,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl7,file-cxm12,R9,TR6,L1,V1,R17,R0,s54,The context of a package-level declaration in file fi.R3,i97,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl7,pkg-objm10,R9,TR6,L1,V7,R18,R19,R20,R17,R21,R22,m2,R23,R24,R3,i103,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,declare-pkg!m10,R9,TR6,L1,V3,R25,R19,R20,R3,i108,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl6,group?m10,R9,TR6,L1,V1,R26,R3,i116,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,group-specsm10,R9,TR6,L1,V1,R26,R3,i120,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,target-listm10,R9,TR6,L1,V1,R27,R3,i122,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,init-listm10,R9,TR6,L1,V1,R28,R3,i123,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl13,collect-constm10,R9,TR6,L1,V2,R10,R17,R3,i125,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,collect-varm10,R9,TR6,L1,V2,R10,R17,R3,i156,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,collect-typem10,R9,TR6,L1,V2,R10,R17,R3,i182,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,recv-basem12,R9,TR6,L1,V1,R29,R0,s134,The receiver base type name of a method's receiver form, and whether the receiver type\n  has type arguments (a generic type's method).R3,i201,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,collect-funcm10,R9,TR6,L1,V3,R10,R17,R30,R3,i212,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl13,collect-file!m10,R6,L1,V1,R17,R0,s65,Collects the package-level objects of a file's declaration forms.R3,i244,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl21,resolve-method-bases!m10,R6,L1,V0,R0,s108,go/types' resolveBaseTypeName: methods whose receiver names an alias go to the type the\n  alias chain names.R3,i259,R4,i1,R5,s23,arbace/go/check/decl.aem8,R2,TR3,i278,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl6,*path*m10,R16,TR3,i280,R4,i1,R5,s23,arbace/go/check/decl.aeR0,s47,The objects being declared (go/types' objPath).v20,arbace.go.check.decl12,cycle-error!m10,R9,TR6,L1,V1,R31,R3,i282,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,valid-cycle?m10,R9,TR6,L1,V1,R25,R3,i291,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,with-declm12,R9,TR6,L1,V2,R15,R10,R0,s77,Runs f with the declaration's context bound (its file, the decl for records).R3,i301,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,run-later!m10,R9,TR6,L1,V1,R15,R3,i314,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,tparam-scopem12,R9,TR6,L1,V2,R32,R33,R0,s108,A scope binding a generic declaration's type parameters to new type parameter types:\n  [scope tparam-types].R3,i322,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,verify-val!m12,R9,TR6,L1,V3,R34,R25,R35,R0,s57,Compares a package constant's value with its :val (§3.6).R3,i337,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,const-decl!m10,R9,TR6,L1,V2,R25,R15,R3,i349,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,var-decl!m10,R9,TR6,L1,V2,R25,R15,R3,i379,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,valid-type!m12,R9,TR6,L1,V2,R13,R20,R0,s100,go/types' validType: reports a named type that contains itself (through arrays and\n  struct fields).R3,i400,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,type-decl!m10,R9,TR6,L1,V2,R25,R15,R3,i421,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl9,func-sig!m12,R9,TR6,L1,V2,R25,R15,R0,s77,A function's or method's signature (funcDecl): its type set, the body queued.R3,i472,R4,i1,R5,s23,arbace/go/check/decl.aem10,R6,L1,V1,R25,R0,s83,Checks the declaration of package-level object x when not done (go/types' objDecl).R3,i518,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl14,resolve-named!m10,R6,L1,V1,R13,R0,s75,Completes a named type's declaration when its underlying type is asked for.R3,i551,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl12,method-data!m10,R6,L1,V1,R8,R0,s83,The data of a method object, its declaration checked: {:name :pkg :type :ptr-recv}.R3,i559,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,check-body!m8,R6,L1,V1,R25,R3,i568,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl10,init-orderm10,R6,L1,V1,R36,R0,s77,go/types' InitOrder: the initializers in order, each its vector of variables.R3,i582,R4,i1,R5,s23,arbace/go/check/decl.aem8,R6,L1,V2,R35,R37,R3,i625,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl11,import-namem10,R9,TR6,L1,V1,R38,R3,i644,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl16,declare-imports!m10,R6,L1,V2,R17,R39,R0,s81,The file scope's imports: package objects, dot imports. resolve: path -> package.R3,i646,R4,i1,R5,s23,arbace/go/check/decl.aev20,arbace.go.check.decl15,unused-imports!m8,R6,L1,V1,R17,R3,i673,R4,i1,R5,s23,arbace/go/check/decl.ae")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.check.decl$eval1368000004$loading__1927001464__auto____1368000005")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.check.decl$eval1368000008$fn__1368000009")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.check.decl$subst")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.check.decl$instantiate")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.check.decl$instance_under_BANG_")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.check.decl$subst_method")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.check.decl$new_decl")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.check.decl$file_cx")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.check.decl$pkg_obj")

var Lit_134 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_pkg_BANG_")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.check.decl$group_QMARK_")

var Lit_136 *jrt.String = jrt.Intern("arbace.go.check.decl$group_specs")

var Lit_137 *jrt.String = jrt.Intern("arbace.go.check.decl$target_list")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.check.decl$init_list")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_const")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_var")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_type")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.check.decl$recv_base")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_func")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.check.decl$collect_file_BANG_")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_method_bases_BANG_")

var Lit_146 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_error_BANG_")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_cycle_QMARK_")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.check.decl$with_decl")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.check.decl$run_later_BANG_")

var Lit_150 *jrt.String = jrt.Intern("arbace.go.check.decl$tparam_scope")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.check.decl$verify_val_BANG_")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.check.decl$const_decl_BANG_")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.check.decl$var_decl_BANG_")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.check.decl$valid_type_BANG_")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.check.decl$type_decl_BANG_")

var Lit_156 *jrt.String = jrt.Intern("arbace.go.check.decl$func_sig_BANG_")

var Lit_157 *jrt.String = jrt.Intern("arbace.go.check.decl$obj_decl_BANG_")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.check.decl$resolve_named_BANG_")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.check.decl$method_data_BANG_")

var Lit_160 *jrt.String = jrt.Intern("arbace.go.check.decl$check_body_BANG_")

var Lit_161 *jrt.String = jrt.Intern("arbace.go.check.decl$init_order")

var Lit_162 *jrt.String = jrt.Intern("arbace.go.check.decl$cycle_report_BANG_")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.check.decl$import_name")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.check.decl$declare_imports_BANG_")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.check.decl$unused_imports_BANG_")
