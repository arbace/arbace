//line aot_arbace_go_check_decl__init.ae:1
package aot_arbace_go_check_decl

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_decl__init_A_Unit0__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_decl__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_decl__init_A_const_1) }
//line :1:1
func A_arbace_go_check_decl__init_A_Unit1__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_decl__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_decl__init_A_Unit2__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_decl_eval1368000004_loading__1927001464__auto____1368000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_decl_eval1368000004_loading__1927001464__auto____1368000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_go_check_decl_eval1368000004_loading__1927001464__auto____1368000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_decl__init_A_Unit3__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_decl__init_A_const_1)).Equals_O__Z(A_arbace_go_check_decl__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_decl_eval1368000008_fn__1368000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_decl_eval1368000008_fn__1368000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_go_check_decl_eval1368000008_fn__1368000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_check_decl__init_A_Load__O() any { A_arbace_go_check_decl__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_decl__init_A_Unit0__O(); A_arbace_go_check_decl__init_A_Unit1__O(); A_arbace_go_check_decl__init_A_Unit2__O(); A_arbace_go_check_decl__init_A_Unit3__O(); A_arbace_go_check_decl__init_A_Unit4__O(); A_arbace_go_check_decl__init_A_Unit5__O(); A_arbace_go_check_decl__init_A_Unit6__O(); A_arbace_go_check_decl__init_A_Unit7__O(); A_arbace_go_check_decl__init_A_Unit8__O(); A_arbace_go_check_decl__init_A_Unit9__O(); A_arbace_go_check_decl__init_A_Unit10__O(); A_arbace_go_check_decl__init_A_Unit11__O(); A_arbace_go_check_decl__init_A_Unit12__O(); A_arbace_go_check_decl__init_A_Unit13__O(); A_arbace_go_check_decl__init_A_Unit14__O(); A_arbace_go_check_decl__init_A_Unit15__O(); A_arbace_go_check_decl__init_A_Unit16__O(); A_arbace_go_check_decl__init_A_Unit17__O(); A_arbace_go_check_decl__init_A_Unit18__O(); A_arbace_go_check_decl__init_A_Unit19__O(); A_arbace_go_check_decl__init_A_Unit20__O(); A_arbace_go_check_decl__init_A_Unit21__O(); A_arbace_go_check_decl__init_A_Unit22__O(); A_arbace_go_check_decl__init_A_Unit23__O(); A_arbace_go_check_decl__init_A_Unit24__O(); A_arbace_go_check_decl__init_A_Unit25__O(); A_arbace_go_check_decl__init_A_Unit26__O(); A_arbace_go_check_decl__init_A_Unit27__O(); A_arbace_go_check_decl__init_A_Unit28__O(); A_arbace_go_check_decl__init_A_Unit29__O(); A_arbace_go_check_decl__init_A_Unit30__O(); A_arbace_go_check_decl__init_A_Unit31__O(); A_arbace_go_check_decl__init_A_Unit32__O(); A_arbace_go_check_decl__init_A_Unit33__O(); A_arbace_go_check_decl__init_A_Unit34__O(); A_arbace_go_check_decl__init_A_Unit35__O(); A_arbace_go_check_decl__init_A_Unit36__O(); A_arbace_go_check_decl__init_A_Unit37__O(); A_arbace_go_check_decl__init_A_Unit38__O(); A_arbace_go_check_decl__init_A_Unit39__O(); A_arbace_go_check_decl__init_A_Unit40__O(); A_arbace_go_check_decl__init_A_Unit41__O(); A_arbace_go_check_decl__init_A_Unit42__O(); A_arbace_go_check_decl__init_A_Unit43__O(); A_arbace_go_check_decl__init_A_Unit44__O(); A_arbace_go_check_decl__init_A_Unit45__O(); A_arbace_go_check_decl__init_A_Unit46__O(); A_arbace_go_check_decl__init_A_Unit47__O(); A_arbace_go_check_decl__init_A_Unit48__O(); A_arbace_go_check_decl__init_A_Unit49__O(); A_arbace_go_check_decl__init_A_Unit50__O(); A_arbace_go_check_decl__init_A_Unit51__O(); A_arbace_go_check_decl__init_A_Unit52__O(); A_arbace_go_check_decl__init_A_Unit53__O(); A_arbace_go_check_decl__init_A_Unit54__O(); A_arbace_go_check_decl__init_A_Unit55__O(); A_arbace_go_check_decl__init_A_Unit56__O(); A_arbace_go_check_decl__init_A_Unit57__O(); A_arbace_go_check_decl__init_A_Unit58__O(); A_arbace_go_check_decl__init_A_Unit59__O(); A_arbace_go_check_decl__init_A_Unit60__O(); A_arbace_go_check_decl__init_A_Unit61__O(); A_arbace_go_check_decl__init_A_Unit62__O(); A_arbace_go_check_decl__init_A_Unit63__O(); A_arbace_go_check_decl__init_A_Unit64__O(); A_arbace_go_check_decl__init_A_Unit65__O(); A_arbace_go_check_decl__init_A_Unit66__O(); A_arbace_go_check_decl__init_A_Unit67__O(); A_arbace_go_check_decl__init_A_Unit68__O(); A_arbace_go_check_decl__init_A_Unit69__O(); A_arbace_go_check_decl__init_A_Unit70__O(); A_arbace_go_check_decl__init_A_Unit71__O(); return nil }







func A_arbace_go_check_decl__init_A_Unit4__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_5)); return A_arbace_go_check_decl__init_A_const_4 }
//line :13:1
func A_arbace_go_check_decl__init_A_Unit5__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_7)); return A_arbace_go_check_decl__init_A_const_6 }
//line :13:1
func A_arbace_go_check_decl__init_A_Unit6__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_9)); return A_arbace_go_check_decl__init_A_const_8 }
//line :13:1
func A_arbace_go_check_decl__init_A_Unit7__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_11)); return A_arbace_go_check_decl__init_A_const_10 }
//line :13:1
func A_arbace_go_check_decl__init_A_Unit8__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_13)); return A_arbace_go_check_decl__init_A_const_12 }
//line :13:1
func A_arbace_go_check_decl__init_A_Unit9__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_15)); return A_arbace_go_check_decl__init_A_const_14 }
//line :13:1
func A_arbace_go_check_decl__init_A_Unit10__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_17)); return A_arbace_go_check_decl__init_A_const_16 }

func A_arbace_go_check_decl__init_A_Unit11__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_4; var tmp2 any = A_arbace_go_check_decl_subst_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_decl_subst_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_172, false); A_arbace_go_check_decl_subst_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_18)); return A_arbace_go_check_decl__init_A_const_4 }

























func A_arbace_go_check_decl__init_A_Unit12__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_6; var tmp2 any = A_arbace_go_check_decl_subst_terms_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_decl_subst_terms_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_go_check_decl_subst_terms_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_19)); return A_arbace_go_check_decl__init_A_const_6 }


func A_arbace_go_check_decl__init_A_Unit13__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_8; var tmp2 any = A_arbace_go_check_decl_subst_tset_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_decl_subst_tset_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_go_check_decl_subst_tset_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_20)); return A_arbace_go_check_decl__init_A_const_8 }


func A_arbace_go_check_decl__init_A_Unit14__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_21; var tmp2 any = A_arbace_go_check_decl_later_BANG__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_decl_later_BANG__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_go_check_decl_later_BANG__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_22)); return A_arbace_go_check_decl__init_A_const_21 }




func A_arbace_go_check_decl__init_A_Unit15__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_23; var tmp2 any = A_arbace_go_check_decl_verify_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_decl_verify_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_go_check_decl_verify_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_24)); return A_arbace_go_check_decl__init_A_const_23 }


















func A_arbace_go_check_decl__init_A_Unit16__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); A_arbace_go_check_decl__init_A_const_25.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_26)); return A_arbace_go_check_decl__init_A_const_25.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_decl__init_A_Unit17__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_27; var tmp2 any = A_arbace_go_check_decl_mono_canon_BANG__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_decl_mono_canon_BANG__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_177, false); A_arbace_go_check_decl_mono_canon_BANG__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_28)); return A_arbace_go_check_decl__init_A_const_27 }




func A_arbace_go_check_decl__init_A_Unit18__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_29; var tmp2 any = A_arbace_go_check_decl_mono_vertex_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_decl_mono_vertex_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_go_check_decl_mono_vertex_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_30)); return A_arbace_go_check_decl__init_A_const_29 }






func A_arbace_go_check_decl__init_A_Unit19__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_31; var tmp2 any = A_arbace_go_check_decl_mono_edge_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_decl_mono_edge_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_go_check_decl_mono_edge_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_32)); return A_arbace_go_check_decl__init_A_const_31 }


func A_arbace_go_check_decl__init_A_Unit20__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_33; var tmp2 any = A_arbace_go_check_decl_tparam_vertex_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_decl_tparam_vertex_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_go_check_decl_tparam_vertex_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_34)); return A_arbace_go_check_decl__init_A_const_33 }




func A_arbace_go_check_decl__init_A_Unit21__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_35; var tmp2 any = A_arbace_go_check_decl_local_named_vertex_BANG__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_decl_local_named_vertex_BANG__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_go_check_decl_local_named_vertex_BANG__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_36)); return A_arbace_go_check_decl__init_A_const_35 }













func A_arbace_go_check_decl__init_A_Unit22__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_37; var tmp2 any = A_arbace_go_check_decl_mono_assign_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_decl_mono_assign_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_go_check_decl_mono_assign_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_38)); return A_arbace_go_check_decl__init_A_const_37 }
























func A_arbace_go_check_decl__init_A_Unit23__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(136, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_39; var tmp2 any = A_arbace_go_check_decl_mono_record_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_decl_mono_record_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_go_check_decl_mono_record_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_40)); return A_arbace_go_check_decl__init_A_const_39 }









func A_arbace_go_check_decl__init_A_Unit24__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_41; var tmp2 any = A_arbace_go_check_decl_monomorph_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_decl_monomorph_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_go_check_decl_monomorph_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_42)); return A_arbace_go_check_decl__init_A_const_41 }







































func A_arbace_go_check_decl__init_A_Unit25__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_16; var tmp2 any = A_arbace_go_check_decl_verify_later_BANG__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_decl_verify_later_BANG__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_185, false); A_arbace_go_check_decl_verify_later_BANG__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_43)); return A_arbace_go_check_decl__init_A_const_16 }









func A_arbace_go_check_decl__init_A_Unit26__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_44; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_go_check_decl__init_A_const_44; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_45)); return A_arbace_go_check_decl__init_A_const_44 }

func A_arbace_go_check_decl__init_A_Unit27__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_10; var tmp2 any = A_arbace_go_check_decl_instantiate_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_decl_instantiate_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_186, false); A_arbace_go_check_decl_instantiate_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_46)); return A_arbace_go_check_decl__init_A_const_10 }

































func A_arbace_go_check_decl__init_A_Unit28__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_47; var tmp2 any = A_arbace_go_check_decl_instance_under_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_decl_instance_under_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_187, false); A_arbace_go_check_decl_instance_under_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_48)); return A_arbace_go_check_decl__init_A_const_47 }








func A_arbace_go_check_decl__init_A_Unit29__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_49; var tmp2 any = A_arbace_go_check_decl_subst_method_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_decl_subst_method_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_188, false); A_arbace_go_check_decl_subst_method_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_50)); return A_arbace_go_check_decl__init_A_const_49 }














func A_arbace_go_check_decl__init_A_Unit30__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); A_arbace_go_check_decl__init_A_const_51.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_51; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_52)); return A_arbace_go_check_decl__init_A_const_51.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_decl__init_A_Unit31__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_53; var tmp2 any = A_arbace_go_check_decl_new_decl_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_decl_new_decl_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_189, false); A_arbace_go_check_decl_new_decl_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_54)); return A_arbace_go_check_decl__init_A_const_53 }


func A_arbace_go_check_decl__init_A_Unit32__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_55; var tmp2 any = A_arbace_go_check_decl_file_cx_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_decl_file_cx_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_go_check_decl_file_cx_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_56)); return A_arbace_go_check_decl__init_A_const_55 }





func A_arbace_go_check_decl__init_A_Unit33__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_57; var tmp2 any = A_arbace_go_check_decl_pkg_obj_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_decl_pkg_obj_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, true); A_arbace_go_check_decl_pkg_obj_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 5)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_58)); return A_arbace_go_check_decl__init_A_const_57 }




func A_arbace_go_check_decl__init_A_Unit34__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_59; var tmp2 any = A_arbace_go_check_decl_declare_pkg_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_decl_declare_pkg_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_192, false); A_arbace_go_check_decl_declare_pkg_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_60)); return A_arbace_go_check_decl__init_A_const_59 }













func A_arbace_go_check_decl__init_A_Unit35__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(289, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_61; var tmp2 any = A_arbace_go_check_decl_group_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_check_decl_group_QMARK__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, false); A_arbace_go_check_decl_group_QMARK__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_62)); return A_arbace_go_check_decl__init_A_const_61 }



func A_arbace_go_check_decl__init_A_Unit36__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(293, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_63; var tmp2 any = A_arbace_go_check_decl_group_specs_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_decl_group_specs_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_194, false); A_arbace_go_check_decl_group_specs_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_64)); return A_arbace_go_check_decl__init_A_const_63 }

func A_arbace_go_check_decl__init_A_Unit37__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_65; var tmp2 any = A_arbace_go_check_decl_target_list_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_check_decl_target_list_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_195, false); A_arbace_go_check_decl_target_list_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_66)); return A_arbace_go_check_decl__init_A_const_65 }
func A_arbace_go_check_decl__init_A_Unit38__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(296, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_67; var tmp2 any = A_arbace_go_check_decl_init_list_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_decl_init_list_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_196, false); A_arbace_go_check_decl_init_list_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_68)); return A_arbace_go_check_decl__init_A_const_67 }

func A_arbace_go_check_decl__init_A_Unit39__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_69; var tmp2 any = A_arbace_go_check_decl_collect_const_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_check_decl_collect_const_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_197, false); A_arbace_go_check_decl_collect_const_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_70)); return A_arbace_go_check_decl__init_A_const_69 }

































func A_arbace_go_check_decl__init_A_Unit40__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(332, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_71; var tmp2 any = A_arbace_go_check_decl_collect_var_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_decl_collect_var_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_198, false); A_arbace_go_check_decl_collect_var_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_72)); return A_arbace_go_check_decl__init_A_const_71 }

























func A_arbace_go_check_decl__init_A_Unit41__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(358, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_73; var tmp2 any = A_arbace_go_check_decl_collect_type_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_decl_collect_type_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_199, false); A_arbace_go_check_decl_collect_type_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_74)); return A_arbace_go_check_decl__init_A_const_73 }




















func A_arbace_go_check_decl__init_A_Unit42__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_75; var tmp2 any = A_arbace_go_check_decl_recv_base_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_decl_recv_base_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_200, false); A_arbace_go_check_decl_recv_base_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_76)); return A_arbace_go_check_decl__init_A_const_75 }










func A_arbace_go_check_decl__init_A_Unit43__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(390, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_77; var tmp2 any = A_arbace_go_check_decl_collect_func_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_check_decl_collect_func_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_201, false); A_arbace_go_check_decl_collect_func_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_78)); return A_arbace_go_check_decl__init_A_const_77 }





































func A_arbace_go_check_decl__init_A_Unit44__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(428, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_79; var tmp2 any = A_arbace_go_check_decl_collect_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_decl_collect_file_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_202, false); A_arbace_go_check_decl_collect_file_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_80)); return A_arbace_go_check_decl__init_A_const_79 }














func A_arbace_go_check_decl__init_A_Unit45__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(443, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_81; var tmp2 any = A_arbace_go_check_decl_resolve_method_bases_BANG__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_203, false); A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_82)); return A_arbace_go_check_decl__init_A_const_81 }


















func A_arbace_go_check_decl__init_A_Unit46__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(462, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_83)); return A_arbace_go_check_decl__init_A_const_14 }

func A_arbace_go_check_decl__init_A_Unit47__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(464, 1); A_arbace_go_check_decl__init_A_const_84.BindRoot_O__V(lang.PersistentVector_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_85)); return A_arbace_go_check_decl__init_A_const_84.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_decl__init_A_Unit48__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(466, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_86; var tmp2 any = A_arbace_go_check_decl_first_in_src_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_decl_first_in_src_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_204, false); A_arbace_go_check_decl_first_in_src_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_87)); return A_arbace_go_check_decl__init_A_const_86 }





func A_arbace_go_check_decl__init_A_Unit49__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(472, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_88; var tmp2 any = A_arbace_go_check_decl_cycle_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_check_decl_cycle_error_BANG__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_205, false); A_arbace_go_check_decl_cycle_error_BANG__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_89)); return A_arbace_go_check_decl__init_A_const_88 }


func A_arbace_go_check_decl__init_A_Unit50__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_90; var tmp2 any = A_arbace_go_check_decl_valid_cycle_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_decl_valid_cycle_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_206, false); A_arbace_go_check_decl_valid_cycle_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_91)); return A_arbace_go_check_decl__init_A_const_90 }









func A_arbace_go_check_decl__init_A_Unit51__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(485, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_92; var tmp2 any = A_arbace_go_check_decl_with_decl_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_go_check_decl_with_decl_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_207, false); A_arbace_go_check_decl_with_decl_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_93)); return A_arbace_go_check_decl__init_A_const_92 }












func A_arbace_go_check_decl__init_A_Unit52__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(498, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_94; var tmp2 any = A_arbace_go_check_decl_run_later_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_decl_run_later_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_208, false); A_arbace_go_check_decl_run_later_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_95)); return A_arbace_go_check_decl__init_A_const_94 }







func A_arbace_go_check_decl__init_A_Unit53__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(506, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_96; var tmp2 any = A_arbace_go_check_decl_verify_val_BANG__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_check_decl_verify_val_BANG__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_209, false); A_arbace_go_check_decl_verify_val_BANG__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_97)); return A_arbace_go_check_decl__init_A_const_96 }











func A_arbace_go_check_decl__init_A_Unit54__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(518, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_98; var tmp2 any = A_arbace_go_check_decl_const_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_decl_const_decl_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_210, false); A_arbace_go_check_decl_const_decl_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_99)); return A_arbace_go_check_decl__init_A_const_98 }

































func A_arbace_go_check_decl__init_A_Unit55__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_100; var tmp2 any = A_arbace_go_check_decl_var_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_check_decl_var_decl_BANG__A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_211, false); A_arbace_go_check_decl_var_decl_BANG__A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_101)); return A_arbace_go_check_decl__init_A_const_100 }




















func A_arbace_go_check_decl__init_A_Unit56__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(573, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_102; var tmp2 any = A_arbace_go_check_decl_type_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_decl_type_decl_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_212, false); A_arbace_go_check_decl_type_decl_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_103)); return A_arbace_go_check_decl__init_A_const_102 }






















































func A_arbace_go_check_decl__init_A_Unit57__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(628, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_104; var tmp2 any = A_arbace_go_check_decl_func_sig_BANG__A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_decl_func_sig_BANG__A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_213, false); A_arbace_go_check_decl_func_sig_BANG__A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_105)); return A_arbace_go_check_decl__init_A_const_104 }



























































func A_arbace_go_check_decl__init_A_Unit58__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(688, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_14; var tmp2 any = A_arbace_go_check_decl_obj_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_decl_obj_decl_BANG__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_214, false); A_arbace_go_check_decl_obj_decl_BANG__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_106)); return A_arbace_go_check_decl__init_A_const_14 }


































func A_arbace_go_check_decl__init_A_Unit59__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(723, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_107; var tmp2 any = A_arbace_go_check_decl_direct_cycles_BANG__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_215, false); A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_108)); return A_arbace_go_check_decl__init_A_const_107 }




























func A_arbace_go_check_decl__init_A_Unit60__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(752, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_109; var tmp2 any = A_arbace_go_check_decl_resolve_named_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_decl_resolve_named_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_216, false); A_arbace_go_check_decl_resolve_named_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_110)); return A_arbace_go_check_decl__init_A_const_109 }







func A_arbace_go_check_decl__init_A_Unit61__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(760, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_111; var tmp2 any = A_arbace_go_check_decl_method_data_BANG__A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_go_check_decl_method_data_BANG__A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_217, false); A_arbace_go_check_decl_method_data_BANG__A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_112)); return A_arbace_go_check_decl__init_A_const_111 }








func A_arbace_go_check_decl__init_A_Unit62__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(769, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_113; var tmp2 any = A_arbace_go_check_decl_check_body_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_decl_check_body_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_218, false); A_arbace_go_check_decl_check_body_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_114)); return A_arbace_go_check_decl__init_A_const_113 }













func A_arbace_go_check_decl__init_A_Unit63__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(783, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_115; var tmp2 any = A_arbace_go_check_decl_init_order_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_go_check_decl_init_order_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_219, false); A_arbace_go_check_decl_init_order_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_116)); return A_arbace_go_check_decl__init_A_const_115 }



















































func A_arbace_go_check_decl__init_A_Unit64__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(835, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_117; var tmp2 any = A_arbace_go_check_decl_find_path_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_check_decl_find_path_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_220, false); A_arbace_go_check_decl_find_path_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_118)); return A_arbace_go_check_decl__init_A_const_117 }








func A_arbace_go_check_decl__init_A_Unit65__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(844, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_12; var tmp2 any = A_arbace_go_check_decl_cycle_report_BANG__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_go_check_decl_cycle_report_BANG__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_221, false); A_arbace_go_check_decl_cycle_report_BANG__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_119)); return A_arbace_go_check_decl__init_A_const_12 }



















func A_arbace_go_check_decl__init_A_Unit66__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(864, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_120; var tmp2 any = A_arbace_go_check_decl_import_name_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_check_decl_import_name_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_222, false); A_arbace_go_check_decl_import_name_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_121)); return A_arbace_go_check_decl__init_A_const_120 }

func A_arbace_go_check_decl__init_A_Unit67__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(866, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_122; var tmp2 any = A_arbace_go_check_decl_clean_path_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_go_check_decl_clean_path_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_223, false); A_arbace_go_check_decl_clean_path_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_123)); return A_arbace_go_check_decl__init_A_const_122 }















func A_arbace_go_check_decl__init_A_Unit68__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(882, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_124; var tmp2 any = A_arbace_go_check_decl_local_path_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_check_decl_local_path_QMARK__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_224, false); A_arbace_go_check_decl_local_path_QMARK__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_125)); return A_arbace_go_check_decl__init_A_const_124 }


func A_arbace_go_check_decl__init_A_Unit69__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(885, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_126; var tmp2 any = A_arbace_go_check_decl_declare_imports_BANG__A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_go_check_decl_declare_imports_BANG__A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_225, false); A_arbace_go_check_decl_declare_imports_BANG__A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_127)); return A_arbace_go_check_decl__init_A_const_126 }

































func A_arbace_go_check_decl__init_A_Unit70__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(919, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_128; var tmp2 any = A_arbace_go_check_decl_file_scope_conflicts_BANG__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_226, false); A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_129)); return A_arbace_go_check_decl__init_A_const_128 }
















func A_arbace_go_check_decl__init_A_Unit71__O() any { A_arbace_go_check_decl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(936, 1); var tmp1 *lang.Var = A_arbace_go_check_decl__init_A_const_130; var tmp2 any = A_arbace_go_check_decl_unused_imports_BANG__A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_check_decl_unused_imports_BANG__A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_227, false); A_arbace_go_check_decl_unused_imports_BANG__A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_decl__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_decl__init_A_const_131)); return A_arbace_go_check_decl__init_A_const_130 }



type A_arbace_go_check_decl__init_A struct{ jrt.Object }

var A_arbace_go_check_decl__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_decl__init_A_const_0 *lang.Var

var A_arbace_go_check_decl__init_A_const_1 any

var A_arbace_go_check_decl__init_A_const_2 any

var A_arbace_go_check_decl__init_A_const_3 any

var A_arbace_go_check_decl__init_A_const_4 *lang.Var

var A_arbace_go_check_decl__init_A_const_5 any

var A_arbace_go_check_decl__init_A_const_6 *lang.Var

var A_arbace_go_check_decl__init_A_const_7 any

var A_arbace_go_check_decl__init_A_const_8 *lang.Var

var A_arbace_go_check_decl__init_A_const_9 any

var A_arbace_go_check_decl__init_A_const_10 *lang.Var

var A_arbace_go_check_decl__init_A_const_11 any

var A_arbace_go_check_decl__init_A_const_12 *lang.Var

var A_arbace_go_check_decl__init_A_const_13 any

var A_arbace_go_check_decl__init_A_const_14 *lang.Var

var A_arbace_go_check_decl__init_A_const_15 any

var A_arbace_go_check_decl__init_A_const_16 *lang.Var

var A_arbace_go_check_decl__init_A_const_17 any

var A_arbace_go_check_decl__init_A_const_18 any

var A_arbace_go_check_decl__init_A_const_19 any

var A_arbace_go_check_decl__init_A_const_20 any

var A_arbace_go_check_decl__init_A_const_21 *lang.Var

var A_arbace_go_check_decl__init_A_const_22 any

var A_arbace_go_check_decl__init_A_const_23 *lang.Var

var A_arbace_go_check_decl__init_A_const_24 any

var A_arbace_go_check_decl__init_A_const_25 *lang.Var

var A_arbace_go_check_decl__init_A_const_26 any

var A_arbace_go_check_decl__init_A_const_27 *lang.Var

var A_arbace_go_check_decl__init_A_const_28 any

var A_arbace_go_check_decl__init_A_const_29 *lang.Var

var A_arbace_go_check_decl__init_A_const_30 any

var A_arbace_go_check_decl__init_A_const_31 *lang.Var

var A_arbace_go_check_decl__init_A_const_32 any

var A_arbace_go_check_decl__init_A_const_33 *lang.Var

var A_arbace_go_check_decl__init_A_const_34 any

var A_arbace_go_check_decl__init_A_const_35 *lang.Var

var A_arbace_go_check_decl__init_A_const_36 any

var A_arbace_go_check_decl__init_A_const_37 *lang.Var

var A_arbace_go_check_decl__init_A_const_38 any

var A_arbace_go_check_decl__init_A_const_39 *lang.Var

var A_arbace_go_check_decl__init_A_const_40 any

var A_arbace_go_check_decl__init_A_const_41 *lang.Var

var A_arbace_go_check_decl__init_A_const_42 any

var A_arbace_go_check_decl__init_A_const_43 any

var A_arbace_go_check_decl__init_A_const_44 *lang.Var

var A_arbace_go_check_decl__init_A_const_45 any

var A_arbace_go_check_decl__init_A_const_46 any

var A_arbace_go_check_decl__init_A_const_47 *lang.Var

var A_arbace_go_check_decl__init_A_const_48 any

var A_arbace_go_check_decl__init_A_const_49 *lang.Var

var A_arbace_go_check_decl__init_A_const_50 any

var A_arbace_go_check_decl__init_A_const_51 *lang.Var

var A_arbace_go_check_decl__init_A_const_52 any

var A_arbace_go_check_decl__init_A_const_53 *lang.Var

var A_arbace_go_check_decl__init_A_const_54 any

var A_arbace_go_check_decl__init_A_const_55 *lang.Var

var A_arbace_go_check_decl__init_A_const_56 any

var A_arbace_go_check_decl__init_A_const_57 *lang.Var

var A_arbace_go_check_decl__init_A_const_58 any

var A_arbace_go_check_decl__init_A_const_59 *lang.Var

var A_arbace_go_check_decl__init_A_const_60 any

var A_arbace_go_check_decl__init_A_const_61 *lang.Var

var A_arbace_go_check_decl__init_A_const_62 any

var A_arbace_go_check_decl__init_A_const_63 *lang.Var

var A_arbace_go_check_decl__init_A_const_64 any

var A_arbace_go_check_decl__init_A_const_65 *lang.Var

var A_arbace_go_check_decl__init_A_const_66 any

var A_arbace_go_check_decl__init_A_const_67 *lang.Var

var A_arbace_go_check_decl__init_A_const_68 any

var A_arbace_go_check_decl__init_A_const_69 *lang.Var

var A_arbace_go_check_decl__init_A_const_70 any

var A_arbace_go_check_decl__init_A_const_71 *lang.Var

var A_arbace_go_check_decl__init_A_const_72 any

var A_arbace_go_check_decl__init_A_const_73 *lang.Var

var A_arbace_go_check_decl__init_A_const_74 any

var A_arbace_go_check_decl__init_A_const_75 *lang.Var

var A_arbace_go_check_decl__init_A_const_76 any

var A_arbace_go_check_decl__init_A_const_77 *lang.Var

var A_arbace_go_check_decl__init_A_const_78 any

var A_arbace_go_check_decl__init_A_const_79 *lang.Var

var A_arbace_go_check_decl__init_A_const_80 any

var A_arbace_go_check_decl__init_A_const_81 *lang.Var

var A_arbace_go_check_decl__init_A_const_82 any

var A_arbace_go_check_decl__init_A_const_83 any

var A_arbace_go_check_decl__init_A_const_84 *lang.Var

var A_arbace_go_check_decl__init_A_const_85 any

var A_arbace_go_check_decl__init_A_const_86 *lang.Var

var A_arbace_go_check_decl__init_A_const_87 any

var A_arbace_go_check_decl__init_A_const_88 *lang.Var

var A_arbace_go_check_decl__init_A_const_89 any

var A_arbace_go_check_decl__init_A_const_90 *lang.Var

var A_arbace_go_check_decl__init_A_const_91 any

var A_arbace_go_check_decl__init_A_const_92 *lang.Var

var A_arbace_go_check_decl__init_A_const_93 any

var A_arbace_go_check_decl__init_A_const_94 *lang.Var

var A_arbace_go_check_decl__init_A_const_95 any

var A_arbace_go_check_decl__init_A_const_96 *lang.Var

var A_arbace_go_check_decl__init_A_const_97 any

var A_arbace_go_check_decl__init_A_const_98 *lang.Var

var A_arbace_go_check_decl__init_A_const_99 any

var A_arbace_go_check_decl__init_A_const_100 *lang.Var

var A_arbace_go_check_decl__init_A_const_101 any

var A_arbace_go_check_decl__init_A_const_102 *lang.Var

var A_arbace_go_check_decl__init_A_const_103 any

var A_arbace_go_check_decl__init_A_const_104 *lang.Var

var A_arbace_go_check_decl__init_A_const_105 any

var A_arbace_go_check_decl__init_A_const_106 any

var A_arbace_go_check_decl__init_A_const_107 *lang.Var

var A_arbace_go_check_decl__init_A_const_108 any

var A_arbace_go_check_decl__init_A_const_109 *lang.Var

var A_arbace_go_check_decl__init_A_const_110 any

var A_arbace_go_check_decl__init_A_const_111 *lang.Var

var A_arbace_go_check_decl__init_A_const_112 any

var A_arbace_go_check_decl__init_A_const_113 *lang.Var

var A_arbace_go_check_decl__init_A_const_114 any

var A_arbace_go_check_decl__init_A_const_115 *lang.Var

var A_arbace_go_check_decl__init_A_const_116 any

var A_arbace_go_check_decl__init_A_const_117 *lang.Var

var A_arbace_go_check_decl__init_A_const_118 any

var A_arbace_go_check_decl__init_A_const_119 any

var A_arbace_go_check_decl__init_A_const_120 *lang.Var

var A_arbace_go_check_decl__init_A_const_121 any

var A_arbace_go_check_decl__init_A_const_122 *lang.Var

var A_arbace_go_check_decl__init_A_const_123 any

var A_arbace_go_check_decl__init_A_const_124 *lang.Var

var A_arbace_go_check_decl__init_A_const_125 any

var A_arbace_go_check_decl__init_A_const_126 *lang.Var

var A_arbace_go_check_decl__init_A_const_127 any

var A_arbace_go_check_decl__init_A_const_128 *lang.Var

var A_arbace_go_check_decl__init_A_const_129 any

var A_arbace_go_check_decl__init_A_const_130 *lang.Var

var A_arbace_go_check_decl__init_A_const_131 any

var A_arbace_go_check_decl__init_A_init jrt.ClassInit

func A_arbace_go_check_decl__init_A_Init() { if !A_arbace_go_check_decl__init_A_init.Done() { A_arbace_go_check_decl__init_A_init.Run(A_arbace_go_check_decl__init_A_clinit) } }

func A_arbace_go_check_decl__init_A_clinit() { A_arbace_go_check_decl__init_A_clinit_p0(); A_arbace_go_check_decl__init_A_clinit_p1(); A_arbace_go_check_decl__init_A_clinit_p2(); A_arbace_go_check_decl__init_A_clinit_p3(); A_arbace_go_check_decl__init_A_clinit_p4(); A_arbace_go_check_decl__init_A_clinit_p5(); A_arbace_go_check_decl__init_A_clinit_p6(); A_arbace_go_check_decl__init_A_clinit_p7(); A_arbace_go_check_decl__init_A_clinit_p8(); A_arbace_go_check_decl__init_A_clinit_p9() }

func A_arbace_go_check_decl__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_decl__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_169, 191); A_arbace_go_check_decl__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[59]); A_arbace_go_check_decl__init_A_const_1 = A_arbace_go_check_decl__init_A_const_pool.A[60]; A_arbace_go_check_decl__init_A_const_2 = A_arbace_go_check_decl__init_A_const_pool.A[61]; A_arbace_go_check_decl__init_A_const_3 = A_arbace_go_check_decl__init_A_const_pool.A[62]; A_arbace_go_check_decl__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[63]); A_arbace_go_check_decl__init_A_const_5 = A_arbace_go_check_decl__init_A_const_pool.A[64]; A_arbace_go_check_decl__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[65]); A_arbace_go_check_decl__init_A_const_7 = A_arbace_go_check_decl__init_A_const_pool.A[66]; A_arbace_go_check_decl__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[67]); A_arbace_go_check_decl__init_A_const_9 = A_arbace_go_check_decl__init_A_const_pool.A[68]; A_arbace_go_check_decl__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[69]); A_arbace_go_check_decl__init_A_const_11 = A_arbace_go_check_decl__init_A_const_pool.A[70]; A_arbace_go_check_decl__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[71]) }

func A_arbace_go_check_decl__init_A_clinit_p1() { A_arbace_go_check_decl__init_A_const_13 = A_arbace_go_check_decl__init_A_const_pool.A[72]; A_arbace_go_check_decl__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[73]); A_arbace_go_check_decl__init_A_const_15 = A_arbace_go_check_decl__init_A_const_pool.A[74]; A_arbace_go_check_decl__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[75]); A_arbace_go_check_decl__init_A_const_17 = A_arbace_go_check_decl__init_A_const_pool.A[76]; A_arbace_go_check_decl__init_A_const_18 = A_arbace_go_check_decl__init_A_const_pool.A[77]; A_arbace_go_check_decl__init_A_const_19 = A_arbace_go_check_decl__init_A_const_pool.A[78]; A_arbace_go_check_decl__init_A_const_20 = A_arbace_go_check_decl__init_A_const_pool.A[79]; A_arbace_go_check_decl__init_A_const_21 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[80]); A_arbace_go_check_decl__init_A_const_22 = A_arbace_go_check_decl__init_A_const_pool.A[81]; A_arbace_go_check_decl__init_A_const_23 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[82]); A_arbace_go_check_decl__init_A_const_24 = A_arbace_go_check_decl__init_A_const_pool.A[83]; A_arbace_go_check_decl__init_A_const_25 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[84]); A_arbace_go_check_decl__init_A_const_26 = A_arbace_go_check_decl__init_A_const_pool.A[85] }

func A_arbace_go_check_decl__init_A_clinit_p2() { A_arbace_go_check_decl__init_A_const_27 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[86]); A_arbace_go_check_decl__init_A_const_28 = A_arbace_go_check_decl__init_A_const_pool.A[87]; A_arbace_go_check_decl__init_A_const_29 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[88]); A_arbace_go_check_decl__init_A_const_30 = A_arbace_go_check_decl__init_A_const_pool.A[89]; A_arbace_go_check_decl__init_A_const_31 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[90]); A_arbace_go_check_decl__init_A_const_32 = A_arbace_go_check_decl__init_A_const_pool.A[91]; A_arbace_go_check_decl__init_A_const_33 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[92]); A_arbace_go_check_decl__init_A_const_34 = A_arbace_go_check_decl__init_A_const_pool.A[93]; A_arbace_go_check_decl__init_A_const_35 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[94]); A_arbace_go_check_decl__init_A_const_36 = A_arbace_go_check_decl__init_A_const_pool.A[95]; A_arbace_go_check_decl__init_A_const_37 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[96]); A_arbace_go_check_decl__init_A_const_38 = A_arbace_go_check_decl__init_A_const_pool.A[97]; A_arbace_go_check_decl__init_A_const_39 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[98]) }

func A_arbace_go_check_decl__init_A_clinit_p3() { A_arbace_go_check_decl__init_A_const_40 = A_arbace_go_check_decl__init_A_const_pool.A[99]; A_arbace_go_check_decl__init_A_const_41 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[100]); A_arbace_go_check_decl__init_A_const_42 = A_arbace_go_check_decl__init_A_const_pool.A[101]; A_arbace_go_check_decl__init_A_const_43 = A_arbace_go_check_decl__init_A_const_pool.A[102]; A_arbace_go_check_decl__init_A_const_44 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[103]); A_arbace_go_check_decl__init_A_const_45 = A_arbace_go_check_decl__init_A_const_pool.A[104]; A_arbace_go_check_decl__init_A_const_46 = A_arbace_go_check_decl__init_A_const_pool.A[105]; A_arbace_go_check_decl__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[106]); A_arbace_go_check_decl__init_A_const_48 = A_arbace_go_check_decl__init_A_const_pool.A[107]; A_arbace_go_check_decl__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[108]); A_arbace_go_check_decl__init_A_const_50 = A_arbace_go_check_decl__init_A_const_pool.A[109]; A_arbace_go_check_decl__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[110]); A_arbace_go_check_decl__init_A_const_52 = A_arbace_go_check_decl__init_A_const_pool.A[111]; A_arbace_go_check_decl__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[112]) }

func A_arbace_go_check_decl__init_A_clinit_p4() { A_arbace_go_check_decl__init_A_const_54 = A_arbace_go_check_decl__init_A_const_pool.A[113]; A_arbace_go_check_decl__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[114]); A_arbace_go_check_decl__init_A_const_56 = A_arbace_go_check_decl__init_A_const_pool.A[115]; A_arbace_go_check_decl__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[116]); A_arbace_go_check_decl__init_A_const_58 = A_arbace_go_check_decl__init_A_const_pool.A[117]; A_arbace_go_check_decl__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[118]); A_arbace_go_check_decl__init_A_const_60 = A_arbace_go_check_decl__init_A_const_pool.A[119]; A_arbace_go_check_decl__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[120]); A_arbace_go_check_decl__init_A_const_62 = A_arbace_go_check_decl__init_A_const_pool.A[121]; A_arbace_go_check_decl__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[122]); A_arbace_go_check_decl__init_A_const_64 = A_arbace_go_check_decl__init_A_const_pool.A[123]; A_arbace_go_check_decl__init_A_const_65 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[124]); A_arbace_go_check_decl__init_A_const_66 = A_arbace_go_check_decl__init_A_const_pool.A[125] }

func A_arbace_go_check_decl__init_A_clinit_p5() { A_arbace_go_check_decl__init_A_const_67 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[126]); A_arbace_go_check_decl__init_A_const_68 = A_arbace_go_check_decl__init_A_const_pool.A[127]; A_arbace_go_check_decl__init_A_const_69 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[128]); A_arbace_go_check_decl__init_A_const_70 = A_arbace_go_check_decl__init_A_const_pool.A[129]; A_arbace_go_check_decl__init_A_const_71 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[130]); A_arbace_go_check_decl__init_A_const_72 = A_arbace_go_check_decl__init_A_const_pool.A[131]; A_arbace_go_check_decl__init_A_const_73 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[132]); A_arbace_go_check_decl__init_A_const_74 = A_arbace_go_check_decl__init_A_const_pool.A[133]; A_arbace_go_check_decl__init_A_const_75 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[134]); A_arbace_go_check_decl__init_A_const_76 = A_arbace_go_check_decl__init_A_const_pool.A[135]; A_arbace_go_check_decl__init_A_const_77 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[136]); A_arbace_go_check_decl__init_A_const_78 = A_arbace_go_check_decl__init_A_const_pool.A[137]; A_arbace_go_check_decl__init_A_const_79 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[138]) }

func A_arbace_go_check_decl__init_A_clinit_p6() { A_arbace_go_check_decl__init_A_const_80 = A_arbace_go_check_decl__init_A_const_pool.A[139]; A_arbace_go_check_decl__init_A_const_81 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[140]); A_arbace_go_check_decl__init_A_const_82 = A_arbace_go_check_decl__init_A_const_pool.A[141]; A_arbace_go_check_decl__init_A_const_83 = A_arbace_go_check_decl__init_A_const_pool.A[142]; A_arbace_go_check_decl__init_A_const_84 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[143]); A_arbace_go_check_decl__init_A_const_85 = A_arbace_go_check_decl__init_A_const_pool.A[144]; A_arbace_go_check_decl__init_A_const_86 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[145]); A_arbace_go_check_decl__init_A_const_87 = A_arbace_go_check_decl__init_A_const_pool.A[146]; A_arbace_go_check_decl__init_A_const_88 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[147]); A_arbace_go_check_decl__init_A_const_89 = A_arbace_go_check_decl__init_A_const_pool.A[148]; A_arbace_go_check_decl__init_A_const_90 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[149]); A_arbace_go_check_decl__init_A_const_91 = A_arbace_go_check_decl__init_A_const_pool.A[150]; A_arbace_go_check_decl__init_A_const_92 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[151]); A_arbace_go_check_decl__init_A_const_93 = A_arbace_go_check_decl__init_A_const_pool.A[152] }

func A_arbace_go_check_decl__init_A_clinit_p7() { A_arbace_go_check_decl__init_A_const_94 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[153]); A_arbace_go_check_decl__init_A_const_95 = A_arbace_go_check_decl__init_A_const_pool.A[154]; A_arbace_go_check_decl__init_A_const_96 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[155]); A_arbace_go_check_decl__init_A_const_97 = A_arbace_go_check_decl__init_A_const_pool.A[156]; A_arbace_go_check_decl__init_A_const_98 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[157]); A_arbace_go_check_decl__init_A_const_99 = A_arbace_go_check_decl__init_A_const_pool.A[158]; A_arbace_go_check_decl__init_A_const_100 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[159]); A_arbace_go_check_decl__init_A_const_101 = A_arbace_go_check_decl__init_A_const_pool.A[160]; A_arbace_go_check_decl__init_A_const_102 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[161]); A_arbace_go_check_decl__init_A_const_103 = A_arbace_go_check_decl__init_A_const_pool.A[162]; A_arbace_go_check_decl__init_A_const_104 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[163]); A_arbace_go_check_decl__init_A_const_105 = A_arbace_go_check_decl__init_A_const_pool.A[164]; A_arbace_go_check_decl__init_A_const_106 = A_arbace_go_check_decl__init_A_const_pool.A[165] }

func A_arbace_go_check_decl__init_A_clinit_p8() { A_arbace_go_check_decl__init_A_const_107 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[166]); A_arbace_go_check_decl__init_A_const_108 = A_arbace_go_check_decl__init_A_const_pool.A[167]; A_arbace_go_check_decl__init_A_const_109 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[168]); A_arbace_go_check_decl__init_A_const_110 = A_arbace_go_check_decl__init_A_const_pool.A[169]; A_arbace_go_check_decl__init_A_const_111 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[170]); A_arbace_go_check_decl__init_A_const_112 = A_arbace_go_check_decl__init_A_const_pool.A[171]; A_arbace_go_check_decl__init_A_const_113 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[172]); A_arbace_go_check_decl__init_A_const_114 = A_arbace_go_check_decl__init_A_const_pool.A[173]; A_arbace_go_check_decl__init_A_const_115 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[174]); A_arbace_go_check_decl__init_A_const_116 = A_arbace_go_check_decl__init_A_const_pool.A[175]; A_arbace_go_check_decl__init_A_const_117 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[176]); A_arbace_go_check_decl__init_A_const_118 = A_arbace_go_check_decl__init_A_const_pool.A[177]; A_arbace_go_check_decl__init_A_const_119 = A_arbace_go_check_decl__init_A_const_pool.A[178] }

func A_arbace_go_check_decl__init_A_clinit_p9() { A_arbace_go_check_decl__init_A_const_120 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[179]); A_arbace_go_check_decl__init_A_const_121 = A_arbace_go_check_decl__init_A_const_pool.A[180]; A_arbace_go_check_decl__init_A_const_122 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[181]); A_arbace_go_check_decl__init_A_const_123 = A_arbace_go_check_decl__init_A_const_pool.A[182]; A_arbace_go_check_decl__init_A_const_124 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[183]); A_arbace_go_check_decl__init_A_const_125 = A_arbace_go_check_decl__init_A_const_pool.A[184]; A_arbace_go_check_decl__init_A_const_126 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[185]); A_arbace_go_check_decl__init_A_const_127 = A_arbace_go_check_decl__init_A_const_pool.A[186]; A_arbace_go_check_decl__init_A_const_128 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[187]); A_arbace_go_check_decl__init_A_const_129 = A_arbace_go_check_decl__init_A_const_pool.A[188]; A_arbace_go_check_decl__init_A_const_130 = lang.Var_Cast(A_arbace_go_check_decl__init_A_const_pool.A[189]); A_arbace_go_check_decl__init_A_const_131 = A_arbace_go_check_decl__init_A_const_pool.A[190] }

func A_arbace_go_check_decl__init_A_New() *A_arbace_go_check_decl__init_A { A_arbace_go_check_decl__init_A_Init(); t := &A_arbace_go_check_decl__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_decl__init_A) Ctor() {}

func (t *A_arbace_go_check_decl__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_decl__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_decl__init_A_class }

func (t *A_arbace_go_check_decl__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_decl__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_decl__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_decl__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_decl__init_A); return ok }

func A_arbace_go_check_decl__init_A_Cast(x any) *A_arbace_go_check_decl__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_decl__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_decl__init_A_class)) }; return v }
