//line aot_arbace_g2a_print_code.ae:1
package aot_arbace_g2a_print_code

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_New() *A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_print_code_A_const_3, A_arbace_g2a_print_code_A_const_4, A_arbace_g2a_print_code_A_const_5); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_New() *A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_10), A_arbace_g2a_print_code_A_const_8.GetRawRoot__O(), A_arbace_g2a_print_code_A_const_9) }




























func A_arbace_g2a_print_code_uses_grouped_QMARK__A_New() *A_arbace_g2a_print_code_uses_grouped_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_uses_grouped_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_g2a_print_code_uses_grouped_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_g2a_print_code_uses_grouped_QMARK__A) Invoke_O_O__O(self, forms__0 any) any { var body_walk__2 *A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A = A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_New(); var walk__2 any; var tmp1 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_204, false); A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_fn_class = fncls__1d; tmp1 = fncls__1d } else { tmp1 = fncls__1 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__2), tmp1, nil); return /*line :37:1*/ jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(walk__2, forms__0))).Ref() }
//line :33:1
func A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_New() *A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A) Ctor() {}
//line :33:1
func (t *A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A) Invoke_O_O__O(self, x__1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(x__1), A_arbace_g2a_print_code_A_const_14); if
														jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(self, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Meta_O__IPersistentMap(x__1), A_arbace_g2a_print_code_A_const_17, A_arbace_g2a_print_code_A_const_18))); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)

		if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_19.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1) } else { tmp2 = x__1 }; return tmp1.Invoke_O_O__O(self, tmp2) } else { return and__1927000168__auto____4 } } } }






func A_arbace_g2a_print_code_fail_A_New() *A_arbace_g2a_print_code_fail_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_fail_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_g2a_print_code_fail_A) Ctor() {}
//line :43:1
func (t *A_arbace_g2a_print_code_fail_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { var tmp1 any = A_arbace_g2a_print_code_A_const_22; var tmp2 any = A_arbace_g2a_print_code_A_const_17; var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_20.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, msg__0, nil, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_21.GetRawRoot__O()).Invoke_O__O(form__1))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, form__1, tmp2, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(form__1)))))))) }





func A_arbace_g2a_print_code_op_A_New() *A_arbace_g2a_print_code_op_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_op_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_g2a_print_code_op_A) Ctor() {}
//line :49:1
func (t *A_arbace_g2a_print_code_op_A) Invoke_O_O__O(self, f__0 any) any {




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0)) { var h__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(f__0)

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(h__2)) { var n__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_26.GetRawRoot__O()).Invoke_O__O(h__2)

			if lang.Util_Identical_O_O__Z(n__3, nil) {
				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(h__2) } else {
//line :58:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_28.Get__O()).Invoke_O__O(n__3)) {

						return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_150, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(h__2))).Ref() } else {
//line :58:1
							var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(h__2), Lit_151)


							if and__1927000168__auto____4 { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_29).Invoke_O__O(n__3) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() }
//line :58:1
							if jrt.A2g_Truth(tmp1) { return Lit_151 } else { if A_arbace_g2a_print_code_A_const_30 != nil { return nil } else { return nil } } } } } else {
//line :56:1
								return nil } } else {
//line :54:1
									return nil
								}
}


























func A_arbace_g2a_print_code_args_A_New() *A_arbace_g2a_print_code_args_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_args_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_g2a_print_code_args_A) Ctor() {}
//line :83:1
func (t *A_arbace_g2a_print_code_args_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0) }

func A_arbace_g2a_print_code_binary_QMARK__A_New() *A_arbace_g2a_print_code_binary_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binary_QMARK__A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_g2a_print_code_binary_QMARK__A) Ctor() {}
//line :85:1
func (t *A_arbace_g2a_print_code_binary_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if


	jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_32.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_J__Z(int64(lang.RT_Count_O__I(f__0)), 3)).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_print_code_negative_literal_QMARK__A_New() *A_arbace_g2a_print_code_negative_literal_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_negative_literal_QMARK__A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_g2a_print_code_negative_literal_QMARK__A) Ctor() {}
//line :90:1
func (t *A_arbace_g2a_print_code_negative_literal_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_34.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0) } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_print_code_unary_QMARK__A_New() *A_arbace_g2a_print_code_unary_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_unary_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_g2a_print_code_unary_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_g2a_print_code_unary_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(f__0); if


	jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0)
		if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_37.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____4) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(f__0)), 2)).Ref() } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } }

func A_arbace_g2a_print_code_unary_op_A_New() *A_arbace_g2a_print_code_unary_op_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_unary_op_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_g2a_print_code_unary_op_A) Ctor() {}
//line :98:1
func (t *A_arbace_g2a_print_code_unary_op_A) Invoke_O_O__O(self, f__0 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(f__0)) { return Lit_203 } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)) } }

func A_arbace_g2a_print_code_unary_operand_A_New() *A_arbace_g2a_print_code_unary_operand_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_unary_operand_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_g2a_print_code_unary_operand_A) Ctor() {}
//line :100:1
func (t *A_arbace_g2a_print_code_unary_operand_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(f__0)) {
		if jrt.Double_InstanceOf(f__0) { return jrt.Double_ValueOf_D__Double(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D(f__0))).Ref() } else { return lang.Numbers_MinusP_O__Number(f__0) } } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)
		} }
func A_arbace_g2a_print_code_bin_op_A_New() *A_arbace_g2a_print_code_bin_op_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_bin_op_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_g2a_print_code_bin_op_A) Ctor() {}
//line :105:1
func (t *A_arbace_g2a_print_code_bin_op_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0))) }
func A_arbace_g2a_print_code_bin_prec_A_New() *A_arbace_g2a_print_code_bin_prec_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_bin_prec_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_g2a_print_code_bin_prec_A) Ctor() {}
//line :106:1
func (t *A_arbace_g2a_print_code_bin_prec_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0))) }

func A_arbace_g2a_print_code_prec_of_A_New() *A_arbace_g2a_print_code_prec_of_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_prec_of_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_g2a_print_code_prec_of_A) Ctor() {}
//line :108:1
func (t *A_arbace_g2a_print_code_prec_of_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_39.GetRawRoot__O()).Invoke_O__O(f__0)) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_40.GetRawRoot__O()).Invoke_O__O(f__0) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(f__0)) { return A_arbace_g2a_print_code_A_const_42 } else { if A_arbace_g2a_print_code_A_const_30 != nil { return A_arbace_g2a_print_code_A_const_43 } else { return nil
	} } } }
func A_arbace_g2a_print_code_go_sym_QMARK__A_New() *A_arbace_g2a_print_code_go_sym_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_go_sym_QMARK__A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_g2a_print_code_go_sym_QMARK__A) Ctor() {}
//line :113:1
func (t *A_arbace_g2a_print_code_go_sym_QMARK__A) Invoke_O_O__O(self, f__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0), Lit_83)).Ref() }

func A_arbace_g2a_print_code_statement_form_QMARK__A_New() *A_arbace_g2a_print_code_statement_form_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_statement_form_QMARK__A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_g2a_print_code_statement_form_QMARK__A) Ctor() {}
//line :115:1
func (t *A_arbace_g2a_print_code_statement_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if
												jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_44.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_print_code_expression_form_QMARK__A_New() *A_arbace_g2a_print_code_expression_form_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expression_form_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_g2a_print_code_expression_form_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_g2a_print_code_expression_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_46.GetRawRoot__O()).Invoke_O__O(f__0)); if


	jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____3_2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0)
		if jrt.A2g_Truth(and__1927000168__auto____3_2) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0), Lit_109)).Ref() } else { tmp2 = and__1927000168__auto____3_2 }; and__1927000168__auto____3 = tmp1.Invoke_O__O(tmp2)
//line :121:1
		if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____4) {

			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :121:1
				return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_g2a_print_code_line_of_A_New() *A_arbace_g2a_print_code_line_of_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_line_of_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_g2a_print_code_line_of_A) Ctor() {}
//line :125:1
func (t *A_arbace_g2a_print_code_line_of_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var l__1256000046__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____2)) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____2)).Ref() } else { return nil } } else { return nil } }

func A_arbace_g2a_print_code_breaks_of_A_New() *A_arbace_g2a_print_code_breaks_of_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_breaks_of_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_g2a_print_code_breaks_of_A) Ctor() {}
//line :127:1
func (t *A_arbace_g2a_print_code_breaks_of_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_52.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_53.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_New(); var tmp4 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }; var tmp5 *lang.Keyword = A_arbace_g2a_print_code_A_const_54; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)))) }
//line :131:1
func A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_New() *A_arbace_g2a_print_code_breaks_of_fn__1022000031_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_breaks_of_fn__1022000031_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_g2a_print_code_breaks_of_fn__1022000031_A) Ctor() {}
//line :131:1
func (t *A_arbace_g2a_print_code_breaks_of_fn__1022000031_A) Invoke_O_O__O(self, p1__1022000030_SHARP___1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(p1__1022000030_SHARP___1)) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(p1__1022000030_SHARP___1) } else { return p1__1022000030_SHARP___1 } }

func A_arbace_g2a_print_code_break_line_A_New() *A_arbace_g2a_print_code_break_line_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_break_line_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_g2a_print_code_break_line_A) Ctor() {}
//line :133:1
func (t *A_arbace_g2a_print_code_break_line_A) Invoke_O_O_O__O(self, parent__0, i__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_break_line_fn__1022000035_A_New_O(i__1); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_print_code_break_line_fn__1022000035_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_g2a_print_code_break_line_fn__1022000035_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; var tmp4 *lang.Keyword = A_arbace_g2a_print_code_A_const_54; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(parent__0))) }
//line :136:1
func A_arbace_g2a_print_code_break_line_fn__1022000035_A_New_O(p0 any) *A_arbace_g2a_print_code_break_line_fn__1022000035_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_break_line_fn__1022000035_A{}; t.Ctor_O(p0); return t }
//line :136:1
func (t *A_arbace_g2a_print_code_break_line_fn__1022000035_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :136:1
func (t *A_arbace_g2a_print_code_break_line_fn__1022000035_A) Invoke_O_O__O(self, p1__1022000034_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(p1__1022000034_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(p1__1022000034_SHARP___1), t.F_i)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(p1__1022000034_SHARP___1) } else { return nil } }

func A_arbace_g2a_print_code_child_target_A_New() *A_arbace_g2a_print_code_child_target_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_child_target_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_g2a_print_code_child_target_A) Ctor() {}
//line :138:1
func (t *A_arbace_g2a_print_code_child_target_A) Invoke_O_O_O_O_O__O(self, parent__0, i__1, child__2, brk__3 any) any { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(child__2); if




	jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {
		var tmp1 any; var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____6 any = tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = parent__0; if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()); var tmp4 any; var or__1927000174__auto____8 any = brk__3; if jrt.A2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { tmp4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_58.GetRawRoot__O()).Invoke_O__O(parent__0) }; tmp1 = tmp3.Invoke_O_O__O(tmp4, i__1) } else { tmp1 = and__1927000168__auto____7 } } else { tmp1 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp1) { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_56.GetRawRoot__O()).Invoke_O_O__O(parent__0, i__1)
			if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { return A_arbace_g2a_print_code_A_const_57 } } else {
//line :144:1
				return nil } } }
//line :138:1
func (t *A_arbace_g2a_print_code_child_target_A) Invoke_O_O_O_O__O(self, parent__0, i__1, child__2 any) any {


	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_59.GetRawRoot__O()).Invoke_O_O_O_O__O(parent__0, i__1, child__2, nil)
}




func A_arbace_g2a_print_code_next_targets_A_New() *A_arbace_g2a_print_code_next_targets_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_next_targets_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_g2a_print_code_next_targets_A) Ctor() {}
//line :147:1
func (t *A_arbace_g2a_print_code_next_targets_A) Invoke_O_O__O(self, ts__0 any) any { var ts__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(ts__0); var n__3 int32 = lang.RT_Count_O__I(ts__2); var out__4 any = lang.RT_Object_array_O__O1(jrt.Integer_ValueOf_I__Integer(n__3).Ref()).Ref(); var i__5 int64 = lang.Numbers_Dec_J__J(int64(n__3)); var nxt__6 any; L1: for {






	if lang.Numbers_Gte_J_J__Z(i__5, 0) {
		lang.RT_Aset_O1_I_O__O(jrt.A2g_CastArray[*jrt.RefArray](out__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I(i__5), nxt__6)
		var tmp1 int64 = lang.Numbers_Dec_J__J(i__5); var tmp2 any; var t__7 any = lang.RT_Nth_O_I__O(ts__2, lang.RT_IntCast_J__I(i__5)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(t__7)) { tmp2 = t__7 } else { tmp2 = nxt__6 }; i__5, nxt__6 = tmp1, tmp2; continue L1 }
//line :147:1
	break L1 }; return /*line :157:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(out__4) }

func A_arbace_g2a_print_code_room_QMARK__A_New() *A_arbace_g2a_print_code_room_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_room_QMARK__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_g2a_print_code_room_QMARK__A) Ctor() {}
//line :159:1
func (t *A_arbace_g2a_print_code_room_QMARK__A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_61.GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_g2a_print_code_body_offset_A_New() *A_arbace_g2a_print_code_body_offset_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_body_offset_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_g2a_print_code_body_offset_A) Ctor() {}
//line :161:1
func (t *A_arbace_g2a_print_code_body_offset_A) Invoke_O_O_O__O(self, f__0, body__1 any) any {

	return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(f__0)), int64(lang.RT_Count_O__I(body__1)))).Ref()
}
func A_arbace_g2a_print_code_next_line_A_New() *A_arbace_g2a_print_code_next_line_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_next_line_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_g2a_print_code_next_line_A) Ctor() {}
//line :165:1
func (t *A_arbace_g2a_print_code_next_line_A) Invoke_O_O__O(self, forms__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O(), forms__0); if


	jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_g2a_print_code_A_const_62.Get__O() } }

func A_arbace_g2a_print_code_comma_list_A_New() *A_arbace_g2a_print_code_comma_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_comma_list_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_g2a_print_code_comma_list_A) Ctor() {}
//line :170:1
func (t *A_arbace_g2a_print_code_comma_list_A) Invoke_O_O_O_O_O__O(self, parent__0, offset__1, xs__2, print_one__3 any) any { { var xs__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__2); var ts__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_comma_list_fn__1022000043_A_New_O_O(parent__0, offset__1); var tmp3 *jrt.Class
																var fncls__4 /*line :170:1*/*jrt.Class = A_arbace_g2a_print_code_comma_list_fn__1022000043_A_fn_class





	if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_g2a_print_code_comma_list_fn__1022000043_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; ts__6 = tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_64.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(xs__5)).Ref()), xs__5)
//line :170:1
	var n__1927000701__auto____7 int64 = lang.RT_LongCast_I__J(lang.RT_Count_O__I(xs__5)); var i__8 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z(i__8, n__1927000701__auto____7) {
			if lang.Numbers_IsPos_J__Z(i__8) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ts__6, lang.RT_IntCast_J__I(i__8))) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_print_code_A_const_62; var tmp7 any; var t__9 any = lang.RT_Get_O_O__O(ts__6, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(i__8)).Ref()); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(t__9)) { tmp7 = t__9 } else { tmp7 = A_arbace_g2a_print_code_A_const_62.Get__O() }; tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7)); var tmp8 any = A_arbace_g2a_print_code_comma_list_fn__1022000045_A_New_J_O_O(i__8, print_one__3, xs__5); var tmp9 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_print_code_comma_list_fn__1022000045_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_g2a_print_code_comma_list_fn__1022000045_A_fn_class = fncls__5d; tmp9 = fncls__5d } else { tmp9 = fncls__5 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()
//line :177:1
			i__8 = lang.Numbers_Unchecked_inc_J__J(i__8); continue L1 } else { return nil } } }; /*line :170:1*/panic("a2g: unreachable") }





func A_arbace_g2a_print_code_comma_list_fn__1022000043_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_comma_list_fn__1022000043_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_comma_list_fn__1022000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_g2a_print_code_comma_list_fn__1022000043_A) Ctor_O_O(c__parent, c__offset any) { t.F_parent = c__parent; t.F_offset = c__offset }
//line :176:1
func (t *A_arbace_g2a_print_code_comma_list_fn__1022000043_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_59.GetRawRoot__O()); var tmp2 any = t.F_parent; return tmp1.Invoke_O_O_O__O(tmp2, lang.Numbers_Add_O_O__Number(i__1, t.F_offset), x__2) }


func A_arbace_g2a_print_code_comma_list_fn__1022000045_A_New_J_O_O(p0 int64, p1, p2 any) *A_arbace_g2a_print_code_comma_list_fn__1022000045_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_comma_list_fn__1022000045_A{}; t.Ctor_J_O_O(p0, p1, p2); return t }
//line :179:1
func (t *A_arbace_g2a_print_code_comma_list_fn__1022000045_A) Ctor_J_O_O(c__i int64, c__print_one, c__xs any) { t.F_i = c__i; t.F_print_one = c__print_one; t.F_xs = c__xs }
//line :179:1
func (t *A_arbace_g2a_print_code_comma_list_fn__1022000045_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var t_ any = t.F_print_one; t.F_print_one = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_xs; t.F_xs = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(lang.RT_Nth_O_I__O(tmp4, lang.RT_IntCast_J__I(t.F_i))) }
//line :179:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }





func A_arbace_g2a_print_code_ident_string_A_New() *A_arbace_g2a_print_code_ident_string_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_ident_string_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_g2a_print_code_ident_string_A) Ctor() {}
//line :185:1
func (t *A_arbace_g2a_print_code_ident_string_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(f__0)) { var temp__1927000408__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_26.GetRawRoot__O()).Invoke_O__O(f__0)
		if jrt.A2g_Truth(temp__1927000408__auto____2) { var n__3 any = temp__1927000408__auto____2; return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_80, nil), jrt.RefArrayOf(jrt.Object_class, n__3, nil, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(f__0))).Ref() } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(f__0) } } else {
//line :188:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_71.GetRawRoot__O()).Invoke_O__O(f__0)) {

				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :188:1
					if A_arbace_g2a_print_code_A_const_30 != nil {


						return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_132, f__0) } else {
//line :188:1
							return nil
						}
				}
		}
}
func A_arbace_g2a_print_code_name_list_A_New() *A_arbace_g2a_print_code_name_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_name_list_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_g2a_print_code_name_list_A) Ctor() {}
//line :193:1
func (t *A_arbace_g2a_print_code_name_list_A) Invoke_O_O__O(self, nms__0 any) any { { var seq_1022000049__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_78.GetRawRoot__O(), nms__0)); var chunk_1022000050__3 any; var count_1022000051__4 int64 = 0; var i_1022000052__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z(i_1022000052__5, count_1022000051__4) { var vec__1022000053__6 any = lang.Indexed_Cast(chunk_1022000050__3).Nth_I__O(lang.RT_IntCast_J__I(i_1022000052__5)); var i__7 any = lang.RT_Nth_O_I_O__O(vec__1022000053__6, lang.RT_IntCast_J__I(0), nil); var nm__8 any = lang.RT_Nth_O_I_O__O(vec__1022000053__6, lang.RT_IntCast_J__I(1), nil)
		if lang.Numbers_IsPos_O__Z(i__7) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(nm__8)) }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(nm__8))
//line :198:1
		seq_1022000049__2, chunk_1022000050__3, count_1022000051__4, i_1022000052__5 = seq_1022000049__2, chunk_1022000050__3, count_1022000051__4, lang.Numbers_Unchecked_inc_J__J(i_1022000052__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000049__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1022000049__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000049__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000049__7); seq_1022000049__2, chunk_1022000050__3, count_1022000051__4, i_1022000052__5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000049__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1022000056__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000049__7); var i__9 any = lang.RT_Nth_O_I_O__O(vec__1022000056__8, lang.RT_IntCast_J__I(0), nil); var nm__10 any = lang.RT_Nth_O_I_O__O(vec__1022000056__8, lang.RT_IntCast_J__I(1), nil)
			if lang.Numbers_IsPos_O__Z(i__9) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(nm__10)) }
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(nm__10))
//line :198:1
			seq_1022000049__2, chunk_1022000050__3, count_1022000051__4, i_1022000052__5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000049__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :193:1*/panic("a2g: unreachable") }








func A_arbace_g2a_print_code_group_line_A_New() *A_arbace_g2a_print_code_group_line_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_line_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_g2a_print_code_group_line_A) Ctor() {}
//line :202:1
func (t *A_arbace_g2a_print_code_group_line_A) Invoke_O_O__O(self, g__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__0)); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = A_arbace_g2a_print_code_A_const_82.Invoke_O__O(g__0) }; return tmp1.Invoke_O__O(tmp2)
}
func A_arbace_g2a_print_code_label_name_A_New() *A_arbace_g2a_print_code_label_name_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_label_name_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_g2a_print_code_label_name_A) Ctor() {}
//line :207:1
func (t *A_arbace_g2a_print_code_label_name_A) Invoke_O_O__O(self, k__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(k__0)) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(k__0) } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_140, k__0)
	} }
func A_arbace_g2a_print_code_literal_A_New() *A_arbace_g2a_print_code_literal_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_literal_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_g2a_print_code_literal_A) Ctor() {}
//line :210:1
func (t *A_arbace_g2a_print_code_literal_A) Invoke_O_O__O(self, f__0 any) any {
	if lang.Util_Identical_O_O__Z(f__0, nil) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_30) } else {
//line :211:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_84.GetRawRoot__O()).Invoke_O__O(f__0)) {

				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_144) } else {
//line :211:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_85.GetRawRoot__O()).Invoke_O__O(f__0)) {


						return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_145) } else {
//line :211:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(f__0)) { var nl_QMARK___2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_87.GetRawRoot__O()).Invoke_O_O__O(f__0, Lit_146); var tmp1 any
								var and__1927000168__auto____3 any = nl_QMARK___2






								if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_88.GetRawRoot__O()).Invoke_O__O(f__0) } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
									return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_147, nil, Lit_147), jrt.RefArrayOf(jrt.Object_class, nil, f__0, nil)).Ref()) } else {
										return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_91.GetRawRoot__O()).Invoke_O__O(f__0)) } } else {
//line :211:1
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_90.GetRawRoot__O()).Invoke_O__O(f__0)) {










												return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(lang.RT_IntCast_O__I(f__0))).Ref())) } else {
//line :211:1
													if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_34.GetRawRoot__O()).Invoke_O__O(f__0)) {











														return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_93.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :211:1
															if A_arbace_g2a_print_code_A_const_30 != nil {












																return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_148, f__0) } else {
//line :211:1
																	return nil
																}
														}
												}
										}
						}
				}
		}
}









func A_arbace_g2a_print_code_element_list_A_New() *A_arbace_g2a_print_code_element_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_element_list_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_g2a_print_code_element_list_A) Ctor() {}
//line :229:1
func (t *A_arbace_g2a_print_code_element_list_A) Invoke_O_O_O_O_O_O__O(self, open__0, close__1, xs__2, print_one__3, p__1022000063__4 any) any { var default__1022000066__6 int64 = 1; var map__1022000064__7 any = p__1022000063__4; var map__1022000064__8 any; if lang.ISeq_InstanceOf(map__1022000064__7) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(map__1022000064__7)) { map__1022000064__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(map__1022000064__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(map__1022000064__7)) { map__1022000064__8 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(map__1022000064__7) } else { lang.PersistentArrayMap_Init(); map__1022000064__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1022000064__8 = map__1022000064__7 }; var parent__9 any = lang.RT_Get_O_O__O(map__1022000064__8, A_arbace_g2a_print_code_A_const_95); var tmp1 any = A_arbace_g2a_print_code_A_const_96; var offset__10 any = lang.RT_Get_O_O_O__O(map__1022000064__8, tmp1, jrt.Long_ValueOf_J__Long(default__1022000066__6).Ref()); var end__11 any = lang.RT_Get_O_O__O(map__1022000064__8, A_arbace_g2a_print_code_A_const_97); var target__12 any = lang.RT_Get_O_O__O(map__1022000064__8, A_arbace_g2a_print_code_A_const_98);







	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(open__0);
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke__O(); var tmp2 /*line :229:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_17; var start__13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); var xs__14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__2); var n__15 int32 = lang.RT_Count_O__I(xs__14); var brk__16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_58.GetRawRoot__O()).Invoke_O__O(parent__9); var ts__17 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_code_element_list_fn__1022000068_A_New_O_O_O_O(parent__9, target__12, offset__10, brk__16); var tmp5 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_print_code_element_list_fn__1022000068_A_fn_class; if













	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_g2a_print_code_element_list_fn__1022000068_A_fn_class = fncls__6d; tmp5 = fncls__6d } else { tmp5 = fncls__6 }; ts__17 = tmp3.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_64.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(n__15).Ref()), xs__14); var nxt__18 any = /*line :229:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_99.GetRawRoot__O()).Invoke_O__O(ts__17); var n__1927000701__auto____19 int64 = lang.RT_LongCast_I__J(n__15); var i__20 int64 = 0; L1: for {


















		if lang.Numbers_Lt_J_J__Z(i__20, n__1927000701__auto____19) { var x__21 any = lang.RT_Nth_O_I__O(xs__14, lang.RT_IntCast_J__I(i__20)); var t__22 any = lang.RT_Nth_O_I__O(ts__17, lang.RT_IntCast_J__I(i__20))


			if lang.Numbers_IsPos_J__Z(i__20) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(t__22)
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_print_code_A_const_62; var tmp9 any; var or__1927000174__auto____23 any = lang.RT_Nth_O_I__O(nxt__18, lang.RT_IntCast_J__I(i__20)); if jrt.A2g_Truth(or__1927000174__auto____23) { tmp9 = or__1927000174__auto____23 } else { tmp9 = A_arbace_g2a_print_code_A_const_62.Get__O() }; tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9)); var tmp10 any = A_arbace_g2a_print_code_element_list_fn__1022000070_A_New_O_O_J(x__21, print_one__3, i__20); var tmp11 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_print_code_element_list_fn__1022000070_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_g2a_print_code_element_list_fn__1022000070_A_fn_class = fncls__7d; tmp11 = fncls__7d } else { tmp11 = fncls__7 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :248:1
			i__20 = lang.Numbers_Unchecked_inc_J__J(i__20); continue L1 }
//line :229:1
		break L1 }; var indent__19 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O(); var tmp12 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var multi_QMARK___20 bool = lang.Numbers_Gt_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())), start__13); var end__21 any; var tmp13 any; var or__1927000174__auto____21 bool = lang.Util_Equiv_O_O__Z(end__11, A_arbace_g2a_print_code_A_const_101); if or__1927000174__auto____21 {





























			tmp13 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____21).Ref() } else { var and__1927000168__auto____22 bool = lang.Numbers_IsPos_J__Z(int64(n__15)); if and__1927000168__auto____22 { var and__1927000168__auto____23 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(xs__14)), Lit_72); if and__1927000168__auto____23 { var tmp14 *lang.Keyword = A_arbace_g2a_print_code_A_const_102; tmp13 = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(xs__14))) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____23).Ref() } } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____22).Ref() } }; if jrt.A2g_Truth(tmp13) {
				var tmp15 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; end__21 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } else {
//line :259:1
					end__21 = end__11 }; var tmp16 any; var tmp17 /*line :262:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____22_2 any = tmp17.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()); if jrt.A2g_Truth(and__1927000168__auto____22_2) { var and__1927000168__auto____23_2 bool = lang.Numbers_IsPos_J__Z(int64(n__15)); if and__1927000168__auto____23_2 { var or__1927000174__auto____24 any; var and__1927000168__auto____24 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(end__21)
						if jrt.A2g_Truth(and__1927000168__auto____24) { var tmp18 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; or__1927000174__auto____24 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(end__21), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))).Ref() } else { or__1927000174__auto____24 = and__1927000168__auto____24 }; if jrt.A2g_Truth(or__1927000174__auto____24) { tmp16 = or__1927000174__auto____24 } else { var and__1927000168__auto____25 bool = lang.Util_Identical_O_O__Z(end__21, nil)
							if and__1927000168__auto____25 { var and__1927000168__auto____26 bool = multi_QMARK___20; if and__1927000168__auto____26 { tmp16 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_61.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_106) } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____26).Ref() } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____25).Ref() } } } else {
//line :262:1
								tmp16 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____23_2).Ref() } } else { tmp16 = and__1927000168__auto____22_2 }; if jrt.A2g_Truth(tmp16) {


									lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41) }; var tmp19 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_105.GetRawRoot__O()); var tmp20 any = jrt.Boolean_ValueOf_Z__Boolean(multi_QMARK___20).Ref(); var tmp21 *jrt.Boolean; jrt.Boolean_Init(); tmp21 = jrt.Boolean_FALSE; tmp19.Invoke_O_O_O_O__O(end__21, tmp20, tmp21.Ref(), indent__19); return /*line :267:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(close__1) }
//line :243:1
func A_arbace_g2a_print_code_element_list_fn__1022000068_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_print_code_element_list_fn__1022000068_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_element_list_fn__1022000068_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :243:1
func (t *A_arbace_g2a_print_code_element_list_fn__1022000068_A) Ctor_O_O_O_O(c__parent, c__target, c__offset, c__brk any) { t.F_parent = c__parent; t.F_target = c__target; t.F_offset = c__offset; t.F_brk = c__brk }
//line :243:1
func (t *A_arbace_g2a_print_code_element_list_fn__1022000068_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if jrt.A2g_Truth(t.F_parent) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_59.GetRawRoot__O()); var tmp2 any = t.F_parent; return tmp1.Invoke_O_O_O_O__O(tmp2, lang.Numbers_Add_O_O__Number(i__1, t.F_offset), x__2, t.F_brk) } else { if jrt.A2g_Truth(t.F_target) {
														return lang.IFn_Cast(t.F_target).Invoke_O__O(x__2) } else {
//line :243:1
		if A_arbace_g2a_print_code_A_const_30 != nil {

			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(x__2) } else {
//line :243:1
				return nil } } } }









func A_arbace_g2a_print_code_element_list_fn__1022000070_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_g2a_print_code_element_list_fn__1022000070_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_element_list_fn__1022000070_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :253:1
func (t *A_arbace_g2a_print_code_element_list_fn__1022000070_A) Ctor_O_O_J(c__x, c__print_one any, c__i int64) { t.F_x = c__x; t.F_print_one = c__print_one; t.F_i = c__i }
//line :253:1
func (t *A_arbace_g2a_print_code_element_list_fn__1022000070_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 any; var t_ any = t.F_print_one; t.F_print_one = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_x; t.F_x = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O_O__O(tmp4, jrt.Long_ValueOf_J__Long(t.F_i).Ref()) }
//line :253:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }


















func A_arbace_g2a_print_code_tagged_QMARK__A_New() *A_arbace_g2a_print_code_tagged_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_tagged_QMARK__A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_g2a_print_code_tagged_QMARK__A) Ctor() {}
//line :272:1
func (t *A_arbace_g2a_print_code_tagged_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0); if


	jrt.A2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { and__1927000168__auto____2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_71.GetRawRoot__O()).Invoke_O__O(x__0) }; if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(x__0), A_arbace_g2a_print_code_A_const_107) } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_print_code_param_entries_A_New() *A_arbace_g2a_print_code_param_entries_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_param_entries_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_g2a_print_code_param_entries_A) Ctor() {}
//line :277:1
func (t *A_arbace_g2a_print_code_param_entries_A) Invoke_O_O__O(self, v__0 any) any { { var xs__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(v__0); var acc__3 any; lang.PersistentVector_Init(); acc__3 = lang.PersistentVector_EMPTY.Ref(); var variadic__4 any; jrt.Boolean_Init(); variadic__4 = jrt.Boolean_FALSE.Ref(); L1: for {




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(xs__2)) { return acc__3 } else { var x__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__2)


		if lang.Util_Equiv_O_O__Z(x__5, A_arbace_g2a_print_code_A_const_108) {
			var tmp1 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(xs__2); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; xs__2, acc__3, variadic__4 = tmp1, acc__3, tmp2.Ref(); continue L1 } else {
				var tmp3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(xs__2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()); var tmp5 lang.IPersistentMap
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_109.GetRawRoot__O()).Invoke_O__O(x__5)) { var tmp6 any = A_arbace_g2a_print_code_A_const_110; var tmp7 any = A_arbace_g2a_print_code_A_const_111; var tmp8 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; var tmp9 any = tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__5)); var tmp10 any = A_arbace_g2a_print_code_A_const_112; var tmp11 any = A_arbace_g2a_print_code_A_const_113; tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, x__5, tmp7, tmp9, tmp10, variadic__4, tmp11, lang.RT_Meta_O__IPersistentMap(x__5), A_arbace_g2a_print_code_A_const_82, x__5)) } else { var tmp12 any = A_arbace_g2a_print_code_A_const_110; var tmp13 any = A_arbace_g2a_print_code_A_const_111; var tmp14 any = A_arbace_g2a_print_code_A_const_112; var tmp15 any = A_arbace_g2a_print_code_A_const_113; tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, nil, tmp13, x__5, tmp14, variadic__4, tmp15, lang.RT_Meta_O__IPersistentMap(x__5), A_arbace_g2a_print_code_A_const_82, x__5)) }
//line :287:1
				xs__2, acc__3, variadic__4 = tmp3, tmp4.Invoke_O_O__O(acc__3, tmp5), variadic__4; continue L1 } } } }; /*line :277:1*/panic("a2g: unreachable") }















func A_arbace_g2a_print_code_groupable_QMARK__A_New() *A_arbace_g2a_print_code_groupable_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_groupable_QMARK__A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_g2a_print_code_groupable_QMARK__A) Ctor() {}
//line :293:1
func (t *A_arbace_g2a_print_code_groupable_QMARK__A) Invoke_O_O_O__O(self, prev__0, cur__1 any) any { var and__1927000168__auto____3 any = prev__0; if




	jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = A_arbace_g2a_print_code_A_const_110.Invoke_O__O(prev__0); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = A_arbace_g2a_print_code_A_const_110.Invoke_O__O(cur__1); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_112.Invoke_O__O(prev__0)); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_112.Invoke_O__O(cur__1)); if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(A_arbace_g2a_print_code_A_const_111.Invoke_O__O(prev__0), A_arbace_g2a_print_code_A_const_111.Invoke_O__O(cur__1)); if and__1927000168__auto____8 { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_114; var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_114; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(prev__0)), tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(cur__1))); if and__1927000168__auto____9 { var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_115; var tmp4 *lang.Keyword = A_arbace_g2a_print_code_A_const_115; var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z(tmp3.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(prev__0)), tmp4.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(cur__1))); if and__1927000168__auto____10 { var t__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_82.Invoke_O__O(cur__1)); var or__1927000174__auto____12 bool = lang.Util_Identical_O_O__Z(t__11, nil)




		if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____12).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(t__11, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_82.Invoke_O__O(prev__0)))).Ref() } } else {
//line :298:1
			return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } }






func A_arbace_g2a_print_code_group_entries_A_New() *A_arbace_g2a_print_code_group_entries_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_entries_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_g2a_print_code_group_entries_A) Ctor() {}
//line :305:1
func (t *A_arbace_g2a_print_code_group_entries_A) Invoke_O_O__O(self, entries__0 any) any { var explicit_QMARK___2 any; var or__1927000174__auto____2 any; var and__1927000168__auto____2 any = A_arbace_g2a_print_code_A_const_116.Get__O(); if








	jrt.A2g_Truth(and__1927000168__auto____2) { or__1927000174__auto____2 = A_arbace_g2a_print_code_A_const_117.Get__O() } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.A2g_Truth(or__1927000174__auto____2) { explicit_QMARK___2 = or__1927000174__auto____2 } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_group_entries_fn__1022000077_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_print_code_group_entries_fn__1022000077_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_g2a_print_code_group_entries_fn__1022000077_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; explicit_QMARK___2 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), entries__0) }; var tmp4 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_118.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_code_group_entries_fn__1022000079_A_New_O(explicit_QMARK___2); var tmp6 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_print_code_group_entries_fn__1022000079_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_g2a_print_code_group_entries_fn__1022000079_A_fn_class = fncls__9d; tmp6 = fncls__9d } else { tmp6 = fncls__9 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; return tmp4.Invoke_O_O_O__O(tmp7, tmp8.Ref(), entries__0) }
//line :315:1
func A_arbace_g2a_print_code_group_entries_fn__1022000077_A_New() *A_arbace_g2a_print_code_group_entries_fn__1022000077_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_entries_fn__1022000077_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_g2a_print_code_group_entries_fn__1022000077_A) Ctor() {}
//line :315:1
func (t *A_arbace_g2a_print_code_group_entries_fn__1022000077_A) Invoke_O_O__O(self, p1__1022000076_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(p1__1022000076_SHARP___1), A_arbace_g2a_print_code_A_const_14) }
func A_arbace_g2a_print_code_group_entries_fn__1022000079_A_New_O(p0 any) *A_arbace_g2a_print_code_group_entries_fn__1022000079_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_entries_fn__1022000079_A{}; t.Ctor_O(p0); return t }
//line :316:1
func (t *A_arbace_g2a_print_code_group_entries_fn__1022000079_A) Ctor_O(c__explicit_QMARK_ any) { t.F_explicit_QMARK_ = c__explicit_QMARK_ }
//line :316:1
func (t *A_arbace_g2a_print_code_group_entries_fn__1022000079_A) Invoke_O_O_O__O(self, groups__1, cur__2 any) any { var prev__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(groups__1); var tmp1 any; var and__1927000168__auto____4 any = prev__3; if

	jrt.A2g_Truth(and__1927000168__auto____4) {
		if jrt.A2g_Truth(t.F_explicit_QMARK_) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_14; var and__1927000168__auto____5 any = tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(cur__2))
			if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = A_arbace_g2a_print_code_A_const_110.Invoke_O__O(cur__2); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_110; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_120.Invoke_O__O(prev__3))) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else {
				tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_119.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_120.Invoke_O__O(prev__3)), cur__2) } } else {
//line :318:1
					tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) {



						var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_122.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_122.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_print_code_A_const_83; var tmp7 any = tmp5.Invoke_O_O_O_O__O(prev__3, tmp6, A_arbace_g2a_print_code_A_const_8.GetRawRoot__O(), A_arbace_g2a_print_code_A_const_110.Invoke_O__O(cur__2)); var tmp8 any = A_arbace_g2a_print_code_A_const_120; return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_121.GetRawRoot__O()).Invoke_O__O(groups__1), tmp4.Invoke_O_O_O_O__O(tmp7, tmp8, A_arbace_g2a_print_code_A_const_8.GetRawRoot__O(), cur__2)) } else {


							var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_123.GetRawRoot__O()); var tmp11 any = A_arbace_g2a_print_code_A_const_83; var tmp12 lang.IPersistentVector; if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_110.Invoke_O__O(cur__2)) { tmp12 = lang.Tuple_Create_O__IPersistentVector(A_arbace_g2a_print_code_A_const_110.Invoke_O__O(cur__2)) } else { lang.PersistentVector_Init(); tmp12 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY) }; var tmp13 any = tmp12; var tmp14 any = A_arbace_g2a_print_code_A_const_120; return tmp9.Invoke_O_O__O(groups__1, tmp10.Invoke_O_O_O_O_O__O(cur__2, tmp11, tmp13, tmp14, lang.Tuple_Create_O__IPersistentVector(cur__2))) } }


func A_arbace_g2a_print_code_variadic_elem_A_New() *A_arbace_g2a_print_code_variadic_elem_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_variadic_elem_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_g2a_print_code_variadic_elem_A) Ctor() {}
//line :328:1
func (t *A_arbace_g2a_print_code_variadic_elem_A) Invoke_O_O__O(self, t__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__0), Lit_191)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(t__0) } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_206, t__0)
	} }
func A_arbace_g2a_print_code_param_list_A_New() *A_arbace_g2a_print_code_param_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_param_list_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_g2a_print_code_param_list_A) Ctor() {}
//line :331:1
func (t *A_arbace_g2a_print_code_param_list_A) DoInvoke_O_O_O__O(self, v__0, p__1022000083__1 any) any { var vec__1022000084__3 any = p__1022000083__1; var end__4 any = lang.RT_Nth_O_I_O__O(vec__1022000084__3, lang.RT_IntCast_J__I(0), nil); var groups__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_124.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(v__0)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_125.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_param_list_fn__1022000087_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_print_code_param_list_fn__1022000087_A_fn_class; if





	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_152, false); A_arbace_g2a_print_code_param_list_fn__1022000087_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; var tmp4 any = A_arbace_g2a_print_code_A_const_98; return /*line :336:1*/ tmp1.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, groups__5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, A_arbace_g2a_print_code_A_const_130.GetRawRoot__O(), A_arbace_g2a_print_code_A_const_97, end__4))) }
func A_arbace_g2a_print_code_param_list_fn__1022000087_A_New() *A_arbace_g2a_print_code_param_list_fn__1022000087_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_param_list_fn__1022000087_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_g2a_print_code_param_list_fn__1022000087_A) Ctor() {}
//line :337:1
func (t *A_arbace_g2a_print_code_param_list_fn__1022000087_A) Invoke_O_O_O__O(self, g__1, ___2 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__1))) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_128.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__1))
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
	if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_112.Invoke_O__O(g__1)) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_25); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_129.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_111.Invoke_O__O(g__1))) } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_111.Invoke_O__O(g__1))
		}
}
func A_arbace_g2a_print_code_results_entries_A_New() *A_arbace_g2a_print_code_results_entries_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_results_entries_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_g2a_print_code_results_entries_A) Ctor() {}
//line :346:1
func (t *A_arbace_g2a_print_code_results_entries_A) Invoke_O_O_O__O(self, params__0, results__1 any) any {


	if jrt.A2g_Truth(results__1) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(results__1) } else {
//line :349:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(params__0), A_arbace_g2a_print_code_A_const_107)) { var tmp1 any = A_arbace_g2a_print_code_A_const_110; var tmp2 any = A_arbace_g2a_print_code_A_const_111; var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, nil, tmp2, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(params__0))))) } else { if A_arbace_g2a_print_code_A_const_30 != nil { lang.PersistentVector_Init(); return lang.PersistentVector_EMPTY.Ref() } else { return nil
			}
			}
		}
}
func A_arbace_g2a_print_code_print_results_A_New() *A_arbace_g2a_print_code_print_results_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_print_results_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_g2a_print_code_print_results_A) Ctor() {}
//line :354:1
func (t *A_arbace_g2a_print_code_print_results_A) Invoke_O_O__O(self, entries__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_131.GetRawRoot__O()).Invoke_O__O(entries__0)) { return nil } else { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(entries__0)))

		if and__1927000168__auto____2 { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_110; tmp1 = lang.Util_Identical_O_O__Z(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(entries__0)), nil) } else { tmp1 = and__1927000168__auto____2 }
//line :355:1
		if tmp1 {


			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_111; return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(entries__0))) } else {
//line :355:1
				if A_arbace_g2a_print_code_A_const_30 != nil {



					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_132.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_53.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_print_results_fn__1022000091_A_New(); var tmp8 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_print_code_print_results_fn__1022000091_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_154, false); A_arbace_g2a_print_code_print_results_fn__1022000091_A_fn_class = fncls__11d; tmp8 = fncls__11d } else { tmp8 = fncls__11 }; return tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), entries__0))) } else {
//line :355:1
						return nil
					}
			}
	} }
func A_arbace_g2a_print_code_print_results_fn__1022000091_A_New() *A_arbace_g2a_print_code_print_results_fn__1022000091_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_print_results_fn__1022000091_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_g2a_print_code_print_results_fn__1022000091_A) Ctor() {}
//line :359:1
func (t *A_arbace_g2a_print_code_print_results_fn__1022000091_A) Invoke_O_O__O(self, en__1 any) any { var or__1927000174__auto____2 any = A_arbace_g2a_print_code_A_const_82.Invoke_O__O(en__1); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_g2a_print_code_A_const_111.Invoke_O__O(en__1) } }

func A_arbace_g2a_print_code_line_indent_A_New() *A_arbace_g2a_print_code_line_indent_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_line_indent_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_g2a_print_code_line_indent_A) Ctor() {}
//line :361:1
func (t *A_arbace_g2a_print_code_line_indent_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_133; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_134; return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } else { var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_135; return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))
	} }
func A_arbace_g2a_print_code_signature_A_New() *A_arbace_g2a_print_code_signature_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_signature_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_g2a_print_code_signature_A) Ctor() {}
//line :366:1
func (t *A_arbace_g2a_print_code_signature_A) Invoke_O_O_O_O__O(self, params__0, res__1, body__2 any) any { var r__4 any; if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(res__1)) { var en__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(res__1); var or__1927000174__auto____5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____5_2 any = A_arbace_g2a_print_code_A_const_82.Invoke_O__O(en__4); if jrt.A2g_Truth(or__1927000174__auto____5_2) { tmp2 = or__1927000174__auto____5_2 } else { tmp2 = A_arbace_g2a_print_code_A_const_111.Invoke_O__O(en__4) }; or__1927000174__auto____5 = tmp1.Invoke_O__O(tmp2); if jrt.A2g_Truth(or__1927000174__auto____5) { r__4 = or__1927000174__auto____5 } else { r__4 = A_arbace_g2a_print_code_A_const_101 } } else { r__4 = nil }; var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_code_A_const_62; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_137.GetRawRoot__O()).Invoke_O__O(body__2))); var tmp5 any; tmp6 := /*line :366:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_132.GetRawRoot__O()).Invoke_O_O__O(params__0, r__4)
		tmp5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_136.GetRawRoot__O()).Invoke_O__O(res__1)
//line :366:1
		return nil }();






	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if /*line :366:1*/ tmp6 != nil { panic(tmp6) }; return tmp5 }










func A_arbace_g2a_print_code_func_type_sig_A_New() *A_arbace_g2a_print_code_func_type_sig_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_func_type_sig_A{}; t.Ctor(); return t }
//line :377:1
func (t *A_arbace_g2a_print_code_func_type_sig_A) Ctor() {}
//line :377:1
func (t *A_arbace_g2a_print_code_func_type_sig_A) Invoke_O_O_O__O(self, params__0, results__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_138.GetRawRoot__O()); var tmp2 any; if jrt.A2g_Truth(results__1) { tmp2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(results__1) } else { lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY.Ref() }; return tmp1.Invoke_O_O_O__O(params__0, tmp2, nil)
}
func A_arbace_g2a_print_code_struct_tag_A_New() *A_arbace_g2a_print_code_struct_tag_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_struct_tag_A{}; t.Ctor(); return t }
//line :382:1
func (t *A_arbace_g2a_print_code_struct_tag_A) Ctor() {}
//line :382:1
func (t *A_arbace_g2a_print_code_struct_tag_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(s__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_87.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_146)); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_88.GetRawRoot__O()).Invoke_O__O(s__0) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_147, nil, Lit_147), jrt.RefArrayOf(jrt.Object_class, nil, s__0, nil)).Ref()) } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_91.GetRawRoot__O()).Invoke_O__O(s__0))
		} }
func A_arbace_g2a_print_code_doc_lines_A_New() *A_arbace_g2a_print_code_doc_lines_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_doc_lines_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_g2a_print_code_doc_lines_A) Ctor() {}
//line :387:1
func (t *A_arbace_g2a_print_code_doc_lines_A) Invoke_O_O__O(self, doc__0 any) any { var ls__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_139.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_72.GetRawRoot__O()).Invoke_O__O(doc__0), A_arbace_g2a_print_code_A_const_140, A_arbace_g2a_print_code_A_const_141); var ls__3 any; if

	lang.Util_Equiv_O_O__Z(Lit_69, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(ls__2)) { ls__3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_121.GetRawRoot__O()).Invoke_O__O(ls__2) } else { ls__3 = ls__2 }; return ls__3 }


func A_arbace_g2a_print_code_write_doc_A_New() *A_arbace_g2a_print_code_write_doc_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_write_doc_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_g2a_print_code_write_doc_A) Ctor() {}
//line :392:1
func (t *A_arbace_g2a_print_code_write_doc_A) Invoke_O_O_O__O(self, doc__0, indent__1 any) any {


	{ var tmp1 any; var and__1927000168__auto____3 any = doc__0; if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(doc__0, Lit_69) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { var seq_1022000099__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_143.GetRawRoot__O()).Invoke_O__O(doc__0)); var chunk_1022000100__4 any; var count_1022000101__5 int64 = 0; var i_1022000102__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1022000102__6, count_1022000101__5) { var l__7 any = lang.Indexed_Cast(chunk_1022000100__4).Nth_I__O(lang.RT_IntCast_J__I(i_1022000102__6)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_144.GetRawRoot__O()); var tmp3 *jrt.String
			if lang.Util_Equiv_O_O__Z(l__7, Lit_69) { tmp3 = Lit_209 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_145.GetRawRoot__O()).Invoke_O_O__O(l__7, Lit_210)) { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_209, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__7)) } else { if A_arbace_g2a_print_code_A_const_30 != nil { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_211, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__7)) } else { tmp3 = nil } } }; tmp2.Invoke_O_O__O(tmp3.Ref(), indent__1)
//line :396:1
			seq_1022000099__3, chunk_1022000100__4, count_1022000101__5, i_1022000102__6 = seq_1022000099__3, chunk_1022000100__4, count_1022000101__5, lang.Numbers_Unchecked_inc_J__J(i_1022000102__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000099__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1022000099__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000099__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000099__8); seq_1022000099__3, chunk_1022000100__4, count_1022000101__5, i_1022000102__6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000099__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var l__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000099__8); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_144.GetRawRoot__O()); var tmp5 *jrt.String
				if lang.Util_Equiv_O_O__Z(l__9, Lit_69) { tmp5 = Lit_209 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_145.GetRawRoot__O()).Invoke_O_O__O(l__9, Lit_210)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_209, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__9)) } else { if A_arbace_g2a_print_code_A_const_30 != nil { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_211, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__9)) } else { tmp5 = nil } } }; tmp4.Invoke_O_O__O(tmp5.Ref(), indent__1)
//line :396:1
				seq_1022000099__3, chunk_1022000100__4, count_1022000101__5, i_1022000102__6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000099__8), nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :395:1
					return nil } }
//line :392:1
	panic("a2g: unreachable")
}










func A_arbace_g2a_print_code_directives_of_A_New() *A_arbace_g2a_print_code_directives_of_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_directives_of_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_g2a_print_code_directives_of_A) Ctor() {}
//line :404:1
func (t *A_arbace_g2a_print_code_directives_of_A) Invoke_O_O__O(self, m__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_New(); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_fn_class; if




	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_152.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_153.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O(), A_arbace_g2a_print_code_A_const_155.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_154.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_directives_of_fn__1022000124_A_New(); var tmp8 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_print_code_directives_of_fn__1022000124_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_g2a_print_code_directives_of_fn__1022000124_A_fn_class = fncls__17d; tmp8 = fncls__17d } else { tmp8 = fncls__17 }; return tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), m__0))) }
//line :409:1
func A_arbace_g2a_print_code_directives_of_fn__1022000124_A_New() *A_arbace_g2a_print_code_directives_of_fn__1022000124_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_directives_of_fn__1022000124_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_fn__1022000124_A) Ctor() {}
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_fn__1022000124_A) Invoke_O_O__O(self, p__1022000123__1 any) any { var vec__1022000125__2 any = p__1022000123__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1022000125__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1022000125__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(k__3); _ = ___4; if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_26.GetRawRoot__O()).Invoke_O__O(k__3), Lit_62); if and__1927000168__auto____6 {
														return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_156.GetRawRoot__O()).Invoke_O__O(k__3)) } else {
//line :409:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else { return and__1927000168__auto____5 } }
//line :409:1
func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_New() *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A) Ctor() {}
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A) Invoke_O_O__O(self, s__1022000105__1 any) any { var tmp1 any = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_New_O_O(s__1022000105__1, self); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :409:1
func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A{}; t.Ctor_O_O(p0, p1); return t }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A) Ctor_O_O(c__s__1022000105, c__iter__1022000104 any) { t.F_s__1022000105 = c__s__1022000105; t.F_iter__1022000104 = c__iter__1022000104 }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A) Invoke_O__O(self any) any { { var s__1022000105__1 any; var t_ any = t.F_s__1022000105; t.F_s__1022000105 = nil; s__1022000105__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(s__1022000105__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1022000112__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1022000112__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1022000112__4, lang.RT_IntCast_J__I(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_New_O(k__5); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp5 any


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(v__6)) { tmp5 = v__6 } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(v__6) }
//line :409:1
	fs__1927001036__auto____8 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if jrt.A2g_Truth(fs__1927001036__auto____8) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1022000104); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_151.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____8, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1022000105__1))) } else { s__1022000105__1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1022000105__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :409:1
func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_New_O(p0 any) *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A{}; t.Ctor_O(p0); return t }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A) Invoke_O_O__O(self, s__1022000107__1 any) any { var tmp1 any = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_New_O_O_O(t.F_k, s__1022000107__1, self); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :409:1
func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A) Ctor_O_O_O(c__k, c__s__1022000107, c__iter__1022000106 any) { t.F_k = c__k; t.F_s__1022000107 = c__s__1022000107; t.F_iter__1022000106 = c__iter__1022000106 }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A) Invoke_O__O(self any) any { { var s__1022000107__1 any; var t_ any = t.F_s__1022000107; t.F_s__1022000107 = nil; s__1022000107__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(s__1022000107__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1022000107__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1022000107__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(s__1022000107__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1022000109__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_146.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_New_O_O_I_O(b__1022000109__6, t.F_k, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1022000106); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(b__1022000109__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(s__1022000107__3))) } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(b__1022000109__6), nil) } } else { var v__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1022000107__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_149.GetRawRoot__O()); var tmp5 *jrt.String



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_84.GetRawRoot__O()).Invoke_O__O(v__4)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(t.F_k))) } else { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(t.F_k), nil, v__4)) }
//line :409:1
	var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1022000106); return tmp4.Invoke_O_O__O(tmp5.Ref(), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1022000107__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :409:1
func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A) Ctor_O_O_I_O(c__b__1022000109, c__k any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1022000109 = c__b__1022000109; t.F_k = c__k; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :409:1
func (t *A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A) Invoke_O__O(self any) any { { var i__1022000108__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1022000108__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var v__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1022000108__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_147.GetRawRoot__O()); var tmp3 any = t.F_b__1022000109; var tmp4 *jrt.String



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_84.GetRawRoot__O()).Invoke_O__O(v__2)) { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(t.F_k))) } else { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(t.F_k), nil, v__2)) }
//line :409:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Ref()); i__1022000108__1 = lang.Numbers_Unchecked_inc_J__J(i__1022000108__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_g2a_print_code_pre_lines_A_New() *A_arbace_g2a_print_code_pre_lines_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_pre_lines_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_g2a_print_code_pre_lines_A) Ctor() {}
//line :415:1
func (t *A_arbace_g2a_print_code_pre_lines_A) Invoke_O_O_O__O(self, doc__0, dirs__1 any) any { var d__3 any; var tmp1 any; var and__1927000168__auto____3 any = doc__0; if



	jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(doc__0, Lit_69) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { d__3 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_143.GetRawRoot__O()).Invoke_O__O(doc__0))).Ref() } else { d__3 = A_arbace_g2a_print_code_A_const_157 }; var tmp2 int64; var tmp3 any; var and__1927000168__auto____4 bool =
	lang.Numbers_IsPos_O__Z(d__3); if and__1927000168__auto____4 { tmp3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(dirs__1) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() }; if jrt.A2g_Truth(tmp3) { tmp2 = 1 } else { tmp2 = 0 }; return lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_J__Number(d__3, tmp2), int64(lang.RT_Count_O__I(dirs__1))) }

func A_arbace_g2a_print_code_write_pre_A_New() *A_arbace_g2a_print_code_write_pre_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_write_pre_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_g2a_print_code_write_pre_A) Ctor() {}
//line :422:1
func (t *A_arbace_g2a_print_code_write_pre_A) Invoke_O_O_O_O__O(self, doc__0, dirs__1, indent__2 any) any {
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_158.GetRawRoot__O()).Invoke_O_O__O(doc__0, indent__2)
	{ var tmp1 any; var and__1927000168__auto____4 any = doc__0; if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(doc__0, Lit_69); if jrt.A2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(dirs__1) } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_144.GetRawRoot__O()).Invoke_O_O__O(Lit_209, indent__2) }
//line :422:1
		var seq_1022000131__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(dirs__1); var chunk_1022000132__5 any; var count_1022000133__6 int64 = 0; var i_1022000134__7 int64 = 0; L1: for {


			if lang.Numbers_Lt_J_J__Z(i_1022000134__7, count_1022000133__6) { var d__8 any = lang.Indexed_Cast(chunk_1022000132__5).Nth_I__O(lang.RT_IntCast_J__I(i_1022000134__7)); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_144.GetRawRoot__O()).Invoke_O_O__O(d__8, indent__2); seq_1022000131__4, chunk_1022000132__5, count_1022000133__6, i_1022000134__7 = seq_1022000131__4, chunk_1022000132__5, count_1022000133__6, lang.Numbers_Unchecked_inc_J__J(i_1022000134__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000131__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1022000131__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000131__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000131__9); seq_1022000131__4, chunk_1022000132__5, count_1022000133__6, i_1022000134__7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000131__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var d__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000131__9); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_144.GetRawRoot__O()).Invoke_O_O__O(d__10, indent__2); seq_1022000131__4, chunk_1022000132__5, count_1022000133__6, i_1022000134__7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000131__9), nil, 0, 0; continue L1 } } else { return nil } } } }
//line :422:1
	panic("a2g: unreachable")
}



func A_arbace_g2a_print_code_interface_method_QMARK__A_New() *A_arbace_g2a_print_code_interface_method_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_interface_method_QMARK__A{}; t.Ctor(); return t }
//line :427:1
func (t *A_arbace_g2a_print_code_interface_method_QMARK__A) Ctor() {}
//line :427:1
func (t *A_arbace_g2a_print_code_interface_method_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(x__0); if
												jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(x__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(x__0)), nil); if and__1927000168__auto____4 { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(x__0)); if jrt.A2g_Truth(and__1927000168__auto____5) {
													return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(x__0), Lit_26) } else {
//line :428:1
			return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_g2a_print_code_iface_method_sig_A_New() *A_arbace_g2a_print_code_iface_method_sig_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_iface_method_sig_A{}; t.Ctor(); return t }
//line :431:1
func (t *A_arbace_g2a_print_code_iface_method_sig_A) Ctor() {}
//line :431:1
func (t *A_arbace_g2a_print_code_iface_method_sig_A) Invoke_O_O_O__O(self, params__0, more__1 any) any { var results__3 any; if



	lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(more__1), A_arbace_g2a_print_code_A_const_159) { results__3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(more__1) } else { results__3 = nil }; return /*line :436:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_138.GetRawRoot__O()).Invoke_O_O_O__O(params__0, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_160.GetRawRoot__O()).Invoke_O_O__O(params__0, results__3), nil) }



func A_arbace_g2a_print_code_one_line_fields_QMARK__A_New() *A_arbace_g2a_print_code_one_line_fields_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_one_line_fields_QMARK__A{}; t.Ctor(); return t }
//line :440:1
func (t *A_arbace_g2a_print_code_one_line_fields_QMARK__A) Ctor() {}
//line :440:1
func (t *A_arbace_g2a_print_code_one_line_fields_QMARK__A) Invoke_O_O_O__O(self, groups__0, struct_QMARK___1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(groups__0))); if and__1927000168__auto____3 {



	var g__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(groups__0); var m__5 any = A_arbace_g2a_print_code_A_const_113.Invoke_O__O(g__4); var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_115.Invoke_O__O(m__5))


	if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_114.Invoke_O__O(m__5)); if jrt.A2g_Truth(and__1927000168__auto____7) { var x__8 any = A_arbace_g2a_print_code_A_const_82.Invoke_O__O(g__4); var method_QMARK___9 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(struct_QMARK___1)

		if jrt.A2g_Truth(and__1927000168__auto____9) { method_QMARK___9 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_161.GetRawRoot__O()).Invoke_O__O(x__8) } else { method_QMARK___9 = and__1927000168__auto____9 }
//line :447:1
		var names_QMARK___10 any


		if jrt.A2g_Truth(struct_QMARK___1) { names_QMARK___10 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__4)) } else { names_QMARK___10 = method_QMARK___9 }
//line :447:1
		var text__11 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_162.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_New_O_O_O(g__4, x__8, method_QMARK___9); var tmp3 *jrt.Class
		var fncls__18 /*line :447:1*/*jrt.Class = A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_fn_class




		if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_149, false); A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }
//line :451:1
		text__11 = tmp1.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))
//line :447:1
		var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_87.GetRawRoot__O()).Invoke_O_O__O(text__11, Lit_146))







		if jrt.A2g_Truth(and__1927000168__auto____12) {
			var tmp4 int64; if jrt.A2g_Truth(names_QMARK___10) { tmp4 = 1 } else { tmp4 = 0 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lte_J_J__Z(lang.Numbers_Add_J_J__J(tmp4, int64(lang.RT_Count_O__I(text__11))), 30)).Ref() } else {
//line :455:1
				return and__1927000168__auto____12 } } else {
//line :447:1
					return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else {
//line :444:1
						return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }







func A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :452:1
func (t *A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A) Ctor_O_O_O(c__g, c__x, c__method_QMARK_ any) { t.F_g = c__g; t.F_x = c__x; t.F_method_QMARK_ = c__method_QMARK_ }
//line :452:1
func (t *A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A) Invoke_O__O(self any) any { if jrt.A2g_Truth(t.F_method_QMARK_) {
													lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_26); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_163.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(t.F_x), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(t.F_x)) } else {
														return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_111.Invoke_O_O__O(t.F_g, t.F_x)) } }



func A_arbace_g2a_print_code_struct_fields_A_New() *A_arbace_g2a_print_code_struct_fields_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_struct_fields_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_g2a_print_code_struct_fields_A) Ctor() {}
//line :458:1
func (t *A_arbace_g2a_print_code_struct_fields_A) Invoke_O_O__O(self, fs__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_124.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_New(); var tmp4 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_183, false); A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_fn_class = fncls__21d; tmp4 = fncls__21d } else { tmp4 = fncls__21 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(fs__0); return tmp1.Invoke_O__O(tmp2) }
//line :459:1
func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_New() *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A{}; t.Ctor(); return t }
//line :459:1
func (t *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A) Ctor() {}
//line :459:1
func (t *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A) Invoke_O_O__O(self, s__1022000142__1 any) any { var tmp1 any = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_New_O_O(s__1022000142__1, self); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_184, false); A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :459:1
func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A{}; t.Ctor_O_O(p0, p1); return t }
//line :459:1
func (t *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A) Ctor_O_O(c__s__1022000142, c__iter__1022000141 any) { t.F_s__1022000142 = c__s__1022000142; t.F_iter__1022000141 = c__iter__1022000141 }
//line :459:1
func (t *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A) Invoke_O__O(self any) any { { var s__1022000142__1 any; var t_ any = t.F_s__1022000142; t.F_s__1022000142 = nil; s__1022000142__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(s__1022000142__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1022000142__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1022000142__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(s__1022000142__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1022000144__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_146.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_New_O_I_O(b__1022000144__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_185, false); A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1022000141); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(b__1022000144__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(s__1022000142__3))) } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(b__1022000144__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1022000142__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_149.GetRawRoot__O()); var tmp5 lang.IPersistentMap
															if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_109.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp6 any = A_arbace_g2a_print_code_A_const_110; var tmp7 any = A_arbace_g2a_print_code_A_const_111; var tmp8 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; var tmp9 any = tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__4)); var tmp10 any = A_arbace_g2a_print_code_A_const_113; tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, f__4, tmp7, tmp9, tmp10, lang.RT_Meta_O__IPersistentMap(f__4), A_arbace_g2a_print_code_A_const_82, f__4)) } else { var tmp11 any = A_arbace_g2a_print_code_A_const_110; var tmp12 any = A_arbace_g2a_print_code_A_const_111; var tmp13 any = A_arbace_g2a_print_code_A_const_113; tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, nil, tmp12, f__4, tmp13, lang.RT_Meta_O__IPersistentMap(f__4), A_arbace_g2a_print_code_A_const_82, f__4)) }
//line :459:1
	var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1022000141); return tmp4.Invoke_O_O__O(tmp5, tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1022000142__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :459:1
func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :459:1
func (t *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A) Ctor_O_I_O(c__b__1022000144 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1022000144 = c__b__1022000144; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :459:1
func (t *A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A) Invoke_O__O(self any) any { { var i__1022000143__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1022000143__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1022000143__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_147.GetRawRoot__O()); var tmp3 any = t.F_b__1022000144; var tmp4 lang.IPersistentMap
																	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_109.GetRawRoot__O()).Invoke_O__O(f__2)) { var tmp5 any = A_arbace_g2a_print_code_A_const_110; var tmp6 any = A_arbace_g2a_print_code_A_const_111; var tmp7 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; var tmp8 any = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__2)); var tmp9 any = A_arbace_g2a_print_code_A_const_113; tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, f__2, tmp6, tmp8, tmp9, lang.RT_Meta_O__IPersistentMap(f__2), A_arbace_g2a_print_code_A_const_82, f__2)) } else { var tmp10 any = A_arbace_g2a_print_code_A_const_110; var tmp11 any = A_arbace_g2a_print_code_A_const_111; var tmp12 any = A_arbace_g2a_print_code_A_const_113; tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, f__2, tmp12, lang.RT_Meta_O__IPersistentMap(f__2), A_arbace_g2a_print_code_A_const_82, f__2)) }
//line :459:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1022000143__1 = lang.Numbers_Unchecked_inc_J__J(i__1022000143__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_g2a_print_code_field_body_A_New() *A_arbace_g2a_print_code_field_body_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_body_A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_g2a_print_code_field_body_A) Ctor() {}
//line :464:1
func (t *A_arbace_g2a_print_code_field_body_A) Invoke_O_O_O_O__O(self, g__0, struct_QMARK___1, sep__2 any) any {


	if jrt.A2g_Truth(struct_QMARK___1) {

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__0))) {
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_128.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__0))
			lang.IFn_Cast(sep__2).Invoke__O()
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_111.Invoke_O__O(g__0)) } else {
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_111.Invoke_O__O(g__0)) }
//line :467:1
		var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_115; var temp__1927000414__auto____4 any = tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(g__0))






		if jrt.A2g_Truth(temp__1927000414__auto____4) { var t__5 any = temp__1927000414__auto____4; var tmp2 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__0))
			if jrt.A2g_Truth(and__1927000168__auto____6) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(sep__2, A_arbace_g2a_print_code_A_const_166.GetRawRoot__O())).Ref() } else { tmp2 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp2) { lang.IFn_Cast(sep__2).Invoke__O() }
			lang.IFn_Cast(sep__2).Invoke__O()
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_165.GetRawRoot__O()).Invoke_O__O(t__5) } else {
//line :474:1
				return nil } } else {
//line :467:1
					var x__4 any = A_arbace_g2a_print_code_A_const_82.Invoke_O__O(g__0)











					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_161.GetRawRoot__O()).Invoke_O__O(x__4)) {
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(x__4))); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_163.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(x__4), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(x__4)) } else {
							return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(x__4)
						} } }
func A_arbace_g2a_print_code_field_list_A_New() *A_arbace_g2a_print_code_field_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_g2a_print_code_field_list_A) Ctor() {}
//line :483:1
func (t *A_arbace_g2a_print_code_field_list_A) Invoke_O_O_O_O__O(self, kw__0, fs__1, struct_QMARK___2 any) any { var groups__4 any; if


	jrt.A2g_Truth(struct_QMARK___2) {
		groups__4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_167.GetRawRoot__O()).Invoke_O__O(fs__1) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__1); groups__4 = tmp1.Invoke_O__O(tmp2) }; var tmp5 /*line :483:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_17; var start__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); var ts__6 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_field_list_fn__1022000164_A_New(); var tmp8 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_g2a_print_code_field_list_fn__1022000164_A_fn_class; if






	fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_112, false); A_arbace_g2a_print_code_field_list_fn__1022000164_A_fn_class = fncls__25d; tmp8 = fncls__25d } else { tmp8 = fncls__25 }; ts__6 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), groups__4); var breaks_QMARK___7 any; var tmp9 /*line :483:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____7 any = tmp9.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()); if







	jrt.A2g_Truth(and__1927000168__auto____7) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp11 any = A_arbace_g2a_print_code_field_list_fn__1022000166_A_New_O(start__5); var tmp12 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_g2a_print_code_field_list_fn__1022000166_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); A_arbace_g2a_print_code_field_list_fn__1022000166_A_fn_class = fncls__26d; tmp12 = fncls__26d } else { tmp12 = fncls__26 }; breaks_QMARK___7 = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), ts__6) } else { breaks_QMARK___7 = and__1927000168__auto____7 }; var docs_QMARK___8 any; var tmp13 lang.IFn = /*line :483:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_print_code_field_list_fn__1022000168_A_New(); var tmp15 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_g2a_print_code_field_list_fn__1022000168_A_fn_class; if








	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_g2a_print_code_field_list_fn__1022000168_A_fn_class = fncls__27d; tmp15 = fncls__27d } else { tmp15 = fncls__27 }; docs_QMARK___8 = tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), groups__4); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_131.GetRawRoot__O()).Invoke_O__O(groups__4)) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_115), jrt.RefArrayOf(jrt.Object_class, kw__0, nil)).Ref()) } else {
//line :493:1
			var tmp16 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(breaks_QMARK___7)

			if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(docs_QMARK___8); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp17 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; var or__1927000174__auto____11 any = tmp17.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()); if jrt.A2g_Truth(or__1927000174__auto____11) { tmp16 = or__1927000174__auto____11 } else { tmp16 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_168.GetRawRoot__O()).Invoke_O_O__O(groups__4, struct_QMARK___2) } } else { tmp16 = and__1927000168__auto____10 } } else { tmp16 = and__1927000168__auto____9 }
//line :493:1
			if jrt.A2g_Truth(tmp16) {


				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, kw__0, nil)).Ref()); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
//line :493:1
				var seq_1022000170__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_78.GetRawRoot__O(), groups__4)); var chunk_1022000171__10 any; var count_1022000172__11 int64 = 0; var i_1022000173__12 int64 = 0; L1: for {



					if lang.Numbers_Lt_J_J__Z(i_1022000173__12, count_1022000172__11) { var vec__1022000174__13 any = lang.Indexed_Cast(chunk_1022000171__10).Nth_I__O(lang.RT_IntCast_J__I(i_1022000173__12)); var i__14 any = lang.RT_Nth_O_I_O__O(vec__1022000174__13, lang.RT_IntCast_J__I(0), nil); var g__15 any = lang.RT_Nth_O_I_O__O(vec__1022000174__13, lang.RT_IntCast_J__I(1), nil)
						if lang.Numbers_IsPos_O__Z(i__14) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_170.GetRawRoot__O()).Invoke_O_O_O__O(g__15, struct_QMARK___2, A_arbace_g2a_print_code_A_const_68.GetRawRoot__O())
//line :497:1
						seq_1022000170__9, chunk_1022000171__10, count_1022000172__11, i_1022000173__12 = seq_1022000170__9, chunk_1022000171__10, count_1022000172__11, lang.Numbers_Unchecked_inc_J__J(i_1022000173__12); continue L1 } else { var temp__1927000414__auto____13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000170__9); if jrt.A2g_Truth(temp__1927000414__auto____13) { var seq_1022000170__14 any = temp__1927000414__auto____13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000170__14)) { var c__1927000678__auto____15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000170__14); seq_1022000170__9, chunk_1022000171__10, count_1022000172__11, i_1022000173__12 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000170__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1022000177__15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000170__14); var i__16 any = lang.RT_Nth_O_I_O__O(vec__1022000177__15, lang.RT_IntCast_J__I(0), nil); var g__17 any = lang.RT_Nth_O_I_O__O(vec__1022000177__15, lang.RT_IntCast_J__I(1), nil)
							if lang.Numbers_IsPos_O__Z(i__16) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_170.GetRawRoot__O()).Invoke_O_O_O__O(g__17, struct_QMARK___2, A_arbace_g2a_print_code_A_const_68.GetRawRoot__O())
//line :497:1
							seq_1022000170__9, chunk_1022000171__10, count_1022000172__11, i_1022000173__12 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000170__14), nil, 0, 0; continue L1 } } }
//line :493:1
					break L1
				}





				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_19) } else {
//line :493:1
					if A_arbace_g2a_print_code_A_const_30 != nil { var indent__9 any
						var tmp18 /*line :493:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_133








						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))) { var tmp19 *lang.Keyword = A_arbace_g2a_print_code_A_const_134; indent__9 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } else { var tmp20 *lang.Keyword = A_arbace_g2a_print_code_A_const_135; indent__9 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) }
//line :493:1
						var sep__10 any; var tmp21 any
						var and__1927000168__auto____10_2 any = struct_QMARK___2








						if jrt.A2g_Truth(and__1927000168__auto____10_2) { tmp21 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(groups__4)))).Ref() } else { tmp21 = and__1927000168__auto____10_2 }; if jrt.A2g_Truth(tmp21) { sep__10 = A_arbace_g2a_print_code_A_const_68.GetRawRoot__O() } else { sep__10 = A_arbace_g2a_print_code_A_const_166.GetRawRoot__O() }
//line :493:1
						var tmp22 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var last_start__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_169.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp22.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))











						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(kw__0); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_17)
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(indent__9)
//line :493:1
						var n__1927000701__auto____12 int64 = lang.RT_LongCast_I__J(lang.RT_Count_O__I(groups__4)); var i__13 int64 = 0; L2: for {













							if lang.Numbers_Lt_J_J__Z(i__13, n__1927000701__auto____12) { var g__14 any = lang.RT_Nth_O_I__O(groups__4, lang.RT_IntCast_J__I(i__13)); var tmp23 *lang.Keyword = A_arbace_g2a_print_code_A_const_114; var doc__15 any = tmp23.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(g__14)); var pre__16 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_172.GetRawRoot__O()); var tmp25 *lang.PersistentVector


								lang.PersistentVector_Init(); tmp25 = lang.PersistentVector_EMPTY; pre__16 = tmp24.Invoke_O_O__O(doc__15, tmp25.Ref())
//line :507:1
								var t__17 any = lang.RT_Nth_O_I__O(ts__6, lang.RT_IntCast_J__I(i__13)); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp27 any = A_arbace_g2a_print_code_A_const_62; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_53.GetRawRoot__O())
								var tmp29 any = A_arbace_g2a_print_code_A_const_82



								lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_137.GetRawRoot__O()).Invoke_O__O(tmp28.Invoke_O_O__O(tmp29, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_175.GetRawRoot__O()).Invoke_O_O__O(groups__4, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(i__13)).Ref()))))); var tmp30 any = A_arbace_g2a_print_code_field_list_fn__1022000180_A_New_O_O_O_O_O_O_O_O_J(indent__9, t__17, struct_QMARK___2, doc__15, last_start__11, pre__16, sep__10, g__14, i__13); var tmp31 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_g2a_print_code_field_list_fn__1022000180_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_g2a_print_code_field_list_fn__1022000180_A_fn_class = fncls__28d; tmp31 = fncls__28d } else { tmp31 = fncls__28 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil).Invoke__O()
//line :507:1
								i__13 = lang.Numbers_Unchecked_inc_J__J(i__13); continue L2 }
//line :493:1
							break L2
						}




























						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O()
						var tmp32 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp32.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) {
							var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_105.GetRawRoot__O()); var tmp34 *jrt.Boolean; jrt.Boolean_Init(); tmp34 = jrt.Boolean_TRUE; var tmp35 any = tmp34.Ref(); var tmp36 *jrt.Boolean; jrt.Boolean_Init(); tmp36 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp33.Invoke_O_O_O_O__O(nil, tmp35, tmp36.Ref(), indent__9)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() } } else {
								var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_171.GetRawRoot__O()); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; tmp37.Invoke_O_O__O(indent__9, tmp38.Ref()) }
						return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_19) } else {
//line :493:1
							return nil } } } }
//line :488:1
func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_New() *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A) Ctor() {}
//line :488:1
func (t *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A) Invoke_O_O__O(self, s__1022000155__1 any) any { var tmp1 any = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_New_O_O(s__1022000155__1, self); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :488:1
func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A{}; t.Ctor_O_O(p0, p1); return t }
//line :488:1
func (t *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A) Ctor_O_O(c__s__1022000155, c__iter__1022000154 any) { t.F_s__1022000155 = c__s__1022000155; t.F_iter__1022000154 = c__iter__1022000154 }
//line :488:1
func (t *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A) Invoke_O__O(self any) any { { var s__1022000155__1 any; var t_ any = t.F_s__1022000155; t.F_s__1022000155 = nil; s__1022000155__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(s__1022000155__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1022000155__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1022000155__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(s__1022000155__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1022000157__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_146.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_New_I_O_O(size__1927001038__auto____5, b__1022000157__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1022000154); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(b__1022000157__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(s__1022000155__3))) } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(b__1022000157__6), nil) } } else { var x__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1022000155__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_149.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_code_A_const_82; var tmp6 any = A_arbace_g2a_print_code_A_const_113; var tmp7 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_161.GetRawRoot__O()).Invoke_O__O(x__4)) { tmp7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(x__4) } else { tmp7 = x__4 }; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1022000154); return tmp4.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, x__4, tmp6, lang.RT_Meta_O__IPersistentMap(tmp7))), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1022000155__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :488:1
func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :488:1
func (t *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1022000157, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1022000157 = c__b__1022000157; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :488:1
func (t *A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A) Invoke_O__O(self any) any { { var i__1022000156__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1022000156__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1022000156__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_147.GetRawRoot__O()); var tmp3 any = t.F_b__1022000157; var tmp4 any = A_arbace_g2a_print_code_A_const_82; var tmp5 any = A_arbace_g2a_print_code_A_const_113; var tmp6 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_161.GetRawRoot__O()).Invoke_O__O(x__2)) { tmp6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(x__2) } else { tmp6 = x__2 }; tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, x__2, tmp5, lang.RT_Meta_O__IPersistentMap(tmp6)))); i__1022000156__1 = lang.Numbers_Unchecked_inc_J__J(i__1022000156__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_print_code_field_list_fn__1022000164_A_New() *A_arbace_g2a_print_code_field_list_fn__1022000164_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_fn__1022000164_A{}; t.Ctor(); return t }
//line :490:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000164_A) Ctor() {}
//line :490:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000164_A) Invoke_O_O__O(self, g__1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_82.Invoke_O__O(g__1)); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__1))) } }
func A_arbace_g2a_print_code_field_list_fn__1022000166_A_New_O(p0 any) *A_arbace_g2a_print_code_field_list_fn__1022000166_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_fn__1022000166_A{}; t.Ctor_O(p0); return t }
//line :491:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000166_A) Ctor_O(c__start any) { t.F_start = c__start }
//line :491:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000166_A) Invoke_O_O__O(self, p1__1022000153_SHARP___1 any) any { var and__1927000168__auto____2 any = p1__1022000153_SHARP___1; if jrt.A2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(p1__1022000153_SHARP___1), t.F_start)).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_g2a_print_code_field_list_fn__1022000168_A_New() *A_arbace_g2a_print_code_field_list_fn__1022000168_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_fn__1022000168_A{}; t.Ctor(); return t }
//line :492:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000168_A) Ctor() {}
//line :492:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000168_A) Invoke_O_O__O(self, g__1 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_114; return tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_113.Invoke_O__O(g__1)) }



















func A_arbace_g2a_print_code_field_list_fn__1022000180_A_New_O_O_O_O_O_O_O_O_J(p0, p1, p2, p3, p4, p5, p6, p7 any, p8 int64) *A_arbace_g2a_print_code_field_list_fn__1022000180_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_field_list_fn__1022000180_A{}; t.Ctor_O_O_O_O_O_O_O_O_J(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :512:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000180_A) Ctor_O_O_O_O_O_O_O_O_J(c__indent, c__t, c__struct_QMARK_, c__doc, c__last_start, c__pre, c__sep, c__g any, c__i int64) { t.F_indent = c__indent; t.F_t = c__t; t.F_struct_QMARK_ = c__struct_QMARK_; t.F_doc = c__doc; t.F_last_start = c__last_start; t.F_pre = c__pre; t.F_sep = c__sep; t.F_g = c__g; t.F_i = c__i }
//line :512:1
func (t *A_arbace_g2a_print_code_field_list_fn__1022000180_A) Invoke_O__O(self any) any { var tmp1 any; tmp39 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))) {
												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_171.GetRawRoot__O()); var tmp4 any = lang.Numbers_Inc_O__Number(t.F_indent); var tmp5 *jrt.Boolean; var or__1927000174__auto____3 bool = lang.Numbers_IsZero_J__Z(t.F_i); if or__1927000174__auto____3 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3) } else { var tmp6 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_last_start))) }; tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()) } else {
//line :513:1
			var tmp7 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(t.F_t)

			if jrt.A2g_Truth(and__1927000168__auto____3) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(t.F_pre)).Ref() } else { tmp7 = and__1927000168__auto____3 }
//line :513:1
			if jrt.A2g_Truth(tmp7) {

				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp9 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var tmp10 any = lang.Numbers_Max_O_O__O(lang.Numbers_Minus_J_O__Number(lang.RT_LongCast_O__J(t.F_t), t.F_pre), lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_FALSE; var tmp12 any = tmp11.Ref(); tmp8.Invoke_O_O_O_O__O(tmp10, tmp12, Lit_36, lang.Numbers_Inc_O__Number(t.F_indent)) } else {
//line :513:1
					if lang.Numbers_IsPos_O__Z(t.F_pre) {


						var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_print_code_A_const_57; var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_FALSE; var tmp16 any = tmp15.Ref(); tmp13.Invoke_O_O_O_O__O(tmp14, tmp16, Lit_36, lang.Numbers_Inc_O__Number(t.F_indent)) } else {
//line :513:1
							if A_arbace_g2a_print_code_A_const_30 != nil {



								var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp18 any = t.F_t; tmp17.Invoke_O_O_O_O__O(tmp18, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(t.F_i)).Ref(), Lit_36, lang.Numbers_Inc_O__Number(t.F_indent)) } } } }
		var tmp19 any; var t_ any = t.F_pre; t.F_pre = nil; tmp19 = t_; if lang.Numbers_IsPos_O__Z(tmp19) {
			var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_158.GetRawRoot__O()); var tmp21 any; var t__2 any = t.F_doc; t.F_doc = nil; tmp21 = t__2; tmp20.Invoke_O_O__O(tmp21, lang.Numbers_Inc_O__Number(t.F_indent))
			var tmp22 any; var tmp23 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____3_2 any = tmp23.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()); if jrt.A2g_Truth(and__1927000168__auto____3_2) { tmp22 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(t.F_t) } else { tmp22 = and__1927000168__auto____3_2 }; if jrt.A2g_Truth(tmp22) { var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp25 any; var t__3 any = t.F_t; t.F_t = nil; tmp25 = t__3; var tmp26 any = tmp25; var tmp27 *jrt.Boolean; jrt.Boolean_Init(); tmp27 = jrt.Boolean_TRUE; var tmp28 any = tmp27.Ref(); var tmp29 any; var t__4 any = t.F_indent; t.F_indent = nil; tmp29 = t__4; tmp24.Invoke_O_O_O_O__O(tmp26, tmp28, nil, lang.Numbers_Inc_O__Number(tmp29)) } }
		var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_174.GetRawRoot__O()); var tmp31 any; var t__5 any = t.F_last_start; t.F_last_start = nil; tmp31 = t__5; var tmp32 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; tmp30.Invoke_O_O__O(tmp31, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp32.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))
		var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_170.GetRawRoot__O()); var tmp34 any; var t__6 any = t.F_g; t.F_g = nil; tmp34 = t__6; var tmp35 any = tmp34; var tmp36 any; var t__7 any = t.F_struct_QMARK_; t.F_struct_QMARK_ = nil; tmp36 = t__7; var tmp37 any = tmp36; var tmp38 any; var t__8 any = t.F_sep; t.F_sep = nil; tmp38 = t__8; tmp1 = tmp33.Invoke_O_O_O__O(tmp35, tmp37, tmp38) }
//line :512:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp39 != nil { panic(tmp39) }; return tmp1 }
















func A_arbace_g2a_print_code_chan_type_A_New() *A_arbace_g2a_print_code_chan_type_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_chan_type_A{}; t.Ctor(); return t }
//line :529:1
func (t *A_arbace_g2a_print_code_chan_type_A) Ctor() {}
//line :529:1
func (t *A_arbace_g2a_print_code_chan_type_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000183__2 any = f__0; var ___3 any = lang.RT_Nth_O_I_O__O(vec__1022000183__2, lang.RT_IntCast_J__I(0), nil); var a__4 any = lang.RT_Nth_O_I_O__O(vec__1022000183__2, lang.RT_IntCast_J__I(1), nil); var b__5 any = lang.RT_Nth_O_I_O__O(vec__1022000183__2, lang.RT_IntCast_J__I(2), nil); var dir__6 any; _ = ___3; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(a__4)) { dir__6 = a__4 } else { dir__6 = nil }; var elem__7 any; if
	jrt.A2g_Truth(dir__6) { elem__7 = b__5 } else { elem__7 = a__4 }; var G__1022000186__8_ any = dir__6; L1:
	switch { default: switch lang.Util_Hash_O__I(G__1022000186__8_) >> 8 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__1022000186__8_, nil) {


		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_31)
//line :533:1
		break L1 }; case 1: if lang.Util_Equiv_O_O__Z(G__1022000186__8_, A_arbace_g2a_print_code_A_const_177) {

			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_31); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_32)
//line :533:1
			break L1 }; case 2: if lang.Util_Equiv_O_O__Z(G__1022000186__8_, A_arbace_g2a_print_code_A_const_176) {
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_32); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_31)
//line :533:1
				break L1 }; default:
	}


		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_33, f__0)};
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp1 any; var and__1927000168__auto____8 any =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(dir__6, A_arbace_g2a_print_code_A_const_176); if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(elem__7); if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(elem__7), Lit_31); if and__1927000168__auto____10 { var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(elem__7), A_arbace_g2a_print_code_A_const_176); if and__1927000168__auto____11 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(dir__6, nil)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 }; if jrt.A2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(elem__7); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(elem__7) } }

func A_arbace_g2a_print_code_type_list_A_New() *A_arbace_g2a_print_code_type_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_list_A{}; t.Ctor(); return t }
//line :543:1
func (t *A_arbace_g2a_print_code_type_list_A) Ctor() {}
//line :543:1
func (t *A_arbace_g2a_print_code_type_list_A) Invoke_O_O__O(self, ts__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_125.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_type_list_fn__1022000188_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_g2a_print_code_type_list_fn__1022000188_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_200, false); A_arbace_g2a_print_code_type_list_fn__1022000188_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O_O_O__O(Lit_97, Lit_99, ts__0, tmp4, tmp5.Ref()) }
//line :546:1
func A_arbace_g2a_print_code_type_list_fn__1022000188_A_New() *A_arbace_g2a_print_code_type_list_fn__1022000188_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_list_fn__1022000188_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_g2a_print_code_type_list_fn__1022000188_A) Ctor() {}
//line :546:1
func (t *A_arbace_g2a_print_code_type_list_fn__1022000188_A) Invoke_O_O_O__O(self, t__1, ___2 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__1) }

func A_arbace_g2a_print_code_type_expr_A_New() *A_arbace_g2a_print_code_type_expr_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_expr_A{}; t.Ctor(); return t }
//line :548:1
func (t *A_arbace_g2a_print_code_type_expr_A) Ctor() {}
//line :548:1
func (t *A_arbace_g2a_print_code_type_expr_A) Invoke_O_O__O(self, f__0 any) any {


	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(f__0))
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(f__0)) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :552:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0)) { var o__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)
				var G__1022000191__3_ any = o__2


				switch lang.Util_Hash_O__I(G__1022000191__3_) >> 0 & 127 { case 18: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_191) {

					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_97); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_99); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :556:1
				case 34: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_83) {



















					return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :556:1
				case 42: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_4) {
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_4); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :556:1
				case 57: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_192) {













					var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_178.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(f__0); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O_O__O(Lit_192, tmp2, tmp3.Ref()) }
//line :556:1
				case 68: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_26) { var vec__1022000192__4 any = f__0; var ___5 any = lang.RT_Nth_O_I_O__O(vec__1022000192__4, lang.RT_IntCast_J__I(0), nil); var params__6 any = lang.RT_Nth_O_I_O__O(vec__1022000192__4, lang.RT_IntCast_J__I(1), nil); var results__7 any = lang.RT_Nth_O_I_O__O(vec__1022000192__4, lang.RT_IntCast_J__I(2), nil); _ = ___5











					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_26); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_180.GetRawRoot__O()).Invoke_O_O__O(params__6, results__7) }
//line :556:1
				case 70: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_91) {


















					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :556:1
				case 82: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_31) {









					return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_182.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :556:1
				case 85: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_193) {












					var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_178.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(f__0); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return tmp4.Invoke_O_O_O__O(Lit_193, tmp5, tmp6.Ref()) }
//line :556:1
				case 88: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_194) {

















					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_195); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :556:1
				case 89: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_196) { var vec__1022000195__4 any = f__0; var ___5_2 any = lang.RT_Nth_O_I_O__O(vec__1022000195__4, lang.RT_IntCast_J__I(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O(vec__1022000195__4, lang.RT_IntCast_J__I(1), nil); var t__7 any = lang.RT_Nth_O_I_O__O(vec__1022000195__4, lang.RT_IntCast_J__I(2), nil); _ = ___5_2



					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_97)
					if lang.Util_Equiv_O_O__Z(n__6, A_arbace_g2a_print_code_A_const_183) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_25) } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_print_code_A_const_185; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10.Ref())); var tmp11 any = A_arbace_g2a_print_code_type_expr_fn__1022000198_A_New_O(n__6); var tmp12 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_g2a_print_code_type_expr_fn__1022000198_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_197, false); A_arbace_g2a_print_code_type_expr_fn__1022000198_A_fn_class = fncls__32d; tmp12 = fncls__32d } else { tmp12 = fncls__32 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O() }
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_99)
					return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__7) }
//line :556:1
				case 92: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_198) { var vec__1022000200__4 any = f__0; var ___5_3 any = lang.RT_Nth_O_I_O__O(vec__1022000200__4, lang.RT_IntCast_J__I(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O(vec__1022000200__4, lang.RT_IntCast_J__I(1), nil); var v__7 any = lang.RT_Nth_O_I_O__O(vec__1022000200__4, lang.RT_IntCast_J__I(2), nil); _ = ___5_3








					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_198); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_97); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(k__6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_99); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(v__7) }
//line :556:1
				case 124: if lang.Util_Equiv_O_O__Z(G__1022000191__3_, Lit_5) { var seq_1022000203__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_78.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(f__0))); var chunk_1022000204__5 any; var count_1022000205__6 int64 = 0; var i_1022000206__7 int64 = 0; L2: for {














					if lang.Numbers_Lt_J_J__Z(i_1022000206__7, count_1022000205__6) { var vec__1022000207__8 any = lang.Indexed_Cast(chunk_1022000204__5).Nth_I__O(lang.RT_IntCast_J__I(i_1022000206__7)); var i__9 any = lang.RT_Nth_O_I_O__O(vec__1022000207__8, lang.RT_IntCast_J__I(0), nil); var t__10 any = lang.RT_Nth_O_I_O__O(vec__1022000207__8, lang.RT_IntCast_J__I(1), nil)
						if lang.Numbers_IsPos_O__Z(i__9) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_5); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__10)
//line :571:1
						seq_1022000203__4, chunk_1022000204__5, count_1022000205__6, i_1022000206__7 = seq_1022000203__4, chunk_1022000204__5, count_1022000205__6, lang.Numbers_Unchecked_inc_J__J(i_1022000206__7); continue L2 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000203__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1022000203__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000203__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000203__9); seq_1022000203__4, chunk_1022000204__5, count_1022000205__6, i_1022000206__7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000203__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var vec__1022000210__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000203__9); var i__11 any = lang.RT_Nth_O_I_O__O(vec__1022000210__10, lang.RT_IntCast_J__I(0), nil); var t__12 any = lang.RT_Nth_O_I_O__O(vec__1022000210__10, lang.RT_IntCast_J__I(1), nil)
							if lang.Numbers_IsPos_O__Z(i__11) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_5); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__12)
//line :571:1
							seq_1022000203__4, chunk_1022000204__5, count_1022000205__6, i_1022000206__7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000203__9), nil, 0, 0; continue L2 } } else { return nil } } } }
//line :556:1
				default:
				}




















				var tmp13 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp13 = or__1927000174__auto____4 } else { tmp13 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(f__0)) }; if jrt.A2g_Truth(tmp13) {
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(f__0))); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
						return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_199, f__0) } } else {
//line :552:1
							if A_arbace_g2a_print_code_A_const_30 != nil {




























								return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_199, f__0) } else {
//line :552:1
									return nil
								}
						}
		}
}




func A_arbace_g2a_print_code_type_expr_fn__1022000198_A_New_O(p0 any) *A_arbace_g2a_print_code_type_expr_fn__1022000198_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_expr_fn__1022000198_A{}; t.Ctor_O(p0); return t }
//line :561:1
func (t *A_arbace_g2a_print_code_type_expr_fn__1022000198_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :561:1
func (t *A_arbace_g2a_print_code_type_expr_fn__1022000198_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_g2a_print_code_A_const_106) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }





















func A_arbace_g2a_print_code_type_form_QMARK__A_New() *A_arbace_g2a_print_code_type_form_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_form_QMARK__A{}; t.Ctor(); return t }
//line :583:1
func (t *A_arbace_g2a_print_code_type_form_QMARK__A) Ctor() {}
//line :583:1
func (t *A_arbace_g2a_print_code_type_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if



	jrt.A2g_Truth(and__1927000168__auto____2) { var o__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0); var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_186.GetRawRoot__O(), o__3)

		if jrt.A2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(o__3, Lit_4)
			if jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(f__0)))).Ref() } } else {
//line :589:1
				return and__1927000168__auto____4 } } else {
//line :587:1
					return and__1927000168__auto____2 } }




func A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_New() *A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A{}; t.Ctor(); return t }
//line :592:1
func (t *A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A) Ctor() {}
//line :592:1
func (t *A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if
													jrt.A2g_Truth(and__1927000168__auto____2) { or__1927000174__auto____2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0), Lit_4)).Ref() } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0)
														if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0), Lit_5); if and__1927000168__auto____4 { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_187.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } }

func A_arbace_g2a_print_code_type_params_A_New() *A_arbace_g2a_print_code_type_params_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_params_A{}; t.Ctor(); return t }
//line :596:1
func (t *A_arbace_g2a_print_code_type_params_A) Ctor() {}
//line :596:1
func (t *A_arbace_g2a_print_code_type_params_A) Invoke_O_O__O(self, tps__0 any) any { var entries__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_53.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_type_params_fn__1022000216_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_g2a_print_code_type_params_fn__1022000216_A_fn_class; if



	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_201, false); A_arbace_g2a_print_code_type_params_fn__1022000216_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; entries__2 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tps__0); var groups__3 any = /*line :596:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_124.GetRawRoot__O()).Invoke_O__O(entries__2);








	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_97); var seq_1022000218__4 any = /*line :596:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_78.GetRawRoot__O(), groups__3)); var chunk_1022000219__5 any; var count_1022000220__6 int64 = 0; var i_1022000221__7 int64 = 0; L1: for {









		if lang.Numbers_Lt_J_J__Z(i_1022000221__7, count_1022000220__6) { var vec__1022000222__8 any = lang.Indexed_Cast(chunk_1022000219__5).Nth_I__O(lang.RT_IntCast_J__I(i_1022000221__7)); var i__9 any = lang.RT_Nth_O_I_O__O(vec__1022000222__8, lang.RT_IntCast_J__I(0), nil); var g__10 any = lang.RT_Nth_O_I_O__O(vec__1022000222__8, lang.RT_IntCast_J__I(1), nil)
			if lang.Numbers_IsPos_O__Z(i__9) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_130.GetRawRoot__O()).Invoke_O__O(g__10)) }
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_128.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__10))
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_111.Invoke_O__O(g__10))
//line :606:1
			seq_1022000218__4, chunk_1022000219__5, count_1022000220__6, i_1022000221__7 = seq_1022000218__4, chunk_1022000219__5, count_1022000220__6, lang.Numbers_Unchecked_inc_J__J(i_1022000221__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000218__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1022000218__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000218__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000218__9); seq_1022000218__4, chunk_1022000219__5, count_1022000220__6, i_1022000221__7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000218__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1022000225__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000218__9); var i__11 any = lang.RT_Nth_O_I_O__O(vec__1022000225__10, lang.RT_IntCast_J__I(0), nil); var g__12 any = lang.RT_Nth_O_I_O__O(vec__1022000225__10, lang.RT_IntCast_J__I(1), nil)
				if lang.Numbers_IsPos_O__Z(i__11) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_130.GetRawRoot__O()).Invoke_O__O(g__12)) }
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_128.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_83.Invoke_O__O(g__12))
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_111.Invoke_O__O(g__12))
//line :606:1
				seq_1022000218__4, chunk_1022000219__5, count_1022000220__6, i_1022000221__7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000218__9), nil, 0, 0; continue L1 } } }
//line :596:1
		break L1 }; var tmp4 any; var and__1927000168__auto____4 bool =














	lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(groups__3))); if and__1927000168__auto____4 { var tmp5 *lang.Keyword = A_arbace_g2a_print_code_A_const_83; var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(groups__3))))); if and__1927000168__auto____5 {
		var tmp6 *lang.Keyword = A_arbace_g2a_print_code_A_const_111; tmp4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_187.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(groups__3))) } else {
//line :611:1
			tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() }; if jrt.A2g_Truth(tmp4) {

				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41) }; return /*line :614:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_99) }
//line :600:1
func A_arbace_g2a_print_code_type_params_fn__1022000216_A_New() *A_arbace_g2a_print_code_type_params_fn__1022000216_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_params_fn__1022000216_A{}; t.Ctor(); return t }
//line :600:1
func (t *A_arbace_g2a_print_code_type_params_fn__1022000216_A) Ctor() {}
//line :600:1
func (t *A_arbace_g2a_print_code_type_params_fn__1022000216_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 any = A_arbace_g2a_print_code_A_const_110; var tmp2 any = A_arbace_g2a_print_code_A_const_111; var tmp3 any; if
													jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(p__1), A_arbace_g2a_print_code_A_const_107)) { var tmp4 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; tmp3 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p__1)) } else { tmp3 = A_arbace_g2a_print_code_A_const_188 }; var tmp5 any = tmp3; var tmp6 any = A_arbace_g2a_print_code_A_const_113; return /*line :600:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, p__1, tmp2, tmp5, tmp6, lang.RT_Meta_O__IPersistentMap(p__1), A_arbace_g2a_print_code_A_const_82, p__1)) }




















func A_arbace_g2a_print_code_walk_right_A_New() *A_arbace_g2a_print_code_walk_right_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_walk_right_A{}; t.Ctor(); return t }
//line :621:1
func (t *A_arbace_g2a_print_code_walk_right_A) Ctor() {}
//line :621:1
func (t *A_arbace_g2a_print_code_walk_right_A) Invoke_O_O_O_O__O(self, o__0, prec__1, r__2 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_39.GetRawRoot__O()).Invoke_O__O(r__2)) {
		if lang.Numbers_Gt_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_40.GetRawRoot__O()).Invoke_O__O(r__2)), lang.RT_LongCast_O__J(prec__1)) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_189.GetRawRoot__O()).Invoke_O__O(r__2) } else { return A_arbace_g2a_print_code_A_const_190 } } else {
//line :625:1
			var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(r__2)

			if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(r__2), Lit_151); if and__1927000168__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(r__2)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp1 = and__1927000168__auto____4 }
//line :625:1
			if jrt.A2g_Truth(tmp1) { var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; var tmp3 any = tmp2.Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; var tmp5 any = tmp4.Ref(); var tmp6 any


				if lang.Util_Equiv_O_O__Z(o__0, Lit_207) { tmp6 = A_arbace_g2a_print_code_A_const_193 } else { tmp6 = A_arbace_g2a_print_code_A_const_157 }
//line :625:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp5, tmp6) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(r__2)) { var s__4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, o__0, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_191.GetRawRoot__O()).Invoke_O__O(r__2))).Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; var tmp8 any = tmp7.Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; var tmp10 any = tmp9.Ref(); var tmp11 any





					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_194).Invoke_O__O(s__4)) { tmp11 = A_arbace_g2a_print_code_A_const_193 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_195).Invoke_O__O(s__4)) { tmp11 = A_arbace_g2a_print_code_A_const_196 } else { if A_arbace_g2a_print_code_A_const_30 != nil { tmp11 = A_arbace_g2a_print_code_A_const_157 } else { tmp11 = nil } } }
//line :625:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp10, tmp11) } else { if A_arbace_g2a_print_code_A_const_30 != nil { return A_arbace_g2a_print_code_A_const_192 } else { return nil
					}
					}
				}
		}
}



func A_arbace_g2a_print_code_walk_prefixes_A_New() *A_arbace_g2a_print_code_walk_prefixes_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_walk_prefixes_A{}; t.Ctor(); return t }
//line :634:1
func (t *A_arbace_g2a_print_code_walk_prefixes_A) Ctor() {}
//line :634:1
func (t *A_arbace_g2a_print_code_walk_prefixes_A) Invoke_O_O__O(self, f__0 any) any { { var prec__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_40.GetRawRoot__O()).Invoke_O__O(f__0); var o__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_197.GetRawRoot__O()).Invoke_O__O(f__0); var xs__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)); var x1__5 any = lang.RT_Nth_O_I__O(xs__4, lang.RT_IntCast_J__I(0)); var vec__1022000230__6 any; var tmp1 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_39.GetRawRoot__O()).Invoke_O__O(x1__5)








	if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_40.GetRawRoot__O()).Invoke_O__O(x1__5)), lang.RT_LongCast_O__J(prec__2))).Ref() } else { tmp1 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp1) { vec__1022000230__6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_189.GetRawRoot__O()).Invoke_O__O(x1__5) } else { vec__1022000230__6 = A_arbace_g2a_print_code_A_const_198 }
//line :634:1
	var h4__7 any = lang.RT_Nth_O_I_O__O(vec__1022000230__6, lang.RT_IntCast_J__I(0), nil); var h5__8 any = lang.RT_Nth_O_I_O__O(vec__1022000230__6, lang.RT_IntCast_J__I(1), nil); var mp__9 any = lang.RT_Nth_O_I_O__O(vec__1022000230__6, lang.RT_IntCast_J__I(2), nil); var i__10 int64 = 1; var acc__11 any; var tmp2 any; var or__1927000174__auto____11 bool = lang.Util_Equiv_O_J__Z(prec__2, 4)









	if or__1927000174__auto____11 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { tmp2 = h4__7 }
//line :634:1
	var tmp3 any = tmp2; var tmp4 any; var or__1927000174__auto____11_2 bool = lang.Util_Equiv_O_J__Z(prec__2, 5)









	if or__1927000174__auto____11_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11_2).Ref() } else { tmp4 = h5__8 }
//line :634:1
	acc__11 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp4, mp__9); var out__12 any; lang.PersistentVector_Init(); out__12 = lang.PersistentVector_EMPTY.Ref(); L1: for {










		if lang.Numbers_Lt_J_J__Z(i__10, int64(lang.RT_Count_O__I(xs__4))) { var vec__1022000233__13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_199.GetRawRoot__O()).Invoke_O_O_O__O(o__3, prec__2, lang.RT_Nth_O_I__O(xs__4, lang.RT_IntCast_J__I(i__10))); var rh4__14 any = lang.RT_Nth_O_I_O__O(vec__1022000233__13, lang.RT_IntCast_J__I(0), nil); var rh5__15 any = lang.RT_Nth_O_I_O__O(vec__1022000233__13, lang.RT_IntCast_J__I(1), nil); var rmp__16 any = lang.RT_Nth_O_I_O__O(vec__1022000233__13, lang.RT_IntCast_J__I(2), nil); var vec__1022000236__17 any = acc__11; var a4__18 any = lang.RT_Nth_O_I_O__O(vec__1022000236__17, lang.RT_IntCast_J__I(0), nil); var a5__19 any = lang.RT_Nth_O_I_O__O(vec__1022000236__17, lang.RT_IntCast_J__I(1), nil); var amp__20 any = lang.RT_Nth_O_I_O__O(vec__1022000236__17, lang.RT_IntCast_J__I(2), nil); var w__21 any; var tmp5 any
			var or__1927000174__auto____21 any = a4__18

			if jrt.A2g_Truth(or__1927000174__auto____21) { tmp5 = or__1927000174__auto____21 } else { tmp5 = rh4__14 }
//line :645:1
			var tmp6 any = tmp5; var tmp7 any
			var or__1927000174__auto____21_2 any = a5__19

			if jrt.A2g_Truth(or__1927000174__auto____21_2) { tmp7 = or__1927000174__auto____21_2 } else { tmp7 = rh5__15 }
//line :645:1
			w__21 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp7, jrt.Long_ValueOf_J__Long(lang.Numbers_Max_J_J__J(lang.RT_LongCast_O__J(amp__20), lang.RT_LongCast_O__J(rmp__16))).Ref())



			i__10, acc__11, out__12 = lang.Numbers_Inc_J__J(i__10), w__21, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(out__12, w__21); continue L1 } else {
//line :645:1
				return out__12 } } }; /*line :634:1*/panic("a2g: unreachable") }

















func A_arbace_g2a_print_code_walk_binary_A_New() *A_arbace_g2a_print_code_walk_binary_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_walk_binary_A{}; t.Ctor(); return t }
//line :652:1
func (t *A_arbace_g2a_print_code_walk_binary_A) Ctor() {}
//line :652:1
func (t *A_arbace_g2a_print_code_walk_binary_A) Invoke_O_O__O(self, f__0 any) any {


	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_200.GetRawRoot__O()).Invoke_O__O(f__0))
}
func A_arbace_g2a_print_code_cutoff_of_A_New() *A_arbace_g2a_print_code_cutoff_of_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_cutoff_of_A{}; t.Ctor(); return t }
//line :657:1
func (t *A_arbace_g2a_print_code_cutoff_of_A) Ctor() {}
//line :657:1
func (t *A_arbace_g2a_print_code_cutoff_of_A) Invoke_O_O_O__O(self, p__1022000241__0, depth__1 any) any { var vec__1022000242__3 any = p__1022000241__0; var has4__4 any = lang.RT_Nth_O_I_O__O(vec__1022000242__3, lang.RT_IntCast_J__I(0), nil); var has5__5 any = lang.RT_Nth_O_I_O__O(vec__1022000242__3, lang.RT_IntCast_J__I(1), nil); var mp__6 any = lang.RT_Nth_O_I_O__O(vec__1022000242__3, lang.RT_IntCast_J__I(2), nil); if
													lang.Numbers_IsPos_O__Z(mp__6) {
														return lang.Numbers_Inc_O__Number(mp__6) } else {
//line :658:1
			var tmp1 any
			var and__1927000168__auto____7 any = has4__4
			if jrt.A2g_Truth(and__1927000168__auto____7) { tmp1 = has5__5 } else { tmp1 = and__1927000168__auto____7 }
//line :658:1
			if jrt.A2g_Truth(tmp1) {

				if lang.Util_Equiv_O_J__Z(depth__1, 1) { return A_arbace_g2a_print_code_A_const_193 } else { return A_arbace_g2a_print_code_A_const_196 } } else {
//line :658:1
					if lang.Util_Equiv_O_J__Z(depth__1, 1) { return A_arbace_g2a_print_code_A_const_42 } else { if A_arbace_g2a_print_code_A_const_30 != nil { return A_arbace_g2a_print_code_A_const_196 } else { return nil } } } } }





func A_arbace_g2a_print_code_cutoff_A_New() *A_arbace_g2a_print_code_cutoff_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_cutoff_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_g2a_print_code_cutoff_A) Ctor() {}
//line :664:1
func (t *A_arbace_g2a_print_code_cutoff_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_201.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_189.GetRawRoot__O()).Invoke_O__O(f__0), depth__1) }

func A_arbace_g2a_print_code_diff_prec_A_New() *A_arbace_g2a_print_code_diff_prec_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_diff_prec_A{}; t.Ctor(); return t }
//line :666:1
func (t *A_arbace_g2a_print_code_diff_prec_A) Ctor() {}
//line :666:1
func (t *A_arbace_g2a_print_code_diff_prec_A) Invoke_O_O_O__O(self, x__0, prec__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_39.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(prec__1, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_40.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { return A_arbace_g2a_print_code_A_const_157 } else { return A_arbace_g2a_print_code_A_const_106
	} }
func A_arbace_g2a_print_code_reduce_depth_A_New() *A_arbace_g2a_print_code_reduce_depth_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_reduce_depth_A{}; t.Ctor(); return t }
//line :669:1
func (t *A_arbace_g2a_print_code_reduce_depth_A) Ctor() {}
//line :669:1
func (t *A_arbace_g2a_print_code_reduce_depth_A) Invoke_O_O__O(self, d__0 any) any { return lang.Numbers_Max_J_O__O(1, lang.Numbers_Dec_O__Number(d__0)) }

func A_arbace_g2a_print_code_paren_operand_A_New() *A_arbace_g2a_print_code_paren_operand_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_paren_operand_A{}; t.Ctor(); return t }
//line :671:1
func (t *A_arbace_g2a_print_code_paren_operand_A) Ctor() {}
//line :671:1
func (t *A_arbace_g2a_print_code_paren_operand_A) Invoke_O_O__O(self, x__0 any) any {



	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(x__0))
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any = A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_New_O(x__0); var tmp6 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_153, false); A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_fn_class = fncls__34d; tmp6 = fncls__34d } else { tmp6 = fncls__34 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :677:1
func A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_New_O(p0 any) *A_arbace_g2a_print_code_paren_operand_fn__1022000249_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_paren_operand_fn__1022000249_A{}; t.Ctor_O(p0); return t }
//line :677:1
func (t *A_arbace_g2a_print_code_paren_operand_fn__1022000249_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :677:1
func (t *A_arbace_g2a_print_code_paren_operand_fn__1022000249_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_x; t.F_x = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_g2a_print_code_A_const_106) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_g2a_print_code_binary_expr_A_New() *A_arbace_g2a_print_code_binary_expr_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binary_expr_A{}; t.Ctor(); return t }
//line :680:1
func (t *A_arbace_g2a_print_code_binary_expr_A) Ctor() {}
//line :680:1
func (t *A_arbace_g2a_print_code_binary_expr_A) Invoke_O_O_O_O_O__O(self, f__0, prec1__1, cut__2, depth__3 any) any { { var prec__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_40.GetRawRoot__O()).Invoke_O__O(f__0)






	if lang.Numbers_Lt_O_O__Z(prec__5, prec1__1) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6)
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any = A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_New_O_O(f__0, depth__3); var tmp6 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_fn_class = fncls__35d; tmp6 = fncls__35d } else { tmp6 = fncls__35 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
//line :687:1
			var xs__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)); var k__7 int32 = lang.RT_Count_O__I(xs__6); var o__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_197.GetRawRoot__O()).Invoke_O__O(f__0); var cuts__9 any







			if lang.Numbers_Gt_J_J__Z(int64(k__7), 2) {
				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_New_O(depth__3); var tmp10 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_fn_class = fncls__36d; tmp10 = fncls__36d } else { tmp10 = fncls__36 }; cuts__9 = tmp7.Invoke_O_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_121.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_200.GetRawRoot__O()).Invoke_O__O(f__0))), cut__2) } else {
//line :695:1
					cuts__9 = lang.Tuple_Create_O__IPersistentVector(cut__2) }
//line :687:1
			var t__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(f__0); var x1__11 any = lang.RT_Nth_O_I__O(xs__6, lang.RT_IntCast_J__I(0)); var n__1927000701__auto____12 int64 = lang.RT_LongCast_J__J(lang.Numbers_Minus_J_J__J(int64(k__7), 2)); var ___13 int64 = 0; L1: for {












				if lang.Numbers_Lt_J_J__Z(___13, n__1927000701__auto____12) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(t__10); ___13 = lang.Numbers_Unchecked_inc_J__J(___13); continue L1 }
//line :687:1
				break L1
			}












			var tmp11 *lang.Keyword = A_arbace_g2a_print_code_A_const_203; if jrt.A2g_Truth(tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x1__11))) {
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_204.GetRawRoot__O()).Invoke_O__O(x1__11) } else {
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(x1__11, prec__5, lang.Numbers_Add_O_O__Number(depth__3, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_206.GetRawRoot__O()).Invoke_O_O__O(x1__11, prec__5))) }
//line :687:1
			var n__1927000701__auto____12_2 int64 = lang.RT_LongCast_J__J(lang.Numbers_Dec_J__J(int64(k__7))); var i__13 int64 = 0; L2: for {
















				if lang.Numbers_Lt_J_J__Z(i__13, n__1927000701__auto____12_2) { var blank_QMARK___14 bool = lang.Numbers_Lt_J_J__Z(lang.RT_LongCast_O__J(prec__5), lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(cuts__9, lang.RT_IntCast_J__I(i__13)))); var y__15 any = lang.RT_Nth_O_I__O(xs__6, lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(i__13)))


					if blank_QMARK___14 { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(o__8)
//line :704:1
					var yt__16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_59.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__13, 2)).Ref(), y__15); var tmp12 any
					var and__1927000168__auto____17 any = yt__16




					if jrt.A2g_Truth(and__1927000168__auto____17) { var or__1927000174__auto____18 bool = lang.Util_Equiv_O_O__Z(yt__16, A_arbace_g2a_print_code_A_const_57); if or__1927000174__auto____18 { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____18).Ref() } else { var tmp13 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; tmp12 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(yt__16), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp13.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))).Ref() } } else { tmp12 = and__1927000168__auto____17 }; if jrt.A2g_Truth(tmp12) {
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(yt__16) } else {
							if blank_QMARK___14 { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() } }
					var tmp14 *lang.Keyword = A_arbace_g2a_print_code_A_const_203; if jrt.A2g_Truth(tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(y__15))) {
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_204.GetRawRoot__O()).Invoke_O__O(y__15) } else {
							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(y__15, lang.Numbers_Inc_O__Number(prec__5), lang.Numbers_Inc_O__Number(depth__3)) }
//line :704:1
					i__13 = lang.Numbers_Unchecked_inc_J__J(i__13); continue L2 } else { return nil } } } }; /*line :680:1*/panic("a2g: unreachable") }








func A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_binary_expr_fn__1022000253_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binary_expr_fn__1022000253_A{}; t.Ctor_O_O(p0, p1); return t }
//line :689:1
func (t *A_arbace_g2a_print_code_binary_expr_fn__1022000253_A) Ctor_O_O(c__f, c__depth any) { t.F_f = c__f; t.F_depth = c__depth }
//line :689:1
func (t *A_arbace_g2a_print_code_binary_expr_fn__1022000253_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_202.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_depth; t.F_depth = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5.Invoke_O__O(tmp6)) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }






func A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_New_O(p0 any) *A_arbace_g2a_print_code_binary_expr_fn__1022000255_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binary_expr_fn__1022000255_A{}; t.Ctor_O(p0); return t }
//line :696:1
func (t *A_arbace_g2a_print_code_binary_expr_fn__1022000255_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :696:1
func (t *A_arbace_g2a_print_code_binary_expr_fn__1022000255_A) Invoke_O_O__O(self, p1__1022000252_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_201.GetRawRoot__O()).Invoke_O_O__O(p1__1022000252_SHARP___1, t.F_depth) }




















func A_arbace_g2a_print_code_call_args_A_New() *A_arbace_g2a_print_code_call_args_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_call_args_A{}; t.Ctor(); return t }
//line :717:1
func (t *A_arbace_g2a_print_code_call_args_A) Ctor() {}
//line :717:1
func (t *A_arbace_g2a_print_code_call_args_A) Invoke_O_O_O_O_O__O(self, f__0, xs__1, depth__2, offset__3 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_125.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_call_args_fn__1022000258_A_New_O(depth__2); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_g2a_print_code_call_args_fn__1022000258_A_fn_class
	if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_g2a_print_code_call_args_fn__1022000258_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }
//line :720:1
	return tmp1.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, xs__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, offset__3))) }
func A_arbace_g2a_print_code_call_args_fn__1022000258_A_New_O(p0 any) *A_arbace_g2a_print_code_call_args_fn__1022000258_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_call_args_fn__1022000258_A{}; t.Ctor_O(p0); return t }
//line :721:1
func (t *A_arbace_g2a_print_code_call_args_fn__1022000258_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :721:1
func (t *A_arbace_g2a_print_code_call_args_fn__1022000258_A) Invoke_O_O_O__O(self, x__1, ___2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(x__1), Lit_24)).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(x__1), t.F_depth); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_25) } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(x__1, t.F_depth)
		}
}
func A_arbace_g2a_print_code_callee_A_New() *A_arbace_g2a_print_code_callee_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_callee_A{}; t.Ctor(); return t }
//line :727:1
func (t *A_arbace_g2a_print_code_callee_A) Ctor() {}
//line :727:1
func (t *A_arbace_g2a_print_code_callee_A) Invoke_O_O_O__O(self, h__0, depth__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(h__0)
	if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(h__0), Lit_26)).Ref() } else { tmp1 = and__1927000168__auto____3 }
//line :728:1
	if jrt.A2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(h__0); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
//line :728:1
			if A_arbace_g2a_print_code_A_const_30 != nil {

				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(h__0, A_arbace_g2a_print_code_A_const_43, depth__1) } else {
//line :728:1
					return nil
				}
		}
}
func A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_New() *A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A{}; t.Ctor(); return t }
//line :732:1
func (t *A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A) Ctor() {}
//line :732:1
func (t *A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(t__0); if
													jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_71.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__0)
														if jrt.A2g_Truth(and__1927000168__auto____4) { or__1927000174__auto____4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_186.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__0))) } else { or__1927000174__auto____4 = and__1927000168__auto____4 }
//line :733:1
		if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__0)

			if jrt.A2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__0), Lit_91)).Ref() } else { return and__1927000168__auto____5 } } } } }

func A_arbace_g2a_print_code_lit_elements_A_New() *A_arbace_g2a_print_code_lit_elements_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_lit_elements_A{}; t.Ctor(); return t }
//line :737:1
func (t *A_arbace_g2a_print_code_lit_elements_A) Ctor() {}
//line :737:1
func (t *A_arbace_g2a_print_code_lit_elements_A) Invoke_O_O__O(self, f__0 any) any { { var xs__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(f__0)); var i__3 int64 = 2; var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); L1: for {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(xs__2)) { return acc__4 } else { var x__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__2)


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(x__5)) {
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(xs__2)) {
				var tmp1 any = A_arbace_g2a_print_code_A_const_207; var tmp2 any = A_arbace_g2a_print_code_A_const_208; var tmp3 any = A_arbace_g2a_print_code_A_const_209; var tmp4 any = A_arbace_g2a_print_code_A_const_210; var tmp5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(xs__2); var tmp6 any = A_arbace_g2a_print_code_A_const_211; xs__2, i__3, acc__4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(xs__2), lang.Numbers_Add_J_J__J(i__3, 2), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, x__5, tmp4, tmp5, tmp6, jrt.Long_ValueOf_J__Long(i__3).Ref()))); continue L1 } else {
					return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_142, f__0) } } else {
//line :743:1
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(x__5)) {



							if lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(x__5))) {
								var tmp7 any = A_arbace_g2a_print_code_A_const_207; var tmp8 any = A_arbace_g2a_print_code_A_const_209; var tmp9 any = A_arbace_g2a_print_code_A_const_209; var tmp10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(x__5); var tmp11 any = A_arbace_g2a_print_code_A_const_210; var tmp12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(x__5); var tmp13 any = A_arbace_g2a_print_code_A_const_211; xs__2, i__3, acc__4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(xs__2), lang.Numbers_Inc_J__J(i__3), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, jrt.Long_ValueOf_J__Long(i__3).Ref(), A_arbace_g2a_print_code_A_const_82, x__5))); continue L1 } else {
									return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_143, x__5) } } else {
//line :743:1
										if A_arbace_g2a_print_code_A_const_30 != nil {






											var tmp14 any = A_arbace_g2a_print_code_A_const_207; var tmp15 any = A_arbace_g2a_print_code_A_const_212; var tmp16 any = A_arbace_g2a_print_code_A_const_210; var tmp17 any = A_arbace_g2a_print_code_A_const_211; xs__2, i__3, acc__4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(xs__2), lang.Numbers_Inc_J__J(i__3), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, x__5, tmp17, jrt.Long_ValueOf_J__Long(i__3).Ref(), A_arbace_g2a_print_code_A_const_82, x__5))); continue L1 } else {
//line :743:1
												return nil } } } } } }; /*line :737:1*/panic("a2g: unreachable") }














func A_arbace_g2a_print_code_key_size_A_New() *A_arbace_g2a_print_code_key_size_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_key_size_A{}; t.Ctor(); return t }
//line :752:1
func (t *A_arbace_g2a_print_code_key_size_A) Ctor() {}
//line :752:1
func (t *A_arbace_g2a_print_code_key_size_A) Invoke_O_O__O(self, el__0 any) any {


	if lang.Util_Equiv_O_O__Z(A_arbace_g2a_print_code_A_const_207.Invoke_O__O(el__0), A_arbace_g2a_print_code_A_const_208) {
		return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_209.Invoke_O__O(el__0)))).Ref() } else {
//line :755:1
			var k__2 any = A_arbace_g2a_print_code_A_const_209.Invoke_O__O(el__0)


			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(k__2)) {
				return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(k__2))).Ref() } else {
//line :758:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(k__2)) {

						return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_91.GetRawRoot__O()).Invoke_O__O(k__2))).Ref() } else {
//line :758:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_34.GetRawRoot__O()).Invoke_O__O(k__2)) {


								return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_72.GetRawRoot__O()).Invoke_O__O(k__2))).Ref() } else {
//line :758:1
									if A_arbace_g2a_print_code_A_const_30 != nil { return A_arbace_g2a_print_code_A_const_213 } else { return nil
									}
								}
						}
				}
		} }
func A_arbace_g2a_print_code_composite_lit_A_New() *A_arbace_g2a_print_code_composite_lit_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_composite_lit_A{}; t.Ctor(); return t }
//line :764:1
func (t *A_arbace_g2a_print_code_composite_lit_A) Ctor() {}
//line :764:1
func (t *A_arbace_g2a_print_code_composite_lit_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { var t__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0); var wrap_QMARK___4 any; var and__1927000168__auto____4 any = A_arbace_g2a_print_code_A_const_185.Get__O(); if

	jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(t__3, A_arbace_g2a_print_code_A_const_215); if jrt.A2g_Truth(and__1927000168__auto____5) { wrap_QMARK___4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_214.GetRawRoot__O()).Invoke_O__O(t__3) } else { wrap_QMARK___4 = and__1927000168__auto____5 } } else { wrap_QMARK___4 = and__1927000168__auto____4 }; if
	jrt.A2g_Truth(wrap_QMARK___4) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any = A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_New_O_O(f__0, t__3); var tmp6 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_fn_class = fncls__44d; tmp6 = fncls__44d } else { tmp6 = fncls__44 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); if


























	jrt.A2g_Truth(wrap_QMARK___4) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else { return nil } }
//line :768:1
func A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_composite_lit_fn__1022000265_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_composite_lit_fn__1022000265_A{}; t.Ctor_O_O(p0, p1); return t }
//line :768:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_A) Ctor_O_O(c__f, c__t any) { t.F_f = c__f; t.F_t = c__t }
//line :768:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_A) Invoke_O__O(self any) any { var tmp1 any; tmp29 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												if lang.Util_Equiv_O_O__Z(t.F_t, A_arbace_g2a_print_code_A_const_217) { } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_t; t.F_t = nil; tmp3 = t_; tmp2.Invoke_O__O(tmp3) }
//line :768:1
	{ var els__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_216.GetRawRoot__O()).Invoke_O__O(t.F_f); var tmp4 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var start__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); var brk__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_58.GetRawRoot__O()).Invoke_O__O(t.F_f); var ts__6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_New_O_O(t.F_f, brk__5); var tmp7 *jrt.Class
		var fncls__38 /*line :768:1*/*jrt.Class = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_fn_class




		if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_fn_class = fncls__38d; tmp7 = fncls__38d } else { tmp7 = fncls__38 }; ts__6 = tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), els__3)
//line :768:1
		var nxt__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_99.GetRawRoot__O()).Invoke_O__O(ts__6); var multi_QMARK___8 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_New_O(start__4); var tmp10 *jrt.Class
		var fncls__39 /*line :768:1*/*jrt.Class = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_fn_class






		if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_fn_class = fncls__39d; tmp10 = fncls__39d } else { tmp10 = fncls__39 }; multi_QMARK___8 = tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), ts__6)
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_17)
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke__O()
//line :768:1
		var n__9 int32 = lang.RT_Count_O__I(els__3); var seq_1022000270__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_78.GetRawRoot__O(), els__3)); var chunk_1022000271__11 any; var count_1022000272__12 int64 = 0; var i_1022000273__13 int64 = 0; L1: for {










			if lang.Numbers_Lt_J_J__Z(i_1022000273__13, count_1022000272__12) { var vec__1022000274__14 any = lang.Indexed_Cast(chunk_1022000271__11).Nth_I__O(lang.RT_IntCast_J__I(i_1022000273__13)); var i__15 any = lang.RT_Nth_O_I_O__O(vec__1022000274__14, lang.RT_IntCast_J__I(0), nil); var el__16 any = lang.RT_Nth_O_I_O__O(vec__1022000274__14, lang.RT_IntCast_J__I(1), nil); var tl__17 any = lang.RT_Nth_O_I__O(ts__6, lang.RT_IntCast_O__I(i__15))

				if lang.Numbers_IsPos_O__Z(i__15) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(tl__17)
				var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_print_code_A_const_62; var tmp14 any; var or__1927000174__auto____18 any = lang.RT_Nth_O_I__O(nxt__7, lang.RT_IntCast_O__I(i__15)); if jrt.A2g_Truth(or__1927000174__auto____18) { tmp14 = or__1927000174__auto____18 } else { tmp14 = A_arbace_g2a_print_code_A_const_62.Get__O() }; tmp11.Invoke_O__O(tmp12.Invoke_O_O__O(tmp13, tmp14)); var tmp15 any = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_New_I_O_O(n__9, el__16, multi_QMARK___8); var tmp16 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_fn_class = fncls__41d; tmp16 = fncls__41d } else { tmp16 = fncls__41 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :779:1
				seq_1022000270__10, chunk_1022000271__11, count_1022000272__12, i_1022000273__13 = seq_1022000270__10, chunk_1022000271__11, count_1022000272__12, lang.Numbers_Unchecked_inc_J__J(i_1022000273__13); continue L1 } else { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000270__10); if jrt.A2g_Truth(temp__1927000414__auto____14) { var seq_1022000270__15 any = temp__1927000414__auto____14; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000270__15)) { var c__1927000678__auto____16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000270__15); seq_1022000270__10, chunk_1022000271__11, count_1022000272__12, i_1022000273__13 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000270__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1022000280__16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000270__15); var i__17 any = lang.RT_Nth_O_I_O__O(vec__1022000280__16, lang.RT_IntCast_J__I(0), nil); var el__18 any = lang.RT_Nth_O_I_O__O(vec__1022000280__16, lang.RT_IntCast_J__I(1), nil); var tl__19 any = lang.RT_Nth_O_I__O(ts__6, lang.RT_IntCast_O__I(i__17))

					if lang.Numbers_IsPos_O__Z(i__17) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(tl__19)
					var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp19 any = A_arbace_g2a_print_code_A_const_62; var tmp20 any; var or__1927000174__auto____20 any = lang.RT_Nth_O_I__O(nxt__7, lang.RT_IntCast_O__I(i__17)); if jrt.A2g_Truth(or__1927000174__auto____20) { tmp20 = or__1927000174__auto____20 } else { tmp20 = A_arbace_g2a_print_code_A_const_62.Get__O() }; tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(tmp19, tmp20)); var tmp21 any = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_New_I_O_O(n__9, el__18, multi_QMARK___8); var tmp22 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_fn_class = fncls__43d; tmp22 = fncls__43d } else { tmp22 = fncls__43 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O()
//line :779:1
					seq_1022000270__10, chunk_1022000271__11, count_1022000272__12, i_1022000273__13 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000270__15), nil, 0, 0; continue L1 } } }
//line :768:1
			break L1 }; var indent__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O(); var tmp23 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var multi__11 bool = lang.Numbers_Gt_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())), start__4); var tmp24 any; var tmp25 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____12 any = tmp25.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())























		if jrt.A2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 bool = lang.Numbers_IsPos_J__Z(int64(n__9)); if and__1927000168__auto____13 { var and__1927000168__auto____14 bool = multi__11; if and__1927000168__auto____14 { tmp24 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_61.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_106) } else { tmp24 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14).Ref() } } else { tmp24 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13).Ref() } } else { tmp24 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp24) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_41) }
		var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_105.GetRawRoot__O()); var tmp27 any = jrt.Boolean_ValueOf_Z__Boolean(multi__11).Ref(); var tmp28 *jrt.Boolean; jrt.Boolean_Init(); tmp28 = jrt.Boolean_FALSE; tmp26.Invoke_O_O_O_O__O(nil, tmp27, tmp28.Ref(), indent__10)
		tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_19) }
//line :768:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp29 != nil { panic(tmp29) }; return tmp1 }




func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A{}; t.Ctor_O_O(p0, p1); return t }
//line :773:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A) Ctor_O_O(c__f, c__brk any) { t.F_f = c__f; t.F_brk = c__brk }
//line :773:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A) Invoke_O_O__O(self, el__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_59.GetRawRoot__O()); var tmp2 any = t.F_f; var tmp3 any = A_arbace_g2a_print_code_A_const_211.Invoke_O__O(el__1); var tmp4 any; var or__1927000174__auto____2 any = A_arbace_g2a_print_code_A_const_82.Invoke_O__O(el__1); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { tmp4 = A_arbace_g2a_print_code_A_const_210.Invoke_O__O(el__1) }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, t.F_brk) }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_New_O(p0 any) *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A{}; t.Ctor_O(p0); return t }
//line :775:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A) Ctor_O(c__start any) { t.F_start = c__start }
//line :775:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A) Invoke_O_O__O(self, tl__1 any) any { var and__1927000168__auto____2 any = tl__1; if jrt.A2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(tl__1, A_arbace_g2a_print_code_A_const_57); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(tl__1), t.F_start)).Ref() } } else { return and__1927000168__auto____2 } }







func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :783:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A) Ctor_I_O_O(c__n int32, c__el, c__multi_QMARK_ any) { t.F_n = c__n; t.F_el = c__el; t.F_multi_QMARK_ = c__multi_QMARK_ }
//line :783:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var G__1022000278__3_ any = A_arbace_g2a_print_code_A_const_207.Invoke_O__O(t.F_el)
L1: switch { default: switch lang.Util_Hash_O__I(G__1022000278__3_) { case 1021133523: if any(G__1022000278__3_) == any(A_arbace_g2a_print_code_A_const_212) {
	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_210; var tmp4 any; var t_ any = t.F_el; t.F_el = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3.Invoke_O__O(tmp4), A_arbace_g2a_print_code_A_const_106)
//line :784:1
	break L1 }; default:
}
	if lang.Util_Equiv_O_O__Z(A_arbace_g2a_print_code_A_const_207.Invoke_O__O(t.F_el), A_arbace_g2a_print_code_A_const_208) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_209.Invoke_O__O(t.F_el))) } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_209.Invoke_O__O(t.F_el), A_arbace_g2a_print_code_A_const_106) }
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38)
	var tmp5 any; var and__1927000168__auto____4 any; var t__2 any = t.F_multi_QMARK_; t.F_multi_QMARK_ = nil; and__1927000168__auto____4 = t__2; if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Numbers_Gt_J_J__Z(int64(t.F_n), 1); if and__1927000168__auto____5 { var tmp6 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; tmp5 = tmp6.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp5 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp5) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_166.GetRawRoot__O()).Invoke__O() } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp8 *lang.Keyword = A_arbace_g2a_print_code_A_const_210; var tmp9 any; var t__3 any = t.F_el; t.F_el = nil; tmp9 = t__3; tmp1 = tmp7.Invoke_O_O__O(tmp8.Invoke_O__O(tmp9), A_arbace_g2a_print_code_A_const_106)} }; return nil }(); /*line :783:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }
//line :783:1
func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :783:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A) Ctor_I_O_O(c__n int32, c__el, c__multi_QMARK_ any) { t.F_n = c__n; t.F_el = c__el; t.F_multi_QMARK_ = c__multi_QMARK_ }
//line :783:1
func (t *A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var G__1022000284__3_ any = A_arbace_g2a_print_code_A_const_207.Invoke_O__O(t.F_el)
L1: switch { default: switch lang.Util_Hash_O__I(G__1022000284__3_) { case 1021133523: if any(G__1022000284__3_) == any(A_arbace_g2a_print_code_A_const_212) {
	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_210; var tmp4 any; var t_ any = t.F_el; t.F_el = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3.Invoke_O__O(tmp4), A_arbace_g2a_print_code_A_const_106)
//line :784:1
	break L1 }; default:
}
	if lang.Util_Equiv_O_O__Z(A_arbace_g2a_print_code_A_const_207.Invoke_O__O(t.F_el), A_arbace_g2a_print_code_A_const_208) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_209.Invoke_O__O(t.F_el))) } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_209.Invoke_O__O(t.F_el), A_arbace_g2a_print_code_A_const_106) }
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38)
	var tmp5 any; var and__1927000168__auto____4 any; var t__2 any = t.F_multi_QMARK_; t.F_multi_QMARK_ = nil; and__1927000168__auto____4 = t__2; if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Numbers_Gt_J_J__Z(int64(t.F_n), 1); if and__1927000168__auto____5 { var tmp6 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; tmp5 = tmp6.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp5 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp5) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_166.GetRawRoot__O()).Invoke__O() } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp8 *lang.Keyword = A_arbace_g2a_print_code_A_const_210; var tmp9 any; var t__3 any = t.F_el; t.F_el = nil; tmp9 = t__3; tmp1 = tmp7.Invoke_O_O__O(tmp8.Invoke_O__O(tmp9), A_arbace_g2a_print_code_A_const_106)} }; return nil }(); /*line :783:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }













func A_arbace_g2a_print_code_slice_expr_A_New() *A_arbace_g2a_print_code_slice_expr_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_slice_expr_A{}; t.Ctor(); return t }
//line :797:1
func (t *A_arbace_g2a_print_code_slice_expr_A) Ctor() {}
//line :797:1
func (t *A_arbace_g2a_print_code_slice_expr_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { var vec__1022000289__3 any = f__0; var seq__1022000290__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000289__3); var first__1022000291__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000290__4); var seq__1022000290__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000290__4); var ___7 any = first__1022000291__5; var first__1022000291__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000290__6); var seq__1022000290__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000290__6); var x__10 any = first__1022000291__8; var idx__11 any = seq__1022000290__9; var idx__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(idx__11); var idx__13 any; _ = ___7; if


	lang.Numbers_Lt_J_J__Z(int64(lang.RT_Count_O__I(idx__12)), 2) { idx__13 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_218.GetRawRoot__O()).Invoke_O_O__O(idx__12, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_219.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(2, int64(lang.RT_Count_O__I(idx__12)))).Ref(), A_arbace_g2a_print_code_A_const_220)) } else { idx__13 = idx__12 }; var present__14 any; var tmp1 lang.IFn = /*line :797:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_154.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_fn_class; if



	fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_179, false); A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; present__14 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), idx__13); var blanks_QMARK___15 any; var and__1927000168__auto____15 bool = /*line :797:1*/lang.Numbers_Lte_O_J__Z(depth__1, 1); if and__1927000168__auto____15 {




		var and__1927000168__auto____16 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(present__14)), 1); if and__1927000168__auto____16 { blanks_QMARK___15 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_39.GetRawRoot__O(), present__14) } else { blanks_QMARK___15 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____16).Ref() } } else { blanks_QMARK___15 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____15).Ref() };
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(x__10, A_arbace_g2a_print_code_A_const_43, A_arbace_g2a_print_code_A_const_106);
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_97); var tmp4 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_print_code_A_const_185; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Ref())); var tmp8 any = A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_New_O_O_O(depth__1, idx__13, blanks_QMARK___15); var tmp9 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_180, false); A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_fn_class = fncls__46d; tmp9 = fncls__46d } else { tmp9 = fncls__46 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O(); return /*line :812:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_99) }
//line :801:1
func A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_New() *A_arbace_g2a_print_code_slice_expr_fn__1022000292_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_slice_expr_fn__1022000292_A{}; t.Ctor(); return t }
//line :801:1
func (t *A_arbace_g2a_print_code_slice_expr_fn__1022000292_A) Ctor() {}
//line :801:1
func (t *A_arbace_g2a_print_code_slice_expr_fn__1022000292_A) Invoke_O_O__O(self, p1__1022000288_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(p1__1022000288_SHARP___1, A_arbace_g2a_print_code_A_const_221) }



func A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_print_code_slice_expr_fn__1022000294_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_slice_expr_fn__1022000294_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :805:1
func (t *A_arbace_g2a_print_code_slice_expr_fn__1022000294_A) Ctor_O_O_O(c__depth, c__idx, c__blanks_QMARK_ any) { t.F_depth = c__depth; t.F_idx = c__idx; t.F_blanks_QMARK_ = c__blanks_QMARK_ }
//line :805:1
func (t *A_arbace_g2a_print_code_slice_expr_fn__1022000294_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1022000295__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_78.GetRawRoot__O(), t.F_idx)); var chunk_1022000296__4 any; var count_1022000297__5 int64 = 0; var i_1022000298__6 int64 = 0; L1: for {
											if lang.Numbers_Lt_J_J__Z(i_1022000298__6, count_1022000297__5) { var vec__1022000299__7 any = lang.Indexed_Cast(chunk_1022000296__4).Nth_I__O(lang.RT_IntCast_J__I(i_1022000298__6)); var i__8 any = lang.RT_Nth_O_I_O__O(vec__1022000299__7, lang.RT_IntCast_J__I(0), nil); var ix__9 any = lang.RT_Nth_O_I_O__O(vec__1022000299__7, lang.RT_IntCast_J__I(1), nil)
												if lang.Numbers_IsPos_O__Z(i__8) {
													var tmp2 any; var and__1927000168__auto____10 any = t.F_blanks_QMARK_; if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp3 any = t.F_idx; tmp2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(i__8))), A_arbace_g2a_print_code_A_const_222) } else { tmp2 = and__1927000168__auto____10 }; if jrt.A2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
													lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38)
													var tmp4 any; var and__1927000168__auto____10_2 any = t.F_blanks_QMARK_; if jrt.A2g_Truth(and__1927000168__auto____10_2) { tmp4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(ix__9, A_arbace_g2a_print_code_A_const_223) } else { tmp4 = and__1927000168__auto____10_2 }; if jrt.A2g_Truth(tmp4) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() } }
												if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(ix__9, A_arbace_g2a_print_code_A_const_224)) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(ix__9, lang.Numbers_Inc_O__Number(t.F_depth)) }
//line :806:1
		seq_1022000295__3, chunk_1022000296__4, count_1022000297__5, i_1022000298__6 = seq_1022000295__3, chunk_1022000296__4, count_1022000297__5, lang.Numbers_Unchecked_inc_J__J(i_1022000298__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000295__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1022000295__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000295__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000295__8); seq_1022000295__3, chunk_1022000296__4, count_1022000297__5, i_1022000298__6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000295__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1022000302__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000295__8); var i__10 any = lang.RT_Nth_O_I_O__O(vec__1022000302__9, lang.RT_IntCast_J__I(0), nil); var ix__11 any = lang.RT_Nth_O_I_O__O(vec__1022000302__9, lang.RT_IntCast_J__I(1), nil)
			if lang.Numbers_IsPos_O__Z(i__10) {
				var tmp5 any; var and__1927000168__auto____12 any = t.F_blanks_QMARK_; if jrt.A2g_Truth(and__1927000168__auto____12) { var tmp6 any = t.F_idx; tmp5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(tmp6, lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(i__10))), A_arbace_g2a_print_code_A_const_222) } else { tmp5 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp5) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38)
				var tmp7 any; var and__1927000168__auto____12_2 any = t.F_blanks_QMARK_; if jrt.A2g_Truth(and__1927000168__auto____12_2) { tmp7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(ix__11, A_arbace_g2a_print_code_A_const_223) } else { tmp7 = and__1927000168__auto____12_2 }; if jrt.A2g_Truth(tmp7) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() } }
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(ix__11, A_arbace_g2a_print_code_A_const_224)) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(ix__11, lang.Numbers_Inc_O__Number(t.F_depth)) }
//line :806:1
			seq_1022000295__3, chunk_1022000296__4, count_1022000297__5, i_1022000298__6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000295__8), nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :805:1
	break L1 } }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }








func A_arbace_g2a_print_code_func_lit_A_New() *A_arbace_g2a_print_code_func_lit_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_func_lit_A{}; t.Ctor(); return t }
//line :814:1
func (t *A_arbace_g2a_print_code_func_lit_A) Ctor() {}
//line :814:1
func (t *A_arbace_g2a_print_code_func_lit_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000307__2 any = f__0; var seq__1022000308__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000307__2); var first__1022000309__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000308__3); var seq__1022000308__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000308__3); var ___6 any = first__1022000309__4; var first__1022000309__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000308__5); var seq__1022000308__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000308__5); var params__9 any = first__1022000309__7; var more__10 any = seq__1022000308__8; var vec__1022000310__11 any; _ = ___6; if



	lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(more__10), A_arbace_g2a_print_code_A_const_159) { vec__1022000310__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(more__10), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(more__10)) } else { vec__1022000310__11 = lang.Tuple_Create_O_O__IPersistentVector(nil, more__10) }; var results__12 any = /*line :814:1*/lang.RT_Nth_O_I_O__O(vec__1022000310__11, lang.RT_IntCast_J__I(0), nil); var body__13 any = lang.RT_Nth_O_I_O__O(vec__1022000310__11, lang.RT_IntCast_J__I(1), nil); var res__14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_160.GetRawRoot__O()).Invoke_O_O__O(params__9, results__12); if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(params__9)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_127, f__0) }; var indent__15 any = /*line :814:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_225.GetRawRoot__O()).Invoke__O();







	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_26); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any; tmp19 := /*line :814:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)









		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_138.GetRawRoot__O()).Invoke_O_O_O__O(params__9, res__14, body__13)
		{ var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_A_const_227; var tmp8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(res__14); var tmp9 any = A_arbace_g2a_print_code_A_const_97; var tmp10 *lang.Keyword = A_arbace_g2a_print_code_A_const_102; var tmp11 any = tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); var tmp12 any = A_arbace_g2a_print_code_A_const_228; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; var tmp14 any = tmp13.Ref(); var tmp15 any = A_arbace_g2a_print_code_A_const_229; var tmp16 any = A_arbace_g2a_print_code_A_const_68.GetRawRoot__O(); var tmp17 any = A_arbace_g2a_print_code_A_const_95; var tmp18 any = A_arbace_g2a_print_code_A_const_96; tmp5 = tmp6.Invoke_O_O__O(body__13, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, f__0, tmp18, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_230.GetRawRoot__O()).Invoke_O_O__O(f__0, body__13), A_arbace_g2a_print_code_A_const_134, indent__15))) }
//line :814:1
		return nil }();








	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if /*line :814:1*/ tmp19 != nil { panic(tmp19) }; return tmp5 }













func A_arbace_g2a_print_code_new_arg_A_New() *A_arbace_g2a_print_code_new_arg_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_new_arg_A{}; t.Ctor(); return t }
//line :828:1
func (t *A_arbace_g2a_print_code_new_arg_A) Ctor() {}
//line :828:1
func (t *A_arbace_g2a_print_code_new_arg_A) Invoke_O_O__O(self, x__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_71.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_231.GetRawRoot__O()).Invoke_O__O(x__0) } }; if jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(x__0) } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(x__0, A_arbace_g2a_print_code_A_const_106)
		} }
func A_arbace_g2a_print_code_expr1_A_New() *A_arbace_g2a_print_code_expr1_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr1_A{}; t.Ctor(); return t }
//line :836:1
func (t *A_arbace_g2a_print_code_expr1_A) Ctor() {}
//line :836:1
func (t *A_arbace_g2a_print_code_expr1_A) Invoke_O_O_O_O__O(self, f__0, prec1__1, depth__2 any) any {


	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(f__0))
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_39.GetRawRoot__O()).Invoke_O__O(f__0)) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O_O_O__O(f__0, prec1__1, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_239.GetRawRoot__O()).Invoke_O_O__O(f__0, depth__2), depth__2) } else {
//line :840:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(f__0)) {


				if lang.Numbers_Lt_J_O__Z(6, prec1__1) {
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any = A_arbace_g2a_print_code_expr1_fn__1022000315_A_New_O(f__0); var tmp6 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_g2a_print_code_expr1_fn__1022000315_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_g2a_print_code_expr1_fn__1022000315_A_fn_class = fncls__48d; tmp6 = fncls__48d } else { tmp6 = fncls__48 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
//line :843:1
						var o__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_191.GetRawRoot__O()).Invoke_O__O(f__0); var x__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_233.GetRawRoot__O()).Invoke_O__O(f__0)


						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(o__4)
						if lang.Util_Equiv_O_O__Z(o__4, Lit_4) {
							if lang.Numbers_Lt_O_J__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_234.GetRawRoot__O()).Invoke_O__O(x__5), 6) {
								lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_print_code_A_const_185; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10.Ref())); var tmp11 any = A_arbace_g2a_print_code_expr1_fn__1022000317_A_New_O(x__5); var tmp12 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_g2a_print_code_expr1_fn__1022000317_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_g2a_print_code_expr1_fn__1022000317_A_fn_class = fncls__49d; tmp12 = fncls__49d } else { tmp12 = fncls__49 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
									return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(x__5, A_arbace_g2a_print_code_A_const_42, A_arbace_g2a_print_code_A_const_106) } } else {
										return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(x__5, A_arbace_g2a_print_code_A_const_42, depth__2) } } } else {
//line :840:1
											var tmp13 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(f__0)











											if jrt.A2g_Truth(or__1927000174__auto____4) { tmp13 = or__1927000174__auto____4 } else { tmp13 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_71.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :840:1
											if jrt.A2g_Truth(tmp13) {











												return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :840:1
													var tmp14 any; var or__1927000174__auto____4_2 bool = lang.Util_Identical_O_O__Z(f__0, nil)












													if or__1927000174__auto____4_2 { tmp14 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4_2).Ref() } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_84.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp14 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_85.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp14 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____7) { tmp14 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_90.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____8) { tmp14 = or__1927000174__auto____8 } else { tmp14 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_34.GetRawRoot__O()).Invoke_O__O(f__0) } } } } }
//line :840:1
													if jrt.A2g_Truth(tmp14) {












														return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_235.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :840:1
															if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0)) { var o__4_2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)
																var G__1022000319__5_ any = o__4_2














																switch lang.Util_Hash_O__I(G__1022000319__5_) >> 10 & 127 { case 3: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_72) {



















																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_236.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :856:1
																case 23: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_76) { var x__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)






















																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_77), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_93.GetRawRoot__O()).Invoke_O__O(x__6), nil)).Ref()) }
//line :856:1
																case 25: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_78) {










																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_237.GetRawRoot__O()).Invoke_O_O__O(f__0, depth__2) }
//line :856:1
																case 27: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_79) { var vec__1022000320__6 any = f__0; var ___7 any = lang.RT_Nth_O_I_O__O(vec__1022000320__6, lang.RT_IntCast_J__I(0), nil); var t__8 any = lang.RT_Nth_O_I_O__O(vec__1022000320__6, lang.RT_IntCast_J__I(1), nil); var m__9 any = lang.RT_Nth_O_I_O__O(vec__1022000320__6, lang.RT_IntCast_J__I(2), nil); var tmp15 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__8); _ = ___7















																	if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_240); tmp15 = tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__8)) } else { tmp15 = and__1927000168__auto____10 }; if jrt.A2g_Truth(tmp15) {
																		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__8); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
																			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__8) }
																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_80); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(m__9)) }
//line :856:1
																case 28: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_81) { var vec__1022000323__6 any = f__0; var ___7_2 any = lang.RT_Nth_O_I_O__O(vec__1022000323__6, lang.RT_IntCast_J__I(0), nil); var t__8_2 any = lang.RT_Nth_O_I_O__O(vec__1022000323__6, lang.RT_IntCast_J__I(1), nil); var x__9 any = lang.RT_Nth_O_I_O__O(vec__1022000323__6, lang.RT_IntCast_J__I(2), nil); _ = ___7_2







																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(x__9, A_arbace_g2a_print_code_A_const_43, A_arbace_g2a_print_code_A_const_106); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_80); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__8_2); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :856:1
																case 35: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_82) { var vec__1022000326__6 any = f__0; var seq__1022000327__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000326__6); var first__1022000328__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000327__7); var seq__1022000327__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000327__7); var ___10 any = first__1022000328__8; var first__1022000328__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000327__9); var seq__1022000327__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000327__9); var g__13 any = first__1022000328__11; var xs__14 any = seq__1022000327__12; _ = ___10

























																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(g__13))
																	var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp19 any = A_arbace_g2a_print_code_A_const_185; var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_FALSE; tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(tmp19, tmp20.Ref()))
//line :856:1
																	var tmp21 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


























																		{ var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_238.GetRawRoot__O()); var tmp23 any; if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(xs__14)), 1) { tmp23 = lang.Numbers_Inc_O__Number(depth__2) } else { tmp23 = depth__2 }; tmp21 = tmp22.Invoke_O_O_O_O__O(f__0, xs__14, tmp23, A_arbace_g2a_print_code_A_const_241) }
//line :856:1
																		return nil
																	}()

























																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :856:1
																	if tmp24 != nil { panic(tmp24) }; return tmp21 }; case 41: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_83) {



























																		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :856:1
																case 43: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_84) { var vec__1022000329__6 any = f__0; var ___7_3 any = lang.RT_Nth_O_I_O__O(vec__1022000329__6, lang.RT_IntCast_J__I(0), nil); var t__8_3 any = lang.RT_Nth_O_I_O__O(vec__1022000329__6, lang.RT_IntCast_J__I(1), nil); var x__9_2 any = lang.RT_Nth_O_I_O__O(vec__1022000329__6, lang.RT_IntCast_J__I(2), nil); var tmp25 any; var and__1927000168__auto____10_2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__8_3); _ = ___7_3


																	if jrt.A2g_Truth(and__1927000168__auto____10_2) { var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_242); tmp25 = tmp26.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__8_3)) } else { tmp25 = and__1927000168__auto____10_2 }; if jrt.A2g_Truth(tmp25) {
																		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__8_3); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
																			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__8_3) }
																	var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_125.GetRawRoot__O()); var tmp28 any = lang.Tuple_Create_O__IPersistentVector(x__9_2); var tmp29 any = A_arbace_g2a_print_code_expr1_fn__1022000332_A_New_O(depth__2); var tmp30 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_g2a_print_code_expr1_fn__1022000332_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_g2a_print_code_expr1_fn__1022000332_A_fn_class = fncls__50d; tmp30 = fncls__50d } else { tmp30 = fncls__50 }; return tmp27.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, tmp28, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_241))) }
//line :856:1
																case 60: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_24) {





























																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_86, f__0) }
//line :856:1
																case 63: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_87) {






























																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_88, f__0) }
//line :856:1
																case 65: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_89) { var vec__1022000334__6 any = f__0; var seq__1022000335__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000334__6); var first__1022000336__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000335__7); var seq__1022000335__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000335__7); var ___10_2 any = first__1022000336__8; var first__1022000336__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000335__9); var seq__1022000335__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000335__9); var t__13 any = first__1022000336__11; var xs__14_2 any = seq__1022000335__12; var depth__15 any; _ = ___10_2
































																	if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0))), 1) { depth__15 = lang.Numbers_Inc_O__Number(depth__2) } else { depth__15 = depth__2 }
																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_89)
																	var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp33 any = A_arbace_g2a_print_code_A_const_185; var tmp34 *jrt.Boolean; jrt.Boolean_Init(); tmp34 = jrt.Boolean_FALSE; tmp31.Invoke_O__O(tmp32.Invoke_O_O__O(tmp33, tmp34.Ref()))
//line :856:1
																	var tmp35 any; tmp40 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



































																		{ var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_125.GetRawRoot__O()); var tmp37 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_149.GetRawRoot__O()).Invoke_O_O__O(t__13, xs__14_2); var tmp38 any = A_arbace_g2a_print_code_expr1_fn__1022000337_A_New_O(depth__15); var tmp39 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_g2a_print_code_expr1_fn__1022000337_A_fn_class
																			if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_g2a_print_code_expr1_fn__1022000337_A_fn_class = fncls__51d; tmp39 = fncls__51d } else { tmp39 = fncls__51 }
//line :892:1
																			tmp35 = tmp36.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, tmp37, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_106))) }
//line :856:1
																		return nil
																	}()

































																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :856:1
																	if tmp40 != nil { panic(tmp40) }; return tmp35 }; case 89: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_91) { var vec__1022000339__6 any = f__0; var seq__1022000340__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000339__6); var first__1022000341__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000340__7); var seq__1022000340__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000340__7); var ___10_3 any = first__1022000341__8; var first__1022000341__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000340__9); var seq__1022000340__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000340__9); var g__13_2 any = first__1022000341__11; var ts__14 any = seq__1022000340__12; _ = ___10_3












																		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(g__13_2, A_arbace_g2a_print_code_A_const_43, depth__2)
																		var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp43 any = A_arbace_g2a_print_code_A_const_185; var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_FALSE; tmp41.Invoke_O__O(tmp42.Invoke_O_O__O(tmp43, tmp44.Ref()))
//line :856:1
																		var tmp45 any; tmp46 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)













																			tmp45 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_179.GetRawRoot__O()).Invoke_O__O(ts__14)
//line :856:1
																			return nil
																		}()












																		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :856:1
																		if tmp46 != nil { panic(tmp46) }; return tmp45 }; case 101: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_92) {




















																			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0))).Ref())) }
//line :856:1
																case 103: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_93) {




























																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_94, f__0) }
//line :856:1
																case 104: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_95) {
																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_243.GetRawRoot__O()).Invoke_O_O__O(f__0, depth__2) }
//line :856:1
																case 105: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_96) { var vec__1022000342__6 any = f__0; var ___7_4 any = lang.RT_Nth_O_I_O__O(vec__1022000342__6, lang.RT_IntCast_J__I(0), nil); var x__8 any = lang.RT_Nth_O_I_O__O(vec__1022000342__6, lang.RT_IntCast_J__I(1), nil); var i__9 any = lang.RT_Nth_O_I_O__O(vec__1022000342__6, lang.RT_IntCast_J__I(2), nil); _ = ___7_4









																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(x__8, A_arbace_g2a_print_code_A_const_43, A_arbace_g2a_print_code_A_const_106); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_97); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp49 any = A_arbace_g2a_print_code_A_const_185; var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_FALSE; tmp47.Invoke_O__O(tmp48.Invoke_O_O__O(tmp49, tmp50.Ref())); var tmp51 any = A_arbace_g2a_print_code_expr1_fn__1022000345_A_New_O_O(i__9, depth__2); var tmp52 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_g2a_print_code_expr1_fn__1022000345_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_g2a_print_code_expr1_fn__1022000345_A_fn_class = fncls__52d; tmp52 = fncls__52d } else { tmp52 = fncls__52 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_99) }
//line :856:1
																case 106: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_100) { var vec__1022000347__6 any = f__0; var ___7_5 any = lang.RT_Nth_O_I_O__O(vec__1022000347__6, lang.RT_IntCast_J__I(0), nil); var x__8_2 any = lang.RT_Nth_O_I_O__O(vec__1022000347__6, lang.RT_IntCast_J__I(1), nil); _ = ___7_5







































																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_100)
																	var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp55 any = A_arbace_g2a_print_code_A_const_185; var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_FALSE; tmp53.Invoke_O__O(tmp54.Invoke_O_O__O(tmp55, tmp56.Ref()))
//line :856:1
																	var tmp57 any; tmp62 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)









































																		{ var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_125.GetRawRoot__O()); var tmp59 any = lang.Tuple_Create_O__IPersistentVector(x__8_2); var tmp60 any = A_arbace_g2a_print_code_expr1_fn__1022000350_A_New(); var tmp61 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_g2a_print_code_expr1_fn__1022000350_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); A_arbace_g2a_print_code_expr1_fn__1022000350_A_fn_class = fncls__53d; tmp61 = fncls__53d } else { tmp61 = fncls__53 }; tmp57 = tmp58.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, tmp59, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_106))) }
//line :856:1
																		return nil
																	}()







































																	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :856:1
																	if tmp62 != nil { panic(tmp62) }; return tmp57 }; case 108: if lang.Util_Equiv_O_O__Z(G__1022000319__5_, Lit_102) {























																		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_245.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0))) }
//line :856:1
																default:
																}









































																if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_44.GetRawRoot__O(), o__4_2)) {
																	return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_103, f__0) } else {
//line :899:1
																		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_231.GetRawRoot__O()).Invoke_O__O(f__0)) {

																			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :899:1
																				var tmp63 any
																				var and__1927000168__auto____6 any = o__4_2

																				if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_145.GetRawRoot__O()).Invoke_O_O__O(o__4_2, Lit_104); if jrt.A2g_Truth(and__1927000168__auto____7) { tmp63 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(o__4_2)), 2)).Ref() } else { tmp63 = and__1927000168__auto____7 } } else { tmp63 = and__1927000168__auto____6 }
//line :899:1
																				if jrt.A2g_Truth(tmp63) {



																					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_g2a_print_code_A_const_43, depth__2); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_80); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_246.GetRawRoot__O()).Invoke_O_O__O(o__4_2, A_arbace_g2a_print_code_A_const_241)) } else {
//line :899:1
																						var tmp64 any
																						var and__1927000168__auto____6_2 any = o__4_2



																						if jrt.A2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_145.GetRawRoot__O()).Invoke_O_O__O(o__4_2, Lit_80); if jrt.A2g_Truth(and__1927000168__auto____7_2) { var and__1927000168__auto____8 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(o__4_2)), 1); if and__1927000168__auto____8 { tmp64 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(o__4_2, Lit_25) } else { tmp64 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp64 = and__1927000168__auto____7_2 } } else { tmp64 = and__1927000168__auto____6_2 }
//line :899:1
																						if jrt.A2g_Truth(tmp64) { var vec__1022000352__6 any = f__0; var seq__1022000353__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000352__6); var first__1022000354__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000353__7); var seq__1022000353__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000353__7); var ___10_4 any = first__1022000354__8; var first__1022000354__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000353__9); var seq__1022000353__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000353__9); var recv__13 any = first__1022000354__11; var xs__14_3 any = seq__1022000353__12; _ = ___10_4






																							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(recv__13, A_arbace_g2a_print_code_A_const_43, depth__2); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_80); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_246.GetRawRoot__O()).Invoke_O_O__O(o__4_2, A_arbace_g2a_print_code_A_const_106))
																							var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp67 any = A_arbace_g2a_print_code_A_const_185; var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_FALSE; tmp65.Invoke_O__O(tmp66.Invoke_O_O__O(tmp67, tmp68.Ref()))
//line :899:1
																							var tmp69 any; tmp72 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







																								{ var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_238.GetRawRoot__O()); var tmp71 any; if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(xs__14_3)), 1) { tmp71 = lang.Numbers_Inc_O__Number(depth__2) } else { tmp71 = depth__2 }; tmp69 = tmp70.Invoke_O_O_O_O__O(f__0, xs__14_3, tmp71, A_arbace_g2a_print_code_A_const_241) }
//line :899:1
																								return nil
																							}()






																							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :899:1
																							if tmp72 != nil { panic(tmp72) }; return tmp69 } else { if A_arbace_g2a_print_code_A_const_30 != nil { var vec__1022000355__6 any = f__0; var seq__1022000356__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000355__6); var first__1022000357__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000356__7); var seq__1022000356__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000356__7); var h__10 any = first__1022000357__8; var xs__11 any = seq__1022000356__9; var depth__12 any










																								if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(xs__11)), 1) { depth__12 = lang.Numbers_Inc_O__Number(depth__2) } else { depth__12 = depth__2 }
																								lang.IFn_Cast(A_arbace_g2a_print_code_A_const_247.GetRawRoot__O()).Invoke_O_O__O(h__10, depth__12)
																								var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp74 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp75 any = A_arbace_g2a_print_code_A_const_185; var tmp76 *jrt.Boolean; jrt.Boolean_Init(); tmp76 = jrt.Boolean_FALSE; tmp73.Invoke_O__O(tmp74.Invoke_O_O__O(tmp75, tmp76.Ref()))
//line :899:1
																								var tmp77 any; tmp78 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)












																									tmp77 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_238.GetRawRoot__O()).Invoke_O_O_O_O__O(f__0, xs__11, depth__12, A_arbace_g2a_print_code_A_const_106)
//line :899:1
																									return nil
																								}()











																								lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :899:1
																								if tmp78 != nil { panic(tmp78) }; return tmp77 } else { return nil } } } } } } else {
//line :840:1
																									if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(f__0)) {








































































																										return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_105, f__0) } else {
//line :840:1
																											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(f__0)) {









































































																												return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_106, f__0) } else {
//line :840:1
																													if A_arbace_g2a_print_code_A_const_30 != nil {










































































																														return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_107, f__0) } else {
//line :840:1
																															return nil
																														}
																												}
																										} } } } } } }
func A_arbace_g2a_print_code_expr1_fn__1022000315_A_New_O(p0 any) *A_arbace_g2a_print_code_expr1_fn__1022000315_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr1_fn__1022000315_A{}; t.Ctor_O(p0); return t }
//line :844:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000315_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :844:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000315_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_g2a_print_code_A_const_106) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }




func A_arbace_g2a_print_code_expr1_fn__1022000317_A_New_O(p0 any) *A_arbace_g2a_print_code_expr1_fn__1022000317_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr1_fn__1022000317_A{}; t.Ctor_O(p0); return t }
//line :849:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000317_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :849:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000317_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_x; t.F_x = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_g2a_print_code_A_const_106) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }












func A_arbace_g2a_print_code_expr1_fn__1022000332_A_New_O(p0 any) *A_arbace_g2a_print_code_expr1_fn__1022000332_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr1_fn__1022000332_A{}; t.Ctor_O(p0); return t }
//line :862:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000332_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :862:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000332_A) Invoke_O_O_O__O(self, x__1, ___2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(x__1, t.F_depth); return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp5 }



func A_arbace_g2a_print_code_expr1_fn__1022000345_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_expr1_fn__1022000345_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr1_fn__1022000345_A{}; t.Ctor_O_O(p0, p1); return t }
//line :866:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000345_A) Ctor_O_O(c__i, c__depth any) { t.F_i = c__i; t.F_depth = c__depth }
//line :866:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000345_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_depth; t.F_depth = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Numbers_Inc_O__Number(tmp5)) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }


























func A_arbace_g2a_print_code_expr1_fn__1022000337_A_New_O(p0 any) *A_arbace_g2a_print_code_expr1_fn__1022000337_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr1_fn__1022000337_A{}; t.Ctor_O(p0); return t }
//line :893:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000337_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :893:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000337_A) Invoke_O_O_O__O(self, x__1, i__2 any) any { if lang.Numbers_IsZero_O__Z(i__2) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(x__1) } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(x__1, t.F_depth) } }




func A_arbace_g2a_print_code_expr1_fn__1022000350_A_New() *A_arbace_g2a_print_code_expr1_fn__1022000350_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr1_fn__1022000350_A{}; t.Ctor(); return t }
//line :898:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000350_A) Ctor() {}
//line :898:1
func (t *A_arbace_g2a_print_code_expr1_fn__1022000350_A) Invoke_O_O_O__O(self, x__1, ___2 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_244.GetRawRoot__O()).Invoke_O__O(x__1) }


















func A_arbace_g2a_print_code_expr0_A_New() *A_arbace_g2a_print_code_expr0_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr0_A{}; t.Ctor(); return t }
//line :917:1
func (t *A_arbace_g2a_print_code_expr0_A) Ctor() {}
//line :917:1
func (t *A_arbace_g2a_print_code_expr0_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(f__0, A_arbace_g2a_print_code_A_const_157, depth__1) }

func A_arbace_g2a_print_code_expr_list_A_New() *A_arbace_g2a_print_code_expr_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr_list_A{}; t.Ctor(); return t }
//line :919:1
func (t *A_arbace_g2a_print_code_expr_list_A) Ctor() {}
//line :919:1
func (t *A_arbace_g2a_print_code_expr_list_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { var vs_QMARK___3 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if



	jrt.A2g_Truth(and__1927000168__auto____3) { vs_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0), Lit_93)).Ref() } else { vs_QMARK___3 = and__1927000168__auto____3 }; var xs__4 any; if
	jrt.A2g_Truth(vs_QMARK___3) { xs__4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0) } else { xs__4 = lang.Tuple_Create_O__IPersistentVector(f__0) }; if
	jrt.A2g_Truth(vs_QMARK___3) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(f__0)) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_248.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_A_const_106; var tmp3 any = A_arbace_g2a_print_code_expr_list_fn__1022000361_A_New_O(depth__1); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_g2a_print_code_expr_list_fn__1022000361_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_g2a_print_code_expr_list_fn__1022000361_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; return tmp1.Invoke_O_O_O_O__O(f__0, tmp2, xs__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :926:1
func A_arbace_g2a_print_code_expr_list_fn__1022000361_A_New_O(p0 any) *A_arbace_g2a_print_code_expr_list_fn__1022000361_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_expr_list_fn__1022000361_A{}; t.Ctor_O(p0); return t }
//line :926:1
func (t *A_arbace_g2a_print_code_expr_list_fn__1022000361_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :926:1
func (t *A_arbace_g2a_print_code_expr_list_fn__1022000361_A) Invoke_O_O__O(self, p1__1022000360_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(p1__1022000360_SHARP___1, t.F_depth) }

func A_arbace_g2a_print_code_n_values_A_New() *A_arbace_g2a_print_code_n_values_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_n_values_A{}; t.Ctor(); return t }
//line :928:1
func (t *A_arbace_g2a_print_code_n_values_A) Ctor() {}
//line :928:1
func (t *A_arbace_g2a_print_code_n_values_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0), Lit_93)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0))).Ref() } else { return A_arbace_g2a_print_code_A_const_106 } }




func A_arbace_g2a_print_code_zero_form_QMARK__A_New() *A_arbace_g2a_print_code_zero_form_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_zero_form_QMARK__A{}; t.Ctor(); return t }
//line :933:1
func (t *A_arbace_g2a_print_code_zero_form_QMARK__A) Ctor() {}
//line :933:1
func (t *A_arbace_g2a_print_code_zero_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0), Lit_87)).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_print_code_targets_A_New() *A_arbace_g2a_print_code_targets_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_targets_A{}; t.Ctor(); return t }
//line :935:1
func (t *A_arbace_g2a_print_code_targets_A) Ctor() {}
//line :935:1
func (t *A_arbace_g2a_print_code_targets_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__0), Lit_93)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(t__0)) } else { return lang.Tuple_Create_O__IPersistentVector(t__0) } }

func A_arbace_g2a_print_code_binding_stmt_A_New() *A_arbace_g2a_print_code_binding_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binding_stmt_A{}; t.Ctor(); return t }
//line :937:1
func (t *A_arbace_g2a_print_code_binding_stmt_A) Ctor() {}
//line :937:1
func (t *A_arbace_g2a_print_code_binding_stmt_A) Invoke_O_O_O__O(self, target__0, init__1 any) any { var ts__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_249.GetRawRoot__O()).Invoke_O__O(target__0); var ms__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_255.GetRawRoot__O(), ts__3); var tm__5 any = lang.RT_Meta_O__IPersistentMap(target__0); var const_QMARK___6 any; var or__1927000174__auto____6 any = A_arbace_g2a_print_code_A_const_250.Invoke_O__O(tm__5); if





	jrt.A2g_Truth(or__1927000174__auto____6) { const_QMARK___6 = or__1927000174__auto____6 } else { const_QMARK___6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_250, ms__4) }; var var_QMARK___7 any; var or__1927000174__auto____7 any = /*line :937:1*/A_arbace_g2a_print_code_A_const_251.Invoke_O__O(tm__5); if






	jrt.A2g_Truth(or__1927000174__auto____7) { var_QMARK___7 = or__1927000174__auto____7 } else { var_QMARK___7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_251, ms__4) }; var typ__8 any; var tmp1 lang.IFn = /*line :937:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_fn_class; if







	fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; typ__8 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ms__4); var names__9 any; var tmp4 any = /*line :937:1*/A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_New_O(ts__3); var tmp5 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_fn_class; if








	fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_fn_class = fncls__55d; tmp5 = fncls__55d } else { tmp5 = fncls__55 }; names__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if
	jrt.A2g_Truth(const_QMARK___6) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_12); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(names__9).Invoke__O()
		if jrt.A2g_Truth(typ__8) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(typ__8) }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_252.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_g2a_print_code_A_const_106) } else {
//line :947:1
			var tmp6 any
			var or__1927000174__auto____10 any = var_QMARK___7


			if jrt.A2g_Truth(or__1927000174__auto____10) { tmp6 = or__1927000174__auto____10 } else { tmp6 = typ__8 }
//line :947:1
			if jrt.A2g_Truth(tmp6) {



				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_13); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(names__9).Invoke__O()
				if jrt.A2g_Truth(typ__8) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(typ__8) }
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_253.GetRawRoot__O()).Invoke_O__O(init__1)) { return nil } else {
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_252.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_g2a_print_code_A_const_106) } } else {
//line :947:1
						if A_arbace_g2a_print_code_A_const_30 != nil { var depth__10 int64; var tmp7 bool; var and__1927000168__auto____10 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ts__3)), 1)







							if and__1927000168__auto____10 { tmp7 = lang.Numbers_Gt_O_J__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_254.GetRawRoot__O()).Invoke_O__O(init__1), 1) } else { tmp7 = and__1927000168__auto____10 }; if tmp7 { depth__10 = 2 } else { depth__10 = 1 }
							var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_248.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_print_code_A_const_106; var tmp10 any = A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_New_J(depth__10); var tmp11 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_fn_class = fncls__57d; tmp11 = fncls__57d } else { tmp11 = fncls__57 }; tmp8.Invoke_O_O_O_O__O(target__0, tmp9, ts__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))
							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_15); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_252.GetRawRoot__O()).Invoke_O_O__O(init__1, jrt.Long_ValueOf_J__Long(depth__10).Ref()) } else {
//line :947:1
								return nil } } } }
//line :945:1
func A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_New() *A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A{}; t.Ctor(); return t }
//line :945:1
func (t *A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A) Ctor() {}
//line :945:1
func (t *A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A) Invoke_O_O__O(self, p1__1022000367_SHARP___1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(p1__1022000367_SHARP___1, A_arbace_g2a_print_code_A_const_107)) { return A_arbace_g2a_print_code_A_const_107.Invoke_O__O(p1__1022000367_SHARP___1) } else { return nil } }
func A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_New_O(p0 any) *A_arbace_g2a_print_code_binding_stmt_names__1022000371_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binding_stmt_names__1022000371_A{}; t.Ctor_O(p0); return t }
//line :946:1
func (t *A_arbace_g2a_print_code_binding_stmt_names__1022000371_A) Ctor_O(c__ts any) { t.F_ts = c__ts }
//line :946:1
func (t *A_arbace_g2a_print_code_binding_stmt_names__1022000371_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_128.GetRawRoot__O()).Invoke_O__O(t.F_ts) }









func A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_New_J(p0 int64) *A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A{}; t.Ctor_J(p0); return t }
//line :956:1
func (t *A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A) Ctor_J(c__depth int64) { t.F_depth = c__depth }
//line :956:1
func (t *A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A) Invoke_O_O__O(self, p1__1022000368_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(p1__1022000368_SHARP___1, jrt.Long_ValueOf_J__Long(t.F_depth).Ref()) }


func A_arbace_g2a_print_code_type_binding_stmt_A_New() *A_arbace_g2a_print_code_type_binding_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_binding_stmt_A{}; t.Ctor(); return t }
//line :959:1
func (t *A_arbace_g2a_print_code_type_binding_stmt_A) Ctor() {}
//line :959:1
func (t *A_arbace_g2a_print_code_type_binding_stmt_A) Invoke_O_O_O__O(self, nm__0, t__1 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_256; var tps__3 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__0)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_117;

	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tps__3)).Ref())); var tmp4 any; tmp6 := /*line :959:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_188); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(nm__0))
		if jrt.A2g_Truth(tps__3) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_257.GetRawRoot__O()).Invoke_O__O(tps__3) }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
		{ var tmp5 *lang.Keyword = A_arbace_g2a_print_code_A_const_258; if jrt.A2g_Truth(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__0))) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
			tmp4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__1) }
//line :959:1
		return nil }();

	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if /*line :959:1*/ tmp6 != nil { panic(tmp6) }; return tmp4 }








func A_arbace_g2a_print_code_assign_stmt_A_New() *A_arbace_g2a_print_code_assign_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_assign_stmt_A{}; t.Ctor(); return t }
//line :968:1
func (t *A_arbace_g2a_print_code_assign_stmt_A) Ctor() {}
//line :968:1
func (t *A_arbace_g2a_print_code_assign_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000377__2 any = f__0; var ___3 any = lang.RT_Nth_O_I_O__O(vec__1022000377__2, lang.RT_IntCast_J__I(0), nil); var place__4 any = lang.RT_Nth_O_I_O__O(vec__1022000377__2, lang.RT_IntCast_J__I(1), nil); var a__5 any = lang.RT_Nth_O_I_O__O(vec__1022000377__2, lang.RT_IntCast_J__I(2), nil); var b__6 any = lang.RT_Nth_O_I_O__O(vec__1022000377__2, lang.RT_IntCast_J__I(3), nil); var G__1022000380__7_ int32 = lang.RT_Count_O__I(f__0); _ = ___3; switch G__1022000380__7_ {

case 3: var depth__8 int64; var tmp1 bool; var and__1927000168__auto____8 bool = lang.Numbers_Gt_O_J__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_254.GetRawRoot__O()).Invoke_O__O(place__4), 1)
	if and__1927000168__auto____8 { tmp1 = lang.Numbers_Gt_O_J__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_254.GetRawRoot__O()).Invoke_O__O(a__5), 1) } else { tmp1 = and__1927000168__auto____8 }; if tmp1 { depth__8 = 2 } else { depth__8 = 1 }
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_252.GetRawRoot__O()).Invoke_O_O__O(place__4, jrt.Long_ValueOf_J__Long(depth__8).Ref()); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_252.GetRawRoot__O()).Invoke_O_O__O(a__5, jrt.Long_ValueOf_J__Long(depth__8).Ref())
//line :970:1
case 4: var aop__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_259.GetRawRoot__O()); var tmp3 any


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_25.GetRawRoot__O()).Invoke_O__O(a__5)) { tmp3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(a__5) } else { tmp3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_72.GetRawRoot__O()).Invoke_O__O(a__5) }; aop__8 = tmp2.Invoke_O__O(tmp3)
	if jrt.A2g_Truth(aop__8) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_2, a__5) }
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(place__4, A_arbace_g2a_print_code_A_const_106); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(aop__8); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(b__6, A_arbace_g2a_print_code_A_const_106)
//line :970:1
default:}; return /*line :976:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_3, f__0) }

func A_arbace_g2a_print_code_simple_stmt_A_New() *A_arbace_g2a_print_code_simple_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_simple_stmt_A{}; t.Ctor(); return t }
//line :978:1
func (t *A_arbace_g2a_print_code_simple_stmt_A) Ctor() {}
//line :978:1
func (t *A_arbace_g2a_print_code_simple_stmt_A) Invoke_O_O__O(self, f__0 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(f__0)) { var G__1022000382__2_ int32 = lang.RT_Count_O__I(f__0)
		switch G__1022000382__2_ { case 1:

			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(f__0))
//line :983:1
		case 2:
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_261.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(f__0), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0))
//line :983:1
		default:
		}

		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_176, f__0) } else {
//line :982:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0)) { var G__1022000383__2_ any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)





				switch lang.Util_Hash_O__I(G__1022000383__2_) >> 4 & 7 { case 0: if lang.Util_Equiv_O_O__Z(G__1022000383__2_, Lit_161) {



					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_g2a_print_code_A_const_241); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_177) }
//line :988:1
				case 2: if lang.Util_Equiv_O_O__Z(G__1022000383__2_, Lit_170) { var vec__1022000384__3 any = f__0; var ___4 any = lang.RT_Nth_O_I_O__O(vec__1022000384__3, lang.RT_IntCast_J__I(0), nil); var ch__5 any = lang.RT_Nth_O_I_O__O(vec__1022000384__3, lang.RT_IntCast_J__I(1), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1022000384__3, lang.RT_IntCast_J__I(2), nil); _ = ___4





					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(ch__5, A_arbace_g2a_print_code_A_const_106); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_32); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(v__6, A_arbace_g2a_print_code_A_const_106) }
//line :988:1
				case 5: if lang.Util_Equiv_O_O__Z(G__1022000383__2_, Lit_162) {




					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_g2a_print_code_A_const_241); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_178) }
//line :988:1
				case 6: if lang.Util_Equiv_O_O__Z(G__1022000383__2_, Lit_163) { var vec__1022000387__3 any = f__0; var ___4_2 any = lang.RT_Nth_O_I_O__O(vec__1022000387__3, lang.RT_IntCast_J__I(0), nil); var a__5 any = lang.RT_Nth_O_I_O__O(vec__1022000387__3, lang.RT_IntCast_J__I(1), nil); var i__6 any = lang.RT_Nth_O_I_O__O(vec__1022000387__3, lang.RT_IntCast_J__I(2), nil); var v__7 any = lang.RT_Nth_O_I_O__O(vec__1022000387__3, lang.RT_IntCast_J__I(3), nil); _ = ___4_2


					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(a__5, A_arbace_g2a_print_code_A_const_43, A_arbace_g2a_print_code_A_const_106); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_97); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(i__6, A_arbace_g2a_print_code_A_const_241); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_99); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(v__7, A_arbace_g2a_print_code_A_const_106) }
//line :988:1
				case 7: if lang.Util_Equiv_O_O__Z(G__1022000383__2_, Lit_172) {
					return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_262.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :988:1
				default:
				}





				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_g2a_print_code_A_const_106) } else {
//line :982:1
					if A_arbace_g2a_print_code_A_const_30 != nil {













						return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_g2a_print_code_A_const_106) } else {
//line :982:1
							return nil
						}
				}
		}
}











func A_arbace_g2a_print_code_clause_QMARK__A_New() *A_arbace_g2a_print_code_clause_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_clause_QMARK__A{}; t.Ctor(); return t }
//line :998:1
func (t *A_arbace_g2a_print_code_clause_QMARK__A) Ctor() {}
//line :998:1
func (t *A_arbace_g2a_print_code_clause_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_263); return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_print_code_control_clause_A_New() *A_arbace_g2a_print_code_control_clause_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_control_clause_A{}; t.Ctor(); return t }
//line :1000:1
func (t *A_arbace_g2a_print_code_control_clause_A) Ctor() {}
//line :1000:1
func (t *A_arbace_g2a_print_code_control_clause_A) Invoke_O_O_O_O_O__O(self, for_QMARK___0, init__1, cond__2, post__3 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref()))
//line :1000:1
	var tmp5 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
//line :1000:1
		{ var init__7 any; var tmp6 any
			var and__1927000168__auto____7 any = init__1



			if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()); var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; tmp6 = tmp7.Invoke_O_O__O(init__1, tmp8.Ref()) } else { tmp6 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp6) { init__7 = init__1 } else { init__7 = nil }
//line :1000:1
			var post__8 any; var tmp9 any
			var and__1927000168__auto____8 any = post__3




			if jrt.A2g_Truth(and__1927000168__auto____8) { tmp9 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(post__3, A_arbace_g2a_print_code_A_const_265) } else { tmp9 = and__1927000168__auto____8 }; if jrt.A2g_Truth(tmp9) { post__8 = post__3 } else { post__8 = nil }
//line :1000:1
			var cond__9 any; var tmp10 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(cond__2)






			if jrt.A2g_Truth(and__1927000168__auto____9) { tmp10 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(cond__2, A_arbace_g2a_print_code_A_const_266) } else { tmp10 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp10) { cond__9 = cond__2 } else { cond__9 = nil }
			var tmp11 bool; var and__1927000168__auto____10 bool = lang.Util_Identical_O_O__Z(init__7, nil); if and__1927000168__auto____10 { tmp11 = lang.Util_Identical_O_O__Z(post__8, nil) } else { tmp11 = and__1927000168__auto____10 }; if tmp11 {
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(cond__9)) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(cond__9, A_arbace_g2a_print_code_A_const_106); tmp5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() } else { tmp5 = nil } } else {
					if jrt.A2g_Truth(init__7) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(init__7) }
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(cond__9)) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(cond__9, A_arbace_g2a_print_code_A_const_106) }
					if jrt.A2g_Truth(for_QMARK___0) {
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
						if jrt.A2g_Truth(post__8) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(post__8); tmp5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() } else { tmp5 = nil } } else {
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(cond__9)) { tmp5 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() } else { tmp5 = nil } } } }
//line :1000:1
		return nil
	}()

	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :1000:1
	if tmp12 != nil { panic(tmp12) }; return tmp5
}
















func A_arbace_g2a_print_code_branch_forms_A_New() *A_arbace_g2a_print_code_branch_forms_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_branch_forms_A{}; t.Ctor(); return t }
//line :1018:1
func (t *A_arbace_g2a_print_code_branch_forms_A) Ctor() {}
//line :1018:1
func (t *A_arbace_g2a_print_code_branch_forms_A) Invoke_O_O__O(self, b__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(b__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(b__0), Lit_20)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(b__0)) } else { return lang.Tuple_Create_O__IPersistentVector(b__0)
	} }
func A_arbace_g2a_print_code_branch_opts_A_New() *A_arbace_g2a_print_code_branch_opts_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_branch_opts_A{}; t.Ctor(); return t }
//line :1023:1
func (t *A_arbace_g2a_print_code_branch_opts_A) Ctor() {}
//line :1023:1
func (t *A_arbace_g2a_print_code_branch_opts_A) Invoke_O_O_O_O__O(self, parent__0, i__1, b__2 any) any {


	var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(b__2); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(b__2), Lit_20)).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, b__2, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_106)) } else { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, parent__0, A_arbace_g2a_print_code_A_const_96, i__1))
	} }
func A_arbace_g2a_print_code_if_like_QMARK__A_New() *A_arbace_g2a_print_code_if_like_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_if_like_QMARK__A{}; t.Ctor(); return t }
//line :1028:1
func (t *A_arbace_g2a_print_code_if_like_QMARK__A) Ctor() {}
//line :1028:1
func (t *A_arbace_g2a_print_code_if_like_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_267); return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return and__1927000168__auto____2 } }



func A_arbace_g2a_print_code_else_part_A_New() *A_arbace_g2a_print_code_else_part_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_else_part_A{}; t.Ctor(); return t }
//line :1032:1
func (t *A_arbace_g2a_print_code_else_part_A) Ctor() {}
//line :1032:1
func (t *A_arbace_g2a_print_code_else_part_A) Invoke_O_O_O__O(self, els__0, opts__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_73); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_268.GetRawRoot__O()).Invoke_O__O(els__0)) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_269.GetRawRoot__O()).Invoke_O__O(els__0) } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(els__0), opts__1)
		} }
func A_arbace_g2a_print_code_if_stmt_A_New() *A_arbace_g2a_print_code_if_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_if_stmt_A{}; t.Ctor(); return t }
//line :1038:1
func (t *A_arbace_g2a_print_code_if_stmt_A) Ctor() {}
//line :1038:1
func (t *A_arbace_g2a_print_code_if_stmt_A) Invoke_O_O__O(self, f__0 any) any { var o__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0); var G__1022000397__3_ any = o__2; switch

	lang.Util_Hash_O__I(G__1022000397__3_) >> 2 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__1022000397__3_, Lit_133) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_271.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_A_const_241; var pairs__4 any = tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0))






















		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_273.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0))).Ref())) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_134, f__0) }
//line :1040:1
		var G__1022000404__5_ any = pairs__4; var vec__1022000405__6 any = G__1022000404__5_; var seq__1022000406__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000405__6); var first__1022000407__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000406__7); var seq__1022000406__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000406__7); var vec__1022000408__10 any = first__1022000407__8; var t__11 any = lang.RT_Nth_O_I_O__O(vec__1022000408__10, lang.RT_IntCast_J__I(0), nil); var b__12 any = lang.RT_Nth_O_I_O__O(vec__1022000408__10, lang.RT_IntCast_J__I(1), nil); var more__13 any = seq__1022000406__9; var bi__14 int64 = 2; var G__1022000404__15_ any = G__1022000404__5_; var bi__16 int64 = bi__14; _ = t__11; _ = b__12; _ = more__13; L2: for { var vec__1022000411__17 any = G__1022000404__15_; var seq__1022000412__18 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000411__17); var first__1022000413__19 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000412__18); var seq__1022000412__20 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000412__18); var vec__1022000414__21 any = first__1022000413__19; var t__22 any = lang.RT_Nth_O_I_O__O(vec__1022000414__21, lang.RT_IntCast_J__I(0), nil); var b__23 any = lang.RT_Nth_O_I_O__O(vec__1022000414__21, lang.RT_IntCast_J__I(1), nil)
			var more__24 any = seq__1022000412__20
			var bi__25 int64 = bi__16






















			if lang.Util_Equiv_O_O__Z(t__22, A_arbace_g2a_print_code_A_const_30) {
				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(b__23), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_274.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long(bi__25).Ref(), b__23)) } else {
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_135); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_275.GetRawRoot__O()); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp3.Invoke_O_O_O_O__O(tmp4.Ref(), nil, t__22, nil)
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(more__24)) { var vec__1022000417__26 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(more__24); var nt__27 any = lang.RT_Nth_O_I_O__O(vec__1022000417__26, lang.RT_IntCast_J__I(0), nil); var nb__28 any = lang.RT_Nth_O_I_O__O(vec__1022000417__26, lang.RT_IntCast_J__I(1), nil); var nl__29 any

						if lang.Util_Equiv_O_O__Z(nt__27, A_arbace_g2a_print_code_A_const_30) { nl__29 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_137.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(nb__28)) } else { nl__29 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(nt__27) }
						var tmp5 any = A_arbace_g2a_print_code_A_const_277; var tmp6 any = A_arbace_g2a_print_code_A_const_278; var tmp7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(nt__27, A_arbace_g2a_print_code_A_const_30); var tmp8 any = A_arbace_g2a_print_code_A_const_279; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(b__23), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_276.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_274.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long(bi__25).Ref(), b__23), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, nl__29, tmp6, tmp7, tmp8, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(nt__27, A_arbace_g2a_print_code_A_const_30)).Ref()))))


						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_73); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
						G__1022000404__15_, bi__16 = more__24, lang.Numbers_Add_J_J__J(bi__25, 2); continue L2 } else {
							return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(b__23), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_274.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long(bi__25).Ref(), b__23)) } } } }
//line :1040:1
	case 2: if lang.Util_Equiv_O_O__Z(G__1022000397__3_, Lit_136) { var vec__1022000420__4 any = f__0; var seq__1022000421__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000420__4); var first__1022000422__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000421__5); var seq__1022000421__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000421__5); var ___8 any = first__1022000422__6; var xs__9 any = seq__1022000421__7; var vec__1022000423__10 any; _ = ___8

















		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__9))) { vec__1022000423__10 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__9), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__9)) } else { vec__1022000423__10 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__9) }
//line :1040:1
		var init__11 any = lang.RT_Nth_O_I_O__O(vec__1022000423__10, lang.RT_IntCast_J__I(0), nil); var xs__12 any = lang.RT_Nth_O_I_O__O(vec__1022000423__10, lang.RT_IntCast_J__I(1), nil); var vec__1022000426__13 any = xs__12; var seq__1022000427__14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000426__13); var first__1022000428__15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000427__14); var seq__1022000427__16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000427__14)
		var c__17 any = first__1022000428__15
		var body__18 any = seq__1022000427__16

















		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_135); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_275.GetRawRoot__O()); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; tmp9.Invoke_O_O_O_O__O(tmp10.Ref(), init__11, c__17, nil)
		var tmp11 any = A_arbace_g2a_print_code_A_const_95; var tmp12 any = A_arbace_g2a_print_code_A_const_96; return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(body__18), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, f__0, tmp12, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_230.GetRawRoot__O()).Invoke_O_O__O(f__0, body__18)))) }
//line :1040:1
	case 3: if lang.Util_Equiv_O_O__Z(G__1022000397__3_, Lit_135) { var vec__1022000429__4 any = f__0; var seq__1022000430__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000429__4); var first__1022000431__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000430__5); var seq__1022000430__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000430__5); var ___8_2 any = first__1022000431__6; var xs__9_2 any = seq__1022000430__7; var vec__1022000432__10 any; _ = ___8_2

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__9_2))) { vec__1022000432__10 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__9_2), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__9_2)) } else { vec__1022000432__10 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__9_2) }
//line :1040:1
		var init__11_2 any = lang.RT_Nth_O_I_O__O(vec__1022000432__10, lang.RT_IntCast_J__I(0), nil); var xs__12_2 any = lang.RT_Nth_O_I_O__O(vec__1022000432__10, lang.RT_IntCast_J__I(1), nil); var vec__1022000435__13 any = xs__12_2; var seq__1022000436__14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000435__13); var first__1022000437__15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000436__14); var seq__1022000436__16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000436__14); var c__17_2 any = first__1022000437__15; var first__1022000437__18 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000436__16); var seq__1022000436__19 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000436__16)
		var then__20 any = first__1022000437__18
		var more__21 any = seq__1022000436__19

		if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(more__21)), 1) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_137, f__0) }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_135); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_275.GetRawRoot__O()); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_FALSE; tmp13.Invoke_O_O_O_O__O(tmp14.Ref(), init__11_2, c__17_2, nil)
//line :1040:1
		var ti__22 int64





		if jrt.A2g_Truth(init__11_2) { ti__22 = 3 } else { ti__22 = 2 }
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(more__21)) { var els__23 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(more__21); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()); var tmp16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(then__20); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_276.GetRawRoot__O()); var tmp18 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_274.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long(ti__22).Ref(), then__20); var tmp19 any = A_arbace_g2a_print_code_A_const_277; var tmp20 any; var or__1927000174__auto____24 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(els__23)


			if jrt.A2g_Truth(or__1927000174__auto____24) { tmp20 = or__1927000174__auto____24 } else {
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_268.GetRawRoot__O()).Invoke_O__O(els__23)) { tmp20 = nil } else {
					tmp20 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_137.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(els__23)) } }
//line :1049:1
			var tmp21 any = tmp20; var tmp22 any = A_arbace_g2a_print_code_A_const_278; var tmp23 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_268.GetRawRoot__O()).Invoke_O__O(els__23); var tmp24 any = A_arbace_g2a_print_code_A_const_279; tmp15.Invoke_O_O__O(tmp16, tmp17.Invoke_O_O__O(tmp18, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, tmp22, tmp23, tmp24, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_268.GetRawRoot__O()).Invoke_O__O(els__23))))))





			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_272.GetRawRoot__O()).Invoke_O_O__O(els__23, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_274.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(ti__22)).Ref(), els__23)) } else {
				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_270.GetRawRoot__O()).Invoke_O__O(then__20), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_274.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long(ti__22).Ref(), then__20)) } }
//line :1040:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1022000397__3_))))) }





































func A_arbace_g2a_print_code_clause_list_A_New() *A_arbace_g2a_print_code_clause_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_clause_list_A{}; t.Ctor(); return t }
//line :1078:1
func (t *A_arbace_g2a_print_code_clause_list_A) Ctor() {}
//line :1078:1
func (t *A_arbace_g2a_print_code_clause_list_A) Invoke_O_O_O__O(self, clauses__0, print_head__1 any) any { var indent__3 any; var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_133; if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_134; indent__3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } else { var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_135; indent__3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) };
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_17);
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(indent__3); var clauses__4 any = /*line :1078:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(clauses__0); var n__1927000701__auto____5 int64 = lang.RT_LongCast_I__J(lang.RT_Count_O__I(clauses__4)); var i__6 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z(i__6, n__1927000701__auto____5) { var c__7 any = lang.RT_Nth_O_I__O(clauses__4, lang.RT_IntCast_J__I(i__6))

			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_281.GetRawRoot__O()).Invoke_O__O(c__7)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_34, c__7) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_code_A_const_62; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_137.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_175.GetRawRoot__O()).Invoke_O_O__O(clauses__4, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(i__6)).Ref())))); var tmp6 any = A_arbace_g2a_print_code_clause_list_fn__1022000439_A_New_J_O_O_O(i__6, indent__3, print_head__1, c__7); var tmp7 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_g2a_print_code_clause_list_fn__1022000439_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_g2a_print_code_clause_list_fn__1022000439_A_fn_class = fncls__62d; tmp7 = fncls__62d } else { tmp7 = fncls__62 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :1085:1
			i__6 = lang.Numbers_Unchecked_inc_J__J(i__6); continue L1 }
//line :1078:1
		break L1 };

















	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O(); var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_105.GetRawRoot__O()); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; var tmp10 any = tmp9.Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; tmp8.Invoke_O_O_O_O__O(nil, tmp10, tmp11.Ref(), indent__3); return /*line :1098:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_19) }
//line :1088:1
func A_arbace_g2a_print_code_clause_list_fn__1022000439_A_New_J_O_O_O(p0 int64, p1, p2, p3 any) *A_arbace_g2a_print_code_clause_list_fn__1022000439_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_clause_list_fn__1022000439_A{}; t.Ctor_J_O_O_O(p0, p1, p2, p3); return t }
//line :1088:1
func (t *A_arbace_g2a_print_code_clause_list_fn__1022000439_A) Ctor_J_O_O_O(c__i int64, c__indent, c__print_head, c__c any) { t.F_i = c__i; t.F_indent = c__indent; t.F_print_head = c__print_head; t.F_c = c__c }
//line :1088:1
func (t *A_arbace_g2a_print_code_clause_list_fn__1022000439_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(t.F_c), jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(t.F_i)).Ref(), Lit_36, t.F_indent)
												if lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t.F_c), Lit_37) {
													lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_37); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38)
													var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_280.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(t.F_c)); var tmp4 any = A_arbace_g2a_print_code_A_const_134; var tmp5 any; var t_ any = t.F_indent; t.F_indent = nil; tmp5 = t_; var tmp6 any = lang.Numbers_Inc_O__Number(tmp5); var tmp7 any = A_arbace_g2a_print_code_A_const_95; var tmp8 any; var t__2 any = t.F_c; t.F_c = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp8, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_106))) } else {
//line :1090:1
			var vec__1022000440__3 any = t.F_c; var seq__1022000441__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000440__3); var first__1022000442__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000441__4); var seq__1022000441__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000441__4); var ___7 any = first__1022000442__5; var first__1022000442__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000441__6); var seq__1022000441__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000441__6); var head__10 any = first__1022000442__8; var body__11 any = seq__1022000441__9; _ = ___7



			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_39); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp9 any; var t__3 any = t.F_print_head; t.F_print_head = nil; tmp9 = t__3; lang.IFn_Cast(tmp9).Invoke_O__O(head__10); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38)
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_280.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(body__11); var tmp12 any = A_arbace_g2a_print_code_A_const_134; var tmp13 any; var t__4 any = t.F_indent; t.F_indent = nil; tmp13 = t__4; var tmp14 any = lang.Numbers_Inc_O__Number(tmp13); var tmp15 any = A_arbace_g2a_print_code_A_const_95; var tmp16 any; var t__5 any = t.F_c; t.F_c = nil; tmp16 = t__5; tmp1 = tmp10.Invoke_O_O__O(tmp11, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, tmp15, tmp16, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_241))) }
//line :1088:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp17 != nil { panic(tmp17) }; return tmp1 }











func A_arbace_g2a_print_code_case_exprs_A_New() *A_arbace_g2a_print_code_case_exprs_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_case_exprs_A{}; t.Ctor(); return t }
//line :1100:1
func (t *A_arbace_g2a_print_code_case_exprs_A) Ctor() {}
//line :1100:1
func (t *A_arbace_g2a_print_code_case_exprs_A) Invoke_O_O__O(self, v__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(v__0)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_27, v__0) }
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(v__0))
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_248.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_A_const_157; var tmp3 any = A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_New(); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; return tmp1.Invoke_O_O_O_O__O(v__0, tmp2, v__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :1103:1
func A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_New() *A_arbace_g2a_print_code_case_exprs_fn__1022000446_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_case_exprs_fn__1022000446_A{}; t.Ctor(); return t }
//line :1103:1
func (t *A_arbace_g2a_print_code_case_exprs_fn__1022000446_A) Ctor() {}
//line :1103:1
func (t *A_arbace_g2a_print_code_case_exprs_fn__1022000446_A) Invoke_O_O__O(self, p1__1022000445_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(p1__1022000445_SHARP___1, A_arbace_g2a_print_code_A_const_106) }

func A_arbace_g2a_print_code_case_types_A_New() *A_arbace_g2a_print_code_case_types_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_case_types_A{}; t.Ctor(); return t }
//line :1105:1
func (t *A_arbace_g2a_print_code_case_types_A) Ctor() {}
//line :1105:1
func (t *A_arbace_g2a_print_code_case_types_A) Invoke_O_O__O(self, v__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(v__0)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_27, v__0) }
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(v__0))
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_248.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_A_const_157; var tmp3 any = A_arbace_g2a_print_code_case_types_fn__1022000450_A_New(); var tmp4 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_g2a_print_code_case_types_fn__1022000450_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_g2a_print_code_case_types_fn__1022000450_A_fn_class = fncls__64d; tmp4 = fncls__64d } else { tmp4 = fncls__64 }; return tmp1.Invoke_O_O_O_O__O(v__0, tmp2, v__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :1108:1
func A_arbace_g2a_print_code_case_types_fn__1022000450_A_New() *A_arbace_g2a_print_code_case_types_fn__1022000450_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_case_types_fn__1022000450_A{}; t.Ctor(); return t }
//line :1108:1
func (t *A_arbace_g2a_print_code_case_types_fn__1022000450_A) Ctor() {}
//line :1108:1
func (t *A_arbace_g2a_print_code_case_types_fn__1022000450_A) Invoke_O_O__O(self, p1__1022000449_SHARP___1 any) any { if lang.Util_Identical_O_O__Z(p1__1022000449_SHARP___1, nil) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_30) } else { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(p1__1022000449_SHARP___1) } }

func A_arbace_g2a_print_code_switch_stmt_A_New() *A_arbace_g2a_print_code_switch_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_switch_stmt_A{}; t.Ctor(); return t }
//line :1110:1
func (t *A_arbace_g2a_print_code_switch_stmt_A) Ctor() {}
//line :1110:1
func (t *A_arbace_g2a_print_code_switch_stmt_A) Invoke_O_O__O(self, f__0 any) any { var xs__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0); var vec__1022000453__3 any; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__2))) { vec__1022000453__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__2), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__2)) } else { vec__1022000453__3 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__2) }; var init__4 any = /*line :1110:1*/lang.RT_Nth_O_I_O__O(vec__1022000453__3, lang.RT_IntCast_J__I(0), nil); var xs__5 any = lang.RT_Nth_O_I_O__O(vec__1022000453__3, lang.RT_IntCast_J__I(1), nil); var vec__1022000456__6 any; var tmp1 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(xs__5); if


	jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_281.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__5))) } else { tmp1 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp1) { vec__1022000456__6 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__5), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__5)) } else { vec__1022000456__6 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__5) }; var tag__7 any = /*line :1110:1*/lang.RT_Nth_O_I_O__O(vec__1022000456__6, lang.RT_IntCast_J__I(0), nil); var xs__8 any = lang.RT_Nth_O_I_O__O(vec__1022000456__6, lang.RT_IntCast_J__I(1), nil);



	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_169); var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_code_A_const_185; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); var tmp6 any = A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_New_O_O(init__4, tag__7); var tmp7 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_186, false); A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_fn_class = fncls__65d; tmp7 = fncls__65d } else { tmp7 = fncls__65 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O(); return /*line :1120:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_282.GetRawRoot__O()).Invoke_O_O__O(xs__8, A_arbace_g2a_print_code_A_const_283.GetRawRoot__O()) }
//line :1115:1
func A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1115:1
func (t *A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A) Ctor_O_O(c__init, c__tag any) { t.F_init = c__init; t.F_tag = c__tag }
//line :1115:1
func (t *A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 any; var and__1927000168__auto____3 any = t.F_init
													if jrt.A2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(t.F_tag) } else { tmp2 = and__1927000168__auto____3 }
//line :1116:1
		if jrt.A2g_Truth(tmp2) {
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_init; t.F_init = nil; tmp4 = t_; tmp3.Invoke_O__O(tmp4); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_tag; t.F_tag = nil; tmp6 = t__2; tmp1 = tmp5.Invoke_O_O__O(tmp6, A_arbace_g2a_print_code_A_const_106) } else {
//line :1116:1
				if jrt.A2g_Truth(t.F_init) {

					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()); var tmp8 any; var t__3 any = t.F_init; t.F_init = nil; tmp8 = t__3; tmp7.Invoke_O__O(tmp8); tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36) } else {
//line :1116:1
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(t.F_tag)) {


							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp10 any; var t__4 any = t.F_tag; t.F_tag = nil; tmp10 = t__4; tmp1 = tmp9.Invoke_O_O__O(tmp10, A_arbace_g2a_print_code_A_const_106) } else {
//line :1116:1
								tmp1 = nil } } } }
//line :1115:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp11 != nil { panic(tmp11) }; return tmp1 }






func A_arbace_g2a_print_code_type_switch_stmt_A_New() *A_arbace_g2a_print_code_type_switch_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_switch_stmt_A{}; t.Ctor(); return t }
//line :1122:1
func (t *A_arbace_g2a_print_code_type_switch_stmt_A) Ctor() {}
//line :1122:1
func (t *A_arbace_g2a_print_code_type_switch_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000462__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0); var seq__1022000463__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000462__2); var first__1022000464__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000463__3); var seq__1022000463__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000463__3); var a__6 any = first__1022000464__4; var first__1022000464__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000463__5); var seq__1022000463__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000463__5); var b__9 any = first__1022000464__7; var more__10 any = seq__1022000463__8; var vec__1022000465__11 any; var tmp1 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(a__6); if


	jrt.A2g_Truth(and__1927000168__auto____11) { var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(b__9); if jrt.A2g_Truth(and__1927000168__auto____12) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_281.GetRawRoot__O()).Invoke_O__O(b__9)) } else { tmp1 = and__1927000168__auto____12 } } else { tmp1 = and__1927000168__auto____11 }; if /*line :1124:1*/ jrt.A2g_Truth(tmp1) { vec__1022000465__11 = lang.Tuple_Create_O_O_O__IPersistentVector(a__6, b__9, more__10) } else { if A_arbace_g2a_print_code_A_const_30 != nil { vec__1022000465__11 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, a__6, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_149.GetRawRoot__O()).Invoke_O_O__O(b__9, more__10)) } else { vec__1022000465__11 = nil } }; var init__12 any = /*line :1122:1*/lang.RT_Nth_O_I_O__O(vec__1022000465__11, lang.RT_IntCast_J__I(0), nil); var guard__13 any = lang.RT_Nth_O_I_O__O(vec__1022000465__11, lang.RT_IntCast_J__I(1), nil); var clauses__14 any = lang.RT_Nth_O_I_O__O(vec__1022000465__11, lang.RT_IntCast_J__I(2), nil); var clauses__15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_284.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_285.GetRawRoot__O(), clauses__14);





	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_169); var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_code_A_const_185; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); var tmp6 any = A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_New_O_O(init__12, guard__13); var tmp7 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_202, false); A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_fn_class = fncls__66d; tmp7 = fncls__66d } else { tmp7 = fncls__66 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O(); return /*line :1137:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_282.GetRawRoot__O()).Invoke_O_O__O(clauses__15, A_arbace_g2a_print_code_A_const_286.GetRawRoot__O()) }
//line :1129:1
func A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1129:1
func (t *A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A) Ctor_O_O(c__init, c__guard any) { t.F_init = c__init; t.F_guard = c__guard }
//line :1129:1
func (t *A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												if jrt.A2g_Truth(t.F_init) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_init; t.F_init = nil; tmp3 = t_; tmp2.Invoke_O__O(tmp3); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36) }
												lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
												if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(t.F_guard)) { var vec__1022000469__3 any; var t__2 any = t.F_guard; t.F_guard = nil; vec__1022000469__3 = t__2; var x__4 any = lang.RT_Nth_O_I_O__O(vec__1022000469__3, lang.RT_IntCast_J__I(0), nil); var g__5 any = lang.RT_Nth_O_I_O__O(vec__1022000469__3, lang.RT_IntCast_J__I(1), nil)

		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(x__4)); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_15); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O_O__O(g__5, A_arbace_g2a_print_code_A_const_43, A_arbace_g2a_print_code_A_const_106); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_80); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_188); tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_205.GetRawRoot__O()); var tmp5 any; var t__3 any = t.F_guard; t.F_guard = nil; tmp5 = t__3; tmp4.Invoke_O_O_O__O(tmp5, A_arbace_g2a_print_code_A_const_43, A_arbace_g2a_print_code_A_const_106); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_80); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_188); tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :1129:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }









func A_arbace_g2a_print_code_comm_A_New() *A_arbace_g2a_print_code_comm_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_comm_A{}; t.Ctor(); return t }
//line :1139:1
func (t *A_arbace_g2a_print_code_comm_A) Ctor() {}
//line :1139:1
func (t *A_arbace_g2a_print_code_comm_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(c__0)) { var vec__1022000474__2 any = c__0; var t__3 any = lang.RT_Nth_O_I_O__O(vec__1022000474__2, lang.RT_IntCast_J__I(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O(vec__1022000474__2, lang.RT_IntCast_J__I(1), nil)
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_261.GetRawRoot__O()).Invoke_O_O__O(t__3, x__4) } else {
//line :1140:1
			if A_arbace_g2a_print_code_A_const_30 != nil {

				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(c__0) } else {
//line :1140:1
					return nil
				}
		}
}
func A_arbace_g2a_print_code_select_stmt_A_New() *A_arbace_g2a_print_code_select_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_select_stmt_A{}; t.Ctor(); return t }
//line :1144:1
func (t *A_arbace_g2a_print_code_select_stmt_A) Ctor() {}
//line :1144:1
func (t *A_arbace_g2a_print_code_select_stmt_A) Invoke_O_O__O(self, f__0 any) any {
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_165)
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_17); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_19) } else {
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_282.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_g2a_print_code_A_const_287.GetRawRoot__O())
		} }
func A_arbace_g2a_print_code_for_stmt_A_New() *A_arbace_g2a_print_code_for_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_for_stmt_A{}; t.Ctor(); return t }
//line :1150:1
func (t *A_arbace_g2a_print_code_for_stmt_A) Ctor() {}
//line :1150:1
func (t *A_arbace_g2a_print_code_for_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000479__2 any = f__0; var seq__1022000480__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000479__2); var first__1022000481__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000480__3); var seq__1022000480__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000480__3); var ___6 any = first__1022000481__4; var first__1022000481__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000480__5); var seq__1022000480__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000480__5); var init__9 any = first__1022000481__7; var first__1022000481__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000480__8); var seq__1022000480__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000480__8); var c__12 any = first__1022000481__10; var first__1022000481__13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000480__11); var seq__1022000480__14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000480__11); var post__15 any = first__1022000481__13; var body__16 any = seq__1022000480__14; _ = ___6; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(init__9)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_124, f__0) };
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_125); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_275.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; tmp1.Invoke_O_O_O_O__O(tmp2.Ref(), init__9, c__12, post__15); return /*line :1155:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(body__16), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_193))) }

func A_arbace_g2a_print_code_while_stmt_A_New() *A_arbace_g2a_print_code_while_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_while_stmt_A{}; t.Ctor(); return t }
//line :1157:1
func (t *A_arbace_g2a_print_code_while_stmt_A) Ctor() {}
//line :1157:1
func (t *A_arbace_g2a_print_code_while_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000483__2 any = f__0; var seq__1022000484__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000483__2); var first__1022000485__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000484__3); var seq__1022000484__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000484__3); var ___6 any = first__1022000485__4; var first__1022000485__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000484__5); var seq__1022000484__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000484__5); var c__9 any = first__1022000485__7; var body__10 any = seq__1022000484__8; _ = ___6;

	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_125); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_84.GetRawRoot__O()).Invoke_O__O(c__9)) { } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_185; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any = A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_New_O(c__9); var tmp6 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_208, false); A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_fn_class = fncls__67d; tmp6 = fncls__67d } else { tmp6 = fncls__67 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O() }; return /*line :1161:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(body__10), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_241))) }
//line :1160:1
func A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_New_O(p0 any) *A_arbace_g2a_print_code_while_stmt_fn__1022000486_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_while_stmt_fn__1022000486_A{}; t.Ctor_O(p0); return t }
//line :1160:1
func (t *A_arbace_g2a_print_code_while_stmt_fn__1022000486_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :1160:1
func (t *A_arbace_g2a_print_code_while_stmt_fn__1022000486_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_c; t.F_c = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_g2a_print_code_A_const_106) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_g2a_print_code_range_stmt_A_New() *A_arbace_g2a_print_code_range_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_range_stmt_A{}; t.Ctor(); return t }
//line :1163:1
func (t *A_arbace_g2a_print_code_range_stmt_A) Ctor() {}
//line :1163:1
func (t *A_arbace_g2a_print_code_range_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000490__2 any = f__0; var seq__1022000491__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000490__2); var first__1022000492__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000491__3); var seq__1022000491__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000491__3); var ___6 any = first__1022000492__4; var first__1022000492__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000491__5); var seq__1022000491__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000491__5); var v__9 any = first__1022000492__7; var body__10 any = seq__1022000491__8; var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_288; var assign_QMARK___11 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); _ = ___6; if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(v__9)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_173, f__0) };
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_125); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_code_A_const_185; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); var tmp6 any = A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_New_O_O(assign_QMARK___11, v__9); var tmp7 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_174, false); A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_fn_class = fncls__69d; tmp7 = fncls__69d } else { tmp7 = fncls__69 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O(); return /*line :1174:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(body__10), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_241))) }
//line :1168:1
func A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_code_range_stmt_fn__1022000493_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_range_stmt_fn__1022000493_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1168:1
func (t *A_arbace_g2a_print_code_range_stmt_fn__1022000493_A) Ctor_O_O(c__assign_QMARK_, c__v any) { t.F_assign_QMARK_ = c__assign_QMARK_; t.F_v = c__v }
//line :1168:1
func (t *A_arbace_g2a_print_code_range_stmt_fn__1022000493_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var x__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(t.F_v); var vars__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_121.GetRawRoot__O()).Invoke_O__O(t.F_v)

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vars__4)) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_248.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_v; t.F_v = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any = A_arbace_g2a_print_code_A_const_157; var tmp6 any = A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_New(); var tmp7 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_175, false); A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_fn_class = fncls__68d; tmp7 = fncls__68d } else { tmp7 = fncls__68 }; tmp2.Invoke_O_O_O_O__O(tmp4, tmp5, vars__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil))
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()); var tmp9 *jrt.String; var tmp10 any; var t__2 any = t.F_assign_QMARK_; t.F_assign_QMARK_ = nil; tmp10 = t__2; if jrt.A2g_Truth(tmp10) { tmp9 = Lit_1 } else { tmp9 = Lit_15 }; tmp8.Invoke_O__O(tmp9.Ref()); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_156); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(x__3, A_arbace_g2a_print_code_A_const_106) }; return nil }(); /*line :1168:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp11 != nil { panic(tmp11) }; return tmp1 }


func A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_New() *A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A{}; t.Ctor(); return t }
//line :1171:1
func (t *A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A) Ctor() {}
//line :1171:1
func (t *A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A) Invoke_O_O__O(self, p1__1022000489_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(p1__1022000489_SHARP___1, A_arbace_g2a_print_code_A_const_106) }






func A_arbace_g2a_print_code_print_stmt_A_New() *A_arbace_g2a_print_code_print_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_print_stmt_A{}; t.Ctor(); return t }
//line :1178:1
func (t *A_arbace_g2a_print_code_print_stmt_A) Ctor() {}
//line :1178:1
func (t *A_arbace_g2a_print_code_print_stmt_A) Invoke_O_O__O(self, f__0 any) any { var o__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0); var G__1022000499__3_ any = o__2; switch



	lang.Util_Hash_O__I(G__1022000499__3_) >> 3 & 255 { case 31: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_155) {







		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_155)
//line :1182:1
		var temp__1927000414__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)







		if jrt.A2g_Truth(temp__1927000414__auto____4) { var l__5 any = temp__1927000414__auto____4; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_290.GetRawRoot__O()).Invoke_O__O(l__5)) } else { return nil } }
//line :1182:1
	case 39: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_156) {


















		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_289.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 44: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_157) {









		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_157); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_290.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0))) }
//line :1182:1
	case 67: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_123) {



















		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O__IPersistentVector(f__0); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O__O(tmp2, tmp3.Ref()) }
//line :1182:1
	case 93: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_158) {










		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_158) }
//line :1182:1
	case 102: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_159) {

















		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_291.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 103: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_136) {












		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_292.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 110: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_160) {


		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_160); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_g2a_print_code_A_const_106) }
//line :1182:1
	case 128: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_161) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 139: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_162) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 140: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_163) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 145: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_20) {











		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_code_A_const_95, f__0, A_arbace_g2a_print_code_A_const_96, A_arbace_g2a_print_code_A_const_106))) }
//line :1182:1
	case 148: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_164) {








		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_164)
//line :1182:1
		var temp__1927000414__auto____4_2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)








		if jrt.A2g_Truth(temp__1927000414__auto____4_2) { var l__5_2 any = temp__1927000414__auto____4_2; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_290.GetRawRoot__O()).Invoke_O__O(l__5_2)) } else { return nil } }
//line :1182:1
	case 153: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_125) {
















		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_293.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 157: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_62) {

		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_62); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_g2a_print_code_A_const_106) }
//line :1182:1
	case 159: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_165) {















		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_294.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 163: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_135) {












		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_292.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 164: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_166) {














		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_295.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 166: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_167) {



		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_167)
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0))) {
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_248.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_code_A_const_106; var tmp6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0); var tmp7 any = A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_New(); var tmp8 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_168, false); A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_fn_class = fncls__71d; tmp8 = fncls__71d } else { tmp8 = fncls__71 }; return tmp4.Invoke_O_O_O_O__O(f__0, tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {
//line :1187:1
				return nil } }
//line :1182:1
	case 222: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_141) {




















		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_296.GetRawRoot__O()); var tmp10 *lang.Keyword = A_arbace_g2a_print_code_A_const_135; var tmp11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_FALSE; return tmp9.Invoke_O_O_O__O(f__0, tmp11, tmp12.Ref()) }
//line :1182:1
	case 228: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_133) {












		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_292.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 230: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_169) {













		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_297.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 244: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_170) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	case 245: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_171) {



















		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()); var tmp14 any = lang.Tuple_Create_O__IPersistentVector(f__0); var tmp15 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp15 = lang.PersistentArrayMap_EMPTY; return tmp13.Invoke_O_O__O(tmp14, tmp15.Ref()) }
//line :1182:1
	case 255: if lang.Util_Equiv_O_O__Z(G__1022000499__3_, Lit_172) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1182:1
	default:}; return /*line :1204:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_260.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1189:1
func A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_New() *A_arbace_g2a_print_code_print_stmt_fn__1022000500_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_print_stmt_fn__1022000500_A{}; t.Ctor(); return t }
//line :1189:1
func (t *A_arbace_g2a_print_code_print_stmt_fn__1022000500_A) Ctor() {}
//line :1189:1
func (t *A_arbace_g2a_print_code_print_stmt_fn__1022000500_A) Invoke_O_O__O(self, p1__1022000498_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(p1__1022000498_SHARP___1, A_arbace_g2a_print_code_A_const_106) }


















func A_arbace_g2a_print_code_flatten_stmts_A_New() *A_arbace_g2a_print_code_flatten_stmts_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_flatten_stmts_A{}; t.Ctor(); return t }
//line :1208:1
func (t *A_arbace_g2a_print_code_flatten_stmts_A) Ctor() {}
//line :1208:1
func (t *A_arbace_g2a_print_code_flatten_stmts_A) Invoke_O_O_O_O__O(self, forms__0, parent__1, offset__2 any) any { var forms__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(forms__0); var n__5 int32 = lang.RT_Count_O__I(forms__4); var brk__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_58.GetRawRoot__O()).Invoke_O__O(parent__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_218.GetRawRoot__O()); var tmp2 *lang.PersistentVector;








	lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_298.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_New_O_I_O_O(parent__1, n__5, offset__2, brk__6); var tmp6 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_fn_class; if

	fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_fn_class = fncls__73d; tmp6 = fncls__73d } else { tmp6 = fncls__73 }; return /*line :1217:1*/ tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_64.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(n__5).Ref()), forms__4)) }

func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1219:1
func (t *A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A) Ctor_O_I_O_O(c__parent any, c__n int32, c__offset, c__brk any) { t.F_parent = c__parent; t.F_n = c__n; t.F_offset = c__offset; t.F_brk = c__brk }
//line :1219:1
func (t *A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A) Invoke_O_O_O__O(self, i__1, f__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2)
	if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_299); var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__2)); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_J__Z(i__1, lang.Numbers_Dec_J__J(int64(t.F_n)))).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :1220:1
	if jrt.A2g_Truth(tmp1) { var vec__1022000504__3 any = f__2; var seq__1022000505__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000504__3); var first__1022000506__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000505__4); var seq__1022000505__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000505__4); var ___7 any = first__1022000506__5; var first__1022000506__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000505__6); var seq__1022000505__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000505__6); var bv__10 any = first__1022000506__8; var body__11 any = seq__1022000505__9; var ___12 any; _ = ___7; _ = ___12


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(bv__10)) { ___12 = nil } else { ___12 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_120, f__2) }
//line :1220:1
		var pairs__13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_271.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_241, bv__10); var items__14 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_New_O(f__2); var tmp5 *jrt.Class
		var fncls__72 /*line :1220:1*/*jrt.Class = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_fn_class





		if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_fn_class = fncls__72d; tmp5 = fncls__72d } else { tmp5 = fncls__72 }
//line :1225:1
		items__14 = tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), pairs__13)








		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_273.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(bv__10)).Ref())) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_122, f__2) }
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_151.GetRawRoot__O()).Invoke_O_O__O(items__14, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(body__11, f__2, A_arbace_g2a_print_code_A_const_241)) } else {
//line :1220:1
			if A_arbace_g2a_print_code_A_const_30 != nil { var tmp6 any = A_arbace_g2a_print_code_A_const_22; var tmp7 any = A_arbace_g2a_print_code_A_const_301; var tmp8 any















				if jrt.A2g_Truth(t.F_parent) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_59.GetRawRoot__O()); var tmp10 any = t.F_parent; tmp8 = tmp9.Invoke_O_O_O_O__O(tmp10, lang.Numbers_Add_O_O__Number(t.F_offset, i__1), f__2, t.F_brk) } else { tmp8 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(f__2) }
//line :1220:1
				return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, f__2, tmp7, tmp8))) } else { return nil
				}
		}
}


func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_New_O(p0 any) *A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A{}; t.Ctor_O(p0); return t }
//line :1226:1
func (t *A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1226:1
func (t *A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A) Invoke_O_O_O__O(self, j__1, p__1022000507__2 any) any { var vec__1022000509__3 any = p__1022000507__2; var t__4 any = lang.RT_Nth_O_I_O__O(vec__1022000509__3, lang.RT_IntCast_J__I(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O(vec__1022000509__3, lang.RT_IntCast_J__I(1), nil); var tl__6 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(t__4); if
																	jrt.A2g_Truth(or__1927000174__auto____6) { tl__6 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any
																		if lang.Numbers_IsZero_O__Z(j__1) { or__1927000174__auto____7 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(t.F_f) } else { or__1927000174__auto____7 = nil }
//line :1227:1
		if jrt.A2g_Truth(or__1927000174__auto____7) { tl__6 = or__1927000174__auto____7 } else {

			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(x__5)) { tl__6 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(x__5) } else { tl__6 = nil } } }; if
	lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t.F_f), Lit_123) { var tmp1 any = A_arbace_g2a_print_code_A_const_300; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Tuple_Create_O_O__IPersistentVector(t__4, x__5), A_arbace_g2a_print_code_A_const_301, tl__6)) } else { var tmp2 any = A_arbace_g2a_print_code_A_const_302; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Tuple_Create_O_O__IPersistentVector(t__4, x__5), A_arbace_g2a_print_code_A_const_301, tl__6)) } }








func A_arbace_g2a_print_code_item_t_A_New() *A_arbace_g2a_print_code_item_t_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_item_t_A{}; t.Ctor(); return t }
//line :1239:1
func (t *A_arbace_g2a_print_code_item_t_A) Ctor() {}
//line :1239:1
func (t *A_arbace_g2a_print_code_item_t_A) Invoke_O_O__O(self, it__0 any) any { return A_arbace_g2a_print_code_A_const_301.Invoke_O__O(it__0) }

func A_arbace_g2a_print_code_label_stmt_A_New() *A_arbace_g2a_print_code_label_stmt_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_label_stmt_A{}; t.Ctor(); return t }
//line :1241:1
func (t *A_arbace_g2a_print_code_label_stmt_A) Ctor() {}
//line :1241:1
func (t *A_arbace_g2a_print_code_label_stmt_A) Invoke_O_O_O_O__O(self, f__0, indent__1, more_QMARK___2 any) any { var vec__1022000516__4 any = f__0; var ___5 any = lang.RT_Nth_O_I_O__O(vec__1022000516__4, lang.RT_IntCast_J__I(0), nil); var l__6 any = lang.RT_Nth_O_I_O__O(vec__1022000516__4, lang.RT_IntCast_J__I(1), nil); var s__7 any = lang.RT_Nth_O_I_O__O(vec__1022000516__4, lang.RT_IntCast_J__I(2), nil); _ = ___5;




	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_290.GetRawRoot__O()).Invoke_O__O(l__6)); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_264.GetRawRoot__O()).Invoke_O__O(s__7)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(s__7); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; var tmp4 any = tmp3.Ref(); var tmp5 any; var tmp6 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(s__7)
		if jrt.A2g_Truth(and__1927000168__auto____8) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(s__7), Lit_141)).Ref() } else { tmp6 = and__1927000168__auto____8 }; if jrt.A2g_Truth(tmp6) { tmp5 = lang.Numbers_Max_J_O__O(0, lang.Numbers_Dec_O__Number(indent__1)) } else { tmp5 = indent__1 }
//line :1248:1
		tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, nil, tmp5)

		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(indent__1)
		var tmp7 any; var and__1927000168__auto____8_2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(s__7)
		if jrt.A2g_Truth(and__1927000168__auto____8_2) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_304); tmp7 = tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(s__7)) } else { tmp7 = and__1927000168__auto____8_2 }
//line :1251:1
		if jrt.A2g_Truth(tmp7) {
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()); var tmp10 any = lang.Tuple_Create_O__IPersistentVector(s__7); var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; tmp9.Invoke_O_O__O(tmp10, tmp11.Ref()) } else {
//line :1251:1
				var tmp12 any; var and__1927000168__auto____8_3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(s__7)

				if jrt.A2g_Truth(and__1927000168__auto____8_3) { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(s__7), Lit_141)).Ref() } else { tmp12 = and__1927000168__auto____8_3 }
//line :1251:1
				if jrt.A2g_Truth(tmp12) {

					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_296.GetRawRoot__O()).Invoke_O_O_O__O(s__7, indent__1, more_QMARK___2) } else {
//line :1251:1
						if A_arbace_g2a_print_code_A_const_30 != nil {


							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_269.GetRawRoot__O()).Invoke_O__O(s__7) } } }
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O() } else {
//line :1247:1
			if jrt.A2g_Truth(more_QMARK___2) {








				var tmp13 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp13.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36) } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_171.GetRawRoot__O()).Invoke_O__O(indent__1); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36) } } else {
//line :1247:1
					return nil } } }










func A_arbace_g2a_print_code_bind_target_A_New() *A_arbace_g2a_print_code_bind_target_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_bind_target_A{}; t.Ctor(); return t }
//line :1258:1
func (t *A_arbace_g2a_print_code_bind_target_A) Ctor() {}
//line :1258:1
func (t *A_arbace_g2a_print_code_bind_target_A) Invoke_O_O__O(self, it__0 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_300.Invoke_O__O(it__0)) }

func A_arbace_g2a_print_code_const_bind_QMARK__A_New() *A_arbace_g2a_print_code_const_bind_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_bind_QMARK__A{}; t.Ctor(); return t }
//line :1260:1
func (t *A_arbace_g2a_print_code_const_bind_QMARK__A) Ctor() {}
//line :1260:1
func (t *A_arbace_g2a_print_code_const_bind_QMARK__A) Invoke_O_O__O(self, it__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_305.GetRawRoot__O()).Invoke_O__O(it__0); if
												jrt.A2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var ts__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_249.GetRawRoot__O()).Invoke_O__O(t__3); var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_250; var or__1927000174__auto____5 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(t__3))

		if jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_New(); var tmp4 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_fn_class = fncls__74d; tmp4 = fncls__74d } else { tmp4 = fncls__74 }; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ts__4) } } else {
//line :1261:1
			return nil } }

func A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_New() *A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A{}; t.Ctor(); return t }
//line :1263:1
func (t *A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A) Ctor() {}
//line :1263:1
func (t *A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A) Invoke_O_O__O(self, p1__1022000521_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_250; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1022000521_SHARP___1)) }

func A_arbace_g2a_print_code_group_consts_A_New() *A_arbace_g2a_print_code_group_consts_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_consts_A{}; t.Ctor(); return t }
//line :1265:1
func (t *A_arbace_g2a_print_code_group_consts_A) Ctor() {}
//line :1265:1
func (t *A_arbace_g2a_print_code_group_consts_A) Invoke_O_O__O(self, items__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_118.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_group_consts_fn__1022000525_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_g2a_print_code_group_consts_fn__1022000525_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_g2a_print_code_group_consts_fn__1022000525_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O_O_O__O(tmp4, tmp5.Ref(), items__0) }
//line :1269:1
func A_arbace_g2a_print_code_group_consts_fn__1022000525_A_New() *A_arbace_g2a_print_code_group_consts_fn__1022000525_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_consts_fn__1022000525_A{}; t.Ctor(); return t }
//line :1269:1
func (t *A_arbace_g2a_print_code_group_consts_fn__1022000525_A) Ctor() {}
//line :1269:1
func (t *A_arbace_g2a_print_code_group_consts_fn__1022000525_A) Invoke_O_O_O__O(self, acc__1, it__2 any) any { var prev__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_103.GetRawRoot__O()).Invoke_O__O(acc__1); var tmp1 any; var and__1927000168__auto____4 any = prev__3; if

	jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_306.GetRawRoot__O()).Invoke_O__O(it__2); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_14; var and__1927000168__auto____6 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_305.GetRawRoot__O()).Invoke_O__O(it__2))); if jrt.A2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 any = A_arbace_g2a_print_code_A_const_307.Invoke_O__O(prev__3)
		if jrt.A2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_306.GetRawRoot__O()).Invoke_O__O(prev__3) } } else {
//line :1271:1
			tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) {

				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_121.GetRawRoot__O()).Invoke_O__O(acc__1); var tmp5 any; if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_307.Invoke_O__O(prev__3)) {
					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_122.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_A_const_307; tmp5 = tmp6.Invoke_O_O_O_O__O(prev__3, tmp7, A_arbace_g2a_print_code_A_const_8.GetRawRoot__O(), it__2) } else {
//line :1273:1
						var tmp8 any = A_arbace_g2a_print_code_A_const_307; var tmp9 any = lang.Tuple_Create_O_O__IPersistentVector(prev__3, it__2); var tmp10 any = A_arbace_g2a_print_code_A_const_301; tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, A_arbace_g2a_print_code_A_const_301.Invoke_O__O(prev__3))) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {


							return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__1, it__2) } }


func A_arbace_g2a_print_code_label_of_A_New() *A_arbace_g2a_print_code_label_of_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_label_of_A{}; t.Ctor(); return t }
//line :1279:1
func (t *A_arbace_g2a_print_code_label_of_A) Ctor() {}
//line :1279:1
func (t *A_arbace_g2a_print_code_label_of_A) Invoke_O_O__O(self, it__0 any) any { var temp__1927000414__auto____2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_305.GetRawRoot__O()).Invoke_O__O(it__0); if


	jrt.A2g_Truth(or__1927000174__auto____2) { temp__1927000414__auto____2 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_302.Invoke_O__O(it__0)); if jrt.A2g_Truth(or__1927000174__auto____3) { temp__1927000414__auto____2 = or__1927000174__auto____3 } else {
		temp__1927000414__auto____2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_305.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_307.Invoke_O__O(it__0))) } }; if /*line :1282:1*/ jrt.A2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2
			var tmp1 /*line :1282:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_308

			return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(t__3)) } else {
//line :1282:1
				return nil } }



func A_arbace_g2a_print_code_const_spec_A_New() *A_arbace_g2a_print_code_const_spec_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_spec_A{}; t.Ctor(); return t }
//line :1286:1
func (t *A_arbace_g2a_print_code_const_spec_A) Ctor() {}
//line :1286:1
func (t *A_arbace_g2a_print_code_const_spec_A) Invoke_O_O_O__O(self, p__1022000530__0, keep_type__1 any) any { var vec__1022000531__3 any = p__1022000530__0; var target__4 any = lang.RT_Nth_O_I_O__O(vec__1022000531__3, lang.RT_IntCast_J__I(0), nil); var init__5 any = lang.RT_Nth_O_I_O__O(vec__1022000531__3, lang.RT_IntCast_J__I(1), nil); var ts__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_249.GetRawRoot__O()).Invoke_O__O(target__4); var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_309; var implicit_QMARK___7 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(target__4)); var typ__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_const_spec_fn__1022000534_A_New(); var tmp4 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_g2a_print_code_const_spec_fn__1022000534_A_fn_class; if




	fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_g2a_print_code_const_spec_fn__1022000534_A_fn_class = fncls__76d; tmp4 = fncls__76d } else { tmp4 = fncls__76 }; typ__8 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ts__6);
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_128.GetRawRoot__O()).Invoke_O__O(ts__6); if
	jrt.A2g_Truth(implicit_QMARK___7) { return nil } else {
		var tmp5 any; var or__1927000174__auto____9 any = typ__8; if jrt.A2g_Truth(or__1927000174__auto____9) { tmp5 = or__1927000174__auto____9 } else { tmp5 = keep_type__1 }; if jrt.A2g_Truth(tmp5) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_166.GetRawRoot__O()).Invoke__O() }
		if jrt.A2g_Truth(typ__8) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(typ__8) }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_166.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_252.GetRawRoot__O()).Invoke_O_O__O(init__5, A_arbace_g2a_print_code_A_const_106) } }
//line :1291:1
func A_arbace_g2a_print_code_const_spec_fn__1022000534_A_New() *A_arbace_g2a_print_code_const_spec_fn__1022000534_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_spec_fn__1022000534_A{}; t.Ctor(); return t }
//line :1291:1
func (t *A_arbace_g2a_print_code_const_spec_fn__1022000534_A) Ctor() {}
//line :1291:1
func (t *A_arbace_g2a_print_code_const_spec_fn__1022000534_A) Invoke_O_O__O(self, p1__1022000529_SHARP___1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(p1__1022000529_SHARP___1), A_arbace_g2a_print_code_A_const_107)) { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1022000529_SHARP___1)) } else { return nil } }








func A_arbace_g2a_print_code_const_group_A_New() *A_arbace_g2a_print_code_const_group_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_group_A{}; t.Ctor(); return t }
//line :1300:1
func (t *A_arbace_g2a_print_code_const_group_A) Ctor() {}
//line :1300:1
func (t *A_arbace_g2a_print_code_const_group_A) Invoke_O_O_O__O(self, its__0, indent__1 any) any { var specs__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_300, its__0); var keep__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_310.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_const_group_fn__1022000538_A_New(); var tmp4 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_g2a_print_code_const_group_fn__1022000538_A_fn_class; if



	fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_g2a_print_code_const_group_fn__1022000538_A_fn_class = fncls__77d; tmp4 = fncls__77d } else { tmp4 = fncls__77 }; keep__4 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), specs__3)); var nxts__5 any = /*line :1300:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_99.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_301, its__0));





	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_12); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6);
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(indent__1); var n__1927000701__auto____6 int64 = /*line :1300:1*/lang.RT_LongCast_I__J(lang.RT_Count_O__I(its__0)); var j__7 int64 = 0; L1: for {







		if lang.Numbers_Lt_J_J__Z(j__7, n__1927000701__auto____6) {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_A_const_62; var tmp8 any; var or__1927000174__auto____8 any = lang.RT_Nth_O_I__O(nxts__5, lang.RT_IntCast_J__I(j__7)); if jrt.A2g_Truth(or__1927000174__auto____8) { tmp8 = or__1927000174__auto____8 } else { tmp8 = A_arbace_g2a_print_code_A_const_62.Get__O() }; tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8)); var tmp9 any = A_arbace_g2a_print_code_const_group_fn__1022000543_A_New_O_J_O_O_O(keep__4, j__7, its__0, indent__1, specs__3); var tmp10 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_g2a_print_code_const_group_fn__1022000543_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_g2a_print_code_const_group_fn__1022000543_A_fn_class = fncls__78d; tmp10 = fncls__78d } else { tmp10 = fncls__78 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :1308:1
			j__7 = lang.Numbers_Unchecked_inc_J__J(j__7); continue L1 }
//line :1300:1
		break L1 };











	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O(); var tmp11 /*line :1313:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp11.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) {
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_105.GetRawRoot__O()); var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; var tmp14 any = tmp13.Ref(); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; tmp12.Invoke_O_O_O_O__O(nil, tmp14, tmp15.Ref(), indent__1) } else {
			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_171.GetRawRoot__O()); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; tmp16.Invoke_O_O__O(indent__1, tmp17.Ref()) }; return /*line :1316:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :1304:1
func A_arbace_g2a_print_code_const_group_fn__1022000538_A_New() *A_arbace_g2a_print_code_const_group_fn__1022000538_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_group_fn__1022000538_A{}; t.Ctor(); return t }
//line :1304:1
func (t *A_arbace_g2a_print_code_const_group_fn__1022000538_A) Ctor() {}
//line :1304:1
func (t *A_arbace_g2a_print_code_const_group_fn__1022000538_A) Invoke_O_O__O(self, p__1022000537__1 any) any { var vec__1022000539__2 any = p__1022000537__1; var t__3 any = lang.RT_Nth_O_I_O__O(vec__1022000539__2, lang.RT_IntCast_J__I(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O(vec__1022000539__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any; var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_309; if jrt.A2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(t__3))) { tmp1 = A_arbace_g2a_print_code_A_const_311 } else { tmp1 = x__4 }; return lang.Tuple_Create_O_O__IPersistentVector(t__3, tmp1) }




func A_arbace_g2a_print_code_const_group_fn__1022000543_A_New_O_J_O_O_O(p0 any, p1 int64, p2, p3, p4 any) *A_arbace_g2a_print_code_const_group_fn__1022000543_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_group_fn__1022000543_A{}; t.Ctor_O_J_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1309:1
func (t *A_arbace_g2a_print_code_const_group_fn__1022000543_A) Ctor_O_J_O_O_O(c__keep any, c__j int64, c__its, c__indent, c__specs any) { t.F_keep = c__keep; t.F_j = c__j; t.F_its = c__its; t.F_indent = c__indent; t.F_specs = c__specs }
//line :1309:1
func (t *A_arbace_g2a_print_code_const_group_fn__1022000543_A) Invoke_O__O(self any) any { var tmp1 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____3 any; var tmp4 *lang.Keyword = A_arbace_g2a_print_code_A_const_301; var tmp5 any; var t_ any = t.F_its; t.F_its = nil; tmp5 = t_; or__1927000174__auto____3 = tmp4.Invoke_O__O(lang.RT_Nth_O_I__O(tmp5, lang.RT_IntCast_J__I(t.F_j))); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp6 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp6.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) { tmp3 = nil } else { tmp3 = A_arbace_g2a_print_code_A_const_57 } }; var tmp7 any = tmp3; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(t.F_j)).Ref(); var tmp9 any; var t__2 any = t.F_indent; t.F_indent = nil; tmp9 = t__2; tmp2.Invoke_O_O_O_O__O(tmp7, tmp8, Lit_36, lang.Numbers_Inc_O__Number(tmp9))
													var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_312.GetRawRoot__O()); var tmp11 any; var t__3 any = t.F_specs; t.F_specs = nil; tmp11 = t__3; var tmp12 any = lang.RT_Nth_O_I__O(tmp11, lang.RT_IntCast_J__I(t.F_j)); var tmp13 any; var t__4 any = t.F_keep; t.F_keep = nil; tmp13 = t__4; tmp1 = tmp10.Invoke_O_O__O(tmp12, lang.RT_Nth_O_I__O(tmp13, lang.RT_IntCast_J__I(t.F_j))) }
//line :1309:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp14 != nil { panic(tmp14) }; return tmp1 }








func A_arbace_g2a_print_code_group_target_A_New() *A_arbace_g2a_print_code_group_target_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_target_A{}; t.Ctor(); return t }
//line :1318:1
func (t *A_arbace_g2a_print_code_group_target_A) Ctor() {}
//line :1318:1
func (t *A_arbace_g2a_print_code_group_target_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.Numbers_Dec_J__J(lang.RT_LongCast_O__J(t__0)), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(lang.RT_LongCast_O__J(t__0))).Ref() } else { return t__0
	} }
func A_arbace_g2a_print_code_stmt_list_A_New() *A_arbace_g2a_print_code_stmt_list_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_stmt_list_A{}; t.Ctor(); return t }
//line :1323:1
func (t *A_arbace_g2a_print_code_stmt_list_A) Ctor() {}
//line :1323:1
func (t *A_arbace_g2a_print_code_stmt_list_A) Invoke_O_O_O__O(self, forms__0, p__1022000547__1 any) any { { var map__1022000548__3 any = p__1022000547__1; var map__1022000548__4 any; if lang.ISeq_InstanceOf(map__1022000548__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(map__1022000548__3)) { map__1022000548__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(map__1022000548__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(map__1022000548__3)) { map__1022000548__4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(map__1022000548__3) } else { lang.PersistentArrayMap_Init(); map__1022000548__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1022000548__4 = map__1022000548__3 }; var opts__5 any = map__1022000548__4; var indent__6 any = lang.RT_Get_O_O__O(map__1022000548__4, A_arbace_g2a_print_code_A_const_134); var results_QMARK___7 any = lang.RT_Get_O_O__O(map__1022000548__4, A_arbace_g2a_print_code_A_const_227); var parent__8 any = lang.RT_Get_O_O__O(map__1022000548__4, A_arbace_g2a_print_code_A_const_95); var offset__9 any = lang.RT_Get_O_O__O(map__1022000548__4, A_arbace_g2a_print_code_A_const_96); var items__10 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_313.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_303.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____10 any = offset__9; _ = opts__5




	if jrt.A2g_Truth(or__1927000174__auto____10) { tmp3 = or__1927000174__auto____10 } else { tmp3 = A_arbace_g2a_print_code_A_const_157 }; items__10 = tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(forms__0, parent__8, tmp3))
//line :1323:1
	var n__11 int32 = lang.RT_Count_O__I(items__10); var nxts__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_99.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_314.GetRawRoot__O(), items__10)); var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J(n__11); var i__14 int64 = 0; L1: for {







		if lang.Numbers_Lt_J_J__Z(i__14, n__1927000701__auto____13) { var it__15 any = lang.RT_Nth_O_I__O(items__10, lang.RT_IntCast_J__I(i__14)); var nxt__16 any; var or__1927000174__auto____16 any = lang.RT_Nth_O_I__O(nxts__12, lang.RT_IntCast_J__I(i__14))

			if jrt.A2g_Truth(or__1927000174__auto____16) { nxt__16 = or__1927000174__auto____16 } else { nxt__16 = A_arbace_g2a_print_code_A_const_62.Get__O() }
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_62, nxt__16)); var tmp4 any = A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_New_I_O_O_J_O(n__11, results_QMARK___7, indent__6, i__14, it__15); var tmp5 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_181, false); A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_fn_class = fncls__79d; tmp5 = fncls__79d } else { tmp5 = fncls__79 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :1331:1
			i__14 = lang.Numbers_Unchecked_inc_J__J(i__14); continue L1 } else { return nil } } }; /*line :1323:1*/panic("a2g: unreachable") }










func A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_New_I_O_O_J_O(p0 int32, p1, p2 any, p3 int64, p4 any) *A_arbace_g2a_print_code_stmt_list_fn__1022000550_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_stmt_list_fn__1022000550_A{}; t.Ctor_I_O_O_J_O(p0, p1, p2, p3, p4); return t }
//line :1334:1
func (t *A_arbace_g2a_print_code_stmt_list_fn__1022000550_A) Ctor_I_O_O_J_O(c__n int32, c__results_QMARK_, c__indent any, c__i int64, c__it any) { t.F_n = c__n; t.F_results_QMARK_ = c__results_QMARK_; t.F_indent = c__indent; t.F_i = c__i; t.F_it = c__it }
//line :1334:1
func (t *A_arbace_g2a_print_code_stmt_list_fn__1022000550_A) Invoke_O__O(self any) any { var tmp1 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var f__3 any = A_arbace_g2a_print_code_A_const_22.Invoke_O__O(t.F_it); var label_QMARK___4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__3)

	if jrt.A2g_Truth(and__1927000168__auto____4) { label_QMARK___4 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__3), Lit_141)).Ref() } else { label_QMARK___4 = and__1927000168__auto____4 }
//line :1334:1
	var directive_QMARK___5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(f__3)


	if jrt.A2g_Truth(and__1927000168__auto____5) { directive_QMARK___5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__3), Lit_182)).Ref() } else { directive_QMARK___5 = and__1927000168__auto____5 }
//line :1334:1
	var decl_label__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_315.GetRawRoot__O()).Invoke_O__O(t.F_it)




	if jrt.A2g_Truth(directive_QMARK___5) {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_301; var tmp4 any; var t_ any = t.F_it; t.F_it = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; tmp2.Invoke_O_O_O_O__O(tmp5, tmp6.Ref(), Lit_36, t.F_indent)
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_144.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(f__3); var tmp9 any; var t__2 any = t.F_indent; t.F_indent = nil; tmp9 = t__2; tmp1 = tmp7.Invoke_O_O__O(tmp8, tmp9) } else {
//line :1339:1
			if A_arbace_g2a_print_code_A_const_30 != nil {





				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp11 any; if jrt.A2g_Truth(decl_label__6) {
					tmp11 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_319.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_301.Invoke_O__O(t.F_it)) } else {
//line :1345:1
						if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_307.Invoke_O__O(t.F_it)) {

							tmp11 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_319.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_301.Invoke_O__O(t.F_it)) } else {
//line :1345:1
								if A_arbace_g2a_print_code_A_const_30 != nil {


									tmp11 = A_arbace_g2a_print_code_A_const_301.Invoke_O__O(t.F_it) } else {
//line :1345:1
										tmp11 = nil } } }; var tmp12 any = tmp11; var tmp13 any = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(t.F_i)).Ref(); var tmp14 any; var tmp15 any
				var or__1927000174__auto____7 any = label_QMARK___4


				if jrt.A2g_Truth(or__1927000174__auto____7) { tmp15 = or__1927000174__auto____7 } else { tmp15 = decl_label__6 }; if jrt.A2g_Truth(tmp15) { tmp14 = lang.Numbers_Max_J_O__O(0, lang.Numbers_Dec_O__Number(t.F_indent)) } else { tmp14 = t.F_indent }
//line :1345:1
				tmp10.Invoke_O_O_O_O__O(tmp12, tmp13, Lit_36, tmp14)




				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(t.F_indent)
				if jrt.A2g_Truth(decl_label__6) {

					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_290.GetRawRoot__O()).Invoke_O__O(decl_label__6)); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38)
					var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp17 any; if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_307.Invoke_O__O(t.F_it)) { tmp17 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_319.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_301.Invoke_O__O(t.F_it)) } else { tmp17 = A_arbace_g2a_print_code_A_const_301.Invoke_O__O(t.F_it) }; var tmp18 any = tmp17; var tmp19 *jrt.Boolean; jrt.Boolean_Init(); tmp19 = jrt.Boolean_FALSE; tmp16.Invoke_O_O_O_O__O(tmp18, tmp19.Ref(), nil, t.F_indent) }
				if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_307.Invoke_O__O(t.F_it)) {
					var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_316.GetRawRoot__O()); var tmp21 *lang.Keyword = A_arbace_g2a_print_code_A_const_307; var tmp22 any; var t__3 any = t.F_it; t.F_it = nil; tmp22 = t__3; var tmp23 any = tmp21.Invoke_O__O(tmp22); var tmp24 any; var t__4 any = t.F_indent; t.F_indent = nil; tmp24 = t__4; tmp20.Invoke_O_O__O(tmp23, tmp24) } else {
//line :1355:1
						if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_300.Invoke_O__O(t.F_it)) {

							var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_317.GetRawRoot__O()); var tmp26 any = A_arbace_g2a_print_code_A_const_261.GetRawRoot__O(); var tmp27 *lang.Keyword = A_arbace_g2a_print_code_A_const_300; var tmp28 any; var t__5 any = t.F_it; t.F_it = nil; tmp28 = t__5; tmp25.Invoke_O_O__O(tmp26, tmp27.Invoke_O__O(tmp28)) } else {
//line :1355:1
								if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_302.Invoke_O__O(t.F_it)) {


									var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_317.GetRawRoot__O()); var tmp30 any = A_arbace_g2a_print_code_A_const_320.GetRawRoot__O(); var tmp31 *lang.Keyword = A_arbace_g2a_print_code_A_const_302; var tmp32 any; var t__6 any = t.F_it; t.F_it = nil; tmp32 = t__6; tmp29.Invoke_O_O__O(tmp30, tmp31.Invoke_O__O(tmp32)) } else {
//line :1355:1
										if jrt.A2g_Truth(label_QMARK___4) {



											var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_296.GetRawRoot__O()); var tmp34 any; var t__7 any = t.F_indent; t.F_indent = nil; tmp34 = t__7; var tmp35 int64 = t.F_i; tmp33.Invoke_O_O_O__O(f__3, tmp34, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_J_J__Z(tmp35, lang.Numbers_Dec_J__J(int64(t.F_n)))).Ref()) } else {
//line :1355:1
												var tmp36 any; var and__1927000168__auto____7 any; var t__8 any = t.F_results_QMARK_; t.F_results_QMARK_ = nil; and__1927000168__auto____7 = t__8




												if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp37 int64 = t.F_i; var and__1927000168__auto____8 bool = lang.Util_Equiv_J_J__Z(tmp37, lang.Numbers_Dec_J__J(int64(t.F_n))); if and__1927000168__auto____8 { tmp36 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_318.GetRawRoot__O()).Invoke_O__O(f__3) } else { tmp36 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp36 = and__1927000168__auto____7 }
//line :1355:1
												if jrt.A2g_Truth(tmp36) {





													lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_167); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(f__3, A_arbace_g2a_print_code_A_const_106) } else {
//line :1355:1
														if A_arbace_g2a_print_code_A_const_30 != nil {






															lang.IFn_Cast(A_arbace_g2a_print_code_A_const_269.GetRawRoot__O()).Invoke_O__O(f__3) } } } } } }
				tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O() } else {
//line :1339:1
					tmp1 = nil } } }; return nil }(); /*line :1334:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp38 != nil { panic(tmp38) }; return tmp1 }






























func A_arbace_g2a_print_code_block_body_A_New() *A_arbace_g2a_print_code_block_body_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_block_body_A{}; t.Ctor(); return t }
//line :1365:1
func (t *A_arbace_g2a_print_code_block_body_A) Ctor() {}
//line :1365:1
func (t *A_arbace_g2a_print_code_block_body_A) Invoke_O_O_O__O(self, forms__0, p__1022000554__1 any) any { var map__1022000555__3 any = p__1022000554__1; var map__1022000555__4 any; if lang.ISeq_InstanceOf(map__1022000555__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(map__1022000555__3)) { map__1022000555__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(map__1022000555__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(map__1022000555__3)) { map__1022000555__4 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(map__1022000555__3) } else { lang.PersistentArrayMap_Init(); map__1022000555__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1022000555__4 = map__1022000555__3 }; var opts__5 any = map__1022000555__4; var results_QMARK___6 any = lang.RT_Get_O_O__O(map__1022000555__4, A_arbace_g2a_print_code_A_const_227); var end__7 any = lang.RT_Get_O_O__O(map__1022000555__4, A_arbace_g2a_print_code_A_const_97); var func_QMARK___8 any = lang.RT_Get_O_O__O(map__1022000555__4, A_arbace_g2a_print_code_A_const_228); var sep__9 any = lang.RT_Get_O_O__O(map__1022000555__4, A_arbace_g2a_print_code_A_const_229); var next__10 any = lang.RT_Get_O_O__O(map__1022000555__4, A_arbace_g2a_print_code_A_const_277); var parent__11 any = lang.RT_Get_O_O__O(map__1022000555__4, A_arbace_g2a_print_code_A_const_95); var offset__12 any = lang.RT_Get_O_O__O(map__1022000555__4, A_arbace_g2a_print_code_A_const_96); var indent__13 any; var or__1927000174__auto____13 any = A_arbace_g2a_print_code_A_const_134.Invoke_O__O(opts__5); if






	jrt.A2g_Truth(or__1927000174__auto____13) { indent__13 = or__1927000174__auto____13 } else { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_133; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))) { var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_134; indent__13 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } else { var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_135; indent__13 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } }; var tmp4 /*line :1365:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_17; var start__14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); var forms__15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(forms__0); var one_line_QMARK___16 any; var tmp5 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if









	jrt.A2g_Truth(tmp5.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) {
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(end__7)) {
			one_line_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_O__Z(lang.RT_LongCast_O__J(end__7), start__14)).Ref() } else {
//line :1376:1
				var and__1927000168__auto____16 any = func_QMARK___8

				if jrt.A2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_321.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_block_body_fn__1022000557_A_New_O(start__14); var tmp8 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_g2a_print_code_block_body_fn__1022000557_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_g2a_print_code_block_body_fn__1022000557_A_fn_class = fncls__80d; tmp8 = fncls__80d } else { tmp8 = fncls__80 }; and__1927000168__auto____17 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), forms__15); if jrt.A2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_58.GetRawRoot__O()).Invoke_O__O(parent__11); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_64.GetRawRoot__O()); var tmp13 any; var or__1927000174__auto____18 any = offset__12
					if jrt.A2g_Truth(or__1927000174__auto____18) { tmp13 = or__1927000174__auto____18 } else { tmp13 = A_arbace_g2a_print_code_A_const_157 }; var tmp14 any = tmp13; var tmp15 any; var or__1927000174__auto____18_2 any = offset__12; if jrt.A2g_Truth(or__1927000174__auto____18_2) { tmp15 = or__1927000174__auto____18_2 } else { tmp15 = A_arbace_g2a_print_code_A_const_157 }; and__1927000168__auto____18 = tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp14, lang.Numbers_Add_O_J__Number(tmp15, int64(lang.RT_Count_O__I(forms__15))))))
//line :1378:1
					if jrt.A2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(forms__15)

						if jrt.A2g_Truth(or__1927000174__auto____19) { one_line_QMARK___16 = or__1927000174__auto____19 } else { var or__1927000174__auto____20 bool = lang.Util_Identical_O_O__Z(next__10, nil); if or__1927000174__auto____20 { one_line_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____20).Ref() } else { one_line_QMARK___16 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_322.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_157) } } } else {
//line :1378:1
							one_line_QMARK___16 = and__1927000168__auto____18 } } else { one_line_QMARK___16 = and__1927000168__auto____17 } } else { one_line_QMARK___16 = and__1927000168__auto____16 } } } else {
//line :1375:1
								var and__1927000168__auto____16_2 any = func_QMARK___8





								if jrt.A2g_Truth(and__1927000168__auto____16_2) { one_line_QMARK___16 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_131.GetRawRoot__O()).Invoke_O__O(forms__15) } else { one_line_QMARK___16 = and__1927000168__auto____16_2 } }; if
	jrt.A2g_Truth(one_line_QMARK___16) { var tmp16 any; var or__1927000174__auto____17 any = sep__9; if jrt.A2g_Truth(or__1927000174__auto____17) { tmp16 = or__1927000174__auto____17 } else { tmp16 = A_arbace_g2a_print_code_A_const_68.GetRawRoot__O() }; lang.IFn_Cast(tmp16).Invoke__O() } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() };
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_17);
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(indent__13); var tmp17 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp19 any = A_arbace_g2a_print_code_A_const_62; var tmp20 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(end__7)) { tmp20 = end__7 } else { var or__1927000174__auto____17_2 any = next__10; if jrt.A2g_Truth(or__1927000174__auto____17_2) { tmp20 = or__1927000174__auto____17_2 } else { tmp20 = A_arbace_g2a_print_code_A_const_62.Get__O() } }; tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(tmp19, tmp20)); var tmp21 any; tmp39 := /*line :1365:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




















		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(forms__15)) {
			if jrt.A2g_Truth(one_line_QMARK___16) {

				var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp24 any = A_arbace_g2a_print_code_A_const_62; var tmp25 any; var tmp26 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp26.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) { var tmp27 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; tmp25 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp27.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) } else { tmp25 = nil }; tmp22.Invoke_O__O(tmp23.Invoke_O_O__O(tmp24, tmp25)); var tmp28 any = A_arbace_g2a_print_code_block_body_fn__1022000559_A_New_O_O_O(forms__15, results_QMARK___6, indent__13); var tmp29 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_g2a_print_code_block_body_fn__1022000559_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_g2a_print_code_block_body_fn__1022000559_A_fn_class = fncls__81d; tmp29 = fncls__81d } else { tmp29 = fncls__81 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil).Invoke__O() } else {


					var tmp30 any = A_arbace_g2a_print_code_A_const_134; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(forms__15, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30, lang.Numbers_Inc_O__Number(indent__13), A_arbace_g2a_print_code_A_const_227, results_QMARK___6, A_arbace_g2a_print_code_A_const_95, parent__11, A_arbace_g2a_print_code_A_const_96, offset__12))) } }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O()
		if jrt.A2g_Truth(one_line_QMARK___16) {
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(forms__15)) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }; tmp21 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_19) } else {
//line :1394:1
				var close_end__19 any
				var or__1927000174__auto____19_2 any = end__7


				if jrt.A2g_Truth(or__1927000174__auto____19_2) { close_end__19 = or__1927000174__auto____19_2 } else { var or__1927000174__auto____20_2 any; var tmp31 any; var and__1927000168__auto____20 any = A_arbace_g2a_print_code_A_const_278.Invoke_O__O(opts__5)
					if jrt.A2g_Truth(and__1927000168__auto____20) { var and__1927000168__auto____21 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(next__10); if jrt.A2g_Truth(and__1927000168__auto____21) { var tmp32 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; tmp31 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(next__10), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp32.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))).Ref() } else { tmp31 = and__1927000168__auto____21 } } else { tmp31 = and__1927000168__auto____20 }; if jrt.A2g_Truth(tmp31) { or__1927000174__auto____20_2 = next__10 } else { or__1927000174__auto____20_2 = nil }
//line :1398:1
					if jrt.A2g_Truth(or__1927000174__auto____20_2) { close_end__19 = or__1927000174__auto____20_2 } else {


						var tmp33 any; var and__1927000168__auto____21_2 any = A_arbace_g2a_print_code_A_const_279.Invoke_O__O(opts__5); if jrt.A2g_Truth(and__1927000168__auto____21_2) { var and__1927000168__auto____22 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(next__10); if jrt.A2g_Truth(and__1927000168__auto____22) { var tmp34 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; tmp33 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.Numbers_Dec_J__J(lang.RT_LongCast_O__J(next__10)), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp34.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))).Ref() } else { tmp33 = and__1927000168__auto____22 } } else { tmp33 = and__1927000168__auto____21_2 }; if jrt.A2g_Truth(tmp33) {
							close_end__19 = jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(lang.RT_LongCast_O__J(next__10))).Ref() } else {
//line :1401:1
								close_end__19 = nil
							} } }
				var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_105.GetRawRoot__O()); var tmp36 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var tmp37 any = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp36.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())), start__14)).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp35.Invoke_O_O_O_O__O(close_end__19, tmp37, tmp38.Ref(), indent__13)) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
				tmp21 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_19) }
//line :1365:1
		return nil }();



















	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if /*line :1365:1*/ tmp39 != nil { panic(tmp39) }; return tmp21 }












func A_arbace_g2a_print_code_block_body_fn__1022000557_A_New_O(p0 any) *A_arbace_g2a_print_code_block_body_fn__1022000557_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_block_body_fn__1022000557_A{}; t.Ctor_O(p0); return t }
//line :1378:1
func (t *A_arbace_g2a_print_code_block_body_fn__1022000557_A) Ctor_O(c__start any) { t.F_start = c__start }
//line :1378:1
func (t *A_arbace_g2a_print_code_block_body_fn__1022000557_A) Invoke_O_O__O(self, p1__1022000553_SHARP___1 any) any { var t__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(p1__1022000553_SHARP___1); var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z(t__2, nil); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(t__2, t.F_start)).Ref() } }










func A_arbace_g2a_print_code_block_body_fn__1022000559_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_print_code_block_body_fn__1022000559_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_block_body_fn__1022000559_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1389:1
func (t *A_arbace_g2a_print_code_block_body_fn__1022000559_A) Ctor_O_O_O(c__forms, c__results_QMARK_, c__indent any) { t.F_forms = c__forms; t.F_results_QMARK_ = c__results_QMARK_; t.F_indent = c__indent }
//line :1389:1
func (t *A_arbace_g2a_print_code_block_body_fn__1022000559_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_323.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_forms; t.F_forms = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_results_QMARK_; t.F_results_QMARK_ = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any; var t__3 any = t.F_indent; t.F_indent = nil; tmp7 = t__3; tmp1 = tmp2.Invoke_O_O_O__O(tmp4, tmp6, lang.Numbers_Inc_O__Number(tmp7)) }
//line :1389:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
















func A_arbace_g2a_print_code_stmt_list_one_line_A_New() *A_arbace_g2a_print_code_stmt_list_one_line_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_stmt_list_one_line_A{}; t.Ctor(); return t }
//line :1406:1
func (t *A_arbace_g2a_print_code_stmt_list_one_line_A) Ctor() {}
//line :1406:1
func (t *A_arbace_g2a_print_code_stmt_list_one_line_A) Invoke_O_O_O_O__O(self, forms__0, results_QMARK___1, indent__2 any) any { { var items__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_313.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(forms__0, nil, A_arbace_g2a_print_code_A_const_157)); var n__5 int32 = lang.RT_Count_O__I(items__4); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J(n__5); var i__7 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z(i__7, n__1927000701__auto____6) { var it__8 any = lang.RT_Nth_O_I__O(items__4, lang.RT_IntCast_J__I(i__7)); var f__9 any = A_arbace_g2a_print_code_A_const_22.Invoke_O__O(it__8)

		if lang.Numbers_IsPos_J__Z(i__7) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.Numbers_Dec_O__Number(indent__2))
//line :1411:1
		var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_315.GetRawRoot__O()).Invoke_O__O(it__8)



		if jrt.A2g_Truth(temp__1927000414__auto____10) { var l__11 any = temp__1927000414__auto____10; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_290.GetRawRoot__O()).Invoke_O__O(l__11)); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_38); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
		if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_307.Invoke_O__O(it__8)) {
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_316.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_307.Invoke_O__O(it__8), lang.Numbers_Dec_O__Number(indent__2)) } else {
//line :1416:1
				if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_300.Invoke_O__O(it__8)) {

					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_317.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_261.GetRawRoot__O(), A_arbace_g2a_print_code_A_const_300.Invoke_O__O(it__8)) } else {
//line :1416:1
						if jrt.A2g_Truth(A_arbace_g2a_print_code_A_const_302.Invoke_O__O(it__8)) {


							lang.IFn_Cast(A_arbace_g2a_print_code_A_const_317.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_320.GetRawRoot__O(), A_arbace_g2a_print_code_A_const_302.Invoke_O__O(it__8)) } else {
//line :1416:1
								var tmp1 any
								var and__1927000168__auto____10 any = results_QMARK___1


								if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 bool = lang.Util_Equiv_J_J__Z(i__7, lang.Numbers_Dec_J__J(int64(n__5))); if and__1927000168__auto____11 { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_318.GetRawRoot__O()).Invoke_O__O(f__9) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() } } else { tmp1 = and__1927000168__auto____10 }
//line :1416:1
								if jrt.A2g_Truth(tmp1) {



									lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_167); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(f__9, A_arbace_g2a_print_code_A_const_106) } else {
//line :1416:1
										if A_arbace_g2a_print_code_A_const_30 != nil {




											lang.IFn_Cast(A_arbace_g2a_print_code_A_const_269.GetRawRoot__O()).Invoke_O__O(f__9) } } } } }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O()
//line :1411:1
		i__7 = lang.Numbers_Unchecked_inc_J__J(i__7); continue L1 } else { return nil } } }; /*line :1406:1*/panic("a2g: unreachable") }




















func A_arbace_g2a_print_code_parse_decl_head_A_New() *A_arbace_g2a_print_code_parse_decl_head_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_parse_decl_head_A{}; t.Ctor(); return t }
//line :1427:1
func (t *A_arbace_g2a_print_code_parse_decl_head_A) Ctor() {}
//line :1427:1
func (t *A_arbace_g2a_print_code_parse_decl_head_A) Invoke_O_O__O(self, xs__0 any) any { var vec__1022000563__2 any; if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__0))) { vec__1022000563__2 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__0), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__0)) } else { vec__1022000563__2 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__0) }; var doc__3 any = /*line :1427:1*/lang.RT_Nth_O_I_O__O(vec__1022000563__2, lang.RT_IntCast_J__I(0), nil); var xs__4 any = lang.RT_Nth_O_I_O__O(vec__1022000563__2, lang.RT_IntCast_J__I(1), nil); var vec__1022000566__5 any; if




	lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__4), A_arbace_g2a_print_code_A_const_256) { vec__1022000566__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(xs__4), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(xs__4)) } else { vec__1022000566__5 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__4) }; var tps__6 any = /*line :1427:1*/lang.RT_Nth_O_I_O__O(vec__1022000566__5, lang.RT_IntCast_J__I(0), nil); var xs__7 any = lang.RT_Nth_O_I_O__O(vec__1022000566__5, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(doc__3, tps__6, xs__7) }







func A_arbace_g2a_print_code_generic_type_QMARK__A_New() *A_arbace_g2a_print_code_generic_type_QMARK__A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_generic_type_QMARK__A{}; t.Ctor(); return t }
//line :1435:1
func (t *A_arbace_g2a_print_code_generic_type_QMARK__A) Ctor() {}
//line :1435:1
func (t *A_arbace_g2a_print_code_generic_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__0); if

	jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__0), Lit_4)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { t__2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(t__0) } else { t__2 = t__0 }; var and__1927000168__auto____3 any = /*line :1435:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__2); if


	jrt.A2g_Truth(and__1927000168__auto____3) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_186.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__2))) } else { return and__1927000168__auto____3 } }

func A_arbace_g2a_print_code_func_decl_A_New() *A_arbace_g2a_print_code_func_decl_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_func_decl_A{}; t.Ctor(); return t }
//line :1440:1
func (t *A_arbace_g2a_print_code_func_decl_A) Ctor() {}
//line :1440:1
func (t *A_arbace_g2a_print_code_func_decl_A) Invoke_O_O_O__O(self, f__0, method_QMARK___1 any) any { var vec__1022000571__3 any = f__0; var seq__1022000572__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000571__3); var first__1022000573__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000572__4); var seq__1022000572__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000572__4); var ___7 any = first__1022000573__5; var first__1022000573__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000572__6); var seq__1022000572__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000572__6); var nm__10 any = first__1022000573__8; var xs__11 any = seq__1022000572__9; var vec__1022000574__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_324.GetRawRoot__O()).Invoke_O__O(xs__11); var doc__13 any = lang.RT_Nth_O_I_O__O(vec__1022000574__12, lang.RT_IntCast_J__I(0), nil); var tps__14 any = lang.RT_Nth_O_I_O__O(vec__1022000574__12, lang.RT_IntCast_J__I(1), nil); var xs__15 any = lang.RT_Nth_O_I_O__O(vec__1022000574__12, lang.RT_IntCast_J__I(2), nil); var vec__1022000577__16 any = xs__15; var seq__1022000578__17 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000577__16); var first__1022000579__18 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000578__17); var seq__1022000578__19 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000578__17); var params__20 any = first__1022000579__18; var more__21 any = seq__1022000578__19; var ___22 any; _ = ___7; _ = doc__13; _ = ___22; if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O()).Invoke_O__O(params__20)) { ___22 = nil } else { ___22 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_126, f__0) }; var vec__1022000580__23 any; if
	lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(more__21), A_arbace_g2a_print_code_A_const_159) { vec__1022000580__23 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(more__21), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_164.GetRawRoot__O()).Invoke_O__O(more__21)) } else { vec__1022000580__23 = lang.Tuple_Create_O_O__IPersistentVector(nil, more__21) }; var results__24 any = /*line :1440:1*/lang.RT_Nth_O_I_O__O(vec__1022000580__23, lang.RT_IntCast_J__I(0), nil); var body__25 any = lang.RT_Nth_O_I_O__O(vec__1022000580__23, lang.RT_IntCast_J__I(1), nil); var m__26 any = lang.RT_Meta_O__IPersistentMap(nm__10); var extern_QMARK___27 any = A_arbace_g2a_print_code_A_const_325.Invoke_O__O(m__26); var vec__1022000583__28 any; if









	jrt.A2g_Truth(method_QMARK___1) { vec__1022000583__28 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(params__20), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_326.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(params__20)), lang.RT_Meta_O__IPersistentMap(params__20))) } else { vec__1022000583__28 = lang.Tuple_Create_O_O__IPersistentVector(nil, params__20) }; var recv__29 any = /*line :1440:1*/lang.RT_Nth_O_I_O__O(vec__1022000583__28, lang.RT_IntCast_J__I(0), nil); var params__30 any = lang.RT_Nth_O_I_O__O(vec__1022000583__28, lang.RT_IntCast_J__I(1), nil); var res__31 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_160.GetRawRoot__O()).Invoke_O_O__O(params__30, results__24); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_A_const_117; var tmp4 any; var or__1927000174__auto____32 any = tps__14; if











	jrt.A2g_Truth(or__1927000174__auto____32) { tmp4 = or__1927000174__auto____32 } else { var and__1927000168__auto____33 any = recv__29; if jrt.A2g_Truth(and__1927000168__auto____33) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_327.GetRawRoot__O()); var tmp6 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_109.GetRawRoot__O()).Invoke_O__O(recv__29)) { var tmp7 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(recv__29)) } else { tmp6 = recv__29 }; tmp4 = tmp5.Invoke_O__O(tmp6) } else { tmp4 = and__1927000168__auto____33 } }; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp4)).Ref())); var tmp8 any; tmp29 := /*line :1440:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var indent__34 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_225.GetRawRoot__O()).Invoke__O()













		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_26); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
		if jrt.A2g_Truth(method_QMARK___1) {
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6)
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_109.GetRawRoot__O()).Invoke_O__O(recv__29)) {
				lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(recv__29)); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); var tmp9 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(recv__29))) } else {
					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(recv__29) }
			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
		lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(nm__10))
		if jrt.A2g_Truth(tps__14) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_257.GetRawRoot__O()).Invoke_O__O(tps__14) }
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_138.GetRawRoot__O()); var tmp11 any; if jrt.A2g_Truth(extern_QMARK___27) { tmp11 = nil } else { tmp11 = body__25 }; tmp10.Invoke_O_O_O__O(params__30, res__31, tmp11)
		if jrt.A2g_Truth(extern_QMARK___27) { tmp8 = nil } else {
			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_226.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(body__25); var tmp14 any = A_arbace_g2a_print_code_A_const_227; var tmp15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(res__31); var tmp16 any = A_arbace_g2a_print_code_A_const_97; var tmp17 *lang.Keyword = A_arbace_g2a_print_code_A_const_102; var tmp18 any = tmp17.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); var tmp19 any = A_arbace_g2a_print_code_A_const_228; var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); var tmp22 any = A_arbace_g2a_print_code_A_const_95; var tmp23 any = A_arbace_g2a_print_code_A_const_96; var tmp24 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_230.GetRawRoot__O()).Invoke_O_O__O(f__0, body__25); var tmp25 any = A_arbace_g2a_print_code_A_const_134; var tmp26 any = A_arbace_g2a_print_code_A_const_229; var tmp27 any
			var tmp28 /*line :1465:1*/*lang.Keyword = A_arbace_g2a_print_code_A_const_49

			if jrt.A2g_Truth(tmp28.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) { tmp27 = A_arbace_g2a_print_code_A_const_166.GetRawRoot__O() } else { tmp27 = A_arbace_g2a_print_code_A_const_68.GetRawRoot__O() }
//line :1465:1
			tmp8 = tmp12.Invoke_O_O__O(tmp13, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, f__0, tmp23, tmp24, tmp25, indent__34, tmp26, tmp27))) } }; return nil }(); /*line :1452:1*/lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if /*line :1440:1*/ tmp29 != nil { panic(tmp29) }; return tmp8 }




























func A_arbace_g2a_print_code_spec_name_A_New() *A_arbace_g2a_print_code_spec_name_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_spec_name_A{}; t.Ctor(); return t }
//line :1469:1
func (t *A_arbace_g2a_print_code_spec_name_A) Ctor() {}
//line :1469:1
func (t *A_arbace_g2a_print_code_spec_name_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(t__0), Lit_93)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(t__0) } else { return t__0 } }

func A_arbace_g2a_print_code_value_spec_A_New() *A_arbace_g2a_print_code_value_spec_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_value_spec_A{}; t.Ctor(); return t }
//line :1471:1
func (t *A_arbace_g2a_print_code_value_spec_A) Ctor() {}
//line :1471:1
func (t *A_arbace_g2a_print_code_value_spec_A) Invoke_O_O_O_O_O__O(self, target__0, init__1, group_QMARK___2, keep_type__3 any) any { var ts__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_249.GetRawRoot__O()).Invoke_O__O(target__0); var typ__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_value_spec_fn__1022000589_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_g2a_print_code_value_spec_fn__1022000589_A_fn_class; if



	fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_205, false); A_arbace_g2a_print_code_value_spec_fn__1022000589_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; typ__6 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ts__5); var sep__7 any; if
	jrt.A2g_Truth(group_QMARK___2) { sep__7 = A_arbace_g2a_print_code_A_const_166.GetRawRoot__O() } else { sep__7 = A_arbace_g2a_print_code_A_const_68.GetRawRoot__O() };
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_128.GetRawRoot__O()).Invoke_O__O(ts__5); var tmp4 any; var or__1927000174__auto____8 any = typ__6; if
	jrt.A2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var and__1927000168__auto____9 any = group_QMARK___2; if jrt.A2g_Truth(and__1927000168__auto____9) { tmp4 = keep_type__3 } else { tmp4 = and__1927000168__auto____9 } }; if jrt.A2g_Truth(tmp4) { lang.IFn_Cast(sep__7).Invoke__O() }; if
	jrt.A2g_Truth(typ__6) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(typ__6) }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_g2a_print_code_A_const_311)) {
		lang.IFn_Cast(sep__7).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_252.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_g2a_print_code_A_const_106) } else {
//line :1480:1
			return nil } }
//line :1475:1
func A_arbace_g2a_print_code_value_spec_fn__1022000589_A_New() *A_arbace_g2a_print_code_value_spec_fn__1022000589_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_value_spec_fn__1022000589_A{}; t.Ctor(); return t }
//line :1475:1
func (t *A_arbace_g2a_print_code_value_spec_fn__1022000589_A) Ctor() {}
//line :1475:1
func (t *A_arbace_g2a_print_code_value_spec_fn__1022000589_A) Invoke_O_O__O(self, p1__1022000588_SHARP___1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(p1__1022000588_SHARP___1), A_arbace_g2a_print_code_A_const_107)) { var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_107; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1022000588_SHARP___1)) } else { return nil } }







func A_arbace_g2a_print_code_keep_type_column_A_New() *A_arbace_g2a_print_code_keep_type_column_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_keep_type_column_A{}; t.Ctor(); return t }
//line :1483:1
func (t *A_arbace_g2a_print_code_keep_type_column_A) Ctor() {}
//line :1483:1
func (t *A_arbace_g2a_print_code_keep_type_column_A) Invoke_O_O__O(self, specs__0 any) any { { var n__2 int32 = lang.RT_Count_O__I(specs__0); var m__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_328.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_219.GetRawRoot__O()); var tmp4 any = jrt.Integer_ValueOf_I__Integer(n__2).Ref(); var tmp5 *jrt.Boolean



	jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; m__3 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())))
//line :1483:1
	var i__4 int64 = 0; var i0__5 any = lang.RT_Box_J__Number(-1); var keep__6 any; jrt.Boolean_Init(); keep__6 = jrt.Boolean_FALSE.Ref(); L1: for {





		if lang.Numbers_Lt_J_J__Z(i__4, int64(n__2)) { var vec__1022000609__7 any = lang.RT_Nth_O_I__O(specs__0, lang.RT_IntCast_J__I(i__4)); var t__8 any = lang.RT_Nth_O_I_O__O(vec__1022000609__7, lang.RT_IntCast_J__I(0), nil); var init__9 any = lang.RT_Nth_O_I_O__O(vec__1022000609__7, lang.RT_IntCast_J__I(1), nil); var has_values__10 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_142.GetRawRoot__O()).Invoke_O_O__O(init__9, A_arbace_g2a_print_code_A_const_311); var typed__11 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_12.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_New(); var tmp8 *jrt.Class
			var fncls__83 /*line :1489:1*/*jrt.Class = A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_fn_class


			if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_fn_class = fncls__83d; tmp8 = fncls__83d } else { tmp8 = fncls__83 }; typed__11 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_249.GetRawRoot__O()).Invoke_O__O(t__8))
//line :1489:1
			var vec__1022000612__12 any



			if jrt.A2g_Truth(has_values__10) {
				if lang.Numbers_IsNeg_O__Z(i0__5) { var tmp9 any = jrt.Long_ValueOf_J__Long(i__4).Ref(); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; vec__1022000612__12 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Ref()) } else { vec__1022000612__12 = lang.Tuple_Create_O_O__IPersistentVector(i0__5, keep__6) } } else {
					if lang.Numbers_Gte_O_J__Z(i0__5, 0) { var seq_1022000617__12 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_64.GetRawRoot__O()).Invoke_O_O__O(i0__5, jrt.Long_ValueOf_J__Long(i__4).Ref())); var chunk_1022000618__13 any; var count_1022000619__14 int64 = 0; var i_1022000620__15 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z(i_1022000620__15, count_1022000619__14) { var j__16 any = lang.Indexed_Cast(chunk_1022000618__13).Nth_I__O(lang.RT_IntCast_J__I(i_1022000620__15)); if jrt.A2g_Truth(keep__6) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_330.GetRawRoot__O()); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; tmp11.Invoke_O_O_O__O(m__3, j__16, tmp12.Ref()) }; seq_1022000617__12, chunk_1022000618__13, count_1022000619__14, i_1022000620__15 = seq_1022000617__12, chunk_1022000618__13, count_1022000619__14, lang.Numbers_Unchecked_inc_J__J(i_1022000620__15); continue L2 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000617__12); if jrt.A2g_Truth(temp__1927000414__auto____16) { var seq_1022000617__17 any = temp__1927000414__auto____16; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000617__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000617__17); seq_1022000617__12, chunk_1022000618__13, count_1022000619__14, i_1022000620__15 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000617__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var j__18 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000617__17); if jrt.A2g_Truth(keep__6) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_330.GetRawRoot__O()); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; tmp13.Invoke_O_O_O__O(m__3, j__18, tmp14.Ref()) }; seq_1022000617__12, chunk_1022000618__13, count_1022000619__14, i_1022000620__15 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000617__17), nil, 0, 0; continue L2 } } }; break L2 } }
//line :1493:1
					vec__1022000612__12 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_g2a_print_code_A_const_141, keep__6) }
//line :1489:1
			var i0__13 any = lang.RT_Nth_O_I_O__O(vec__1022000612__12, lang.RT_IntCast_J__I(0), nil); var keep__14 any = lang.RT_Nth_O_I_O__O(vec__1022000612__12, lang.RT_IntCast_J__I(1), nil); var keep__15 any
			var or__1927000174__auto____15 any = keep__14






			if jrt.A2g_Truth(or__1927000174__auto____15) { keep__15 = or__1927000174__auto____15 } else { keep__15 = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(typed__11)).Ref() }
			i__4, i0__5, keep__6 = lang.Numbers_Inc_J__J(i__4), i0__13, keep__15; continue L1 } else {
				if lang.Numbers_Gte_O_J__Z(i0__5, 0) { var seq_1022000621__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_64.GetRawRoot__O()).Invoke_O_O__O(i0__5, jrt.Integer_ValueOf_I__Integer(n__2).Ref())); var chunk_1022000622__8 any; var count_1022000623__9 int64 = 0; var i_1022000624__10 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z(i_1022000624__10, count_1022000623__9) { var j__11 any = lang.Indexed_Cast(chunk_1022000622__8).Nth_I__O(lang.RT_IntCast_J__I(i_1022000624__10)); if jrt.A2g_Truth(keep__6) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_330.GetRawRoot__O()); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; tmp15.Invoke_O_O_O__O(m__3, j__11, tmp16.Ref()) }; seq_1022000621__7, chunk_1022000622__8, count_1022000623__9, i_1022000624__10 = seq_1022000621__7, chunk_1022000622__8, count_1022000623__9, lang.Numbers_Unchecked_inc_J__J(i_1022000624__10); continue L3 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(seq_1022000621__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1022000621__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1022000621__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1022000621__12); seq_1022000621__7, chunk_1022000622__8, count_1022000623__9, i_1022000624__10 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(seq_1022000621__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var j__13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1022000621__12); if jrt.A2g_Truth(keep__6) { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_330.GetRawRoot__O()); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; tmp17.Invoke_O_O_O__O(m__3, j__13, tmp18.Ref()) }; seq_1022000621__7, chunk_1022000622__8, count_1022000623__9, i_1022000624__10 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1022000621__12), nil, 0, 0; continue L3 } } }; break L3 } }
				return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_329.GetRawRoot__O()).Invoke_O__O(m__3) } } }; /*line :1483:1*/panic("a2g: unreachable") }








func A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_New() *A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A{}; t.Ctor(); return t }
//line :1492:1
func (t *A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A) Ctor() {}
//line :1492:1
func (t *A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A) Invoke_O_O__O(self, p1__1022000592_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(p1__1022000592_SHARP___1), A_arbace_g2a_print_code_A_const_107) }









func A_arbace_g2a_print_code_spec_t_A_New() *A_arbace_g2a_print_code_spec_t_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_spec_t_A{}; t.Ctor(); return t }
//line :1502:1
func (t *A_arbace_g2a_print_code_spec_t_A) Ctor() {}
//line :1502:1
func (t *A_arbace_g2a_print_code_spec_t_A) Invoke_O_O__O(self, v__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(v__0); if
										jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(v__0))); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(v__0))) { return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(v__0)) } else { return nil } } } }

func A_arbace_g2a_print_code_group_decl_A_New() *A_arbace_g2a_print_code_group_decl_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_decl_A{}; t.Ctor(); return t }
//line :1505:1
func (t *A_arbace_g2a_print_code_group_decl_A) Ctor() {}
//line :1505:1
func (t *A_arbace_g2a_print_code_group_decl_A) Invoke_O_O_O_O_O_O__O(self, kw__0, doc__1, specs__2, print_spec__3, meta_of__4 any) any {


	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(kw__0); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_6)
//line :1505:1
	var indent__6 int64 = 0




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_131.GetRawRoot__O()).Invoke_O__O(specs__2)) {
		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
//line :1510:1
			var specs__7 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(specs__2); var tmp1 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var last_start__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_169.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))); var tmp2 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var first_line__9 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); _ = first_line__9




			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_104.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_157)
//line :1510:1
			var n__1927000701__auto____10 int64 = lang.RT_LongCast_I__J(lang.RT_Count_O__I(specs__7)); var i__11 int64 = 0; L1: for {





				if lang.Numbers_Lt_J_J__Z(i__11, n__1927000701__auto____10) { var s__12 any = lang.RT_Nth_O_I__O(specs__7, lang.RT_IntCast_J__I(i__11)); var m__13 any = lang.IFn_Cast(meta_of__4).Invoke_O__O(s__12); var dirs__14 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(m__13); var pre__15 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_172.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_114.Invoke_O__O(m__13), dirs__14); var t__16 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(s__12); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O())
					var tmp4 any = A_arbace_g2a_print_code_A_const_62




					lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_137.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_175.GetRawRoot__O()).Invoke_O_O__O(specs__7, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(i__11)).Ref())))); var tmp5 any = A_arbace_g2a_print_code_group_decl_fn__1022000627_A_New_O_O_O_J(t__16, last_start__8, pre__15, i__11); var tmp6 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_g2a_print_code_group_decl_fn__1022000627_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_g2a_print_code_group_decl_fn__1022000627_A_fn_class = fncls__84d; tmp6 = fncls__84d } else { tmp6 = fncls__84 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()







					if lang.Numbers_IsPos_O__Z(pre__15) {
						var tmp7 *lang.Keyword = A_arbace_g2a_print_code_A_const_133; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()))) { } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_171.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code_A_const_106) }
						lang.IFn_Cast(A_arbace_g2a_print_code_A_const_334.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_print_code_A_const_114.Invoke_O__O(m__13), dirs__14, A_arbace_g2a_print_code_A_const_106)
						var tmp8 any; var tmp9 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____17 any = tmp9.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O()); if jrt.A2g_Truth(and__1927000168__auto____17) { tmp8 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(t__16) } else { tmp8 = and__1927000168__auto____17 }; if jrt.A2g_Truth(tmp8) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; tmp10.Invoke_O_O_O_O__O(t__16, tmp11.Ref(), nil, A_arbace_g2a_print_code_A_const_106) } }
					var tmp12 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_174.GetRawRoot__O()).Invoke_O_O__O(last_start__8, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))
					lang.IFn_Cast(print_spec__3).Invoke_O_O__O(s__12, jrt.Long_ValueOf_J__Long(i__11).Ref())
//line :1516:1
					i__11 = lang.Numbers_Unchecked_inc_J__J(i__11); continue L1 }
//line :1510:1
				break L1
			}
























			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_100.GetRawRoot__O()).Invoke__O()
			var tmp13 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp13.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) {
				var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_105.GetRawRoot__O()); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; var tmp16 any = tmp15.Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); tmp14.Invoke_O_O_O_O__O(nil, tmp16, tmp18, jrt.Long_ValueOf_J__Long(indent__6).Ref()) } else {
					var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_171.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_print_code_A_const_157; var tmp21 *jrt.Boolean; jrt.Boolean_Init(); tmp21 = jrt.Boolean_TRUE; tmp19.Invoke_O_O__O(tmp20, tmp21.Ref()) }
			return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_8) } }
//line :1522:1
func A_arbace_g2a_print_code_group_decl_fn__1022000627_A_New_O_O_O_J(p0, p1, p2 any, p3 int64) *A_arbace_g2a_print_code_group_decl_fn__1022000627_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_group_decl_fn__1022000627_A{}; t.Ctor_O_O_O_J(p0, p1, p2, p3); return t }
//line :1522:1
func (t *A_arbace_g2a_print_code_group_decl_fn__1022000627_A) Ctor_O_O_O_J(c__t, c__last_start, c__pre any, c__i int64) { t.F_t = c__t; t.F_last_start = c__last_start; t.F_pre = c__pre; t.F_i = c__i }
//line :1522:1
func (t *A_arbace_g2a_print_code_group_decl_fn__1022000627_A) Invoke_O__O(self any) any { var tmp1 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var tmp3 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; var and__1927000168__auto____3 any = tmp3.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())
												if jrt.A2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(t.F_t) } else { tmp2 = and__1927000168__auto____3 }
//line :1523:1
		if jrt.A2g_Truth(tmp2) {

			if lang.Numbers_IsPos_O__Z(t.F_pre) {
				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_t; t.F_t = nil; tmp5 = t_; var tmp6 int64 = lang.RT_LongCast_O__J(tmp5); var tmp7 any; var t__2 any = t.F_pre; t.F_pre = nil; tmp7 = t__2; var tmp8 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var tmp9 any = lang.Numbers_Max_O_O__O(lang.Numbers_Minus_J_O__Number(tmp6, tmp7), lang.Numbers_Inc_O__Number(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())))); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; tmp1 = tmp4.Invoke_O_O_O_O__O(tmp9, tmp10.Ref(), Lit_36, A_arbace_g2a_print_code_A_const_106) } else {
					var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp12 any; var t__3 any = t.F_t; t.F_t = nil; tmp12 = t__3; tmp1 = tmp11.Invoke_O_O_O_O__O(tmp12, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(t.F_i)).Ref(), Lit_36, A_arbace_g2a_print_code_A_const_106) } } else {
//line :1523:1
						var tmp13 *lang.Keyword = A_arbace_g2a_print_code_A_const_49; if jrt.A2g_Truth(tmp13.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())) {




							var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_173.GetRawRoot__O()); var tmp15 *lang.Keyword; var tmp16 any; var t__4 any = t.F_pre; t.F_pre = nil; tmp16 = t__4; if lang.Numbers_IsPos_O__Z(tmp16) { tmp15 = A_arbace_g2a_print_code_A_const_57 } else { tmp15 = nil }; tmp1 = tmp14.Invoke_O_O_O_O__O(tmp15.Ref(), jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(t.F_i)).Ref(), Lit_36, A_arbace_g2a_print_code_A_const_106) } else {
//line :1523:1
								if A_arbace_g2a_print_code_A_const_30 != nil {





									var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_171.GetRawRoot__O()); var tmp18 any = A_arbace_g2a_print_code_A_const_106; var tmp19 *jrt.Boolean; var or__1927000174__auto____3 bool = lang.Numbers_IsZero_J__Z(t.F_i); if or__1927000174__auto____3 { tmp19 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3) } else { var tmp20 *lang.Keyword = A_arbace_g2a_print_code_A_const_17; var tmp21 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(A_arbace_g2a_print_code_A_const_50.Get__O())); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_7.GetRawRoot__O()); var tmp23 any; var t__5 any = t.F_last_start; t.F_last_start = nil; tmp23 = t__5; tmp19 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(tmp21, tmp22.Invoke_O__O(tmp23))) }; tmp1 = tmp17.Invoke_O_O__O(tmp18, tmp19.Ref()) } else {
//line :1523:1
										tmp1 = nil } } } }
//line :1522:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp24 != nil { panic(tmp24) }; return tmp1 }



















func A_arbace_g2a_print_code_const_var_decl_A_New() *A_arbace_g2a_print_code_const_var_decl_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_var_decl_A{}; t.Ctor(); return t }
//line :1542:1
func (t *A_arbace_g2a_print_code_const_var_decl_A) Ctor() {}
//line :1542:1
func (t *A_arbace_g2a_print_code_const_var_decl_A) Invoke_O_O_O__O(self, f__0, kw__1 any) any { var vec__1022000630__3 any = f__0; var seq__1022000631__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000630__3); var first__1022000632__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000631__4); var seq__1022000631__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000631__4); var ___7 any = first__1022000632__5; var xs__8 any = seq__1022000631__6; var vec__1022000633__9 any; _ = ___7; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__8))) { vec__1022000633__9 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__8), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__8)) } else { vec__1022000633__9 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__8) }; var doc__10 any = /*line :1542:1*/lang.RT_Nth_O_I_O__O(vec__1022000633__9, lang.RT_IntCast_J__I(0), nil); var xs__11 any = lang.RT_Nth_O_I_O__O(vec__1022000633__9, lang.RT_IntCast_J__I(1), nil); if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_321.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O(), xs__11)) { var specs__12 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_63.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_New(); var tmp3 *jrt.Class
		var fncls__85 /*line :1545:1*/*jrt.Class = A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_fn_class

		if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; specs__12 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), xs__11)
//line :1545:1
		var keep__13 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_310.GetRawRoot__O()).Invoke_O__O(specs__12); var group_QMARK___14 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(specs__12)), 1); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_335.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_New_O_Z_O(specs__12, group_QMARK___14, keep__13); var tmp6 *jrt.Class
		var fncls__86 /*line :1545:1*/*jrt.Class = A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_fn_class





		if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_fn_class = fncls__86d; tmp6 = fncls__86d } else { tmp6 = fncls__86 }
//line :1550:1
		var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_New(); var tmp9 *jrt.Class
		var fncls__87 /*line :1550:1*/*jrt.Class = A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_fn_class

		if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_fn_class = fncls__87d; tmp9 = fncls__87d } else { tmp9 = fncls__87 }
//line :1550:1
		return tmp4.Invoke_O_O_O_O_O__O(kw__1, doc__10, xs__11, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else {
//line :1545:1
			var vec__1022000645__12 any = xs__11; var t__13 any = lang.RT_Nth_O_I_O__O(vec__1022000645__12, lang.RT_IntCast_J__I(0), nil); var init__14 any = lang.RT_Nth_O_I_O__O(vec__1022000645__12, lang.RT_IntCast_J__I(1), nil)








			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(kw__1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_336.GetRawRoot__O()); var tmp11 any; if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(xs__11)), 1) { tmp11 = init__14 } else { tmp11 = A_arbace_g2a_print_code_A_const_311 }; var tmp12 any = tmp11; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_FALSE; var tmp14 any = tmp13.Ref(); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_FALSE; return tmp10.Invoke_O_O_O_O__O(t__13, tmp12, tmp14, tmp15.Ref()) } }
//line :1547:1
func A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_New() *A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A{}; t.Ctor(); return t }
//line :1547:1
func (t *A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A) Ctor() {}
//line :1547:1
func (t *A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(v__1); var tmp2 any; if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(v__1)), 1) { tmp2 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_38.GetRawRoot__O()).Invoke_O__O(v__1) } else { tmp2 = A_arbace_g2a_print_code_A_const_311 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }



func A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_New_O_Z_O(p0 any, p1 bool, p2 any) *A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A{}; t.Ctor_O_Z_O(p0, p1, p2); return t }
//line :1551:1
func (t *A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A) Ctor_O_Z_O(c__specs any, c__group_QMARK_ bool, c__keep any) { t.F_specs = c__specs; t.F_group_QMARK_ = c__group_QMARK_; t.F_keep = c__keep }
//line :1551:1
func (t *A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A) Invoke_O_O_O__O(self, v__1, i__2 any) any { var tmp1 any = t.F_specs; var vec__1022000639__3 any = lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(i__2)); var t__4 any = lang.RT_Nth_O_I_O__O(vec__1022000639__3, lang.RT_IntCast_J__I(0), nil); var init__5 any = lang.RT_Nth_O_I_O__O(vec__1022000639__3, lang.RT_IntCast_J__I(1), nil); var tmp2 any = t.F_keep; return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_336.GetRawRoot__O()).Invoke_O_O_O_O__O(t__4, init__5, jrt.Boolean_ValueOf_Z__Boolean(t.F_group_QMARK_).Ref(), lang.RT_Nth_O_I__O(tmp2, lang.RT_IntCast_O__I(i__2))) }
func A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_New() *A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A{}; t.Ctor(); return t }
//line :1552:1
func (t *A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A) Ctor() {}
//line :1552:1
func (t *A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A) Invoke_O_O__O(self, v__1 any) any { return lang.RT_Meta_O__IPersistentMap(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(v__1))) }




func A_arbace_g2a_print_code_type_spec_A_New() *A_arbace_g2a_print_code_type_spec_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_spec_A{}; t.Ctor(); return t }
//line :1557:1
func (t *A_arbace_g2a_print_code_type_spec_A) Ctor() {}
//line :1557:1
func (t *A_arbace_g2a_print_code_type_spec_A) Invoke_O_O_O_O_O__O(self, nm__0, tps__1, t__2, group_QMARK___3 any) any {
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_79.GetRawRoot__O()).Invoke_O__O(nm__0))
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_70.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_code_A_const_117; lang.IFn_Cast(A_arbace_g2a_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tps__1)).Ref()))
//line :1557:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		if jrt.A2g_Truth(tps__1) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_257.GetRawRoot__O()).Invoke_O__O(tps__1) }
		if jrt.A2g_Truth(group_QMARK___3) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_166.GetRawRoot__O()).Invoke__O() } else { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
		{ var tmp4 *lang.Keyword = A_arbace_g2a_print_code_A_const_258; if jrt.A2g_Truth(tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__0))) { lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O() }
			tmp3 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t__2) }
//line :1557:1
		return nil
	}()
	lang.IFn_Cast(A_arbace_g2a_print_code_A_const_66.GetRawRoot__O()).Invoke__O()
//line :1557:1
	if tmp5 != nil { panic(tmp5) }; return tmp3
}






func A_arbace_g2a_print_code_parse_type_spec_A_New() *A_arbace_g2a_print_code_parse_type_spec_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_parse_type_spec_A{}; t.Ctor(); return t }
//line :1565:1
func (t *A_arbace_g2a_print_code_parse_type_spec_A) Ctor() {}
//line :1565:1
func (t *A_arbace_g2a_print_code_parse_type_spec_A) Invoke_O_O__O(self, xs__0 any) any { var vec__1022000650__2 any = xs__0; var seq__1022000651__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000650__2); var first__1022000652__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000651__3); var seq__1022000651__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000651__3); var nm__6 any = first__1022000652__4; var xs__7 any = seq__1022000651__5; var vec__1022000653__8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_324.GetRawRoot__O()).Invoke_O__O(xs__7); var doc__9 any = lang.RT_Nth_O_I_O__O(vec__1022000653__8, lang.RT_IntCast_J__I(0), nil); var tps__10 any = lang.RT_Nth_O_I_O__O(vec__1022000653__8, lang.RT_IntCast_J__I(1), nil); var xs__11 any = lang.RT_Nth_O_I_O__O(vec__1022000653__8, lang.RT_IntCast_J__I(2), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(nm__6, doc__9, tps__10, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__11)) }





func A_arbace_g2a_print_code_type_decl_A_New() *A_arbace_g2a_print_code_type_decl_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_decl_A{}; t.Ctor(); return t }
//line :1571:1
func (t *A_arbace_g2a_print_code_type_decl_A) Ctor() {}
//line :1571:1
func (t *A_arbace_g2a_print_code_type_decl_A) Invoke_O_O__O(self, f__0 any) any { var vec__1022000657__2 any = f__0; var seq__1022000658__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(vec__1022000657__2); var first__1022000659__4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(seq__1022000658__3); var seq__1022000658__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_81.GetRawRoot__O()).Invoke_O__O(seq__1022000658__3); var ___6 any = first__1022000659__4; var xs__7 any = seq__1022000658__5; var vec__1022000660__8 any; _ = ___6; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__7))) { vec__1022000660__8 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__7), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__7)) } else { vec__1022000660__8 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__7) }; var gdoc__9 any = /*line :1571:1*/lang.RT_Nth_O_I_O__O(vec__1022000660__8, lang.RT_IntCast_J__I(0), nil); var gxs__10 any = lang.RT_Nth_O_I_O__O(vec__1022000660__8, lang.RT_IntCast_J__I(1), nil); var tmp1 any; var or__1927000174__auto____11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_131.GetRawRoot__O()).Invoke_O__O(gxs__10); if


	jrt.A2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_321.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O(), gxs__10) }; if jrt.A2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_335.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_code_type_decl_fn__1022000663_A_New_O(gxs__10); var tmp4 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_g2a_print_code_type_decl_fn__1022000663_A_fn_class
		if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_189, false); A_arbace_g2a_print_code_type_decl_fn__1022000663_A_fn_class = fncls__88d; tmp4 = fncls__88d } else { tmp4 = fncls__88 }
//line :1575:1
		var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_g2a_print_code_type_decl_fn__1022000668_A_New(); var tmp7 *jrt.Class
		var fncls__89 /*line :1575:1*/*jrt.Class = A_arbace_g2a_print_code_type_decl_fn__1022000668_A_fn_class


		if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_190, false); A_arbace_g2a_print_code_type_decl_fn__1022000668_A_fn_class = fncls__89d; tmp7 = fncls__89d } else { tmp7 = fncls__89 }
//line :1575:1
		return tmp2.Invoke_O_O_O_O_O__O(Lit_188, gdoc__9, gxs__10, tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)) } else {
//line :1574:1
			var vec__1022000670__11 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_337.GetRawRoot__O()).Invoke_O__O(xs__7); var nm__12 any = lang.RT_Nth_O_I_O__O(vec__1022000670__11, lang.RT_IntCast_J__I(0), nil); var ___13 any = lang.RT_Nth_O_I_O__O(vec__1022000670__11, lang.RT_IntCast_J__I(1), nil); var tps__14 any = lang.RT_Nth_O_I_O__O(vec__1022000670__11, lang.RT_IntCast_J__I(2), nil); var t__15 any = lang.RT_Nth_O_I_O__O(vec__1022000670__11, lang.RT_IntCast_J__I(3), nil); _ = ___13





			lang.IFn_Cast(A_arbace_g2a_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(Lit_188); lang.IFn_Cast(A_arbace_g2a_print_code_A_const_68.GetRawRoot__O()).Invoke__O()
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_338.GetRawRoot__O()); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; return tmp8.Invoke_O_O_O_O__O(nm__12, tps__14, t__15, tmp9.Ref()) } }
//line :1576:1
func A_arbace_g2a_print_code_type_decl_fn__1022000663_A_New_O(p0 any) *A_arbace_g2a_print_code_type_decl_fn__1022000663_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_decl_fn__1022000663_A{}; t.Ctor_O(p0); return t }
//line :1576:1
func (t *A_arbace_g2a_print_code_type_decl_fn__1022000663_A) Ctor_O(c__gxs any) { t.F_gxs = c__gxs }
//line :1576:1
func (t *A_arbace_g2a_print_code_type_decl_fn__1022000663_A) Invoke_O_O_O__O(self, v__1, ___2 any) any { var vec__1022000664__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_337.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(v__1)); var nm__4 any = lang.RT_Nth_O_I_O__O(vec__1022000664__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1022000664__3, lang.RT_IntCast_J__I(1), nil); var tps__6 any = lang.RT_Nth_O_I_O__O(vec__1022000664__3, lang.RT_IntCast_J__I(2), nil); var t__7 any = lang.RT_Nth_O_I_O__O(vec__1022000664__3, lang.RT_IntCast_J__I(3), nil); _ = ___5; return /*line :1577:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O_O_O__O(nm__4, tps__6, t__7, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(t.F_gxs)), 1)).Ref()) }
func A_arbace_g2a_print_code_type_decl_fn__1022000668_A_New() *A_arbace_g2a_print_code_type_decl_fn__1022000668_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_type_decl_fn__1022000668_A{}; t.Ctor(); return t }
//line :1578:1
func (t *A_arbace_g2a_print_code_type_decl_fn__1022000668_A) Ctor() {}
//line :1578:1
func (t *A_arbace_g2a_print_code_type_decl_fn__1022000668_A) Invoke_O_O__O(self, v__1 any) any { return lang.RT_Meta_O__IPersistentMap(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(v__1)) }




func A_arbace_g2a_print_code_decl_doc_and_directives_A_New() *A_arbace_g2a_print_code_decl_doc_and_directives_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_decl_doc_and_directives_A{}; t.Ctor(); return t }
//line :1583:1
func (t *A_arbace_g2a_print_code_decl_doc_and_directives_A) Ctor() {}
//line :1583:1
func (t *A_arbace_g2a_print_code_decl_doc_and_directives_A) Invoke_O_O__O(self, f__0 any) any { var o__2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0); var xs__3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0); var G__1022000674__4_ any = o__2; switch




	lang.Util_Hash_O__I(G__1022000674__4_) >> 9 & 7 { case 2: if lang.Util_Equiv_O_O__Z(G__1022000674__4_, Lit_55) {



		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3))) { var tmp1 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Ref()) } else {

			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_321.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O(), xs__3)) { var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(nil, tmp3.Ref()) } else { var vec__1022000675__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_337.GetRawRoot__O()).Invoke_O__O(xs__3); var nm__6 any = lang.RT_Nth_O_I_O__O(vec__1022000675__5, lang.RT_IntCast_J__I(0), nil); var doc__7 any = lang.RT_Nth_O_I_O__O(vec__1022000675__5, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(doc__7, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__6))) } } }
//line :1588:1
	case 3: if lang.Util_Equiv_O_O__Z(G__1022000674__4_, Lit_56) { var nm__5 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3); var vec__1022000678__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_324.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__3)); var doc__7_2 any = lang.RT_Nth_O_I_O__O(vec__1022000678__6, lang.RT_IntCast_J__I(0), nil); return lang.Tuple_Create_O_O__IPersistentVector(doc__7_2, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__5))) }; case 5: if lang.Util_Equiv_O_O__Z(G__1022000674__4_, Lit_57) {








		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3))) { var tmp4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5.Ref()) } else {

			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_321.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O(), xs__3)) { var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(nil, tmp6.Ref()) } else { var nm__5_2 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3)); var tmp7 *lang.Keyword = A_arbace_g2a_print_code_A_const_114; return lang.Tuple_Create_O_O__IPersistentVector(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__5_2)), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__5_2))) } } }
//line :1588:1
	case 6: if lang.Util_Equiv_O_O__Z(G__1022000674__4_, Lit_58) {








		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_86.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3))) { var tmp8 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3); var tmp9 *lang.PersistentVector; lang.PersistentVector_Init(); tmp9 = lang.PersistentVector_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9.Ref()) } else {

			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_321.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_code_A_const_48.GetRawRoot__O(), xs__3)) { var tmp10 *lang.PersistentVector; lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(nil, tmp10.Ref()) } else { var nm__5_3 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3)); var tmp11 *lang.Keyword = A_arbace_g2a_print_code_A_const_114; return lang.Tuple_Create_O_O__IPersistentVector(tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__5_3)), lang.IFn_Cast(A_arbace_g2a_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__5_3))) } } }
//line :1588:1
	case 7: if lang.Util_Equiv_O_O__Z(G__1022000674__4_, Lit_59) { var nm__5_4 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__3); var vec__1022000681__6 any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_324.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_code_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__3)); var doc__7_3 any = lang.RT_Nth_O_I_O__O(vec__1022000681__6, lang.RT_IntCast_J__I(0), nil); return lang.Tuple_Create_O_O__IPersistentVector(doc__7_3, lang.IFn_Cast(A_arbace_g2a_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__5_4))) }; default:}; var tmp12 *lang.PersistentVector; lang.PersistentVector_Init(); tmp12 = lang.PersistentVector_EMPTY; return lang.Tuple_Create_O_O__IPersistentVector(nil, tmp12.Ref()) }
















func A_arbace_g2a_print_code_top_decl_A_New() *A_arbace_g2a_print_code_top_decl_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_top_decl_A{}; t.Ctor(); return t }
//line :1605:1
func (t *A_arbace_g2a_print_code_top_decl_A) Ctor() {}
//line :1605:1
func (t *A_arbace_g2a_print_code_top_decl_A) Invoke_O_O__O(self, f__0 any) any { var G__1022000685__2_ any = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_33.GetRawRoot__O()).Invoke_O__O(f__0); switch


	lang.Util_Hash_O__I(G__1022000685__2_) >> 9 & 7 { case 2: if lang.Util_Equiv_O_O__Z(G__1022000685__2_, Lit_55) {


		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_339.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1608:1
	case 3: if lang.Util_Equiv_O_O__Z(G__1022000685__2_, Lit_56) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_340.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(f__0, tmp2.Ref()) }
//line :1608:1
	case 5: if lang.Util_Equiv_O_O__Z(G__1022000685__2_, Lit_57) {



		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_341.GetRawRoot__O()).Invoke_O_O__O(f__0, Lit_12) }
//line :1608:1
	case 6: if lang.Util_Equiv_O_O__Z(G__1022000685__2_, Lit_58) {




		return lang.IFn_Cast(A_arbace_g2a_print_code_A_const_341.GetRawRoot__O()).Invoke_O_O__O(f__0, Lit_13) }
//line :1608:1
	case 7: if lang.Util_Equiv_O_O__Z(G__1022000685__2_, Lit_59) {

		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_code_A_const_340.GetRawRoot__O()); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; return tmp3.Invoke_O_O__O(f__0, tmp4.Ref()) }
//line :1608:1
	default:}; return /*line :1614:1*/ lang.IFn_Cast(A_arbace_g2a_print_code_A_const_73.GetRawRoot__O()).Invoke_O_O__O(Lit_187, f__0) }
//line :1613:1
type A_arbace_g2a_print_code_A struct{ jrt.Object }

var A_arbace_g2a_print_code_A_const_pool *jrt.RefArray

var A_arbace_g2a_print_code_A_const_0 *lang.Var

var A_arbace_g2a_print_code_A_const_1 *lang.Var

var A_arbace_g2a_print_code_A_const_2 any

var A_arbace_g2a_print_code_A_const_3 any

var A_arbace_g2a_print_code_A_const_4 any

var A_arbace_g2a_print_code_A_const_5 any

var A_arbace_g2a_print_code_A_const_6 *lang.Var

var A_arbace_g2a_print_code_A_const_7 *lang.Var

var A_arbace_g2a_print_code_A_const_8 *lang.Var

var A_arbace_g2a_print_code_A_const_9 any

var A_arbace_g2a_print_code_A_const_10 *lang.Var

var A_arbace_g2a_print_code_A_const_11 *lang.Var

var A_arbace_g2a_print_code_A_const_12 *lang.Var

var A_arbace_g2a_print_code_A_const_13 *lang.Var

var A_arbace_g2a_print_code_A_const_14 *lang.Keyword

var A_arbace_g2a_print_code_A_const_15 *lang.Var

var A_arbace_g2a_print_code_A_const_16 *lang.Var

var A_arbace_g2a_print_code_A_const_17 *lang.Keyword

var A_arbace_g2a_print_code_A_const_18 *lang.Keyword

var A_arbace_g2a_print_code_A_const_19 *lang.Var

var A_arbace_g2a_print_code_A_const_20 *lang.Var

var A_arbace_g2a_print_code_A_const_21 *lang.Var

var A_arbace_g2a_print_code_A_const_22 *lang.Keyword

var A_arbace_g2a_print_code_A_const_23 *lang.Var

var A_arbace_g2a_print_code_A_const_24 *lang.Var

var A_arbace_g2a_print_code_A_const_25 *lang.Var

var A_arbace_g2a_print_code_A_const_26 *lang.Var

var A_arbace_g2a_print_code_A_const_27 *lang.Var

var A_arbace_g2a_print_code_A_const_28 *lang.Var

var A_arbace_g2a_print_code_A_const_29 any

var A_arbace_g2a_print_code_A_const_30 *lang.Keyword

var A_arbace_g2a_print_code_A_const_31 *lang.Var

var A_arbace_g2a_print_code_A_const_32 *lang.Var

var A_arbace_g2a_print_code_A_const_33 *lang.Var

var A_arbace_g2a_print_code_A_const_34 *lang.Var

var A_arbace_g2a_print_code_A_const_35 *lang.Var

var A_arbace_g2a_print_code_A_const_36 *lang.Var

var A_arbace_g2a_print_code_A_const_37 *lang.Var

var A_arbace_g2a_print_code_A_const_38 *lang.Var

var A_arbace_g2a_print_code_A_const_39 *lang.Var

var A_arbace_g2a_print_code_A_const_40 *lang.Var

var A_arbace_g2a_print_code_A_const_41 *lang.Var

var A_arbace_g2a_print_code_A_const_42 any

var A_arbace_g2a_print_code_A_const_43 any

var A_arbace_g2a_print_code_A_const_44 *lang.Var

var A_arbace_g2a_print_code_A_const_45 *lang.Var

var A_arbace_g2a_print_code_A_const_46 *lang.Var

var A_arbace_g2a_print_code_A_const_47 *lang.Var

var A_arbace_g2a_print_code_A_const_48 *lang.Var

var A_arbace_g2a_print_code_A_const_49 *lang.Keyword

var A_arbace_g2a_print_code_A_const_50 *lang.Var

var A_arbace_g2a_print_code_A_const_51 *lang.Var

var A_arbace_g2a_print_code_A_const_52 *lang.Var

var A_arbace_g2a_print_code_A_const_53 *lang.Var

var A_arbace_g2a_print_code_A_const_54 *lang.Keyword

var A_arbace_g2a_print_code_A_const_55 *lang.Var

var A_arbace_g2a_print_code_A_const_56 *lang.Var

var A_arbace_g2a_print_code_A_const_57 *lang.Keyword

var A_arbace_g2a_print_code_A_const_58 *lang.Var

var A_arbace_g2a_print_code_A_const_59 *lang.Var

var A_arbace_g2a_print_code_A_const_60 *lang.Var

var A_arbace_g2a_print_code_A_const_61 *lang.Var

var A_arbace_g2a_print_code_A_const_62 *lang.Var

var A_arbace_g2a_print_code_A_const_63 *lang.Var

var A_arbace_g2a_print_code_A_const_64 *lang.Var

var A_arbace_g2a_print_code_A_const_65 *lang.Var

var A_arbace_g2a_print_code_A_const_66 *lang.Var

var A_arbace_g2a_print_code_A_const_67 *lang.Var

var A_arbace_g2a_print_code_A_const_68 *lang.Var

var A_arbace_g2a_print_code_A_const_69 *lang.Var

var A_arbace_g2a_print_code_A_const_70 *lang.Var

var A_arbace_g2a_print_code_A_const_71 *lang.Var

var A_arbace_g2a_print_code_A_const_72 *lang.Var

var A_arbace_g2a_print_code_A_const_73 *lang.Var

var A_arbace_g2a_print_code_A_const_74 *lang.Var

var A_arbace_g2a_print_code_A_const_75 *lang.Var

var A_arbace_g2a_print_code_A_const_76 *lang.Var

var A_arbace_g2a_print_code_A_const_77 *lang.Var

var A_arbace_g2a_print_code_A_const_78 *lang.Var

var A_arbace_g2a_print_code_A_const_79 *lang.Var

var A_arbace_g2a_print_code_A_const_80 *lang.Var

var A_arbace_g2a_print_code_A_const_81 *lang.Var

var A_arbace_g2a_print_code_A_const_82 *lang.Keyword

var A_arbace_g2a_print_code_A_const_83 *lang.Keyword

var A_arbace_g2a_print_code_A_const_84 *lang.Var

var A_arbace_g2a_print_code_A_const_85 *lang.Var

var A_arbace_g2a_print_code_A_const_86 *lang.Var

var A_arbace_g2a_print_code_A_const_87 *lang.Var

var A_arbace_g2a_print_code_A_const_88 *lang.Var

var A_arbace_g2a_print_code_A_const_89 *lang.Var

var A_arbace_g2a_print_code_A_const_90 *lang.Var

var A_arbace_g2a_print_code_A_const_91 *lang.Var

var A_arbace_g2a_print_code_A_const_92 *lang.Var

var A_arbace_g2a_print_code_A_const_93 *lang.Var

var A_arbace_g2a_print_code_A_const_94 *lang.Var

var A_arbace_g2a_print_code_A_const_95 *lang.Keyword

var A_arbace_g2a_print_code_A_const_96 *lang.Keyword

var A_arbace_g2a_print_code_A_const_97 *lang.Keyword

var A_arbace_g2a_print_code_A_const_98 *lang.Keyword

var A_arbace_g2a_print_code_A_const_99 *lang.Var

var A_arbace_g2a_print_code_A_const_100 *lang.Var

var A_arbace_g2a_print_code_A_const_101 *lang.Keyword

var A_arbace_g2a_print_code_A_const_102 *lang.Keyword

var A_arbace_g2a_print_code_A_const_103 *lang.Var

var A_arbace_g2a_print_code_A_const_104 *lang.Var

var A_arbace_g2a_print_code_A_const_105 *lang.Var

var A_arbace_g2a_print_code_A_const_106 any

var A_arbace_g2a_print_code_A_const_107 *lang.Keyword

var A_arbace_g2a_print_code_A_const_108 any

var A_arbace_g2a_print_code_A_const_109 *lang.Var

var A_arbace_g2a_print_code_A_const_110 *lang.Keyword

var A_arbace_g2a_print_code_A_const_111 *lang.Keyword

var A_arbace_g2a_print_code_A_const_112 *lang.Keyword

var A_arbace_g2a_print_code_A_const_113 *lang.Keyword

var A_arbace_g2a_print_code_A_const_114 *lang.Keyword

var A_arbace_g2a_print_code_A_const_115 *lang.Keyword

var A_arbace_g2a_print_code_A_const_116 *lang.Var

var A_arbace_g2a_print_code_A_const_117 *lang.Var

var A_arbace_g2a_print_code_A_const_118 *lang.Var

var A_arbace_g2a_print_code_A_const_119 *lang.Var

var A_arbace_g2a_print_code_A_const_120 *lang.Keyword

var A_arbace_g2a_print_code_A_const_121 *lang.Var

var A_arbace_g2a_print_code_A_const_122 *lang.Var

var A_arbace_g2a_print_code_A_const_123 *lang.Var

var A_arbace_g2a_print_code_A_const_124 *lang.Var

var A_arbace_g2a_print_code_A_const_125 *lang.Var

var A_arbace_g2a_print_code_A_const_126 *lang.Var

var A_arbace_g2a_print_code_A_const_127 *lang.Var

var A_arbace_g2a_print_code_A_const_128 *lang.Var

var A_arbace_g2a_print_code_A_const_129 *lang.Var

var A_arbace_g2a_print_code_A_const_130 *lang.Var

var A_arbace_g2a_print_code_A_const_131 *lang.Var

var A_arbace_g2a_print_code_A_const_132 *lang.Var

var A_arbace_g2a_print_code_A_const_133 *lang.Keyword

var A_arbace_g2a_print_code_A_const_134 *lang.Keyword

var A_arbace_g2a_print_code_A_const_135 *lang.Keyword

var A_arbace_g2a_print_code_A_const_136 *lang.Var

var A_arbace_g2a_print_code_A_const_137 *lang.Var

var A_arbace_g2a_print_code_A_const_138 *lang.Var

var A_arbace_g2a_print_code_A_const_139 *lang.Var

var A_arbace_g2a_print_code_A_const_140 any

var A_arbace_g2a_print_code_A_const_141 any

var A_arbace_g2a_print_code_A_const_142 *lang.Var

var A_arbace_g2a_print_code_A_const_143 *lang.Var

var A_arbace_g2a_print_code_A_const_144 *lang.Var

var A_arbace_g2a_print_code_A_const_145 *lang.Var

var A_arbace_g2a_print_code_A_const_146 *lang.Var

var A_arbace_g2a_print_code_A_const_147 *lang.Var

var A_arbace_g2a_print_code_A_const_148 *lang.Var

var A_arbace_g2a_print_code_A_const_149 *lang.Var

var A_arbace_g2a_print_code_A_const_150 *lang.Var

var A_arbace_g2a_print_code_A_const_151 *lang.Var

var A_arbace_g2a_print_code_A_const_152 *lang.Var

var A_arbace_g2a_print_code_A_const_153 *lang.Var

var A_arbace_g2a_print_code_A_const_154 *lang.Var

var A_arbace_g2a_print_code_A_const_155 *lang.Var

var A_arbace_g2a_print_code_A_const_156 *lang.Var

var A_arbace_g2a_print_code_A_const_157 any

var A_arbace_g2a_print_code_A_const_158 *lang.Var

var A_arbace_g2a_print_code_A_const_159 *lang.Keyword

var A_arbace_g2a_print_code_A_const_160 *lang.Var

var A_arbace_g2a_print_code_A_const_161 *lang.Var

var A_arbace_g2a_print_code_A_const_162 *lang.Var

var A_arbace_g2a_print_code_A_const_163 *lang.Var

var A_arbace_g2a_print_code_A_const_164 *lang.Var

var A_arbace_g2a_print_code_A_const_165 *lang.Var

var A_arbace_g2a_print_code_A_const_166 *lang.Var

var A_arbace_g2a_print_code_A_const_167 *lang.Var

var A_arbace_g2a_print_code_A_const_168 *lang.Var

var A_arbace_g2a_print_code_A_const_169 *lang.Var

var A_arbace_g2a_print_code_A_const_170 *lang.Var

var A_arbace_g2a_print_code_A_const_171 *lang.Var

var A_arbace_g2a_print_code_A_const_172 *lang.Var

var A_arbace_g2a_print_code_A_const_173 *lang.Var

var A_arbace_g2a_print_code_A_const_174 *lang.Var

var A_arbace_g2a_print_code_A_const_175 *lang.Var

var A_arbace_g2a_print_code_A_const_176 *lang.Keyword

var A_arbace_g2a_print_code_A_const_177 *lang.Keyword

var A_arbace_g2a_print_code_A_const_178 *lang.Var

var A_arbace_g2a_print_code_A_const_179 *lang.Var

var A_arbace_g2a_print_code_A_const_180 *lang.Var

var A_arbace_g2a_print_code_A_const_181 *lang.Var

var A_arbace_g2a_print_code_A_const_182 *lang.Var

var A_arbace_g2a_print_code_A_const_183 any

var A_arbace_g2a_print_code_A_const_184 *lang.Var

var A_arbace_g2a_print_code_A_const_185 *lang.Var

var A_arbace_g2a_print_code_A_const_186 *lang.Var

var A_arbace_g2a_print_code_A_const_187 *lang.Var

var A_arbace_g2a_print_code_A_const_188 any

var A_arbace_g2a_print_code_A_const_189 *lang.Var

var A_arbace_g2a_print_code_A_const_190 any

var A_arbace_g2a_print_code_A_const_191 *lang.Var

var A_arbace_g2a_print_code_A_const_192 any

var A_arbace_g2a_print_code_A_const_193 any

var A_arbace_g2a_print_code_A_const_194 any

var A_arbace_g2a_print_code_A_const_195 any

var A_arbace_g2a_print_code_A_const_196 any

var A_arbace_g2a_print_code_A_const_197 *lang.Var

var A_arbace_g2a_print_code_A_const_198 any

var A_arbace_g2a_print_code_A_const_199 *lang.Var

var A_arbace_g2a_print_code_A_const_200 *lang.Var

var A_arbace_g2a_print_code_A_const_201 *lang.Var

var A_arbace_g2a_print_code_A_const_202 *lang.Var

var A_arbace_g2a_print_code_A_const_203 *lang.Keyword

var A_arbace_g2a_print_code_A_const_204 *lang.Var

var A_arbace_g2a_print_code_A_const_205 *lang.Var

var A_arbace_g2a_print_code_A_const_206 *lang.Var

var A_arbace_g2a_print_code_A_const_207 *lang.Keyword

var A_arbace_g2a_print_code_A_const_208 *lang.Keyword

var A_arbace_g2a_print_code_A_const_209 *lang.Keyword

var A_arbace_g2a_print_code_A_const_210 *lang.Keyword

var A_arbace_g2a_print_code_A_const_211 *lang.Keyword

var A_arbace_g2a_print_code_A_const_212 *lang.Keyword

var A_arbace_g2a_print_code_A_const_213 any

var A_arbace_g2a_print_code_A_const_214 *lang.Var

var A_arbace_g2a_print_code_A_const_215 any

var A_arbace_g2a_print_code_A_const_216 *lang.Var

var A_arbace_g2a_print_code_A_const_217 any

var A_arbace_g2a_print_code_A_const_218 *lang.Var

var A_arbace_g2a_print_code_A_const_219 *lang.Var

var A_arbace_g2a_print_code_A_const_220 any

var A_arbace_g2a_print_code_A_const_221 any

var A_arbace_g2a_print_code_A_const_222 any

var A_arbace_g2a_print_code_A_const_223 any

var A_arbace_g2a_print_code_A_const_224 any

var A_arbace_g2a_print_code_A_const_225 *lang.Var

var A_arbace_g2a_print_code_A_const_226 *lang.Var

var A_arbace_g2a_print_code_A_const_227 *lang.Keyword

var A_arbace_g2a_print_code_A_const_228 *lang.Keyword

var A_arbace_g2a_print_code_A_const_229 *lang.Keyword

var A_arbace_g2a_print_code_A_const_230 *lang.Var

var A_arbace_g2a_print_code_A_const_231 *lang.Var

var A_arbace_g2a_print_code_A_const_232 *lang.Var

var A_arbace_g2a_print_code_A_const_233 *lang.Var

var A_arbace_g2a_print_code_A_const_234 *lang.Var

var A_arbace_g2a_print_code_A_const_235 *lang.Var

var A_arbace_g2a_print_code_A_const_236 *lang.Var

var A_arbace_g2a_print_code_A_const_237 *lang.Var

var A_arbace_g2a_print_code_A_const_238 *lang.Var

var A_arbace_g2a_print_code_A_const_239 *lang.Var

var A_arbace_g2a_print_code_A_const_240 any

var A_arbace_g2a_print_code_A_const_241 any

var A_arbace_g2a_print_code_A_const_242 any

var A_arbace_g2a_print_code_A_const_243 *lang.Var

var A_arbace_g2a_print_code_A_const_244 *lang.Var

var A_arbace_g2a_print_code_A_const_245 *lang.Var

var A_arbace_g2a_print_code_A_const_246 *lang.Var

var A_arbace_g2a_print_code_A_const_247 *lang.Var

var A_arbace_g2a_print_code_A_const_248 *lang.Var

var A_arbace_g2a_print_code_A_const_249 *lang.Var

var A_arbace_g2a_print_code_A_const_250 *lang.Keyword

var A_arbace_g2a_print_code_A_const_251 *lang.Keyword

var A_arbace_g2a_print_code_A_const_252 *lang.Var

var A_arbace_g2a_print_code_A_const_253 *lang.Var

var A_arbace_g2a_print_code_A_const_254 *lang.Var

var A_arbace_g2a_print_code_A_const_255 *lang.Var

var A_arbace_g2a_print_code_A_const_256 *lang.Keyword

var A_arbace_g2a_print_code_A_const_257 *lang.Var

var A_arbace_g2a_print_code_A_const_258 *lang.Keyword

var A_arbace_g2a_print_code_A_const_259 *lang.Var

var A_arbace_g2a_print_code_A_const_260 *lang.Var

var A_arbace_g2a_print_code_A_const_261 *lang.Var

var A_arbace_g2a_print_code_A_const_262 *lang.Var

var A_arbace_g2a_print_code_A_const_263 any

var A_arbace_g2a_print_code_A_const_264 *lang.Var

var A_arbace_g2a_print_code_A_const_265 any

var A_arbace_g2a_print_code_A_const_266 any

var A_arbace_g2a_print_code_A_const_267 any

var A_arbace_g2a_print_code_A_const_268 *lang.Var

var A_arbace_g2a_print_code_A_const_269 *lang.Var

var A_arbace_g2a_print_code_A_const_270 *lang.Var

var A_arbace_g2a_print_code_A_const_271 *lang.Var

var A_arbace_g2a_print_code_A_const_272 *lang.Var

var A_arbace_g2a_print_code_A_const_273 *lang.Var

var A_arbace_g2a_print_code_A_const_274 *lang.Var

var A_arbace_g2a_print_code_A_const_275 *lang.Var

var A_arbace_g2a_print_code_A_const_276 *lang.Var

var A_arbace_g2a_print_code_A_const_277 *lang.Keyword

var A_arbace_g2a_print_code_A_const_278 *lang.Keyword

var A_arbace_g2a_print_code_A_const_279 *lang.Keyword

var A_arbace_g2a_print_code_A_const_280 *lang.Var

var A_arbace_g2a_print_code_A_const_281 *lang.Var

var A_arbace_g2a_print_code_A_const_282 *lang.Var

var A_arbace_g2a_print_code_A_const_283 *lang.Var

var A_arbace_g2a_print_code_A_const_284 *lang.Var

var A_arbace_g2a_print_code_A_const_285 *lang.Var

var A_arbace_g2a_print_code_A_const_286 *lang.Var

var A_arbace_g2a_print_code_A_const_287 *lang.Var

var A_arbace_g2a_print_code_A_const_288 *lang.Keyword

var A_arbace_g2a_print_code_A_const_289 *lang.Var

var A_arbace_g2a_print_code_A_const_290 *lang.Var

var A_arbace_g2a_print_code_A_const_291 *lang.Var

var A_arbace_g2a_print_code_A_const_292 *lang.Var

var A_arbace_g2a_print_code_A_const_293 *lang.Var

var A_arbace_g2a_print_code_A_const_294 *lang.Var

var A_arbace_g2a_print_code_A_const_295 *lang.Var

var A_arbace_g2a_print_code_A_const_296 *lang.Var

var A_arbace_g2a_print_code_A_const_297 *lang.Var

var A_arbace_g2a_print_code_A_const_298 *lang.Var

var A_arbace_g2a_print_code_A_const_299 any

var A_arbace_g2a_print_code_A_const_300 *lang.Keyword

var A_arbace_g2a_print_code_A_const_301 *lang.Keyword

var A_arbace_g2a_print_code_A_const_302 *lang.Keyword

var A_arbace_g2a_print_code_A_const_303 *lang.Var

var A_arbace_g2a_print_code_A_const_304 any

var A_arbace_g2a_print_code_A_const_305 *lang.Var

var A_arbace_g2a_print_code_A_const_306 *lang.Var

var A_arbace_g2a_print_code_A_const_307 *lang.Keyword

var A_arbace_g2a_print_code_A_const_308 *lang.Keyword

var A_arbace_g2a_print_code_A_const_309 *lang.Keyword

var A_arbace_g2a_print_code_A_const_310 *lang.Var

var A_arbace_g2a_print_code_A_const_311 *lang.Keyword

var A_arbace_g2a_print_code_A_const_312 *lang.Var

var A_arbace_g2a_print_code_A_const_313 *lang.Var

var A_arbace_g2a_print_code_A_const_314 *lang.Var

var A_arbace_g2a_print_code_A_const_315 *lang.Var

var A_arbace_g2a_print_code_A_const_316 *lang.Var

var A_arbace_g2a_print_code_A_const_317 *lang.Var

var A_arbace_g2a_print_code_A_const_318 *lang.Var

var A_arbace_g2a_print_code_A_const_319 *lang.Var

var A_arbace_g2a_print_code_A_const_320 *lang.Var

var A_arbace_g2a_print_code_A_const_321 *lang.Var

var A_arbace_g2a_print_code_A_const_322 *lang.Var

var A_arbace_g2a_print_code_A_const_323 *lang.Var

var A_arbace_g2a_print_code_A_const_324 *lang.Var

var A_arbace_g2a_print_code_A_const_325 *lang.Keyword

var A_arbace_g2a_print_code_A_const_326 *lang.Var

var A_arbace_g2a_print_code_A_const_327 *lang.Var

var A_arbace_g2a_print_code_A_const_328 *lang.Var

var A_arbace_g2a_print_code_A_const_329 *lang.Var

var A_arbace_g2a_print_code_A_const_330 *lang.Var

var A_arbace_g2a_print_code_A_const_331 *lang.Var

var A_arbace_g2a_print_code_A_const_332 *lang.Var

var A_arbace_g2a_print_code_A_const_333 *lang.Var

var A_arbace_g2a_print_code_A_const_334 *lang.Var

var A_arbace_g2a_print_code_A_const_335 *lang.Var

var A_arbace_g2a_print_code_A_const_336 *lang.Var

var A_arbace_g2a_print_code_A_const_337 *lang.Var

var A_arbace_g2a_print_code_A_const_338 *lang.Var

var A_arbace_g2a_print_code_A_const_339 *lang.Var

var A_arbace_g2a_print_code_A_const_340 *lang.Var

var A_arbace_g2a_print_code_A_const_341 *lang.Var

var A_arbace_g2a_print_code_A_init jrt.ClassInit

func A_arbace_g2a_print_code_A_Init() { if !A_arbace_g2a_print_code_A_init.Done() { A_arbace_g2a_print_code_A_init.Run(A_arbace_g2a_print_code_A_clinit) } }

func A_arbace_g2a_print_code_A_clinit() { A_arbace_g2a_print_code_A_clinit_p0(); A_arbace_g2a_print_code_A_clinit_p1(); A_arbace_g2a_print_code_A_clinit_p2(); A_arbace_g2a_print_code_A_clinit_p3(); A_arbace_g2a_print_code_A_clinit_p4(); A_arbace_g2a_print_code_A_clinit_p5(); A_arbace_g2a_print_code_A_clinit_p6(); A_arbace_g2a_print_code_A_clinit_p7(); A_arbace_g2a_print_code_A_clinit_p8(); A_arbace_g2a_print_code_A_clinit_p9(); A_arbace_g2a_print_code_A_clinit_p10(); A_arbace_g2a_print_code_A_clinit_p11(); A_arbace_g2a_print_code_A_clinit_p12(); A_arbace_g2a_print_code_A_clinit_p13(); A_arbace_g2a_print_code_A_clinit_p14(); A_arbace_g2a_print_code_A_clinit_p15(); A_arbace_g2a_print_code_A_clinit_p16(); A_arbace_g2a_print_code_A_clinit_p17(); A_arbace_g2a_print_code_A_clinit_p18(); A_arbace_g2a_print_code_A_clinit_p19(); A_arbace_g2a_print_code_A_clinit_p20(); A_arbace_g2a_print_code_A_clinit_p21(); A_arbace_g2a_print_code_A_clinit_p22(); A_arbace_g2a_print_code_A_clinit_p23(); A_arbace_g2a_print_code_A_clinit_p24(); A_arbace_g2a_print_code_A_clinit_p25(); A_arbace_g2a_print_code_A_clinit_p26(); A_arbace_g2a_print_code_A_clinit_p27(); A_arbace_g2a_print_code_A_clinit_p28() }

func A_arbace_g2a_print_code_A_clinit_p0() { A_arbace_g2a_print_code_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 414); A_arbace_g2a_print_code_A_const_0 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[72]); A_arbace_g2a_print_code_A_const_1 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[73]); A_arbace_g2a_print_code_A_const_2 = A_arbace_g2a_print_code_A_const_pool.A[74]; A_arbace_g2a_print_code_A_const_3 = A_arbace_g2a_print_code_A_const_pool.A[75]; A_arbace_g2a_print_code_A_const_4 = A_arbace_g2a_print_code_A_const_pool.A[76]; A_arbace_g2a_print_code_A_const_5 = A_arbace_g2a_print_code_A_const_pool.A[77]; A_arbace_g2a_print_code_A_const_6 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[78]); A_arbace_g2a_print_code_A_const_7 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[79]); A_arbace_g2a_print_code_A_const_8 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[80]); A_arbace_g2a_print_code_A_const_9 = A_arbace_g2a_print_code_A_const_pool.A[81]; A_arbace_g2a_print_code_A_const_10 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[82]); A_arbace_g2a_print_code_A_const_11 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[83]) }

func A_arbace_g2a_print_code_A_clinit_p1() { A_arbace_g2a_print_code_A_const_12 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[84]); A_arbace_g2a_print_code_A_const_13 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[85]); A_arbace_g2a_print_code_A_const_14 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[86]); A_arbace_g2a_print_code_A_const_15 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[87]); A_arbace_g2a_print_code_A_const_16 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[88]); A_arbace_g2a_print_code_A_const_17 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[89]); A_arbace_g2a_print_code_A_const_18 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[90]); A_arbace_g2a_print_code_A_const_19 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[91]); A_arbace_g2a_print_code_A_const_20 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[92]); A_arbace_g2a_print_code_A_const_21 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[93]); A_arbace_g2a_print_code_A_const_22 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[94]); A_arbace_g2a_print_code_A_const_23 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[95]) }

func A_arbace_g2a_print_code_A_clinit_p2() { A_arbace_g2a_print_code_A_const_24 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[96]); A_arbace_g2a_print_code_A_const_25 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[97]); A_arbace_g2a_print_code_A_const_26 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[98]); A_arbace_g2a_print_code_A_const_27 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[99]); A_arbace_g2a_print_code_A_const_28 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[100]); A_arbace_g2a_print_code_A_const_29 = A_arbace_g2a_print_code_A_const_pool.A[101]; A_arbace_g2a_print_code_A_const_30 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[102]); A_arbace_g2a_print_code_A_const_31 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[103]); A_arbace_g2a_print_code_A_const_32 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[104]); A_arbace_g2a_print_code_A_const_33 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[105]); A_arbace_g2a_print_code_A_const_34 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[106]); A_arbace_g2a_print_code_A_const_35 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[107]) }

func A_arbace_g2a_print_code_A_clinit_p3() { A_arbace_g2a_print_code_A_const_36 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[108]); A_arbace_g2a_print_code_A_const_37 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[109]); A_arbace_g2a_print_code_A_const_38 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[110]); A_arbace_g2a_print_code_A_const_39 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[111]); A_arbace_g2a_print_code_A_const_40 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[112]); A_arbace_g2a_print_code_A_const_41 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[113]); A_arbace_g2a_print_code_A_const_42 = A_arbace_g2a_print_code_A_const_pool.A[114]; A_arbace_g2a_print_code_A_const_43 = A_arbace_g2a_print_code_A_const_pool.A[115]; A_arbace_g2a_print_code_A_const_44 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[116]); A_arbace_g2a_print_code_A_const_45 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[117]); A_arbace_g2a_print_code_A_const_46 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[118]); A_arbace_g2a_print_code_A_const_47 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[119]) }

func A_arbace_g2a_print_code_A_clinit_p4() { A_arbace_g2a_print_code_A_const_48 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[120]); A_arbace_g2a_print_code_A_const_49 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[121]); A_arbace_g2a_print_code_A_const_50 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[122]); A_arbace_g2a_print_code_A_const_51 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[123]); A_arbace_g2a_print_code_A_const_52 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[124]); A_arbace_g2a_print_code_A_const_53 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[125]); A_arbace_g2a_print_code_A_const_54 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[126]); A_arbace_g2a_print_code_A_const_55 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[127]); A_arbace_g2a_print_code_A_const_56 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[128]); A_arbace_g2a_print_code_A_const_57 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[129]); A_arbace_g2a_print_code_A_const_58 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[130]); A_arbace_g2a_print_code_A_const_59 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[131]) }

func A_arbace_g2a_print_code_A_clinit_p5() { A_arbace_g2a_print_code_A_const_60 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[132]); A_arbace_g2a_print_code_A_const_61 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[133]); A_arbace_g2a_print_code_A_const_62 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[134]); A_arbace_g2a_print_code_A_const_63 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[135]); A_arbace_g2a_print_code_A_const_64 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[136]); A_arbace_g2a_print_code_A_const_65 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[137]); A_arbace_g2a_print_code_A_const_66 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[138]); A_arbace_g2a_print_code_A_const_67 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[139]); A_arbace_g2a_print_code_A_const_68 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[140]); A_arbace_g2a_print_code_A_const_69 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[141]); A_arbace_g2a_print_code_A_const_70 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[142]); A_arbace_g2a_print_code_A_const_71 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[143]) }

func A_arbace_g2a_print_code_A_clinit_p6() { A_arbace_g2a_print_code_A_const_72 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[144]); A_arbace_g2a_print_code_A_const_73 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[145]); A_arbace_g2a_print_code_A_const_74 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[146]); A_arbace_g2a_print_code_A_const_75 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[147]); A_arbace_g2a_print_code_A_const_76 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[148]); A_arbace_g2a_print_code_A_const_77 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[149]); A_arbace_g2a_print_code_A_const_78 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[150]); A_arbace_g2a_print_code_A_const_79 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[151]); A_arbace_g2a_print_code_A_const_80 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[152]); A_arbace_g2a_print_code_A_const_81 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[153]); A_arbace_g2a_print_code_A_const_82 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[154]); A_arbace_g2a_print_code_A_const_83 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[155]) }

func A_arbace_g2a_print_code_A_clinit_p7() { A_arbace_g2a_print_code_A_const_84 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[156]); A_arbace_g2a_print_code_A_const_85 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[157]); A_arbace_g2a_print_code_A_const_86 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[158]); A_arbace_g2a_print_code_A_const_87 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[159]); A_arbace_g2a_print_code_A_const_88 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[160]); A_arbace_g2a_print_code_A_const_89 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[161]); A_arbace_g2a_print_code_A_const_90 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[162]); A_arbace_g2a_print_code_A_const_91 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[163]); A_arbace_g2a_print_code_A_const_92 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[164]); A_arbace_g2a_print_code_A_const_93 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[165]); A_arbace_g2a_print_code_A_const_94 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[166]); A_arbace_g2a_print_code_A_const_95 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[167]) }

func A_arbace_g2a_print_code_A_clinit_p8() { A_arbace_g2a_print_code_A_const_96 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[168]); A_arbace_g2a_print_code_A_const_97 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[169]); A_arbace_g2a_print_code_A_const_98 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[170]); A_arbace_g2a_print_code_A_const_99 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[171]); A_arbace_g2a_print_code_A_const_100 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[172]); A_arbace_g2a_print_code_A_const_101 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[173]); A_arbace_g2a_print_code_A_const_102 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[174]); A_arbace_g2a_print_code_A_const_103 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[175]); A_arbace_g2a_print_code_A_const_104 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[176]); A_arbace_g2a_print_code_A_const_105 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[177]); A_arbace_g2a_print_code_A_const_106 = A_arbace_g2a_print_code_A_const_pool.A[178]; A_arbace_g2a_print_code_A_const_107 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[179]) }

func A_arbace_g2a_print_code_A_clinit_p9() { A_arbace_g2a_print_code_A_const_108 = A_arbace_g2a_print_code_A_const_pool.A[180]; A_arbace_g2a_print_code_A_const_109 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[181]); A_arbace_g2a_print_code_A_const_110 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[182]); A_arbace_g2a_print_code_A_const_111 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[183]); A_arbace_g2a_print_code_A_const_112 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[184]); A_arbace_g2a_print_code_A_const_113 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[185]); A_arbace_g2a_print_code_A_const_114 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[186]); A_arbace_g2a_print_code_A_const_115 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[187]); A_arbace_g2a_print_code_A_const_116 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[188]); A_arbace_g2a_print_code_A_const_117 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[189]); A_arbace_g2a_print_code_A_const_118 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[190]); A_arbace_g2a_print_code_A_const_119 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[191]) }

func A_arbace_g2a_print_code_A_clinit_p10() { A_arbace_g2a_print_code_A_const_120 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[192]); A_arbace_g2a_print_code_A_const_121 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[193]); A_arbace_g2a_print_code_A_const_122 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[194]); A_arbace_g2a_print_code_A_const_123 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[195]); A_arbace_g2a_print_code_A_const_124 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[196]); A_arbace_g2a_print_code_A_const_125 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[197]); A_arbace_g2a_print_code_A_const_126 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[198]); A_arbace_g2a_print_code_A_const_127 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[199]); A_arbace_g2a_print_code_A_const_128 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[200]); A_arbace_g2a_print_code_A_const_129 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[201]); A_arbace_g2a_print_code_A_const_130 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[202]); A_arbace_g2a_print_code_A_const_131 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[203]) }

func A_arbace_g2a_print_code_A_clinit_p11() { A_arbace_g2a_print_code_A_const_132 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[204]); A_arbace_g2a_print_code_A_const_133 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[205]); A_arbace_g2a_print_code_A_const_134 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[206]); A_arbace_g2a_print_code_A_const_135 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[207]); A_arbace_g2a_print_code_A_const_136 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[208]); A_arbace_g2a_print_code_A_const_137 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[209]); A_arbace_g2a_print_code_A_const_138 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[210]); A_arbace_g2a_print_code_A_const_139 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[211]); A_arbace_g2a_print_code_A_const_140 = A_arbace_g2a_print_code_A_const_pool.A[212]; A_arbace_g2a_print_code_A_const_141 = A_arbace_g2a_print_code_A_const_pool.A[213]; A_arbace_g2a_print_code_A_const_142 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[214]); A_arbace_g2a_print_code_A_const_143 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[215]) }

func A_arbace_g2a_print_code_A_clinit_p12() { A_arbace_g2a_print_code_A_const_144 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[216]); A_arbace_g2a_print_code_A_const_145 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[217]); A_arbace_g2a_print_code_A_const_146 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[218]); A_arbace_g2a_print_code_A_const_147 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[219]); A_arbace_g2a_print_code_A_const_148 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[220]); A_arbace_g2a_print_code_A_const_149 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[221]); A_arbace_g2a_print_code_A_const_150 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[222]); A_arbace_g2a_print_code_A_const_151 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[223]); A_arbace_g2a_print_code_A_const_152 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[224]); A_arbace_g2a_print_code_A_const_153 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[225]); A_arbace_g2a_print_code_A_const_154 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[226]); A_arbace_g2a_print_code_A_const_155 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[227]) }

func A_arbace_g2a_print_code_A_clinit_p13() { A_arbace_g2a_print_code_A_const_156 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[228]); A_arbace_g2a_print_code_A_const_157 = A_arbace_g2a_print_code_A_const_pool.A[229]; A_arbace_g2a_print_code_A_const_158 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[230]); A_arbace_g2a_print_code_A_const_159 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[231]); A_arbace_g2a_print_code_A_const_160 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[232]); A_arbace_g2a_print_code_A_const_161 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[233]); A_arbace_g2a_print_code_A_const_162 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[234]); A_arbace_g2a_print_code_A_const_163 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[235]); A_arbace_g2a_print_code_A_const_164 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[236]); A_arbace_g2a_print_code_A_const_165 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[237]); A_arbace_g2a_print_code_A_const_166 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[238]); A_arbace_g2a_print_code_A_const_167 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[239]) }

func A_arbace_g2a_print_code_A_clinit_p14() { A_arbace_g2a_print_code_A_const_168 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[240]); A_arbace_g2a_print_code_A_const_169 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[241]); A_arbace_g2a_print_code_A_const_170 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[242]); A_arbace_g2a_print_code_A_const_171 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[243]); A_arbace_g2a_print_code_A_const_172 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[244]); A_arbace_g2a_print_code_A_const_173 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[245]); A_arbace_g2a_print_code_A_const_174 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[246]); A_arbace_g2a_print_code_A_const_175 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[247]); A_arbace_g2a_print_code_A_const_176 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[248]); A_arbace_g2a_print_code_A_const_177 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[249]); A_arbace_g2a_print_code_A_const_178 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[250]); A_arbace_g2a_print_code_A_const_179 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[251]) }

func A_arbace_g2a_print_code_A_clinit_p15() { A_arbace_g2a_print_code_A_const_180 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[252]); A_arbace_g2a_print_code_A_const_181 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[253]); A_arbace_g2a_print_code_A_const_182 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[254]); A_arbace_g2a_print_code_A_const_183 = A_arbace_g2a_print_code_A_const_pool.A[255]; A_arbace_g2a_print_code_A_const_184 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[256]); A_arbace_g2a_print_code_A_const_185 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[257]); A_arbace_g2a_print_code_A_const_186 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[258]); A_arbace_g2a_print_code_A_const_187 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[259]); A_arbace_g2a_print_code_A_const_188 = A_arbace_g2a_print_code_A_const_pool.A[260]; A_arbace_g2a_print_code_A_const_189 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[261]); A_arbace_g2a_print_code_A_const_190 = A_arbace_g2a_print_code_A_const_pool.A[262]; A_arbace_g2a_print_code_A_const_191 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[263]); A_arbace_g2a_print_code_A_const_192 = A_arbace_g2a_print_code_A_const_pool.A[264] }

func A_arbace_g2a_print_code_A_clinit_p16() { A_arbace_g2a_print_code_A_const_193 = A_arbace_g2a_print_code_A_const_pool.A[265]; A_arbace_g2a_print_code_A_const_194 = A_arbace_g2a_print_code_A_const_pool.A[266]; A_arbace_g2a_print_code_A_const_195 = A_arbace_g2a_print_code_A_const_pool.A[267]; A_arbace_g2a_print_code_A_const_196 = A_arbace_g2a_print_code_A_const_pool.A[268]; A_arbace_g2a_print_code_A_const_197 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[269]); A_arbace_g2a_print_code_A_const_198 = A_arbace_g2a_print_code_A_const_pool.A[270]; A_arbace_g2a_print_code_A_const_199 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[271]); A_arbace_g2a_print_code_A_const_200 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[272]); A_arbace_g2a_print_code_A_const_201 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[273]); A_arbace_g2a_print_code_A_const_202 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[274]); A_arbace_g2a_print_code_A_const_203 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[275]); A_arbace_g2a_print_code_A_const_204 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[276]); A_arbace_g2a_print_code_A_const_205 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[277]) }

func A_arbace_g2a_print_code_A_clinit_p17() { A_arbace_g2a_print_code_A_const_206 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[278]); A_arbace_g2a_print_code_A_const_207 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[279]); A_arbace_g2a_print_code_A_const_208 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[280]); A_arbace_g2a_print_code_A_const_209 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[281]); A_arbace_g2a_print_code_A_const_210 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[282]); A_arbace_g2a_print_code_A_const_211 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[283]); A_arbace_g2a_print_code_A_const_212 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[284]); A_arbace_g2a_print_code_A_const_213 = A_arbace_g2a_print_code_A_const_pool.A[285]; A_arbace_g2a_print_code_A_const_214 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[286]); A_arbace_g2a_print_code_A_const_215 = A_arbace_g2a_print_code_A_const_pool.A[287]; A_arbace_g2a_print_code_A_const_216 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[288]); A_arbace_g2a_print_code_A_const_217 = A_arbace_g2a_print_code_A_const_pool.A[289] }

func A_arbace_g2a_print_code_A_clinit_p18() { A_arbace_g2a_print_code_A_const_218 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[290]); A_arbace_g2a_print_code_A_const_219 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[291]); A_arbace_g2a_print_code_A_const_220 = A_arbace_g2a_print_code_A_const_pool.A[292]; A_arbace_g2a_print_code_A_const_221 = A_arbace_g2a_print_code_A_const_pool.A[293]; A_arbace_g2a_print_code_A_const_222 = A_arbace_g2a_print_code_A_const_pool.A[294]; A_arbace_g2a_print_code_A_const_223 = A_arbace_g2a_print_code_A_const_pool.A[295]; A_arbace_g2a_print_code_A_const_224 = A_arbace_g2a_print_code_A_const_pool.A[296]; A_arbace_g2a_print_code_A_const_225 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[297]); A_arbace_g2a_print_code_A_const_226 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[298]); A_arbace_g2a_print_code_A_const_227 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[299]); A_arbace_g2a_print_code_A_const_228 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[300]); A_arbace_g2a_print_code_A_const_229 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[301]); A_arbace_g2a_print_code_A_const_230 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[302]) }

func A_arbace_g2a_print_code_A_clinit_p19() { A_arbace_g2a_print_code_A_const_231 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[303]); A_arbace_g2a_print_code_A_const_232 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[304]); A_arbace_g2a_print_code_A_const_233 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[305]); A_arbace_g2a_print_code_A_const_234 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[306]); A_arbace_g2a_print_code_A_const_235 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[307]); A_arbace_g2a_print_code_A_const_236 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[308]); A_arbace_g2a_print_code_A_const_237 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[309]); A_arbace_g2a_print_code_A_const_238 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[310]); A_arbace_g2a_print_code_A_const_239 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[311]); A_arbace_g2a_print_code_A_const_240 = A_arbace_g2a_print_code_A_const_pool.A[312]; A_arbace_g2a_print_code_A_const_241 = A_arbace_g2a_print_code_A_const_pool.A[313]; A_arbace_g2a_print_code_A_const_242 = A_arbace_g2a_print_code_A_const_pool.A[314] }

func A_arbace_g2a_print_code_A_clinit_p20() { A_arbace_g2a_print_code_A_const_243 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[315]); A_arbace_g2a_print_code_A_const_244 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[316]); A_arbace_g2a_print_code_A_const_245 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[317]); A_arbace_g2a_print_code_A_const_246 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[318]); A_arbace_g2a_print_code_A_const_247 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[319]); A_arbace_g2a_print_code_A_const_248 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[320]); A_arbace_g2a_print_code_A_const_249 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[321]); A_arbace_g2a_print_code_A_const_250 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[322]); A_arbace_g2a_print_code_A_const_251 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[323]); A_arbace_g2a_print_code_A_const_252 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[324]); A_arbace_g2a_print_code_A_const_253 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[325]); A_arbace_g2a_print_code_A_const_254 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[326]) }

func A_arbace_g2a_print_code_A_clinit_p21() { A_arbace_g2a_print_code_A_const_255 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[327]); A_arbace_g2a_print_code_A_const_256 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[328]); A_arbace_g2a_print_code_A_const_257 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[329]); A_arbace_g2a_print_code_A_const_258 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[330]); A_arbace_g2a_print_code_A_const_259 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[331]); A_arbace_g2a_print_code_A_const_260 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[332]); A_arbace_g2a_print_code_A_const_261 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[333]); A_arbace_g2a_print_code_A_const_262 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[334]); A_arbace_g2a_print_code_A_const_263 = A_arbace_g2a_print_code_A_const_pool.A[335]; A_arbace_g2a_print_code_A_const_264 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[336]); A_arbace_g2a_print_code_A_const_265 = A_arbace_g2a_print_code_A_const_pool.A[337]; A_arbace_g2a_print_code_A_const_266 = A_arbace_g2a_print_code_A_const_pool.A[338]; A_arbace_g2a_print_code_A_const_267 = A_arbace_g2a_print_code_A_const_pool.A[339] }

func A_arbace_g2a_print_code_A_clinit_p22() { A_arbace_g2a_print_code_A_const_268 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[340]); A_arbace_g2a_print_code_A_const_269 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[341]); A_arbace_g2a_print_code_A_const_270 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[342]); A_arbace_g2a_print_code_A_const_271 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[343]); A_arbace_g2a_print_code_A_const_272 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[344]); A_arbace_g2a_print_code_A_const_273 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[345]); A_arbace_g2a_print_code_A_const_274 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[346]); A_arbace_g2a_print_code_A_const_275 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[347]); A_arbace_g2a_print_code_A_const_276 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[348]); A_arbace_g2a_print_code_A_const_277 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[349]); A_arbace_g2a_print_code_A_const_278 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[350]); A_arbace_g2a_print_code_A_const_279 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[351]) }

func A_arbace_g2a_print_code_A_clinit_p23() { A_arbace_g2a_print_code_A_const_280 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[352]); A_arbace_g2a_print_code_A_const_281 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[353]); A_arbace_g2a_print_code_A_const_282 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[354]); A_arbace_g2a_print_code_A_const_283 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[355]); A_arbace_g2a_print_code_A_const_284 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[356]); A_arbace_g2a_print_code_A_const_285 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[357]); A_arbace_g2a_print_code_A_const_286 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[358]); A_arbace_g2a_print_code_A_const_287 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[359]); A_arbace_g2a_print_code_A_const_288 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[360]); A_arbace_g2a_print_code_A_const_289 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[361]); A_arbace_g2a_print_code_A_const_290 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[362]); A_arbace_g2a_print_code_A_const_291 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[363]) }

func A_arbace_g2a_print_code_A_clinit_p24() { A_arbace_g2a_print_code_A_const_292 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[364]); A_arbace_g2a_print_code_A_const_293 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[365]); A_arbace_g2a_print_code_A_const_294 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[366]); A_arbace_g2a_print_code_A_const_295 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[367]); A_arbace_g2a_print_code_A_const_296 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[368]); A_arbace_g2a_print_code_A_const_297 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[369]); A_arbace_g2a_print_code_A_const_298 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[370]); A_arbace_g2a_print_code_A_const_299 = A_arbace_g2a_print_code_A_const_pool.A[371]; A_arbace_g2a_print_code_A_const_300 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[372]); A_arbace_g2a_print_code_A_const_301 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[373]); A_arbace_g2a_print_code_A_const_302 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[374]); A_arbace_g2a_print_code_A_const_303 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[375]) }

func A_arbace_g2a_print_code_A_clinit_p25() { A_arbace_g2a_print_code_A_const_304 = A_arbace_g2a_print_code_A_const_pool.A[376]; A_arbace_g2a_print_code_A_const_305 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[377]); A_arbace_g2a_print_code_A_const_306 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[378]); A_arbace_g2a_print_code_A_const_307 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[379]); A_arbace_g2a_print_code_A_const_308 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[380]); A_arbace_g2a_print_code_A_const_309 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[381]); A_arbace_g2a_print_code_A_const_310 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[382]); A_arbace_g2a_print_code_A_const_311 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[383]); A_arbace_g2a_print_code_A_const_312 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[384]); A_arbace_g2a_print_code_A_const_313 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[385]); A_arbace_g2a_print_code_A_const_314 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[386]); A_arbace_g2a_print_code_A_const_315 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[387]) }

func A_arbace_g2a_print_code_A_clinit_p26() { A_arbace_g2a_print_code_A_const_316 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[388]); A_arbace_g2a_print_code_A_const_317 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[389]); A_arbace_g2a_print_code_A_const_318 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[390]); A_arbace_g2a_print_code_A_const_319 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[391]); A_arbace_g2a_print_code_A_const_320 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[392]); A_arbace_g2a_print_code_A_const_321 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[393]); A_arbace_g2a_print_code_A_const_322 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[394]); A_arbace_g2a_print_code_A_const_323 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[395]); A_arbace_g2a_print_code_A_const_324 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[396]); A_arbace_g2a_print_code_A_const_325 = lang.Keyword_Cast(A_arbace_g2a_print_code_A_const_pool.A[397]); A_arbace_g2a_print_code_A_const_326 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[398]); A_arbace_g2a_print_code_A_const_327 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[399]) }

func A_arbace_g2a_print_code_A_clinit_p27() { A_arbace_g2a_print_code_A_const_328 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[400]); A_arbace_g2a_print_code_A_const_329 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[401]); A_arbace_g2a_print_code_A_const_330 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[402]); A_arbace_g2a_print_code_A_const_331 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[403]); A_arbace_g2a_print_code_A_const_332 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[404]); A_arbace_g2a_print_code_A_const_333 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[405]); A_arbace_g2a_print_code_A_const_334 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[406]); A_arbace_g2a_print_code_A_const_335 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[407]); A_arbace_g2a_print_code_A_const_336 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[408]); A_arbace_g2a_print_code_A_const_337 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[409]); A_arbace_g2a_print_code_A_const_338 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[410]); A_arbace_g2a_print_code_A_const_339 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[411]) }

func A_arbace_g2a_print_code_A_clinit_p28() { A_arbace_g2a_print_code_A_const_340 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[412]); A_arbace_g2a_print_code_A_const_341 = lang.Var_Cast(A_arbace_g2a_print_code_A_const_pool.A[413]) }

func A_arbace_g2a_print_code_A_New() *A_arbace_g2a_print_code_A { A_arbace_g2a_print_code_A_Init(); t := &A_arbace_g2a_print_code_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_code_A) Ctor() {}

func (t *A_arbace_g2a_print_code_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_code_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_code_A_class }

func (t *A_arbace_g2a_print_code_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_code_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_code_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_code_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_code_A); return ok }

func A_arbace_g2a_print_code_A_Cast(x any) *A_arbace_g2a_print_code_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_code_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_code_A_class)) }; return v }



type A_arbace_g2a_print_code_args_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_args_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_assign_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_assign_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_bin_op_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_bin_op_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_bin_prec_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_bin_prec_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binary_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_binary_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binary_expr_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_binary_expr_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binary_expr_fn__1022000253_A struct{ a2g_header uint64; F_f, F_depth any }

var A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binary_expr_fn__1022000255_A struct{ a2g_header uint64; F_depth any }

var A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_bind_target_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_bind_target_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binding_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_binding_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A struct{ a2g_header uint64; F_depth int64 }

var A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_binding_stmt_names__1022000371_A struct{ a2g_header uint64; F_ts any }

var A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_block_body_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_block_body_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_block_body_fn__1022000557_A struct{ a2g_header uint64; F_start any }

var A_arbace_g2a_print_code_block_body_fn__1022000557_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_block_body_fn__1022000559_A struct{ a2g_header uint64; F_forms, F_results_QMARK_, F_indent any }

var A_arbace_g2a_print_code_block_body_fn__1022000559_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_body_offset_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_body_offset_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_branch_forms_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_branch_forms_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_branch_opts_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_branch_opts_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_break_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_break_line_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_break_line_fn__1022000035_A struct{ a2g_header uint64; F_i any }

var A_arbace_g2a_print_code_break_line_fn__1022000035_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_breaks_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_breaks_of_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_breaks_of_fn__1022000031_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_call_args_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_call_args_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_call_args_fn__1022000258_A struct{ a2g_header uint64; F_depth any }

var A_arbace_g2a_print_code_call_args_fn__1022000258_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_callee_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_callee_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_case_exprs_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_case_exprs_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_case_exprs_fn__1022000446_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_case_types_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_case_types_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_case_types_fn__1022000450_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_case_types_fn__1022000450_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_chan_type_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_chan_type_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_child_target_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_child_target_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_clause_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_clause_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_clause_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_clause_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_clause_list_fn__1022000439_A struct{ a2g_header uint64; F_i int64; F_indent, F_print_head, F_c any }

var A_arbace_g2a_print_code_clause_list_fn__1022000439_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_comm_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_comm_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_comma_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_comma_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_comma_list_fn__1022000043_A struct{ a2g_header uint64; F_parent, F_offset any }

var A_arbace_g2a_print_code_comma_list_fn__1022000043_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_comma_list_fn__1022000045_A struct{ a2g_header uint64; F_i int64; F_print_one, F_xs any }

var A_arbace_g2a_print_code_comma_list_fn__1022000045_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_composite_lit_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_composite_lit_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_composite_lit_fn__1022000265_A struct{ a2g_header uint64; F_f, F_t any }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A struct{ a2g_header uint64; F_f, F_brk any }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A struct{ a2g_header uint64; F_start any }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A struct{ a2g_header uint64; F_n int32; F_el, F_multi_QMARK_ any }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A struct{ a2g_header uint64; F_n int32; F_el, F_multi_QMARK_ any }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_bind_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_bind_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_group_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_group_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_group_fn__1022000538_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_group_fn__1022000538_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_group_fn__1022000543_A struct{ a2g_header uint64; F_keep any; F_j int64; F_its, F_indent, F_specs any }

var A_arbace_g2a_print_code_const_group_fn__1022000543_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_spec_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_spec_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_spec_fn__1022000534_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_spec_fn__1022000534_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_var_decl_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_var_decl_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A struct{ a2g_header uint64; F_specs any; F_group_QMARK_ bool; F_keep any }

var A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_control_clause_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_control_clause_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_cutoff_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_cutoff_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_cutoff_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_cutoff_of_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_decl_doc_and_directives_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_decl_doc_and_directives_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_diff_prec_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_diff_prec_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_directives_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_directives_of_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_directives_of_fn__1022000124_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_directives_of_fn__1022000124_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A struct{ a2g_header uint64; F_s__1022000105, F_iter__1022000104 any }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A struct{ a2g_header uint64; F_k any }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A struct{ a2g_header uint64; F_k, F_s__1022000107, F_iter__1022000106 any }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A struct{ a2g_header uint64; F_b__1022000109, F_k any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_doc_lines_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_doc_lines_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_element_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_element_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_element_list_fn__1022000068_A struct{ a2g_header uint64; F_parent, F_target, F_offset, F_brk any }

var A_arbace_g2a_print_code_element_list_fn__1022000068_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_element_list_fn__1022000070_A struct{ a2g_header uint64; F_x, F_print_one any; F_i int64 }

var A_arbace_g2a_print_code_element_list_fn__1022000070_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_else_part_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_else_part_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_eval1022000004_A struct{ jrt.Object }

func A_arbace_g2a_print_code_eval1022000004_A_New() *A_arbace_g2a_print_code_eval1022000004_A { t := &A_arbace_g2a_print_code_eval1022000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_code_eval1022000004_A) Ctor() {}

func (t *A_arbace_g2a_print_code_eval1022000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_code_eval1022000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_code_eval1022000004_A_class }

func (t *A_arbace_g2a_print_code_eval1022000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_code_eval1022000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_code_eval1022000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_code_eval1022000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_code_eval1022000004_A); return ok }

func A_arbace_g2a_print_code_eval1022000004_A_Cast(x any) *A_arbace_g2a_print_code_eval1022000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_code_eval1022000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_code_eval1022000004_A_class)) }; return v }



type A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_eval1022000008_A struct{ jrt.Object }

func A_arbace_g2a_print_code_eval1022000008_A_New() *A_arbace_g2a_print_code_eval1022000008_A { t := &A_arbace_g2a_print_code_eval1022000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_code_eval1022000008_A) Ctor() {}

func (t *A_arbace_g2a_print_code_eval1022000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_code_eval1022000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_code_eval1022000008_A_class }

func (t *A_arbace_g2a_print_code_eval1022000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_code_eval1022000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_code_eval1022000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_code_eval1022000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_code_eval1022000008_A); return ok }

func A_arbace_g2a_print_code_eval1022000008_A_Cast(x any) *A_arbace_g2a_print_code_eval1022000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_code_eval1022000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_code_eval1022000008_A_class)) }; return v }



type A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr0_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_expr0_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr1_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_expr1_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr1_fn__1022000315_A struct{ a2g_header uint64; F_f any }

var A_arbace_g2a_print_code_expr1_fn__1022000315_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr1_fn__1022000317_A struct{ a2g_header uint64; F_x any }

var A_arbace_g2a_print_code_expr1_fn__1022000317_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr1_fn__1022000332_A struct{ a2g_header uint64; F_depth any }

var A_arbace_g2a_print_code_expr1_fn__1022000332_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr1_fn__1022000337_A struct{ a2g_header uint64; F_depth any }

var A_arbace_g2a_print_code_expr1_fn__1022000337_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr1_fn__1022000345_A struct{ a2g_header uint64; F_i, F_depth any }

var A_arbace_g2a_print_code_expr1_fn__1022000345_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr1_fn__1022000350_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_expr1_fn__1022000350_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_expr_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expr_list_fn__1022000361_A struct{ a2g_header uint64; F_depth any }

var A_arbace_g2a_print_code_expr_list_fn__1022000361_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_expression_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_expression_form_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_fail_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_fail_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_body_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_field_body_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_field_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_fn__1022000164_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_field_list_fn__1022000164_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_fn__1022000166_A struct{ a2g_header uint64; F_start any }

var A_arbace_g2a_print_code_field_list_fn__1022000166_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_fn__1022000168_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_field_list_fn__1022000168_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_fn__1022000180_A struct{ a2g_header uint64; F_indent, F_t, F_struct_QMARK_, F_doc, F_last_start, F_pre, F_sep, F_g any; F_i int64 }

var A_arbace_g2a_print_code_field_list_fn__1022000180_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A struct{ a2g_header uint64; F_s__1022000155, F_iter__1022000154 any }

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_b__1022000157, F_c__1927001037__auto__ any }

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_flatten_stmts_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_flatten_stmts_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A struct{ a2g_header uint64; F_parent any; F_n int32; F_offset, F_brk any }

var A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A struct{ a2g_header uint64; F_f any }

var A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_for_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_for_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_func_decl_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_func_decl_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_func_lit_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_func_lit_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_func_type_sig_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_func_type_sig_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_generic_type_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_generic_type_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_go_sym_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_go_sym_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_consts_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_group_consts_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_consts_fn__1022000525_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_group_consts_fn__1022000525_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_decl_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_group_decl_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_decl_fn__1022000627_A struct{ a2g_header uint64; F_t, F_last_start, F_pre any; F_i int64 }

var A_arbace_g2a_print_code_group_decl_fn__1022000627_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_entries_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_group_entries_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_entries_fn__1022000077_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_group_entries_fn__1022000077_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_entries_fn__1022000079_A struct{ a2g_header uint64; F_explicit_QMARK_ any }

var A_arbace_g2a_print_code_group_entries_fn__1022000079_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_group_line_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_group_target_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_group_target_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_groupable_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_groupable_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_ident_string_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_ident_string_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_if_like_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_if_like_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_if_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_if_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_iface_method_sig_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_iface_method_sig_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_interface_method_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_interface_method_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_item_t_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_item_t_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_keep_type_column_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_keep_type_column_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_key_size_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_key_size_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_label_name_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_label_name_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_label_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_label_of_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_label_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_label_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_line_indent_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_line_indent_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_line_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_line_of_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_lit_elements_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_lit_elements_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_literal_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_literal_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_n_values_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_n_values_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_name_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_name_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_negative_literal_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_negative_literal_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_new_arg_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_new_arg_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_next_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_next_line_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_next_targets_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_next_targets_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_one_line_fields_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_one_line_fields_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A struct{ a2g_header uint64; F_g, F_x, F_method_QMARK_ any }

var A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_op_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_op_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_param_entries_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_param_entries_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_param_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_param_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_param_list_fn__1022000087_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_param_list_fn__1022000087_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_paren_operand_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_paren_operand_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_paren_operand_fn__1022000249_A struct{ a2g_header uint64; F_x any }

var A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_parse_decl_head_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_parse_decl_head_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_parse_type_spec_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_parse_type_spec_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_pre_lines_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_pre_lines_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_prec_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_prec_of_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_print_results_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_print_results_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_print_results_fn__1022000091_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_print_results_fn__1022000091_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_print_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_print_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_print_stmt_fn__1022000500_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_range_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_range_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_range_stmt_fn__1022000493_A struct{ a2g_header uint64; F_assign_QMARK_, F_v any }

var A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_reduce_depth_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_reduce_depth_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_results_entries_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_results_entries_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_room_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_room_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_select_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_select_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_signature_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_signature_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_simple_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_simple_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_slice_expr_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_slice_expr_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_slice_expr_fn__1022000292_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_slice_expr_fn__1022000294_A struct{ a2g_header uint64; F_depth, F_idx, F_blanks_QMARK_ any }

var A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_spec_name_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_spec_name_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_spec_t_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_spec_t_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_statement_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_statement_form_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_stmt_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_stmt_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_stmt_list_fn__1022000550_A struct{ a2g_header uint64; F_n int32; F_results_QMARK_, F_indent any; F_i int64; F_it any }

var A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_stmt_list_one_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_stmt_list_one_line_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_struct_fields_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_struct_fields_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A struct{ a2g_header uint64; F_s__1022000142, F_iter__1022000141 any }

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A struct{ a2g_header uint64; F_b__1022000144 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_struct_tag_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_struct_tag_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_switch_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_switch_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A struct{ a2g_header uint64; F_init, F_tag any }

var A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_tagged_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_tagged_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_targets_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_targets_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_top_decl_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_top_decl_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_binding_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_binding_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_decl_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_decl_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_decl_fn__1022000663_A struct{ a2g_header uint64; F_gxs any }

var A_arbace_g2a_print_code_type_decl_fn__1022000663_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_decl_fn__1022000668_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_decl_fn__1022000668_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_expr_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_expr_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_expr_fn__1022000198_A struct{ a2g_header uint64; F_n any }

var A_arbace_g2a_print_code_type_expr_fn__1022000198_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_form_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_list_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_list_fn__1022000188_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_list_fn__1022000188_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_params_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_params_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_params_fn__1022000216_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_params_fn__1022000216_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_spec_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_spec_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_switch_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_type_switch_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A struct{ a2g_header uint64; F_init, F_guard any }

var A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_unary_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_unary_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_unary_op_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_unary_op_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_unary_operand_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_unary_operand_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_uses_grouped_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_uses_grouped_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_value_spec_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_value_spec_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_value_spec_fn__1022000589_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_value_spec_fn__1022000589_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_variadic_elem_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_variadic_elem_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_walk_binary_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_walk_binary_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_walk_prefixes_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_walk_prefixes_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_walk_right_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_walk_right_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_while_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_while_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_while_stmt_fn__1022000486_A struct{ a2g_header uint64; F_c any }

var A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_write_doc_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_write_doc_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_write_pre_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_write_pre_A_fn_class *jrt.Class



type A_arbace_g2a_print_code_zero_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_code_zero_form_QMARK__A_fn_class *jrt.Class
