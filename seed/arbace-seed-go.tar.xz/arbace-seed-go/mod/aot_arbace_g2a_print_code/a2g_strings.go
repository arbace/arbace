//line a2g_strings.ae:1
package aot_arbace_g2a_print_code

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn21,arbace.g2a.print-emitkn2,asyn1,ekn5,referyn3,tokyn2,spyn4,vtabyn21,arbace.g2a.print-textyn4,textyn13,arbace.stringyn3,strkn3,docks2,go7,groupedkn4,linekn6,columnkn4,formkn4,elsekn6,lines?ks2,go6,breakskn5,breakkn3,srckn5,nameskn6,parentkn6,offsetkn3,endkn6,targetkn4,hereks2,go3,endkn3,tagyn1,&kn4,namekn4,typekn9,variadic?kn4,metaks2,go3,tagkn7,entrieskn3,bolkn6,indentkn10,cur-indentkn7,resultskn4,recvkn4,sendyn3,...yn3,anyks2,go5,parenkn4,kindkn5,fieldkn3,keykn5,valuekn1,ikn3,posyn1,_kn8,results?kn5,func?kn3,sepkn5,constkn3,varkn11,type-paramskn5,aliaskn4,nextkn13,else-follows?kn11,else-block?kn6,assignkn4,bindkn1,tkn9,type-bindkn11,const-groupks2,go5,labelks2,go8,implicitks21,arbace.g2a.print-code4,noneks2,go10,label-linekn6,externv11,arbace.core7,requirev11,arbace.core5,referR0,V5,R1,R2,R3,R4,V3,R5,R6,R7,V3,R8,R2,R9,V3,R10,R2,R11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn21,arbace.g2a.print-codem2,R12,s581,g2a's printer, the forms level (doc/go/PRINTER-NOTES.md): Go forms (doc/go/SPEC.md) to Go\n  tokens through arbace.g2a.print-emit. Types (§5), declarations (§6), statements and\n  expressions (§7), literals (§8), directives and doc comments (§9, §10.4), files (§4.3).\n\n  Every form is classified by its head and position (§4.4); nothing is resolved. Spacing\n  follows go/printer (go1.27.1 src/go/printer/nodes.go: binaryExpr, cutoff, walkBinary,\n  the depth rules of exprList, controlClause, funcBody, fieldList, valueSpec, keepTypeColumn)\n  so that gofmt leaves the output as it is.v11,arbace.core13,*loaded-libs*v11,arbace.core9,contains?v11,arbace.core4,somev11,arbace.core5,coll?R13,v11,arbace.core4,valsv11,arbace.core6,dissocR14,R15,v11,arbace.core4,map?v11,arbace.core7,ex-infov11,arbace.core6,pr-strR16,v11,arbace.core4,seq?v11,arbace.core5,firstv11,arbace.core7,symbol?v11,arbace.core9,namespacev11,arbace.core4,namev21,arbace.g2a.print-code7,*go-ns*S2,s12,clojure.cores11,arbace.coreR17,v11,arbace.core4,restv21,arbace.g2a.print-code10,binary-opsv21,arbace.g2a.print-code2,opv11,arbace.core7,number?v21,arbace.g2a.print-text16,negative-number?v21,arbace.g2a.print-code17,negative-literal?v21,arbace.g2a.print-code9,unary-opsv11,arbace.core6,secondv21,arbace.g2a.print-code7,binary?v21,arbace.g2a.print-code8,bin-precv21,arbace.g2a.print-code6,unary?l6,l7,v21,arbace.g2a.print-code10,stmt-headsv11,arbace.core3,notv21,arbace.g2a.print-code15,statement-form?v11,arbace.core8,keyword?v11,arbace.core7,vector?R18,v21,arbace.g2a.print-emit3,*p*v11,arbace.core8,integer?v11,arbace.core3,setv11,arbace.core3,mapR19,v21,arbace.g2a.print-code7,line-ofv21,arbace.g2a.print-code10,break-lineR20,v21,arbace.g2a.print-code9,breaks-ofv21,arbace.g2a.print-code12,child-targetv11,arbace.core3,vecv21,arbace.g2a.print-emit5,room?v21,arbace.g2a.print-emit6,*next*v11,arbace.core4,mapvv11,arbace.core5,rangev21,arbace.g2a.print-emit9,break-to!v11,arbace.core19,pop-thread-bindingsv21,arbace.g2a.print-emit3,tokv21,arbace.g2a.print-emit2,spv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv21,arbace.g2a.print-code7,go-sym?v11,arbace.core3,strv21,arbace.g2a.print-code4,failv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core11,map-indexedv11,arbace.core6,vectorv21,arbace.g2a.print-code12,ident-stringv11,arbace.core10,chunk-restv11,arbace.core4,nextR21,R22,v11,arbace.core5,true?v11,arbace.core6,false?v11,arbace.core7,string?v13,arbace.string9,includes?v21,arbace.g2a.print-text14,raw-string-ok?v21,arbace.g2a.print-emit7,raw-tokv11,arbace.core5,char?v21,arbace.g2a.print-text9,go-stringv21,arbace.g2a.print-text7,go-runev21,arbace.g2a.print-text9,go-numberv11,arbace.core8,to-arrayR23,R24,R25,R26,v21,arbace.g2a.print-code12,next-targetsv21,arbace.g2a.print-emit9,pop-open!R27,R28,v11,arbace.core4,peekv21,arbace.g2a.print-emit10,push-open!v21,arbace.g2a.print-emit12,close-break!l1,R29,R30,v21,arbace.g2a.print-code7,tagged?R31,R32,R33,R34,R12,R35,v21,arbace.g2a.print-code17,*explicit-groups*v21,arbace.g2a.print-code9,*generic*v11,arbace.core6,reducev21,arbace.g2a.print-code10,groupable?R36,v11,arbace.core3,popv11,arbace.core6,updatev11,arbace.core5,assocv21,arbace.g2a.print-code13,group-entriesv21,arbace.g2a.print-code12,element-listv21,arbace.g2a.print-code13,param-entriesv21,arbace.g2a.print-code9,type-exprv21,arbace.g2a.print-code9,name-listv21,arbace.g2a.print-code13,variadic-elemv21,arbace.g2a.print-code10,group-linev11,arbace.core6,empty?v21,arbace.g2a.print-code10,param-listR37,R38,R39,v21,arbace.g2a.print-code13,print-resultsv21,arbace.g2a.print-code9,next-linev21,arbace.g2a.print-code9,signaturev13,arbace.string5,splitp2,\\nl-1,v11,arbace.core4,not=v21,arbace.g2a.print-code9,doc-linesv21,arbace.g2a.print-emit12,comment-linev13,arbace.string12,starts-with?v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core6,concatv11,arbace.core7,sort-byv11,arbace.core4,compv11,arbace.core6,filterv11,arbace.core3,keyv21,arbace.g2a.print-code18,non-directive-keysl0,v21,arbace.g2a.print-code9,write-docR40,v21,arbace.g2a.print-code15,results-entriesv21,arbace.g2a.print-code17,interface-method?v21,arbace.g2a.print-emit6,renderv21,arbace.g2a.print-code16,iface-method-sigv11,arbace.core5,nnextv21,arbace.g2a.print-code10,struct-tagv21,arbace.g2a.print-emit4,vtabv21,arbace.g2a.print-code13,struct-fieldsv21,arbace.g2a.print-code16,one-line-fields?v11,arbace.core9,volatile!v21,arbace.g2a.print-code10,field-bodyv21,arbace.g2a.print-emit2,nlv21,arbace.g2a.print-code9,pre-linesv21,arbace.g2a.print-emit11,stmt-break!v11,arbace.core7,vreset!v11,arbace.core6,subvecR41,R42,v21,arbace.g2a.print-code10,field-listv21,arbace.g2a.print-code9,type-listv21,arbace.g2a.print-code13,func-type-sigv21,arbace.g2a.print-code4,argsv21,arbace.g2a.print-code9,chan-typeR43,v21,arbace.g2a.print-code5,expr0v21,arbace.g2a.print-code8,*header*v21,arbace.g2a.print-code10,type-headsv21,arbace.g2a.print-code26,begins-with-star-or-paren?R44,v21,arbace.g2a.print-code11,walk-binaryV3,FFl0,v21,arbace.g2a.print-code8,unary-opV3,FFl0,l5,S3,s2,&&s2,/*s2,&^S2,s2,++s2,--l4,v21,arbace.g2a.print-code6,bin-opV3,FFl0,v21,arbace.g2a.print-code10,walk-rightv21,arbace.g2a.print-code13,walk-prefixesv21,arbace.g2a.print-code9,cutoff-ofv21,arbace.g2a.print-code12,reduce-depthR45,v21,arbace.g2a.print-code13,paren-operandv21,arbace.g2a.print-code5,expr1v21,arbace.g2a.print-code9,diff-precR46,R47,R48,R49,R50,R51,l10,v21,arbace.g2a.print-code22,lit-type-needs-parens?R52,v21,arbace.g2a.print-code12,lit-elementsR52,v11,arbace.core4,intov11,arbace.core6,repeatR52,R52,R52,R52,R52,v21,arbace.g2a.print-code11,line-indentv21,arbace.g2a.print-code10,block-bodyR53,R54,R55,v21,arbace.g2a.print-code11,body-offsetv21,arbace.g2a.print-code10,type-form?v21,arbace.g2a.print-code11,binary-exprv21,arbace.g2a.print-code13,unary-operandv21,arbace.g2a.print-code7,prec-ofv21,arbace.g2a.print-code7,literalv21,arbace.g2a.print-code8,func-litv21,arbace.g2a.print-code10,slice-exprv21,arbace.g2a.print-code9,call-argsv21,arbace.g2a.print-code6,cutoffS3,s4,funcs4,chans1,*l2,S3,s4,funcs4,chans1,*v21,arbace.g2a.print-code13,composite-litv21,arbace.g2a.print-code7,new-argv21,arbace.g2a.print-text14,go-byte-stringv11,arbace.core4,subsv21,arbace.g2a.print-code6,calleev21,arbace.g2a.print-code10,comma-listv21,arbace.g2a.print-code7,targetsR56,R57,v21,arbace.g2a.print-code9,expr-listv21,arbace.g2a.print-code10,zero-form?v21,arbace.g2a.print-code8,n-valuesv11,arbace.core4,metaR58,v21,arbace.g2a.print-code11,type-paramsR59,v21,arbace.g2a.print-code10,assign-opsv21,arbace.g2a.print-code11,simple-stmtv21,arbace.g2a.print-code12,binding-stmtv21,arbace.g2a.print-code11,assign-stmtS2,s4,cases7,defaultv11,arbace.core5,some?R52,R52,S3,s4,conds2,ifs4,whenv21,arbace.g2a.print-code8,if-like?v21,arbace.g2a.print-code10,print-stmtv21,arbace.g2a.print-code12,branch-formsv11,arbace.core9,partitionv21,arbace.g2a.print-code9,else-partv11,arbace.core4,odd?v21,arbace.g2a.print-code11,branch-optsv21,arbace.g2a.print-code14,control-clausev11,arbace.core5,mergeR60,R61,R62,v21,arbace.g2a.print-code9,stmt-listv21,arbace.g2a.print-code7,clause?v21,arbace.g2a.print-code11,clause-listv21,arbace.g2a.print-code10,case-exprsv11,arbace.core6,removev11,arbace.core4,nil?v21,arbace.g2a.print-code10,case-typesv21,arbace.g2a.print-code4,commR63,v21,arbace.g2a.print-code10,range-stmtv21,arbace.g2a.print-code10,label-namev21,arbace.g2a.print-code10,while-stmtv21,arbace.g2a.print-code7,if-stmtv21,arbace.g2a.print-code8,for-stmtv21,arbace.g2a.print-code11,select-stmtv21,arbace.g2a.print-code16,type-switch-stmtv21,arbace.g2a.print-code10,label-stmtv21,arbace.g2a.print-code11,switch-stmtv11,arbace.core6,mapcatS2,s3,lets8,let-typeR64,R65,R66,v21,arbace.g2a.print-code13,flatten-stmtsS2,s3,lets8,let-typev21,arbace.g2a.print-code11,bind-targetv21,arbace.g2a.print-code11,const-bind?R67,v21,arbace.g2a.print-code12,label-targetR68,R69,v21,arbace.g2a.print-code16,keep-type-columnR70,v21,arbace.g2a.print-code10,const-specv21,arbace.g2a.print-code12,group-constsv21,arbace.g2a.print-code6,item-tv21,arbace.g2a.print-code8,label-ofv21,arbace.g2a.print-code11,const-groupv11,arbace.core5,applyv21,arbace.g2a.print-code16,expression-form?R71,v21,arbace.g2a.print-code12,group-targetv21,arbace.g2a.print-code17,type-binding-stmtv11,arbace.core6,every?v21,arbace.g2a.print-code5,room?v21,arbace.g2a.print-code18,stmt-list-one-linev21,arbace.g2a.print-code15,parse-decl-headR72,v11,arbace.core9,with-metav21,arbace.g2a.print-code13,generic-type?v11,arbace.core9,transientv11,arbace.core11,persistent!v11,arbace.core6,assoc!v21,arbace.g2a.print-code9,spec-namev21,arbace.g2a.print-code13,directives-ofv21,arbace.g2a.print-code6,spec-tv21,arbace.g2a.print-code9,write-prev21,arbace.g2a.print-code10,group-declv21,arbace.g2a.print-code10,value-specv21,arbace.g2a.print-code15,parse-type-specv21,arbace.g2a.print-code9,type-specv21,arbace.g2a.print-code9,type-declv21,arbace.g2a.print-code9,func-declv21,arbace.g2a.print-code14,const-var-decl")

var Lit_1 *jrt.String = jrt.Intern("=")

var Lit_2 *jrt.String = jrt.Intern("not an assignment operator")

var Lit_3 *jrt.String = jrt.Intern("set! takes 2 or 3 arguments")

var Lit_4 *jrt.String = jrt.Intern("*")

var Lit_5 *jrt.String = jrt.Intern("|")

var Lit_6 *jrt.String = jrt.Intern("(")

var Lit_7 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_expr$fn__1022000253")

var Lit_8 *jrt.String = jrt.Intern(")")

var Lit_9 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_expr$fn__1022000255")

var Lit_10 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt$fn__1022000369")

var Lit_11 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt$names__1022000371")

var Lit_12 *jrt.String = jrt.Intern("const")

var Lit_13 *jrt.String = jrt.Intern("var")

var Lit_14 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt$fn__1022000373")

var Lit_15 *jrt.String = jrt.Intern(":=")

var Lit_16 *jrt.String = jrt.Intern("arbace.g2a.print_code$block_body$fn__1022000558")

var Lit_17 *jrt.String = jrt.Intern("{")

var Lit_18 *jrt.String = jrt.Intern("arbace.g2a.print_code$block_body$fn__1022000560")

var Lit_19 *jrt.String = jrt.Intern("}")

var Lit_20 *jrt.String = jrt.Intern("do")

var Lit_21 *jrt.String = jrt.Intern("arbace.g2a.print_code$break_line$fn__1022000035")

var Lit_22 *jrt.String = jrt.Intern("arbace.g2a.print_code$breaks_of$fn__1022000031")

var Lit_23 *jrt.String = jrt.Intern("arbace.g2a.print_code$call_args$fn__1022000258")

var Lit_24 *jrt.String = jrt.Intern("spread")

var Lit_25 *jrt.String = jrt.Intern("...")

var Lit_26 *jrt.String = jrt.Intern("func")

var Lit_27 *jrt.String = jrt.Intern("case needs a vector")

var Lit_28 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_exprs$fn__1022000446")

var Lit_29 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_types$fn__1022000450")

var Lit_30 *jrt.String = jrt.Intern("nil")

var Lit_31 *jrt.String = jrt.Intern("chan")

var Lit_32 *jrt.String = jrt.Intern("<-")

var Lit_33 *jrt.String = jrt.Intern("bad channel direction")

var Lit_34 *jrt.String = jrt.Intern("not a case or default clause")

var Lit_35 *jrt.String = jrt.Intern("arbace.g2a.print_code$clause_list$fn__1022000439")

var Lit_36 *jrt.String = jrt.Intern(";")

var Lit_37 *jrt.String = jrt.Intern("default")

var Lit_38 *jrt.String = jrt.Intern(":")

var Lit_39 *jrt.String = jrt.Intern("case")

var Lit_40 *jrt.String = jrt.Intern("arbace.g2a.print_code$comma_list$fn__1022000043")

var Lit_41 *jrt.String = jrt.Intern(",")

var Lit_42 *jrt.String = jrt.Intern("arbace.g2a.print_code$comma_list$fn__1022000045")

var Lit_43 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265")

var Lit_44 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000266")

var Lit_45 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000268")

var Lit_46 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000277")

var Lit_47 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000283")

var Lit_48 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_bind_QMARK_$fn__1022000522")

var Lit_49 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_group$fn__1022000539")

var Lit_50 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_group$fn__1022000544")

var Lit_51 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_spec$fn__1022000535")

var Lit_52 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl$fn__1022000637")

var Lit_53 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl$fn__1022000639")

var Lit_54 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl$fn__1022000644")

var Lit_55 *jrt.String = jrt.Intern("go/type")

var Lit_56 *jrt.String = jrt.Intern("go/func")

var Lit_57 *jrt.String = jrt.Intern("go/const")

var Lit_58 *jrt.String = jrt.Intern("go/var")

var Lit_59 *jrt.String = jrt.Intern("go/method")

var Lit_60 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110")

var Lit_61 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$fn__1022000124")

var Lit_62 *jrt.String = jrt.Intern("go")

var Lit_63 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111")

var Lit_64 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115")

var Lit_65 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115$fn__1022000116")

var Lit_66 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115$fn__1022000116$fn__1022000117")

var Lit_67 *jrt.String = jrt.Intern("//go:")

var Lit_68 *jrt.String = jrt.Intern(" ")

var Lit_69 *jrt.String = jrt.Intern("")

var Lit_70 *jrt.String = jrt.Intern("arbace.g2a.print_code$element_list$fn__1022000068")

var Lit_71 *jrt.String = jrt.Intern("arbace.g2a.print_code$element_list$fn__1022000070")

var Lit_72 *jrt.String = jrt.Intern("fn")

var Lit_73 *jrt.String = jrt.Intern("else")

var Lit_74 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000315")

var Lit_75 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000317")

var Lit_76 *jrt.String = jrt.Intern("imaginary")

var Lit_77 *jrt.String = jrt.Intern("i")

var Lit_78 *jrt.String = jrt.Intern("subslice")

var Lit_79 *jrt.String = jrt.Intern("method-expr")

var Lit_80 *jrt.String = jrt.Intern(".")

var Lit_81 *jrt.String = jrt.Intern("assert")

var Lit_82 *jrt.String = jrt.Intern("go/call")

var Lit_83 *jrt.String = jrt.Intern("go/id")

var Lit_84 *jrt.String = jrt.Intern("conv")

var Lit_85 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000332")

var Lit_86 *jrt.String = jrt.Intern("spread outside the arguments of a call")

var Lit_87 *jrt.String = jrt.Intern("zero")

var Lit_88 *jrt.String = jrt.Intern("zero outside a var binding")

var Lit_89 *jrt.String = jrt.Intern("make")

var Lit_90 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000337")

var Lit_91 *jrt.String = jrt.Intern("inst")

var Lit_92 *jrt.String = jrt.Intern("rune")

var Lit_93 *jrt.String = jrt.Intern("values")

var Lit_94 *jrt.String = jrt.Intern("values outside a return, an assignment or a binding")

var Lit_95 *jrt.String = jrt.Intern("lit")

var Lit_96 *jrt.String = jrt.Intern("aget")

var Lit_97 *jrt.String = jrt.Intern("[")

var Lit_98 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000345")

var Lit_99 *jrt.String = jrt.Intern("]")

var Lit_100 *jrt.String = jrt.Intern("new")

var Lit_101 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000350")

var Lit_102 *jrt.String = jrt.Intern("byte-string")

var Lit_103 *jrt.String = jrt.Intern("a statement in an expression position")

var Lit_104 *jrt.String = jrt.Intern(".-")

var Lit_105 *jrt.String = jrt.Intern("a keyword in an expression position")

var Lit_106 *jrt.String = jrt.Intern("a vector in an expression position")

var Lit_107 *jrt.String = jrt.Intern("not an expression")

var Lit_108 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr_list$fn__1022000361")

var Lit_109 *jrt.String = jrt.Intern("panic")

var Lit_110 *jrt.String = jrt.Intern(": ")

var Lit_111 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$iter__1022000154__1022000158")

var Lit_112 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000164")

var Lit_113 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000166")

var Lit_114 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000168")

var Lit_115 *jrt.String = jrt.Intern("{}")

var Lit_116 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000180")

var Lit_117 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$iter__1022000154__1022000158$fn__1022000159")

var Lit_118 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$iter__1022000154__1022000158$fn__1022000159$fn__1022000160")

var Lit_119 *jrt.String = jrt.Intern("arbace.g2a.print_code$flatten_stmts$fn__1022000503")

var Lit_120 *jrt.String = jrt.Intern("let needs a binding vector")

var Lit_121 *jrt.String = jrt.Intern("arbace.g2a.print_code$flatten_stmts$fn__1022000503$fn__1022000508")

var Lit_122 *jrt.String = jrt.Intern("let needs pairs")

var Lit_123 *jrt.String = jrt.Intern("let")

var Lit_124 *jrt.String = jrt.Intern("for needs an init vector")

var Lit_125 *jrt.String = jrt.Intern("for")

var Lit_126 *jrt.String = jrt.Intern("a function needs a parameter vector")

var Lit_127 *jrt.String = jrt.Intern("fn needs a parameter vector")

var Lit_128 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_consts$fn__1022000525")

var Lit_129 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_decl$fn__1022000628")

var Lit_130 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_entries$fn__1022000077")

var Lit_131 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_entries$fn__1022000079")

var Lit_132 *jrt.String = jrt.Intern("not a name")

var Lit_133 *jrt.String = jrt.Intern("cond")

var Lit_134 *jrt.String = jrt.Intern("cond takes test-branch pairs")

var Lit_135 *jrt.String = jrt.Intern("if")

var Lit_136 *jrt.String = jrt.Intern("when")

var Lit_137 *jrt.String = jrt.Intern("if takes a condition, then and else")

var Lit_138 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_139 *jrt.String = jrt.Intern("arbace.g2a.print_code$keep_type_column$fn__1022000616")

var Lit_140 *jrt.String = jrt.Intern("not a label")

var Lit_141 *jrt.String = jrt.Intern("label")

var Lit_142 *jrt.String = jrt.Intern("a field key without a value")

var Lit_143 *jrt.String = jrt.Intern("a key-value element is [key value]")

var Lit_144 *jrt.String = jrt.Intern("true")

var Lit_145 *jrt.String = jrt.Intern("false")

var Lit_146 *jrt.String = jrt.Intern("\n")

var Lit_147 *jrt.String = jrt.Intern("`")

var Lit_148 *jrt.String = jrt.Intern("not a literal")

var Lit_149 *jrt.String = jrt.Intern("arbace.g2a.print_code$one_line_fields_QMARK_$fn__1022000138")

var Lit_150 *jrt.String = jrt.Intern("go/")

var Lit_151 *jrt.String = jrt.Intern("deref")

var Lit_152 *jrt.String = jrt.Intern("arbace.g2a.print_code$param_list$fn__1022000087")

var Lit_153 *jrt.String = jrt.Intern("arbace.g2a.print_code$paren_operand$fn__1022000249")

var Lit_154 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_results$fn__1022000091")

var Lit_155 *jrt.String = jrt.Intern("break")

var Lit_156 *jrt.String = jrt.Intern("range")

var Lit_157 *jrt.String = jrt.Intern("goto")

var Lit_158 *jrt.String = jrt.Intern("fallthrough")

var Lit_159 *jrt.String = jrt.Intern("while")

var Lit_160 *jrt.String = jrt.Intern("defer")

var Lit_161 *jrt.String = jrt.Intern("inc!")

var Lit_162 *jrt.String = jrt.Intern("dec!")

var Lit_163 *jrt.String = jrt.Intern("aset")

var Lit_164 *jrt.String = jrt.Intern("continue")

var Lit_165 *jrt.String = jrt.Intern("select")

var Lit_166 *jrt.String = jrt.Intern("type-switch")

var Lit_167 *jrt.String = jrt.Intern("return")

var Lit_168 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_stmt$fn__1022000500")

var Lit_169 *jrt.String = jrt.Intern("switch")

var Lit_170 *jrt.String = jrt.Intern(">!")

var Lit_171 *jrt.String = jrt.Intern("let-type")

var Lit_172 *jrt.String = jrt.Intern("set!")

var Lit_173 *jrt.String = jrt.Intern("range needs a vector")

var Lit_174 *jrt.String = jrt.Intern("arbace.g2a.print_code$range_stmt$fn__1022000493")

var Lit_175 *jrt.String = jrt.Intern("arbace.g2a.print_code$range_stmt$fn__1022000493$fn__1022000494")

var Lit_176 *jrt.String = jrt.Intern("an init vector holds one statement or one binding")

var Lit_177 *jrt.String = jrt.Intern("++")

var Lit_178 *jrt.String = jrt.Intern("--")

var Lit_179 *jrt.String = jrt.Intern("arbace.g2a.print_code$slice_expr$fn__1022000292")

var Lit_180 *jrt.String = jrt.Intern("arbace.g2a.print_code$slice_expr$fn__1022000294")

var Lit_181 *jrt.String = jrt.Intern("arbace.g2a.print_code$stmt_list$fn__1022000551")

var Lit_182 *jrt.String = jrt.Intern("go/directive")

var Lit_183 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145")

var Lit_184 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145$fn__1022000146")

var Lit_185 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145$fn__1022000146$fn__1022000147")

var Lit_186 *jrt.String = jrt.Intern("arbace.g2a.print_code$switch_stmt$fn__1022000459")

var Lit_187 *jrt.String = jrt.Intern("not a declaration")

var Lit_188 *jrt.String = jrt.Intern("type")

var Lit_189 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_decl$fn__1022000664")

var Lit_190 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_decl$fn__1022000669")

var Lit_191 *jrt.String = jrt.Intern("slice")

var Lit_192 *jrt.String = jrt.Intern("interface")

var Lit_193 *jrt.String = jrt.Intern("struct")

var Lit_194 *jrt.String = jrt.Intern("tilde")

var Lit_195 *jrt.String = jrt.Intern("~")

var Lit_196 *jrt.String = jrt.Intern("array")

var Lit_197 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_expr$fn__1022000198")

var Lit_198 *jrt.String = jrt.Intern("map")

var Lit_199 *jrt.String = jrt.Intern("not a type")

var Lit_200 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_list$fn__1022000188")

var Lit_201 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_params$fn__1022000216")

var Lit_202 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_switch_stmt$fn__1022000468")

var Lit_203 *jrt.String = jrt.Intern("-")

var Lit_204 *jrt.String = jrt.Intern("arbace.g2a.print_code$uses_grouped_QMARK_$walk__1022000012")

var Lit_205 *jrt.String = jrt.Intern("arbace.g2a.print_code$value_spec$fn__1022000590")

var Lit_206 *jrt.String = jrt.Intern("variadic parameter not a slice")

var Lit_207 *jrt.String = jrt.Intern("/")

var Lit_208 *jrt.String = jrt.Intern("arbace.g2a.print_code$while_stmt$fn__1022000486")

var Lit_209 *jrt.String = jrt.Intern("//")

var Lit_210 *jrt.String = jrt.Intern("\t")

var Lit_211 *jrt.String = jrt.Intern("// ")

var Lit_212 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn7,dynamickn8,arglistsyn5,formskn7,privateyn3,msgyn4,formyn1,fyn6,parentyn1,iyn5,childyn3,brkyn2,tsyn1,nyn4,bodyyn6,offsetyn2,xsyn9,print-oneyn3,nmsyn1,gyn1,kyn4,openyn5,closekn4,keysyn3,endyn6,targetkn2,oryn1,xyn1,vyn4,prevyn3,curyn7,entriesyn1,tyn1,&yn6,paramsyn7,resultsyn3,resyn1,syn3,docyn6,indentks2,go7,groupedks2,go4,instks2,go8,implicitks2,go3,viaks2,go3,tagks2,go3,endks2,go3,posks2,go4,aposks2,go5,parenks2,go5,labelks2,go6,breaksks2,go10,label-lineyn1,myn4,dirsyn4,moreyn6,groupsyn7,struct?yn2,fsyn3,sepyn2,kwyn3,tpsyn1,oyn4,precyn1,ryn4,has4yn4,has5yn2,mpyn5,depthyn1,dyn5,prec1yn3,cutyn1,hyn2,elv11,arbace.core5,in-nsMyn21,arbace.g2a.print-codem2,R0,s581,g2a's printer, the forms level (doc/go/PRINTER-NOTES.md): Go forms (doc/go/SPEC.md) to Go\n  tokens through arbace.g2a.print-emit. Types (§5), declarations (§6), statements and\n  expressions (§7), literals (§8), directives and doc comments (§9, §10.4), files (§4.3).\n\n  Every form is classified by its head and position (§4.4); nothing is resolved. Spacing\n  follows go/printer (go1.27.1 src/go/printer/nodes.go: binaryExpr, cutoff, walkBinary,\n  the depth rules of exprList, controlClause, funcBody, fieldList, valueSpec, keepTypeColumn)\n  so that gofmt leaves the output as it is.m2,R0,s581,g2a's printer, the forms level (doc/go/PRINTER-NOTES.md): Go forms (doc/go/SPEC.md) to Go\n  tokens through arbace.g2a.print-emit. Types (§5), declarations (§6), statements and\n  expressions (§7), literals (§8), directives and doc comments (§9, §10.4), files (§4.3).\n\n  Every form is classified by its head and position (§4.4); nothing is resolved. Spacing\n  follows go/printer (go1.27.1 src/go/printer/nodes.go: binaryExpr, cutoff, walkBinary,\n  the depth rules of exprList, controlClause, funcBody, fieldList, valueSpec, keepTypeColumn)\n  so that gofmt leaves the output as it is.R1,v21,arbace.g2a.print-code5,expr1m8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code5,expr0m8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,type-exprm8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,stmt-listm8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,simple-stmtm8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,block-bodym8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,print-stmtm8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code18,stmt-list-one-linem8,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,*go-ns*S2,s9,arbace.gos2,gom10,R6,TR3,i16,R4,i1,R5,s24,arbace/g2a/print_code.aeR0,s83,The namespace qualifiers that name the Go forms' own heads (go/func, go/call, ...).v21,arbace.g2a.print-code8,*header*m10,R6,TR3,i20,R4,i1,R5,s24,arbace/g2a/print_code.aeR0,s142,True while printing the header of an if, for or switch outside brackets: a composite\n  literal of a type name needs parentheses there (§12.2).v21,arbace.g2a.print-code17,*explicit-groups*m10,R6,TR3,i25,R4,i1,R5,s24,arbace/g2a/print_code.aeR0,s131,True when the file's forms mark grouped names with :go/grouped: then only marked names are\n  grouped (PRINTER-NOTES, amendment A1).v21,arbace.g2a.print-code13,uses-grouped?m10,R7,L1,V1,R8,R0,s52,Whether :go/grouped occurs in the metadata of forms.R3,i30,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,*generic*m10,R6,TR3,i39,R4,i1,R5,s24,arbace/g2a/print_code.aeR0,s91,True inside a generic declaration: field groups are kept (doc/go/ROUNDTRIP.md, known gaps).v21,arbace.g2a.print-code4,failm10,R9,TR7,L1,V2,R10,R11,R3,i43,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code2,opm10,R7,L1,V1,R12,R0,s196,The name of a list's head as the forms read it: an unqualified symbol's name,\n  \"go/name\" for the Go forms' qualified heads, \"deref\" for @; nil otherwise (a call of a\n  package member, of a list).R3,i49,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,stmt-headsS26,s5,ranges5,defers5,labels6,returns2,>!s4,set!s3,fors11,fallthroughs4,dec!s4,conds2,ifs3,lets2,gos6,switchs6,selects5,breaks4,whens8,let-types8,continues2,dos4,inc!s5,whiles4,asets12,go/directives4,gotos11,type-switchm6,R3,i64,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,binary-opsm38,s2,>>V2,s2,>>l5,s2,!=V2,s2,!=l3,s1,*V2,s1,*l5,s1,%V2,s1,%l5,s2,<=V2,s2,<=l3,s6,bit-orV2,s1,|l4,s1,/V2,s1,/l5,s1,-V2,s1,-l4,s7,bit-xorV2,s1,^l4,s7,bit-andV2,s1,&l5,s11,bit-and-notV2,s2,&^l5,s2,orV2,s2,||l1,s2,>=V2,s2,>=l3,s3,andV2,s2,&&l2,s1,<V2,s1,<l3,s2,<<V2,s2,<<l5,s2,==V2,s2,==l3,s1,+V2,s1,+l4,s1,>V2,s1,>l3,m6,R3,i69,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,unary-opsm14,s1,-s1,-s1,+s1,+s7,bit-nots1,^s3,nots1,!s4,addrs1,&s5,derefs1,*s2,<!s2,<-m6,R3,i75,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,assign-opsm22,s2,>>s3,>>=s1,*s2,*=s1,%s2,%=s6,bit-ors2,|=s1,/s2,/=s1,-s2,-=s7,bit-xors2,^=s7,bit-ands2,&=s11,bit-and-nots3,&^=s2,<<s3,<<=s1,+s2,+=m6,R3,i77,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,type-headsS11,s4,funcs3,maps4,insts4,chans1,*s9,interfaces1,|s5,tildes5,slices6,structs5,arraym6,R3,i81,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code4,argsm10,R9,TR7,L1,V1,R12,R3,i83,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,binary?m10,R7,L1,V1,R12,R0,s82,A binary operator form: two or more operands (n-ary forms are left-nested chains).R3,i85,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code17,negative-literal?m10,R9,TR7,L1,V1,R12,R3,i90,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code6,unary?m10,R7,L1,V1,R12,R0,s74,A unary operator form (Go's UnaryExpr or StarExpr), or a negative literal.R3,i92,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,unary-opm10,R9,TR7,L1,V1,R12,R3,i98,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,unary-operandm10,R9,TR7,L1,V1,R12,R3,i100,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code6,bin-opm10,R9,TR7,L1,V1,R12,R3,i105,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,bin-precm10,R9,TR7,L1,V1,R12,R3,i106,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,prec-ofm10,R7,L1,V1,R12,R0,s85,The precedence of the Go expression a form prints as: 1-5 binary, 6 unary, 7 primary.R3,i108,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,go-sym?m10,R9,TR7,L1,V1,R12,R3,i113,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code15,statement-form?m10,R9,TR7,L1,V1,R12,R3,i115,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code16,expression-form?m10,R7,L1,V1,R12,R0,s75,An expression form other than a call of panic: the implicit return of §6.4.R3,i118,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,line-ofm10,R9,TR7,L1,V1,R12,R3,i125,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,breaks-ofm12,R9,TR7,L1,V1,R12,R0,s178,The child indexes in f's :go/breaks, a set: an entry is an index, or [index line] for a\n  literal whose Go line is not the line after the last one written before it (SPEC §10.1).R3,i127,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,break-linem12,R9,TR7,L1,V2,R13,R14,R0,s71,The line :go/breaks records for child i of parent, when it records one.R3,i133,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,child-targetm12,R9,TR7,L2,V3,R13,R14,R15,V4,R13,R14,R15,R16,R0,s178,The recorded line of child i of a list: its own, or the line of the list's :go/breaks (a\n  new line, or the line it records; brk: the set of the indexes, when the caller has it).R3,i138,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,next-targetsm12,R9,TR7,L1,V1,R17,R0,s75,For targets ts (lines, :break or nil), the first line after each: a vector.R3,i147,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code5,room?m10,R9,TR7,L1,V1,R18,R3,i159,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,body-offsetm12,R9,TR7,L1,V2,R12,R19,R0,s55,The index in f of the first of its trailing body forms.R3,i161,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,next-linem12,R9,TR7,L1,V1,R8,R0,s49,The first recorded line among forms, else *next*.R3,i165,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,comma-listm12,R9,TR7,L1,V4,R13,R20,R21,R22,R0,s196,x1, x2, ...: the children of parent from index offset on, each by (print-one x), each after\n  the first on its recorded line (its own, or parent's :go/breaks: Go allows a break after the\n  comma).R3,i170,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,ident-stringm10,R7,L1,V1,R12,R0,s59,The Go spelling of a name: a symbol, pkg/Name, (go/id \"x\").R3,i185,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,name-listm12,R9,TR7,L1,V1,R23,R0,s259,Names separated by commas (a group of parameters, results, fields, type parameters, or a\n  spec's names), each on its recorded line: a name list may span lines (Go allows a break\n  after a comma), and gc declares each name at its own line (DWARF's decl_line).R3,i193,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,group-linem12,R9,TR7,L1,V1,R24,R0,s75,The recorded line of a group of entries: its first name's, else its type's.R3,i202,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,label-namem10,R9,TR7,L1,V1,R25,R3,i207,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,literalm10,R9,TR7,L1,V1,R12,R3,i210,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,element-listm12,R9,TR7,L1,V5,R26,R27,R21,R22,m4,R28,V4,R13,R20,R29,R30,R31,m2,R20,l1,R0,s493,Prints xs between open and close, separated by commas, each by (print-one x i); keeps\n  the recorded lines of the elements, and puts close on a line of its own after a trailing\n  comma when the elements span lines and there is room. parent and offset give the\n  elements' indexes in their parent list (for :go/breaks); end, the line of close (:here:\n  the line of the last element); target, when given, the recorded line of an element (for\n  elements that are not forms: groups of parameters).R3,i229,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,tagged?m12,R9,TR7,L1,V1,R32,R0,s63,A name with a type: a symbol or (go/id \"x\") carrying :tag (C5).R3,i272,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,param-entriesm12,R9,TR7,L1,V1,R33,R0,s164,The entries of a parameter, result or field vector: {:name sym-or-nil :type T\n  :variadic? bool :meta m :src x}. A symbol with :tag is a name, anything else a type.R3,i277,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,groupable?m12,R9,TR7,L1,V2,R34,R35,R0,s246,Whether cur may join prev's group: names of one type, doc and struct tag (a field's doc and\n  tag are its every name's, so equal ones are one field's), cur not beginning a line of its\n  own (a name that does keeps its line: gc declares it there).R3,i293,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,group-entriesm10,R7,L1,V1,R36,R0,s611,Consecutive named entries of equal type, doc and tag (groupable?) as one group\n  {:names [...] ...}: Go's `a, b T`. Inside generic declarations the grouping must be the\n  source's: when a name of the list carries :go/grouped (the amendment proposed in\n  PRINTER-NOTES: each name declared together with the one before it), exactly those names\n  join the group before them (in a file that marks them, *explicit-groups*, a generic\n  declaration's list without marks has no groups); otherwise the source is assumed to group\n  what it can (outside generic declarations the converter marks nothing: grouping is N3's).R3,i305,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,variadic-elemm10,R9,TR7,L1,V1,R37,R3,i328,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,param-listm12,R9,TR7,L1,V3,R33,R38,V1,R29,R0,s217,(a, b int, c ...T): the parameters of a vector; end, the line of the closing bracket when\n  known. The vector's recorded line is its opening bracket's (a parameter list after type\n  parameters that span lines: SA200).R3,i331,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code15,results-entriesm12,R9,TR7,L1,V2,R39,R40,R0,s77,The results of a signature: a vector's :tag (one unnamed result) or :results.R3,i348,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,print-resultsm10,R9,TR7,L1,V1,R36,R3,i356,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,line-indentm12,R9,TR7,L1,V0,R0,s42,The indentation of the line being written.R3,i363,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,signaturem12,R9,TR7,L1,V3,R39,R41,R19,R0,s319,(params) results. The parameters' closing bracket goes on the line of the results (their\n  first token follows it on its line: the line they record, else the last parameter's), and\n  without results, when the parameters span lines, on a line of its own only if there is room\n  before the body (its first recorded line).R3,i368,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,func-type-sigm12,R9,TR7,L1,V2,R39,R40,R0,s87,(params) results of (func [params] [results]): the results vector holds names or types.R3,i379,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,struct-tagm10,R9,TR7,L1,V1,R42,R3,i384,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,doc-linesm10,R9,TR7,L1,V1,R43,R3,i389,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,write-docm10,R7,L1,V2,R43,R44,R0,s46,A doc comment (CommentGroup.Text) as // lines.R3,i394,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code18,non-directive-keysS12,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,m8,R9,TR3,i402,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,directives-ofm10,R7,L1,V1,R57,R0,s250,The directive lines of a declared name's metadata (§9.1): :go/<name> true or text (a\n  vector for several), sorted by name. Directives not spelled //go: are free-standing\n  (go/directive \"...\") forms (A6, in the converter's spelling), never metadata.R3,i406,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,pre-linesm10,R7,L1,V2,R43,R58,R0,s135,The number of comment lines before a declaration: doc, a // line between doc and\n  directives (gofmt's doc comment format), directives.R3,i417,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,write-prem8,R7,L1,V3,R43,R58,R44,R3,i424,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code17,interface-method?m10,R9,TR7,L1,V1,R32,R3,i429,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code16,iface-method-sigm12,R9,TR7,L1,V2,R39,R59,R0,s101,(params) results of an interface method or declaration: [params] then :results or the\n  vector's tag.R3,i433,R4,i1,R5,s24,arbace/g2a/print_code.aem8,R2,TR3,i440,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code16,one-line-fields?m12,R9,TR7,L1,V2,R60,R61,R0,s165,go/printer's isOneLineFieldList: one field (group) without tag or doc, whose type prints\n  in at most 30 characters, 29 with names (a method's type is func(...)...).R3,i442,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,struct-fieldsm10,R9,TR7,L1,V1,R62,R3,i460,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,field-bodym12,R9,TR7,L1,V3,R24,R61,R63,R0,s67,One struct field (group) or interface element, with its separators.R3,i466,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,field-listm12,R9,TR7,L1,V3,R64,R62,R61,R0,s55,struct{...} or interface{...} (go/printer's fieldList).R3,i485,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,chan-typem10,R9,TR7,L1,V1,R12,R3,i531,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,type-listm12,R9,TR7,L1,V1,R17,R0,s22,Type arguments [A, B].R3,i545,R4,i1,R5,s24,arbace/g2a/print_code.aem10,R7,L1,V1,R12,R0,s26,Prints a type form (§5.1).R3,i550,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,type-form?m12,R9,TR7,L1,V1,R12,R0,s116,A form that prints as a type in an operand position: reserved type heads (other than\n  * with two or more operands).R3,i585,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code26,begins-with-star-or-paren?m10,R9,TR7,L1,V1,R12,R3,i594,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,type-paramsm12,R9,TR7,L1,V1,R65,R0,s107,[P C, Q D] after a name; a single parameter whose constraint begins with * gets a trailing\n  comma (§12.2).R3,i598,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,walk-binarym8,R2,TR3,i621,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,walk-rightm12,R9,TR7,L1,V3,R66,R67,R68,R0,s118,go/printer's walkBinary, the part of a right operand r of the operator o (precedence\n  prec): [has4 has5 max-problem].R3,i623,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,walk-prefixesm12,R9,TR7,L1,V1,R12,R0,s246,go/printer's walkBinary of each left-nested prefix of f: (+ a b c d) is (+ (+ (+ a b) c) d),\n  whose prefixes (+ a b), (+ a b c) and f are walked in one pass (each prefix's walk is its\n  left prefix's and its right operand's): a vector, f's last.R3,i636,R4,i1,R5,s24,arbace/g2a/print_code.aem12,R9,TR7,L1,V1,R12,R0,s49,go/printer's walkBinary: [has4 has5 max-problem].R3,i654,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,cutoff-ofm10,R9,TR7,L1,V2,V3,R69,R70,R71,R72,R3,i659,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code6,cutoffm10,R9,TR7,L1,V2,R12,R72,R3,i666,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,diff-precm10,R9,TR7,L1,V2,R32,R67,R3,i668,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,reduce-depthm10,R9,TR7,L1,V1,R73,R3,i671,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,paren-operandm12,R9,TR7,L1,V1,R32,R0,s140,An operand of && or || the source parenthesized (:go/paren, C3): gc removes dead branches\n  by syntax and does not look through parentheses.R3,i673,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,binary-exprm12,R9,TR7,L1,V4,R12,R74,R75,R72,R0,s341,go/printer's binaryExpr. An n-ary form is a left-nested chain, (+ a b c) printed as\n  (+ (+ a b) c): its prefixes are printed in one pass, each with its own cutoff, as the\n  recursion through them would (each prefix's expr1 first moving to f's line, then its left\n  operand, then its operator and right operand), without making the prefixes.R3,i682,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,call-argsm12,R9,TR7,L1,V4,R12,R21,R72,R20,R0,s47,(args) of a call; a final (spread xs) is xs....R3,i719,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code6,calleem10,R9,TR7,L1,V2,R76,R72,R3,i729,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code22,lit-type-needs-parens?m10,R9,TR7,L1,V1,R37,R3,i734,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,lit-elementsm10,R9,TR7,L1,V1,R12,R3,i739,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,key-sizem12,R9,TR7,L1,V1,R77,R0,s59,The printed width of a key, for gofmt's alignment decision.R3,i754,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,composite-litm10,R9,TR7,L1,V2,R12,R72,R3,i766,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,slice-exprm10,R9,TR7,L1,V2,R12,R72,R3,i799,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,func-litm12,R9,TR7,L1,V1,R12,R0,s27,(fn params results? body*).R3,i816,R4,i1,R5,s24,arbace/g2a/print_code.ae")

var Lit_213 *jrt.String = jrt.Intern("arbace.g2a.print_code$eval1022000004$loading__1927001464__auto____1022000005")

var Lit_214 *jrt.String = jrt.Intern("arbace.g2a.print_code$eval1022000008$fn__1022000009")

var Lit_215 *jrt.String = jrt.Intern("arbace.g2a.print_code$uses_grouped_QMARK_")

var Lit_216 *jrt.String = jrt.Intern("arbace.g2a.print_code$fail")

var Lit_217 *jrt.String = jrt.Intern("arbace.g2a.print_code$op")

var Lit_218 *jrt.String = jrt.Intern("arbace.g2a.print_code$args")

var Lit_219 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_QMARK_")

var Lit_220 *jrt.String = jrt.Intern("arbace.g2a.print_code$negative_literal_QMARK_")

var Lit_221 *jrt.String = jrt.Intern("arbace.g2a.print_code$unary_QMARK_")

var Lit_222 *jrt.String = jrt.Intern("arbace.g2a.print_code$unary_op")

var Lit_223 *jrt.String = jrt.Intern("arbace.g2a.print_code$unary_operand")

var Lit_224 *jrt.String = jrt.Intern("arbace.g2a.print_code$bin_op")

var Lit_225 *jrt.String = jrt.Intern("arbace.g2a.print_code$bin_prec")

var Lit_226 *jrt.String = jrt.Intern("arbace.g2a.print_code$prec_of")

var Lit_227 *jrt.String = jrt.Intern("arbace.g2a.print_code$go_sym_QMARK_")

var Lit_228 *jrt.String = jrt.Intern("arbace.g2a.print_code$statement_form_QMARK_")

var Lit_229 *jrt.String = jrt.Intern("arbace.g2a.print_code$expression_form_QMARK_")

var Lit_230 *jrt.String = jrt.Intern("arbace.g2a.print_code$line_of")

var Lit_231 *jrt.String = jrt.Intern("arbace.g2a.print_code$breaks_of")

var Lit_232 *jrt.String = jrt.Intern("arbace.g2a.print_code$break_line")

var Lit_233 *jrt.String = jrt.Intern("arbace.g2a.print_code$child_target")

var Lit_234 *jrt.String = jrt.Intern("arbace.g2a.print_code$next_targets")

var Lit_235 *jrt.String = jrt.Intern("arbace.g2a.print_code$room_QMARK_")

var Lit_236 *jrt.String = jrt.Intern("arbace.g2a.print_code$body_offset")

var Lit_237 *jrt.String = jrt.Intern("arbace.g2a.print_code$next_line")

var Lit_238 *jrt.String = jrt.Intern("arbace.g2a.print_code$comma_list")

var Lit_239 *jrt.String = jrt.Intern("arbace.g2a.print_code$ident_string")

var Lit_240 *jrt.String = jrt.Intern("arbace.g2a.print_code$name_list")

var Lit_241 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_line")

var Lit_242 *jrt.String = jrt.Intern("arbace.g2a.print_code$label_name")

var Lit_243 *jrt.String = jrt.Intern("arbace.g2a.print_code$literal")

var Lit_244 *jrt.String = jrt.Intern("arbace.g2a.print_code$element_list")

var Lit_245 *jrt.String = jrt.Intern("arbace.g2a.print_code$tagged_QMARK_")

var Lit_246 *jrt.String = jrt.Intern("arbace.g2a.print_code$param_entries")

var Lit_247 *jrt.String = jrt.Intern("arbace.g2a.print_code$groupable_QMARK_")

var Lit_248 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_entries")

var Lit_249 *jrt.String = jrt.Intern("arbace.g2a.print_code$variadic_elem")

var Lit_250 *jrt.String = jrt.Intern("arbace.g2a.print_code$param_list")

var Lit_251 *jrt.String = jrt.Intern("arbace.g2a.print_code$results_entries")

var Lit_252 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_results")

var Lit_253 *jrt.String = jrt.Intern("arbace.g2a.print_code$line_indent")

var Lit_254 *jrt.String = jrt.Intern("arbace.g2a.print_code$signature")

var Lit_255 *jrt.String = jrt.Intern("arbace.g2a.print_code$func_type_sig")

var Lit_256 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_tag")

var Lit_257 *jrt.String = jrt.Intern("arbace.g2a.print_code$doc_lines")

var Lit_258 *jrt.String = jrt.Intern("arbace.g2a.print_code$write_doc")

var Lit_259 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of")

var Lit_260 *jrt.String = jrt.Intern("arbace.g2a.print_code$pre_lines")

var Lit_261 *jrt.String = jrt.Intern("arbace.g2a.print_code$write_pre")

var Lit_262 *jrt.String = jrt.Intern("arbace.g2a.print_code$interface_method_QMARK_")

var Lit_263 *jrt.String = jrt.Intern("arbace.g2a.print_code$iface_method_sig")

var Lit_264 *jrt.String = jrt.Intern("arbace.g2a.print_code$one_line_fields_QMARK_")

var Lit_265 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields")

var Lit_266 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_body")

var Lit_267 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list")

var Lit_268 *jrt.String = jrt.Intern("arbace.g2a.print_code$chan_type")

var Lit_269 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_list")

var Lit_270 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_expr")

var Lit_271 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_form_QMARK_")

var Lit_272 *jrt.String = jrt.Intern("arbace.g2a.print_code$begins_with_star_or_paren_QMARK_")

var Lit_273 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_params")

var Lit_274 *jrt.String = jrt.Intern("arbace.g2a.print_code$walk_right")

var Lit_275 *jrt.String = jrt.Intern("arbace.g2a.print_code$walk_prefixes")

var Lit_276 *jrt.String = jrt.Intern("arbace.g2a.print_code$walk_binary")

var Lit_277 *jrt.String = jrt.Intern("arbace.g2a.print_code$cutoff_of")

var Lit_278 *jrt.String = jrt.Intern("arbace.g2a.print_code$cutoff")

var Lit_279 *jrt.String = jrt.Intern("arbace.g2a.print_code$diff_prec")

var Lit_280 *jrt.String = jrt.Intern("arbace.g2a.print_code$reduce_depth")

var Lit_281 *jrt.String = jrt.Intern("arbace.g2a.print_code$paren_operand")

var Lit_282 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_expr")

var Lit_283 *jrt.String = jrt.Intern("arbace.g2a.print_code$call_args")

var Lit_284 *jrt.String = jrt.Intern("arbace.g2a.print_code$callee")

var Lit_285 *jrt.String = jrt.Intern("arbace.g2a.print_code$lit_type_needs_parens_QMARK_")

var Lit_286 *jrt.String = jrt.Intern("arbace.g2a.print_code$lit_elements")

var Lit_287 *jrt.String = jrt.Intern("arbace.g2a.print_code$key_size")

var Lit_288 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit")

var Lit_289 *jrt.String = jrt.Intern("arbace.g2a.print_code$slice_expr")

var Lit_290 *jrt.String = jrt.Intern("arbace.g2a.print_code$func_lit")

var Lit_291 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,xkn4,linekn6,columnkn4,fileyn1,fyn5,prec1yn5,depthkn3,docyn1,tyn6,targetyn4,inityn2,nmyn4,for?yn4,condyn4,postyn1,byn6,parentyn1,ikn8,declaredyn3,elsyn4,optsyn7,clausesyn10,print-headyn1,vyn1,cyn5,formsyn6,offsetyn2,ityn6,indentyn5,more?yn5,itemsyn9,keep-typeyn3,itskn4,keysyn8,results?kn2,asyn3,endyn5,func?yn3,sepyn4,nextyn2,xsyn7,method?yn6,group?yn5,specsyn2,kwyn3,docyn10,print-specyn7,meta-ofyn3,tpsv21,arbace.g2a.print-code7,new-argm10,R0,TR1,L1,V1,R2,R3,i830,R4,i1,R5,s24,arbace/g2a/print_code.aem10,R1,L1,V3,R6,R7,R8,R9,s72,go/printer's expr1: prints f as an operand of precedence at least prec1.R3,i838,R4,i1,R5,s24,arbace/g2a/print_code.aem8,R1,L1,V2,R6,R8,R3,i919,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,expr-listm12,R0,TR1,L1,V2,R6,R8,R9,s169,e1, e2, ...: (values ...) or one expression; the values on the line of the values form,\n  each after the first on its recorded line (its own, or the values' :go/breaks).R3,i921,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,n-valuesm10,R0,TR1,L1,V1,R6,R3,i930,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,zero-form?m10,R0,TR1,L1,V1,R6,R3,i935,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,targetsm10,R0,TR1,L1,V1,R10,R3,i937,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,binding-stmtm10,R1,L1,V2,R11,R12,R9,s60,A let binding pair as a Go statement: :=, var, const (§7.3).R3,i939,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code17,type-binding-stmtm10,R0,TR1,L1,V2,R13,R10,R3,i961,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,assign-stmtm10,R0,TR1,L1,V1,R6,R3,i970,R4,i1,R5,s24,arbace/g2a/print_code.aem10,R1,L1,V1,R6,R9,s151,A simple statement: an init or post statement, a select communication, an expression\n  statement, an assignment, a := binding written as [target init].R3,i980,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,clause?m10,R0,TR1,L1,V1,R6,R3,i1000,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code14,control-clausem12,R0,TR1,L1,V4,R14,R12,R15,R16,R9,s67,go/printer's controlClause: init; cond; post of if, switch and for.R3,i1002,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,branch-formsm12,R0,TR1,L1,V1,R17,R9,s83,The statement list of a branch: (do ...) is its forms, anything else one statement.R3,i1020,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,branch-optsm12,R0,TR1,L1,V3,R18,R19,R17,R9,s65,block-body's :parent and :offset for branch b, child i of parent.R3,i1025,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,if-like?m10,R0,TR1,L1,V1,R6,R3,i1030,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code7,if-stmtm8,R20,TR3,i1032,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,else-partm10,R0,TR1,L1,V2,R21,R22,R3,i1034,R4,i1,R5,s24,arbace/g2a/print_code.aem10,R0,TR1,L1,V1,R6,R3,i1040,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,clause-listm12,R0,TR1,L1,V2,R23,R24,R9,s63,The clauses of a switch, type switch or select, between braces.R3,i1080,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,case-exprsm10,R0,TR1,L1,V1,R25,R3,i1102,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,case-typesm10,R0,TR1,L1,V1,R25,R3,i1107,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,switch-stmtm10,R0,TR1,L1,V1,R6,R3,i1112,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code16,type-switch-stmtm10,R0,TR1,L1,V1,R6,R3,i1124,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code4,commm10,R0,TR1,L1,V1,R26,R3,i1141,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,select-stmtm10,R0,TR1,L1,V1,R6,R3,i1146,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,for-stmtm10,R0,TR1,L1,V1,R6,R3,i1152,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,while-stmtm10,R0,TR1,L1,V1,R6,R3,i1159,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,range-stmtm10,R0,TR1,L1,V1,R6,R3,i1165,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,label-stmtm8,R20,TR3,i1178,R4,i1,R5,s24,arbace/g2a/print_code.aem10,R1,L1,V1,R6,R9,s64,Prints one statement form (not a let: stmt-list flattens those).R3,i1180,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,flatten-stmtsm12,R0,TR1,L1,V3,R27,R18,R28,R9,s312,The items of a statement list: {:form f} or {:bind [target init] :t line} or\n  {:type-bind [name type]}; a let (or let-type) last in a list continues the list with its\n  body, one that is not last is a block of its own. parent and offset: the list holding the\n  forms and the index of the first (for :go/breaks).R3,i1210,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code6,item-tm10,R0,TR1,L1,V1,R29,R3,i1241,R4,i1,R5,s24,arbace/g2a/print_code.aem12,R0,TR1,L1,V3,R6,R30,R31,R9,s146,(label :L s?): L: s. A label without a statement is followed by ; when more statements\n  follow (more?). Nested labels print in a row (L1: L2: s).R3,i1243,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,bind-targetm10,R0,TR1,L1,V1,R29,R3,i1260,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,const-bind?m10,R0,TR1,L1,V1,R29,R3,i1262,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,group-constsm12,R0,TR1,L1,V1,R32,R9,s152,Joins the bindings of a local const ( ... ) group (C2): a const binding whose target\n  carries :go/grouped continues the group of the binding before it.R3,i1267,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,label-targetm12,R0,TR1,L1,V1,R29,R9,s90,The first target of an item's declaration, which a labeled declaration's label is on (A9).R3,i1281,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,label-ofm12,R0,TR1,L1,V1,R29,R9,s71,The label of a labeled declaration (:go/label on its first target, A9).R3,i1286,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,const-specm12,R0,TR1,L1,V2,V2,R11,R12,R33,R9,s91,One spec of a local const group: names, type and values, or the names alone (:go/implicit).R3,i1292,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code16,keep-type-columnm8,R20,TR3,i1304,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code11,const-groupm12,R0,TR1,L1,V2,R34,R30,R9,s81,const ( specs ) in a function body, at indent: its specs on their recorded lines.R3,i1306,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code12,group-targetm12,R0,TR1,L1,V1,R10,R9,s78,The line of a const group's keyword: the line before its first spec when free.R3,i1324,R4,i1,R5,s24,arbace/g2a/print_code.aem10,R1,L1,V2,R27,m4,R35,V4,R30,R36,R18,R28,R37,R22,R9,s224,Prints a statement list at indent (opts :indent), each statement on its recorded line.\n  :results? makes a final expression the function's return (§6.4). :parent and :offset\n  locate the forms in their list (for :go/breaks).R3,i1329,R4,i1,R5,s24,arbace/g2a/print_code.aem10,R1,L1,V2,R27,m4,R35,V7,R36,R38,R39,R40,R41,R18,R28,R37,R22,R9,s433,{ statements } at one more indentation than the line of the brace. opts: :results?,\n  :end (the recorded line of the closing brace), :func? (a function body: gofmt keeps it on\n  one line when the source has it so), :sep (whitespace before the brace), :next (the line\n  of what follows the brace), :else-follows?, :indent (the indentation of the line the\n  construct began on, when its header may span lines: a function's parameters).R3,i1372,R4,i1,R5,s24,arbace/g2a/print_code.aem12,R0,TR1,L1,V3,R27,R36,R30,R9,s88,A function body on one line: statements separated by semicolons (go/printer's funcBody).R3,i1413,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code15,parse-decl-headm10,R1,L1,V1,R42,R9,s105,[doc opts rest] of the arguments after a declaration's name: an optional doc string, then\n  :type-params.R3,i1434,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code13,generic-type?m10,R0,TR1,L1,V1,R10,R3,i1442,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,func-declm10,R1,L1,V2,R6,R43,R9,s29,go/func and go/method (§6.4).R3,i1447,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,spec-namem10,R0,TR1,L1,V1,R10,R3,i1476,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,value-specm12,R0,TR1,L1,V4,R11,R12,R44,R33,R9,s78,Names, type and values of a const or var spec. keep-type: gofmt's type column.R3,i1478,R4,i1,R5,s24,arbace/g2a/print_code.aem12,R0,TR1,L1,V1,R45,R9,s57,go/printer's keepTypeColumn over the specs [target init].R3,i1490,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code6,spec-tm10,R0,TR1,L1,V1,R25,R3,i1509,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code10,group-declm12,R0,TR1,L1,V5,R46,R47,R45,R48,R49,R9,s64,kw ( specs ): print-spec prints one spec vector given its index.R3,i1512,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code14,const-var-declm10,R0,TR1,L1,V2,R6,R46,R3,i1549,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,type-specm10,R0,TR1,L1,V4,R13,R50,R10,R44,R3,i1564,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code15,parse-type-specm10,R0,TR1,L1,V1,R42,R3,i1572,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code9,type-declm10,R0,TR1,L1,V1,R6,R3,i1578,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code23,decl-doc-and-directivesm10,R1,L1,V1,R6,R9,s37,[doc directives] of a top-level form.R3,i1590,R4,i1,R5,s24,arbace/g2a/print_code.aev21,arbace.g2a.print-code8,top-declm10,R1,L1,V1,R6,R9,s74,Prints a top-level declaration form, after its doc comment and directives.R3,i1612,R4,i1,R5,s24,arbace/g2a/print_code.ae")

var Lit_292 *jrt.String = jrt.Intern("arbace.g2a.print_code$new_arg")

var Lit_293 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1")

var Lit_294 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr0")

var Lit_295 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr_list")

var Lit_296 *jrt.String = jrt.Intern("arbace.g2a.print_code$n_values")

var Lit_297 *jrt.String = jrt.Intern("arbace.g2a.print_code$zero_form_QMARK_")

var Lit_298 *jrt.String = jrt.Intern("arbace.g2a.print_code$targets")

var Lit_299 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt")

var Lit_300 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_binding_stmt")

var Lit_301 *jrt.String = jrt.Intern("arbace.g2a.print_code$assign_stmt")

var Lit_302 *jrt.String = jrt.Intern("arbace.g2a.print_code$simple_stmt")

var Lit_303 *jrt.String = jrt.Intern("arbace.g2a.print_code$clause_QMARK_")

var Lit_304 *jrt.String = jrt.Intern("arbace.g2a.print_code$control_clause")

var Lit_305 *jrt.String = jrt.Intern("arbace.g2a.print_code$branch_forms")

var Lit_306 *jrt.String = jrt.Intern("arbace.g2a.print_code$branch_opts")

var Lit_307 *jrt.String = jrt.Intern("arbace.g2a.print_code$if_like_QMARK_")

var Lit_308 *jrt.String = jrt.Intern("arbace.g2a.print_code$else_part")

var Lit_309 *jrt.String = jrt.Intern("arbace.g2a.print_code$if_stmt")

var Lit_310 *jrt.String = jrt.Intern("arbace.g2a.print_code$clause_list")

var Lit_311 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_exprs")

var Lit_312 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_types")

var Lit_313 *jrt.String = jrt.Intern("arbace.g2a.print_code$switch_stmt")

var Lit_314 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_switch_stmt")

var Lit_315 *jrt.String = jrt.Intern("arbace.g2a.print_code$comm")

var Lit_316 *jrt.String = jrt.Intern("arbace.g2a.print_code$select_stmt")

var Lit_317 *jrt.String = jrt.Intern("arbace.g2a.print_code$for_stmt")

var Lit_318 *jrt.String = jrt.Intern("arbace.g2a.print_code$while_stmt")

var Lit_319 *jrt.String = jrt.Intern("arbace.g2a.print_code$range_stmt")

var Lit_320 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_stmt")

var Lit_321 *jrt.String = jrt.Intern("arbace.g2a.print_code$flatten_stmts")

var Lit_322 *jrt.String = jrt.Intern("arbace.g2a.print_code$item_t")

var Lit_323 *jrt.String = jrt.Intern("arbace.g2a.print_code$label_stmt")

var Lit_324 *jrt.String = jrt.Intern("arbace.g2a.print_code$bind_target")

var Lit_325 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_bind_QMARK_")

var Lit_326 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_consts")

var Lit_327 *jrt.String = jrt.Intern("arbace.g2a.print_code$label_target")

var Lit_328 *jrt.String = jrt.Intern("arbace.g2a.print_code$label_of")

var Lit_329 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_spec")

var Lit_330 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_group")

var Lit_331 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_target")

var Lit_332 *jrt.String = jrt.Intern("arbace.g2a.print_code$stmt_list")

var Lit_333 *jrt.String = jrt.Intern("arbace.g2a.print_code$block_body")

var Lit_334 *jrt.String = jrt.Intern("arbace.g2a.print_code$stmt_list_one_line")

var Lit_335 *jrt.String = jrt.Intern("arbace.g2a.print_code$parse_decl_head")

var Lit_336 *jrt.String = jrt.Intern("arbace.g2a.print_code$generic_type_QMARK_")

var Lit_337 *jrt.String = jrt.Intern("arbace.g2a.print_code$func_decl")

var Lit_338 *jrt.String = jrt.Intern("arbace.g2a.print_code$spec_name")

var Lit_339 *jrt.String = jrt.Intern("arbace.g2a.print_code$value_spec")

var Lit_340 *jrt.String = jrt.Intern("arbace.g2a.print_code$keep_type_column")

var Lit_341 *jrt.String = jrt.Intern("arbace.g2a.print_code$spec_t")

var Lit_342 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_decl")

var Lit_343 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl")

var Lit_344 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_spec")

var Lit_345 *jrt.String = jrt.Intern("arbace.g2a.print_code$parse_type_spec")

var Lit_346 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_decl")

var Lit_347 *jrt.String = jrt.Intern("arbace.g2a.print_code$decl_doc_and_directives")

var Lit_348 *jrt.String = jrt.Intern("arbace.g2a.print_code$top_decl")
