//line a2g_strings.ae:1
package aot_arbace_g2a_print_code

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.print-emit")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("e")

var Lit_6 *jrt.String = jrt.Intern("tok")

var Lit_7 *jrt.String = jrt.Intern("sp")

var Lit_8 *jrt.String = jrt.Intern("vtab")

var Lit_9 *jrt.String = jrt.Intern("arbace.g2a.print-text")

var Lit_10 *jrt.String = jrt.Intern("text")

var Lit_11 *jrt.String = jrt.Intern("arbace.string")

var Lit_12 *jrt.String = jrt.Intern("str")

var Lit_13 *jrt.String = jrt.Intern("commute")

var Lit_14 *jrt.String = jrt.Intern("deref")

var Lit_15 *jrt.String = jrt.Intern("conj")

var Lit_16 *jrt.String = jrt.Intern("arbace.g2a.print-code")

var Lit_17 *jrt.String = jrt.Intern("doc")

var Lit_18 *jrt.String = jrt.Intern("g2a's printer, the forms level (doc/go/PRINTER-NOTES.md): Go forms (doc/go/SPEC.md) to Go\n  tokens through arbace.g2a.print-emit. Types (§5), declarations (§6), statements and\n  expressions (§7), literals (§8), directives and doc comments (§9, §10.4), files (§4.3).\n\n  Every form is classified by its head and position (§4.4); nothing is resolved. Spacing\n  follows go/printer (go1.27.1 src/go/printer/nodes.go: binaryExpr, cutoff, walkBinary,\n  the depth rules of exprList, controlClause, funcBody, fieldList, valueSpec, keepTypeColumn)\n  so that gofmt leaves the output as it is.")

var Lit_19 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_20 *jrt.String = jrt.Intern("contains?")

var Lit_21 *jrt.String = jrt.Intern("some")

var Lit_22 *jrt.String = jrt.Intern("coll?")

var Lit_23 *jrt.String = jrt.Intern("go")

var Lit_24 *jrt.String = jrt.Intern("grouped")

var Lit_25 *jrt.String = jrt.Intern("vals")

var Lit_26 *jrt.String = jrt.Intern("dissoc")

var Lit_27 *jrt.String = jrt.Intern("line")

var Lit_28 *jrt.String = jrt.Intern("column")

var Lit_29 *jrt.String = jrt.Intern("map?")

var Lit_30 *jrt.String = jrt.Intern("ex-info")

var Lit_31 *jrt.String = jrt.Intern("pr-str")

var Lit_32 *jrt.String = jrt.Intern("form")

var Lit_33 *jrt.String = jrt.Intern("seq?")

var Lit_34 *jrt.String = jrt.Intern("first")

var Lit_35 *jrt.String = jrt.Intern("symbol?")

var Lit_36 *jrt.String = jrt.Intern("namespace")

var Lit_37 *jrt.String = jrt.Intern("name")

var Lit_38 *jrt.String = jrt.Intern("*go-ns*")

var Lit_39 *jrt.String = jrt.Intern("clojure.core")

var Lit_40 *jrt.String = jrt.Intern("else")

var Lit_41 *jrt.String = jrt.Intern("rest")

var Lit_42 *jrt.String = jrt.Intern("binary-ops")

var Lit_43 *jrt.String = jrt.Intern("op")

var Lit_44 *jrt.String = jrt.Intern("number?")

var Lit_45 *jrt.String = jrt.Intern("negative-number?")

var Lit_46 *jrt.String = jrt.Intern("negative-literal?")

var Lit_47 *jrt.String = jrt.Intern("unary-ops")

var Lit_48 *jrt.String = jrt.Intern("second")

var Lit_49 *jrt.String = jrt.Intern("binary?")

var Lit_50 *jrt.String = jrt.Intern("bin-prec")

var Lit_51 *jrt.String = jrt.Intern("unary?")

var Lit_52 *jrt.String = jrt.Intern("stmt-heads")

var Lit_53 *jrt.String = jrt.Intern("not")

var Lit_54 *jrt.String = jrt.Intern("statement-form?")

var Lit_55 *jrt.String = jrt.Intern("keyword?")

var Lit_56 *jrt.String = jrt.Intern("vector?")

var Lit_57 *jrt.String = jrt.Intern("lines?")

var Lit_58 *jrt.String = jrt.Intern("*p*")

var Lit_59 *jrt.String = jrt.Intern("integer?")

var Lit_60 *jrt.String = jrt.Intern("set")

var Lit_61 *jrt.String = jrt.Intern("map")

var Lit_62 *jrt.String = jrt.Intern("breaks")

var Lit_63 *jrt.String = jrt.Intern("line-of")

var Lit_64 *jrt.String = jrt.Intern("break-line")

var Lit_65 *jrt.String = jrt.Intern("break")

var Lit_66 *jrt.String = jrt.Intern("breaks-of")

var Lit_67 *jrt.String = jrt.Intern("child-target")

var Lit_68 *jrt.String = jrt.Intern("vec")

var Lit_69 *jrt.String = jrt.Intern("room?")

var Lit_70 *jrt.String = jrt.Intern("*next*")

var Lit_71 *jrt.String = jrt.Intern("mapv")

var Lit_72 *jrt.String = jrt.Intern("range")

var Lit_73 *jrt.String = jrt.Intern("break-to!")

var Lit_74 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_75 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_76 *jrt.String = jrt.Intern("hash-map")

var Lit_77 *jrt.String = jrt.Intern("go-sym?")

var Lit_78 *jrt.String = jrt.Intern("fail")

var Lit_79 *jrt.String = jrt.Intern("seq")

var Lit_80 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_81 *jrt.String = jrt.Intern("chunk-first")

var Lit_82 *jrt.String = jrt.Intern("map-indexed")

var Lit_83 *jrt.String = jrt.Intern("vector")

var Lit_84 *jrt.String = jrt.Intern("ident-string")

var Lit_85 *jrt.String = jrt.Intern("chunk-rest")

var Lit_86 *jrt.String = jrt.Intern("next")

var Lit_87 *jrt.String = jrt.Intern("src")

var Lit_88 *jrt.String = jrt.Intern("names")

var Lit_89 *jrt.String = jrt.Intern("true?")

var Lit_90 *jrt.String = jrt.Intern("false?")

var Lit_91 *jrt.String = jrt.Intern("string?")

var Lit_92 *jrt.String = jrt.Intern("includes?")

var Lit_93 *jrt.String = jrt.Intern("raw-string-ok?")

var Lit_94 *jrt.String = jrt.Intern("raw-tok")

var Lit_95 *jrt.String = jrt.Intern("char?")

var Lit_96 *jrt.String = jrt.Intern("go-string")

var Lit_97 *jrt.String = jrt.Intern("go-rune")

var Lit_98 *jrt.String = jrt.Intern("go-number")

var Lit_99 *jrt.String = jrt.Intern("to-array")

var Lit_100 *jrt.String = jrt.Intern("parent")

var Lit_101 *jrt.String = jrt.Intern("offset")

var Lit_102 *jrt.String = jrt.Intern("end")

var Lit_103 *jrt.String = jrt.Intern("target")

var Lit_104 *jrt.String = jrt.Intern("next-targets")

var Lit_105 *jrt.String = jrt.Intern("pop-open!")

var Lit_106 *jrt.String = jrt.Intern("here")

var Lit_107 *jrt.String = jrt.Intern("peek")

var Lit_108 *jrt.String = jrt.Intern("push-open!")

var Lit_109 *jrt.String = jrt.Intern("close-break!")

var Lit_110 *jrt.String = jrt.Intern("tag")

var Lit_111 *jrt.String = jrt.Intern("&")

var Lit_112 *jrt.String = jrt.Intern("tagged?")

var Lit_113 *jrt.String = jrt.Intern("type")

var Lit_114 *jrt.String = jrt.Intern("variadic?")

var Lit_115 *jrt.String = jrt.Intern("meta")

var Lit_116 *jrt.String = jrt.Intern("*explicit-groups*")

var Lit_117 *jrt.String = jrt.Intern("*generic*")

var Lit_118 *jrt.String = jrt.Intern("reduce")

var Lit_119 *jrt.String = jrt.Intern("groupable?")

var Lit_120 *jrt.String = jrt.Intern("entries")

var Lit_121 *jrt.String = jrt.Intern("pop")

var Lit_122 *jrt.String = jrt.Intern("update")

var Lit_123 *jrt.String = jrt.Intern("assoc")

var Lit_124 *jrt.String = jrt.Intern("group-entries")

var Lit_125 *jrt.String = jrt.Intern("element-list")

var Lit_126 *jrt.String = jrt.Intern("param-entries")

var Lit_127 *jrt.String = jrt.Intern("type-expr")

var Lit_128 *jrt.String = jrt.Intern("name-list")

var Lit_129 *jrt.String = jrt.Intern("variadic-elem")

var Lit_130 *jrt.String = jrt.Intern("group-line")

var Lit_131 *jrt.String = jrt.Intern("empty?")

var Lit_132 *jrt.String = jrt.Intern("param-list")

var Lit_133 *jrt.String = jrt.Intern("bol")

var Lit_134 *jrt.String = jrt.Intern("indent")

var Lit_135 *jrt.String = jrt.Intern("cur-indent")

var Lit_136 *jrt.String = jrt.Intern("print-results")

var Lit_137 *jrt.String = jrt.Intern("next-line")

var Lit_138 *jrt.String = jrt.Intern("signature")

var Lit_139 *jrt.String = jrt.Intern("split")

var Lit_140 *jrt.String = jrt.Intern("\\n")

var Lit_141 *jrt.String = jrt.Intern("not=")

var Lit_142 *jrt.String = jrt.Intern("doc-lines")

var Lit_143 *jrt.String = jrt.Intern("comment-line")

var Lit_144 *jrt.String = jrt.Intern("starts-with?")

var Lit_145 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_146 *jrt.String = jrt.Intern("chunk-append")

var Lit_147 *jrt.String = jrt.Intern("chunk-cons")

var Lit_148 *jrt.String = jrt.Intern("cons")

var Lit_149 *jrt.String = jrt.Intern("chunk")

var Lit_150 *jrt.String = jrt.Intern("concat")

var Lit_151 *jrt.String = jrt.Intern("sort-by")

var Lit_152 *jrt.String = jrt.Intern("comp")

var Lit_153 *jrt.String = jrt.Intern("filter")

var Lit_154 *jrt.String = jrt.Intern("key")

var Lit_155 *jrt.String = jrt.Intern("non-directive-keys")

var Lit_156 *jrt.String = jrt.Intern("write-doc")

var Lit_157 *jrt.String = jrt.Intern("results")

var Lit_158 *jrt.String = jrt.Intern("results-entries")

var Lit_159 *jrt.String = jrt.Intern("interface-method?")

var Lit_160 *jrt.String = jrt.Intern("render")

var Lit_161 *jrt.String = jrt.Intern("iface-method-sig")

var Lit_162 *jrt.String = jrt.Intern("nnext")

var Lit_163 *jrt.String = jrt.Intern("struct-tag")

var Lit_164 *jrt.String = jrt.Intern("struct-fields")

var Lit_165 *jrt.String = jrt.Intern("one-line-fields?")

var Lit_166 *jrt.String = jrt.Intern("volatile!")

var Lit_167 *jrt.String = jrt.Intern("field-body")

var Lit_168 *jrt.String = jrt.Intern("nl")

var Lit_169 *jrt.String = jrt.Intern("pre-lines")

var Lit_170 *jrt.String = jrt.Intern("stmt-break!")

var Lit_171 *jrt.String = jrt.Intern("vreset!")

var Lit_172 *jrt.String = jrt.Intern("subvec")

var Lit_173 *jrt.String = jrt.Intern("recv")

var Lit_174 *jrt.String = jrt.Intern("send")

var Lit_175 *jrt.String = jrt.Intern("field-list")

var Lit_176 *jrt.String = jrt.Intern("type-list")

var Lit_177 *jrt.String = jrt.Intern("func-type-sig")

var Lit_178 *jrt.String = jrt.Intern("args")

var Lit_179 *jrt.String = jrt.Intern("chan-type")

var Lit_180 *jrt.String = jrt.Intern("...")

var Lit_181 *jrt.String = jrt.Intern("expr0")

var Lit_182 *jrt.String = jrt.Intern("*header*")

var Lit_183 *jrt.String = jrt.Intern("type-heads")

var Lit_184 *jrt.String = jrt.Intern("begins-with-star-or-paren?")

var Lit_185 *jrt.String = jrt.Intern("any")

var Lit_186 *jrt.String = jrt.Intern("walk-binary")

var Lit_187 *jrt.String = jrt.Intern("unary-op")

var Lit_188 *jrt.String = jrt.Intern("&&")

var Lit_189 *jrt.String = jrt.Intern("/*")

var Lit_190 *jrt.String = jrt.Intern("&^")

var Lit_191 *jrt.String = jrt.Intern("++")

var Lit_192 *jrt.String = jrt.Intern("--")

var Lit_193 *jrt.String = jrt.Intern("bin-op")

var Lit_194 *jrt.String = jrt.Intern("walk-right")

var Lit_195 *jrt.String = jrt.Intern("walk-prefixes")

var Lit_196 *jrt.String = jrt.Intern("cutoff-of")

var Lit_197 *jrt.String = jrt.Intern("reduce-depth")

var Lit_198 *jrt.String = jrt.Intern("paren")

var Lit_199 *jrt.String = jrt.Intern("paren-operand")

var Lit_200 *jrt.String = jrt.Intern("expr1")

var Lit_201 *jrt.String = jrt.Intern("diff-prec")

var Lit_202 *jrt.String = jrt.Intern("kind")

var Lit_203 *jrt.String = jrt.Intern("field")

var Lit_204 *jrt.String = jrt.Intern("value")

var Lit_205 *jrt.String = jrt.Intern("i")

var Lit_206 *jrt.String = jrt.Intern("pos")

var Lit_207 *jrt.String = jrt.Intern("lit-type-needs-parens?")

var Lit_208 *jrt.String = jrt.Intern("_")

var Lit_209 *jrt.String = jrt.Intern("lit-elements")

var Lit_210 *jrt.String = jrt.Intern("into")

var Lit_211 *jrt.String = jrt.Intern("repeat")

var Lit_212 *jrt.String = jrt.Intern("line-indent")

var Lit_213 *jrt.String = jrt.Intern("block-body")

var Lit_214 *jrt.String = jrt.Intern("results?")

var Lit_215 *jrt.String = jrt.Intern("func?")

var Lit_216 *jrt.String = jrt.Intern("sep")

var Lit_217 *jrt.String = jrt.Intern("body-offset")

var Lit_218 *jrt.String = jrt.Intern("type-form?")

var Lit_219 *jrt.String = jrt.Intern("binary-expr")

var Lit_220 *jrt.String = jrt.Intern("unary-operand")

var Lit_221 *jrt.String = jrt.Intern("prec-of")

var Lit_222 *jrt.String = jrt.Intern("literal")

var Lit_223 *jrt.String = jrt.Intern("func-lit")

var Lit_224 *jrt.String = jrt.Intern("slice-expr")

var Lit_225 *jrt.String = jrt.Intern("call-args")

var Lit_226 *jrt.String = jrt.Intern("cutoff")

var Lit_227 *jrt.String = jrt.Intern("func")

var Lit_228 *jrt.String = jrt.Intern("chan")

var Lit_229 *jrt.String = jrt.Intern("*")

var Lit_230 *jrt.String = jrt.Intern("composite-lit")

var Lit_231 *jrt.String = jrt.Intern("new-arg")

var Lit_232 *jrt.String = jrt.Intern("go-byte-string")

var Lit_233 *jrt.String = jrt.Intern("subs")

var Lit_234 *jrt.String = jrt.Intern("callee")

var Lit_235 *jrt.String = jrt.Intern("comma-list")

var Lit_236 *jrt.String = jrt.Intern("targets")

var Lit_237 *jrt.String = jrt.Intern("const")

var Lit_238 *jrt.String = jrt.Intern("var")

var Lit_239 *jrt.String = jrt.Intern("expr-list")

var Lit_240 *jrt.String = jrt.Intern("zero-form?")

var Lit_241 *jrt.String = jrt.Intern("n-values")

var Lit_242 *jrt.String = jrt.Intern("type-params")

var Lit_243 *jrt.String = jrt.Intern("alias")

var Lit_244 *jrt.String = jrt.Intern("assign-ops")

var Lit_245 *jrt.String = jrt.Intern("simple-stmt")

var Lit_246 *jrt.String = jrt.Intern("binding-stmt")

var Lit_247 *jrt.String = jrt.Intern("assign-stmt")

var Lit_248 *jrt.String = jrt.Intern("case")

var Lit_249 *jrt.String = jrt.Intern("default")

var Lit_250 *jrt.String = jrt.Intern("some?")

var Lit_251 *jrt.String = jrt.Intern("cond")

var Lit_252 *jrt.String = jrt.Intern("if")

var Lit_253 *jrt.String = jrt.Intern("when")

var Lit_254 *jrt.String = jrt.Intern("if-like?")

var Lit_255 *jrt.String = jrt.Intern("print-stmt")

var Lit_256 *jrt.String = jrt.Intern("branch-forms")

var Lit_257 *jrt.String = jrt.Intern("partition")

var Lit_258 *jrt.String = jrt.Intern("else-part")

var Lit_259 *jrt.String = jrt.Intern("odd?")

var Lit_260 *jrt.String = jrt.Intern("branch-opts")

var Lit_261 *jrt.String = jrt.Intern("control-clause")

var Lit_262 *jrt.String = jrt.Intern("merge")

var Lit_263 *jrt.String = jrt.Intern("else-follows?")

var Lit_264 *jrt.String = jrt.Intern("else-block?")

var Lit_265 *jrt.String = jrt.Intern("stmt-list")

var Lit_266 *jrt.String = jrt.Intern("clause?")

var Lit_267 *jrt.String = jrt.Intern("clause-list")

var Lit_268 *jrt.String = jrt.Intern("case-exprs")

var Lit_269 *jrt.String = jrt.Intern("remove")

var Lit_270 *jrt.String = jrt.Intern("nil?")

var Lit_271 *jrt.String = jrt.Intern("case-types")

var Lit_272 *jrt.String = jrt.Intern("comm")

var Lit_273 *jrt.String = jrt.Intern("assign")

var Lit_274 *jrt.String = jrt.Intern("range-stmt")

var Lit_275 *jrt.String = jrt.Intern("label-name")

var Lit_276 *jrt.String = jrt.Intern("while-stmt")

var Lit_277 *jrt.String = jrt.Intern("if-stmt")

var Lit_278 *jrt.String = jrt.Intern("for-stmt")

var Lit_279 *jrt.String = jrt.Intern("select-stmt")

var Lit_280 *jrt.String = jrt.Intern("type-switch-stmt")

var Lit_281 *jrt.String = jrt.Intern("label-stmt")

var Lit_282 *jrt.String = jrt.Intern("switch-stmt")

var Lit_283 *jrt.String = jrt.Intern("mapcat")

var Lit_284 *jrt.String = jrt.Intern("let")

var Lit_285 *jrt.String = jrt.Intern("let-type")

var Lit_286 *jrt.String = jrt.Intern("bind")

var Lit_287 *jrt.String = jrt.Intern("t")

var Lit_288 *jrt.String = jrt.Intern("type-bind")

var Lit_289 *jrt.String = jrt.Intern("flatten-stmts")

var Lit_290 *jrt.String = jrt.Intern("bind-target")

var Lit_291 *jrt.String = jrt.Intern("const-bind?")

var Lit_292 *jrt.String = jrt.Intern("const-group")

var Lit_293 *jrt.String = jrt.Intern("label")

var Lit_294 *jrt.String = jrt.Intern("implicit")

var Lit_295 *jrt.String = jrt.Intern("keep-type-column")

var Lit_296 *jrt.String = jrt.Intern("none")

var Lit_297 *jrt.String = jrt.Intern("const-spec")

var Lit_298 *jrt.String = jrt.Intern("group-consts")

var Lit_299 *jrt.String = jrt.Intern("item-t")

var Lit_300 *jrt.String = jrt.Intern("label-of")

var Lit_301 *jrt.String = jrt.Intern("apply")

var Lit_302 *jrt.String = jrt.Intern("expression-form?")

var Lit_303 *jrt.String = jrt.Intern("group-target")

var Lit_304 *jrt.String = jrt.Intern("type-binding-stmt")

var Lit_305 *jrt.String = jrt.Intern("every?")

var Lit_306 *jrt.String = jrt.Intern("stmt-list-one-line")

var Lit_307 *jrt.String = jrt.Intern("parse-decl-head")

var Lit_308 *jrt.String = jrt.Intern("extern")

var Lit_309 *jrt.String = jrt.Intern("with-meta")

var Lit_310 *jrt.String = jrt.Intern("generic-type?")

var Lit_311 *jrt.String = jrt.Intern("transient")

var Lit_312 *jrt.String = jrt.Intern("persistent!")

var Lit_313 *jrt.String = jrt.Intern("assoc!")

var Lit_314 *jrt.String = jrt.Intern("spec-name")

var Lit_315 *jrt.String = jrt.Intern("directives-of")

var Lit_316 *jrt.String = jrt.Intern("spec-t")

var Lit_317 *jrt.String = jrt.Intern("write-pre")

var Lit_318 *jrt.String = jrt.Intern("group-decl")

var Lit_319 *jrt.String = jrt.Intern("value-spec")

var Lit_320 *jrt.String = jrt.Intern("parse-type-spec")

var Lit_321 *jrt.String = jrt.Intern("type-spec")

var Lit_322 *jrt.String = jrt.Intern("type-decl")

var Lit_323 *jrt.String = jrt.Intern("func-decl")

var Lit_324 *jrt.String = jrt.Intern("const-var-decl")

var Lit_325 *jrt.String = jrt.Intern("arbace.g2a.print_code$args")

var Lit_326 *jrt.String = jrt.Intern("arbace.g2a.print_code$assign_stmt")

var Lit_327 *jrt.String = jrt.Intern("=")

var Lit_328 *jrt.String = jrt.Intern("not an assignment operator")

var Lit_329 *jrt.String = jrt.Intern("set! takes 2 or 3 arguments")

var Lit_330 *jrt.String = jrt.Intern("arbace.g2a.print_code$begins_with_star_or_paren_QMARK_")

var Lit_331 *jrt.String = jrt.Intern("|")

var Lit_332 *jrt.String = jrt.Intern("arbace.g2a.print_code$bin_op")

var Lit_333 *jrt.String = jrt.Intern("arbace.g2a.print_code$bin_prec")

var Lit_334 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_QMARK_")

var Lit_335 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_expr")

var Lit_336 *jrt.String = jrt.Intern("(")

var Lit_337 *jrt.String = jrt.Intern(")")

var Lit_338 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_expr$fn__1022000253")

var Lit_339 *jrt.String = jrt.Intern("arbace.g2a.print_code$binary_expr$fn__1022000255")

var Lit_340 *jrt.String = jrt.Intern("arbace.g2a.print_code$bind_target")

var Lit_341 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt")

var Lit_342 *jrt.String = jrt.Intern(":=")

var Lit_343 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt$fn__1022000369")

var Lit_344 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt$fn__1022000373")

var Lit_345 *jrt.String = jrt.Intern("arbace.g2a.print_code$binding_stmt$names__1022000371")

var Lit_346 *jrt.String = jrt.Intern("arbace.g2a.print_code$block_body")

var Lit_347 *jrt.String = jrt.Intern("{")

var Lit_348 *jrt.String = jrt.Intern("}")

var Lit_349 *jrt.String = jrt.Intern("arbace.g2a.print_code$block_body$fn__1022000557")

var Lit_350 *jrt.String = jrt.Intern("arbace.g2a.print_code$block_body$fn__1022000559")

var Lit_351 *jrt.String = jrt.Intern("arbace.g2a.print_code$body_offset")

var Lit_352 *jrt.String = jrt.Intern("arbace.g2a.print_code$branch_forms")

var Lit_353 *jrt.String = jrt.Intern("do")

var Lit_354 *jrt.String = jrt.Intern("arbace.g2a.print_code$branch_opts")

var Lit_355 *jrt.String = jrt.Intern("arbace.g2a.print_code$break_line")

var Lit_356 *jrt.String = jrt.Intern("arbace.g2a.print_code$break_line$fn__1022000035")

var Lit_357 *jrt.String = jrt.Intern("arbace.g2a.print_code$breaks_of")

var Lit_358 *jrt.String = jrt.Intern("arbace.g2a.print_code$breaks_of$fn__1022000031")

var Lit_359 *jrt.String = jrt.Intern("arbace.g2a.print_code$call_args")

var Lit_360 *jrt.String = jrt.Intern("arbace.g2a.print_code$call_args$fn__1022000258")

var Lit_361 *jrt.String = jrt.Intern("spread")

var Lit_362 *jrt.String = jrt.Intern("arbace.g2a.print_code$callee")

var Lit_363 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_exprs")

var Lit_364 *jrt.String = jrt.Intern("case needs a vector")

var Lit_365 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_exprs$fn__1022000446")

var Lit_366 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_types")

var Lit_367 *jrt.String = jrt.Intern("arbace.g2a.print_code$case_types$fn__1022000450")

var Lit_368 *jrt.String = jrt.Intern("nil")

var Lit_369 *jrt.String = jrt.Intern("arbace.g2a.print_code$chan_type")

var Lit_370 *jrt.String = jrt.Intern("<-")

var Lit_371 *jrt.String = jrt.Intern("bad channel direction")

var Lit_372 *jrt.String = jrt.Intern("arbace.g2a.print_code$child_target")

var Lit_373 *jrt.String = jrt.Intern("arbace.g2a.print_code$clause_QMARK_")

var Lit_374 *jrt.String = jrt.Intern("arbace.g2a.print_code$clause_list")

var Lit_375 *jrt.String = jrt.Intern("not a case or default clause")

var Lit_376 *jrt.String = jrt.Intern("arbace.g2a.print_code$clause_list$fn__1022000439")

var Lit_377 *jrt.String = jrt.Intern(";")

var Lit_378 *jrt.String = jrt.Intern(":")

var Lit_379 *jrt.String = jrt.Intern("arbace.g2a.print_code$comm")

var Lit_380 *jrt.String = jrt.Intern("arbace.g2a.print_code$comma_list")

var Lit_381 *jrt.String = jrt.Intern(",")

var Lit_382 *jrt.String = jrt.Intern("arbace.g2a.print_code$comma_list$fn__1022000043")

var Lit_383 *jrt.String = jrt.Intern("arbace.g2a.print_code$comma_list$fn__1022000045")

var Lit_384 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit")

var Lit_385 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265")

var Lit_386 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000266")

var Lit_387 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000268")

var Lit_388 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000277")

var Lit_389 *jrt.String = jrt.Intern("arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000283")

var Lit_390 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_bind_QMARK_")

var Lit_391 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_bind_QMARK_$fn__1022000522")

var Lit_392 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_group")

var Lit_393 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_group$fn__1022000538")

var Lit_394 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_group$fn__1022000543")

var Lit_395 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_spec")

var Lit_396 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_spec$fn__1022000534")

var Lit_397 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl")

var Lit_398 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl$fn__1022000636")

var Lit_399 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl$fn__1022000638")

var Lit_400 *jrt.String = jrt.Intern("arbace.g2a.print_code$const_var_decl$fn__1022000643")

var Lit_401 *jrt.String = jrt.Intern("arbace.g2a.print_code$control_clause")

var Lit_402 *jrt.String = jrt.Intern("arbace.g2a.print_code$cutoff")

var Lit_403 *jrt.String = jrt.Intern("arbace.g2a.print_code$cutoff_of")

var Lit_404 *jrt.String = jrt.Intern("arbace.g2a.print_code$decl_doc_and_directives")

var Lit_405 *jrt.String = jrt.Intern("go/type")

var Lit_406 *jrt.String = jrt.Intern("go/func")

var Lit_407 *jrt.String = jrt.Intern("go/const")

var Lit_408 *jrt.String = jrt.Intern("go/var")

var Lit_409 *jrt.String = jrt.Intern("go/method")

var Lit_410 *jrt.String = jrt.Intern("arbace.g2a.print_code$diff_prec")

var Lit_411 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of")

var Lit_412 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$fn__1022000124")

var Lit_413 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110")

var Lit_414 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111")

var Lit_415 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115")

var Lit_416 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115$fn__1022000116")

var Lit_417 *jrt.String = jrt.Intern("//go:")

var Lit_418 *jrt.String = jrt.Intern(" ")

var Lit_419 *jrt.String = jrt.Intern("arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115$fn__1022000116$fn__1022000117")

var Lit_420 *jrt.String = jrt.Intern("arbace.g2a.print_code$doc_lines")

var Lit_421 *jrt.String = jrt.Intern("")

var Lit_422 *jrt.String = jrt.Intern("arbace.g2a.print_code$element_list")

var Lit_423 *jrt.String = jrt.Intern("fn")

var Lit_424 *jrt.String = jrt.Intern("arbace.g2a.print_code$element_list$fn__1022000068")

var Lit_425 *jrt.String = jrt.Intern("arbace.g2a.print_code$element_list$fn__1022000070")

var Lit_426 *jrt.String = jrt.Intern("arbace.g2a.print_code$else_part")

var Lit_427 *jrt.String = jrt.Intern("arbace.g2a.print_code$eval1022000004$loading__1927001464__auto____1022000005")

var Lit_428 *jrt.String = jrt.Intern("arbace.g2a.print_code$eval1022000008$fn__1022000009")

var Lit_429 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr0")

var Lit_430 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1")

var Lit_431 *jrt.String = jrt.Intern("imaginary")

var Lit_432 *jrt.String = jrt.Intern("subslice")

var Lit_433 *jrt.String = jrt.Intern("method-expr")

var Lit_434 *jrt.String = jrt.Intern(".")

var Lit_435 *jrt.String = jrt.Intern("assert")

var Lit_436 *jrt.String = jrt.Intern("go/call")

var Lit_437 *jrt.String = jrt.Intern("go/id")

var Lit_438 *jrt.String = jrt.Intern("conv")

var Lit_439 *jrt.String = jrt.Intern("spread outside the arguments of a call")

var Lit_440 *jrt.String = jrt.Intern("zero")

var Lit_441 *jrt.String = jrt.Intern("zero outside a var binding")

var Lit_442 *jrt.String = jrt.Intern("make")

var Lit_443 *jrt.String = jrt.Intern("inst")

var Lit_444 *jrt.String = jrt.Intern("rune")

var Lit_445 *jrt.String = jrt.Intern("values")

var Lit_446 *jrt.String = jrt.Intern("values outside a return, an assignment or a binding")

var Lit_447 *jrt.String = jrt.Intern("lit")

var Lit_448 *jrt.String = jrt.Intern("aget")

var Lit_449 *jrt.String = jrt.Intern("[")

var Lit_450 *jrt.String = jrt.Intern("]")

var Lit_451 *jrt.String = jrt.Intern("new")

var Lit_452 *jrt.String = jrt.Intern("byte-string")

var Lit_453 *jrt.String = jrt.Intern("a statement in an expression position")

var Lit_454 *jrt.String = jrt.Intern(".-")

var Lit_455 *jrt.String = jrt.Intern("a keyword in an expression position")

var Lit_456 *jrt.String = jrt.Intern("a vector in an expression position")

var Lit_457 *jrt.String = jrt.Intern("not an expression")

var Lit_458 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000315")

var Lit_459 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000317")

var Lit_460 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000332")

var Lit_461 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000337")

var Lit_462 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000345")

var Lit_463 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr1$fn__1022000350")

var Lit_464 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr_list")

var Lit_465 *jrt.String = jrt.Intern("arbace.g2a.print_code$expr_list$fn__1022000361")

var Lit_466 *jrt.String = jrt.Intern("arbace.g2a.print_code$expression_form_QMARK_")

var Lit_467 *jrt.String = jrt.Intern("panic")

var Lit_468 *jrt.String = jrt.Intern("arbace.g2a.print_code$fail")

var Lit_469 *jrt.String = jrt.Intern(": ")

var Lit_470 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_body")

var Lit_471 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list")

var Lit_472 *jrt.String = jrt.Intern("{}")

var Lit_473 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000164")

var Lit_474 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000166")

var Lit_475 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000168")

var Lit_476 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$fn__1022000180")

var Lit_477 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$iter__1022000154__1022000158")

var Lit_478 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$iter__1022000154__1022000158$fn__1022000159")

var Lit_479 *jrt.String = jrt.Intern("arbace.g2a.print_code$field_list$iter__1022000154__1022000158$fn__1022000159$fn__1022000160")

var Lit_480 *jrt.String = jrt.Intern("arbace.g2a.print_code$flatten_stmts")

var Lit_481 *jrt.String = jrt.Intern("arbace.g2a.print_code$flatten_stmts$fn__1022000503")

var Lit_482 *jrt.String = jrt.Intern("let needs a binding vector")

var Lit_483 *jrt.String = jrt.Intern("let needs pairs")

var Lit_484 *jrt.String = jrt.Intern("arbace.g2a.print_code$flatten_stmts$fn__1022000503$fn__1022000508")

var Lit_485 *jrt.String = jrt.Intern("arbace.g2a.print_code$for_stmt")

var Lit_486 *jrt.String = jrt.Intern("for needs an init vector")

var Lit_487 *jrt.String = jrt.Intern("for")

var Lit_488 *jrt.String = jrt.Intern("arbace.g2a.print_code$func_decl")

var Lit_489 *jrt.String = jrt.Intern("a function needs a parameter vector")

var Lit_490 *jrt.String = jrt.Intern("arbace.g2a.print_code$func_lit")

var Lit_491 *jrt.String = jrt.Intern("fn needs a parameter vector")

var Lit_492 *jrt.String = jrt.Intern("arbace.g2a.print_code$func_type_sig")

var Lit_493 *jrt.String = jrt.Intern("arbace.g2a.print_code$generic_type_QMARK_")

var Lit_494 *jrt.String = jrt.Intern("arbace.g2a.print_code$go_sym_QMARK_")

var Lit_495 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_consts")

var Lit_496 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_consts$fn__1022000525")

var Lit_497 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_decl")

var Lit_498 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_decl$fn__1022000627")

var Lit_499 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_entries")

var Lit_500 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_entries$fn__1022000077")

var Lit_501 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_entries$fn__1022000079")

var Lit_502 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_line")

var Lit_503 *jrt.String = jrt.Intern("arbace.g2a.print_code$group_target")

var Lit_504 *jrt.String = jrt.Intern("arbace.g2a.print_code$groupable_QMARK_")

var Lit_505 *jrt.String = jrt.Intern("arbace.g2a.print_code$ident_string")

var Lit_506 *jrt.String = jrt.Intern("not a name")

var Lit_507 *jrt.String = jrt.Intern("arbace.g2a.print_code$if_like_QMARK_")

var Lit_508 *jrt.String = jrt.Intern("arbace.g2a.print_code$if_stmt")

var Lit_509 *jrt.String = jrt.Intern("cond takes test-branch pairs")

var Lit_510 *jrt.String = jrt.Intern("if takes a condition, then and else")

var Lit_511 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_512 *jrt.String = jrt.Intern("arbace.g2a.print_code$iface_method_sig")

var Lit_513 *jrt.String = jrt.Intern("arbace.g2a.print_code$interface_method_QMARK_")

var Lit_514 *jrt.String = jrt.Intern("arbace.g2a.print_code$item_t")

var Lit_515 *jrt.String = jrt.Intern("arbace.g2a.print_code$keep_type_column")

var Lit_516 *jrt.String = jrt.Intern("arbace.g2a.print_code$keep_type_column$fn__1022000615")

var Lit_517 *jrt.String = jrt.Intern("arbace.g2a.print_code$key_size")

var Lit_518 *jrt.String = jrt.Intern("arbace.g2a.print_code$label_name")

var Lit_519 *jrt.String = jrt.Intern("not a label")

var Lit_520 *jrt.String = jrt.Intern("arbace.g2a.print_code$label_of")

var Lit_521 *jrt.String = jrt.Intern("arbace.g2a.print_code$label_stmt")

var Lit_522 *jrt.String = jrt.Intern("arbace.g2a.print_code$line_indent")

var Lit_523 *jrt.String = jrt.Intern("arbace.g2a.print_code$line_of")

var Lit_524 *jrt.String = jrt.Intern("arbace.g2a.print_code$lit_elements")

var Lit_525 *jrt.String = jrt.Intern("a field key without a value")

var Lit_526 *jrt.String = jrt.Intern("a key-value element is [key value]")

var Lit_527 *jrt.String = jrt.Intern("arbace.g2a.print_code$lit_type_needs_parens_QMARK_")

var Lit_528 *jrt.String = jrt.Intern("arbace.g2a.print_code$literal")

var Lit_529 *jrt.String = jrt.Intern("true")

var Lit_530 *jrt.String = jrt.Intern("false")

var Lit_531 *jrt.String = jrt.Intern("\n")

var Lit_532 *jrt.String = jrt.Intern("`")

var Lit_533 *jrt.String = jrt.Intern("not a literal")

var Lit_534 *jrt.String = jrt.Intern("arbace.g2a.print_code$n_values")

var Lit_535 *jrt.String = jrt.Intern("arbace.g2a.print_code$name_list")

var Lit_536 *jrt.String = jrt.Intern("arbace.g2a.print_code$negative_literal_QMARK_")

var Lit_537 *jrt.String = jrt.Intern("arbace.g2a.print_code$new_arg")

var Lit_538 *jrt.String = jrt.Intern("arbace.g2a.print_code$next_line")

var Lit_539 *jrt.String = jrt.Intern("arbace.g2a.print_code$next_targets")

var Lit_540 *jrt.String = jrt.Intern("arbace.g2a.print_code$one_line_fields_QMARK_")

var Lit_541 *jrt.String = jrt.Intern("arbace.g2a.print_code$one_line_fields_QMARK_$fn__1022000138")

var Lit_542 *jrt.String = jrt.Intern("arbace.g2a.print_code$op")

var Lit_543 *jrt.String = jrt.Intern("go/")

var Lit_544 *jrt.String = jrt.Intern("arbace.g2a.print_code$param_entries")

var Lit_545 *jrt.String = jrt.Intern("arbace.g2a.print_code$param_list")

var Lit_546 *jrt.String = jrt.Intern("arbace.g2a.print_code$param_list$fn__1022000087")

var Lit_547 *jrt.String = jrt.Intern("arbace.g2a.print_code$paren_operand")

var Lit_548 *jrt.String = jrt.Intern("arbace.g2a.print_code$paren_operand$fn__1022000249")

var Lit_549 *jrt.String = jrt.Intern("arbace.g2a.print_code$parse_decl_head")

var Lit_550 *jrt.String = jrt.Intern("arbace.g2a.print_code$parse_type_spec")

var Lit_551 *jrt.String = jrt.Intern("arbace.g2a.print_code$pre_lines")

var Lit_552 *jrt.String = jrt.Intern("arbace.g2a.print_code$prec_of")

var Lit_553 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_results")

var Lit_554 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_results$fn__1022000091")

var Lit_555 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_stmt")

var Lit_556 *jrt.String = jrt.Intern("goto")

var Lit_557 *jrt.String = jrt.Intern("fallthrough")

var Lit_558 *jrt.String = jrt.Intern("while")

var Lit_559 *jrt.String = jrt.Intern("defer")

var Lit_560 *jrt.String = jrt.Intern("inc!")

var Lit_561 *jrt.String = jrt.Intern("dec!")

var Lit_562 *jrt.String = jrt.Intern("aset")

var Lit_563 *jrt.String = jrt.Intern("continue")

var Lit_564 *jrt.String = jrt.Intern("select")

var Lit_565 *jrt.String = jrt.Intern("type-switch")

var Lit_566 *jrt.String = jrt.Intern("return")

var Lit_567 *jrt.String = jrt.Intern("switch")

var Lit_568 *jrt.String = jrt.Intern(">!")

var Lit_569 *jrt.String = jrt.Intern("set!")

var Lit_570 *jrt.String = jrt.Intern("arbace.g2a.print_code$print_stmt$fn__1022000500")

var Lit_571 *jrt.String = jrt.Intern("arbace.g2a.print_code$range_stmt")

var Lit_572 *jrt.String = jrt.Intern("range needs a vector")

var Lit_573 *jrt.String = jrt.Intern("arbace.g2a.print_code$range_stmt$fn__1022000493")

var Lit_574 *jrt.String = jrt.Intern("arbace.g2a.print_code$range_stmt$fn__1022000493$fn__1022000494")

var Lit_575 *jrt.String = jrt.Intern("arbace.g2a.print_code$reduce_depth")

var Lit_576 *jrt.String = jrt.Intern("arbace.g2a.print_code$results_entries")

var Lit_577 *jrt.String = jrt.Intern("arbace.g2a.print_code$room_QMARK_")

var Lit_578 *jrt.String = jrt.Intern("arbace.g2a.print_code$select_stmt")

var Lit_579 *jrt.String = jrt.Intern("arbace.g2a.print_code$signature")

var Lit_580 *jrt.String = jrt.Intern("arbace.g2a.print_code$simple_stmt")

var Lit_581 *jrt.String = jrt.Intern("an init vector holds one statement or one binding")

var Lit_582 *jrt.String = jrt.Intern("arbace.g2a.print_code$slice_expr")

var Lit_583 *jrt.String = jrt.Intern("arbace.g2a.print_code$slice_expr$fn__1022000292")

var Lit_584 *jrt.String = jrt.Intern("arbace.g2a.print_code$slice_expr$fn__1022000294")

var Lit_585 *jrt.String = jrt.Intern("arbace.g2a.print_code$spec_name")

var Lit_586 *jrt.String = jrt.Intern("arbace.g2a.print_code$spec_t")

var Lit_587 *jrt.String = jrt.Intern("arbace.g2a.print_code$statement_form_QMARK_")

var Lit_588 *jrt.String = jrt.Intern("arbace.g2a.print_code$stmt_list")

var Lit_589 *jrt.String = jrt.Intern("arbace.g2a.print_code$stmt_list$fn__1022000550")

var Lit_590 *jrt.String = jrt.Intern("go/directive")

var Lit_591 *jrt.String = jrt.Intern("arbace.g2a.print_code$stmt_list_one_line")

var Lit_592 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields")

var Lit_593 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145")

var Lit_594 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145$fn__1022000146")

var Lit_595 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145$fn__1022000146$fn__1022000147")

var Lit_596 *jrt.String = jrt.Intern("arbace.g2a.print_code$struct_tag")

var Lit_597 *jrt.String = jrt.Intern("arbace.g2a.print_code$switch_stmt")

var Lit_598 *jrt.String = jrt.Intern("arbace.g2a.print_code$switch_stmt$fn__1022000459")

var Lit_599 *jrt.String = jrt.Intern("arbace.g2a.print_code$tagged_QMARK_")

var Lit_600 *jrt.String = jrt.Intern("arbace.g2a.print_code$targets")

var Lit_601 *jrt.String = jrt.Intern("arbace.g2a.print_code$top_decl")

var Lit_602 *jrt.String = jrt.Intern("not a declaration")

var Lit_603 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_binding_stmt")

var Lit_604 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_decl")

var Lit_605 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_decl$fn__1022000663")

var Lit_606 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_decl$fn__1022000668")

var Lit_607 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_expr")

var Lit_608 *jrt.String = jrt.Intern("slice")

var Lit_609 *jrt.String = jrt.Intern("interface")

var Lit_610 *jrt.String = jrt.Intern("struct")

var Lit_611 *jrt.String = jrt.Intern("tilde")

var Lit_612 *jrt.String = jrt.Intern("~")

var Lit_613 *jrt.String = jrt.Intern("array")

var Lit_614 *jrt.String = jrt.Intern("not a type")

var Lit_615 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_expr$fn__1022000198")

var Lit_616 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_form_QMARK_")

var Lit_617 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_list")

var Lit_618 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_list$fn__1022000188")

var Lit_619 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_params")

var Lit_620 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_params$fn__1022000216")

var Lit_621 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_spec")

var Lit_622 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_switch_stmt")

var Lit_623 *jrt.String = jrt.Intern("arbace.g2a.print_code$type_switch_stmt$fn__1022000468")

var Lit_624 *jrt.String = jrt.Intern("arbace.g2a.print_code$unary_QMARK_")

var Lit_625 *jrt.String = jrt.Intern("arbace.g2a.print_code$unary_op")

var Lit_626 *jrt.String = jrt.Intern("-")

var Lit_627 *jrt.String = jrt.Intern("arbace.g2a.print_code$unary_operand")

var Lit_628 *jrt.String = jrt.Intern("arbace.g2a.print_code$uses_grouped_QMARK_")

var Lit_629 *jrt.String = jrt.Intern("arbace.g2a.print_code$uses_grouped_QMARK_$walk__1022000012")

var Lit_630 *jrt.String = jrt.Intern("arbace.g2a.print_code$value_spec")

var Lit_631 *jrt.String = jrt.Intern("arbace.g2a.print_code$value_spec$fn__1022000589")

var Lit_632 *jrt.String = jrt.Intern("arbace.g2a.print_code$variadic_elem")

var Lit_633 *jrt.String = jrt.Intern("variadic parameter not a slice")

var Lit_634 *jrt.String = jrt.Intern("arbace.g2a.print_code$walk_binary")

var Lit_635 *jrt.String = jrt.Intern("arbace.g2a.print_code$walk_prefixes")

var Lit_636 *jrt.String = jrt.Intern("arbace.g2a.print_code$walk_right")

var Lit_637 *jrt.String = jrt.Intern("/")

var Lit_638 *jrt.String = jrt.Intern("arbace.g2a.print_code$while_stmt")

var Lit_639 *jrt.String = jrt.Intern("arbace.g2a.print_code$while_stmt$fn__1022000486")

var Lit_640 *jrt.String = jrt.Intern("arbace.g2a.print_code$write_doc")

var Lit_641 *jrt.String = jrt.Intern("//")

var Lit_642 *jrt.String = jrt.Intern("\t")

var Lit_643 *jrt.String = jrt.Intern("// ")

var Lit_644 *jrt.String = jrt.Intern("arbace.g2a.print_code$write_pre")

var Lit_645 *jrt.String = jrt.Intern("arbace.g2a.print_code$zero_form_QMARK_")

var Lit_646 *jrt.String = jrt.Intern("in-ns")

var Lit_647 *jrt.String = jrt.Intern("declared")

var Lit_648 *jrt.String = jrt.Intern("file")

var Lit_649 *jrt.String = jrt.Intern("arbace/g2a/print_code.ae")

var Lit_650 *jrt.String = jrt.Intern("arbace.go")

var Lit_651 *jrt.String = jrt.Intern("dynamic")

var Lit_652 *jrt.String = jrt.Intern("The namespace qualifiers that name the Go forms' own heads (go/func, go/call, ...).")

var Lit_653 *jrt.String = jrt.Intern("True while printing the header of an if, for or switch outside brackets: a composite\n  literal of a type name needs parentheses there (§12.2).")

var Lit_654 *jrt.String = jrt.Intern("True when the file's forms mark grouped names with :go/grouped: then only marked names are\n  grouped (PRINTER-NOTES, amendment A1).")

var Lit_655 *jrt.String = jrt.Intern("uses-grouped?")

var Lit_656 *jrt.String = jrt.Intern("arglists")

var Lit_657 *jrt.String = jrt.Intern("forms")

var Lit_658 *jrt.String = jrt.Intern("Whether :go/grouped occurs in the metadata of forms.")

var Lit_659 *jrt.String = jrt.Intern("True inside a generic declaration: field groups are kept (doc/go/ROUNDTRIP.md, known gaps).")

var Lit_660 *jrt.String = jrt.Intern("private")

var Lit_661 *jrt.String = jrt.Intern("msg")

var Lit_662 *jrt.String = jrt.Intern("f")

var Lit_663 *jrt.String = jrt.Intern("The name of a list's head as the forms read it: an unqualified symbol's name,\n  \"go/name\" for the Go forms' qualified heads, \"deref\" for @; nil otherwise (a call of a\n  package member, of a list).")

var Lit_664 *jrt.String = jrt.Intern(">>")

var Lit_665 *jrt.String = jrt.Intern("!=")

var Lit_666 *jrt.String = jrt.Intern("%")

var Lit_667 *jrt.String = jrt.Intern("<=")

var Lit_668 *jrt.String = jrt.Intern("bit-or")

var Lit_669 *jrt.String = jrt.Intern("bit-xor")

var Lit_670 *jrt.String = jrt.Intern("^")

var Lit_671 *jrt.String = jrt.Intern("bit-and")

var Lit_672 *jrt.String = jrt.Intern("bit-and-not")

var Lit_673 *jrt.String = jrt.Intern("or")

var Lit_674 *jrt.String = jrt.Intern("||")

var Lit_675 *jrt.String = jrt.Intern(">=")

var Lit_676 *jrt.String = jrt.Intern("and")

var Lit_677 *jrt.String = jrt.Intern("<")

var Lit_678 *jrt.String = jrt.Intern("<<")

var Lit_679 *jrt.String = jrt.Intern("==")

var Lit_680 *jrt.String = jrt.Intern("+")

var Lit_681 *jrt.String = jrt.Intern(">")

var Lit_682 *jrt.String = jrt.Intern("A binary operator form: two or more operands (n-ary forms are left-nested chains).")

var Lit_683 *jrt.String = jrt.Intern("A unary operator form (Go's UnaryExpr or StarExpr), or a negative literal.")

var Lit_684 *jrt.String = jrt.Intern("The precedence of the Go expression a form prints as: 1-5 binary, 6 unary, 7 primary.")

var Lit_685 *jrt.String = jrt.Intern("An expression form other than a call of panic: the implicit return of §6.4.")

var Lit_686 *jrt.String = jrt.Intern("The child indexes in f's :go/breaks, a set: an entry is an index, or [index line] for a\n  literal whose Go line is not the line after the last one written before it (SPEC §10.1).")

var Lit_687 *jrt.String = jrt.Intern("The line :go/breaks records for child i of parent, when it records one.")

var Lit_688 *jrt.String = jrt.Intern("child")

var Lit_689 *jrt.String = jrt.Intern("brk")

var Lit_690 *jrt.String = jrt.Intern("The recorded line of child i of a list: its own, or the line of the list's :go/breaks (a\n  new line, or the line it records; brk: the set of the indexes, when the caller has it).")

var Lit_691 *jrt.String = jrt.Intern("ts")

var Lit_692 *jrt.String = jrt.Intern("For targets ts (lines, :break or nil), the first line after each: a vector.")

var Lit_693 *jrt.String = jrt.Intern("n")

var Lit_694 *jrt.String = jrt.Intern("body")

var Lit_695 *jrt.String = jrt.Intern("The index in f of the first of its trailing body forms.")

var Lit_696 *jrt.String = jrt.Intern("The first recorded line among forms, else *next*.")

var Lit_697 *jrt.String = jrt.Intern("xs")

var Lit_698 *jrt.String = jrt.Intern("print-one")

var Lit_699 *jrt.String = jrt.Intern("x1, x2, ...: the children of parent from index offset on, each by (print-one x), each after\n  the first on its recorded line (its own, or parent's :go/breaks: Go allows a break after the\n  comma).")

var Lit_700 *jrt.String = jrt.Intern("The Go spelling of a name: a symbol, pkg/Name, (go/id \"x\").")

var Lit_701 *jrt.String = jrt.Intern("nms")

var Lit_702 *jrt.String = jrt.Intern("Names separated by commas (a group of parameters, results, fields, type parameters, or a\n  spec's names), each on its recorded line: a name list may span lines (Go allows a break\n  after a comma), and gc declares each name at its own line (DWARF's decl_line).")

var Lit_703 *jrt.String = jrt.Intern("g")

var Lit_704 *jrt.String = jrt.Intern("The recorded line of a group of entries: its first name's, else its type's.")

var Lit_705 *jrt.String = jrt.Intern("k")

var Lit_706 *jrt.String = jrt.Intern("open")

var Lit_707 *jrt.String = jrt.Intern("close")

var Lit_708 *jrt.String = jrt.Intern("keys")

var Lit_709 *jrt.String = jrt.Intern("Prints xs between open and close, separated by commas, each by (print-one x i); keeps\n  the recorded lines of the elements, and puts close on a line of its own after a trailing\n  comma when the elements span lines and there is room. parent and offset give the\n  elements' indexes in their parent list (for :go/breaks); end, the line of close (:here:\n  the line of the last element); target, when given, the recorded line of an element (for\n  elements that are not forms: groups of parameters).")

var Lit_710 *jrt.String = jrt.Intern("x")

var Lit_711 *jrt.String = jrt.Intern("A name with a type: a symbol or (go/id \"x\") carrying :tag (C5).")

var Lit_712 *jrt.String = jrt.Intern("v")

var Lit_713 *jrt.String = jrt.Intern("The entries of a parameter, result or field vector: {:name sym-or-nil :type T\n  :variadic? bool :meta m :src x}. A symbol with :tag is a name, anything else a type.")

var Lit_714 *jrt.String = jrt.Intern("prev")

var Lit_715 *jrt.String = jrt.Intern("cur")

var Lit_716 *jrt.String = jrt.Intern("Whether cur may join prev's group: names of one type, doc and struct tag (a field's doc and\n  tag are its every name's, so equal ones are one field's), cur not beginning a line of its\n  own (a name that does keeps its line: gc declares it there).")

var Lit_717 *jrt.String = jrt.Intern("Consecutive named entries of equal type, doc and tag (groupable?) as one group\n  {:names [...] ...}: Go's `a, b T`. Inside generic declarations the grouping must be the\n  source's: when a name of the list carries :go/grouped (the amendment proposed in\n  PRINTER-NOTES: each name declared together with the one before it), exactly those names\n  join the group before them (in a file that marks them, *explicit-groups*, a generic\n  declaration's list without marks has no groups); otherwise the source is assumed to group\n  what it can (outside generic declarations the converter marks nothing: grouping is N3's).")

var Lit_718 *jrt.String = jrt.Intern("(a, b int, c ...T): the parameters of a vector; end, the line of the closing bracket when\n  known.")

var Lit_719 *jrt.String = jrt.Intern("params")

var Lit_720 *jrt.String = jrt.Intern("The results of a signature: a vector's :tag (one unnamed result) or :results.")

var Lit_721 *jrt.String = jrt.Intern("The indentation of the line being written.")

var Lit_722 *jrt.String = jrt.Intern("res")

var Lit_723 *jrt.String = jrt.Intern("(params) results. The parameters' closing bracket goes on the line of the results (their\n  first token follows it on its line: the line they record, else the last parameter's), and\n  without results, when the parameters span lines, on a line of its own only if there is room\n  before the body (its first recorded line).")

var Lit_724 *jrt.String = jrt.Intern("(params) results of (func [params] [results]): the results vector holds names or types.")

var Lit_725 *jrt.String = jrt.Intern("s")

var Lit_726 *jrt.String = jrt.Intern("A doc comment (CommentGroup.Text) as // lines.")

var Lit_727 *jrt.String = jrt.Intern("via")

var Lit_728 *jrt.String = jrt.Intern("apos")

var Lit_729 *jrt.String = jrt.Intern("m")

var Lit_730 *jrt.String = jrt.Intern("The directive lines of a declared name's metadata (§9.1): :go/<name> true or text (a\n  vector for several), sorted by name. Directives not spelled //go: are free-standing\n  (go/directive \"...\") forms (A6, in the converter's spelling), never metadata.")

var Lit_731 *jrt.String = jrt.Intern("dirs")

var Lit_732 *jrt.String = jrt.Intern("The number of comment lines before a declaration: doc, a // line between doc and\n  directives (gofmt's doc comment format), directives.")

var Lit_733 *jrt.String = jrt.Intern("more")

var Lit_734 *jrt.String = jrt.Intern("(params) results of an interface method or declaration: [params] then :results or the\n  vector's tag.")

var Lit_735 *jrt.String = jrt.Intern("groups")

var Lit_736 *jrt.String = jrt.Intern("struct?")

var Lit_737 *jrt.String = jrt.Intern("go/printer's isOneLineFieldList: one field (group) without tag or doc, whose type prints\n  in at most 30 characters, 29 with names (a method's type is func(...)...).")

var Lit_738 *jrt.String = jrt.Intern("fs")

var Lit_739 *jrt.String = jrt.Intern("One struct field (group) or interface element, with its separators.")

var Lit_740 *jrt.String = jrt.Intern("kw")

var Lit_741 *jrt.String = jrt.Intern("struct{...} or interface{...} (go/printer's fieldList).")

var Lit_742 *jrt.String = jrt.Intern("Type arguments [A, B].")

var Lit_743 *jrt.String = jrt.Intern("Prints a type form (§5.1).")

var Lit_744 *jrt.String = jrt.Intern("A form that prints as a type in an operand position: reserved type heads (other than\n  * with two or more operands).")

var Lit_745 *jrt.String = jrt.Intern("tps")

var Lit_746 *jrt.String = jrt.Intern("[P C, Q D] after a name; a single parameter whose constraint begins with * gets a trailing\n  comma (§12.2).")

var Lit_747 *jrt.String = jrt.Intern("o")

var Lit_748 *jrt.String = jrt.Intern("prec")

var Lit_749 *jrt.String = jrt.Intern("r")

var Lit_750 *jrt.String = jrt.Intern("go/printer's walkBinary, the part of a right operand r of the operator o (precedence\n  prec): [has4 has5 max-problem].")

var Lit_751 *jrt.String = jrt.Intern("go/printer's walkBinary of each left-nested prefix of f: (+ a b c d) is (+ (+ (+ a b) c) d),\n  whose prefixes (+ a b), (+ a b c) and f are walked in one pass (each prefix's walk is its\n  left prefix's and its right operand's): a vector, f's last.")

var Lit_752 *jrt.String = jrt.Intern("go/printer's walkBinary: [has4 has5 max-problem].")

var Lit_753 *jrt.String = jrt.Intern("has4")

var Lit_754 *jrt.String = jrt.Intern("has5")

var Lit_755 *jrt.String = jrt.Intern("mp")

var Lit_756 *jrt.String = jrt.Intern("depth")

var Lit_757 *jrt.String = jrt.Intern("d")

var Lit_758 *jrt.String = jrt.Intern("An operand of && or || the source parenthesized (:go/paren, C3): gc removes dead branches\n  by syntax and does not look through parentheses.")

var Lit_759 *jrt.String = jrt.Intern("prec1")

var Lit_760 *jrt.String = jrt.Intern("cut")

var Lit_761 *jrt.String = jrt.Intern("go/printer's binaryExpr. An n-ary form is a left-nested chain, (+ a b c) printed as\n  (+ (+ a b) c): its prefixes are printed in one pass, each with its own cutoff, as the\n  recursion through them would (each prefix's expr1 first moving to f's line, then its left\n  operand, then its operator and right operand), without making the prefixes.")

var Lit_762 *jrt.String = jrt.Intern("(args) of a call; a final (spread xs) is xs....")

var Lit_763 *jrt.String = jrt.Intern("h")

var Lit_764 *jrt.String = jrt.Intern("key-size")

var Lit_765 *jrt.String = jrt.Intern("el")

var Lit_766 *jrt.String = jrt.Intern("The printed width of a key, for gofmt's alignment decision.")

var Lit_767 *jrt.String = jrt.Intern("(fn params results? body*).")

var Lit_768 *jrt.String = jrt.Intern("go/printer's expr1: prints f as an operand of precedence at least prec1.")

var Lit_769 *jrt.String = jrt.Intern("e1, e2, ...: (values ...) or one expression; the values on the line of the values form,\n  each after the first on its recorded line (its own, or the values' :go/breaks).")

var Lit_770 *jrt.String = jrt.Intern("init")

var Lit_771 *jrt.String = jrt.Intern("A let binding pair as a Go statement: :=, var, const (§7.3).")

var Lit_772 *jrt.String = jrt.Intern("nm")

var Lit_773 *jrt.String = jrt.Intern("A simple statement: an init or post statement, a select communication, an expression\n  statement, an assignment, a := binding written as [target init].")

var Lit_774 *jrt.String = jrt.Intern("for?")

var Lit_775 *jrt.String = jrt.Intern("post")

var Lit_776 *jrt.String = jrt.Intern("go/printer's controlClause: init; cond; post of if, switch and for.")

var Lit_777 *jrt.String = jrt.Intern("b")

var Lit_778 *jrt.String = jrt.Intern("The statement list of a branch: (do ...) is its forms, anything else one statement.")

var Lit_779 *jrt.String = jrt.Intern("block-body's :parent and :offset for branch b, child i of parent.")

var Lit_780 *jrt.String = jrt.Intern("els")

var Lit_781 *jrt.String = jrt.Intern("opts")

var Lit_782 *jrt.String = jrt.Intern("clauses")

var Lit_783 *jrt.String = jrt.Intern("print-head")

var Lit_784 *jrt.String = jrt.Intern("The clauses of a switch, type switch or select, between braces.")

var Lit_785 *jrt.String = jrt.Intern("c")

var Lit_786 *jrt.String = jrt.Intern("Prints one statement form (not a let: stmt-list flattens those).")

var Lit_787 *jrt.String = jrt.Intern("The items of a statement list: {:form f} or {:bind [target init] :t line} or\n  {:type-bind [name type]}; a let (or let-type) last in a list continues the list with its\n  body, one that is not last is a block of its own. parent and offset: the list holding the\n  forms and the index of the first (for :go/breaks).")

var Lit_788 *jrt.String = jrt.Intern("it")

var Lit_789 *jrt.String = jrt.Intern("more?")

var Lit_790 *jrt.String = jrt.Intern("(label :L s?): L: s. A label without a statement is followed by ; when more statements\n  follow (more?). Nested labels print in a row (L1: L2: s).")

var Lit_791 *jrt.String = jrt.Intern("items")

var Lit_792 *jrt.String = jrt.Intern("Joins the bindings of a local const ( ... ) group (C2): a const binding whose target\n  carries :go/grouped continues the group of the binding before it.")

var Lit_793 *jrt.String = jrt.Intern("The label of a labeled declaration (:go/label on its first target, A9).")

var Lit_794 *jrt.String = jrt.Intern("keep-type")

var Lit_795 *jrt.String = jrt.Intern("One spec of a local const group: names, type and values, or the names alone (:go/implicit).")

var Lit_796 *jrt.String = jrt.Intern("its")

var Lit_797 *jrt.String = jrt.Intern("const ( specs ) in a function body, at indent: its specs on their recorded lines.")

var Lit_798 *jrt.String = jrt.Intern("The line of a const group's keyword: the line before its first spec when free.")

var Lit_799 *jrt.String = jrt.Intern("Prints a statement list at indent (opts :indent), each statement on its recorded line.\n  :results? makes a final expression the function's return (§6.4). :parent and :offset\n  locate the forms in their list (for :go/breaks).")

var Lit_800 *jrt.String = jrt.Intern("{ statements } at one more indentation than the line of the brace. opts: :results?,\n  :end (the recorded line of the closing brace), :func? (a function body: gofmt keeps it on\n  one line when the source has it so), :sep (whitespace before the brace), :next (the line\n  of what follows the brace), :else-follows?, :indent (the indentation of the line the\n  construct began on, when its header may span lines: a function's parameters).")

var Lit_801 *jrt.String = jrt.Intern("A function body on one line: statements separated by semicolons (go/printer's funcBody).")

var Lit_802 *jrt.String = jrt.Intern("[doc opts rest] of the arguments after a declaration's name: an optional doc string, then\n  :type-params.")

var Lit_803 *jrt.String = jrt.Intern("method?")

var Lit_804 *jrt.String = jrt.Intern("go/func and go/method (§6.4).")

var Lit_805 *jrt.String = jrt.Intern("group?")

var Lit_806 *jrt.String = jrt.Intern("Names, type and values of a const or var spec. keep-type: gofmt's type column.")

var Lit_807 *jrt.String = jrt.Intern("specs")

var Lit_808 *jrt.String = jrt.Intern("go/printer's keepTypeColumn over the specs [target init].")

var Lit_809 *jrt.String = jrt.Intern("print-spec")

var Lit_810 *jrt.String = jrt.Intern("meta-of")

var Lit_811 *jrt.String = jrt.Intern("kw ( specs ): print-spec prints one spec vector given its index.")

var Lit_812 *jrt.String = jrt.Intern("decl-doc-and-directives")

var Lit_813 *jrt.String = jrt.Intern("[doc directives] of a top-level form.")

var Lit_814 *jrt.String = jrt.Intern("top-decl")

var Lit_815 *jrt.String = jrt.Intern("Prints a top-level declaration form, after its doc comment and directives.")
