//line aot_arbace_g2a_print_code__init.ae:1
package aot_arbace_g2a_print_code

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_code__init_part0_A_Unit0__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_g2a_print_code__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_code__init_part0_A_const_1) }
//line :1:1
func A_arbace_g2a_print_code__init_part0_A_Unit1__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_print_code__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_2)) }
//line :1:1
func A_arbace_g2a_print_code__init_part0_A_Unit2__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_213, false); A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_print_code__init_part0_A_Unit3__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_print_code__init_part0_A_const_1)).Equals_O__Z(A_arbace_g2a_print_code__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_214, false); A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_g2a_print_code__init_part0_A_Init__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_g2a_print_code__init_part0_A_Load__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); A_arbace_g2a_print_code__init_part0_A_Unit0__O(); A_arbace_g2a_print_code__init_part0_A_Unit1__O(); A_arbace_g2a_print_code__init_part0_A_Unit2__O(); A_arbace_g2a_print_code__init_part0_A_Unit3__O(); A_arbace_g2a_print_code__init_part0_A_Unit4__O(); A_arbace_g2a_print_code__init_part0_A_Unit5__O(); A_arbace_g2a_print_code__init_part0_A_Unit6__O(); A_arbace_g2a_print_code__init_part0_A_Unit7__O(); A_arbace_g2a_print_code__init_part0_A_Unit8__O(); A_arbace_g2a_print_code__init_part0_A_Unit9__O(); A_arbace_g2a_print_code__init_part0_A_Unit10__O(); A_arbace_g2a_print_code__init_part0_A_Unit11__O(); A_arbace_g2a_print_code__init_part0_A_Unit12__O(); A_arbace_g2a_print_code__init_part0_A_Unit13__O(); A_arbace_g2a_print_code__init_part0_A_Unit14__O(); A_arbace_g2a_print_code__init_part0_A_Unit15__O(); A_arbace_g2a_print_code__init_part0_A_Unit16__O(); A_arbace_g2a_print_code__init_part0_A_Unit17__O(); A_arbace_g2a_print_code__init_part0_A_Unit18__O(); A_arbace_g2a_print_code__init_part0_A_Unit19__O(); A_arbace_g2a_print_code__init_part0_A_Unit20__O(); A_arbace_g2a_print_code__init_part0_A_Unit21__O(); A_arbace_g2a_print_code__init_part0_A_Unit22__O(); A_arbace_g2a_print_code__init_part0_A_Unit23__O(); A_arbace_g2a_print_code__init_part0_A_Unit24__O(); A_arbace_g2a_print_code__init_part0_A_Unit25__O(); A_arbace_g2a_print_code__init_part0_A_Unit26__O(); A_arbace_g2a_print_code__init_part0_A_Unit27__O(); A_arbace_g2a_print_code__init_part0_A_Unit28__O(); A_arbace_g2a_print_code__init_part0_A_Unit29__O(); A_arbace_g2a_print_code__init_part0_A_Unit30__O(); A_arbace_g2a_print_code__init_part0_A_Unit31__O(); A_arbace_g2a_print_code__init_part0_A_Unit32__O(); A_arbace_g2a_print_code__init_part0_A_Unit33__O(); A_arbace_g2a_print_code__init_part0_A_Unit34__O(); A_arbace_g2a_print_code__init_part0_A_Unit35__O(); A_arbace_g2a_print_code__init_part0_A_Unit36__O(); A_arbace_g2a_print_code__init_part0_A_Unit37__O(); A_arbace_g2a_print_code__init_part0_A_Unit38__O(); A_arbace_g2a_print_code__init_part0_A_Unit39__O(); A_arbace_g2a_print_code__init_part0_A_Unit40__O(); A_arbace_g2a_print_code__init_part0_A_Unit41__O(); A_arbace_g2a_print_code__init_part0_A_Unit42__O(); A_arbace_g2a_print_code__init_part0_A_Unit43__O(); A_arbace_g2a_print_code__init_part0_A_Unit44__O(); A_arbace_g2a_print_code__init_part0_A_Unit45__O(); A_arbace_g2a_print_code__init_part0_A_Unit46__O(); A_arbace_g2a_print_code__init_part0_A_Unit47__O(); A_arbace_g2a_print_code__init_part0_A_Unit48__O(); A_arbace_g2a_print_code__init_part0_A_Unit49__O(); A_arbace_g2a_print_code__init_part0_A_Unit50__O(); A_arbace_g2a_print_code__init_part0_A_Unit51__O(); A_arbace_g2a_print_code__init_part0_A_Unit52__O(); A_arbace_g2a_print_code__init_part0_A_Unit53__O(); A_arbace_g2a_print_code__init_part0_A_Unit54__O(); A_arbace_g2a_print_code__init_part0_A_Unit55__O(); A_arbace_g2a_print_code__init_part0_A_Unit56__O(); A_arbace_g2a_print_code__init_part0_A_Unit57__O(); A_arbace_g2a_print_code__init_part0_A_Unit58__O(); A_arbace_g2a_print_code__init_part0_A_Unit59__O(); A_arbace_g2a_print_code__init_part0_A_Unit60__O(); A_arbace_g2a_print_code__init_part0_A_Unit61__O(); A_arbace_g2a_print_code__init_part0_A_Unit62__O(); A_arbace_g2a_print_code__init_part0_A_Unit63__O(); A_arbace_g2a_print_code__init_part0_A_Unit64__O(); A_arbace_g2a_print_code__init_part0_A_Unit65__O(); A_arbace_g2a_print_code__init_part0_A_Unit66__O(); A_arbace_g2a_print_code__init_part0_A_Unit67__O(); A_arbace_g2a_print_code__init_part0_A_Unit68__O(); A_arbace_g2a_print_code__init_part0_A_Unit69__O(); A_arbace_g2a_print_code__init_part0_A_Unit70__O(); A_arbace_g2a_print_code__init_part0_A_Unit71__O(); A_arbace_g2a_print_code__init_part0_A_Unit72__O(); A_arbace_g2a_print_code__init_part0_A_Unit73__O(); A_arbace_g2a_print_code__init_part0_A_Unit74__O(); A_arbace_g2a_print_code__init_part0_A_Unit75__O(); A_arbace_g2a_print_code__init_part0_A_Unit76__O(); A_arbace_g2a_print_code__init_part0_A_Unit77__O(); A_arbace_g2a_print_code__init_part0_A_Unit78__O(); A_arbace_g2a_print_code__init_part0_A_Unit79__O(); A_arbace_g2a_print_code__init_part0_A_Unit80__O(); A_arbace_g2a_print_code__init_part0_A_Unit81__O(); A_arbace_g2a_print_code__init_part0_A_Unit82__O(); A_arbace_g2a_print_code__init_part0_A_Unit83__O(); A_arbace_g2a_print_code__init_part0_A_Unit84__O(); A_arbace_g2a_print_code__init_part0_A_Unit85__O(); A_arbace_g2a_print_code__init_part0_A_Unit86__O(); A_arbace_g2a_print_code__init_part0_A_Unit87__O(); A_arbace_g2a_print_code__init_part0_A_Unit88__O(); A_arbace_g2a_print_code__init_part0_A_Unit89__O(); A_arbace_g2a_print_code__init_part0_A_Unit90__O(); A_arbace_g2a_print_code__init_part0_A_Unit91__O(); A_arbace_g2a_print_code__init_part0_A_Unit92__O(); A_arbace_g2a_print_code__init_part0_A_Unit93__O(); A_arbace_g2a_print_code__init_part0_A_Unit94__O(); A_arbace_g2a_print_code__init_part0_A_Unit95__O(); A_arbace_g2a_print_code__init_part0_A_Unit96__O(); A_arbace_g2a_print_code__init_part0_A_Unit97__O(); A_arbace_g2a_print_code__init_part0_A_Unit98__O(); A_arbace_g2a_print_code__init_part0_A_Unit99__O(); return nil }



func A_arbace_g2a_print_code__init_A_Load__O() any { A_arbace_g2a_print_code__init_part0_A_Init__O(); A_arbace_g2a_print_code__init_part1_A_Init__O(); A_arbace_g2a_print_code__init_part0_A_Load__O(); A_arbace_g2a_print_code__init_part1_A_Load__O(); return nil }








func A_arbace_g2a_print_code__init_part0_A_Unit4__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_5)); return A_arbace_g2a_print_code__init_part0_A_const_4 }
//line :14:1
func A_arbace_g2a_print_code__init_part0_A_Unit5__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_7)); return A_arbace_g2a_print_code__init_part0_A_const_6 }
//line :14:1
func A_arbace_g2a_print_code__init_part0_A_Unit6__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_9)); return A_arbace_g2a_print_code__init_part0_A_const_8 }
//line :14:1
func A_arbace_g2a_print_code__init_part0_A_Unit7__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_11)); return A_arbace_g2a_print_code__init_part0_A_const_10 }
//line :14:1
func A_arbace_g2a_print_code__init_part0_A_Unit8__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_13)); return A_arbace_g2a_print_code__init_part0_A_const_12 }
//line :14:1
func A_arbace_g2a_print_code__init_part0_A_Unit9__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_15)); return A_arbace_g2a_print_code__init_part0_A_const_14 }
//line :14:1
func A_arbace_g2a_print_code__init_part0_A_Unit10__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_17)); return A_arbace_g2a_print_code__init_part0_A_const_16 }
//line :14:1
func A_arbace_g2a_print_code__init_part0_A_Unit11__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_19)); return A_arbace_g2a_print_code__init_part0_A_const_18 }

func A_arbace_g2a_print_code__init_part0_A_Unit12__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); A_arbace_g2a_print_code__init_part0_A_const_20.BindRoot_O__V(A_arbace_g2a_print_code__init_part0_A_const_21); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_22)); return A_arbace_g2a_print_code__init_part0_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_g2a_print_code__init_part0_A_Unit13__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_23; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_23; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_24)); return A_arbace_g2a_print_code__init_part0_A_const_23.SetDynamic_Z__Var(true).Ref() }




func A_arbace_g2a_print_code__init_part0_A_Unit14__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_25; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_25; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_26)); return A_arbace_g2a_print_code__init_part0_A_const_25.SetDynamic_Z__Var(true).Ref() }




func A_arbace_g2a_print_code__init_part0_A_Unit15__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_27; var tmp2 any = A_arbace_g2a_print_code_uses_grouped_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_print_code_uses_grouped_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_215, false); A_arbace_g2a_print_code_uses_grouped_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_28)); return A_arbace_g2a_print_code__init_part0_A_const_27 }








func A_arbace_g2a_print_code__init_part0_A_Unit16__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_29; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_29; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_30)); return A_arbace_g2a_print_code__init_part0_A_const_29.SetDynamic_Z__Var(true).Ref() }



func A_arbace_g2a_print_code__init_part0_A_Unit17__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_31; var tmp2 any = A_arbace_g2a_print_code_fail_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_print_code_fail_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_216, false); A_arbace_g2a_print_code_fail_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_32)); return A_arbace_g2a_print_code__init_part0_A_const_31 }





func A_arbace_g2a_print_code__init_part0_A_Unit18__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_33; var tmp2 any = A_arbace_g2a_print_code_op_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_print_code_op_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_217, false); A_arbace_g2a_print_code_op_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_34)); return A_arbace_g2a_print_code__init_part0_A_const_33 }














func A_arbace_g2a_print_code__init_part0_A_Unit19__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); A_arbace_g2a_print_code__init_part0_A_const_35.BindRoot_O__V(A_arbace_g2a_print_code__init_part0_A_const_36); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_37)); return A_arbace_g2a_print_code__init_part0_A_const_35 }




func A_arbace_g2a_print_code__init_part0_A_Unit20__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); A_arbace_g2a_print_code__init_part0_A_const_38.BindRoot_O__V(A_arbace_g2a_print_code__init_part0_A_const_39); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_40)); return A_arbace_g2a_print_code__init_part0_A_const_38 }





func A_arbace_g2a_print_code__init_part0_A_Unit21__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); A_arbace_g2a_print_code__init_part0_A_const_41.BindRoot_O__V(A_arbace_g2a_print_code__init_part0_A_const_42); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_43)); return A_arbace_g2a_print_code__init_part0_A_const_41 }

func A_arbace_g2a_print_code__init_part0_A_Unit22__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); A_arbace_g2a_print_code__init_part0_A_const_44.BindRoot_O__V(A_arbace_g2a_print_code__init_part0_A_const_45); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_46)); return A_arbace_g2a_print_code__init_part0_A_const_44 }



func A_arbace_g2a_print_code__init_part0_A_Unit23__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); A_arbace_g2a_print_code__init_part0_A_const_47.BindRoot_O__V(A_arbace_g2a_print_code__init_part0_A_const_48); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_49)); return A_arbace_g2a_print_code__init_part0_A_const_47 }

func A_arbace_g2a_print_code__init_part0_A_Unit24__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_50; var tmp2 any = A_arbace_g2a_print_code_args_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_print_code_args_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_218, false); A_arbace_g2a_print_code_args_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_51)); return A_arbace_g2a_print_code__init_part0_A_const_50 }

func A_arbace_g2a_print_code__init_part0_A_Unit25__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_52; var tmp2 any = A_arbace_g2a_print_code_binary_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_print_code_binary_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_219, false); A_arbace_g2a_print_code_binary_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_53)); return A_arbace_g2a_print_code__init_part0_A_const_52 }




func A_arbace_g2a_print_code__init_part0_A_Unit26__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(90, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_54; var tmp2 any = A_arbace_g2a_print_code_negative_literal_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_print_code_negative_literal_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_220, false); A_arbace_g2a_print_code_negative_literal_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_55)); return A_arbace_g2a_print_code__init_part0_A_const_54 }

func A_arbace_g2a_print_code__init_part0_A_Unit27__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_56; var tmp2 any = A_arbace_g2a_print_code_unary_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_print_code_unary_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_221, false); A_arbace_g2a_print_code_unary_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_57)); return A_arbace_g2a_print_code__init_part0_A_const_56 }





func A_arbace_g2a_print_code__init_part0_A_Unit28__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(98, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_58; var tmp2 any = A_arbace_g2a_print_code_unary_op_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_print_code_unary_op_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_222, false); A_arbace_g2a_print_code_unary_op_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_59)); return A_arbace_g2a_print_code__init_part0_A_const_58 }

func A_arbace_g2a_print_code__init_part0_A_Unit29__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_60; var tmp2 any = A_arbace_g2a_print_code_unary_operand_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_print_code_unary_operand_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_223, false); A_arbace_g2a_print_code_unary_operand_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_61)); return A_arbace_g2a_print_code__init_part0_A_const_60 }




func A_arbace_g2a_print_code__init_part0_A_Unit30__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(105, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_62; var tmp2 any = A_arbace_g2a_print_code_bin_op_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_g2a_print_code_bin_op_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_224, false); A_arbace_g2a_print_code_bin_op_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_63)); return A_arbace_g2a_print_code__init_part0_A_const_62 }
func A_arbace_g2a_print_code__init_part0_A_Unit31__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_64; var tmp2 any = A_arbace_g2a_print_code_bin_prec_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_print_code_bin_prec_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_225, false); A_arbace_g2a_print_code_bin_prec_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_65)); return A_arbace_g2a_print_code__init_part0_A_const_64 }

func A_arbace_g2a_print_code__init_part0_A_Unit32__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_66; var tmp2 any = A_arbace_g2a_print_code_prec_of_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_g2a_print_code_prec_of_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_226, false); A_arbace_g2a_print_code_prec_of_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_67)); return A_arbace_g2a_print_code__init_part0_A_const_66 }




func A_arbace_g2a_print_code__init_part0_A_Unit33__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_68; var tmp2 any = A_arbace_g2a_print_code_go_sym_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_print_code_go_sym_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_227, false); A_arbace_g2a_print_code_go_sym_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_69)); return A_arbace_g2a_print_code__init_part0_A_const_68 }

func A_arbace_g2a_print_code__init_part0_A_Unit34__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_70; var tmp2 any = A_arbace_g2a_print_code_statement_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_g2a_print_code_statement_form_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_228, false); A_arbace_g2a_print_code_statement_form_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_71)); return A_arbace_g2a_print_code__init_part0_A_const_70 }


func A_arbace_g2a_print_code__init_part0_A_Unit35__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_72; var tmp2 any = A_arbace_g2a_print_code_expression_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_print_code_expression_form_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_229, false); A_arbace_g2a_print_code_expression_form_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_73)); return A_arbace_g2a_print_code__init_part0_A_const_72 }






func A_arbace_g2a_print_code__init_part0_A_Unit36__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_74; var tmp2 any = A_arbace_g2a_print_code_line_of_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_g2a_print_code_line_of_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_230, false); A_arbace_g2a_print_code_line_of_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_75)); return A_arbace_g2a_print_code__init_part0_A_const_74 }

func A_arbace_g2a_print_code__init_part0_A_Unit37__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_76; var tmp2 any = A_arbace_g2a_print_code_breaks_of_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_print_code_breaks_of_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_231, false); A_arbace_g2a_print_code_breaks_of_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_77)); return A_arbace_g2a_print_code__init_part0_A_const_76 }





func A_arbace_g2a_print_code__init_part0_A_Unit38__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(133, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_78; var tmp2 any = A_arbace_g2a_print_code_break_line_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_print_code_break_line_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_232, false); A_arbace_g2a_print_code_break_line_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_79)); return A_arbace_g2a_print_code__init_part0_A_const_78 }




func A_arbace_g2a_print_code__init_part0_A_Unit39__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_80; var tmp2 any = A_arbace_g2a_print_code_child_target_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_g2a_print_code_child_target_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_233, false); A_arbace_g2a_print_code_child_target_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_81)); return A_arbace_g2a_print_code__init_part0_A_const_80 }








func A_arbace_g2a_print_code__init_part0_A_Unit40__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_82; var tmp2 any = A_arbace_g2a_print_code_next_targets_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_g2a_print_code_next_targets_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_234, false); A_arbace_g2a_print_code_next_targets_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_83)); return A_arbace_g2a_print_code__init_part0_A_const_82 }











func A_arbace_g2a_print_code__init_part0_A_Unit41__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(159, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_84; var tmp2 any = A_arbace_g2a_print_code_room_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_g2a_print_code_room_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_235, false); A_arbace_g2a_print_code_room_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_85)); return A_arbace_g2a_print_code__init_part0_A_const_84 }

func A_arbace_g2a_print_code__init_part0_A_Unit42__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_86; var tmp2 any = A_arbace_g2a_print_code_body_offset_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_g2a_print_code_body_offset_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_236, false); A_arbace_g2a_print_code_body_offset_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_87)); return A_arbace_g2a_print_code__init_part0_A_const_86 }



func A_arbace_g2a_print_code__init_part0_A_Unit43__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_88; var tmp2 any = A_arbace_g2a_print_code_next_line_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_g2a_print_code_next_line_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_237, false); A_arbace_g2a_print_code_next_line_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_89)); return A_arbace_g2a_print_code__init_part0_A_const_88 }




func A_arbace_g2a_print_code__init_part0_A_Unit44__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(170, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_90; var tmp2 any = A_arbace_g2a_print_code_comma_list_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_g2a_print_code_comma_list_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_238, false); A_arbace_g2a_print_code_comma_list_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_91)); return A_arbace_g2a_print_code__init_part0_A_const_90 }














func A_arbace_g2a_print_code__init_part0_A_Unit45__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_92; var tmp2 any = A_arbace_g2a_print_code_ident_string_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_g2a_print_code_ident_string_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_239, false); A_arbace_g2a_print_code_ident_string_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_93)); return A_arbace_g2a_print_code__init_part0_A_const_92 }







func A_arbace_g2a_print_code__init_part0_A_Unit46__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(193, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_94; var tmp2 any = A_arbace_g2a_print_code_name_list_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_g2a_print_code_name_list_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_240, false); A_arbace_g2a_print_code_name_list_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_95)); return A_arbace_g2a_print_code__init_part0_A_const_94 }








func A_arbace_g2a_print_code__init_part0_A_Unit47__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_96; var tmp2 any = A_arbace_g2a_print_code_group_line_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_g2a_print_code_group_line_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_241, false); A_arbace_g2a_print_code_group_line_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_97)); return A_arbace_g2a_print_code__init_part0_A_const_96 }




func A_arbace_g2a_print_code__init_part0_A_Unit48__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(207, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_98; var tmp2 any = A_arbace_g2a_print_code_label_name_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_g2a_print_code_label_name_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_242, false); A_arbace_g2a_print_code_label_name_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_99)); return A_arbace_g2a_print_code__init_part0_A_const_98 }


func A_arbace_g2a_print_code__init_part0_A_Unit49__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(210, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_100; var tmp2 any = A_arbace_g2a_print_code_literal_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_g2a_print_code_literal_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_243, false); A_arbace_g2a_print_code_literal_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_101)); return A_arbace_g2a_print_code__init_part0_A_const_100 }


















func A_arbace_g2a_print_code__init_part0_A_Unit50__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(229, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_102; var tmp2 any = A_arbace_g2a_print_code_element_list_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_g2a_print_code_element_list_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_244, false); A_arbace_g2a_print_code_element_list_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_103)); return A_arbace_g2a_print_code__init_part0_A_const_102 }










































func A_arbace_g2a_print_code__init_part0_A_Unit51__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(272, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_104; var tmp2 any = A_arbace_g2a_print_code_tagged_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_g2a_print_code_tagged_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_245, false); A_arbace_g2a_print_code_tagged_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_105)); return A_arbace_g2a_print_code__init_part0_A_const_104 }




func A_arbace_g2a_print_code__init_part0_A_Unit52__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(277, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_106; var tmp2 any = A_arbace_g2a_print_code_param_entries_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_g2a_print_code_param_entries_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_246, false); A_arbace_g2a_print_code_param_entries_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_107)); return A_arbace_g2a_print_code__init_part0_A_const_106 }















func A_arbace_g2a_print_code__init_part0_A_Unit53__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(293, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_108; var tmp2 any = A_arbace_g2a_print_code_groupable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_g2a_print_code_groupable_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_247, false); A_arbace_g2a_print_code_groupable_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_109)); return A_arbace_g2a_print_code__init_part0_A_const_108 }











func A_arbace_g2a_print_code__init_part0_A_Unit54__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(305, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_110; var tmp2 any = A_arbace_g2a_print_code_group_entries_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_g2a_print_code_group_entries_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_248, false); A_arbace_g2a_print_code_group_entries_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_111)); return A_arbace_g2a_print_code__init_part0_A_const_110 }






















func A_arbace_g2a_print_code__init_part0_A_Unit55__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(328, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_112; var tmp2 any = A_arbace_g2a_print_code_variadic_elem_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_g2a_print_code_variadic_elem_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_249, false); A_arbace_g2a_print_code_variadic_elem_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_113)); return A_arbace_g2a_print_code__init_part0_A_const_112 }


func A_arbace_g2a_print_code__init_part0_A_Unit56__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(331, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_114; var tmp2 any = A_arbace_g2a_print_code_param_list_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_g2a_print_code_param_list_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_250, true); A_arbace_g2a_print_code_param_list_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_115)); return A_arbace_g2a_print_code__init_part0_A_const_114 }
















func A_arbace_g2a_print_code__init_part0_A_Unit57__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(348, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_116; var tmp2 any = A_arbace_g2a_print_code_results_entries_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_g2a_print_code_results_entries_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_251, false); A_arbace_g2a_print_code_results_entries_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_117)); return A_arbace_g2a_print_code__init_part0_A_const_116 }







func A_arbace_g2a_print_code__init_part0_A_Unit58__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(356, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_118; var tmp2 any = A_arbace_g2a_print_code_print_results_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_g2a_print_code_print_results_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_252, false); A_arbace_g2a_print_code_print_results_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_119)); return A_arbace_g2a_print_code__init_part0_A_const_118 }






func A_arbace_g2a_print_code__init_part0_A_Unit59__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(363, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_120; var tmp2 any = A_arbace_g2a_print_code_line_indent_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_g2a_print_code_line_indent_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_253, false); A_arbace_g2a_print_code_line_indent_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_121)); return A_arbace_g2a_print_code__init_part0_A_const_120 }




func A_arbace_g2a_print_code__init_part0_A_Unit60__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(368, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_122; var tmp2 any = A_arbace_g2a_print_code_signature_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_g2a_print_code_signature_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_254, false); A_arbace_g2a_print_code_signature_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_123)); return A_arbace_g2a_print_code__init_part0_A_const_122 }










func A_arbace_g2a_print_code__init_part0_A_Unit61__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(379, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_124; var tmp2 any = A_arbace_g2a_print_code_func_type_sig_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_g2a_print_code_func_type_sig_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_255, false); A_arbace_g2a_print_code_func_type_sig_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_125)); return A_arbace_g2a_print_code__init_part0_A_const_124 }




func A_arbace_g2a_print_code__init_part0_A_Unit62__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(384, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_126; var tmp2 any = A_arbace_g2a_print_code_struct_tag_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_g2a_print_code_struct_tag_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_256, false); A_arbace_g2a_print_code_struct_tag_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_127)); return A_arbace_g2a_print_code__init_part0_A_const_126 }




func A_arbace_g2a_print_code__init_part0_A_Unit63__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(389, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_128; var tmp2 any = A_arbace_g2a_print_code_doc_lines_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_g2a_print_code_doc_lines_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_257, false); A_arbace_g2a_print_code_doc_lines_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_129)); return A_arbace_g2a_print_code__init_part0_A_const_128 }




func A_arbace_g2a_print_code__init_part0_A_Unit64__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(394, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_130; var tmp2 any = A_arbace_g2a_print_code_write_doc_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_g2a_print_code_write_doc_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_258, false); A_arbace_g2a_print_code_write_doc_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_131)); return A_arbace_g2a_print_code__init_part0_A_const_130 }







func A_arbace_g2a_print_code__init_part0_A_Unit65__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(402, 1); A_arbace_g2a_print_code__init_part0_A_const_132.BindRoot_O__V(A_arbace_g2a_print_code__init_part0_A_const_133); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_132; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_134)); return A_arbace_g2a_print_code__init_part0_A_const_132 }



func A_arbace_g2a_print_code__init_part0_A_Unit66__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(406, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_135; var tmp2 any = A_arbace_g2a_print_code_directives_of_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_g2a_print_code_directives_of_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_259, false); A_arbace_g2a_print_code_directives_of_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_136)); return A_arbace_g2a_print_code__init_part0_A_const_135 }










func A_arbace_g2a_print_code__init_part0_A_Unit67__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(417, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_137; var tmp2 any = A_arbace_g2a_print_code_pre_lines_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_g2a_print_code_pre_lines_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_260, false); A_arbace_g2a_print_code_pre_lines_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_138)); return A_arbace_g2a_print_code__init_part0_A_const_137 }






func A_arbace_g2a_print_code__init_part0_A_Unit68__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(424, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_139; var tmp2 any = A_arbace_g2a_print_code_write_pre_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_g2a_print_code_write_pre_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_261, false); A_arbace_g2a_print_code_write_pre_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_140)); return A_arbace_g2a_print_code__init_part0_A_const_139 }




func A_arbace_g2a_print_code__init_part0_A_Unit69__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(429, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_141; var tmp2 any = A_arbace_g2a_print_code_interface_method_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_g2a_print_code_interface_method_QMARK__A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_262, false); A_arbace_g2a_print_code_interface_method_QMARK__A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_142)); return A_arbace_g2a_print_code__init_part0_A_const_141 }



func A_arbace_g2a_print_code__init_part0_A_Unit70__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(433, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_143; var tmp2 any = A_arbace_g2a_print_code_iface_method_sig_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_g2a_print_code_iface_method_sig_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_263, false); A_arbace_g2a_print_code_iface_method_sig_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_144)); return A_arbace_g2a_print_code__init_part0_A_const_143 }






func A_arbace_g2a_print_code__init_part0_A_Unit71__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(440, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_145)); return A_arbace_g2a_print_code__init_part0_A_const_8 }

func A_arbace_g2a_print_code__init_part0_A_Unit72__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(442, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_146; var tmp2 any = A_arbace_g2a_print_code_one_line_fields_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_g2a_print_code_one_line_fields_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_264, false); A_arbace_g2a_print_code_one_line_fields_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_147)); return A_arbace_g2a_print_code__init_part0_A_const_146 }

















func A_arbace_g2a_print_code__init_part0_A_Unit73__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(460, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_148; var tmp2 any = A_arbace_g2a_print_code_struct_fields_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_g2a_print_code_struct_fields_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_265, false); A_arbace_g2a_print_code_struct_fields_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_149)); return A_arbace_g2a_print_code__init_part0_A_const_148 }





func A_arbace_g2a_print_code__init_part0_A_Unit74__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(466, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_150; var tmp2 any = A_arbace_g2a_print_code_field_body_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_g2a_print_code_field_body_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_266, false); A_arbace_g2a_print_code_field_body_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_151)); return A_arbace_g2a_print_code__init_part0_A_const_150 }


















func A_arbace_g2a_print_code__init_part0_A_Unit75__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(485, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_152; var tmp2 any = A_arbace_g2a_print_code_field_list_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_g2a_print_code_field_list_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_267, false); A_arbace_g2a_print_code_field_list_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_153)); return A_arbace_g2a_print_code__init_part0_A_const_152 }













































func A_arbace_g2a_print_code__init_part0_A_Unit76__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(531, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_154; var tmp2 any = A_arbace_g2a_print_code_chan_type_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_g2a_print_code_chan_type_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_268, false); A_arbace_g2a_print_code_chan_type_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_155)); return A_arbace_g2a_print_code__init_part0_A_const_154 }













func A_arbace_g2a_print_code__init_part0_A_Unit77__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(545, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_156; var tmp2 any = A_arbace_g2a_print_code_type_list_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_g2a_print_code_type_list_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_269, false); A_arbace_g2a_print_code_type_list_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_157)); return A_arbace_g2a_print_code__init_part0_A_const_156 }




func A_arbace_g2a_print_code__init_part0_A_Unit78__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(550, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_8; var tmp2 any = A_arbace_g2a_print_code_type_expr_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_g2a_print_code_type_expr_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_270, false); A_arbace_g2a_print_code_type_expr_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_158)); return A_arbace_g2a_print_code__init_part0_A_const_8 }


































func A_arbace_g2a_print_code__init_part0_A_Unit79__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(585, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_159; var tmp2 any = A_arbace_g2a_print_code_type_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_g2a_print_code_type_form_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_271, false); A_arbace_g2a_print_code_type_form_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_160)); return A_arbace_g2a_print_code__init_part0_A_const_159 }








func A_arbace_g2a_print_code__init_part0_A_Unit80__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(594, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_161; var tmp2 any = A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_272, false); A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_162)); return A_arbace_g2a_print_code__init_part0_A_const_161 }



func A_arbace_g2a_print_code__init_part0_A_Unit81__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(598, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_163; var tmp2 any = A_arbace_g2a_print_code_type_params_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_g2a_print_code_type_params_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_273, false); A_arbace_g2a_print_code_type_params_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_164)); return A_arbace_g2a_print_code__init_part0_A_const_163 }






















func A_arbace_g2a_print_code__init_part0_A_Unit82__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(621, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_165; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_166)); return A_arbace_g2a_print_code__init_part0_A_const_165 }

func A_arbace_g2a_print_code__init_part0_A_Unit83__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(623, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_167; var tmp2 any = A_arbace_g2a_print_code_walk_right_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_g2a_print_code_walk_right_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_274, false); A_arbace_g2a_print_code_walk_right_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_168)); return A_arbace_g2a_print_code__init_part0_A_const_167 }












func A_arbace_g2a_print_code__init_part0_A_Unit84__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(636, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_169; var tmp2 any = A_arbace_g2a_print_code_walk_prefixes_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_g2a_print_code_walk_prefixes_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_275, false); A_arbace_g2a_print_code_walk_prefixes_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_170)); return A_arbace_g2a_print_code__init_part0_A_const_169 }

















func A_arbace_g2a_print_code__init_part0_A_Unit85__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(654, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_165; var tmp2 any = A_arbace_g2a_print_code_walk_binary_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_g2a_print_code_walk_binary_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_276, false); A_arbace_g2a_print_code_walk_binary_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_171)); return A_arbace_g2a_print_code__init_part0_A_const_165 }




func A_arbace_g2a_print_code__init_part0_A_Unit86__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(659, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_172; var tmp2 any = A_arbace_g2a_print_code_cutoff_of_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_g2a_print_code_cutoff_of_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_277, false); A_arbace_g2a_print_code_cutoff_of_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_173)); return A_arbace_g2a_print_code__init_part0_A_const_172 }






func A_arbace_g2a_print_code__init_part0_A_Unit87__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(666, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_174; var tmp2 any = A_arbace_g2a_print_code_cutoff_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_g2a_print_code_cutoff_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_278, false); A_arbace_g2a_print_code_cutoff_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_175)); return A_arbace_g2a_print_code__init_part0_A_const_174 }

func A_arbace_g2a_print_code__init_part0_A_Unit88__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(668, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_176; var tmp2 any = A_arbace_g2a_print_code_diff_prec_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_g2a_print_code_diff_prec_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_279, false); A_arbace_g2a_print_code_diff_prec_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_177)); return A_arbace_g2a_print_code__init_part0_A_const_176 }


func A_arbace_g2a_print_code__init_part0_A_Unit89__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(671, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_178; var tmp2 any = A_arbace_g2a_print_code_reduce_depth_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_g2a_print_code_reduce_depth_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_280, false); A_arbace_g2a_print_code_reduce_depth_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_179)); return A_arbace_g2a_print_code__init_part0_A_const_178 }

func A_arbace_g2a_print_code__init_part0_A_Unit90__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(673, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_180; var tmp2 any = A_arbace_g2a_print_code_paren_operand_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_g2a_print_code_paren_operand_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_281, false); A_arbace_g2a_print_code_paren_operand_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_181)); return A_arbace_g2a_print_code__init_part0_A_const_180 }








func A_arbace_g2a_print_code__init_part0_A_Unit91__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(682, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_182; var tmp2 any = A_arbace_g2a_print_code_binary_expr_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_g2a_print_code_binary_expr_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_282, false); A_arbace_g2a_print_code_binary_expr_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_183)); return A_arbace_g2a_print_code__init_part0_A_const_182 }




































func A_arbace_g2a_print_code__init_part0_A_Unit92__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(719, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_184; var tmp2 any = A_arbace_g2a_print_code_call_args_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_g2a_print_code_call_args_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_283, false); A_arbace_g2a_print_code_call_args_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_185)); return A_arbace_g2a_print_code__init_part0_A_const_184 }









func A_arbace_g2a_print_code__init_part0_A_Unit93__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(729, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_186; var tmp2 any = A_arbace_g2a_print_code_callee_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_g2a_print_code_callee_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_284, false); A_arbace_g2a_print_code_callee_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_187)); return A_arbace_g2a_print_code__init_part0_A_const_186 }




func A_arbace_g2a_print_code__init_part0_A_Unit94__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(734, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_188; var tmp2 any = A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_285, false); A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_189)); return A_arbace_g2a_print_code__init_part0_A_const_188 }




func A_arbace_g2a_print_code__init_part0_A_Unit95__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(739, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_190; var tmp2 any = A_arbace_g2a_print_code_lit_elements_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_g2a_print_code_lit_elements_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_286, false); A_arbace_g2a_print_code_lit_elements_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_190; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_191)); return A_arbace_g2a_print_code__init_part0_A_const_190 }














func A_arbace_g2a_print_code__init_part0_A_Unit96__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(754, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_192; var tmp2 any = A_arbace_g2a_print_code_key_size_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_g2a_print_code_key_size_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_287, false); A_arbace_g2a_print_code_key_size_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_192; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_193)); return A_arbace_g2a_print_code__init_part0_A_const_192 }











func A_arbace_g2a_print_code__init_part0_A_Unit97__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(766, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_194; var tmp2 any = A_arbace_g2a_print_code_composite_lit_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_g2a_print_code_composite_lit_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_288, false); A_arbace_g2a_print_code_composite_lit_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_194; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_195)); return A_arbace_g2a_print_code__init_part0_A_const_194 }
































func A_arbace_g2a_print_code__init_part0_A_Unit98__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(799, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_196; var tmp2 any = A_arbace_g2a_print_code_slice_expr_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_g2a_print_code_slice_expr_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_289, false); A_arbace_g2a_print_code_slice_expr_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_196; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_197)); return A_arbace_g2a_print_code__init_part0_A_const_196 }
















func A_arbace_g2a_print_code__init_part0_A_Unit99__O() any { A_arbace_g2a_print_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(816, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_198; var tmp2 any = A_arbace_g2a_print_code_func_lit_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_g2a_print_code_func_lit_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_290, false); A_arbace_g2a_print_code_func_lit_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part0_A_const_198; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part0_A_const_199)); return A_arbace_g2a_print_code__init_part0_A_const_198 }













func A_arbace_g2a_print_code__init_part1_A_Unit100__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(830, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_0; var tmp2 any = A_arbace_g2a_print_code_new_arg_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_print_code_new_arg_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_292, false); A_arbace_g2a_print_code_new_arg_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_1)); return A_arbace_g2a_print_code__init_part1_A_const_0 }
//line :830:1
func A_arbace_g2a_print_code__init_part1_A_Init__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); return nil }
//line :830:1
func A_arbace_g2a_print_code__init_part1_A_Load__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); A_arbace_g2a_print_code__init_part1_A_Unit100__O(); A_arbace_g2a_print_code__init_part1_A_Unit101__O(); A_arbace_g2a_print_code__init_part1_A_Unit102__O(); A_arbace_g2a_print_code__init_part1_A_Unit103__O(); A_arbace_g2a_print_code__init_part1_A_Unit104__O(); A_arbace_g2a_print_code__init_part1_A_Unit105__O(); A_arbace_g2a_print_code__init_part1_A_Unit106__O(); A_arbace_g2a_print_code__init_part1_A_Unit107__O(); A_arbace_g2a_print_code__init_part1_A_Unit108__O(); A_arbace_g2a_print_code__init_part1_A_Unit109__O(); A_arbace_g2a_print_code__init_part1_A_Unit110__O(); A_arbace_g2a_print_code__init_part1_A_Unit111__O(); A_arbace_g2a_print_code__init_part1_A_Unit112__O(); A_arbace_g2a_print_code__init_part1_A_Unit113__O(); A_arbace_g2a_print_code__init_part1_A_Unit114__O(); A_arbace_g2a_print_code__init_part1_A_Unit115__O(); A_arbace_g2a_print_code__init_part1_A_Unit116__O(); A_arbace_g2a_print_code__init_part1_A_Unit117__O(); A_arbace_g2a_print_code__init_part1_A_Unit118__O(); A_arbace_g2a_print_code__init_part1_A_Unit119__O(); A_arbace_g2a_print_code__init_part1_A_Unit120__O(); A_arbace_g2a_print_code__init_part1_A_Unit121__O(); A_arbace_g2a_print_code__init_part1_A_Unit122__O(); A_arbace_g2a_print_code__init_part1_A_Unit123__O(); A_arbace_g2a_print_code__init_part1_A_Unit124__O(); A_arbace_g2a_print_code__init_part1_A_Unit125__O(); A_arbace_g2a_print_code__init_part1_A_Unit126__O(); A_arbace_g2a_print_code__init_part1_A_Unit127__O(); A_arbace_g2a_print_code__init_part1_A_Unit128__O(); A_arbace_g2a_print_code__init_part1_A_Unit129__O(); A_arbace_g2a_print_code__init_part1_A_Unit130__O(); A_arbace_g2a_print_code__init_part1_A_Unit131__O(); A_arbace_g2a_print_code__init_part1_A_Unit132__O(); A_arbace_g2a_print_code__init_part1_A_Unit133__O(); A_arbace_g2a_print_code__init_part1_A_Unit134__O(); A_arbace_g2a_print_code__init_part1_A_Unit135__O(); A_arbace_g2a_print_code__init_part1_A_Unit136__O(); A_arbace_g2a_print_code__init_part1_A_Unit137__O(); A_arbace_g2a_print_code__init_part1_A_Unit138__O(); A_arbace_g2a_print_code__init_part1_A_Unit139__O(); A_arbace_g2a_print_code__init_part1_A_Unit140__O(); A_arbace_g2a_print_code__init_part1_A_Unit141__O(); A_arbace_g2a_print_code__init_part1_A_Unit142__O(); A_arbace_g2a_print_code__init_part1_A_Unit143__O(); A_arbace_g2a_print_code__init_part1_A_Unit144__O(); A_arbace_g2a_print_code__init_part1_A_Unit145__O(); A_arbace_g2a_print_code__init_part1_A_Unit146__O(); A_arbace_g2a_print_code__init_part1_A_Unit147__O(); A_arbace_g2a_print_code__init_part1_A_Unit148__O(); A_arbace_g2a_print_code__init_part1_A_Unit149__O(); A_arbace_g2a_print_code__init_part1_A_Unit150__O(); A_arbace_g2a_print_code__init_part1_A_Unit151__O(); A_arbace_g2a_print_code__init_part1_A_Unit152__O(); A_arbace_g2a_print_code__init_part1_A_Unit153__O(); A_arbace_g2a_print_code__init_part1_A_Unit154__O(); A_arbace_g2a_print_code__init_part1_A_Unit155__O(); A_arbace_g2a_print_code__init_part1_A_Unit156__O(); A_arbace_g2a_print_code__init_part1_A_Unit157__O(); A_arbace_g2a_print_code__init_part1_A_Unit158__O(); A_arbace_g2a_print_code__init_part1_A_Unit159__O(); return nil }







func A_arbace_g2a_print_code__init_part1_A_Unit101__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(838, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_2; var tmp2 any = A_arbace_g2a_print_code_expr1_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_print_code_expr1_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_293, false); A_arbace_g2a_print_code_expr1_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_3)); return A_arbace_g2a_print_code__init_part1_A_const_2 }
















































































func A_arbace_g2a_print_code__init_part1_A_Unit102__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(919, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_4; var tmp2 any = A_arbace_g2a_print_code_expr0_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_print_code_expr0_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_294, false); A_arbace_g2a_print_code_expr0_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_5)); return A_arbace_g2a_print_code__init_part1_A_const_4 }

func A_arbace_g2a_print_code__init_part1_A_Unit103__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(921, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_6; var tmp2 any = A_arbace_g2a_print_code_expr_list_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_print_code_expr_list_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_295, false); A_arbace_g2a_print_code_expr_list_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_7)); return A_arbace_g2a_print_code__init_part1_A_const_6 }








func A_arbace_g2a_print_code__init_part1_A_Unit104__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(930, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_8; var tmp2 any = A_arbace_g2a_print_code_n_values_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_print_code_n_values_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_296, false); A_arbace_g2a_print_code_n_values_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_9)); return A_arbace_g2a_print_code__init_part1_A_const_8 }




func A_arbace_g2a_print_code__init_part1_A_Unit105__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(935, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_10; var tmp2 any = A_arbace_g2a_print_code_zero_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_print_code_zero_form_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_297, false); A_arbace_g2a_print_code_zero_form_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_11)); return A_arbace_g2a_print_code__init_part1_A_const_10 }

func A_arbace_g2a_print_code__init_part1_A_Unit106__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(937, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_12; var tmp2 any = A_arbace_g2a_print_code_targets_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_print_code_targets_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_298, false); A_arbace_g2a_print_code_targets_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_13)); return A_arbace_g2a_print_code__init_part1_A_const_12 }

func A_arbace_g2a_print_code__init_part1_A_Unit107__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(939, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_14; var tmp2 any = A_arbace_g2a_print_code_binding_stmt_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_print_code_binding_stmt_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_299, false); A_arbace_g2a_print_code_binding_stmt_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_15)); return A_arbace_g2a_print_code__init_part1_A_const_14 }





















func A_arbace_g2a_print_code__init_part1_A_Unit108__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(961, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_16; var tmp2 any = A_arbace_g2a_print_code_type_binding_stmt_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_print_code_type_binding_stmt_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_300, false); A_arbace_g2a_print_code_type_binding_stmt_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_17)); return A_arbace_g2a_print_code__init_part1_A_const_16 }








func A_arbace_g2a_print_code__init_part1_A_Unit109__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(970, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_18; var tmp2 any = A_arbace_g2a_print_code_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_print_code_assign_stmt_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_301, false); A_arbace_g2a_print_code_assign_stmt_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_19)); return A_arbace_g2a_print_code__init_part1_A_const_18 }









func A_arbace_g2a_print_code__init_part1_A_Unit110__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(980, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_20; var tmp2 any = A_arbace_g2a_print_code_simple_stmt_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_print_code_simple_stmt_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_302, false); A_arbace_g2a_print_code_simple_stmt_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_21)); return A_arbace_g2a_print_code__init_part1_A_const_20 }



















func A_arbace_g2a_print_code__init_part1_A_Unit111__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1000, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_22; var tmp2 any = A_arbace_g2a_print_code_clause_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_g2a_print_code_clause_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_303, false); A_arbace_g2a_print_code_clause_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_23)); return A_arbace_g2a_print_code__init_part1_A_const_22 }

func A_arbace_g2a_print_code__init_part1_A_Unit112__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1002, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_24; var tmp2 any = A_arbace_g2a_print_code_control_clause_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_print_code_control_clause_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_304, false); A_arbace_g2a_print_code_control_clause_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_25)); return A_arbace_g2a_print_code__init_part1_A_const_24 }

















func A_arbace_g2a_print_code__init_part1_A_Unit113__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1020, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_26; var tmp2 any = A_arbace_g2a_print_code_branch_forms_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_g2a_print_code_branch_forms_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_305, false); A_arbace_g2a_print_code_branch_forms_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_27)); return A_arbace_g2a_print_code__init_part1_A_const_26 }




func A_arbace_g2a_print_code__init_part1_A_Unit114__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1025, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_28; var tmp2 any = A_arbace_g2a_print_code_branch_opts_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_print_code_branch_opts_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_306, false); A_arbace_g2a_print_code_branch_opts_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_29)); return A_arbace_g2a_print_code__init_part1_A_const_28 }




func A_arbace_g2a_print_code__init_part1_A_Unit115__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1030, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_30; var tmp2 any = A_arbace_g2a_print_code_if_like_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_g2a_print_code_if_like_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_307, false); A_arbace_g2a_print_code_if_like_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_31)); return A_arbace_g2a_print_code__init_part1_A_const_30 }

func A_arbace_g2a_print_code__init_part1_A_Unit116__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1032, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_33)); return A_arbace_g2a_print_code__init_part1_A_const_32 }

func A_arbace_g2a_print_code__init_part1_A_Unit117__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1034, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_34; var tmp2 any = A_arbace_g2a_print_code_else_part_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_print_code_else_part_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_308, false); A_arbace_g2a_print_code_else_part_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_35)); return A_arbace_g2a_print_code__init_part1_A_const_34 }





func A_arbace_g2a_print_code__init_part1_A_Unit118__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1040, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_32; var tmp2 any = A_arbace_g2a_print_code_if_stmt_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_g2a_print_code_if_stmt_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_309, false); A_arbace_g2a_print_code_if_stmt_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_36)); return A_arbace_g2a_print_code__init_part1_A_const_32 }







































func A_arbace_g2a_print_code__init_part1_A_Unit119__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1080, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_37; var tmp2 any = A_arbace_g2a_print_code_clause_list_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_print_code_clause_list_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_310, false); A_arbace_g2a_print_code_clause_list_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_38)); return A_arbace_g2a_print_code__init_part1_A_const_37 }





















func A_arbace_g2a_print_code__init_part1_A_Unit120__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1102, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_39; var tmp2 any = A_arbace_g2a_print_code_case_exprs_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_print_code_case_exprs_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_311, false); A_arbace_g2a_print_code_case_exprs_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_40)); return A_arbace_g2a_print_code__init_part1_A_const_39 }




func A_arbace_g2a_print_code__init_part1_A_Unit121__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1107, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_41; var tmp2 any = A_arbace_g2a_print_code_case_types_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_g2a_print_code_case_types_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_312, false); A_arbace_g2a_print_code_case_types_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_42)); return A_arbace_g2a_print_code__init_part1_A_const_41 }




func A_arbace_g2a_print_code__init_part1_A_Unit122__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1112, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_43; var tmp2 any = A_arbace_g2a_print_code_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_g2a_print_code_switch_stmt_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_313, false); A_arbace_g2a_print_code_switch_stmt_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_44)); return A_arbace_g2a_print_code__init_part1_A_const_43 }











func A_arbace_g2a_print_code__init_part1_A_Unit123__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1124, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_45; var tmp2 any = A_arbace_g2a_print_code_type_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_g2a_print_code_type_switch_stmt_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_314, false); A_arbace_g2a_print_code_type_switch_stmt_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_46)); return A_arbace_g2a_print_code__init_part1_A_const_45 }
















func A_arbace_g2a_print_code__init_part1_A_Unit124__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1141, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_47; var tmp2 any = A_arbace_g2a_print_code_comm_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_g2a_print_code_comm_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_315, false); A_arbace_g2a_print_code_comm_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_48)); return A_arbace_g2a_print_code__init_part1_A_const_47 }




func A_arbace_g2a_print_code__init_part1_A_Unit125__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1146, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_49; var tmp2 any = A_arbace_g2a_print_code_select_stmt_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_g2a_print_code_select_stmt_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_316, false); A_arbace_g2a_print_code_select_stmt_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_50)); return A_arbace_g2a_print_code__init_part1_A_const_49 }





func A_arbace_g2a_print_code__init_part1_A_Unit126__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1152, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_51; var tmp2 any = A_arbace_g2a_print_code_for_stmt_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_g2a_print_code_for_stmt_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_317, false); A_arbace_g2a_print_code_for_stmt_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_52)); return A_arbace_g2a_print_code__init_part1_A_const_51 }






func A_arbace_g2a_print_code__init_part1_A_Unit127__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1159, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_53; var tmp2 any = A_arbace_g2a_print_code_while_stmt_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_g2a_print_code_while_stmt_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_318, false); A_arbace_g2a_print_code_while_stmt_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_54)); return A_arbace_g2a_print_code__init_part1_A_const_53 }





func A_arbace_g2a_print_code__init_part1_A_Unit128__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1165, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_55; var tmp2 any = A_arbace_g2a_print_code_range_stmt_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_g2a_print_code_range_stmt_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_319, false); A_arbace_g2a_print_code_range_stmt_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_56)); return A_arbace_g2a_print_code__init_part1_A_const_55 }












func A_arbace_g2a_print_code__init_part1_A_Unit129__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1178, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_58)); return A_arbace_g2a_print_code__init_part1_A_const_57 }

func A_arbace_g2a_print_code__init_part1_A_Unit130__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1180, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_59; var tmp2 any = A_arbace_g2a_print_code_print_stmt_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_g2a_print_code_print_stmt_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_320, false); A_arbace_g2a_print_code_print_stmt_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_60)); return A_arbace_g2a_print_code__init_part1_A_const_59 }





























func A_arbace_g2a_print_code__init_part1_A_Unit131__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1210, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_61; var tmp2 any = A_arbace_g2a_print_code_flatten_stmts_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_g2a_print_code_flatten_stmts_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_321, false); A_arbace_g2a_print_code_flatten_stmts_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_62)); return A_arbace_g2a_print_code__init_part1_A_const_61 }






























func A_arbace_g2a_print_code__init_part1_A_Unit132__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1241, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_63; var tmp2 any = A_arbace_g2a_print_code_item_t_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_g2a_print_code_item_t_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_322, false); A_arbace_g2a_print_code_item_t_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_64)); return A_arbace_g2a_print_code__init_part1_A_const_63 }

func A_arbace_g2a_print_code__init_part1_A_Unit133__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1243, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_57; var tmp2 any = A_arbace_g2a_print_code_label_stmt_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_g2a_print_code_label_stmt_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_323, false); A_arbace_g2a_print_code_label_stmt_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_65)); return A_arbace_g2a_print_code__init_part1_A_const_57 }
















func A_arbace_g2a_print_code__init_part1_A_Unit134__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1260, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_66; var tmp2 any = A_arbace_g2a_print_code_bind_target_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_g2a_print_code_bind_target_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_324, false); A_arbace_g2a_print_code_bind_target_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_67)); return A_arbace_g2a_print_code__init_part1_A_const_66 }

func A_arbace_g2a_print_code__init_part1_A_Unit135__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1262, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_68; var tmp2 any = A_arbace_g2a_print_code_const_bind_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_g2a_print_code_const_bind_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_325, false); A_arbace_g2a_print_code_const_bind_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_69)); return A_arbace_g2a_print_code__init_part1_A_const_68 }




func A_arbace_g2a_print_code__init_part1_A_Unit136__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1267, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_70; var tmp2 any = A_arbace_g2a_print_code_group_consts_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_g2a_print_code_group_consts_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_326, false); A_arbace_g2a_print_code_group_consts_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_71)); return A_arbace_g2a_print_code__init_part1_A_const_70 }













func A_arbace_g2a_print_code__init_part1_A_Unit137__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1281, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_72; var tmp2 any = A_arbace_g2a_print_code_label_target_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_g2a_print_code_label_target_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_327, false); A_arbace_g2a_print_code_label_target_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_73)); return A_arbace_g2a_print_code__init_part1_A_const_72 }




func A_arbace_g2a_print_code__init_part1_A_Unit138__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1286, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_74; var tmp2 any = A_arbace_g2a_print_code_label_of_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_g2a_print_code_label_of_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_328, false); A_arbace_g2a_print_code_label_of_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_75)); return A_arbace_g2a_print_code__init_part1_A_const_74 }





func A_arbace_g2a_print_code__init_part1_A_Unit139__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1292, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_76; var tmp2 any = A_arbace_g2a_print_code_const_spec_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_g2a_print_code_const_spec_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_329, false); A_arbace_g2a_print_code_const_spec_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_77)); return A_arbace_g2a_print_code__init_part1_A_const_76 }











func A_arbace_g2a_print_code__init_part1_A_Unit140__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1304, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_79)); return A_arbace_g2a_print_code__init_part1_A_const_78 }

func A_arbace_g2a_print_code__init_part1_A_Unit141__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1306, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_80; var tmp2 any = A_arbace_g2a_print_code_const_group_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_g2a_print_code_const_group_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_330, false); A_arbace_g2a_print_code_const_group_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_81)); return A_arbace_g2a_print_code__init_part1_A_const_80 }

















func A_arbace_g2a_print_code__init_part1_A_Unit142__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1324, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_82; var tmp2 any = A_arbace_g2a_print_code_group_target_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_g2a_print_code_group_target_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_331, false); A_arbace_g2a_print_code_group_target_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_83)); return A_arbace_g2a_print_code__init_part1_A_const_82 }




func A_arbace_g2a_print_code__init_part1_A_Unit143__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1329, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_84; var tmp2 any = A_arbace_g2a_print_code_stmt_list_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_g2a_print_code_stmt_list_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_332, false); A_arbace_g2a_print_code_stmt_list_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_85)); return A_arbace_g2a_print_code__init_part1_A_const_84 }










































func A_arbace_g2a_print_code__init_part1_A_Unit144__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1372, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_86; var tmp2 any = A_arbace_g2a_print_code_block_body_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_g2a_print_code_block_body_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_333, false); A_arbace_g2a_print_code_block_body_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_87)); return A_arbace_g2a_print_code__init_part1_A_const_86 }








































func A_arbace_g2a_print_code__init_part1_A_Unit145__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1413, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_88; var tmp2 any = A_arbace_g2a_print_code_stmt_list_one_line_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_g2a_print_code_stmt_list_one_line_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_334, false); A_arbace_g2a_print_code_stmt_list_one_line_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_89)); return A_arbace_g2a_print_code__init_part1_A_const_88 }




















func A_arbace_g2a_print_code__init_part1_A_Unit146__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1434, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_90; var tmp2 any = A_arbace_g2a_print_code_parse_decl_head_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_g2a_print_code_parse_decl_head_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_335, false); A_arbace_g2a_print_code_parse_decl_head_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_91)); return A_arbace_g2a_print_code__init_part1_A_const_90 }







func A_arbace_g2a_print_code__init_part1_A_Unit147__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1442, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_92; var tmp2 any = A_arbace_g2a_print_code_generic_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_g2a_print_code_generic_type_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_336, false); A_arbace_g2a_print_code_generic_type_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_93)); return A_arbace_g2a_print_code__init_part1_A_const_92 }




func A_arbace_g2a_print_code__init_part1_A_Unit148__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1447, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_94; var tmp2 any = A_arbace_g2a_print_code_func_decl_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_g2a_print_code_func_decl_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_337, false); A_arbace_g2a_print_code_func_decl_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_95)); return A_arbace_g2a_print_code__init_part1_A_const_94 }




























func A_arbace_g2a_print_code__init_part1_A_Unit149__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1476, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_96; var tmp2 any = A_arbace_g2a_print_code_spec_name_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_g2a_print_code_spec_name_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_338, false); A_arbace_g2a_print_code_spec_name_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_97)); return A_arbace_g2a_print_code__init_part1_A_const_96 }

func A_arbace_g2a_print_code__init_part1_A_Unit150__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1478, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_98; var tmp2 any = A_arbace_g2a_print_code_value_spec_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_g2a_print_code_value_spec_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_339, false); A_arbace_g2a_print_code_value_spec_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_99)); return A_arbace_g2a_print_code__init_part1_A_const_98 }











func A_arbace_g2a_print_code__init_part1_A_Unit151__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1490, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_78; var tmp2 any = A_arbace_g2a_print_code_keep_type_column_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_g2a_print_code_keep_type_column_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_340, false); A_arbace_g2a_print_code_keep_type_column_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_100)); return A_arbace_g2a_print_code__init_part1_A_const_78 }


















func A_arbace_g2a_print_code__init_part1_A_Unit152__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1509, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_101; var tmp2 any = A_arbace_g2a_print_code_spec_t_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_g2a_print_code_spec_t_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_341, false); A_arbace_g2a_print_code_spec_t_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_102)); return A_arbace_g2a_print_code__init_part1_A_const_101 }


func A_arbace_g2a_print_code__init_part1_A_Unit153__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1512, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_103; var tmp2 any = A_arbace_g2a_print_code_group_decl_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_g2a_print_code_group_decl_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_342, false); A_arbace_g2a_print_code_group_decl_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_104)); return A_arbace_g2a_print_code__init_part1_A_const_103 }




































func A_arbace_g2a_print_code__init_part1_A_Unit154__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1549, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_105; var tmp2 any = A_arbace_g2a_print_code_const_var_decl_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_g2a_print_code_const_var_decl_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_343, false); A_arbace_g2a_print_code_const_var_decl_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_106)); return A_arbace_g2a_print_code__init_part1_A_const_105 }














func A_arbace_g2a_print_code__init_part1_A_Unit155__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1564, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_107; var tmp2 any = A_arbace_g2a_print_code_type_spec_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_g2a_print_code_type_spec_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_344, false); A_arbace_g2a_print_code_type_spec_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_108)); return A_arbace_g2a_print_code__init_part1_A_const_107 }







func A_arbace_g2a_print_code__init_part1_A_Unit156__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1572, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_109; var tmp2 any = A_arbace_g2a_print_code_parse_type_spec_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_g2a_print_code_parse_type_spec_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_345, false); A_arbace_g2a_print_code_parse_type_spec_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_110)); return A_arbace_g2a_print_code__init_part1_A_const_109 }





func A_arbace_g2a_print_code__init_part1_A_Unit157__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1578, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_111; var tmp2 any = A_arbace_g2a_print_code_type_decl_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_g2a_print_code_type_decl_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_346, false); A_arbace_g2a_print_code_type_decl_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_112)); return A_arbace_g2a_print_code__init_part1_A_const_111 }











func A_arbace_g2a_print_code__init_part1_A_Unit158__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1590, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_113; var tmp2 any = A_arbace_g2a_print_code_decl_doc_and_directives_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_g2a_print_code_decl_doc_and_directives_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_347, false); A_arbace_g2a_print_code_decl_doc_and_directives_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_114)); return A_arbace_g2a_print_code__init_part1_A_const_113 }





















func A_arbace_g2a_print_code__init_part1_A_Unit159__O() any { A_arbace_g2a_print_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1612, 1); var tmp1 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_115; var tmp2 any = A_arbace_g2a_print_code_top_decl_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_g2a_print_code_top_decl_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_348, false); A_arbace_g2a_print_code_top_decl_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_code__init_part1_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_code__init_part1_A_const_116)); return A_arbace_g2a_print_code__init_part1_A_const_115 }



type A_arbace_g2a_print_code__init_A struct{ jrt.Object }

func A_arbace_g2a_print_code__init_A_New() *A_arbace_g2a_print_code__init_A { t := &A_arbace_g2a_print_code__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_code__init_A) Ctor() {}

func (t *A_arbace_g2a_print_code__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_code__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_code__init_A_class }

func (t *A_arbace_g2a_print_code__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_code__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_code__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_code__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_code__init_A); return ok }

func A_arbace_g2a_print_code__init_A_Cast(x any) *A_arbace_g2a_print_code__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_code__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_code__init_A_class)) }; return v }



type A_arbace_g2a_print_code__init_part0_A struct{ jrt.Object }

var A_arbace_g2a_print_code__init_part0_A_const_pool *jrt.RefArray

var A_arbace_g2a_print_code__init_part0_A_const_0 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_1 any

var A_arbace_g2a_print_code__init_part0_A_const_2 any

var A_arbace_g2a_print_code__init_part0_A_const_3 any

var A_arbace_g2a_print_code__init_part0_A_const_4 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_5 any

var A_arbace_g2a_print_code__init_part0_A_const_6 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_7 any

var A_arbace_g2a_print_code__init_part0_A_const_8 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_9 any

var A_arbace_g2a_print_code__init_part0_A_const_10 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_11 any

var A_arbace_g2a_print_code__init_part0_A_const_12 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_13 any

var A_arbace_g2a_print_code__init_part0_A_const_14 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_15 any

var A_arbace_g2a_print_code__init_part0_A_const_16 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_17 any

var A_arbace_g2a_print_code__init_part0_A_const_18 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_19 any

var A_arbace_g2a_print_code__init_part0_A_const_20 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_21 any

var A_arbace_g2a_print_code__init_part0_A_const_22 any

var A_arbace_g2a_print_code__init_part0_A_const_23 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_24 any

var A_arbace_g2a_print_code__init_part0_A_const_25 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_26 any

var A_arbace_g2a_print_code__init_part0_A_const_27 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_28 any

var A_arbace_g2a_print_code__init_part0_A_const_29 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_30 any

var A_arbace_g2a_print_code__init_part0_A_const_31 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_32 any

var A_arbace_g2a_print_code__init_part0_A_const_33 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_34 any

var A_arbace_g2a_print_code__init_part0_A_const_35 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_36 any

var A_arbace_g2a_print_code__init_part0_A_const_37 any

var A_arbace_g2a_print_code__init_part0_A_const_38 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_39 any

var A_arbace_g2a_print_code__init_part0_A_const_40 any

var A_arbace_g2a_print_code__init_part0_A_const_41 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_42 any

var A_arbace_g2a_print_code__init_part0_A_const_43 any

var A_arbace_g2a_print_code__init_part0_A_const_44 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_45 any

var A_arbace_g2a_print_code__init_part0_A_const_46 any

var A_arbace_g2a_print_code__init_part0_A_const_47 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_48 any

var A_arbace_g2a_print_code__init_part0_A_const_49 any

var A_arbace_g2a_print_code__init_part0_A_const_50 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_51 any

var A_arbace_g2a_print_code__init_part0_A_const_52 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_53 any

var A_arbace_g2a_print_code__init_part0_A_const_54 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_55 any

var A_arbace_g2a_print_code__init_part0_A_const_56 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_57 any

var A_arbace_g2a_print_code__init_part0_A_const_58 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_59 any

var A_arbace_g2a_print_code__init_part0_A_const_60 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_61 any

var A_arbace_g2a_print_code__init_part0_A_const_62 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_63 any

var A_arbace_g2a_print_code__init_part0_A_const_64 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_65 any

var A_arbace_g2a_print_code__init_part0_A_const_66 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_67 any

var A_arbace_g2a_print_code__init_part0_A_const_68 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_69 any

var A_arbace_g2a_print_code__init_part0_A_const_70 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_71 any

var A_arbace_g2a_print_code__init_part0_A_const_72 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_73 any

var A_arbace_g2a_print_code__init_part0_A_const_74 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_75 any

var A_arbace_g2a_print_code__init_part0_A_const_76 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_77 any

var A_arbace_g2a_print_code__init_part0_A_const_78 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_79 any

var A_arbace_g2a_print_code__init_part0_A_const_80 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_81 any

var A_arbace_g2a_print_code__init_part0_A_const_82 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_83 any

var A_arbace_g2a_print_code__init_part0_A_const_84 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_85 any

var A_arbace_g2a_print_code__init_part0_A_const_86 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_87 any

var A_arbace_g2a_print_code__init_part0_A_const_88 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_89 any

var A_arbace_g2a_print_code__init_part0_A_const_90 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_91 any

var A_arbace_g2a_print_code__init_part0_A_const_92 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_93 any

var A_arbace_g2a_print_code__init_part0_A_const_94 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_95 any

var A_arbace_g2a_print_code__init_part0_A_const_96 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_97 any

var A_arbace_g2a_print_code__init_part0_A_const_98 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_99 any

var A_arbace_g2a_print_code__init_part0_A_const_100 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_101 any

var A_arbace_g2a_print_code__init_part0_A_const_102 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_103 any

var A_arbace_g2a_print_code__init_part0_A_const_104 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_105 any

var A_arbace_g2a_print_code__init_part0_A_const_106 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_107 any

var A_arbace_g2a_print_code__init_part0_A_const_108 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_109 any

var A_arbace_g2a_print_code__init_part0_A_const_110 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_111 any

var A_arbace_g2a_print_code__init_part0_A_const_112 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_113 any

var A_arbace_g2a_print_code__init_part0_A_const_114 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_115 any

var A_arbace_g2a_print_code__init_part0_A_const_116 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_117 any

var A_arbace_g2a_print_code__init_part0_A_const_118 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_119 any

var A_arbace_g2a_print_code__init_part0_A_const_120 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_121 any

var A_arbace_g2a_print_code__init_part0_A_const_122 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_123 any

var A_arbace_g2a_print_code__init_part0_A_const_124 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_125 any

var A_arbace_g2a_print_code__init_part0_A_const_126 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_127 any

var A_arbace_g2a_print_code__init_part0_A_const_128 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_129 any

var A_arbace_g2a_print_code__init_part0_A_const_130 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_131 any

var A_arbace_g2a_print_code__init_part0_A_const_132 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_133 any

var A_arbace_g2a_print_code__init_part0_A_const_134 any

var A_arbace_g2a_print_code__init_part0_A_const_135 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_136 any

var A_arbace_g2a_print_code__init_part0_A_const_137 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_138 any

var A_arbace_g2a_print_code__init_part0_A_const_139 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_140 any

var A_arbace_g2a_print_code__init_part0_A_const_141 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_142 any

var A_arbace_g2a_print_code__init_part0_A_const_143 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_144 any

var A_arbace_g2a_print_code__init_part0_A_const_145 any

var A_arbace_g2a_print_code__init_part0_A_const_146 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_147 any

var A_arbace_g2a_print_code__init_part0_A_const_148 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_149 any

var A_arbace_g2a_print_code__init_part0_A_const_150 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_151 any

var A_arbace_g2a_print_code__init_part0_A_const_152 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_153 any

var A_arbace_g2a_print_code__init_part0_A_const_154 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_155 any

var A_arbace_g2a_print_code__init_part0_A_const_156 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_157 any

var A_arbace_g2a_print_code__init_part0_A_const_158 any

var A_arbace_g2a_print_code__init_part0_A_const_159 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_160 any

var A_arbace_g2a_print_code__init_part0_A_const_161 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_162 any

var A_arbace_g2a_print_code__init_part0_A_const_163 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_164 any

var A_arbace_g2a_print_code__init_part0_A_const_165 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_166 any

var A_arbace_g2a_print_code__init_part0_A_const_167 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_168 any

var A_arbace_g2a_print_code__init_part0_A_const_169 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_170 any

var A_arbace_g2a_print_code__init_part0_A_const_171 any

var A_arbace_g2a_print_code__init_part0_A_const_172 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_173 any

var A_arbace_g2a_print_code__init_part0_A_const_174 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_175 any

var A_arbace_g2a_print_code__init_part0_A_const_176 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_177 any

var A_arbace_g2a_print_code__init_part0_A_const_178 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_179 any

var A_arbace_g2a_print_code__init_part0_A_const_180 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_181 any

var A_arbace_g2a_print_code__init_part0_A_const_182 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_183 any

var A_arbace_g2a_print_code__init_part0_A_const_184 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_185 any

var A_arbace_g2a_print_code__init_part0_A_const_186 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_187 any

var A_arbace_g2a_print_code__init_part0_A_const_188 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_189 any

var A_arbace_g2a_print_code__init_part0_A_const_190 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_191 any

var A_arbace_g2a_print_code__init_part0_A_const_192 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_193 any

var A_arbace_g2a_print_code__init_part0_A_const_194 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_195 any

var A_arbace_g2a_print_code__init_part0_A_const_196 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_197 any

var A_arbace_g2a_print_code__init_part0_A_const_198 *lang.Var

var A_arbace_g2a_print_code__init_part0_A_const_199 any

var A_arbace_g2a_print_code__init_part0_A_init jrt.ClassInit

func A_arbace_g2a_print_code__init_part0_A_Init() { if !A_arbace_g2a_print_code__init_part0_A_init.Done() { A_arbace_g2a_print_code__init_part0_A_init.Run(A_arbace_g2a_print_code__init_part0_A_clinit) } }

func A_arbace_g2a_print_code__init_part0_A_clinit() { A_arbace_g2a_print_code__init_part0_A_clinit_p0(); A_arbace_g2a_print_code__init_part0_A_clinit_p1(); A_arbace_g2a_print_code__init_part0_A_clinit_p2(); A_arbace_g2a_print_code__init_part0_A_clinit_p3(); A_arbace_g2a_print_code__init_part0_A_clinit_p4(); A_arbace_g2a_print_code__init_part0_A_clinit_p5(); A_arbace_g2a_print_code__init_part0_A_clinit_p6(); A_arbace_g2a_print_code__init_part0_A_clinit_p7(); A_arbace_g2a_print_code__init_part0_A_clinit_p8(); A_arbace_g2a_print_code__init_part0_A_clinit_p9(); A_arbace_g2a_print_code__init_part0_A_clinit_p10(); A_arbace_g2a_print_code__init_part0_A_clinit_p11(); A_arbace_g2a_print_code__init_part0_A_clinit_p12(); A_arbace_g2a_print_code__init_part0_A_clinit_p13(); A_arbace_g2a_print_code__init_part0_A_clinit_p14() }

func A_arbace_g2a_print_code__init_part0_A_clinit_p0() { A_arbace_g2a_print_code__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_212, 278); A_arbace_g2a_print_code__init_part0_A_const_0 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[78]); A_arbace_g2a_print_code__init_part0_A_const_1 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[79]; A_arbace_g2a_print_code__init_part0_A_const_2 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[80]; A_arbace_g2a_print_code__init_part0_A_const_3 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[81]; A_arbace_g2a_print_code__init_part0_A_const_4 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[82]); A_arbace_g2a_print_code__init_part0_A_const_5 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[83]; A_arbace_g2a_print_code__init_part0_A_const_6 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[84]); A_arbace_g2a_print_code__init_part0_A_const_7 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[85]; A_arbace_g2a_print_code__init_part0_A_const_8 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[86]); A_arbace_g2a_print_code__init_part0_A_const_9 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[87]; A_arbace_g2a_print_code__init_part0_A_const_10 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[88]); A_arbace_g2a_print_code__init_part0_A_const_11 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[89]; A_arbace_g2a_print_code__init_part0_A_const_12 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[90]) }

func A_arbace_g2a_print_code__init_part0_A_clinit_p1() { A_arbace_g2a_print_code__init_part0_A_const_13 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[91]; A_arbace_g2a_print_code__init_part0_A_const_14 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[92]); A_arbace_g2a_print_code__init_part0_A_const_15 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[93]; A_arbace_g2a_print_code__init_part0_A_const_16 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[94]); A_arbace_g2a_print_code__init_part0_A_const_17 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[95]; A_arbace_g2a_print_code__init_part0_A_const_18 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[96]); A_arbace_g2a_print_code__init_part0_A_const_19 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[97]; A_arbace_g2a_print_code__init_part0_A_const_20 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[98]); A_arbace_g2a_print_code__init_part0_A_const_21 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[99]; A_arbace_g2a_print_code__init_part0_A_const_22 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[100]; A_arbace_g2a_print_code__init_part0_A_const_23 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[101]); A_arbace_g2a_print_code__init_part0_A_const_24 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[102]; A_arbace_g2a_print_code__init_part0_A_const_25 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[103]); A_arbace_g2a_print_code__init_part0_A_const_26 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[104] }

func A_arbace_g2a_print_code__init_part0_A_clinit_p2() { A_arbace_g2a_print_code__init_part0_A_const_27 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[105]); A_arbace_g2a_print_code__init_part0_A_const_28 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[106]; A_arbace_g2a_print_code__init_part0_A_const_29 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[107]); A_arbace_g2a_print_code__init_part0_A_const_30 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[108]; A_arbace_g2a_print_code__init_part0_A_const_31 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[109]); A_arbace_g2a_print_code__init_part0_A_const_32 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[110]; A_arbace_g2a_print_code__init_part0_A_const_33 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[111]); A_arbace_g2a_print_code__init_part0_A_const_34 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[112]; A_arbace_g2a_print_code__init_part0_A_const_35 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[113]); A_arbace_g2a_print_code__init_part0_A_const_36 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[114]; A_arbace_g2a_print_code__init_part0_A_const_37 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[115]; A_arbace_g2a_print_code__init_part0_A_const_38 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[116]); A_arbace_g2a_print_code__init_part0_A_const_39 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[117]; A_arbace_g2a_print_code__init_part0_A_const_40 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[118] }

func A_arbace_g2a_print_code__init_part0_A_clinit_p3() { A_arbace_g2a_print_code__init_part0_A_const_41 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[119]); A_arbace_g2a_print_code__init_part0_A_const_42 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[120]; A_arbace_g2a_print_code__init_part0_A_const_43 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[121]; A_arbace_g2a_print_code__init_part0_A_const_44 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[122]); A_arbace_g2a_print_code__init_part0_A_const_45 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[123]; A_arbace_g2a_print_code__init_part0_A_const_46 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[124]; A_arbace_g2a_print_code__init_part0_A_const_47 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[125]); A_arbace_g2a_print_code__init_part0_A_const_48 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[126]; A_arbace_g2a_print_code__init_part0_A_const_49 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[127]; A_arbace_g2a_print_code__init_part0_A_const_50 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[128]); A_arbace_g2a_print_code__init_part0_A_const_51 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[129]; A_arbace_g2a_print_code__init_part0_A_const_52 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[130]); A_arbace_g2a_print_code__init_part0_A_const_53 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[131]; A_arbace_g2a_print_code__init_part0_A_const_54 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[132]) }

func A_arbace_g2a_print_code__init_part0_A_clinit_p4() { A_arbace_g2a_print_code__init_part0_A_const_55 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[133]; A_arbace_g2a_print_code__init_part0_A_const_56 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[134]); A_arbace_g2a_print_code__init_part0_A_const_57 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[135]; A_arbace_g2a_print_code__init_part0_A_const_58 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[136]); A_arbace_g2a_print_code__init_part0_A_const_59 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[137]; A_arbace_g2a_print_code__init_part0_A_const_60 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[138]); A_arbace_g2a_print_code__init_part0_A_const_61 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[139]; A_arbace_g2a_print_code__init_part0_A_const_62 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[140]); A_arbace_g2a_print_code__init_part0_A_const_63 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[141]; A_arbace_g2a_print_code__init_part0_A_const_64 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[142]); A_arbace_g2a_print_code__init_part0_A_const_65 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[143]; A_arbace_g2a_print_code__init_part0_A_const_66 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[144]); A_arbace_g2a_print_code__init_part0_A_const_67 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[145] }

func A_arbace_g2a_print_code__init_part0_A_clinit_p5() { A_arbace_g2a_print_code__init_part0_A_const_68 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[146]); A_arbace_g2a_print_code__init_part0_A_const_69 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[147]; A_arbace_g2a_print_code__init_part0_A_const_70 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[148]); A_arbace_g2a_print_code__init_part0_A_const_71 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[149]; A_arbace_g2a_print_code__init_part0_A_const_72 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[150]); A_arbace_g2a_print_code__init_part0_A_const_73 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[151]; A_arbace_g2a_print_code__init_part0_A_const_74 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[152]); A_arbace_g2a_print_code__init_part0_A_const_75 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[153]; A_arbace_g2a_print_code__init_part0_A_const_76 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[154]); A_arbace_g2a_print_code__init_part0_A_const_77 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[155]; A_arbace_g2a_print_code__init_part0_A_const_78 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[156]); A_arbace_g2a_print_code__init_part0_A_const_79 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[157]; A_arbace_g2a_print_code__init_part0_A_const_80 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[158]) }

func A_arbace_g2a_print_code__init_part0_A_clinit_p6() { A_arbace_g2a_print_code__init_part0_A_const_81 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[159]; A_arbace_g2a_print_code__init_part0_A_const_82 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[160]); A_arbace_g2a_print_code__init_part0_A_const_83 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[161]; A_arbace_g2a_print_code__init_part0_A_const_84 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[162]); A_arbace_g2a_print_code__init_part0_A_const_85 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[163]; A_arbace_g2a_print_code__init_part0_A_const_86 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[164]); A_arbace_g2a_print_code__init_part0_A_const_87 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[165]; A_arbace_g2a_print_code__init_part0_A_const_88 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[166]); A_arbace_g2a_print_code__init_part0_A_const_89 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[167]; A_arbace_g2a_print_code__init_part0_A_const_90 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[168]); A_arbace_g2a_print_code__init_part0_A_const_91 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[169]; A_arbace_g2a_print_code__init_part0_A_const_92 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[170]); A_arbace_g2a_print_code__init_part0_A_const_93 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[171] }

func A_arbace_g2a_print_code__init_part0_A_clinit_p7() { A_arbace_g2a_print_code__init_part0_A_const_94 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[172]); A_arbace_g2a_print_code__init_part0_A_const_95 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[173]; A_arbace_g2a_print_code__init_part0_A_const_96 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[174]); A_arbace_g2a_print_code__init_part0_A_const_97 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[175]; A_arbace_g2a_print_code__init_part0_A_const_98 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[176]); A_arbace_g2a_print_code__init_part0_A_const_99 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[177]; A_arbace_g2a_print_code__init_part0_A_const_100 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[178]); A_arbace_g2a_print_code__init_part0_A_const_101 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[179]; A_arbace_g2a_print_code__init_part0_A_const_102 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[180]); A_arbace_g2a_print_code__init_part0_A_const_103 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[181]; A_arbace_g2a_print_code__init_part0_A_const_104 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[182]); A_arbace_g2a_print_code__init_part0_A_const_105 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[183]; A_arbace_g2a_print_code__init_part0_A_const_106 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[184]) }

func A_arbace_g2a_print_code__init_part0_A_clinit_p8() { A_arbace_g2a_print_code__init_part0_A_const_107 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[185]; A_arbace_g2a_print_code__init_part0_A_const_108 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[186]); A_arbace_g2a_print_code__init_part0_A_const_109 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[187]; A_arbace_g2a_print_code__init_part0_A_const_110 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[188]); A_arbace_g2a_print_code__init_part0_A_const_111 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[189]; A_arbace_g2a_print_code__init_part0_A_const_112 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[190]); A_arbace_g2a_print_code__init_part0_A_const_113 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[191]; A_arbace_g2a_print_code__init_part0_A_const_114 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[192]); A_arbace_g2a_print_code__init_part0_A_const_115 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[193]; A_arbace_g2a_print_code__init_part0_A_const_116 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[194]); A_arbace_g2a_print_code__init_part0_A_const_117 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[195]; A_arbace_g2a_print_code__init_part0_A_const_118 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[196]); A_arbace_g2a_print_code__init_part0_A_const_119 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[197] }

func A_arbace_g2a_print_code__init_part0_A_clinit_p9() { A_arbace_g2a_print_code__init_part0_A_const_120 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[198]); A_arbace_g2a_print_code__init_part0_A_const_121 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[199]; A_arbace_g2a_print_code__init_part0_A_const_122 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[200]); A_arbace_g2a_print_code__init_part0_A_const_123 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[201]; A_arbace_g2a_print_code__init_part0_A_const_124 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[202]); A_arbace_g2a_print_code__init_part0_A_const_125 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[203]; A_arbace_g2a_print_code__init_part0_A_const_126 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[204]); A_arbace_g2a_print_code__init_part0_A_const_127 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[205]; A_arbace_g2a_print_code__init_part0_A_const_128 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[206]); A_arbace_g2a_print_code__init_part0_A_const_129 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[207]; A_arbace_g2a_print_code__init_part0_A_const_130 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[208]); A_arbace_g2a_print_code__init_part0_A_const_131 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[209]; A_arbace_g2a_print_code__init_part0_A_const_132 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[210]) }

func A_arbace_g2a_print_code__init_part0_A_clinit_p10() { A_arbace_g2a_print_code__init_part0_A_const_133 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[211]; A_arbace_g2a_print_code__init_part0_A_const_134 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[212]; A_arbace_g2a_print_code__init_part0_A_const_135 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[213]); A_arbace_g2a_print_code__init_part0_A_const_136 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[214]; A_arbace_g2a_print_code__init_part0_A_const_137 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[215]); A_arbace_g2a_print_code__init_part0_A_const_138 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[216]; A_arbace_g2a_print_code__init_part0_A_const_139 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[217]); A_arbace_g2a_print_code__init_part0_A_const_140 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[218]; A_arbace_g2a_print_code__init_part0_A_const_141 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[219]); A_arbace_g2a_print_code__init_part0_A_const_142 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[220]; A_arbace_g2a_print_code__init_part0_A_const_143 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[221]); A_arbace_g2a_print_code__init_part0_A_const_144 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[222]; A_arbace_g2a_print_code__init_part0_A_const_145 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[223]; A_arbace_g2a_print_code__init_part0_A_const_146 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[224]) }

func A_arbace_g2a_print_code__init_part0_A_clinit_p11() { A_arbace_g2a_print_code__init_part0_A_const_147 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[225]; A_arbace_g2a_print_code__init_part0_A_const_148 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[226]); A_arbace_g2a_print_code__init_part0_A_const_149 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[227]; A_arbace_g2a_print_code__init_part0_A_const_150 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[228]); A_arbace_g2a_print_code__init_part0_A_const_151 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[229]; A_arbace_g2a_print_code__init_part0_A_const_152 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[230]); A_arbace_g2a_print_code__init_part0_A_const_153 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[231]; A_arbace_g2a_print_code__init_part0_A_const_154 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[232]); A_arbace_g2a_print_code__init_part0_A_const_155 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[233]; A_arbace_g2a_print_code__init_part0_A_const_156 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[234]); A_arbace_g2a_print_code__init_part0_A_const_157 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[235]; A_arbace_g2a_print_code__init_part0_A_const_158 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[236]; A_arbace_g2a_print_code__init_part0_A_const_159 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[237]); A_arbace_g2a_print_code__init_part0_A_const_160 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[238] }

func A_arbace_g2a_print_code__init_part0_A_clinit_p12() { A_arbace_g2a_print_code__init_part0_A_const_161 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[239]); A_arbace_g2a_print_code__init_part0_A_const_162 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[240]; A_arbace_g2a_print_code__init_part0_A_const_163 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[241]); A_arbace_g2a_print_code__init_part0_A_const_164 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[242]; A_arbace_g2a_print_code__init_part0_A_const_165 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[243]); A_arbace_g2a_print_code__init_part0_A_const_166 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[244]; A_arbace_g2a_print_code__init_part0_A_const_167 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[245]); A_arbace_g2a_print_code__init_part0_A_const_168 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[246]; A_arbace_g2a_print_code__init_part0_A_const_169 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[247]); A_arbace_g2a_print_code__init_part0_A_const_170 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[248]; A_arbace_g2a_print_code__init_part0_A_const_171 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[249]; A_arbace_g2a_print_code__init_part0_A_const_172 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[250]); A_arbace_g2a_print_code__init_part0_A_const_173 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[251] }

func A_arbace_g2a_print_code__init_part0_A_clinit_p13() { A_arbace_g2a_print_code__init_part0_A_const_174 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[252]); A_arbace_g2a_print_code__init_part0_A_const_175 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[253]; A_arbace_g2a_print_code__init_part0_A_const_176 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[254]); A_arbace_g2a_print_code__init_part0_A_const_177 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[255]; A_arbace_g2a_print_code__init_part0_A_const_178 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[256]); A_arbace_g2a_print_code__init_part0_A_const_179 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[257]; A_arbace_g2a_print_code__init_part0_A_const_180 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[258]); A_arbace_g2a_print_code__init_part0_A_const_181 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[259]; A_arbace_g2a_print_code__init_part0_A_const_182 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[260]); A_arbace_g2a_print_code__init_part0_A_const_183 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[261]; A_arbace_g2a_print_code__init_part0_A_const_184 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[262]); A_arbace_g2a_print_code__init_part0_A_const_185 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[263]; A_arbace_g2a_print_code__init_part0_A_const_186 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[264]) }

func A_arbace_g2a_print_code__init_part0_A_clinit_p14() { A_arbace_g2a_print_code__init_part0_A_const_187 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[265]; A_arbace_g2a_print_code__init_part0_A_const_188 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[266]); A_arbace_g2a_print_code__init_part0_A_const_189 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[267]; A_arbace_g2a_print_code__init_part0_A_const_190 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[268]); A_arbace_g2a_print_code__init_part0_A_const_191 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[269]; A_arbace_g2a_print_code__init_part0_A_const_192 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[270]); A_arbace_g2a_print_code__init_part0_A_const_193 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[271]; A_arbace_g2a_print_code__init_part0_A_const_194 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[272]); A_arbace_g2a_print_code__init_part0_A_const_195 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[273]; A_arbace_g2a_print_code__init_part0_A_const_196 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[274]); A_arbace_g2a_print_code__init_part0_A_const_197 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[275]; A_arbace_g2a_print_code__init_part0_A_const_198 = lang.Var_Cast(A_arbace_g2a_print_code__init_part0_A_const_pool.A[276]); A_arbace_g2a_print_code__init_part0_A_const_199 = A_arbace_g2a_print_code__init_part0_A_const_pool.A[277] }

func A_arbace_g2a_print_code__init_part0_A_New() *A_arbace_g2a_print_code__init_part0_A { A_arbace_g2a_print_code__init_part0_A_Init(); t := &A_arbace_g2a_print_code__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_code__init_part0_A) Ctor() {}

func (t *A_arbace_g2a_print_code__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_code__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_code__init_part0_A_class }

func (t *A_arbace_g2a_print_code__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_code__init_part0_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_code__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_code__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_code__init_part0_A); return ok }

func A_arbace_g2a_print_code__init_part0_A_Cast(x any) *A_arbace_g2a_print_code__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_code__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_code__init_part0_A_class)) }; return v }



type A_arbace_g2a_print_code__init_part1_A struct{ jrt.Object }

var A_arbace_g2a_print_code__init_part1_A_const_pool *jrt.RefArray

var A_arbace_g2a_print_code__init_part1_A_const_0 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_1 any

var A_arbace_g2a_print_code__init_part1_A_const_2 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_3 any

var A_arbace_g2a_print_code__init_part1_A_const_4 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_5 any

var A_arbace_g2a_print_code__init_part1_A_const_6 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_7 any

var A_arbace_g2a_print_code__init_part1_A_const_8 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_9 any

var A_arbace_g2a_print_code__init_part1_A_const_10 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_11 any

var A_arbace_g2a_print_code__init_part1_A_const_12 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_13 any

var A_arbace_g2a_print_code__init_part1_A_const_14 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_15 any

var A_arbace_g2a_print_code__init_part1_A_const_16 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_17 any

var A_arbace_g2a_print_code__init_part1_A_const_18 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_19 any

var A_arbace_g2a_print_code__init_part1_A_const_20 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_21 any

var A_arbace_g2a_print_code__init_part1_A_const_22 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_23 any

var A_arbace_g2a_print_code__init_part1_A_const_24 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_25 any

var A_arbace_g2a_print_code__init_part1_A_const_26 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_27 any

var A_arbace_g2a_print_code__init_part1_A_const_28 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_29 any

var A_arbace_g2a_print_code__init_part1_A_const_30 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_31 any

var A_arbace_g2a_print_code__init_part1_A_const_32 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_33 any

var A_arbace_g2a_print_code__init_part1_A_const_34 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_35 any

var A_arbace_g2a_print_code__init_part1_A_const_36 any

var A_arbace_g2a_print_code__init_part1_A_const_37 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_38 any

var A_arbace_g2a_print_code__init_part1_A_const_39 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_40 any

var A_arbace_g2a_print_code__init_part1_A_const_41 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_42 any

var A_arbace_g2a_print_code__init_part1_A_const_43 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_44 any

var A_arbace_g2a_print_code__init_part1_A_const_45 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_46 any

var A_arbace_g2a_print_code__init_part1_A_const_47 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_48 any

var A_arbace_g2a_print_code__init_part1_A_const_49 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_50 any

var A_arbace_g2a_print_code__init_part1_A_const_51 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_52 any

var A_arbace_g2a_print_code__init_part1_A_const_53 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_54 any

var A_arbace_g2a_print_code__init_part1_A_const_55 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_56 any

var A_arbace_g2a_print_code__init_part1_A_const_57 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_58 any

var A_arbace_g2a_print_code__init_part1_A_const_59 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_60 any

var A_arbace_g2a_print_code__init_part1_A_const_61 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_62 any

var A_arbace_g2a_print_code__init_part1_A_const_63 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_64 any

var A_arbace_g2a_print_code__init_part1_A_const_65 any

var A_arbace_g2a_print_code__init_part1_A_const_66 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_67 any

var A_arbace_g2a_print_code__init_part1_A_const_68 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_69 any

var A_arbace_g2a_print_code__init_part1_A_const_70 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_71 any

var A_arbace_g2a_print_code__init_part1_A_const_72 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_73 any

var A_arbace_g2a_print_code__init_part1_A_const_74 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_75 any

var A_arbace_g2a_print_code__init_part1_A_const_76 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_77 any

var A_arbace_g2a_print_code__init_part1_A_const_78 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_79 any

var A_arbace_g2a_print_code__init_part1_A_const_80 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_81 any

var A_arbace_g2a_print_code__init_part1_A_const_82 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_83 any

var A_arbace_g2a_print_code__init_part1_A_const_84 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_85 any

var A_arbace_g2a_print_code__init_part1_A_const_86 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_87 any

var A_arbace_g2a_print_code__init_part1_A_const_88 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_89 any

var A_arbace_g2a_print_code__init_part1_A_const_90 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_91 any

var A_arbace_g2a_print_code__init_part1_A_const_92 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_93 any

var A_arbace_g2a_print_code__init_part1_A_const_94 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_95 any

var A_arbace_g2a_print_code__init_part1_A_const_96 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_97 any

var A_arbace_g2a_print_code__init_part1_A_const_98 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_99 any

var A_arbace_g2a_print_code__init_part1_A_const_100 any

var A_arbace_g2a_print_code__init_part1_A_const_101 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_102 any

var A_arbace_g2a_print_code__init_part1_A_const_103 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_104 any

var A_arbace_g2a_print_code__init_part1_A_const_105 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_106 any

var A_arbace_g2a_print_code__init_part1_A_const_107 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_108 any

var A_arbace_g2a_print_code__init_part1_A_const_109 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_110 any

var A_arbace_g2a_print_code__init_part1_A_const_111 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_112 any

var A_arbace_g2a_print_code__init_part1_A_const_113 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_114 any

var A_arbace_g2a_print_code__init_part1_A_const_115 *lang.Var

var A_arbace_g2a_print_code__init_part1_A_const_116 any

var A_arbace_g2a_print_code__init_part1_A_init jrt.ClassInit

func A_arbace_g2a_print_code__init_part1_A_Init() { if !A_arbace_g2a_print_code__init_part1_A_init.Done() { A_arbace_g2a_print_code__init_part1_A_init.Run(A_arbace_g2a_print_code__init_part1_A_clinit) } }

func A_arbace_g2a_print_code__init_part1_A_clinit() { A_arbace_g2a_print_code__init_part1_A_clinit_p0(); A_arbace_g2a_print_code__init_part1_A_clinit_p1() }

func A_arbace_g2a_print_code__init_part1_A_clinit_p0() { A_arbace_g2a_print_code__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_291, 161); A_arbace_g2a_print_code__init_part1_A_const_0 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[51]); A_arbace_g2a_print_code__init_part1_A_const_1 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[52] }

func A_arbace_g2a_print_code__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_g2a_print_code__init_part0_A_Init(); tmp1 = A_arbace_g2a_print_code__init_part0_A_const_4; A_arbace_g2a_print_code__init_part1_A_const_2 = tmp1; A_arbace_g2a_print_code__init_part1_A_const_3 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[53]; var tmp2 *lang.Var; A_arbace_g2a_print_code__init_part0_A_Init(); tmp2 = A_arbace_g2a_print_code__init_part0_A_const_6; A_arbace_g2a_print_code__init_part1_A_const_4 = tmp2; A_arbace_g2a_print_code__init_part1_A_const_5 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[54]; A_arbace_g2a_print_code__init_part1_A_const_6 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[55]); A_arbace_g2a_print_code__init_part1_A_const_7 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[56]; A_arbace_g2a_print_code__init_part1_A_const_8 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[57]); A_arbace_g2a_print_code__init_part1_A_const_9 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[58]; A_arbace_g2a_print_code__init_part1_A_const_10 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[59]); A_arbace_g2a_print_code__init_part1_A_const_11 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[60]; A_arbace_g2a_print_code__init_part1_A_const_12 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[61]); A_arbace_g2a_print_code__init_part1_A_const_13 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[62]; A_arbace_g2a_print_code__init_part1_A_const_14 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[63]); A_arbace_g2a_print_code__init_part1_A_const_15 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[64]; A_arbace_g2a_print_code__init_part1_A_const_16 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[65]); A_arbace_g2a_print_code__init_part1_A_const_17 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[66]; A_arbace_g2a_print_code__init_part1_A_const_18 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[67]); A_arbace_g2a_print_code__init_part1_A_const_19 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[68]; var tmp3 *lang.Var; A_arbace_g2a_print_code__init_part0_A_Init(); tmp3 = A_arbace_g2a_print_code__init_part0_A_const_12; A_arbace_g2a_print_code__init_part1_A_const_20 = tmp3; A_arbace_g2a_print_code__init_part1_A_const_21 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[69]; A_arbace_g2a_print_code__init_part1_A_const_22 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[70]); A_arbace_g2a_print_code__init_part1_A_const_23 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[71]; A_arbace_g2a_print_code__init_part1_A_const_24 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[72]); A_arbace_g2a_print_code__init_part1_A_const_25 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[73]; A_arbace_g2a_print_code__init_part1_A_const_26 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[74]); A_arbace_g2a_print_code__init_part1_A_const_27 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[75]; A_arbace_g2a_print_code__init_part1_A_const_28 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[76]); A_arbace_g2a_print_code__init_part1_A_const_29 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[77]; A_arbace_g2a_print_code__init_part1_A_const_30 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[78]); A_arbace_g2a_print_code__init_part1_A_const_31 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[79]; A_arbace_g2a_print_code__init_part1_A_const_32 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[80]); A_arbace_g2a_print_code__init_part1_A_const_33 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[81]; A_arbace_g2a_print_code__init_part1_A_const_34 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[82]); A_arbace_g2a_print_code__init_part1_A_const_35 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[83]; A_arbace_g2a_print_code__init_part1_A_const_36 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[84]; A_arbace_g2a_print_code__init_part1_A_const_37 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[85]); A_arbace_g2a_print_code__init_part1_A_const_38 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[86]; A_arbace_g2a_print_code__init_part1_A_const_39 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[87]); A_arbace_g2a_print_code__init_part1_A_const_40 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[88]; A_arbace_g2a_print_code__init_part1_A_const_41 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[89]); A_arbace_g2a_print_code__init_part1_A_const_42 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[90]; A_arbace_g2a_print_code__init_part1_A_const_43 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[91]); A_arbace_g2a_print_code__init_part1_A_const_44 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[92]; A_arbace_g2a_print_code__init_part1_A_const_45 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[93]); A_arbace_g2a_print_code__init_part1_A_const_46 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[94]; A_arbace_g2a_print_code__init_part1_A_const_47 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[95]); A_arbace_g2a_print_code__init_part1_A_const_48 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[96]; A_arbace_g2a_print_code__init_part1_A_const_49 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[97]); A_arbace_g2a_print_code__init_part1_A_const_50 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[98]; A_arbace_g2a_print_code__init_part1_A_const_51 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[99]); A_arbace_g2a_print_code__init_part1_A_const_52 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[100]; A_arbace_g2a_print_code__init_part1_A_const_53 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[101]); A_arbace_g2a_print_code__init_part1_A_const_54 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[102]; A_arbace_g2a_print_code__init_part1_A_const_55 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[103]); A_arbace_g2a_print_code__init_part1_A_const_56 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[104]; A_arbace_g2a_print_code__init_part1_A_const_57 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[105]); A_arbace_g2a_print_code__init_part1_A_const_58 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[106]; var tmp4 *lang.Var; A_arbace_g2a_print_code__init_part0_A_Init(); tmp4 = A_arbace_g2a_print_code__init_part0_A_const_16; A_arbace_g2a_print_code__init_part1_A_const_59 = tmp4; A_arbace_g2a_print_code__init_part1_A_const_60 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[107]; A_arbace_g2a_print_code__init_part1_A_const_61 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[108]); A_arbace_g2a_print_code__init_part1_A_const_62 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[109]; A_arbace_g2a_print_code__init_part1_A_const_63 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[110]); A_arbace_g2a_print_code__init_part1_A_const_64 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[111]; A_arbace_g2a_print_code__init_part1_A_const_65 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[112]; A_arbace_g2a_print_code__init_part1_A_const_66 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[113]); A_arbace_g2a_print_code__init_part1_A_const_67 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[114]; A_arbace_g2a_print_code__init_part1_A_const_68 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[115]); A_arbace_g2a_print_code__init_part1_A_const_69 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[116]; A_arbace_g2a_print_code__init_part1_A_const_70 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[117]); A_arbace_g2a_print_code__init_part1_A_const_71 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[118]; A_arbace_g2a_print_code__init_part1_A_const_72 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[119]); A_arbace_g2a_print_code__init_part1_A_const_73 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[120]; A_arbace_g2a_print_code__init_part1_A_const_74 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[121]); A_arbace_g2a_print_code__init_part1_A_const_75 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[122]; A_arbace_g2a_print_code__init_part1_A_const_76 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[123]); A_arbace_g2a_print_code__init_part1_A_const_77 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[124]; A_arbace_g2a_print_code__init_part1_A_const_78 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[125]); A_arbace_g2a_print_code__init_part1_A_const_79 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[126]; A_arbace_g2a_print_code__init_part1_A_const_80 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[127]); A_arbace_g2a_print_code__init_part1_A_const_81 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[128]; A_arbace_g2a_print_code__init_part1_A_const_82 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[129]); A_arbace_g2a_print_code__init_part1_A_const_83 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[130]; var tmp5 *lang.Var; A_arbace_g2a_print_code__init_part0_A_Init(); tmp5 = A_arbace_g2a_print_code__init_part0_A_const_10; A_arbace_g2a_print_code__init_part1_A_const_84 = tmp5; A_arbace_g2a_print_code__init_part1_A_const_85 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[131]; var tmp6 *lang.Var; A_arbace_g2a_print_code__init_part0_A_Init(); tmp6 = A_arbace_g2a_print_code__init_part0_A_const_14; A_arbace_g2a_print_code__init_part1_A_const_86 = tmp6; A_arbace_g2a_print_code__init_part1_A_const_87 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[132]; var tmp7 *lang.Var; A_arbace_g2a_print_code__init_part0_A_Init(); tmp7 = A_arbace_g2a_print_code__init_part0_A_const_18; A_arbace_g2a_print_code__init_part1_A_const_88 = tmp7; A_arbace_g2a_print_code__init_part1_A_const_89 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[133]; A_arbace_g2a_print_code__init_part1_A_const_90 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[134]); A_arbace_g2a_print_code__init_part1_A_const_91 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[135]; A_arbace_g2a_print_code__init_part1_A_const_92 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[136]); A_arbace_g2a_print_code__init_part1_A_const_93 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[137]; A_arbace_g2a_print_code__init_part1_A_const_94 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[138]); A_arbace_g2a_print_code__init_part1_A_const_95 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[139]; A_arbace_g2a_print_code__init_part1_A_const_96 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[140]); A_arbace_g2a_print_code__init_part1_A_const_97 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[141]; A_arbace_g2a_print_code__init_part1_A_const_98 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[142]); A_arbace_g2a_print_code__init_part1_A_const_99 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[143]; A_arbace_g2a_print_code__init_part1_A_const_100 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[144]; A_arbace_g2a_print_code__init_part1_A_const_101 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[145]); A_arbace_g2a_print_code__init_part1_A_const_102 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[146]; A_arbace_g2a_print_code__init_part1_A_const_103 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[147]); A_arbace_g2a_print_code__init_part1_A_const_104 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[148]; A_arbace_g2a_print_code__init_part1_A_const_105 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[149]); A_arbace_g2a_print_code__init_part1_A_const_106 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[150]; A_arbace_g2a_print_code__init_part1_A_const_107 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[151]); A_arbace_g2a_print_code__init_part1_A_const_108 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[152]; A_arbace_g2a_print_code__init_part1_A_const_109 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[153]); A_arbace_g2a_print_code__init_part1_A_const_110 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[154]; A_arbace_g2a_print_code__init_part1_A_const_111 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[155]); A_arbace_g2a_print_code__init_part1_A_const_112 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[156]; A_arbace_g2a_print_code__init_part1_A_const_113 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[157]); A_arbace_g2a_print_code__init_part1_A_const_114 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[158]; A_arbace_g2a_print_code__init_part1_A_const_115 = lang.Var_Cast(A_arbace_g2a_print_code__init_part1_A_const_pool.A[159]); A_arbace_g2a_print_code__init_part1_A_const_116 = A_arbace_g2a_print_code__init_part1_A_const_pool.A[160] }

func A_arbace_g2a_print_code__init_part1_A_New() *A_arbace_g2a_print_code__init_part1_A { A_arbace_g2a_print_code__init_part1_A_Init(); t := &A_arbace_g2a_print_code__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_code__init_part1_A) Ctor() {}

func (t *A_arbace_g2a_print_code__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_code__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_code__init_part1_A_class }

func (t *A_arbace_g2a_print_code__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_code__init_part1_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_code__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_code__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_code__init_part1_A); return ok }

func A_arbace_g2a_print_code__init_part1_A_Cast(x any) *A_arbace_g2a_print_code__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_code__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_code__init_part1_A_class)) }; return v }
