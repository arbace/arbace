//line a2g_classes.ae:1
package aot_arbace_g2a_print_code

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_print_code_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_A_New()}; return nil }

var A_arbace_g2a_print_code_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_code_A_new}

var A_arbace_g2a_print_code_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_A"})

func init() { i := A_arbace_g2a_print_code_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_A_InstanceOf; i.Init = A_arbace_g2a_print_code_A_Init; i.Table = A_arbace_g2a_print_code_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_A_class, reflect.TypeFor[A_arbace_g2a_print_code_A]()) }

func A_arbace_g2a_print_code_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_args_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_args_A_New()}; return nil }

func A_arbace_g2a_print_code_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_args_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_args_A_invoke, New: A_arbace_g2a_print_code_args_A_new, Get: A_arbace_g2a_print_code_args_A_get}

var A_arbace_g2a_print_code_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "args", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_args_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_args_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_args_A_InstanceOf; i.Init = A_arbace_g2a_print_code_args_A_Init; i.Table = A_arbace_g2a_print_code_args_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_args_A_class, reflect.TypeFor[A_arbace_g2a_print_code_args_A]()) }

func A_arbace_g2a_print_code_assign_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_assign_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_assign_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_assign_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_assign_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_assign_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_assign_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_assign_stmt_A_invoke, New: A_arbace_g2a_print_code_assign_stmt_A_new, Get: A_arbace_g2a_print_code_assign_stmt_A_get}

var A_arbace_g2a_print_code_assign_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$assign_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "assign_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_assign_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_assign_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_assign_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_assign_stmt_A_Init; i.Table = A_arbace_g2a_print_code_assign_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_assign_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_assign_stmt_A]()) }

func A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_invoke, New: A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_new, Get: A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_get}

var A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$begins_with_star_or_paren_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "begins_with_star_or_paren_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_begins_with_star_or_paren_QMARK__A]()) }

func A_arbace_g2a_print_code_bin_op_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_bin_op_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_bin_op_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_bin_op_A_New()}; return nil }

func A_arbace_g2a_print_code_bin_op_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_bin_op_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_bin_op_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_bin_op_A_invoke, New: A_arbace_g2a_print_code_bin_op_A_new, Get: A_arbace_g2a_print_code_bin_op_A_get}

var A_arbace_g2a_print_code_bin_op_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$bin_op", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "bin_op", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_bin_op_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_bin_op_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_bin_op_A_InstanceOf; i.Init = A_arbace_g2a_print_code_bin_op_A_Init; i.Table = A_arbace_g2a_print_code_bin_op_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_bin_op_A_class, reflect.TypeFor[A_arbace_g2a_print_code_bin_op_A]()) }

func A_arbace_g2a_print_code_bin_prec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_bin_prec_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_bin_prec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_bin_prec_A_New()}; return nil }

func A_arbace_g2a_print_code_bin_prec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_bin_prec_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_bin_prec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_bin_prec_A_invoke, New: A_arbace_g2a_print_code_bin_prec_A_new, Get: A_arbace_g2a_print_code_bin_prec_A_get}

var A_arbace_g2a_print_code_bin_prec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$bin_prec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "bin_prec", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_bin_prec_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_bin_prec_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_bin_prec_A_InstanceOf; i.Init = A_arbace_g2a_print_code_bin_prec_A_Init; i.Table = A_arbace_g2a_print_code_bin_prec_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_bin_prec_A_class, reflect.TypeFor[A_arbace_g2a_print_code_bin_prec_A]()) }

func A_arbace_g2a_print_code_binary_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binary_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_binary_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binary_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_binary_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binary_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binary_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binary_QMARK__A_invoke, New: A_arbace_g2a_print_code_binary_QMARK__A_new, Get: A_arbace_g2a_print_code_binary_QMARK__A_get}

var A_arbace_g2a_print_code_binary_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binary_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "binary_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binary_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binary_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binary_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_binary_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_binary_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binary_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_binary_QMARK__A]()) }

func A_arbace_g2a_print_code_binary_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binary_expr_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_binary_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binary_expr_A_New()}; return nil }

func A_arbace_g2a_print_code_binary_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binary_expr_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binary_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binary_expr_A_invoke, New: A_arbace_g2a_print_code_binary_expr_A_new, Get: A_arbace_g2a_print_code_binary_expr_A_get}

var A_arbace_g2a_print_code_binary_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binary_expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "binary_expr", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binary_expr_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binary_expr_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binary_expr_A_InstanceOf; i.Init = A_arbace_g2a_print_code_binary_expr_A_Init; i.Table = A_arbace_g2a_print_code_binary_expr_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binary_expr_A_class, reflect.TypeFor[A_arbace_g2a_print_code_binary_expr_A]()) }

func A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binary_expr_fn__1022000253_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_invoke, New: A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_new, Get: A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_get}

var A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binary_expr$fn__1022000253", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_binary_expr_A_class, Simple: "fn__1022000253", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binary_expr_fn__1022000253_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_InstanceOf; i.Init = A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_Init; i.Table = A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binary_expr_fn__1022000253_A_class, reflect.TypeFor[A_arbace_g2a_print_code_binary_expr_fn__1022000253_A]()) }

func A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binary_expr_fn__1022000255_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_invoke, New: A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_new, Get: A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_get}

var A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binary_expr$fn__1022000255", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_binary_expr_A_class, Simple: "fn__1022000255", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binary_expr_fn__1022000255_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_InstanceOf; i.Init = A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_Init; i.Table = A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binary_expr_fn__1022000255_A_class, reflect.TypeFor[A_arbace_g2a_print_code_binary_expr_fn__1022000255_A]()) }

func A_arbace_g2a_print_code_bind_target_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_bind_target_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_bind_target_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_bind_target_A_New()}; return nil }

func A_arbace_g2a_print_code_bind_target_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_bind_target_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_bind_target_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_bind_target_A_invoke, New: A_arbace_g2a_print_code_bind_target_A_new, Get: A_arbace_g2a_print_code_bind_target_A_get}

var A_arbace_g2a_print_code_bind_target_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$bind_target", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "bind_target", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_bind_target_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_bind_target_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_bind_target_A_InstanceOf; i.Init = A_arbace_g2a_print_code_bind_target_A_Init; i.Table = A_arbace_g2a_print_code_bind_target_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_bind_target_A_class, reflect.TypeFor[A_arbace_g2a_print_code_bind_target_A]()) }

func A_arbace_g2a_print_code_binding_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binding_stmt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_binding_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binding_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_binding_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binding_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binding_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binding_stmt_A_invoke, New: A_arbace_g2a_print_code_binding_stmt_A_new, Get: A_arbace_g2a_print_code_binding_stmt_A_get}

var A_arbace_g2a_print_code_binding_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binding_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "binding_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binding_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binding_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binding_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_binding_stmt_A_Init; i.Table = A_arbace_g2a_print_code_binding_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binding_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_binding_stmt_A]()) }

func A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_New()}; return nil }

func A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_invoke, New: A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_new, Get: A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_get}

var A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binding_stmt$fn__1022000369", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_binding_stmt_A_class, Simple: "fn__1022000369", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_InstanceOf; i.Init = A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_Init; i.Table = A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A_class, reflect.TypeFor[A_arbace_g2a_print_code_binding_stmt_fn__1022000369_A]()) }

func A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_New_J(args[0].(int64))}; return nil }

func A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_invoke, New: A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_new, Get: A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_get}

var A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binding_stmt$fn__1022000373", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_binding_stmt_A_class, Simple: "fn__1022000373", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_InstanceOf; i.Init = A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_Init; i.Table = A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A_class, reflect.TypeFor[A_arbace_g2a_print_code_binding_stmt_fn__1022000373_A]()) }

func A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_binding_stmt_names__1022000371_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_invoke, New: A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_new, Get: A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_get}

var A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$binding_stmt$names__1022000371", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_binding_stmt_A_class, Simple: "names__1022000371", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_binding_stmt_names__1022000371_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_InstanceOf; i.Init = A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_Init; i.Table = A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_binding_stmt_names__1022000371_A_class, reflect.TypeFor[A_arbace_g2a_print_code_binding_stmt_names__1022000371_A]()) }

func A_arbace_g2a_print_code_block_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_block_body_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_block_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_block_body_A_New()}; return nil }

func A_arbace_g2a_print_code_block_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_block_body_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_block_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_block_body_A_invoke, New: A_arbace_g2a_print_code_block_body_A_new, Get: A_arbace_g2a_print_code_block_body_A_get}

var A_arbace_g2a_print_code_block_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$block_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "block_body", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_block_body_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_block_body_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_block_body_A_InstanceOf; i.Init = A_arbace_g2a_print_code_block_body_A_Init; i.Table = A_arbace_g2a_print_code_block_body_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_block_body_A_class, reflect.TypeFor[A_arbace_g2a_print_code_block_body_A]()) }

func A_arbace_g2a_print_code_block_body_fn__1022000557_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_block_body_fn__1022000557_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_block_body_fn__1022000557_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_block_body_fn__1022000557_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_block_body_fn__1022000557_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_block_body_fn__1022000557_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_block_body_fn__1022000557_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_block_body_fn__1022000557_A_invoke, New: A_arbace_g2a_print_code_block_body_fn__1022000557_A_new, Get: A_arbace_g2a_print_code_block_body_fn__1022000557_A_get}

var A_arbace_g2a_print_code_block_body_fn__1022000557_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$block_body$fn__1022000557", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_block_body_A_class, Simple: "fn__1022000557", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_block_body_fn__1022000557_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_block_body_fn__1022000557_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_block_body_fn__1022000557_A_InstanceOf; i.Init = A_arbace_g2a_print_code_block_body_fn__1022000557_A_Init; i.Table = A_arbace_g2a_print_code_block_body_fn__1022000557_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_block_body_fn__1022000557_A_class, reflect.TypeFor[A_arbace_g2a_print_code_block_body_fn__1022000557_A]()) }

func A_arbace_g2a_print_code_block_body_fn__1022000559_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_block_body_fn__1022000559_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_block_body_fn__1022000559_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_block_body_fn__1022000559_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_block_body_fn__1022000559_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_block_body_fn__1022000559_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_block_body_fn__1022000559_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_block_body_fn__1022000559_A_invoke, New: A_arbace_g2a_print_code_block_body_fn__1022000559_A_new, Get: A_arbace_g2a_print_code_block_body_fn__1022000559_A_get}

var A_arbace_g2a_print_code_block_body_fn__1022000559_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$block_body$fn__1022000559", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_block_body_A_class, Simple: "fn__1022000559", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_block_body_fn__1022000559_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_block_body_fn__1022000559_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_block_body_fn__1022000559_A_InstanceOf; i.Init = A_arbace_g2a_print_code_block_body_fn__1022000559_A_Init; i.Table = A_arbace_g2a_print_code_block_body_fn__1022000559_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_block_body_fn__1022000559_A_class, reflect.TypeFor[A_arbace_g2a_print_code_block_body_fn__1022000559_A]()) }

func A_arbace_g2a_print_code_body_offset_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_body_offset_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_body_offset_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_body_offset_A_New()}; return nil }

func A_arbace_g2a_print_code_body_offset_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_body_offset_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_body_offset_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_body_offset_A_invoke, New: A_arbace_g2a_print_code_body_offset_A_new, Get: A_arbace_g2a_print_code_body_offset_A_get}

var A_arbace_g2a_print_code_body_offset_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$body_offset", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "body_offset", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_body_offset_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_body_offset_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_body_offset_A_InstanceOf; i.Init = A_arbace_g2a_print_code_body_offset_A_Init; i.Table = A_arbace_g2a_print_code_body_offset_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_body_offset_A_class, reflect.TypeFor[A_arbace_g2a_print_code_body_offset_A]()) }

func A_arbace_g2a_print_code_branch_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_branch_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_branch_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_branch_forms_A_New()}; return nil }

func A_arbace_g2a_print_code_branch_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_branch_forms_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_branch_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_branch_forms_A_invoke, New: A_arbace_g2a_print_code_branch_forms_A_new, Get: A_arbace_g2a_print_code_branch_forms_A_get}

var A_arbace_g2a_print_code_branch_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$branch_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "branch_forms", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_branch_forms_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_branch_forms_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_branch_forms_A_InstanceOf; i.Init = A_arbace_g2a_print_code_branch_forms_A_Init; i.Table = A_arbace_g2a_print_code_branch_forms_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_branch_forms_A_class, reflect.TypeFor[A_arbace_g2a_print_code_branch_forms_A]()) }

func A_arbace_g2a_print_code_branch_opts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_branch_opts_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_branch_opts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_branch_opts_A_New()}; return nil }

func A_arbace_g2a_print_code_branch_opts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_branch_opts_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_branch_opts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_branch_opts_A_invoke, New: A_arbace_g2a_print_code_branch_opts_A_new, Get: A_arbace_g2a_print_code_branch_opts_A_get}

var A_arbace_g2a_print_code_branch_opts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$branch_opts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "branch_opts", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_branch_opts_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_branch_opts_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_branch_opts_A_InstanceOf; i.Init = A_arbace_g2a_print_code_branch_opts_A_Init; i.Table = A_arbace_g2a_print_code_branch_opts_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_branch_opts_A_class, reflect.TypeFor[A_arbace_g2a_print_code_branch_opts_A]()) }

func A_arbace_g2a_print_code_break_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_break_line_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_break_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_break_line_A_New()}; return nil }

func A_arbace_g2a_print_code_break_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_break_line_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_break_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_break_line_A_invoke, New: A_arbace_g2a_print_code_break_line_A_new, Get: A_arbace_g2a_print_code_break_line_A_get}

var A_arbace_g2a_print_code_break_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$break_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "break_line", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_break_line_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_break_line_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_break_line_A_InstanceOf; i.Init = A_arbace_g2a_print_code_break_line_A_Init; i.Table = A_arbace_g2a_print_code_break_line_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_break_line_A_class, reflect.TypeFor[A_arbace_g2a_print_code_break_line_A]()) }

func A_arbace_g2a_print_code_break_line_fn__1022000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_break_line_fn__1022000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_break_line_fn__1022000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_break_line_fn__1022000035_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_break_line_fn__1022000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_break_line_fn__1022000035_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_break_line_fn__1022000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_break_line_fn__1022000035_A_invoke, New: A_arbace_g2a_print_code_break_line_fn__1022000035_A_new, Get: A_arbace_g2a_print_code_break_line_fn__1022000035_A_get}

var A_arbace_g2a_print_code_break_line_fn__1022000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$break_line$fn__1022000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_break_line_A_class, Simple: "fn__1022000035", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_break_line_fn__1022000035_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_break_line_fn__1022000035_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_break_line_fn__1022000035_A_InstanceOf; i.Init = A_arbace_g2a_print_code_break_line_fn__1022000035_A_Init; i.Table = A_arbace_g2a_print_code_break_line_fn__1022000035_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_break_line_fn__1022000035_A_class, reflect.TypeFor[A_arbace_g2a_print_code_break_line_fn__1022000035_A]()) }

func A_arbace_g2a_print_code_breaks_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_breaks_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_breaks_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_breaks_of_A_New()}; return nil }

func A_arbace_g2a_print_code_breaks_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_breaks_of_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_breaks_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_breaks_of_A_invoke, New: A_arbace_g2a_print_code_breaks_of_A_new, Get: A_arbace_g2a_print_code_breaks_of_A_get}

var A_arbace_g2a_print_code_breaks_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$breaks_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "breaks_of", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_breaks_of_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_breaks_of_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_breaks_of_A_InstanceOf; i.Init = A_arbace_g2a_print_code_breaks_of_A_Init; i.Table = A_arbace_g2a_print_code_breaks_of_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_breaks_of_A_class, reflect.TypeFor[A_arbace_g2a_print_code_breaks_of_A]()) }

func A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_breaks_of_fn__1022000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_New()}; return nil }

func A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_invoke, New: A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_new, Get: A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_get}

var A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$breaks_of$fn__1022000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_breaks_of_A_class, Simple: "fn__1022000031", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_breaks_of_fn__1022000031_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_InstanceOf; i.Init = A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_Init; i.Table = A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_breaks_of_fn__1022000031_A_class, reflect.TypeFor[A_arbace_g2a_print_code_breaks_of_fn__1022000031_A]()) }

func A_arbace_g2a_print_code_call_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_call_args_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_call_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_call_args_A_New()}; return nil }

func A_arbace_g2a_print_code_call_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_call_args_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_call_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_call_args_A_invoke, New: A_arbace_g2a_print_code_call_args_A_new, Get: A_arbace_g2a_print_code_call_args_A_get}

var A_arbace_g2a_print_code_call_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$call_args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "call_args", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_call_args_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_call_args_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_call_args_A_InstanceOf; i.Init = A_arbace_g2a_print_code_call_args_A_Init; i.Table = A_arbace_g2a_print_code_call_args_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_call_args_A_class, reflect.TypeFor[A_arbace_g2a_print_code_call_args_A]()) }

func A_arbace_g2a_print_code_call_args_fn__1022000258_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_call_args_fn__1022000258_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_call_args_fn__1022000258_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_call_args_fn__1022000258_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_call_args_fn__1022000258_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_call_args_fn__1022000258_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_call_args_fn__1022000258_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_call_args_fn__1022000258_A_invoke, New: A_arbace_g2a_print_code_call_args_fn__1022000258_A_new, Get: A_arbace_g2a_print_code_call_args_fn__1022000258_A_get}

var A_arbace_g2a_print_code_call_args_fn__1022000258_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$call_args$fn__1022000258", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_call_args_A_class, Simple: "fn__1022000258", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_call_args_fn__1022000258_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_call_args_fn__1022000258_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_call_args_fn__1022000258_A_InstanceOf; i.Init = A_arbace_g2a_print_code_call_args_fn__1022000258_A_Init; i.Table = A_arbace_g2a_print_code_call_args_fn__1022000258_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_call_args_fn__1022000258_A_class, reflect.TypeFor[A_arbace_g2a_print_code_call_args_fn__1022000258_A]()) }

func A_arbace_g2a_print_code_callee_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_callee_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_callee_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_callee_A_New()}; return nil }

func A_arbace_g2a_print_code_callee_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_callee_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_callee_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_callee_A_invoke, New: A_arbace_g2a_print_code_callee_A_new, Get: A_arbace_g2a_print_code_callee_A_get}

var A_arbace_g2a_print_code_callee_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$callee", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "callee", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_callee_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_callee_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_callee_A_InstanceOf; i.Init = A_arbace_g2a_print_code_callee_A_Init; i.Table = A_arbace_g2a_print_code_callee_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_callee_A_class, reflect.TypeFor[A_arbace_g2a_print_code_callee_A]()) }

func A_arbace_g2a_print_code_case_exprs_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_case_exprs_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_case_exprs_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_case_exprs_A_New()}; return nil }

func A_arbace_g2a_print_code_case_exprs_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_case_exprs_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_case_exprs_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_case_exprs_A_invoke, New: A_arbace_g2a_print_code_case_exprs_A_new, Get: A_arbace_g2a_print_code_case_exprs_A_get}

var A_arbace_g2a_print_code_case_exprs_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$case_exprs", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "case_exprs", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_case_exprs_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_case_exprs_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_case_exprs_A_InstanceOf; i.Init = A_arbace_g2a_print_code_case_exprs_A_Init; i.Table = A_arbace_g2a_print_code_case_exprs_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_case_exprs_A_class, reflect.TypeFor[A_arbace_g2a_print_code_case_exprs_A]()) }

func A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_case_exprs_fn__1022000446_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_New()}; return nil }

func A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_invoke, New: A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_new, Get: A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_get}

var A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$case_exprs$fn__1022000446", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_case_exprs_A_class, Simple: "fn__1022000446", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_case_exprs_fn__1022000446_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_InstanceOf; i.Init = A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_Init; i.Table = A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_case_exprs_fn__1022000446_A_class, reflect.TypeFor[A_arbace_g2a_print_code_case_exprs_fn__1022000446_A]()) }

func A_arbace_g2a_print_code_case_types_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_case_types_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_case_types_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_case_types_A_New()}; return nil }

func A_arbace_g2a_print_code_case_types_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_case_types_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_case_types_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_case_types_A_invoke, New: A_arbace_g2a_print_code_case_types_A_new, Get: A_arbace_g2a_print_code_case_types_A_get}

var A_arbace_g2a_print_code_case_types_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$case_types", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "case_types", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_case_types_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_case_types_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_case_types_A_InstanceOf; i.Init = A_arbace_g2a_print_code_case_types_A_Init; i.Table = A_arbace_g2a_print_code_case_types_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_case_types_A_class, reflect.TypeFor[A_arbace_g2a_print_code_case_types_A]()) }

func A_arbace_g2a_print_code_case_types_fn__1022000450_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_case_types_fn__1022000450_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_case_types_fn__1022000450_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_case_types_fn__1022000450_A_New()}; return nil }

func A_arbace_g2a_print_code_case_types_fn__1022000450_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_case_types_fn__1022000450_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_case_types_fn__1022000450_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_case_types_fn__1022000450_A_invoke, New: A_arbace_g2a_print_code_case_types_fn__1022000450_A_new, Get: A_arbace_g2a_print_code_case_types_fn__1022000450_A_get}

var A_arbace_g2a_print_code_case_types_fn__1022000450_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$case_types$fn__1022000450", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_case_types_A_class, Simple: "fn__1022000450", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_case_types_fn__1022000450_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_case_types_fn__1022000450_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_case_types_fn__1022000450_A_InstanceOf; i.Init = A_arbace_g2a_print_code_case_types_fn__1022000450_A_Init; i.Table = A_arbace_g2a_print_code_case_types_fn__1022000450_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_case_types_fn__1022000450_A_class, reflect.TypeFor[A_arbace_g2a_print_code_case_types_fn__1022000450_A]()) }

func A_arbace_g2a_print_code_chan_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_chan_type_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_chan_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_chan_type_A_New()}; return nil }

func A_arbace_g2a_print_code_chan_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_chan_type_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_chan_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_chan_type_A_invoke, New: A_arbace_g2a_print_code_chan_type_A_new, Get: A_arbace_g2a_print_code_chan_type_A_get}

var A_arbace_g2a_print_code_chan_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$chan_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "chan_type", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_chan_type_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_chan_type_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_chan_type_A_InstanceOf; i.Init = A_arbace_g2a_print_code_chan_type_A_Init; i.Table = A_arbace_g2a_print_code_chan_type_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_chan_type_A_class, reflect.TypeFor[A_arbace_g2a_print_code_chan_type_A]()) }

func A_arbace_g2a_print_code_child_target_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_child_target_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_g2a_print_code_child_target_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_child_target_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_child_target_A_New()}; return nil }

func A_arbace_g2a_print_code_child_target_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_child_target_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_child_target_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_child_target_A_invoke, New: A_arbace_g2a_print_code_child_target_A_new, Get: A_arbace_g2a_print_code_child_target_A_get}

var A_arbace_g2a_print_code_child_target_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$child_target", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "child_target", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_child_target_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_child_target_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_child_target_A_InstanceOf; i.Init = A_arbace_g2a_print_code_child_target_A_Init; i.Table = A_arbace_g2a_print_code_child_target_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_child_target_A_class, reflect.TypeFor[A_arbace_g2a_print_code_child_target_A]()) }

func A_arbace_g2a_print_code_clause_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_clause_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_clause_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_clause_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_clause_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_clause_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_clause_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_clause_QMARK__A_invoke, New: A_arbace_g2a_print_code_clause_QMARK__A_new, Get: A_arbace_g2a_print_code_clause_QMARK__A_get}

var A_arbace_g2a_print_code_clause_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$clause_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "clause_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_clause_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_clause_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_clause_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_clause_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_clause_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_clause_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_clause_QMARK__A]()) }

func A_arbace_g2a_print_code_clause_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_clause_list_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_clause_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_clause_list_A_New()}; return nil }

func A_arbace_g2a_print_code_clause_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_clause_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_clause_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_clause_list_A_invoke, New: A_arbace_g2a_print_code_clause_list_A_new, Get: A_arbace_g2a_print_code_clause_list_A_get}

var A_arbace_g2a_print_code_clause_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$clause_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "clause_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_clause_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_clause_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_clause_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_clause_list_A_Init; i.Table = A_arbace_g2a_print_code_clause_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_clause_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_clause_list_A]()) }

func A_arbace_g2a_print_code_clause_list_fn__1022000439_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_clause_list_fn__1022000439_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_clause_list_fn__1022000439_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_clause_list_fn__1022000439_A_New_J_O_O_O(args[0].(int64), args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_clause_list_fn__1022000439_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_clause_list_fn__1022000439_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_clause_list_fn__1022000439_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (JLjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_clause_list_fn__1022000439_A_invoke, New: A_arbace_g2a_print_code_clause_list_fn__1022000439_A_new, Get: A_arbace_g2a_print_code_clause_list_fn__1022000439_A_get}

var A_arbace_g2a_print_code_clause_list_fn__1022000439_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$clause_list$fn__1022000439", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_clause_list_A_class, Simple: "fn__1022000439", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_clause_list_fn__1022000439_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_clause_list_fn__1022000439_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_clause_list_fn__1022000439_A_InstanceOf; i.Init = A_arbace_g2a_print_code_clause_list_fn__1022000439_A_Init; i.Table = A_arbace_g2a_print_code_clause_list_fn__1022000439_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_clause_list_fn__1022000439_A_class, reflect.TypeFor[A_arbace_g2a_print_code_clause_list_fn__1022000439_A]()) }

func A_arbace_g2a_print_code_comm_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_comm_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_comm_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_comm_A_New()}; return nil }

func A_arbace_g2a_print_code_comm_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_comm_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_comm_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_comm_A_invoke, New: A_arbace_g2a_print_code_comm_A_new, Get: A_arbace_g2a_print_code_comm_A_get}

var A_arbace_g2a_print_code_comm_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$comm", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "comm", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_comm_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_comm_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_comm_A_InstanceOf; i.Init = A_arbace_g2a_print_code_comm_A_Init; i.Table = A_arbace_g2a_print_code_comm_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_comm_A_class, reflect.TypeFor[A_arbace_g2a_print_code_comm_A]()) }

func A_arbace_g2a_print_code_comma_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_comma_list_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_comma_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_comma_list_A_New()}; return nil }

func A_arbace_g2a_print_code_comma_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_comma_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_comma_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_comma_list_A_invoke, New: A_arbace_g2a_print_code_comma_list_A_new, Get: A_arbace_g2a_print_code_comma_list_A_get}

var A_arbace_g2a_print_code_comma_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$comma_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "comma_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_comma_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_comma_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_comma_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_comma_list_A_Init; i.Table = A_arbace_g2a_print_code_comma_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_comma_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_comma_list_A]()) }

func A_arbace_g2a_print_code_comma_list_fn__1022000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_comma_list_fn__1022000043_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_comma_list_fn__1022000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_comma_list_fn__1022000043_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_comma_list_fn__1022000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_comma_list_fn__1022000043_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_comma_list_fn__1022000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_comma_list_fn__1022000043_A_invoke, New: A_arbace_g2a_print_code_comma_list_fn__1022000043_A_new, Get: A_arbace_g2a_print_code_comma_list_fn__1022000043_A_get}

var A_arbace_g2a_print_code_comma_list_fn__1022000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$comma_list$fn__1022000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_comma_list_A_class, Simple: "fn__1022000043", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_comma_list_fn__1022000043_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_comma_list_fn__1022000043_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_comma_list_fn__1022000043_A_InstanceOf; i.Init = A_arbace_g2a_print_code_comma_list_fn__1022000043_A_Init; i.Table = A_arbace_g2a_print_code_comma_list_fn__1022000043_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_comma_list_fn__1022000043_A_class, reflect.TypeFor[A_arbace_g2a_print_code_comma_list_fn__1022000043_A]()) }

func A_arbace_g2a_print_code_comma_list_fn__1022000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_comma_list_fn__1022000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_comma_list_fn__1022000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_comma_list_fn__1022000045_A_New_J_O_O(args[0].(int64), args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_comma_list_fn__1022000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_comma_list_fn__1022000045_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_comma_list_fn__1022000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (JLjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_comma_list_fn__1022000045_A_invoke, New: A_arbace_g2a_print_code_comma_list_fn__1022000045_A_new, Get: A_arbace_g2a_print_code_comma_list_fn__1022000045_A_get}

var A_arbace_g2a_print_code_comma_list_fn__1022000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$comma_list$fn__1022000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_comma_list_A_class, Simple: "fn__1022000045", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_comma_list_fn__1022000045_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_comma_list_fn__1022000045_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_comma_list_fn__1022000045_A_InstanceOf; i.Init = A_arbace_g2a_print_code_comma_list_fn__1022000045_A_Init; i.Table = A_arbace_g2a_print_code_comma_list_fn__1022000045_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_comma_list_fn__1022000045_A_class, reflect.TypeFor[A_arbace_g2a_print_code_comma_list_fn__1022000045_A]()) }

func A_arbace_g2a_print_code_composite_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_composite_lit_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_composite_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_composite_lit_A_New()}; return nil }

func A_arbace_g2a_print_code_composite_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_composite_lit_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_composite_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_composite_lit_A_invoke, New: A_arbace_g2a_print_code_composite_lit_A_new, Get: A_arbace_g2a_print_code_composite_lit_A_get}

var A_arbace_g2a_print_code_composite_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$composite_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "composite_lit", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_composite_lit_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_composite_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_composite_lit_A_InstanceOf; i.Init = A_arbace_g2a_print_code_composite_lit_A_Init; i.Table = A_arbace_g2a_print_code_composite_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_composite_lit_A_class, reflect.TypeFor[A_arbace_g2a_print_code_composite_lit_A]()) }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_composite_lit_fn__1022000265_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_invoke, New: A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_new, Get: A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_get}

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$composite_lit$fn__1022000265", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_composite_lit_A_class, Simple: "fn__1022000265", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_composite_lit_fn__1022000265_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_InstanceOf; i.Init = A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_Init; i.Table = A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_class, reflect.TypeFor[A_arbace_g2a_print_code_composite_lit_fn__1022000265_A]()) }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_invoke, New: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_new, Get: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_get}

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000266", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_class, Simple: "fn__1022000266", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_InstanceOf; i.Init = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_Init; i.Table = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A_class, reflect.TypeFor[A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000266_A]()) }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_invoke, New: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_new, Get: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_get}

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000268", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_class, Simple: "fn__1022000268", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_InstanceOf; i.Init = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_Init; i.Table = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A_class, reflect.TypeFor[A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000268_A]()) }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_invoke, New: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_new, Get: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_get}

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000277", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_class, Simple: "fn__1022000277", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_InstanceOf; i.Init = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_Init; i.Table = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A_class, reflect.TypeFor[A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000277_A]()) }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_invoke, New: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_new, Get: A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_get}

var A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$composite_lit$fn__1022000265$fn__1022000283", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_composite_lit_fn__1022000265_A_class, Simple: "fn__1022000283", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_InstanceOf; i.Init = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_Init; i.Table = A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A_class, reflect.TypeFor[A_arbace_g2a_print_code_composite_lit_fn__1022000265_fn__1022000283_A]()) }

func A_arbace_g2a_print_code_const_bind_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_bind_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_const_bind_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_bind_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_const_bind_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_bind_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_bind_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_bind_QMARK__A_invoke, New: A_arbace_g2a_print_code_const_bind_QMARK__A_new, Get: A_arbace_g2a_print_code_const_bind_QMARK__A_get}

var A_arbace_g2a_print_code_const_bind_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_bind_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "const_bind_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_bind_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_bind_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_bind_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_bind_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_const_bind_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_bind_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_bind_QMARK__A]()) }

func A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_New()}; return nil }

func A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_invoke, New: A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_new, Get: A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_get}

var A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_bind_QMARK_$fn__1022000522", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_const_bind_QMARK__A_class, Simple: "fn__1022000522", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_Init; i.Table = A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_bind_QMARK__fn__1022000522_A]()) }

func A_arbace_g2a_print_code_const_group_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_group_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_const_group_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_group_A_New()}; return nil }

func A_arbace_g2a_print_code_const_group_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_group_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_group_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_group_A_invoke, New: A_arbace_g2a_print_code_const_group_A_new, Get: A_arbace_g2a_print_code_const_group_A_get}

var A_arbace_g2a_print_code_const_group_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_group", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "const_group", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_group_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_group_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_group_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_group_A_Init; i.Table = A_arbace_g2a_print_code_const_group_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_group_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_group_A]()) }

func A_arbace_g2a_print_code_const_group_fn__1022000538_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_group_fn__1022000538_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_const_group_fn__1022000538_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_group_fn__1022000538_A_New()}; return nil }

func A_arbace_g2a_print_code_const_group_fn__1022000538_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_group_fn__1022000538_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_group_fn__1022000538_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_group_fn__1022000538_A_invoke, New: A_arbace_g2a_print_code_const_group_fn__1022000538_A_new, Get: A_arbace_g2a_print_code_const_group_fn__1022000538_A_get}

var A_arbace_g2a_print_code_const_group_fn__1022000538_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_group$fn__1022000538", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_const_group_A_class, Simple: "fn__1022000538", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_group_fn__1022000538_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_group_fn__1022000538_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_group_fn__1022000538_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_group_fn__1022000538_A_Init; i.Table = A_arbace_g2a_print_code_const_group_fn__1022000538_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_group_fn__1022000538_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_group_fn__1022000538_A]()) }

func A_arbace_g2a_print_code_const_group_fn__1022000543_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_group_fn__1022000543_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_const_group_fn__1022000543_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_group_fn__1022000543_A_New_O_J_O_O_O(args[0], args[1].(int64), args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_const_group_fn__1022000543_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_group_fn__1022000543_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_group_fn__1022000543_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;JLjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_group_fn__1022000543_A_invoke, New: A_arbace_g2a_print_code_const_group_fn__1022000543_A_new, Get: A_arbace_g2a_print_code_const_group_fn__1022000543_A_get}

var A_arbace_g2a_print_code_const_group_fn__1022000543_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_group$fn__1022000543", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_const_group_A_class, Simple: "fn__1022000543", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_group_fn__1022000543_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_group_fn__1022000543_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_group_fn__1022000543_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_group_fn__1022000543_A_Init; i.Table = A_arbace_g2a_print_code_const_group_fn__1022000543_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_group_fn__1022000543_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_group_fn__1022000543_A]()) }

func A_arbace_g2a_print_code_const_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_spec_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_const_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_spec_A_New()}; return nil }

func A_arbace_g2a_print_code_const_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_spec_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_spec_A_invoke, New: A_arbace_g2a_print_code_const_spec_A_new, Get: A_arbace_g2a_print_code_const_spec_A_get}

var A_arbace_g2a_print_code_const_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "const_spec", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_spec_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_spec_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_spec_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_spec_A_Init; i.Table = A_arbace_g2a_print_code_const_spec_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_spec_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_spec_A]()) }

func A_arbace_g2a_print_code_const_spec_fn__1022000534_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_spec_fn__1022000534_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_const_spec_fn__1022000534_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_spec_fn__1022000534_A_New()}; return nil }

func A_arbace_g2a_print_code_const_spec_fn__1022000534_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_spec_fn__1022000534_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_spec_fn__1022000534_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_spec_fn__1022000534_A_invoke, New: A_arbace_g2a_print_code_const_spec_fn__1022000534_A_new, Get: A_arbace_g2a_print_code_const_spec_fn__1022000534_A_get}

var A_arbace_g2a_print_code_const_spec_fn__1022000534_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_spec$fn__1022000534", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_const_spec_A_class, Simple: "fn__1022000534", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_spec_fn__1022000534_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_spec_fn__1022000534_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_spec_fn__1022000534_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_spec_fn__1022000534_A_Init; i.Table = A_arbace_g2a_print_code_const_spec_fn__1022000534_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_spec_fn__1022000534_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_spec_fn__1022000534_A]()) }

func A_arbace_g2a_print_code_const_var_decl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_var_decl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_const_var_decl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_var_decl_A_New()}; return nil }

func A_arbace_g2a_print_code_const_var_decl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_var_decl_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_var_decl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_var_decl_A_invoke, New: A_arbace_g2a_print_code_const_var_decl_A_new, Get: A_arbace_g2a_print_code_const_var_decl_A_get}

var A_arbace_g2a_print_code_const_var_decl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_var_decl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "const_var_decl", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_var_decl_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_var_decl_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_var_decl_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_var_decl_A_Init; i.Table = A_arbace_g2a_print_code_const_var_decl_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_var_decl_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_var_decl_A]()) }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_New()}; return nil }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_invoke, New: A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_new, Get: A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_get}

var A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_var_decl$fn__1022000636", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_const_var_decl_A_class, Simple: "fn__1022000636", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_Init; i.Table = A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_var_decl_fn__1022000636_A]()) }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_New_O_Z_O(args[0], args[1].(bool), args[2])}; return nil }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ZLjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_invoke, New: A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_new, Get: A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_get}

var A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_var_decl$fn__1022000638", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_const_var_decl_A_class, Simple: "fn__1022000638", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_Init; i.Table = A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_var_decl_fn__1022000638_A]()) }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_New()}; return nil }

func A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_invoke, New: A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_new, Get: A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_get}

var A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$const_var_decl$fn__1022000643", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_const_var_decl_A_class, Simple: "fn__1022000643", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_InstanceOf; i.Init = A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_Init; i.Table = A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A_class, reflect.TypeFor[A_arbace_g2a_print_code_const_var_decl_fn__1022000643_A]()) }

func A_arbace_g2a_print_code_control_clause_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_control_clause_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_control_clause_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_control_clause_A_New()}; return nil }

func A_arbace_g2a_print_code_control_clause_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_control_clause_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_control_clause_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_control_clause_A_invoke, New: A_arbace_g2a_print_code_control_clause_A_new, Get: A_arbace_g2a_print_code_control_clause_A_get}

var A_arbace_g2a_print_code_control_clause_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$control_clause", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "control_clause", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_control_clause_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_control_clause_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_control_clause_A_InstanceOf; i.Init = A_arbace_g2a_print_code_control_clause_A_Init; i.Table = A_arbace_g2a_print_code_control_clause_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_control_clause_A_class, reflect.TypeFor[A_arbace_g2a_print_code_control_clause_A]()) }

func A_arbace_g2a_print_code_cutoff_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_cutoff_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_cutoff_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_cutoff_A_New()}; return nil }

func A_arbace_g2a_print_code_cutoff_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_cutoff_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_cutoff_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_cutoff_A_invoke, New: A_arbace_g2a_print_code_cutoff_A_new, Get: A_arbace_g2a_print_code_cutoff_A_get}

var A_arbace_g2a_print_code_cutoff_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$cutoff", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "cutoff", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_cutoff_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_cutoff_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_cutoff_A_InstanceOf; i.Init = A_arbace_g2a_print_code_cutoff_A_Init; i.Table = A_arbace_g2a_print_code_cutoff_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_cutoff_A_class, reflect.TypeFor[A_arbace_g2a_print_code_cutoff_A]()) }

func A_arbace_g2a_print_code_cutoff_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_cutoff_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_cutoff_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_cutoff_of_A_New()}; return nil }

func A_arbace_g2a_print_code_cutoff_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_cutoff_of_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_cutoff_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_cutoff_of_A_invoke, New: A_arbace_g2a_print_code_cutoff_of_A_new, Get: A_arbace_g2a_print_code_cutoff_of_A_get}

var A_arbace_g2a_print_code_cutoff_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$cutoff_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "cutoff_of", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_cutoff_of_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_cutoff_of_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_cutoff_of_A_InstanceOf; i.Init = A_arbace_g2a_print_code_cutoff_of_A_Init; i.Table = A_arbace_g2a_print_code_cutoff_of_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_cutoff_of_A_class, reflect.TypeFor[A_arbace_g2a_print_code_cutoff_of_A]()) }

func A_arbace_g2a_print_code_decl_doc_and_directives_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_decl_doc_and_directives_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_decl_doc_and_directives_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_decl_doc_and_directives_A_New()}; return nil }

func A_arbace_g2a_print_code_decl_doc_and_directives_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_decl_doc_and_directives_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_decl_doc_and_directives_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_decl_doc_and_directives_A_invoke, New: A_arbace_g2a_print_code_decl_doc_and_directives_A_new, Get: A_arbace_g2a_print_code_decl_doc_and_directives_A_get}

var A_arbace_g2a_print_code_decl_doc_and_directives_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$decl_doc_and_directives", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "decl_doc_and_directives", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_decl_doc_and_directives_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_decl_doc_and_directives_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_decl_doc_and_directives_A_InstanceOf; i.Init = A_arbace_g2a_print_code_decl_doc_and_directives_A_Init; i.Table = A_arbace_g2a_print_code_decl_doc_and_directives_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_decl_doc_and_directives_A_class, reflect.TypeFor[A_arbace_g2a_print_code_decl_doc_and_directives_A]()) }

func A_arbace_g2a_print_code_diff_prec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_diff_prec_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_diff_prec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_diff_prec_A_New()}; return nil }

func A_arbace_g2a_print_code_diff_prec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_diff_prec_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_diff_prec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_diff_prec_A_invoke, New: A_arbace_g2a_print_code_diff_prec_A_new, Get: A_arbace_g2a_print_code_diff_prec_A_get}

var A_arbace_g2a_print_code_diff_prec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$diff_prec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "diff_prec", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_diff_prec_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_diff_prec_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_diff_prec_A_InstanceOf; i.Init = A_arbace_g2a_print_code_diff_prec_A_Init; i.Table = A_arbace_g2a_print_code_diff_prec_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_diff_prec_A_class, reflect.TypeFor[A_arbace_g2a_print_code_diff_prec_A]()) }

func A_arbace_g2a_print_code_directives_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_directives_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_directives_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_directives_of_A_New()}; return nil }

func A_arbace_g2a_print_code_directives_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_directives_of_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_directives_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_directives_of_A_invoke, New: A_arbace_g2a_print_code_directives_of_A_new, Get: A_arbace_g2a_print_code_directives_of_A_get}

var A_arbace_g2a_print_code_directives_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$directives_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "directives_of", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_directives_of_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_directives_of_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_directives_of_A_InstanceOf; i.Init = A_arbace_g2a_print_code_directives_of_A_Init; i.Table = A_arbace_g2a_print_code_directives_of_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_directives_of_A_class, reflect.TypeFor[A_arbace_g2a_print_code_directives_of_A]()) }

func A_arbace_g2a_print_code_directives_of_fn__1022000124_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_directives_of_fn__1022000124_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_directives_of_fn__1022000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_directives_of_fn__1022000124_A_New()}; return nil }

func A_arbace_g2a_print_code_directives_of_fn__1022000124_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_directives_of_fn__1022000124_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_directives_of_fn__1022000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_directives_of_fn__1022000124_A_invoke, New: A_arbace_g2a_print_code_directives_of_fn__1022000124_A_new, Get: A_arbace_g2a_print_code_directives_of_fn__1022000124_A_get}

var A_arbace_g2a_print_code_directives_of_fn__1022000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$directives_of$fn__1022000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_directives_of_A_class, Simple: "fn__1022000124", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_directives_of_fn__1022000124_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_directives_of_fn__1022000124_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_directives_of_fn__1022000124_A_InstanceOf; i.Init = A_arbace_g2a_print_code_directives_of_fn__1022000124_A_Init; i.Table = A_arbace_g2a_print_code_directives_of_fn__1022000124_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_directives_of_fn__1022000124_A_class, reflect.TypeFor[A_arbace_g2a_print_code_directives_of_fn__1022000124_A]()) }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_New()}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_invoke, New: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_new, Get: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_get}

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$directives_of$iter__1022000104__1022000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_directives_of_A_class, Simple: "iter__1022000104__1022000110", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_InstanceOf; i.Init = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_Init; i.Table = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_class, reflect.TypeFor[A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A]()) }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_invoke, New: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_new, Get: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_get}

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_A_class, Simple: "fn__1022000111", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_InstanceOf; i.Init = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_Init; i.Table = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_class, reflect.TypeFor[A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A]()) }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_invoke, New: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_new, Get: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_get}

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_A_class, Simple: "iter__1022000106__1022000115", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_InstanceOf; i.Init = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_Init; i.Table = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_class, reflect.TypeFor[A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A]()) }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_invoke, New: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_new, Get: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_get}

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115$fn__1022000116", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_A_class, Simple: "fn__1022000116", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_InstanceOf; i.Init = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_Init; i.Table = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_class, reflect.TypeFor[A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A]()) }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_invoke, New: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_new, Get: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_get}

var A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$directives_of$iter__1022000104__1022000110$fn__1022000111$iter__1022000106__1022000115$fn__1022000116$fn__1022000117", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_A_class, Simple: "fn__1022000117", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_InstanceOf; i.Init = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_Init; i.Table = A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A_class, reflect.TypeFor[A_arbace_g2a_print_code_directives_of_iter__1022000104__1022000110_fn__1022000111_iter__1022000106__1022000115_fn__1022000116_fn__1022000117_A]()) }

func A_arbace_g2a_print_code_doc_lines_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_doc_lines_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_doc_lines_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_doc_lines_A_New()}; return nil }

func A_arbace_g2a_print_code_doc_lines_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_doc_lines_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_doc_lines_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_doc_lines_A_invoke, New: A_arbace_g2a_print_code_doc_lines_A_new, Get: A_arbace_g2a_print_code_doc_lines_A_get}

var A_arbace_g2a_print_code_doc_lines_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$doc_lines", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "doc_lines", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_doc_lines_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_doc_lines_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_doc_lines_A_InstanceOf; i.Init = A_arbace_g2a_print_code_doc_lines_A_Init; i.Table = A_arbace_g2a_print_code_doc_lines_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_doc_lines_A_class, reflect.TypeFor[A_arbace_g2a_print_code_doc_lines_A]()) }

func A_arbace_g2a_print_code_element_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_element_list_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_g2a_print_code_element_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_element_list_A_New()}; return nil }

func A_arbace_g2a_print_code_element_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_element_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_element_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_element_list_A_invoke, New: A_arbace_g2a_print_code_element_list_A_new, Get: A_arbace_g2a_print_code_element_list_A_get}

var A_arbace_g2a_print_code_element_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$element_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "element_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_element_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_element_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_element_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_element_list_A_Init; i.Table = A_arbace_g2a_print_code_element_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_element_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_element_list_A]()) }

func A_arbace_g2a_print_code_element_list_fn__1022000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_element_list_fn__1022000068_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_element_list_fn__1022000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_element_list_fn__1022000068_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_element_list_fn__1022000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_element_list_fn__1022000068_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_element_list_fn__1022000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_element_list_fn__1022000068_A_invoke, New: A_arbace_g2a_print_code_element_list_fn__1022000068_A_new, Get: A_arbace_g2a_print_code_element_list_fn__1022000068_A_get}

var A_arbace_g2a_print_code_element_list_fn__1022000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$element_list$fn__1022000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_element_list_A_class, Simple: "fn__1022000068", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_element_list_fn__1022000068_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_element_list_fn__1022000068_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_element_list_fn__1022000068_A_InstanceOf; i.Init = A_arbace_g2a_print_code_element_list_fn__1022000068_A_Init; i.Table = A_arbace_g2a_print_code_element_list_fn__1022000068_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_element_list_fn__1022000068_A_class, reflect.TypeFor[A_arbace_g2a_print_code_element_list_fn__1022000068_A]()) }

func A_arbace_g2a_print_code_element_list_fn__1022000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_element_list_fn__1022000070_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_element_list_fn__1022000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_element_list_fn__1022000070_A_New_O_O_J(args[0], args[1], args[2].(int64))}; return nil }

func A_arbace_g2a_print_code_element_list_fn__1022000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_element_list_fn__1022000070_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_element_list_fn__1022000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_element_list_fn__1022000070_A_invoke, New: A_arbace_g2a_print_code_element_list_fn__1022000070_A_new, Get: A_arbace_g2a_print_code_element_list_fn__1022000070_A_get}

var A_arbace_g2a_print_code_element_list_fn__1022000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$element_list$fn__1022000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_element_list_A_class, Simple: "fn__1022000070", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_element_list_fn__1022000070_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_element_list_fn__1022000070_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_element_list_fn__1022000070_A_InstanceOf; i.Init = A_arbace_g2a_print_code_element_list_fn__1022000070_A_Init; i.Table = A_arbace_g2a_print_code_element_list_fn__1022000070_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_element_list_fn__1022000070_A_class, reflect.TypeFor[A_arbace_g2a_print_code_element_list_fn__1022000070_A]()) }

func A_arbace_g2a_print_code_else_part_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_else_part_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_else_part_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_else_part_A_New()}; return nil }

func A_arbace_g2a_print_code_else_part_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_else_part_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_else_part_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_else_part_A_invoke, New: A_arbace_g2a_print_code_else_part_A_new, Get: A_arbace_g2a_print_code_else_part_A_get}

var A_arbace_g2a_print_code_else_part_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$else_part", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "else_part", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_else_part_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_else_part_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_else_part_A_InstanceOf; i.Init = A_arbace_g2a_print_code_else_part_A_Init; i.Table = A_arbace_g2a_print_code_else_part_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_else_part_A_class, reflect.TypeFor[A_arbace_g2a_print_code_else_part_A]()) }

func A_arbace_g2a_print_code_eval1022000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_eval1022000004_A_New()}; return nil }

var A_arbace_g2a_print_code_eval1022000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_code_eval1022000004_A_new}

var A_arbace_g2a_print_code_eval1022000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$eval1022000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_code_A_class, Simple: "eval1022000004", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_eval1022000004_A"})

func init() { i := A_arbace_g2a_print_code_eval1022000004_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_eval1022000004_A_InstanceOf; i.Table = A_arbace_g2a_print_code_eval1022000004_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_eval1022000004_A_class, reflect.TypeFor[A_arbace_g2a_print_code_eval1022000004_A]()) }

func A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_New()}; return nil }

func A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_invoke, New: A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_new, Get: A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_get}

var A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$eval1022000004$loading__1927001464__auto____1022000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_eval1022000004_A_class, Simple: "loading__1927001464__auto____1022000005", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_InstanceOf; i.Init = A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_Init; i.Table = A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A_class, reflect.TypeFor[A_arbace_g2a_print_code_eval1022000004_loading__1927001464__auto____1022000005_A]()) }

func A_arbace_g2a_print_code_eval1022000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_eval1022000008_A_New()}; return nil }

var A_arbace_g2a_print_code_eval1022000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_code_eval1022000008_A_new}

var A_arbace_g2a_print_code_eval1022000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$eval1022000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_code_A_class, Simple: "eval1022000008", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_eval1022000008_A"})

func init() { i := A_arbace_g2a_print_code_eval1022000008_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_eval1022000008_A_InstanceOf; i.Table = A_arbace_g2a_print_code_eval1022000008_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_eval1022000008_A_class, reflect.TypeFor[A_arbace_g2a_print_code_eval1022000008_A]()) }

func A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_New()}; return nil }

func A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_invoke, New: A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_new, Get: A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_get}

var A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$eval1022000008$fn__1022000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_eval1022000008_A_class, Simple: "fn__1022000009", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_InstanceOf; i.Init = A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_Init; i.Table = A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A_class, reflect.TypeFor[A_arbace_g2a_print_code_eval1022000008_fn__1022000009_A]()) }

func A_arbace_g2a_print_code_expr0_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr0_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_expr0_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr0_A_New()}; return nil }

func A_arbace_g2a_print_code_expr0_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr0_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr0_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr0_A_invoke, New: A_arbace_g2a_print_code_expr0_A_new, Get: A_arbace_g2a_print_code_expr0_A_get}

var A_arbace_g2a_print_code_expr0_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr0", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "expr0", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr0_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr0_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr0_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr0_A_Init; i.Table = A_arbace_g2a_print_code_expr0_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr0_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr0_A]()) }

func A_arbace_g2a_print_code_expr1_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr1_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_expr1_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr1_A_New()}; return nil }

func A_arbace_g2a_print_code_expr1_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr1_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr1_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr1_A_invoke, New: A_arbace_g2a_print_code_expr1_A_new, Get: A_arbace_g2a_print_code_expr1_A_get}

var A_arbace_g2a_print_code_expr1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr1", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "expr1", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr1_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr1_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr1_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr1_A_Init; i.Table = A_arbace_g2a_print_code_expr1_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr1_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr1_A]()) }

func A_arbace_g2a_print_code_expr1_fn__1022000315_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr1_fn__1022000315_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000315_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr1_fn__1022000315_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000315_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr1_fn__1022000315_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr1_fn__1022000315_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr1_fn__1022000315_A_invoke, New: A_arbace_g2a_print_code_expr1_fn__1022000315_A_new, Get: A_arbace_g2a_print_code_expr1_fn__1022000315_A_get}

var A_arbace_g2a_print_code_expr1_fn__1022000315_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr1$fn__1022000315", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_expr1_A_class, Simple: "fn__1022000315", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr1_fn__1022000315_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr1_fn__1022000315_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr1_fn__1022000315_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr1_fn__1022000315_A_Init; i.Table = A_arbace_g2a_print_code_expr1_fn__1022000315_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr1_fn__1022000315_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr1_fn__1022000315_A]()) }

func A_arbace_g2a_print_code_expr1_fn__1022000317_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr1_fn__1022000317_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000317_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr1_fn__1022000317_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000317_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr1_fn__1022000317_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr1_fn__1022000317_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr1_fn__1022000317_A_invoke, New: A_arbace_g2a_print_code_expr1_fn__1022000317_A_new, Get: A_arbace_g2a_print_code_expr1_fn__1022000317_A_get}

var A_arbace_g2a_print_code_expr1_fn__1022000317_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr1$fn__1022000317", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_expr1_A_class, Simple: "fn__1022000317", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr1_fn__1022000317_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr1_fn__1022000317_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr1_fn__1022000317_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr1_fn__1022000317_A_Init; i.Table = A_arbace_g2a_print_code_expr1_fn__1022000317_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr1_fn__1022000317_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr1_fn__1022000317_A]()) }

func A_arbace_g2a_print_code_expr1_fn__1022000332_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr1_fn__1022000332_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000332_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr1_fn__1022000332_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000332_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr1_fn__1022000332_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr1_fn__1022000332_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr1_fn__1022000332_A_invoke, New: A_arbace_g2a_print_code_expr1_fn__1022000332_A_new, Get: A_arbace_g2a_print_code_expr1_fn__1022000332_A_get}

var A_arbace_g2a_print_code_expr1_fn__1022000332_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr1$fn__1022000332", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_expr1_A_class, Simple: "fn__1022000332", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr1_fn__1022000332_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr1_fn__1022000332_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr1_fn__1022000332_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr1_fn__1022000332_A_Init; i.Table = A_arbace_g2a_print_code_expr1_fn__1022000332_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr1_fn__1022000332_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr1_fn__1022000332_A]()) }

func A_arbace_g2a_print_code_expr1_fn__1022000337_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr1_fn__1022000337_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000337_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr1_fn__1022000337_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000337_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr1_fn__1022000337_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr1_fn__1022000337_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr1_fn__1022000337_A_invoke, New: A_arbace_g2a_print_code_expr1_fn__1022000337_A_new, Get: A_arbace_g2a_print_code_expr1_fn__1022000337_A_get}

var A_arbace_g2a_print_code_expr1_fn__1022000337_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr1$fn__1022000337", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_expr1_A_class, Simple: "fn__1022000337", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr1_fn__1022000337_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr1_fn__1022000337_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr1_fn__1022000337_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr1_fn__1022000337_A_Init; i.Table = A_arbace_g2a_print_code_expr1_fn__1022000337_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr1_fn__1022000337_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr1_fn__1022000337_A]()) }

func A_arbace_g2a_print_code_expr1_fn__1022000345_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr1_fn__1022000345_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000345_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr1_fn__1022000345_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000345_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr1_fn__1022000345_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr1_fn__1022000345_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr1_fn__1022000345_A_invoke, New: A_arbace_g2a_print_code_expr1_fn__1022000345_A_new, Get: A_arbace_g2a_print_code_expr1_fn__1022000345_A_get}

var A_arbace_g2a_print_code_expr1_fn__1022000345_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr1$fn__1022000345", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_expr1_A_class, Simple: "fn__1022000345", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr1_fn__1022000345_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr1_fn__1022000345_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr1_fn__1022000345_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr1_fn__1022000345_A_Init; i.Table = A_arbace_g2a_print_code_expr1_fn__1022000345_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr1_fn__1022000345_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr1_fn__1022000345_A]()) }

func A_arbace_g2a_print_code_expr1_fn__1022000350_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr1_fn__1022000350_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000350_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr1_fn__1022000350_A_New()}; return nil }

func A_arbace_g2a_print_code_expr1_fn__1022000350_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr1_fn__1022000350_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr1_fn__1022000350_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr1_fn__1022000350_A_invoke, New: A_arbace_g2a_print_code_expr1_fn__1022000350_A_new, Get: A_arbace_g2a_print_code_expr1_fn__1022000350_A_get}

var A_arbace_g2a_print_code_expr1_fn__1022000350_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr1$fn__1022000350", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_expr1_A_class, Simple: "fn__1022000350", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr1_fn__1022000350_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr1_fn__1022000350_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr1_fn__1022000350_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr1_fn__1022000350_A_Init; i.Table = A_arbace_g2a_print_code_expr1_fn__1022000350_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr1_fn__1022000350_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr1_fn__1022000350_A]()) }

func A_arbace_g2a_print_code_expr_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr_list_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_expr_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr_list_A_New()}; return nil }

func A_arbace_g2a_print_code_expr_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr_list_A_invoke, New: A_arbace_g2a_print_code_expr_list_A_new, Get: A_arbace_g2a_print_code_expr_list_A_get}

var A_arbace_g2a_print_code_expr_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "expr_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr_list_A_Init; i.Table = A_arbace_g2a_print_code_expr_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr_list_A]()) }

func A_arbace_g2a_print_code_expr_list_fn__1022000361_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expr_list_fn__1022000361_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_expr_list_fn__1022000361_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expr_list_fn__1022000361_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_expr_list_fn__1022000361_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expr_list_fn__1022000361_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expr_list_fn__1022000361_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expr_list_fn__1022000361_A_invoke, New: A_arbace_g2a_print_code_expr_list_fn__1022000361_A_new, Get: A_arbace_g2a_print_code_expr_list_fn__1022000361_A_get}

var A_arbace_g2a_print_code_expr_list_fn__1022000361_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expr_list$fn__1022000361", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_expr_list_A_class, Simple: "fn__1022000361", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expr_list_fn__1022000361_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expr_list_fn__1022000361_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expr_list_fn__1022000361_A_InstanceOf; i.Init = A_arbace_g2a_print_code_expr_list_fn__1022000361_A_Init; i.Table = A_arbace_g2a_print_code_expr_list_fn__1022000361_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expr_list_fn__1022000361_A_class, reflect.TypeFor[A_arbace_g2a_print_code_expr_list_fn__1022000361_A]()) }

func A_arbace_g2a_print_code_expression_form_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_expression_form_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_expression_form_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_expression_form_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_expression_form_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_expression_form_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_expression_form_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_expression_form_QMARK__A_invoke, New: A_arbace_g2a_print_code_expression_form_QMARK__A_new, Get: A_arbace_g2a_print_code_expression_form_QMARK__A_get}

var A_arbace_g2a_print_code_expression_form_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$expression_form_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "expression_form_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_expression_form_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_expression_form_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_expression_form_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_expression_form_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_expression_form_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_expression_form_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_expression_form_QMARK__A]()) }

func A_arbace_g2a_print_code_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_fail_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_fail_A_New()}; return nil }

func A_arbace_g2a_print_code_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_fail_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_fail_A_invoke, New: A_arbace_g2a_print_code_fail_A_new, Get: A_arbace_g2a_print_code_fail_A_get}

var A_arbace_g2a_print_code_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "fail", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_fail_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_fail_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_fail_A_InstanceOf; i.Init = A_arbace_g2a_print_code_fail_A_Init; i.Table = A_arbace_g2a_print_code_fail_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_fail_A_class, reflect.TypeFor[A_arbace_g2a_print_code_fail_A]()) }

func A_arbace_g2a_print_code_field_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_body_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_field_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_body_A_New()}; return nil }

func A_arbace_g2a_print_code_field_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_body_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_body_A_invoke, New: A_arbace_g2a_print_code_field_body_A_new, Get: A_arbace_g2a_print_code_field_body_A_get}

var A_arbace_g2a_print_code_field_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "field_body", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_body_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_body_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_body_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_body_A_Init; i.Table = A_arbace_g2a_print_code_field_body_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_body_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_body_A]()) }

func A_arbace_g2a_print_code_field_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_field_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_A_New()}; return nil }

func A_arbace_g2a_print_code_field_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_A_invoke, New: A_arbace_g2a_print_code_field_list_A_new, Get: A_arbace_g2a_print_code_field_list_A_get}

var A_arbace_g2a_print_code_field_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "field_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_A_Init; i.Table = A_arbace_g2a_print_code_field_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_A]()) }

func A_arbace_g2a_print_code_field_list_fn__1022000164_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_fn__1022000164_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000164_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_fn__1022000164_A_New()}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000164_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_fn__1022000164_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_fn__1022000164_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_fn__1022000164_A_invoke, New: A_arbace_g2a_print_code_field_list_fn__1022000164_A_new, Get: A_arbace_g2a_print_code_field_list_fn__1022000164_A_get}

var A_arbace_g2a_print_code_field_list_fn__1022000164_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list$fn__1022000164", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_field_list_A_class, Simple: "fn__1022000164", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_fn__1022000164_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_fn__1022000164_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_fn__1022000164_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_fn__1022000164_A_Init; i.Table = A_arbace_g2a_print_code_field_list_fn__1022000164_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_fn__1022000164_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_fn__1022000164_A]()) }

func A_arbace_g2a_print_code_field_list_fn__1022000166_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_fn__1022000166_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000166_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_fn__1022000166_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000166_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_fn__1022000166_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_fn__1022000166_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_fn__1022000166_A_invoke, New: A_arbace_g2a_print_code_field_list_fn__1022000166_A_new, Get: A_arbace_g2a_print_code_field_list_fn__1022000166_A_get}

var A_arbace_g2a_print_code_field_list_fn__1022000166_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list$fn__1022000166", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_field_list_A_class, Simple: "fn__1022000166", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_fn__1022000166_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_fn__1022000166_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_fn__1022000166_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_fn__1022000166_A_Init; i.Table = A_arbace_g2a_print_code_field_list_fn__1022000166_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_fn__1022000166_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_fn__1022000166_A]()) }

func A_arbace_g2a_print_code_field_list_fn__1022000168_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_fn__1022000168_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000168_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_fn__1022000168_A_New()}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000168_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_fn__1022000168_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_fn__1022000168_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_fn__1022000168_A_invoke, New: A_arbace_g2a_print_code_field_list_fn__1022000168_A_new, Get: A_arbace_g2a_print_code_field_list_fn__1022000168_A_get}

var A_arbace_g2a_print_code_field_list_fn__1022000168_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list$fn__1022000168", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_field_list_A_class, Simple: "fn__1022000168", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_fn__1022000168_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_fn__1022000168_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_fn__1022000168_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_fn__1022000168_A_Init; i.Table = A_arbace_g2a_print_code_field_list_fn__1022000168_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_fn__1022000168_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_fn__1022000168_A]()) }

func A_arbace_g2a_print_code_field_list_fn__1022000180_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_fn__1022000180_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000180_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_fn__1022000180_A_New_O_O_O_O_O_O_O_O_J(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8].(int64))}; return nil }

func A_arbace_g2a_print_code_field_list_fn__1022000180_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_fn__1022000180_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_fn__1022000180_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_fn__1022000180_A_invoke, New: A_arbace_g2a_print_code_field_list_fn__1022000180_A_new, Get: A_arbace_g2a_print_code_field_list_fn__1022000180_A_get}

var A_arbace_g2a_print_code_field_list_fn__1022000180_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list$fn__1022000180", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_field_list_A_class, Simple: "fn__1022000180", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_fn__1022000180_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_fn__1022000180_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_fn__1022000180_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_fn__1022000180_A_Init; i.Table = A_arbace_g2a_print_code_field_list_fn__1022000180_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_fn__1022000180_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_fn__1022000180_A]()) }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_New()}; return nil }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_invoke, New: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_new, Get: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_get}

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list$iter__1022000154__1022000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_field_list_A_class, Simple: "iter__1022000154__1022000158", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_Init; i.Table = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A]()) }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_invoke, New: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_new, Get: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_get}

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list$iter__1022000154__1022000158$fn__1022000159", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_A_class, Simple: "fn__1022000159", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_Init; i.Table = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A]()) }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_invoke, New: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_new, Get: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_get}

var A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$field_list$iter__1022000154__1022000158$fn__1022000159$fn__1022000160", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_A_class, Simple: "fn__1022000160", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_InstanceOf; i.Init = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_Init; i.Table = A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A_class, reflect.TypeFor[A_arbace_g2a_print_code_field_list_iter__1022000154__1022000158_fn__1022000159_fn__1022000160_A]()) }

func A_arbace_g2a_print_code_flatten_stmts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_flatten_stmts_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_flatten_stmts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_flatten_stmts_A_New()}; return nil }

func A_arbace_g2a_print_code_flatten_stmts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_flatten_stmts_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_flatten_stmts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_flatten_stmts_A_invoke, New: A_arbace_g2a_print_code_flatten_stmts_A_new, Get: A_arbace_g2a_print_code_flatten_stmts_A_get}

var A_arbace_g2a_print_code_flatten_stmts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$flatten_stmts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "flatten_stmts", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_flatten_stmts_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_flatten_stmts_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_flatten_stmts_A_InstanceOf; i.Init = A_arbace_g2a_print_code_flatten_stmts_A_Init; i.Table = A_arbace_g2a_print_code_flatten_stmts_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_flatten_stmts_A_class, reflect.TypeFor[A_arbace_g2a_print_code_flatten_stmts_A]()) }

func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_invoke, New: A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_new, Get: A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_get}

var A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$flatten_stmts$fn__1022000503", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_flatten_stmts_A_class, Simple: "fn__1022000503", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_InstanceOf; i.Init = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_Init; i.Table = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_class, reflect.TypeFor[A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A]()) }

func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_invoke, New: A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_new, Get: A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_get}

var A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$flatten_stmts$fn__1022000503$fn__1022000508", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_A_class, Simple: "fn__1022000508", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_InstanceOf; i.Init = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_Init; i.Table = A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A_class, reflect.TypeFor[A_arbace_g2a_print_code_flatten_stmts_fn__1022000503_fn__1022000508_A]()) }

func A_arbace_g2a_print_code_for_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_for_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_for_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_for_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_for_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_for_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_for_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_for_stmt_A_invoke, New: A_arbace_g2a_print_code_for_stmt_A_new, Get: A_arbace_g2a_print_code_for_stmt_A_get}

var A_arbace_g2a_print_code_for_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$for_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "for_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_for_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_for_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_for_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_for_stmt_A_Init; i.Table = A_arbace_g2a_print_code_for_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_for_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_for_stmt_A]()) }

func A_arbace_g2a_print_code_func_decl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_func_decl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_func_decl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_func_decl_A_New()}; return nil }

func A_arbace_g2a_print_code_func_decl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_func_decl_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_func_decl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_func_decl_A_invoke, New: A_arbace_g2a_print_code_func_decl_A_new, Get: A_arbace_g2a_print_code_func_decl_A_get}

var A_arbace_g2a_print_code_func_decl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$func_decl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "func_decl", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_func_decl_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_func_decl_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_func_decl_A_InstanceOf; i.Init = A_arbace_g2a_print_code_func_decl_A_Init; i.Table = A_arbace_g2a_print_code_func_decl_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_func_decl_A_class, reflect.TypeFor[A_arbace_g2a_print_code_func_decl_A]()) }

func A_arbace_g2a_print_code_func_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_func_lit_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_func_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_func_lit_A_New()}; return nil }

func A_arbace_g2a_print_code_func_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_func_lit_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_func_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_func_lit_A_invoke, New: A_arbace_g2a_print_code_func_lit_A_new, Get: A_arbace_g2a_print_code_func_lit_A_get}

var A_arbace_g2a_print_code_func_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$func_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "func_lit", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_func_lit_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_func_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_func_lit_A_InstanceOf; i.Init = A_arbace_g2a_print_code_func_lit_A_Init; i.Table = A_arbace_g2a_print_code_func_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_func_lit_A_class, reflect.TypeFor[A_arbace_g2a_print_code_func_lit_A]()) }

func A_arbace_g2a_print_code_func_type_sig_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_func_type_sig_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_func_type_sig_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_func_type_sig_A_New()}; return nil }

func A_arbace_g2a_print_code_func_type_sig_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_func_type_sig_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_func_type_sig_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_func_type_sig_A_invoke, New: A_arbace_g2a_print_code_func_type_sig_A_new, Get: A_arbace_g2a_print_code_func_type_sig_A_get}

var A_arbace_g2a_print_code_func_type_sig_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$func_type_sig", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "func_type_sig", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_func_type_sig_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_func_type_sig_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_func_type_sig_A_InstanceOf; i.Init = A_arbace_g2a_print_code_func_type_sig_A_Init; i.Table = A_arbace_g2a_print_code_func_type_sig_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_func_type_sig_A_class, reflect.TypeFor[A_arbace_g2a_print_code_func_type_sig_A]()) }

func A_arbace_g2a_print_code_generic_type_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_generic_type_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_generic_type_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_generic_type_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_generic_type_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_generic_type_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_generic_type_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_generic_type_QMARK__A_invoke, New: A_arbace_g2a_print_code_generic_type_QMARK__A_new, Get: A_arbace_g2a_print_code_generic_type_QMARK__A_get}

var A_arbace_g2a_print_code_generic_type_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$generic_type_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "generic_type_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_generic_type_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_generic_type_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_generic_type_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_generic_type_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_generic_type_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_generic_type_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_generic_type_QMARK__A]()) }

func A_arbace_g2a_print_code_go_sym_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_go_sym_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_go_sym_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_go_sym_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_go_sym_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_go_sym_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_go_sym_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_go_sym_QMARK__A_invoke, New: A_arbace_g2a_print_code_go_sym_QMARK__A_new, Get: A_arbace_g2a_print_code_go_sym_QMARK__A_get}

var A_arbace_g2a_print_code_go_sym_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$go_sym_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "go_sym_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_go_sym_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_go_sym_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_go_sym_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_go_sym_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_go_sym_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_go_sym_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_go_sym_QMARK__A]()) }

func A_arbace_g2a_print_code_group_consts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_consts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_group_consts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_consts_A_New()}; return nil }

func A_arbace_g2a_print_code_group_consts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_consts_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_consts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_consts_A_invoke, New: A_arbace_g2a_print_code_group_consts_A_new, Get: A_arbace_g2a_print_code_group_consts_A_get}

var A_arbace_g2a_print_code_group_consts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_consts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "group_consts", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_consts_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_consts_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_consts_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_consts_A_Init; i.Table = A_arbace_g2a_print_code_group_consts_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_consts_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_consts_A]()) }

func A_arbace_g2a_print_code_group_consts_fn__1022000525_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_consts_fn__1022000525_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_group_consts_fn__1022000525_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_consts_fn__1022000525_A_New()}; return nil }

func A_arbace_g2a_print_code_group_consts_fn__1022000525_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_consts_fn__1022000525_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_consts_fn__1022000525_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_consts_fn__1022000525_A_invoke, New: A_arbace_g2a_print_code_group_consts_fn__1022000525_A_new, Get: A_arbace_g2a_print_code_group_consts_fn__1022000525_A_get}

var A_arbace_g2a_print_code_group_consts_fn__1022000525_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_consts$fn__1022000525", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_group_consts_A_class, Simple: "fn__1022000525", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_consts_fn__1022000525_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_consts_fn__1022000525_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_consts_fn__1022000525_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_consts_fn__1022000525_A_Init; i.Table = A_arbace_g2a_print_code_group_consts_fn__1022000525_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_consts_fn__1022000525_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_consts_fn__1022000525_A]()) }

func A_arbace_g2a_print_code_group_decl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_decl_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_g2a_print_code_group_decl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_decl_A_New()}; return nil }

func A_arbace_g2a_print_code_group_decl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_decl_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_decl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_decl_A_invoke, New: A_arbace_g2a_print_code_group_decl_A_new, Get: A_arbace_g2a_print_code_group_decl_A_get}

var A_arbace_g2a_print_code_group_decl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_decl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "group_decl", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_decl_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_decl_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_decl_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_decl_A_Init; i.Table = A_arbace_g2a_print_code_group_decl_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_decl_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_decl_A]()) }

func A_arbace_g2a_print_code_group_decl_fn__1022000627_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_decl_fn__1022000627_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_group_decl_fn__1022000627_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_decl_fn__1022000627_A_New_O_O_O_J(args[0], args[1], args[2], args[3].(int64))}; return nil }

func A_arbace_g2a_print_code_group_decl_fn__1022000627_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_decl_fn__1022000627_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_decl_fn__1022000627_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_decl_fn__1022000627_A_invoke, New: A_arbace_g2a_print_code_group_decl_fn__1022000627_A_new, Get: A_arbace_g2a_print_code_group_decl_fn__1022000627_A_get}

var A_arbace_g2a_print_code_group_decl_fn__1022000627_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_decl$fn__1022000627", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_group_decl_A_class, Simple: "fn__1022000627", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_decl_fn__1022000627_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_decl_fn__1022000627_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_decl_fn__1022000627_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_decl_fn__1022000627_A_Init; i.Table = A_arbace_g2a_print_code_group_decl_fn__1022000627_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_decl_fn__1022000627_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_decl_fn__1022000627_A]()) }

func A_arbace_g2a_print_code_group_entries_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_entries_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_group_entries_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_entries_A_New()}; return nil }

func A_arbace_g2a_print_code_group_entries_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_entries_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_entries_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_entries_A_invoke, New: A_arbace_g2a_print_code_group_entries_A_new, Get: A_arbace_g2a_print_code_group_entries_A_get}

var A_arbace_g2a_print_code_group_entries_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_entries", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "group_entries", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_entries_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_entries_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_entries_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_entries_A_Init; i.Table = A_arbace_g2a_print_code_group_entries_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_entries_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_entries_A]()) }

func A_arbace_g2a_print_code_group_entries_fn__1022000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_entries_fn__1022000077_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_group_entries_fn__1022000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_entries_fn__1022000077_A_New()}; return nil }

func A_arbace_g2a_print_code_group_entries_fn__1022000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_entries_fn__1022000077_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_entries_fn__1022000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_entries_fn__1022000077_A_invoke, New: A_arbace_g2a_print_code_group_entries_fn__1022000077_A_new, Get: A_arbace_g2a_print_code_group_entries_fn__1022000077_A_get}

var A_arbace_g2a_print_code_group_entries_fn__1022000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_entries$fn__1022000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_group_entries_A_class, Simple: "fn__1022000077", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_entries_fn__1022000077_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_entries_fn__1022000077_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_entries_fn__1022000077_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_entries_fn__1022000077_A_Init; i.Table = A_arbace_g2a_print_code_group_entries_fn__1022000077_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_entries_fn__1022000077_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_entries_fn__1022000077_A]()) }

func A_arbace_g2a_print_code_group_entries_fn__1022000079_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_entries_fn__1022000079_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_group_entries_fn__1022000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_entries_fn__1022000079_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_group_entries_fn__1022000079_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_entries_fn__1022000079_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_entries_fn__1022000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_entries_fn__1022000079_A_invoke, New: A_arbace_g2a_print_code_group_entries_fn__1022000079_A_new, Get: A_arbace_g2a_print_code_group_entries_fn__1022000079_A_get}

var A_arbace_g2a_print_code_group_entries_fn__1022000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_entries$fn__1022000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_group_entries_A_class, Simple: "fn__1022000079", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_entries_fn__1022000079_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_entries_fn__1022000079_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_entries_fn__1022000079_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_entries_fn__1022000079_A_Init; i.Table = A_arbace_g2a_print_code_group_entries_fn__1022000079_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_entries_fn__1022000079_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_entries_fn__1022000079_A]()) }

func A_arbace_g2a_print_code_group_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_group_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_line_A_New()}; return nil }

func A_arbace_g2a_print_code_group_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_line_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_line_A_invoke, New: A_arbace_g2a_print_code_group_line_A_new, Get: A_arbace_g2a_print_code_group_line_A_get}

var A_arbace_g2a_print_code_group_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "group_line", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_line_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_line_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_line_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_line_A_Init; i.Table = A_arbace_g2a_print_code_group_line_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_line_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_line_A]()) }

func A_arbace_g2a_print_code_group_target_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_group_target_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_group_target_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_group_target_A_New()}; return nil }

func A_arbace_g2a_print_code_group_target_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_group_target_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_group_target_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_group_target_A_invoke, New: A_arbace_g2a_print_code_group_target_A_new, Get: A_arbace_g2a_print_code_group_target_A_get}

var A_arbace_g2a_print_code_group_target_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$group_target", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "group_target", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_group_target_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_group_target_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_group_target_A_InstanceOf; i.Init = A_arbace_g2a_print_code_group_target_A_Init; i.Table = A_arbace_g2a_print_code_group_target_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_group_target_A_class, reflect.TypeFor[A_arbace_g2a_print_code_group_target_A]()) }

func A_arbace_g2a_print_code_groupable_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_groupable_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_groupable_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_groupable_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_groupable_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_groupable_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_groupable_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_groupable_QMARK__A_invoke, New: A_arbace_g2a_print_code_groupable_QMARK__A_new, Get: A_arbace_g2a_print_code_groupable_QMARK__A_get}

var A_arbace_g2a_print_code_groupable_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$groupable_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "groupable_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_groupable_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_groupable_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_groupable_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_groupable_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_groupable_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_groupable_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_groupable_QMARK__A]()) }

func A_arbace_g2a_print_code_ident_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_ident_string_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_ident_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_ident_string_A_New()}; return nil }

func A_arbace_g2a_print_code_ident_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_ident_string_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_ident_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_ident_string_A_invoke, New: A_arbace_g2a_print_code_ident_string_A_new, Get: A_arbace_g2a_print_code_ident_string_A_get}

var A_arbace_g2a_print_code_ident_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$ident_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "ident_string", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_ident_string_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_ident_string_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_ident_string_A_InstanceOf; i.Init = A_arbace_g2a_print_code_ident_string_A_Init; i.Table = A_arbace_g2a_print_code_ident_string_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_ident_string_A_class, reflect.TypeFor[A_arbace_g2a_print_code_ident_string_A]()) }

func A_arbace_g2a_print_code_if_like_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_if_like_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_if_like_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_if_like_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_if_like_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_if_like_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_if_like_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_if_like_QMARK__A_invoke, New: A_arbace_g2a_print_code_if_like_QMARK__A_new, Get: A_arbace_g2a_print_code_if_like_QMARK__A_get}

var A_arbace_g2a_print_code_if_like_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$if_like_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "if_like_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_if_like_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_if_like_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_if_like_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_if_like_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_if_like_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_if_like_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_if_like_QMARK__A]()) }

func A_arbace_g2a_print_code_if_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_if_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_if_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_if_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_if_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_if_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_if_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_if_stmt_A_invoke, New: A_arbace_g2a_print_code_if_stmt_A_new, Get: A_arbace_g2a_print_code_if_stmt_A_get}

var A_arbace_g2a_print_code_if_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$if_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "if_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_if_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_if_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_if_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_if_stmt_A_Init; i.Table = A_arbace_g2a_print_code_if_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_if_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_if_stmt_A]()) }

func A_arbace_g2a_print_code_iface_method_sig_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_iface_method_sig_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_iface_method_sig_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_iface_method_sig_A_New()}; return nil }

func A_arbace_g2a_print_code_iface_method_sig_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_iface_method_sig_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_iface_method_sig_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_iface_method_sig_A_invoke, New: A_arbace_g2a_print_code_iface_method_sig_A_new, Get: A_arbace_g2a_print_code_iface_method_sig_A_get}

var A_arbace_g2a_print_code_iface_method_sig_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$iface_method_sig", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "iface_method_sig", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_iface_method_sig_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_iface_method_sig_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_iface_method_sig_A_InstanceOf; i.Init = A_arbace_g2a_print_code_iface_method_sig_A_Init; i.Table = A_arbace_g2a_print_code_iface_method_sig_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_iface_method_sig_A_class, reflect.TypeFor[A_arbace_g2a_print_code_iface_method_sig_A]()) }

func A_arbace_g2a_print_code_interface_method_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_interface_method_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_interface_method_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_interface_method_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_interface_method_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_interface_method_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_interface_method_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_interface_method_QMARK__A_invoke, New: A_arbace_g2a_print_code_interface_method_QMARK__A_new, Get: A_arbace_g2a_print_code_interface_method_QMARK__A_get}

var A_arbace_g2a_print_code_interface_method_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$interface_method_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "interface_method_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_interface_method_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_interface_method_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_interface_method_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_interface_method_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_interface_method_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_interface_method_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_interface_method_QMARK__A]()) }

func A_arbace_g2a_print_code_item_t_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_item_t_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_item_t_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_item_t_A_New()}; return nil }

func A_arbace_g2a_print_code_item_t_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_item_t_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_item_t_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_item_t_A_invoke, New: A_arbace_g2a_print_code_item_t_A_new, Get: A_arbace_g2a_print_code_item_t_A_get}

var A_arbace_g2a_print_code_item_t_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$item_t", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "item_t", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_item_t_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_item_t_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_item_t_A_InstanceOf; i.Init = A_arbace_g2a_print_code_item_t_A_Init; i.Table = A_arbace_g2a_print_code_item_t_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_item_t_A_class, reflect.TypeFor[A_arbace_g2a_print_code_item_t_A]()) }

func A_arbace_g2a_print_code_keep_type_column_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_keep_type_column_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_keep_type_column_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_keep_type_column_A_New()}; return nil }

func A_arbace_g2a_print_code_keep_type_column_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_keep_type_column_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_keep_type_column_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_keep_type_column_A_invoke, New: A_arbace_g2a_print_code_keep_type_column_A_new, Get: A_arbace_g2a_print_code_keep_type_column_A_get}

var A_arbace_g2a_print_code_keep_type_column_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$keep_type_column", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "keep_type_column", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_keep_type_column_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_keep_type_column_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_keep_type_column_A_InstanceOf; i.Init = A_arbace_g2a_print_code_keep_type_column_A_Init; i.Table = A_arbace_g2a_print_code_keep_type_column_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_keep_type_column_A_class, reflect.TypeFor[A_arbace_g2a_print_code_keep_type_column_A]()) }

func A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_New()}; return nil }

func A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_invoke, New: A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_new, Get: A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_get}

var A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$keep_type_column$fn__1022000615", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_keep_type_column_A_class, Simple: "fn__1022000615", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_InstanceOf; i.Init = A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_Init; i.Table = A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A_class, reflect.TypeFor[A_arbace_g2a_print_code_keep_type_column_fn__1022000615_A]()) }

func A_arbace_g2a_print_code_key_size_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_key_size_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_key_size_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_key_size_A_New()}; return nil }

func A_arbace_g2a_print_code_key_size_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_key_size_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_key_size_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_key_size_A_invoke, New: A_arbace_g2a_print_code_key_size_A_new, Get: A_arbace_g2a_print_code_key_size_A_get}

var A_arbace_g2a_print_code_key_size_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$key_size", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "key_size", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_key_size_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_key_size_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_key_size_A_InstanceOf; i.Init = A_arbace_g2a_print_code_key_size_A_Init; i.Table = A_arbace_g2a_print_code_key_size_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_key_size_A_class, reflect.TypeFor[A_arbace_g2a_print_code_key_size_A]()) }

func A_arbace_g2a_print_code_label_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_label_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_label_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_label_name_A_New()}; return nil }

func A_arbace_g2a_print_code_label_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_label_name_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_label_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_label_name_A_invoke, New: A_arbace_g2a_print_code_label_name_A_new, Get: A_arbace_g2a_print_code_label_name_A_get}

var A_arbace_g2a_print_code_label_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$label_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "label_name", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_label_name_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_label_name_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_label_name_A_InstanceOf; i.Init = A_arbace_g2a_print_code_label_name_A_Init; i.Table = A_arbace_g2a_print_code_label_name_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_label_name_A_class, reflect.TypeFor[A_arbace_g2a_print_code_label_name_A]()) }

func A_arbace_g2a_print_code_label_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_label_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_label_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_label_of_A_New()}; return nil }

func A_arbace_g2a_print_code_label_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_label_of_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_label_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_label_of_A_invoke, New: A_arbace_g2a_print_code_label_of_A_new, Get: A_arbace_g2a_print_code_label_of_A_get}

var A_arbace_g2a_print_code_label_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$label_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "label_of", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_label_of_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_label_of_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_label_of_A_InstanceOf; i.Init = A_arbace_g2a_print_code_label_of_A_Init; i.Table = A_arbace_g2a_print_code_label_of_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_label_of_A_class, reflect.TypeFor[A_arbace_g2a_print_code_label_of_A]()) }

func A_arbace_g2a_print_code_label_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_label_stmt_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_label_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_label_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_label_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_label_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_label_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_label_stmt_A_invoke, New: A_arbace_g2a_print_code_label_stmt_A_new, Get: A_arbace_g2a_print_code_label_stmt_A_get}

var A_arbace_g2a_print_code_label_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$label_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "label_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_label_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_label_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_label_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_label_stmt_A_Init; i.Table = A_arbace_g2a_print_code_label_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_label_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_label_stmt_A]()) }

func A_arbace_g2a_print_code_line_indent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_line_indent_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_line_indent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_line_indent_A_New()}; return nil }

func A_arbace_g2a_print_code_line_indent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_line_indent_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_line_indent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_line_indent_A_invoke, New: A_arbace_g2a_print_code_line_indent_A_new, Get: A_arbace_g2a_print_code_line_indent_A_get}

var A_arbace_g2a_print_code_line_indent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$line_indent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "line_indent", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_line_indent_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_line_indent_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_line_indent_A_InstanceOf; i.Init = A_arbace_g2a_print_code_line_indent_A_Init; i.Table = A_arbace_g2a_print_code_line_indent_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_line_indent_A_class, reflect.TypeFor[A_arbace_g2a_print_code_line_indent_A]()) }

func A_arbace_g2a_print_code_line_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_line_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_line_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_line_of_A_New()}; return nil }

func A_arbace_g2a_print_code_line_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_line_of_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_line_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_line_of_A_invoke, New: A_arbace_g2a_print_code_line_of_A_new, Get: A_arbace_g2a_print_code_line_of_A_get}

var A_arbace_g2a_print_code_line_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$line_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "line_of", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_line_of_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_line_of_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_line_of_A_InstanceOf; i.Init = A_arbace_g2a_print_code_line_of_A_Init; i.Table = A_arbace_g2a_print_code_line_of_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_line_of_A_class, reflect.TypeFor[A_arbace_g2a_print_code_line_of_A]()) }

func A_arbace_g2a_print_code_lit_elements_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_lit_elements_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_lit_elements_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_lit_elements_A_New()}; return nil }

func A_arbace_g2a_print_code_lit_elements_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_lit_elements_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_lit_elements_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_lit_elements_A_invoke, New: A_arbace_g2a_print_code_lit_elements_A_new, Get: A_arbace_g2a_print_code_lit_elements_A_get}

var A_arbace_g2a_print_code_lit_elements_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$lit_elements", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "lit_elements", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_lit_elements_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_lit_elements_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_lit_elements_A_InstanceOf; i.Init = A_arbace_g2a_print_code_lit_elements_A_Init; i.Table = A_arbace_g2a_print_code_lit_elements_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_lit_elements_A_class, reflect.TypeFor[A_arbace_g2a_print_code_lit_elements_A]()) }

func A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_invoke, New: A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_new, Get: A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_get}

var A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$lit_type_needs_parens_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "lit_type_needs_parens_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_lit_type_needs_parens_QMARK__A]()) }

func A_arbace_g2a_print_code_literal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_literal_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_literal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_literal_A_New()}; return nil }

func A_arbace_g2a_print_code_literal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_literal_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_literal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_literal_A_invoke, New: A_arbace_g2a_print_code_literal_A_new, Get: A_arbace_g2a_print_code_literal_A_get}

var A_arbace_g2a_print_code_literal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$literal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "literal", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_literal_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_literal_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_literal_A_InstanceOf; i.Init = A_arbace_g2a_print_code_literal_A_Init; i.Table = A_arbace_g2a_print_code_literal_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_literal_A_class, reflect.TypeFor[A_arbace_g2a_print_code_literal_A]()) }

func A_arbace_g2a_print_code_n_values_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_n_values_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_n_values_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_n_values_A_New()}; return nil }

func A_arbace_g2a_print_code_n_values_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_n_values_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_n_values_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_n_values_A_invoke, New: A_arbace_g2a_print_code_n_values_A_new, Get: A_arbace_g2a_print_code_n_values_A_get}

var A_arbace_g2a_print_code_n_values_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$n_values", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "n_values", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_n_values_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_n_values_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_n_values_A_InstanceOf; i.Init = A_arbace_g2a_print_code_n_values_A_Init; i.Table = A_arbace_g2a_print_code_n_values_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_n_values_A_class, reflect.TypeFor[A_arbace_g2a_print_code_n_values_A]()) }

func A_arbace_g2a_print_code_name_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_name_list_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_name_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_name_list_A_New()}; return nil }

func A_arbace_g2a_print_code_name_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_name_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_name_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_name_list_A_invoke, New: A_arbace_g2a_print_code_name_list_A_new, Get: A_arbace_g2a_print_code_name_list_A_get}

var A_arbace_g2a_print_code_name_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$name_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "name_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_name_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_name_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_name_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_name_list_A_Init; i.Table = A_arbace_g2a_print_code_name_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_name_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_name_list_A]()) }

func A_arbace_g2a_print_code_negative_literal_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_negative_literal_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_negative_literal_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_negative_literal_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_negative_literal_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_negative_literal_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_negative_literal_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_negative_literal_QMARK__A_invoke, New: A_arbace_g2a_print_code_negative_literal_QMARK__A_new, Get: A_arbace_g2a_print_code_negative_literal_QMARK__A_get}

var A_arbace_g2a_print_code_negative_literal_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$negative_literal_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "negative_literal_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_negative_literal_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_negative_literal_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_negative_literal_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_negative_literal_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_negative_literal_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_negative_literal_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_negative_literal_QMARK__A]()) }

func A_arbace_g2a_print_code_new_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_new_arg_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_new_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_new_arg_A_New()}; return nil }

func A_arbace_g2a_print_code_new_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_new_arg_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_new_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_new_arg_A_invoke, New: A_arbace_g2a_print_code_new_arg_A_new, Get: A_arbace_g2a_print_code_new_arg_A_get}

var A_arbace_g2a_print_code_new_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$new_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "new_arg", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_new_arg_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_new_arg_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_new_arg_A_InstanceOf; i.Init = A_arbace_g2a_print_code_new_arg_A_Init; i.Table = A_arbace_g2a_print_code_new_arg_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_new_arg_A_class, reflect.TypeFor[A_arbace_g2a_print_code_new_arg_A]()) }

func A_arbace_g2a_print_code_next_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_next_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_next_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_next_line_A_New()}; return nil }

func A_arbace_g2a_print_code_next_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_next_line_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_next_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_next_line_A_invoke, New: A_arbace_g2a_print_code_next_line_A_new, Get: A_arbace_g2a_print_code_next_line_A_get}

var A_arbace_g2a_print_code_next_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$next_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "next_line", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_next_line_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_next_line_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_next_line_A_InstanceOf; i.Init = A_arbace_g2a_print_code_next_line_A_Init; i.Table = A_arbace_g2a_print_code_next_line_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_next_line_A_class, reflect.TypeFor[A_arbace_g2a_print_code_next_line_A]()) }

func A_arbace_g2a_print_code_next_targets_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_next_targets_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_next_targets_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_next_targets_A_New()}; return nil }

func A_arbace_g2a_print_code_next_targets_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_next_targets_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_next_targets_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_next_targets_A_invoke, New: A_arbace_g2a_print_code_next_targets_A_new, Get: A_arbace_g2a_print_code_next_targets_A_get}

var A_arbace_g2a_print_code_next_targets_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$next_targets", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "next_targets", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_next_targets_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_next_targets_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_next_targets_A_InstanceOf; i.Init = A_arbace_g2a_print_code_next_targets_A_Init; i.Table = A_arbace_g2a_print_code_next_targets_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_next_targets_A_class, reflect.TypeFor[A_arbace_g2a_print_code_next_targets_A]()) }

func A_arbace_g2a_print_code_one_line_fields_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_one_line_fields_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_one_line_fields_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_one_line_fields_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_one_line_fields_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_one_line_fields_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_one_line_fields_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_one_line_fields_QMARK__A_invoke, New: A_arbace_g2a_print_code_one_line_fields_QMARK__A_new, Get: A_arbace_g2a_print_code_one_line_fields_QMARK__A_get}

var A_arbace_g2a_print_code_one_line_fields_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$one_line_fields_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "one_line_fields_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_one_line_fields_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_one_line_fields_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_one_line_fields_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_one_line_fields_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_one_line_fields_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_one_line_fields_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_one_line_fields_QMARK__A]()) }

func A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_invoke, New: A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_new, Get: A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_get}

var A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$one_line_fields_QMARK_$fn__1022000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_one_line_fields_QMARK__A_class, Simple: "fn__1022000138", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_InstanceOf; i.Init = A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_Init; i.Table = A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A_class, reflect.TypeFor[A_arbace_g2a_print_code_one_line_fields_QMARK__fn__1022000138_A]()) }

func A_arbace_g2a_print_code_op_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_op_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_op_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_op_A_New()}; return nil }

func A_arbace_g2a_print_code_op_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_op_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_op_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_op_A_invoke, New: A_arbace_g2a_print_code_op_A_new, Get: A_arbace_g2a_print_code_op_A_get}

var A_arbace_g2a_print_code_op_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$op", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "op", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_op_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_op_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_op_A_InstanceOf; i.Init = A_arbace_g2a_print_code_op_A_Init; i.Table = A_arbace_g2a_print_code_op_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_op_A_class, reflect.TypeFor[A_arbace_g2a_print_code_op_A]()) }

func A_arbace_g2a_print_code_param_entries_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_param_entries_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_param_entries_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_param_entries_A_New()}; return nil }

func A_arbace_g2a_print_code_param_entries_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_param_entries_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_param_entries_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_param_entries_A_invoke, New: A_arbace_g2a_print_code_param_entries_A_new, Get: A_arbace_g2a_print_code_param_entries_A_get}

var A_arbace_g2a_print_code_param_entries_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$param_entries", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "param_entries", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_param_entries_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_param_entries_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_param_entries_A_InstanceOf; i.Init = A_arbace_g2a_print_code_param_entries_A_Init; i.Table = A_arbace_g2a_print_code_param_entries_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_param_entries_A_class, reflect.TypeFor[A_arbace_g2a_print_code_param_entries_A]()) }

func A_arbace_g2a_print_code_param_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_param_list_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_param_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_param_list_A_New()}; return nil }

func A_arbace_g2a_print_code_param_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_param_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_param_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_param_list_A_invoke, New: A_arbace_g2a_print_code_param_list_A_new, Get: A_arbace_g2a_print_code_param_list_A_get}

var A_arbace_g2a_print_code_param_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$param_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "param_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_param_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_param_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_param_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_param_list_A_Init; i.Table = A_arbace_g2a_print_code_param_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_param_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_param_list_A]()) }

func A_arbace_g2a_print_code_param_list_fn__1022000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_param_list_fn__1022000087_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_param_list_fn__1022000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_param_list_fn__1022000087_A_New()}; return nil }

func A_arbace_g2a_print_code_param_list_fn__1022000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_param_list_fn__1022000087_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_param_list_fn__1022000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_param_list_fn__1022000087_A_invoke, New: A_arbace_g2a_print_code_param_list_fn__1022000087_A_new, Get: A_arbace_g2a_print_code_param_list_fn__1022000087_A_get}

var A_arbace_g2a_print_code_param_list_fn__1022000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$param_list$fn__1022000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_param_list_A_class, Simple: "fn__1022000087", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_param_list_fn__1022000087_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_param_list_fn__1022000087_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_param_list_fn__1022000087_A_InstanceOf; i.Init = A_arbace_g2a_print_code_param_list_fn__1022000087_A_Init; i.Table = A_arbace_g2a_print_code_param_list_fn__1022000087_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_param_list_fn__1022000087_A_class, reflect.TypeFor[A_arbace_g2a_print_code_param_list_fn__1022000087_A]()) }

func A_arbace_g2a_print_code_paren_operand_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_paren_operand_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_paren_operand_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_paren_operand_A_New()}; return nil }

func A_arbace_g2a_print_code_paren_operand_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_paren_operand_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_paren_operand_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_paren_operand_A_invoke, New: A_arbace_g2a_print_code_paren_operand_A_new, Get: A_arbace_g2a_print_code_paren_operand_A_get}

var A_arbace_g2a_print_code_paren_operand_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$paren_operand", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "paren_operand", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_paren_operand_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_paren_operand_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_paren_operand_A_InstanceOf; i.Init = A_arbace_g2a_print_code_paren_operand_A_Init; i.Table = A_arbace_g2a_print_code_paren_operand_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_paren_operand_A_class, reflect.TypeFor[A_arbace_g2a_print_code_paren_operand_A]()) }

func A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_paren_operand_fn__1022000249_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_invoke, New: A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_new, Get: A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_get}

var A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$paren_operand$fn__1022000249", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_paren_operand_A_class, Simple: "fn__1022000249", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_paren_operand_fn__1022000249_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_InstanceOf; i.Init = A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_Init; i.Table = A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_paren_operand_fn__1022000249_A_class, reflect.TypeFor[A_arbace_g2a_print_code_paren_operand_fn__1022000249_A]()) }

func A_arbace_g2a_print_code_parse_decl_head_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_parse_decl_head_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_parse_decl_head_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_parse_decl_head_A_New()}; return nil }

func A_arbace_g2a_print_code_parse_decl_head_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_parse_decl_head_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_parse_decl_head_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_parse_decl_head_A_invoke, New: A_arbace_g2a_print_code_parse_decl_head_A_new, Get: A_arbace_g2a_print_code_parse_decl_head_A_get}

var A_arbace_g2a_print_code_parse_decl_head_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$parse_decl_head", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "parse_decl_head", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_parse_decl_head_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_parse_decl_head_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_parse_decl_head_A_InstanceOf; i.Init = A_arbace_g2a_print_code_parse_decl_head_A_Init; i.Table = A_arbace_g2a_print_code_parse_decl_head_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_parse_decl_head_A_class, reflect.TypeFor[A_arbace_g2a_print_code_parse_decl_head_A]()) }

func A_arbace_g2a_print_code_parse_type_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_parse_type_spec_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_parse_type_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_parse_type_spec_A_New()}; return nil }

func A_arbace_g2a_print_code_parse_type_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_parse_type_spec_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_parse_type_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_parse_type_spec_A_invoke, New: A_arbace_g2a_print_code_parse_type_spec_A_new, Get: A_arbace_g2a_print_code_parse_type_spec_A_get}

var A_arbace_g2a_print_code_parse_type_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$parse_type_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "parse_type_spec", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_parse_type_spec_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_parse_type_spec_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_parse_type_spec_A_InstanceOf; i.Init = A_arbace_g2a_print_code_parse_type_spec_A_Init; i.Table = A_arbace_g2a_print_code_parse_type_spec_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_parse_type_spec_A_class, reflect.TypeFor[A_arbace_g2a_print_code_parse_type_spec_A]()) }

func A_arbace_g2a_print_code_pre_lines_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_pre_lines_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_pre_lines_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_pre_lines_A_New()}; return nil }

func A_arbace_g2a_print_code_pre_lines_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_pre_lines_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_pre_lines_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_pre_lines_A_invoke, New: A_arbace_g2a_print_code_pre_lines_A_new, Get: A_arbace_g2a_print_code_pre_lines_A_get}

var A_arbace_g2a_print_code_pre_lines_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$pre_lines", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "pre_lines", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_pre_lines_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_pre_lines_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_pre_lines_A_InstanceOf; i.Init = A_arbace_g2a_print_code_pre_lines_A_Init; i.Table = A_arbace_g2a_print_code_pre_lines_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_pre_lines_A_class, reflect.TypeFor[A_arbace_g2a_print_code_pre_lines_A]()) }

func A_arbace_g2a_print_code_prec_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_prec_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_prec_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_prec_of_A_New()}; return nil }

func A_arbace_g2a_print_code_prec_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_prec_of_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_prec_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_prec_of_A_invoke, New: A_arbace_g2a_print_code_prec_of_A_new, Get: A_arbace_g2a_print_code_prec_of_A_get}

var A_arbace_g2a_print_code_prec_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$prec_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "prec_of", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_prec_of_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_prec_of_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_prec_of_A_InstanceOf; i.Init = A_arbace_g2a_print_code_prec_of_A_Init; i.Table = A_arbace_g2a_print_code_prec_of_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_prec_of_A_class, reflect.TypeFor[A_arbace_g2a_print_code_prec_of_A]()) }

func A_arbace_g2a_print_code_print_results_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_print_results_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_print_results_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_print_results_A_New()}; return nil }

func A_arbace_g2a_print_code_print_results_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_print_results_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_print_results_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_print_results_A_invoke, New: A_arbace_g2a_print_code_print_results_A_new, Get: A_arbace_g2a_print_code_print_results_A_get}

var A_arbace_g2a_print_code_print_results_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$print_results", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "print_results", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_print_results_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_print_results_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_print_results_A_InstanceOf; i.Init = A_arbace_g2a_print_code_print_results_A_Init; i.Table = A_arbace_g2a_print_code_print_results_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_print_results_A_class, reflect.TypeFor[A_arbace_g2a_print_code_print_results_A]()) }

func A_arbace_g2a_print_code_print_results_fn__1022000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_print_results_fn__1022000091_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_print_results_fn__1022000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_print_results_fn__1022000091_A_New()}; return nil }

func A_arbace_g2a_print_code_print_results_fn__1022000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_print_results_fn__1022000091_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_print_results_fn__1022000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_print_results_fn__1022000091_A_invoke, New: A_arbace_g2a_print_code_print_results_fn__1022000091_A_new, Get: A_arbace_g2a_print_code_print_results_fn__1022000091_A_get}

var A_arbace_g2a_print_code_print_results_fn__1022000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$print_results$fn__1022000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_print_results_A_class, Simple: "fn__1022000091", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_print_results_fn__1022000091_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_print_results_fn__1022000091_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_print_results_fn__1022000091_A_InstanceOf; i.Init = A_arbace_g2a_print_code_print_results_fn__1022000091_A_Init; i.Table = A_arbace_g2a_print_code_print_results_fn__1022000091_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_print_results_fn__1022000091_A_class, reflect.TypeFor[A_arbace_g2a_print_code_print_results_fn__1022000091_A]()) }

func A_arbace_g2a_print_code_print_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_print_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_print_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_print_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_print_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_print_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_print_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_print_stmt_A_invoke, New: A_arbace_g2a_print_code_print_stmt_A_new, Get: A_arbace_g2a_print_code_print_stmt_A_get}

var A_arbace_g2a_print_code_print_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$print_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "print_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_print_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_print_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_print_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_print_stmt_A_Init; i.Table = A_arbace_g2a_print_code_print_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_print_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_print_stmt_A]()) }

func A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_print_stmt_fn__1022000500_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_New()}; return nil }

func A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_invoke, New: A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_new, Get: A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_get}

var A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$print_stmt$fn__1022000500", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_print_stmt_A_class, Simple: "fn__1022000500", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_print_stmt_fn__1022000500_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_InstanceOf; i.Init = A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_Init; i.Table = A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_print_stmt_fn__1022000500_A_class, reflect.TypeFor[A_arbace_g2a_print_code_print_stmt_fn__1022000500_A]()) }

func A_arbace_g2a_print_code_range_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_range_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_range_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_range_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_range_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_range_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_range_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_range_stmt_A_invoke, New: A_arbace_g2a_print_code_range_stmt_A_new, Get: A_arbace_g2a_print_code_range_stmt_A_get}

var A_arbace_g2a_print_code_range_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$range_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "range_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_range_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_range_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_range_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_range_stmt_A_Init; i.Table = A_arbace_g2a_print_code_range_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_range_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_range_stmt_A]()) }

func A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_range_stmt_fn__1022000493_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_invoke, New: A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_new, Get: A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_get}

var A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$range_stmt$fn__1022000493", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_range_stmt_A_class, Simple: "fn__1022000493", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_range_stmt_fn__1022000493_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_InstanceOf; i.Init = A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_Init; i.Table = A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_class, reflect.TypeFor[A_arbace_g2a_print_code_range_stmt_fn__1022000493_A]()) }

func A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_New()}; return nil }

func A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_invoke, New: A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_new, Get: A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_get}

var A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$range_stmt$fn__1022000493$fn__1022000494", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_range_stmt_fn__1022000493_A_class, Simple: "fn__1022000494", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_InstanceOf; i.Init = A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_Init; i.Table = A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A_class, reflect.TypeFor[A_arbace_g2a_print_code_range_stmt_fn__1022000493_fn__1022000494_A]()) }

func A_arbace_g2a_print_code_reduce_depth_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_reduce_depth_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_reduce_depth_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_reduce_depth_A_New()}; return nil }

func A_arbace_g2a_print_code_reduce_depth_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_reduce_depth_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_reduce_depth_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_reduce_depth_A_invoke, New: A_arbace_g2a_print_code_reduce_depth_A_new, Get: A_arbace_g2a_print_code_reduce_depth_A_get}

var A_arbace_g2a_print_code_reduce_depth_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$reduce_depth", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "reduce_depth", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_reduce_depth_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_reduce_depth_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_reduce_depth_A_InstanceOf; i.Init = A_arbace_g2a_print_code_reduce_depth_A_Init; i.Table = A_arbace_g2a_print_code_reduce_depth_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_reduce_depth_A_class, reflect.TypeFor[A_arbace_g2a_print_code_reduce_depth_A]()) }

func A_arbace_g2a_print_code_results_entries_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_results_entries_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_results_entries_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_results_entries_A_New()}; return nil }

func A_arbace_g2a_print_code_results_entries_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_results_entries_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_results_entries_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_results_entries_A_invoke, New: A_arbace_g2a_print_code_results_entries_A_new, Get: A_arbace_g2a_print_code_results_entries_A_get}

var A_arbace_g2a_print_code_results_entries_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$results_entries", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "results_entries", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_results_entries_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_results_entries_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_results_entries_A_InstanceOf; i.Init = A_arbace_g2a_print_code_results_entries_A_Init; i.Table = A_arbace_g2a_print_code_results_entries_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_results_entries_A_class, reflect.TypeFor[A_arbace_g2a_print_code_results_entries_A]()) }

func A_arbace_g2a_print_code_room_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_room_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_room_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_room_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_room_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_room_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_room_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_room_QMARK__A_invoke, New: A_arbace_g2a_print_code_room_QMARK__A_new, Get: A_arbace_g2a_print_code_room_QMARK__A_get}

var A_arbace_g2a_print_code_room_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$room_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "room_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_room_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_room_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_room_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_room_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_room_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_room_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_room_QMARK__A]()) }

func A_arbace_g2a_print_code_select_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_select_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_select_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_select_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_select_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_select_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_select_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_select_stmt_A_invoke, New: A_arbace_g2a_print_code_select_stmt_A_new, Get: A_arbace_g2a_print_code_select_stmt_A_get}

var A_arbace_g2a_print_code_select_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$select_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "select_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_select_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_select_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_select_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_select_stmt_A_Init; i.Table = A_arbace_g2a_print_code_select_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_select_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_select_stmt_A]()) }

func A_arbace_g2a_print_code_signature_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_signature_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_signature_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_signature_A_New()}; return nil }

func A_arbace_g2a_print_code_signature_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_signature_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_signature_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_signature_A_invoke, New: A_arbace_g2a_print_code_signature_A_new, Get: A_arbace_g2a_print_code_signature_A_get}

var A_arbace_g2a_print_code_signature_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$signature", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "signature", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_signature_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_signature_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_signature_A_InstanceOf; i.Init = A_arbace_g2a_print_code_signature_A_Init; i.Table = A_arbace_g2a_print_code_signature_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_signature_A_class, reflect.TypeFor[A_arbace_g2a_print_code_signature_A]()) }

func A_arbace_g2a_print_code_simple_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_simple_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_simple_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_simple_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_simple_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_simple_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_simple_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_simple_stmt_A_invoke, New: A_arbace_g2a_print_code_simple_stmt_A_new, Get: A_arbace_g2a_print_code_simple_stmt_A_get}

var A_arbace_g2a_print_code_simple_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$simple_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "simple_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_simple_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_simple_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_simple_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_simple_stmt_A_Init; i.Table = A_arbace_g2a_print_code_simple_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_simple_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_simple_stmt_A]()) }

func A_arbace_g2a_print_code_slice_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_slice_expr_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_slice_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_slice_expr_A_New()}; return nil }

func A_arbace_g2a_print_code_slice_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_slice_expr_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_slice_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_slice_expr_A_invoke, New: A_arbace_g2a_print_code_slice_expr_A_new, Get: A_arbace_g2a_print_code_slice_expr_A_get}

var A_arbace_g2a_print_code_slice_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$slice_expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "slice_expr", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_slice_expr_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_slice_expr_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_slice_expr_A_InstanceOf; i.Init = A_arbace_g2a_print_code_slice_expr_A_Init; i.Table = A_arbace_g2a_print_code_slice_expr_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_slice_expr_A_class, reflect.TypeFor[A_arbace_g2a_print_code_slice_expr_A]()) }

func A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_slice_expr_fn__1022000292_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_New()}; return nil }

func A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_invoke, New: A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_new, Get: A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_get}

var A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$slice_expr$fn__1022000292", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_slice_expr_A_class, Simple: "fn__1022000292", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_slice_expr_fn__1022000292_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_InstanceOf; i.Init = A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_Init; i.Table = A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_slice_expr_fn__1022000292_A_class, reflect.TypeFor[A_arbace_g2a_print_code_slice_expr_fn__1022000292_A]()) }

func A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_slice_expr_fn__1022000294_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_invoke, New: A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_new, Get: A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_get}

var A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$slice_expr$fn__1022000294", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_slice_expr_A_class, Simple: "fn__1022000294", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_slice_expr_fn__1022000294_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_InstanceOf; i.Init = A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_Init; i.Table = A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_slice_expr_fn__1022000294_A_class, reflect.TypeFor[A_arbace_g2a_print_code_slice_expr_fn__1022000294_A]()) }

func A_arbace_g2a_print_code_spec_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_spec_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_spec_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_spec_name_A_New()}; return nil }

func A_arbace_g2a_print_code_spec_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_spec_name_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_spec_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_spec_name_A_invoke, New: A_arbace_g2a_print_code_spec_name_A_new, Get: A_arbace_g2a_print_code_spec_name_A_get}

var A_arbace_g2a_print_code_spec_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$spec_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "spec_name", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_spec_name_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_spec_name_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_spec_name_A_InstanceOf; i.Init = A_arbace_g2a_print_code_spec_name_A_Init; i.Table = A_arbace_g2a_print_code_spec_name_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_spec_name_A_class, reflect.TypeFor[A_arbace_g2a_print_code_spec_name_A]()) }

func A_arbace_g2a_print_code_spec_t_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_spec_t_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_spec_t_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_spec_t_A_New()}; return nil }

func A_arbace_g2a_print_code_spec_t_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_spec_t_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_spec_t_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_spec_t_A_invoke, New: A_arbace_g2a_print_code_spec_t_A_new, Get: A_arbace_g2a_print_code_spec_t_A_get}

var A_arbace_g2a_print_code_spec_t_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$spec_t", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "spec_t", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_spec_t_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_spec_t_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_spec_t_A_InstanceOf; i.Init = A_arbace_g2a_print_code_spec_t_A_Init; i.Table = A_arbace_g2a_print_code_spec_t_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_spec_t_A_class, reflect.TypeFor[A_arbace_g2a_print_code_spec_t_A]()) }

func A_arbace_g2a_print_code_statement_form_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_statement_form_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_statement_form_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_statement_form_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_statement_form_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_statement_form_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_statement_form_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_statement_form_QMARK__A_invoke, New: A_arbace_g2a_print_code_statement_form_QMARK__A_new, Get: A_arbace_g2a_print_code_statement_form_QMARK__A_get}

var A_arbace_g2a_print_code_statement_form_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$statement_form_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "statement_form_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_statement_form_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_statement_form_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_statement_form_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_statement_form_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_statement_form_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_statement_form_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_statement_form_QMARK__A]()) }

func A_arbace_g2a_print_code_stmt_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_stmt_list_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_stmt_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_stmt_list_A_New()}; return nil }

func A_arbace_g2a_print_code_stmt_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_stmt_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_stmt_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_stmt_list_A_invoke, New: A_arbace_g2a_print_code_stmt_list_A_new, Get: A_arbace_g2a_print_code_stmt_list_A_get}

var A_arbace_g2a_print_code_stmt_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$stmt_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "stmt_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_stmt_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_stmt_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_stmt_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_stmt_list_A_Init; i.Table = A_arbace_g2a_print_code_stmt_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_stmt_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_stmt_list_A]()) }

func A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_stmt_list_fn__1022000550_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_New_I_O_O_J_O(args[0].(int32), args[1], args[2], args[3].(int64), args[4])}; return nil }

func A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;JLjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_invoke, New: A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_new, Get: A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_get}

var A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$stmt_list$fn__1022000550", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_stmt_list_A_class, Simple: "fn__1022000550", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_stmt_list_fn__1022000550_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_InstanceOf; i.Init = A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_Init; i.Table = A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_stmt_list_fn__1022000550_A_class, reflect.TypeFor[A_arbace_g2a_print_code_stmt_list_fn__1022000550_A]()) }

func A_arbace_g2a_print_code_stmt_list_one_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_stmt_list_one_line_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_stmt_list_one_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_stmt_list_one_line_A_New()}; return nil }

func A_arbace_g2a_print_code_stmt_list_one_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_stmt_list_one_line_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_stmt_list_one_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_stmt_list_one_line_A_invoke, New: A_arbace_g2a_print_code_stmt_list_one_line_A_new, Get: A_arbace_g2a_print_code_stmt_list_one_line_A_get}

var A_arbace_g2a_print_code_stmt_list_one_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$stmt_list_one_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "stmt_list_one_line", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_stmt_list_one_line_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_stmt_list_one_line_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_stmt_list_one_line_A_InstanceOf; i.Init = A_arbace_g2a_print_code_stmt_list_one_line_A_Init; i.Table = A_arbace_g2a_print_code_stmt_list_one_line_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_stmt_list_one_line_A_class, reflect.TypeFor[A_arbace_g2a_print_code_stmt_list_one_line_A]()) }

func A_arbace_g2a_print_code_struct_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_struct_fields_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_struct_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_struct_fields_A_New()}; return nil }

func A_arbace_g2a_print_code_struct_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_struct_fields_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_struct_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_struct_fields_A_invoke, New: A_arbace_g2a_print_code_struct_fields_A_new, Get: A_arbace_g2a_print_code_struct_fields_A_get}

var A_arbace_g2a_print_code_struct_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$struct_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "struct_fields", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_struct_fields_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_struct_fields_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_struct_fields_A_InstanceOf; i.Init = A_arbace_g2a_print_code_struct_fields_A_Init; i.Table = A_arbace_g2a_print_code_struct_fields_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_struct_fields_A_class, reflect.TypeFor[A_arbace_g2a_print_code_struct_fields_A]()) }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_New()}; return nil }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_invoke, New: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_new, Get: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_get}

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_struct_fields_A_class, Simple: "iter__1022000141__1022000145", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_InstanceOf; i.Init = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_Init; i.Table = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_class, reflect.TypeFor[A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A]()) }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_invoke, New: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_new, Get: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_get}

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145$fn__1022000146", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_A_class, Simple: "fn__1022000146", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_InstanceOf; i.Init = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_Init; i.Table = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_class, reflect.TypeFor[A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A]()) }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_invoke, New: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_new, Get: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_get}

var A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$struct_fields$iter__1022000141__1022000145$fn__1022000146$fn__1022000147", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_A_class, Simple: "fn__1022000147", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_InstanceOf; i.Init = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_Init; i.Table = A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A_class, reflect.TypeFor[A_arbace_g2a_print_code_struct_fields_iter__1022000141__1022000145_fn__1022000146_fn__1022000147_A]()) }

func A_arbace_g2a_print_code_struct_tag_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_struct_tag_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_struct_tag_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_struct_tag_A_New()}; return nil }

func A_arbace_g2a_print_code_struct_tag_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_struct_tag_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_struct_tag_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_struct_tag_A_invoke, New: A_arbace_g2a_print_code_struct_tag_A_new, Get: A_arbace_g2a_print_code_struct_tag_A_get}

var A_arbace_g2a_print_code_struct_tag_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$struct_tag", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "struct_tag", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_struct_tag_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_struct_tag_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_struct_tag_A_InstanceOf; i.Init = A_arbace_g2a_print_code_struct_tag_A_Init; i.Table = A_arbace_g2a_print_code_struct_tag_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_struct_tag_A_class, reflect.TypeFor[A_arbace_g2a_print_code_struct_tag_A]()) }

func A_arbace_g2a_print_code_switch_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_switch_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_switch_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_switch_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_switch_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_switch_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_switch_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_switch_stmt_A_invoke, New: A_arbace_g2a_print_code_switch_stmt_A_new, Get: A_arbace_g2a_print_code_switch_stmt_A_get}

var A_arbace_g2a_print_code_switch_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$switch_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "switch_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_switch_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_switch_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_switch_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_switch_stmt_A_Init; i.Table = A_arbace_g2a_print_code_switch_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_switch_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_switch_stmt_A]()) }

func A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_invoke, New: A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_new, Get: A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_get}

var A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$switch_stmt$fn__1022000459", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_switch_stmt_A_class, Simple: "fn__1022000459", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_InstanceOf; i.Init = A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_Init; i.Table = A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A_class, reflect.TypeFor[A_arbace_g2a_print_code_switch_stmt_fn__1022000459_A]()) }

func A_arbace_g2a_print_code_tagged_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_tagged_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_tagged_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_tagged_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_tagged_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_tagged_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_tagged_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_tagged_QMARK__A_invoke, New: A_arbace_g2a_print_code_tagged_QMARK__A_new, Get: A_arbace_g2a_print_code_tagged_QMARK__A_get}

var A_arbace_g2a_print_code_tagged_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$tagged_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "tagged_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_tagged_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_tagged_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_tagged_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_tagged_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_tagged_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_tagged_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_tagged_QMARK__A]()) }

func A_arbace_g2a_print_code_targets_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_targets_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_targets_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_targets_A_New()}; return nil }

func A_arbace_g2a_print_code_targets_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_targets_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_targets_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_targets_A_invoke, New: A_arbace_g2a_print_code_targets_A_new, Get: A_arbace_g2a_print_code_targets_A_get}

var A_arbace_g2a_print_code_targets_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$targets", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "targets", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_targets_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_targets_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_targets_A_InstanceOf; i.Init = A_arbace_g2a_print_code_targets_A_Init; i.Table = A_arbace_g2a_print_code_targets_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_targets_A_class, reflect.TypeFor[A_arbace_g2a_print_code_targets_A]()) }

func A_arbace_g2a_print_code_top_decl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_top_decl_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_top_decl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_top_decl_A_New()}; return nil }

func A_arbace_g2a_print_code_top_decl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_top_decl_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_top_decl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_top_decl_A_invoke, New: A_arbace_g2a_print_code_top_decl_A_new, Get: A_arbace_g2a_print_code_top_decl_A_get}

var A_arbace_g2a_print_code_top_decl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$top_decl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "top_decl", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_top_decl_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_top_decl_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_top_decl_A_InstanceOf; i.Init = A_arbace_g2a_print_code_top_decl_A_Init; i.Table = A_arbace_g2a_print_code_top_decl_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_top_decl_A_class, reflect.TypeFor[A_arbace_g2a_print_code_top_decl_A]()) }

func A_arbace_g2a_print_code_type_binding_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_binding_stmt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_type_binding_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_binding_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_type_binding_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_binding_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_binding_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_binding_stmt_A_invoke, New: A_arbace_g2a_print_code_type_binding_stmt_A_new, Get: A_arbace_g2a_print_code_type_binding_stmt_A_get}

var A_arbace_g2a_print_code_type_binding_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_binding_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_binding_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_binding_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_binding_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_binding_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_binding_stmt_A_Init; i.Table = A_arbace_g2a_print_code_type_binding_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_binding_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_binding_stmt_A]()) }

func A_arbace_g2a_print_code_type_decl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_decl_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_decl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_decl_A_New()}; return nil }

func A_arbace_g2a_print_code_type_decl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_decl_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_decl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_decl_A_invoke, New: A_arbace_g2a_print_code_type_decl_A_new, Get: A_arbace_g2a_print_code_type_decl_A_get}

var A_arbace_g2a_print_code_type_decl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_decl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_decl", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_decl_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_decl_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_decl_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_decl_A_Init; i.Table = A_arbace_g2a_print_code_type_decl_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_decl_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_decl_A]()) }

func A_arbace_g2a_print_code_type_decl_fn__1022000663_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_decl_fn__1022000663_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_type_decl_fn__1022000663_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_decl_fn__1022000663_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_type_decl_fn__1022000663_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_decl_fn__1022000663_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_decl_fn__1022000663_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_decl_fn__1022000663_A_invoke, New: A_arbace_g2a_print_code_type_decl_fn__1022000663_A_new, Get: A_arbace_g2a_print_code_type_decl_fn__1022000663_A_get}

var A_arbace_g2a_print_code_type_decl_fn__1022000663_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_decl$fn__1022000663", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_type_decl_A_class, Simple: "fn__1022000663", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_decl_fn__1022000663_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_decl_fn__1022000663_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_decl_fn__1022000663_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_decl_fn__1022000663_A_Init; i.Table = A_arbace_g2a_print_code_type_decl_fn__1022000663_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_decl_fn__1022000663_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_decl_fn__1022000663_A]()) }

func A_arbace_g2a_print_code_type_decl_fn__1022000668_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_decl_fn__1022000668_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_decl_fn__1022000668_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_decl_fn__1022000668_A_New()}; return nil }

func A_arbace_g2a_print_code_type_decl_fn__1022000668_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_decl_fn__1022000668_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_decl_fn__1022000668_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_decl_fn__1022000668_A_invoke, New: A_arbace_g2a_print_code_type_decl_fn__1022000668_A_new, Get: A_arbace_g2a_print_code_type_decl_fn__1022000668_A_get}

var A_arbace_g2a_print_code_type_decl_fn__1022000668_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_decl$fn__1022000668", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_type_decl_A_class, Simple: "fn__1022000668", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_decl_fn__1022000668_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_decl_fn__1022000668_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_decl_fn__1022000668_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_decl_fn__1022000668_A_Init; i.Table = A_arbace_g2a_print_code_type_decl_fn__1022000668_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_decl_fn__1022000668_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_decl_fn__1022000668_A]()) }

func A_arbace_g2a_print_code_type_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_expr_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_expr_A_New()}; return nil }

func A_arbace_g2a_print_code_type_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_expr_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_expr_A_invoke, New: A_arbace_g2a_print_code_type_expr_A_new, Get: A_arbace_g2a_print_code_type_expr_A_get}

var A_arbace_g2a_print_code_type_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_expr", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_expr_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_expr_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_expr_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_expr_A_Init; i.Table = A_arbace_g2a_print_code_type_expr_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_expr_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_expr_A]()) }

func A_arbace_g2a_print_code_type_expr_fn__1022000198_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_expr_fn__1022000198_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_type_expr_fn__1022000198_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_expr_fn__1022000198_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_type_expr_fn__1022000198_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_expr_fn__1022000198_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_expr_fn__1022000198_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_expr_fn__1022000198_A_invoke, New: A_arbace_g2a_print_code_type_expr_fn__1022000198_A_new, Get: A_arbace_g2a_print_code_type_expr_fn__1022000198_A_get}

var A_arbace_g2a_print_code_type_expr_fn__1022000198_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_expr$fn__1022000198", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_type_expr_A_class, Simple: "fn__1022000198", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_expr_fn__1022000198_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_expr_fn__1022000198_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_expr_fn__1022000198_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_expr_fn__1022000198_A_Init; i.Table = A_arbace_g2a_print_code_type_expr_fn__1022000198_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_expr_fn__1022000198_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_expr_fn__1022000198_A]()) }

func A_arbace_g2a_print_code_type_form_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_form_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_form_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_form_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_type_form_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_form_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_form_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_form_QMARK__A_invoke, New: A_arbace_g2a_print_code_type_form_QMARK__A_new, Get: A_arbace_g2a_print_code_type_form_QMARK__A_get}

var A_arbace_g2a_print_code_type_form_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_form_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_form_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_form_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_form_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_form_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_form_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_type_form_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_form_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_form_QMARK__A]()) }

func A_arbace_g2a_print_code_type_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_list_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_list_A_New()}; return nil }

func A_arbace_g2a_print_code_type_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_list_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_list_A_invoke, New: A_arbace_g2a_print_code_type_list_A_new, Get: A_arbace_g2a_print_code_type_list_A_get}

var A_arbace_g2a_print_code_type_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_list", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_list_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_list_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_list_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_list_A_Init; i.Table = A_arbace_g2a_print_code_type_list_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_list_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_list_A]()) }

func A_arbace_g2a_print_code_type_list_fn__1022000188_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_list_fn__1022000188_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_type_list_fn__1022000188_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_list_fn__1022000188_A_New()}; return nil }

func A_arbace_g2a_print_code_type_list_fn__1022000188_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_list_fn__1022000188_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_list_fn__1022000188_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_list_fn__1022000188_A_invoke, New: A_arbace_g2a_print_code_type_list_fn__1022000188_A_new, Get: A_arbace_g2a_print_code_type_list_fn__1022000188_A_get}

var A_arbace_g2a_print_code_type_list_fn__1022000188_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_list$fn__1022000188", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_type_list_A_class, Simple: "fn__1022000188", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_list_fn__1022000188_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_list_fn__1022000188_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_list_fn__1022000188_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_list_fn__1022000188_A_Init; i.Table = A_arbace_g2a_print_code_type_list_fn__1022000188_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_list_fn__1022000188_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_list_fn__1022000188_A]()) }

func A_arbace_g2a_print_code_type_params_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_params_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_params_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_params_A_New()}; return nil }

func A_arbace_g2a_print_code_type_params_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_params_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_params_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_params_A_invoke, New: A_arbace_g2a_print_code_type_params_A_new, Get: A_arbace_g2a_print_code_type_params_A_get}

var A_arbace_g2a_print_code_type_params_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_params", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_params", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_params_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_params_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_params_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_params_A_Init; i.Table = A_arbace_g2a_print_code_type_params_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_params_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_params_A]()) }

func A_arbace_g2a_print_code_type_params_fn__1022000216_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_params_fn__1022000216_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_params_fn__1022000216_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_params_fn__1022000216_A_New()}; return nil }

func A_arbace_g2a_print_code_type_params_fn__1022000216_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_params_fn__1022000216_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_params_fn__1022000216_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_params_fn__1022000216_A_invoke, New: A_arbace_g2a_print_code_type_params_fn__1022000216_A_new, Get: A_arbace_g2a_print_code_type_params_fn__1022000216_A_get}

var A_arbace_g2a_print_code_type_params_fn__1022000216_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_params$fn__1022000216", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_type_params_A_class, Simple: "fn__1022000216", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_params_fn__1022000216_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_params_fn__1022000216_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_params_fn__1022000216_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_params_fn__1022000216_A_Init; i.Table = A_arbace_g2a_print_code_type_params_fn__1022000216_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_params_fn__1022000216_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_params_fn__1022000216_A]()) }

func A_arbace_g2a_print_code_type_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_spec_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_type_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_spec_A_New()}; return nil }

func A_arbace_g2a_print_code_type_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_spec_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_spec_A_invoke, New: A_arbace_g2a_print_code_type_spec_A_new, Get: A_arbace_g2a_print_code_type_spec_A_get}

var A_arbace_g2a_print_code_type_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_spec", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_spec_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_spec_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_spec_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_spec_A_Init; i.Table = A_arbace_g2a_print_code_type_spec_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_spec_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_spec_A]()) }

func A_arbace_g2a_print_code_type_switch_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_switch_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_switch_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_switch_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_type_switch_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_switch_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_switch_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_switch_stmt_A_invoke, New: A_arbace_g2a_print_code_type_switch_stmt_A_new, Get: A_arbace_g2a_print_code_type_switch_stmt_A_get}

var A_arbace_g2a_print_code_type_switch_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_switch_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "type_switch_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_switch_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_switch_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_switch_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_switch_stmt_A_Init; i.Table = A_arbace_g2a_print_code_type_switch_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_switch_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_switch_stmt_A]()) }

func A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_invoke, New: A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_new, Get: A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_get}

var A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$type_switch_stmt$fn__1022000468", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_type_switch_stmt_A_class, Simple: "fn__1022000468", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_InstanceOf; i.Init = A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_Init; i.Table = A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A_class, reflect.TypeFor[A_arbace_g2a_print_code_type_switch_stmt_fn__1022000468_A]()) }

func A_arbace_g2a_print_code_unary_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_unary_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_unary_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_unary_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_unary_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_unary_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_unary_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_unary_QMARK__A_invoke, New: A_arbace_g2a_print_code_unary_QMARK__A_new, Get: A_arbace_g2a_print_code_unary_QMARK__A_get}

var A_arbace_g2a_print_code_unary_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$unary_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "unary_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_unary_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_unary_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_unary_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_unary_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_unary_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_unary_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_unary_QMARK__A]()) }

func A_arbace_g2a_print_code_unary_op_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_unary_op_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_unary_op_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_unary_op_A_New()}; return nil }

func A_arbace_g2a_print_code_unary_op_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_unary_op_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_unary_op_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_unary_op_A_invoke, New: A_arbace_g2a_print_code_unary_op_A_new, Get: A_arbace_g2a_print_code_unary_op_A_get}

var A_arbace_g2a_print_code_unary_op_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$unary_op", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "unary_op", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_unary_op_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_unary_op_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_unary_op_A_InstanceOf; i.Init = A_arbace_g2a_print_code_unary_op_A_Init; i.Table = A_arbace_g2a_print_code_unary_op_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_unary_op_A_class, reflect.TypeFor[A_arbace_g2a_print_code_unary_op_A]()) }

func A_arbace_g2a_print_code_unary_operand_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_unary_operand_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_unary_operand_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_unary_operand_A_New()}; return nil }

func A_arbace_g2a_print_code_unary_operand_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_unary_operand_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_unary_operand_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_unary_operand_A_invoke, New: A_arbace_g2a_print_code_unary_operand_A_new, Get: A_arbace_g2a_print_code_unary_operand_A_get}

var A_arbace_g2a_print_code_unary_operand_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$unary_operand", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "unary_operand", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_unary_operand_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_unary_operand_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_unary_operand_A_InstanceOf; i.Init = A_arbace_g2a_print_code_unary_operand_A_Init; i.Table = A_arbace_g2a_print_code_unary_operand_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_unary_operand_A_class, reflect.TypeFor[A_arbace_g2a_print_code_unary_operand_A]()) }

func A_arbace_g2a_print_code_uses_grouped_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_uses_grouped_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_uses_grouped_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_uses_grouped_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_uses_grouped_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_uses_grouped_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_uses_grouped_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_uses_grouped_QMARK__A_invoke, New: A_arbace_g2a_print_code_uses_grouped_QMARK__A_new, Get: A_arbace_g2a_print_code_uses_grouped_QMARK__A_get}

var A_arbace_g2a_print_code_uses_grouped_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$uses_grouped_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "uses_grouped_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_uses_grouped_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_uses_grouped_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_uses_grouped_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_uses_grouped_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_uses_grouped_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_uses_grouped_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_uses_grouped_QMARK__A]()) }

func A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_New()}; return nil }

func A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_invoke, New: A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_new, Get: A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_get}

var A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$uses_grouped_QMARK_$walk__1022000012", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_uses_grouped_QMARK__A_class, Simple: "walk__1022000012", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_InstanceOf; i.Init = A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_Init; i.Table = A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A_class, reflect.TypeFor[A_arbace_g2a_print_code_uses_grouped_QMARK__walk__1022000012_A]()) }

func A_arbace_g2a_print_code_value_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_value_spec_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_code_value_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_value_spec_A_New()}; return nil }

func A_arbace_g2a_print_code_value_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_value_spec_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_value_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_value_spec_A_invoke, New: A_arbace_g2a_print_code_value_spec_A_new, Get: A_arbace_g2a_print_code_value_spec_A_get}

var A_arbace_g2a_print_code_value_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$value_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "value_spec", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_value_spec_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_value_spec_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_value_spec_A_InstanceOf; i.Init = A_arbace_g2a_print_code_value_spec_A_Init; i.Table = A_arbace_g2a_print_code_value_spec_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_value_spec_A_class, reflect.TypeFor[A_arbace_g2a_print_code_value_spec_A]()) }

func A_arbace_g2a_print_code_value_spec_fn__1022000589_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_value_spec_fn__1022000589_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_value_spec_fn__1022000589_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_value_spec_fn__1022000589_A_New()}; return nil }

func A_arbace_g2a_print_code_value_spec_fn__1022000589_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_value_spec_fn__1022000589_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_value_spec_fn__1022000589_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_value_spec_fn__1022000589_A_invoke, New: A_arbace_g2a_print_code_value_spec_fn__1022000589_A_new, Get: A_arbace_g2a_print_code_value_spec_fn__1022000589_A_get}

var A_arbace_g2a_print_code_value_spec_fn__1022000589_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$value_spec$fn__1022000589", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_value_spec_A_class, Simple: "fn__1022000589", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_value_spec_fn__1022000589_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_value_spec_fn__1022000589_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_value_spec_fn__1022000589_A_InstanceOf; i.Init = A_arbace_g2a_print_code_value_spec_fn__1022000589_A_Init; i.Table = A_arbace_g2a_print_code_value_spec_fn__1022000589_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_value_spec_fn__1022000589_A_class, reflect.TypeFor[A_arbace_g2a_print_code_value_spec_fn__1022000589_A]()) }

func A_arbace_g2a_print_code_variadic_elem_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_variadic_elem_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_variadic_elem_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_variadic_elem_A_New()}; return nil }

func A_arbace_g2a_print_code_variadic_elem_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_variadic_elem_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_variadic_elem_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_variadic_elem_A_invoke, New: A_arbace_g2a_print_code_variadic_elem_A_new, Get: A_arbace_g2a_print_code_variadic_elem_A_get}

var A_arbace_g2a_print_code_variadic_elem_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$variadic_elem", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "variadic_elem", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_variadic_elem_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_variadic_elem_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_variadic_elem_A_InstanceOf; i.Init = A_arbace_g2a_print_code_variadic_elem_A_Init; i.Table = A_arbace_g2a_print_code_variadic_elem_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_variadic_elem_A_class, reflect.TypeFor[A_arbace_g2a_print_code_variadic_elem_A]()) }

func A_arbace_g2a_print_code_walk_binary_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_walk_binary_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_walk_binary_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_walk_binary_A_New()}; return nil }

func A_arbace_g2a_print_code_walk_binary_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_walk_binary_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_walk_binary_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_walk_binary_A_invoke, New: A_arbace_g2a_print_code_walk_binary_A_new, Get: A_arbace_g2a_print_code_walk_binary_A_get}

var A_arbace_g2a_print_code_walk_binary_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$walk_binary", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "walk_binary", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_walk_binary_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_walk_binary_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_walk_binary_A_InstanceOf; i.Init = A_arbace_g2a_print_code_walk_binary_A_Init; i.Table = A_arbace_g2a_print_code_walk_binary_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_walk_binary_A_class, reflect.TypeFor[A_arbace_g2a_print_code_walk_binary_A]()) }

func A_arbace_g2a_print_code_walk_prefixes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_walk_prefixes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_walk_prefixes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_walk_prefixes_A_New()}; return nil }

func A_arbace_g2a_print_code_walk_prefixes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_walk_prefixes_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_walk_prefixes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_walk_prefixes_A_invoke, New: A_arbace_g2a_print_code_walk_prefixes_A_new, Get: A_arbace_g2a_print_code_walk_prefixes_A_get}

var A_arbace_g2a_print_code_walk_prefixes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$walk_prefixes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "walk_prefixes", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_walk_prefixes_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_walk_prefixes_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_walk_prefixes_A_InstanceOf; i.Init = A_arbace_g2a_print_code_walk_prefixes_A_Init; i.Table = A_arbace_g2a_print_code_walk_prefixes_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_walk_prefixes_A_class, reflect.TypeFor[A_arbace_g2a_print_code_walk_prefixes_A]()) }

func A_arbace_g2a_print_code_walk_right_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_walk_right_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_walk_right_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_walk_right_A_New()}; return nil }

func A_arbace_g2a_print_code_walk_right_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_walk_right_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_walk_right_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_walk_right_A_invoke, New: A_arbace_g2a_print_code_walk_right_A_new, Get: A_arbace_g2a_print_code_walk_right_A_get}

var A_arbace_g2a_print_code_walk_right_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$walk_right", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "walk_right", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_walk_right_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_walk_right_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_walk_right_A_InstanceOf; i.Init = A_arbace_g2a_print_code_walk_right_A_Init; i.Table = A_arbace_g2a_print_code_walk_right_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_walk_right_A_class, reflect.TypeFor[A_arbace_g2a_print_code_walk_right_A]()) }

func A_arbace_g2a_print_code_while_stmt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_while_stmt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_while_stmt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_while_stmt_A_New()}; return nil }

func A_arbace_g2a_print_code_while_stmt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_while_stmt_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_while_stmt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_while_stmt_A_invoke, New: A_arbace_g2a_print_code_while_stmt_A_new, Get: A_arbace_g2a_print_code_while_stmt_A_get}

var A_arbace_g2a_print_code_while_stmt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$while_stmt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "while_stmt", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_while_stmt_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_while_stmt_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_while_stmt_A_InstanceOf; i.Init = A_arbace_g2a_print_code_while_stmt_A_Init; i.Table = A_arbace_g2a_print_code_while_stmt_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_while_stmt_A_class, reflect.TypeFor[A_arbace_g2a_print_code_while_stmt_A]()) }

func A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_while_stmt_fn__1022000486_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_invoke, New: A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_new, Get: A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_get}

var A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$while_stmt$fn__1022000486", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_code_while_stmt_A_class, Simple: "fn__1022000486", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_while_stmt_fn__1022000486_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_InstanceOf; i.Init = A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_Init; i.Table = A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_while_stmt_fn__1022000486_A_class, reflect.TypeFor[A_arbace_g2a_print_code_while_stmt_fn__1022000486_A]()) }

func A_arbace_g2a_print_code_write_doc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_write_doc_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_code_write_doc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_write_doc_A_New()}; return nil }

func A_arbace_g2a_print_code_write_doc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_write_doc_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_write_doc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_write_doc_A_invoke, New: A_arbace_g2a_print_code_write_doc_A_new, Get: A_arbace_g2a_print_code_write_doc_A_get}

var A_arbace_g2a_print_code_write_doc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$write_doc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "write_doc", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_write_doc_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_write_doc_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_write_doc_A_InstanceOf; i.Init = A_arbace_g2a_print_code_write_doc_A_Init; i.Table = A_arbace_g2a_print_code_write_doc_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_write_doc_A_class, reflect.TypeFor[A_arbace_g2a_print_code_write_doc_A]()) }

func A_arbace_g2a_print_code_write_pre_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_write_pre_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_code_write_pre_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_write_pre_A_New()}; return nil }

func A_arbace_g2a_print_code_write_pre_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_write_pre_A_fn_class)}; return nil }

var A_arbace_g2a_print_code_write_pre_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_write_pre_A_invoke, New: A_arbace_g2a_print_code_write_pre_A_new, Get: A_arbace_g2a_print_code_write_pre_A_get}

var A_arbace_g2a_print_code_write_pre_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$write_pre", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "write_pre", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_write_pre_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_write_pre_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_write_pre_A_InstanceOf; i.Init = A_arbace_g2a_print_code_write_pre_A_Init; i.Table = A_arbace_g2a_print_code_write_pre_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_write_pre_A_class, reflect.TypeFor[A_arbace_g2a_print_code_write_pre_A]()) }

func A_arbace_g2a_print_code_zero_form_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_code_zero_form_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_code_zero_form_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code_zero_form_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_code_zero_form_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_code_zero_form_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_code_zero_form_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_code_zero_form_QMARK__A_invoke, New: A_arbace_g2a_print_code_zero_form_QMARK__A_new, Get: A_arbace_g2a_print_code_zero_form_QMARK__A_get}

var A_arbace_g2a_print_code_zero_form_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code$zero_form_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_code_A_class, Simple: "zero_form_QMARK_", Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code_zero_form_QMARK__A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code_zero_form_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_code_zero_form_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_code_zero_form_QMARK__A_Init; i.Table = A_arbace_g2a_print_code_zero_form_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_code_zero_form_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_code_zero_form_QMARK__A]()) }

func A_arbace_g2a_print_code__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_print_code__init_A_Load__O(); case 1: return A_arbace_g2a_print_code__init_A_Unit0__O(); case 2: return A_arbace_g2a_print_code__init_A_Unit1__O(); case 3: return A_arbace_g2a_print_code__init_A_Unit10__O(); case 4: return A_arbace_g2a_print_code__init_A_Unit100__O(); case 5: return A_arbace_g2a_print_code__init_A_Unit101__O(); case 6: return A_arbace_g2a_print_code__init_A_Unit102__O(); case 7: return A_arbace_g2a_print_code__init_A_Unit103__O(); case 8: return A_arbace_g2a_print_code__init_A_Unit104__O(); case 9: return A_arbace_g2a_print_code__init_A_Unit105__O(); case 10: return A_arbace_g2a_print_code__init_A_Unit106__O(); case 11: return A_arbace_g2a_print_code__init_A_Unit107__O(); case 12: return A_arbace_g2a_print_code__init_A_Unit108__O(); case 13: return A_arbace_g2a_print_code__init_A_Unit109__O(); case 14: return A_arbace_g2a_print_code__init_A_Unit11__O(); case 15: return A_arbace_g2a_print_code__init_A_Unit110__O(); case 16: return A_arbace_g2a_print_code__init_A_Unit111__O(); case 17: return A_arbace_g2a_print_code__init_A_Unit112__O(); case 18: return A_arbace_g2a_print_code__init_A_Unit113__O(); case 19: return A_arbace_g2a_print_code__init_A_Unit114__O(); case 20: return A_arbace_g2a_print_code__init_A_Unit115__O(); case 21: return A_arbace_g2a_print_code__init_A_Unit116__O(); case 22: return A_arbace_g2a_print_code__init_A_Unit117__O(); case 23: return A_arbace_g2a_print_code__init_A_Unit118__O(); case 24: return A_arbace_g2a_print_code__init_A_Unit119__O(); case 25: return A_arbace_g2a_print_code__init_A_Unit12__O(); case 26: return A_arbace_g2a_print_code__init_A_Unit120__O(); case 27: return A_arbace_g2a_print_code__init_A_Unit121__O(); case 28: return A_arbace_g2a_print_code__init_A_Unit122__O(); case 29: return A_arbace_g2a_print_code__init_A_Unit123__O(); case 30: return A_arbace_g2a_print_code__init_A_Unit124__O(); case 31: return A_arbace_g2a_print_code__init_A_Unit125__O(); case 32: return A_arbace_g2a_print_code__init_A_Unit126__O(); case 33: return A_arbace_g2a_print_code__init_A_Unit127__O(); case 34: return A_arbace_g2a_print_code__init_A_Unit128__O(); case 35: return A_arbace_g2a_print_code__init_A_Unit129__O(); case 36: return A_arbace_g2a_print_code__init_A_Unit13__O(); case 37: return A_arbace_g2a_print_code__init_A_Unit130__O(); case 38: return A_arbace_g2a_print_code__init_A_Unit131__O(); case 39: return A_arbace_g2a_print_code__init_A_Unit132__O(); case 40: return A_arbace_g2a_print_code__init_A_Unit133__O(); case 41: return A_arbace_g2a_print_code__init_A_Unit134__O(); case 42: return A_arbace_g2a_print_code__init_A_Unit135__O(); case 43: return A_arbace_g2a_print_code__init_A_Unit136__O(); case 44: return A_arbace_g2a_print_code__init_A_Unit137__O(); case 45: return A_arbace_g2a_print_code__init_A_Unit138__O(); case 46: return A_arbace_g2a_print_code__init_A_Unit139__O(); case 47: return A_arbace_g2a_print_code__init_A_Unit14__O(); case 48: return A_arbace_g2a_print_code__init_A_Unit140__O(); case 49: return A_arbace_g2a_print_code__init_A_Unit141__O(); case 50: return A_arbace_g2a_print_code__init_A_Unit142__O(); case 51: return A_arbace_g2a_print_code__init_A_Unit143__O(); case 52: return A_arbace_g2a_print_code__init_A_Unit144__O(); case 53: return A_arbace_g2a_print_code__init_A_Unit145__O(); case 54: return A_arbace_g2a_print_code__init_A_Unit146__O(); case 55: return A_arbace_g2a_print_code__init_A_Unit147__O(); case 56: return A_arbace_g2a_print_code__init_A_Unit148__O(); case 57: return A_arbace_g2a_print_code__init_A_Unit149__O(); case 58: return A_arbace_g2a_print_code__init_A_Unit15__O(); case 59: return A_arbace_g2a_print_code__init_A_Unit150__O(); case 60: return A_arbace_g2a_print_code__init_A_Unit151__O(); case 61: return A_arbace_g2a_print_code__init_A_Unit152__O(); case 62: return A_arbace_g2a_print_code__init_A_Unit153__O(); case 63: return A_arbace_g2a_print_code__init_A_Unit154__O(); case 64: return A_arbace_g2a_print_code__init_A_Unit155__O(); case 65: return A_arbace_g2a_print_code__init_A_Unit156__O(); case 66: return A_arbace_g2a_print_code__init_A_Unit157__O(); case 67: return A_arbace_g2a_print_code__init_A_Unit158__O(); case 68: return A_arbace_g2a_print_code__init_A_Unit16__O(); case 69: return A_arbace_g2a_print_code__init_A_Unit17__O(); case 70: return A_arbace_g2a_print_code__init_A_Unit18__O(); case 71: return A_arbace_g2a_print_code__init_A_Unit19__O(); case 72: return A_arbace_g2a_print_code__init_A_Unit2__O(); case 73: return A_arbace_g2a_print_code__init_A_Unit20__O(); case 74: return A_arbace_g2a_print_code__init_A_Unit21__O(); case 75: return A_arbace_g2a_print_code__init_A_Unit22__O(); case 76: return A_arbace_g2a_print_code__init_A_Unit23__O(); case 77: return A_arbace_g2a_print_code__init_A_Unit24__O(); case 78: return A_arbace_g2a_print_code__init_A_Unit25__O(); case 79: return A_arbace_g2a_print_code__init_A_Unit26__O(); case 80: return A_arbace_g2a_print_code__init_A_Unit27__O(); case 81: return A_arbace_g2a_print_code__init_A_Unit28__O(); case 82: return A_arbace_g2a_print_code__init_A_Unit29__O(); case 83: return A_arbace_g2a_print_code__init_A_Unit3__O(); case 84: return A_arbace_g2a_print_code__init_A_Unit30__O(); case 85: return A_arbace_g2a_print_code__init_A_Unit31__O(); case 86: return A_arbace_g2a_print_code__init_A_Unit32__O(); case 87: return A_arbace_g2a_print_code__init_A_Unit33__O(); case 88: return A_arbace_g2a_print_code__init_A_Unit34__O(); case 89: return A_arbace_g2a_print_code__init_A_Unit35__O(); case 90: return A_arbace_g2a_print_code__init_A_Unit36__O(); case 91: return A_arbace_g2a_print_code__init_A_Unit37__O(); case 92: return A_arbace_g2a_print_code__init_A_Unit38__O(); case 93: return A_arbace_g2a_print_code__init_A_Unit39__O(); case 94: return A_arbace_g2a_print_code__init_A_Unit4__O(); case 95: return A_arbace_g2a_print_code__init_A_Unit40__O(); case 96: return A_arbace_g2a_print_code__init_A_Unit41__O(); case 97: return A_arbace_g2a_print_code__init_A_Unit42__O(); case 98: return A_arbace_g2a_print_code__init_A_Unit43__O(); case 99: return A_arbace_g2a_print_code__init_A_Unit44__O(); case 100: return A_arbace_g2a_print_code__init_A_Unit45__O(); case 101: return A_arbace_g2a_print_code__init_A_Unit46__O(); case 102: return A_arbace_g2a_print_code__init_A_Unit47__O(); case 103: return A_arbace_g2a_print_code__init_A_Unit48__O(); case 104: return A_arbace_g2a_print_code__init_A_Unit49__O(); case 105: return A_arbace_g2a_print_code__init_A_Unit5__O(); case 106: return A_arbace_g2a_print_code__init_A_Unit50__O(); case 107: return A_arbace_g2a_print_code__init_A_Unit51__O(); case 108: return A_arbace_g2a_print_code__init_A_Unit52__O(); case 109: return A_arbace_g2a_print_code__init_A_Unit53__O(); case 110: return A_arbace_g2a_print_code__init_A_Unit54__O(); case 111: return A_arbace_g2a_print_code__init_A_Unit55__O(); case 112: return A_arbace_g2a_print_code__init_A_Unit56__O(); case 113: return A_arbace_g2a_print_code__init_A_Unit57__O(); case 114: return A_arbace_g2a_print_code__init_A_Unit58__O(); case 115: return A_arbace_g2a_print_code__init_A_Unit59__O(); case 116: return A_arbace_g2a_print_code__init_A_Unit6__O(); case 117: return A_arbace_g2a_print_code__init_A_Unit60__O(); case 118: return A_arbace_g2a_print_code__init_A_Unit61__O(); case 119: return A_arbace_g2a_print_code__init_A_Unit62__O(); case 120: return A_arbace_g2a_print_code__init_A_Unit63__O(); case 121: return A_arbace_g2a_print_code__init_A_Unit64__O(); case 122: return A_arbace_g2a_print_code__init_A_Unit65__O(); case 123: return A_arbace_g2a_print_code__init_A_Unit66__O(); case 124: return A_arbace_g2a_print_code__init_A_Unit67__O(); case 125: return A_arbace_g2a_print_code__init_A_Unit68__O(); case 126: return A_arbace_g2a_print_code__init_A_Unit69__O(); case 127: return A_arbace_g2a_print_code__init_A_Unit7__O(); case 128: return A_arbace_g2a_print_code__init_A_Unit70__O(); case 129: return A_arbace_g2a_print_code__init_A_Unit71__O(); case 130: return A_arbace_g2a_print_code__init_A_Unit72__O(); case 131: return A_arbace_g2a_print_code__init_A_Unit73__O(); case 132: return A_arbace_g2a_print_code__init_A_Unit74__O(); case 133: return A_arbace_g2a_print_code__init_A_Unit75__O(); case 134: return A_arbace_g2a_print_code__init_A_Unit76__O(); case 135: return A_arbace_g2a_print_code__init_A_Unit77__O(); case 136: return A_arbace_g2a_print_code__init_A_Unit78__O(); case 137: return A_arbace_g2a_print_code__init_A_Unit79__O(); case 138: return A_arbace_g2a_print_code__init_A_Unit8__O(); case 139: return A_arbace_g2a_print_code__init_A_Unit80__O(); case 140: return A_arbace_g2a_print_code__init_A_Unit81__O(); case 141: return A_arbace_g2a_print_code__init_A_Unit82__O(); case 142: return A_arbace_g2a_print_code__init_A_Unit83__O(); case 143: return A_arbace_g2a_print_code__init_A_Unit84__O(); case 144: return A_arbace_g2a_print_code__init_A_Unit85__O(); case 145: return A_arbace_g2a_print_code__init_A_Unit86__O(); case 146: return A_arbace_g2a_print_code__init_A_Unit87__O(); case 147: return A_arbace_g2a_print_code__init_A_Unit88__O(); case 148: return A_arbace_g2a_print_code__init_A_Unit89__O(); case 149: return A_arbace_g2a_print_code__init_A_Unit9__O(); case 150: return A_arbace_g2a_print_code__init_A_Unit90__O(); case 151: return A_arbace_g2a_print_code__init_A_Unit91__O(); case 152: return A_arbace_g2a_print_code__init_A_Unit92__O(); case 153: return A_arbace_g2a_print_code__init_A_Unit93__O(); case 154: return A_arbace_g2a_print_code__init_A_Unit94__O(); case 155: return A_arbace_g2a_print_code__init_A_Unit95__O(); case 156: return A_arbace_g2a_print_code__init_A_Unit96__O(); case 157: return A_arbace_g2a_print_code__init_A_Unit97__O(); case 158: return A_arbace_g2a_print_code__init_A_Unit98__O(); case 159: return A_arbace_g2a_print_code__init_A_Unit99__O()}; return nil }

func A_arbace_g2a_print_code__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_code__init_A_New()}; return nil }

var A_arbace_g2a_print_code__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit100 ()Ljava.lang.Object;\nM9 unit101 ()Ljava.lang.Object;\nM9 unit102 ()Ljava.lang.Object;\nM9 unit103 ()Ljava.lang.Object;\nM9 unit104 ()Ljava.lang.Object;\nM9 unit105 ()Ljava.lang.Object;\nM9 unit106 ()Ljava.lang.Object;\nM9 unit107 ()Ljava.lang.Object;\nM9 unit108 ()Ljava.lang.Object;\nM9 unit109 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit110 ()Ljava.lang.Object;\nM9 unit111 ()Ljava.lang.Object;\nM9 unit112 ()Ljava.lang.Object;\nM9 unit113 ()Ljava.lang.Object;\nM9 unit114 ()Ljava.lang.Object;\nM9 unit115 ()Ljava.lang.Object;\nM9 unit116 ()Ljava.lang.Object;\nM9 unit117 ()Ljava.lang.Object;\nM9 unit118 ()Ljava.lang.Object;\nM9 unit119 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit120 ()Ljava.lang.Object;\nM9 unit121 ()Ljava.lang.Object;\nM9 unit122 ()Ljava.lang.Object;\nM9 unit123 ()Ljava.lang.Object;\nM9 unit124 ()Ljava.lang.Object;\nM9 unit125 ()Ljava.lang.Object;\nM9 unit126 ()Ljava.lang.Object;\nM9 unit127 ()Ljava.lang.Object;\nM9 unit128 ()Ljava.lang.Object;\nM9 unit129 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit130 ()Ljava.lang.Object;\nM9 unit131 ()Ljava.lang.Object;\nM9 unit132 ()Ljava.lang.Object;\nM9 unit133 ()Ljava.lang.Object;\nM9 unit134 ()Ljava.lang.Object;\nM9 unit135 ()Ljava.lang.Object;\nM9 unit136 ()Ljava.lang.Object;\nM9 unit137 ()Ljava.lang.Object;\nM9 unit138 ()Ljava.lang.Object;\nM9 unit139 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit140 ()Ljava.lang.Object;\nM9 unit141 ()Ljava.lang.Object;\nM9 unit142 ()Ljava.lang.Object;\nM9 unit143 ()Ljava.lang.Object;\nM9 unit144 ()Ljava.lang.Object;\nM9 unit145 ()Ljava.lang.Object;\nM9 unit146 ()Ljava.lang.Object;\nM9 unit147 ()Ljava.lang.Object;\nM9 unit148 ()Ljava.lang.Object;\nM9 unit149 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit150 ()Ljava.lang.Object;\nM9 unit151 ()Ljava.lang.Object;\nM9 unit152 ()Ljava.lang.Object;\nM9 unit153 ()Ljava.lang.Object;\nM9 unit154 ()Ljava.lang.Object;\nM9 unit155 ()Ljava.lang.Object;\nM9 unit156 ()Ljava.lang.Object;\nM9 unit157 ()Ljava.lang.Object;\nM9 unit158 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit75 ()Ljava.lang.Object;\nM9 unit76 ()Ljava.lang.Object;\nM9 unit77 ()Ljava.lang.Object;\nM9 unit78 ()Ljava.lang.Object;\nM9 unit79 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit80 ()Ljava.lang.Object;\nM9 unit81 ()Ljava.lang.Object;\nM9 unit82 ()Ljava.lang.Object;\nM9 unit83 ()Ljava.lang.Object;\nM9 unit84 ()Ljava.lang.Object;\nM9 unit85 ()Ljava.lang.Object;\nM9 unit86 ()Ljava.lang.Object;\nM9 unit87 ()Ljava.lang.Object;\nM9 unit88 ()Ljava.lang.Object;\nM9 unit89 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nM9 unit90 ()Ljava.lang.Object;\nM9 unit91 ()Ljava.lang.Object;\nM9 unit92 ()Ljava.lang.Object;\nM9 unit93 ()Ljava.lang.Object;\nM9 unit94 ()Ljava.lang.Object;\nM9 unit95 ()Ljava.lang.Object;\nM9 unit96 ()Ljava.lang.Object;\nM9 unit97 ()Ljava.lang.Object;\nM9 unit98 ()Ljava.lang.Object;\nM9 unit99 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_print_code__init_A_invoke, New: A_arbace_g2a_print_code__init_A_new}

var A_arbace_g2a_print_code__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_code__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_code.A_arbace_g2a_print_code__init_A", Source: "print_code.ae"})

func init() { i := A_arbace_g2a_print_code__init_A_class.Info(); i.IsInstance = A_arbace_g2a_print_code__init_A_InstanceOf; i.Init = A_arbace_g2a_print_code__init_A_Init; i.Table = A_arbace_g2a_print_code__init_A_members; jrt.RegisterGoType(A_arbace_g2a_print_code__init_A_class, reflect.TypeFor[A_arbace_g2a_print_code__init_A]()) }
