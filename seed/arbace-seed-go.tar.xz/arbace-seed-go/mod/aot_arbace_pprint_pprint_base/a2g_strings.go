//line a2g_strings.ae:1
package aot_arbace_pprint_pprint_base

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_3 *jrt.String = jrt.Intern("*print-pretty*")

var Lit_4 *jrt.String = jrt.Intern("doc")

var Lit_5 *jrt.String = jrt.Intern("Bind to true if you want write to use pretty printing")

var Lit_6 *jrt.String = jrt.Intern("added")

var Lit_7 *jrt.String = jrt.Intern("1.2")

var Lit_8 *jrt.String = jrt.Intern("dynamic")

var Lit_9 *jrt.String = jrt.Intern("line")

var Lit_10 *jrt.String = jrt.Intern("column")

var Lit_11 *jrt.String = jrt.Intern("file")

var Lit_12 *jrt.String = jrt.Intern("arbace/pprint/pprint_base.ae")

var Lit_13 *jrt.String = jrt.Intern("*print-pprint-dispatch*")

var Lit_14 *jrt.String = jrt.Intern("The pretty print dispatch function. Use with-pprint-dispatch or set-pprint-dispatch\nto modify.")

var Lit_15 *jrt.String = jrt.Intern("*print-right-margin*")

var Lit_16 *jrt.String = jrt.Intern("Pretty printing will try to avoid anything going beyond this column.\nSet it to nil to have pprint let the line be arbitrarily long. This will ignore all\nnon-mandatory newlines.")

var Lit_17 *jrt.String = jrt.Intern("*print-miser-width*")

var Lit_18 *jrt.String = jrt.Intern("The column at which to enter miser style. Depending on the dispatch table,\nmiser style add newlines in more places to try to keep lines short allowing for further\nlevels of nesting.")

var Lit_19 *jrt.String = jrt.Intern("*print-lines*")

var Lit_20 *jrt.String = jrt.Intern("private")

var Lit_21 *jrt.String = jrt.Intern("Maximum number of lines to print in a pretty print instance (N.B. This is not yet used)")

var Lit_22 *jrt.String = jrt.Intern("*print-circle*")

var Lit_23 *jrt.String = jrt.Intern("Mark circular structures (N.B. This is not yet used)")

var Lit_24 *jrt.String = jrt.Intern("*print-shared*")

var Lit_25 *jrt.String = jrt.Intern("Mark repeated structures rather than repeat them (N.B. This is not yet used)")

var Lit_26 *jrt.String = jrt.Intern("*print-suppress-namespaces*")

var Lit_27 *jrt.String = jrt.Intern("Don't print namespaces with symbols. This is particularly useful when\npretty printing the results of macro expansions")

var Lit_28 *jrt.String = jrt.Intern("*print-radix*")

var Lit_29 *jrt.String = jrt.Intern("Print a radix specifier in front of integers and rationals. If *print-base* is 2, 8,\nor 16, then the radix specifier used is #b, #o, or #x, respectively. Otherwise the\nradix specifier is in the form #XXr where XX is the decimal value of *print-base* ")

var Lit_30 *jrt.String = jrt.Intern("*print-base*")

var Lit_31 *jrt.String = jrt.Intern("The base to use for printing integers and rationals.")

var Lit_32 *jrt.String = jrt.Intern("*current-level*")

var Lit_33 *jrt.String = jrt.Intern("*current-length*")

var Lit_34 *jrt.String = jrt.Intern("format-simple-number")

var Lit_35 *jrt.String = jrt.Intern("declared")

var Lit_36 *jrt.String = jrt.Intern("orig-pr")

var Lit_37 *jrt.String = jrt.Intern("pr")

var Lit_38 *jrt.String = jrt.Intern("pr-with-base")

var Lit_39 *jrt.String = jrt.Intern("arglists")

var Lit_40 *jrt.String = jrt.Intern("x")

var Lit_41 *jrt.String = jrt.Intern("write-option-table")

var Lit_42 *jrt.String = jrt.Intern("base")

var Lit_43 *jrt.String = jrt.Intern("circle")

var Lit_44 *jrt.String = jrt.Intern("length")

var Lit_45 *jrt.String = jrt.Intern("*print-length*")

var Lit_46 *jrt.String = jrt.Intern("level")

var Lit_47 *jrt.String = jrt.Intern("*print-level*")

var Lit_48 *jrt.String = jrt.Intern("lines")

var Lit_49 *jrt.String = jrt.Intern("miser-width")

var Lit_50 *jrt.String = jrt.Intern("dispatch")

var Lit_51 *jrt.String = jrt.Intern("pretty")

var Lit_52 *jrt.String = jrt.Intern("radix")

var Lit_53 *jrt.String = jrt.Intern("readably")

var Lit_54 *jrt.String = jrt.Intern("*print-readably*")

var Lit_55 *jrt.String = jrt.Intern("right-margin")

var Lit_56 *jrt.String = jrt.Intern("suppress-namespaces")

var Lit_57 *jrt.String = jrt.Intern("binding-map")

var Lit_58 *jrt.String = jrt.Intern("amap")

var Lit_59 *jrt.String = jrt.Intern("&")

var Lit_60 *jrt.String = jrt.Intern("body")

var Lit_61 *jrt.String = jrt.Intern("table-ize")

var Lit_62 *jrt.String = jrt.Intern("t")

var Lit_63 *jrt.String = jrt.Intern("m")

var Lit_64 *jrt.String = jrt.Intern("pretty-writer?")

var Lit_65 *jrt.String = jrt.Intern("Return true iff x is a PrettyWriter")

var Lit_66 *jrt.String = jrt.Intern("make-pretty-writer")

var Lit_67 *jrt.String = jrt.Intern("base-writer")

var Lit_68 *jrt.String = jrt.Intern("Wrap base-writer in a PrettyWriter with the specified right-margin and miser-width")

var Lit_69 *jrt.String = jrt.Intern("with-pretty-writer")

var Lit_70 *jrt.String = jrt.Intern("write-out")

var Lit_71 *jrt.String = jrt.Intern("object")

var Lit_72 *jrt.String = jrt.Intern("Write an object to *out* subject to the current bindings of the printer control\nvariables. Use the kw-args argument to override individual variables for this call (and\nany recursive calls).\n\n*out* must be a PrettyWriter if pretty printing is enabled. This is the responsibility\nof the caller.\n\nThis method is primarily intended for use by pretty print dispatch functions that\nalready know that the pretty printer will have set up their environment appropriately.\nNormal library clients should use the standard \"write\" interface. ")

var Lit_73 *jrt.String = jrt.Intern("write")

var Lit_74 *jrt.String = jrt.Intern("kw-args")

var Lit_75 *jrt.String = jrt.Intern("Write an object subject to the current bindings of the printer control variables.\nUse the kw-args argument to override individual variables for this call (and any\nrecursive calls). Returns the string result if :stream is nil or nil otherwise.\n\nThe following keyword arguments can be passed with values:\n  Keyword              Meaning                              Default value\n  :stream              Writer for output or nil             true (indicates *out*)\n  :base                Base to use for writing rationals    Current value of *print-base*\n  :circle*             If true, mark circular structures    Current value of *print-circle*\n  :length              Maximum elements to show in sublists Current value of *print-length*\n  :level               Maximum depth                        Current value of *print-level*\n  :lines*              Maximum lines of output              Current value of *print-lines*\n  :miser-width         Width to enter miser mode            Current value of *print-miser-width*\n  :dispatch            The pretty print dispatch function   Current value of *print-pprint-dispatch*\n  :pretty              If true, do pretty printing          Current value of *print-pretty*\n  :radix               If true, prepend a radix specifier   Current value of *print-radix*\n  :readably*           If true, print readably              Current value of *print-readably*\n  :right-margin        The column for the right margin      Current value of *print-right-margin*\n  :suppress-namespaces If true, no namespaces in symbols    Current value of *print-suppress-namespaces*\n\n  * = not yet supported\n")

var Lit_76 *jrt.String = jrt.Intern("pprint")

var Lit_77 *jrt.String = jrt.Intern("writer")

var Lit_78 *jrt.String = jrt.Intern("Pretty print object to the optional output writer. If the writer is not provided,\nprint the object to the currently bound value of *out*.")

var Lit_79 *jrt.String = jrt.Intern("pp")

var Lit_80 *jrt.String = jrt.Intern("A convenience macro that pretty prints the last thing output. This is\nexactly equivalent to (pprint *1).")

var Lit_81 *jrt.String = jrt.Intern("set-pprint-dispatch")

var Lit_82 *jrt.String = jrt.Intern("function")

var Lit_83 *jrt.String = jrt.Intern("Set the pretty print dispatch function to a function matching (fn [obj] ...)\nwhere obj is the object to pretty print. That function will be called with *out* set\nto a pretty printing writer to which it should do its printing.\n\nFor example functions, see simple-dispatch and code-dispatch in\nclojure.pprint.dispatch.clj.")

var Lit_84 *jrt.String = jrt.Intern("with-pprint-dispatch")

var Lit_85 *jrt.String = jrt.Intern("Execute body with the pretty print dispatch function bound to function.")

var Lit_86 *jrt.String = jrt.Intern("parse-lb-options")

var Lit_87 *jrt.String = jrt.Intern("opts")

var Lit_88 *jrt.String = jrt.Intern("check-enumerated-arg")

var Lit_89 *jrt.String = jrt.Intern("arg")

var Lit_90 *jrt.String = jrt.Intern("choices")

var Lit_91 *jrt.String = jrt.Intern("level-exceeded")

var Lit_92 *jrt.String = jrt.Intern("pprint-logical-block")

var Lit_93 *jrt.String = jrt.Intern("options*")

var Lit_94 *jrt.String = jrt.Intern("Execute the body as a pretty printing logical block with output to *out* which\nmust be a pretty printing writer. When used from pprint or cl-format, this can be\nassumed.\n\nThis function is intended for use when writing custom dispatch functions.\n\nBefore the body, the caller can optionally specify options: :prefix, :per-line-prefix,\nand :suffix.")

var Lit_95 *jrt.String = jrt.Intern("pprint-newline")

var Lit_96 *jrt.String = jrt.Intern("kind")

var Lit_97 *jrt.String = jrt.Intern("Print a conditional newline to a pretty printing stream. kind specifies if the\nnewline is :linear, :miser, :fill, or :mandatory.\n\nThis function is intended for use when writing custom dispatch functions.\n\nOutput is sent to *out* which must be a pretty printing writer.")

var Lit_98 *jrt.String = jrt.Intern("pprint-indent")

var Lit_99 *jrt.String = jrt.Intern("relative-to")

var Lit_100 *jrt.String = jrt.Intern("n")

var Lit_101 *jrt.String = jrt.Intern("Create an indent at this point in the pretty printing stream. This defines how\nfollowing lines are indented. relative-to can be either :block or :current depending\nwhether the indent should be computed relative to the start of the logical block or\nthe current column position. n is an offset.\n\nThis function is intended for use when writing custom dispatch functions.\n\nOutput is sent to *out* which must be a pretty printing writer.")

var Lit_102 *jrt.String = jrt.Intern("pprint-tab")

var Lit_103 *jrt.String = jrt.Intern("colnum")

var Lit_104 *jrt.String = jrt.Intern("colinc")

var Lit_105 *jrt.String = jrt.Intern("Tab at this point in the pretty printing stream. kind specifies whether the tab\nis :line, :section, :line-relative, or :section-relative.\n\nColnum and colinc specify the target column and the increment to move the target\nforward if the output is already past the original target.\n\nThis function is intended for use when writing custom dispatch functions.\n\nOutput is sent to *out* which must be a pretty printing writer.\n\nTHIS FUNCTION IS NOT YET IMPLEMENTED.")

var Lit_106 *jrt.String = jrt.Intern("pll-mod-body")

var Lit_107 *jrt.String = jrt.Intern("var-sym")

var Lit_108 *jrt.String = jrt.Intern("print-length-loop")

var Lit_109 *jrt.String = jrt.Intern("bindings")

var Lit_110 *jrt.String = jrt.Intern("A version of loop that iterates at most *print-length* times. This is designed\nfor use in pretty-printer dispatch functions.")

var Lit_111 *jrt.String = jrt.Intern("1.3")
