//line aot_arbace_pprint_pprint_base__init.ae:1
package aot_arbace_pprint_pprint_base

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_pprint_base__init_A_Load__O() any { A_arbace_pprint_pprint_base__init_A_Init(); A_arbace_pprint_pprint_base__init_A_Unit0__O(); A_arbace_pprint_pprint_base__init_A_Unit1__O(); A_arbace_pprint_pprint_base__init_A_Unit2__O(); A_arbace_pprint_pprint_base__init_A_Unit3__O(); A_arbace_pprint_pprint_base__init_A_Unit4__O(); A_arbace_pprint_pprint_base__init_A_Unit5__O(); A_arbace_pprint_pprint_base__init_A_Unit6__O(); A_arbace_pprint_pprint_base__init_A_Unit7__O(); A_arbace_pprint_pprint_base__init_A_Unit8__O(); A_arbace_pprint_pprint_base__init_A_Unit9__O(); A_arbace_pprint_pprint_base__init_A_Unit10__O(); A_arbace_pprint_pprint_base__init_A_Unit11__O(); A_arbace_pprint_pprint_base__init_A_Unit12__O(); A_arbace_pprint_pprint_base__init_A_Unit13__O(); A_arbace_pprint_pprint_base__init_A_Unit14__O(); A_arbace_pprint_pprint_base__init_A_Unit15__O(); A_arbace_pprint_pprint_base__init_A_Unit16__O(); A_arbace_pprint_pprint_base__init_A_Unit17__O(); A_arbace_pprint_pprint_base__init_A_Unit18__O(); A_arbace_pprint_pprint_base__init_A_Unit19__O(); A_arbace_pprint_pprint_base__init_A_Unit20__O(); A_arbace_pprint_pprint_base__init_A_Unit21__O(); A_arbace_pprint_pprint_base__init_A_Unit22__O(); A_arbace_pprint_pprint_base__init_A_Unit23__O(); A_arbace_pprint_pprint_base__init_A_Unit24__O(); A_arbace_pprint_pprint_base__init_A_Unit25__O(); A_arbace_pprint_pprint_base__init_A_Unit26__O(); A_arbace_pprint_pprint_base__init_A_Unit27__O(); A_arbace_pprint_pprint_base__init_A_Unit28__O(); A_arbace_pprint_pprint_base__init_A_Unit29__O(); A_arbace_pprint_pprint_base__init_A_Unit30__O(); A_arbace_pprint_pprint_base__init_A_Unit31__O(); A_arbace_pprint_pprint_base__init_A_Unit32__O(); A_arbace_pprint_pprint_base__init_A_Unit33__O(); A_arbace_pprint_pprint_base__init_A_Unit34__O(); A_arbace_pprint_pprint_base__init_A_Unit35__O(); A_arbace_pprint_pprint_base__init_A_Unit36__O(); A_arbace_pprint_pprint_base__init_A_Unit37__O(); A_arbace_pprint_pprint_base__init_A_Unit38__O(); A_arbace_pprint_pprint_base__init_A_Unit39__O(); A_arbace_pprint_pprint_base__init_A_Unit40__O(); A_arbace_pprint_pprint_base__init_A_Unit41__O(); A_arbace_pprint_pprint_base__init_A_Unit42__O(); A_arbace_pprint_pprint_base__init_A_Unit43__O(); A_arbace_pprint_pprint_base__init_A_Unit44__O(); A_arbace_pprint_pprint_base__init_A_Unit45__O(); A_arbace_pprint_pprint_base__init_A_Unit46__O(); A_arbace_pprint_pprint_base__init_A_Unit47__O(); A_arbace_pprint_pprint_base__init_A_Unit48__O(); A_arbace_pprint_pprint_base__init_A_Unit49__O(); return nil }










func A_arbace_pprint_pprint_base__init_A_Unit0__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_pprint_base__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pprint_base__init_A_const_1) }











func A_arbace_pprint_pprint_base__init_A_Unit1__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_2; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_2; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_3)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_2).SetDynamic_Z__Var(true).Ref() }



func A_arbace_pprint_pprint_base__init_A_Unit2__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var v__1927001498__auto____1 any; jrt.NN(A_arbace_pprint_pprint_base__init_A_const_4).SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_5)); v__1927001498__auto____1 = A_arbace_pprint_pprint_base__init_A_const_4.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { jrt.NN(A_arbace_pprint_pprint_base__init_A_const_4).SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_6)); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_4).BindRoot_O__V(nil); return A_arbace_pprint_pprint_base__init_A_const_4.Ref() } }





func A_arbace_pprint_pprint_base__init_A_Unit3__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_7).BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_8); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_7; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_9)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_7).SetDynamic_Z__Var(true).Ref() }






func A_arbace_pprint_pprint_base__init_A_Unit4__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_10).BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_11); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_10; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_12)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_10).SetDynamic_Z__Var(true).Ref() }
func A_arbace_pprint_pprint_base__init_A_Unit49__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); return nil }






func A_arbace_pprint_pprint_base__init_A_Unit5__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_13).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_13; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_14)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_13).SetDynamic_Z__Var(true).Ref() }





func A_arbace_pprint_pprint_base__init_A_Unit6__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_15).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_15; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_16)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_15).SetDynamic_Z__Var(true).Ref() }





func A_arbace_pprint_pprint_base__init_A_Unit7__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_17).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_17; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_18)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_17).SetDynamic_Z__Var(true).Ref() }




func A_arbace_pprint_pprint_base__init_A_Unit8__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_19).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_19; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_20)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_19).SetDynamic_Z__Var(true).Ref() }







func A_arbace_pprint_pprint_base__init_A_Unit9__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_21).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_21; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_22)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_21).SetDynamic_Z__Var(true).Ref() }






func A_arbace_pprint_pprint_base__init_A_Unit10__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_23).BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_24); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_23; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_25)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_23).SetDynamic_Z__Var(true).Ref() }









func A_arbace_pprint_pprint_base__init_A_Unit11__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_26).BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_27); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_26; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_28)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_26).SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_pprint_base__init_A_Unit12__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_29).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_29; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_30)); return jrt.NN(A_arbace_pprint_pprint_base__init_A_const_29).SetDynamic_Z__Var(true).Ref() }







func A_arbace_pprint_pprint_base__init_A_Unit13__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(105, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_31; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_32)); return A_arbace_pprint_pprint_base__init_A_const_31.Ref() }

func A_arbace_pprint_pprint_base__init_A_Unit14__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_33; jrt.NN(tmp1).BindRoot_O__V(jrt.NN(A_arbace_pprint_pprint_base__init_A_const_34).Get__O()); var tmp2 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_33; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_35)); return A_arbace_pprint_pprint_base__init_A_const_33.Ref() }

func A_arbace_pprint_pprint_base__init_A_Unit15__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_36; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pr_with_base_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pr_with_base_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pr_with_base_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_37)); return A_arbace_pprint_pprint_base__init_A_const_36.Ref() }




func A_arbace_pprint_pprint_base__init_A_Unit16__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(114, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_38).BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_39); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_38; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_40)); return A_arbace_pprint_pprint_base__init_A_const_38.Ref() }

















func A_arbace_pprint_pprint_base__init_A_Unit17__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_41; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_binding_map_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_binding_map_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_binding_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_42)); return A_arbace_pprint_pprint_base__init_A_const_41.Ref() }
//line :132:1
func A_arbace_pprint_pprint_base__init_A_Unit18__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_41).SetMacro__V(); return nil }
//line :132:1
func A_arbace_pprint_pprint_base__init_A_Unit19__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); return A_arbace_pprint_pprint_base__init_A_const_41.Ref() }








func A_arbace_pprint_pprint_base__init_A_Unit20__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(141, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_43; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_table_ize_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_table_ize_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_table_ize_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_44)); return A_arbace_pprint_pprint_base__init_A_const_43.Ref() }




func A_arbace_pprint_pprint_base__init_A_Unit21__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(146, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_45; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pretty_writer_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pretty_writer_QMARK__A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pretty_writer_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_46)); return A_arbace_pprint_pprint_base__init_A_const_45.Ref() }



func A_arbace_pprint_pprint_base__init_A_Unit22__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_47; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_make_pretty_writer_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_make_pretty_writer_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_make_pretty_writer_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_48)); return A_arbace_pprint_pprint_base__init_A_const_47.Ref() }




func A_arbace_pprint_pprint_base__init_A_Unit23__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_with_pretty_writer_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_with_pretty_writer_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_with_pretty_writer_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_50)); return A_arbace_pprint_pprint_base__init_A_const_49.Ref() }
//line :155:1
func A_arbace_pprint_pprint_base__init_A_Unit24__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_49).SetMacro__V(); return nil }
//line :155:1
func A_arbace_pprint_pprint_base__init_A_Unit25__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); return A_arbace_pprint_pprint_base__init_A_const_49.Ref() }









func A_arbace_pprint_pprint_base__init_A_Unit26__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_out_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_out_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_out_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_52)); return A_arbace_pprint_pprint_base__init_A_const_51.Ref() }

























func A_arbace_pprint_pprint_base__init_A_Unit27__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_53; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_write_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_write_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_write_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_54)); return A_arbace_pprint_pprint_base__init_A_const_53.Ref() }










































func A_arbace_pprint_pprint_base__init_A_Unit28__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(234, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_56)); return A_arbace_pprint_pprint_base__init_A_const_55.Ref() }












func A_arbace_pprint_pprint_base__init_A_Unit29__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(247, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_57; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pp_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pp_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_58)); return A_arbace_pprint_pprint_base__init_A_const_57.Ref() }
//line :247:1
func A_arbace_pprint_pprint_base__init_A_Unit30__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(247, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_57).SetMacro__V(); return nil }
//line :247:1
func A_arbace_pprint_pprint_base__init_A_Unit31__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(247, 1); return A_arbace_pprint_pprint_base__init_A_const_57.Ref() }





func A_arbace_pprint_pprint_base__init_A_Unit32__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(253, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_59; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_59; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_60)); return A_arbace_pprint_pprint_base__init_A_const_59.Ref() }













func A_arbace_pprint_pprint_base__init_A_Unit33__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_with_pprint_dispatch_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_with_pprint_dispatch_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_with_pprint_dispatch_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_62)); return A_arbace_pprint_pprint_base__init_A_const_61.Ref() }
//line :267:1
func A_arbace_pprint_pprint_base__init_A_Unit34__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_61).SetMacro__V(); return nil }
//line :267:1
func A_arbace_pprint_pprint_base__init_A_Unit35__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); return A_arbace_pprint_pprint_base__init_A_const_61.Ref() }










func A_arbace_pprint_pprint_base__init_A_Unit36__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(278, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_parse_lb_options_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_parse_lb_options_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_parse_lb_options_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_63; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_64)); return A_arbace_pprint_pprint_base__init_A_const_63.Ref() }






func A_arbace_pprint_pprint_base__init_A_Unit37__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(285, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_65; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_check_enumerated_arg_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_check_enumerated_arg_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_check_enumerated_arg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_65; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_66)); return A_arbace_pprint_pprint_base__init_A_const_65.Ref() }






func A_arbace_pprint_pprint_base__init_A_Unit38__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(292, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_67; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_level_exceeded_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_level_exceeded_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_level_exceeded_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_67; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_68)); return A_arbace_pprint_pprint_base__init_A_const_67.Ref() }


func A_arbace_pprint_pprint_base__init_A_Unit39__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(295, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_69; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_logical_block_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_logical_block_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_logical_block_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_69; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_70)); return A_arbace_pprint_pprint_base__init_A_const_69.Ref() }
//line :295:1
func A_arbace_pprint_pprint_base__init_A_Unit40__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(295, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_69).SetMacro__V(); return nil }
//line :295:1
func A_arbace_pprint_pprint_base__init_A_Unit41__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(295, 1); return A_arbace_pprint_pprint_base__init_A_const_69.Ref() }


























func A_arbace_pprint_pprint_base__init_A_Unit42__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(322, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_71; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_newline_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_newline_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_newline_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_71; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_72)); return A_arbace_pprint_pprint_base__init_A_const_71.Ref() }











func A_arbace_pprint_pprint_base__init_A_Unit43__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(334, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_73; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_indent_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_indent_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_indent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_73; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_74)); return A_arbace_pprint_pprint_base__init_A_const_73.Ref() }














func A_arbace_pprint_pprint_base__init_A_Unit44__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(349, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_75; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_tab_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_tab_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_tab_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_75; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_76)); return A_arbace_pprint_pprint_base__init_A_const_75.Ref() }






















func A_arbace_pprint_pprint_base__init_A_Unit45__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(372, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_77; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pll_mod_body_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pll_mod_body_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pll_mod_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_77; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_78)); return A_arbace_pprint_pprint_base__init_A_const_77.Ref() }










func A_arbace_pprint_pprint_base__init_A_Unit46__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(383, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_79; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_print_length_loop_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_print_length_loop_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_print_length_loop_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_79; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_80)); return A_arbace_pprint_pprint_base__init_A_const_79.Ref() }
//line :383:1
func A_arbace_pprint_pprint_base__init_A_Unit47__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(383, 1); jrt.NN(A_arbace_pprint_pprint_base__init_A_const_79).SetMacro__V(); return nil }
//line :383:1
func A_arbace_pprint_pprint_base__init_A_Unit48__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V(383, 1); return A_arbace_pprint_pprint_base__init_A_const_79.Ref() }







type A_arbace_pprint_pprint_base__init_A struct{ jrt.Object }

var A_arbace_pprint_pprint_base__init_A_const_0 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_1 any

var A_arbace_pprint_pprint_base__init_A_const_2 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_3 any

var A_arbace_pprint_pprint_base__init_A_const_4 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_5 any

var A_arbace_pprint_pprint_base__init_A_const_6 any

var A_arbace_pprint_pprint_base__init_A_const_7 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_8 any

var A_arbace_pprint_pprint_base__init_A_const_9 any

var A_arbace_pprint_pprint_base__init_A_const_10 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_11 any

var A_arbace_pprint_pprint_base__init_A_const_12 any

var A_arbace_pprint_pprint_base__init_A_const_13 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_14 any

var A_arbace_pprint_pprint_base__init_A_const_15 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_16 any

var A_arbace_pprint_pprint_base__init_A_const_17 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_18 any

var A_arbace_pprint_pprint_base__init_A_const_19 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_20 any

var A_arbace_pprint_pprint_base__init_A_const_21 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_22 any

var A_arbace_pprint_pprint_base__init_A_const_23 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_24 any

var A_arbace_pprint_pprint_base__init_A_const_25 any

var A_arbace_pprint_pprint_base__init_A_const_26 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_27 any

var A_arbace_pprint_pprint_base__init_A_const_28 any

var A_arbace_pprint_pprint_base__init_A_const_29 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_30 any

var A_arbace_pprint_pprint_base__init_A_const_31 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_32 any

var A_arbace_pprint_pprint_base__init_A_const_33 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_34 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_35 any

var A_arbace_pprint_pprint_base__init_A_const_36 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_37 any

var A_arbace_pprint_pprint_base__init_A_const_38 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_39 any

var A_arbace_pprint_pprint_base__init_A_const_40 any

var A_arbace_pprint_pprint_base__init_A_const_41 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_42 any

var A_arbace_pprint_pprint_base__init_A_const_43 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_44 any

var A_arbace_pprint_pprint_base__init_A_const_45 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_46 any

var A_arbace_pprint_pprint_base__init_A_const_47 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_48 any

var A_arbace_pprint_pprint_base__init_A_const_49 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_50 any

var A_arbace_pprint_pprint_base__init_A_const_51 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_52 any

var A_arbace_pprint_pprint_base__init_A_const_53 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_54 any

var A_arbace_pprint_pprint_base__init_A_const_55 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_56 any

var A_arbace_pprint_pprint_base__init_A_const_57 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_58 any

var A_arbace_pprint_pprint_base__init_A_const_59 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_60 any

var A_arbace_pprint_pprint_base__init_A_const_61 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_62 any

var A_arbace_pprint_pprint_base__init_A_const_63 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_64 any

var A_arbace_pprint_pprint_base__init_A_const_65 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_66 any

var A_arbace_pprint_pprint_base__init_A_const_67 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_68 any

var A_arbace_pprint_pprint_base__init_A_const_69 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_70 any

var A_arbace_pprint_pprint_base__init_A_const_71 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_72 any

var A_arbace_pprint_pprint_base__init_A_const_73 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_74 any

var A_arbace_pprint_pprint_base__init_A_const_75 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_76 any

var A_arbace_pprint_pprint_base__init_A_const_77 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_78 any

var A_arbace_pprint_pprint_base__init_A_const_79 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_80 any

var A_arbace_pprint_pprint_base__init_A_init jrt.ClassInit

func A_arbace_pprint_pprint_base__init_A_Init() { if !A_arbace_pprint_pprint_base__init_A_init.Done() { A_arbace_pprint_pprint_base__init_A_init.Run(A_arbace_pprint_pprint_base__init_A_clinit) } }

func A_arbace_pprint_pprint_base__init_A_clinit() { A_arbace_pprint_pprint_base__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_pprint_pprint_base__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_2).Ref(); A_arbace_pprint_pprint_base__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_2, Lit_3); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp2 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp3 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; var tmp5 any = tmp4.Ref(); A_arbace_pprint_pprint_base__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, Lit_5, tmp2, Lit_7, tmp3, tmp5, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_2, Lit_13); var tmp6 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp8 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; var tmp10 any = tmp9.Ref(); A_arbace_pprint_pprint_base__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_14, tmp7, Lit_7, tmp8, tmp10, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); var tmp11 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp12 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_pprint_pprint_base__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, Lit_14, tmp12, Lit_7, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_2, Lit_15); A_arbace_pprint_pprint_base__init_A_const_8 = jrt.Long_ValueOf_J__Long(72).Ref(); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp17 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp18 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp19 *jrt.Boolean; jrt.Boolean_Init(); tmp19 = jrt.Boolean_TRUE; var tmp20 any = tmp19.Ref(); A_arbace_pprint_pprint_base__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, Lit_16, tmp17, Lit_7, tmp18, tmp20, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_2, Lit_17); A_arbace_pprint_pprint_base__init_A_const_11 = jrt.Long_ValueOf_J__Long(40).Ref(); var tmp21 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp23 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; var tmp25 any = tmp24.Ref(); A_arbace_pprint_pprint_base__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, Lit_18, tmp22, Lit_7, tmp23, tmp25, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_2, Lit_19); var tmp26 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp27 *jrt.Boolean; jrt.Boolean_Init(); tmp27 = jrt.Boolean_TRUE; var tmp28 any = tmp27.Ref(); var tmp29 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp30 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp31 *jrt.Boolean; jrt.Boolean_Init(); tmp31 = jrt.Boolean_TRUE; var tmp32 any = tmp31.Ref(); A_arbace_pprint_pprint_base__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp28, tmp29, Lit_21, tmp30, tmp32, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_2, Lit_22); var tmp33 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp34 *jrt.Boolean; jrt.Boolean_Init(); tmp34 = jrt.Boolean_TRUE; var tmp35 any = tmp34.Ref(); var tmp36 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_pprint_pprint_base__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp35, tmp36, Lit_23, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_2, Lit_24); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp44 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp45 *jrt.Boolean; jrt.Boolean_Init(); tmp45 = jrt.Boolean_TRUE; var tmp46 any = tmp45.Ref(); A_arbace_pprint_pprint_base__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, tmp43, Lit_25, tmp44, tmp46, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_2, Lit_26); var tmp47 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp48 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_pprint_pprint_base__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp47, Lit_27, tmp48, Lit_7, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_2, Lit_28); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp53 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp54 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp55 *jrt.Boolean; jrt.Boolean_Init(); tmp55 = jrt.Boolean_TRUE; var tmp56 any = tmp55.Ref(); A_arbace_pprint_pprint_base__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, Lit_29, tmp53, Lit_7, tmp54, tmp56, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_2, Lit_30); A_arbace_pprint_pprint_base__init_A_const_24 = jrt.Long_ValueOf_J__Long(10).Ref(); var tmp57 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp59 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp60 *jrt.Boolean; jrt.Boolean_Init(); tmp60 = jrt.Boolean_TRUE; var tmp61 any = tmp60.Ref(); A_arbace_pprint_pprint_base__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp57, Lit_31, tmp58, Lit_7, tmp59, tmp61, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_2, Lit_32); A_arbace_pprint_pprint_base__init_A_const_27 = jrt.Long_ValueOf_J__Long(0).Ref(); var tmp62 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp63 *jrt.Boolean; jrt.Boolean_Init(); tmp63 = jrt.Boolean_TRUE; var tmp64 any = tmp63.Ref(); var tmp65 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp66 *jrt.Boolean; jrt.Boolean_Init(); tmp66 = jrt.Boolean_TRUE; var tmp67 any = tmp66.Ref(); A_arbace_pprint_pprint_base__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp62, tmp64, tmp65, tmp67, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_2, Lit_33); var tmp68 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp69 *jrt.Boolean; jrt.Boolean_Init(); tmp69 = jrt.Boolean_TRUE; var tmp70 any = tmp69.Ref(); var tmp71 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp72 *jrt.Boolean; jrt.Boolean_Init(); tmp72 = jrt.Boolean_TRUE; var tmp73 any = tmp72.Ref(); A_arbace_pprint_pprint_base__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp68, tmp70, tmp71, tmp73, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_2, Lit_34); var tmp74 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_35).Ref(); var tmp75 *jrt.Boolean; jrt.Boolean_Init(); tmp75 = jrt.Boolean_TRUE; var tmp76 any = tmp75.Ref(); A_arbace_pprint_pprint_base__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp74, tmp76, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(105).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_2, Lit_36); A_arbace_pprint_pprint_base__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); var tmp77 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp78 *jrt.Boolean; jrt.Boolean_Init(); tmp78 = jrt.Boolean_TRUE; var tmp79 any = tmp78.Ref(); A_arbace_pprint_pprint_base__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp77, tmp79, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(107).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_2, Lit_38); var tmp80 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp81 *jrt.Boolean; jrt.Boolean_Init(); tmp81 = jrt.Boolean_TRUE; var tmp82 any = tmp81.Ref(); A_arbace_pprint_pprint_base__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp80, tmp82, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_2, Lit_41); A_arbace_pprint_pprint_base__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_54).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_56).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_2, Lit_26).Ref())); var tmp83 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp84 *jrt.Boolean; jrt.Boolean_Init(); tmp84 = jrt.Boolean_TRUE; var tmp85 any = tmp84.Ref(); A_arbace_pprint_pprint_base__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp83, tmp85, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(114).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_2, Lit_57); var tmp86 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp87 *jrt.Boolean; jrt.Boolean_Init(); tmp87 = jrt.Boolean_TRUE; var tmp88 any = tmp87.Ref(); A_arbace_pprint_pprint_base__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp86, tmp88, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_59).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(132).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_2, Lit_61); var tmp89 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp90 *jrt.Boolean; jrt.Boolean_Init(); tmp90 = jrt.Boolean_TRUE; var tmp91 any = tmp90.Ref(); A_arbace_pprint_pprint_base__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp89, tmp91, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_63).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_2, Lit_64); var tmp92 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp93 *jrt.Boolean; jrt.Boolean_Init(); tmp93 = jrt.Boolean_TRUE; var tmp94 any = tmp93.Ref(); A_arbace_pprint_pprint_base__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp92, tmp94, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_65, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(146).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_2, Lit_66); var tmp95 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp96 *jrt.Boolean; jrt.Boolean_Init(); tmp96 = jrt.Boolean_TRUE; var tmp97 any = tmp96.Ref(); A_arbace_pprint_pprint_base__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp95, tmp97, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_68, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_2, Lit_69); var tmp98 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp99 *jrt.Boolean; jrt.Boolean_Init(); tmp99 = jrt.Boolean_TRUE; var tmp100 any = tmp99.Ref(); A_arbace_pprint_pprint_base__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp98, tmp100, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_59).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(155).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_2, Lit_70); A_arbace_pprint_pprint_base__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_72, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(165).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_2, Lit_73); A_arbace_pprint_pprint_base__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_59).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_75, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(191).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_2, Lit_76); A_arbace_pprint_pprint_base__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_78, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(234).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_2, Lit_79); A_arbace_pprint_pprint_base__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_80, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(247).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_2, Lit_81); A_arbace_pprint_pprint_base__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_82).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_83, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(253).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_2, Lit_84); A_arbace_pprint_pprint_base__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_82).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_59).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(267).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_2, Lit_86); var tmp101 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp102 *jrt.Boolean; jrt.Boolean_Init(); tmp102 = jrt.Boolean_TRUE; var tmp103 any = tmp102.Ref(); A_arbace_pprint_pprint_base__init_A_const_64 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp101, tmp103, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(278).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_65 = lang.RT_Var_String_String__Var(Lit_2, Lit_88); var tmp104 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp105 *jrt.Boolean; jrt.Boolean_Init(); tmp105 = jrt.Boolean_TRUE; var tmp106 any = tmp105.Ref(); A_arbace_pprint_pprint_base__init_A_const_66 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp104, tmp106, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(285).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_67 = lang.RT_Var_String_String__Var(Lit_2, Lit_91); var tmp107 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp108 *jrt.Boolean; jrt.Boolean_Init(); tmp108 = jrt.Boolean_TRUE; var tmp109 any = tmp108.Ref(); A_arbace_pprint_pprint_base__init_A_const_68 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp107, tmp109, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(292).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_2, Lit_92); A_arbace_pprint_pprint_base__init_A_const_70 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_94, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(295).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_71 = lang.RT_Var_String_String__Var(Lit_2, Lit_95); A_arbace_pprint_pprint_base__init_A_const_72 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(322).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_73 = lang.RT_Var_String_String__Var(Lit_2, Lit_98); A_arbace_pprint_pprint_base__init_A_const_74 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_101, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(334).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_75 = lang.RT_Var_String_String__Var(Lit_2, Lit_102); A_arbace_pprint_pprint_base__init_A_const_76 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_104).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_105, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(349).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_77 = lang.RT_Var_String_String__Var(Lit_2, Lit_106); var tmp110 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp111 *jrt.Boolean; jrt.Boolean_Init(); tmp111 = jrt.Boolean_TRUE; var tmp112 any = tmp111.Ref(); A_arbace_pprint_pprint_base__init_A_const_78 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp110, tmp112, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(372).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_pprint_base__init_A_const_79 = lang.RT_Var_String_String__Var(Lit_2, Lit_108); A_arbace_pprint_pprint_base__init_A_const_80 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_59).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_110, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_111, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(383).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)) }

func A_arbace_pprint_pprint_base__init_A_New() *A_arbace_pprint_pprint_base__init_A { A_arbace_pprint_pprint_base__init_A_Init(); t := &A_arbace_pprint_pprint_base__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_pprint_base__init_A) Ctor() {}

func (t *A_arbace_pprint_pprint_base__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_pprint_base__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_pprint_base__init_A_class }

func (t *A_arbace_pprint_pprint_base__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_pprint_base__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_pprint_base__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_pprint_base__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_pprint_base__init_A); return ok }

func A_arbace_pprint_pprint_base__init_A_Cast(x any) *A_arbace_pprint_pprint_base__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_pprint_base__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_pprint_base__init_A_class)) }; return v }
