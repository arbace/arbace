//line aot_arbace_pprint_pprint_base__init.ae:1
package aot_arbace_pprint_pprint_base

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_pprint_base__init_A_Load__O() any { A_arbace_pprint_pprint_base__init_A_Init(); jrt.StartCheck(); A_arbace_pprint_pprint_base__init_A_Unit0__O(); A_arbace_pprint_pprint_base__init_A_Unit1__O(); A_arbace_pprint_pprint_base__init_A_Unit2__O(); A_arbace_pprint_pprint_base__init_A_Unit3__O(); A_arbace_pprint_pprint_base__init_A_Unit4__O(); A_arbace_pprint_pprint_base__init_A_Unit5__O(); A_arbace_pprint_pprint_base__init_A_Unit6__O(); A_arbace_pprint_pprint_base__init_A_Unit7__O(); A_arbace_pprint_pprint_base__init_A_Unit8__O(); A_arbace_pprint_pprint_base__init_A_Unit9__O(); A_arbace_pprint_pprint_base__init_A_Unit10__O(); A_arbace_pprint_pprint_base__init_A_Unit11__O(); A_arbace_pprint_pprint_base__init_A_Unit12__O(); A_arbace_pprint_pprint_base__init_A_Unit13__O(); A_arbace_pprint_pprint_base__init_A_Unit14__O(); A_arbace_pprint_pprint_base__init_A_Unit15__O(); A_arbace_pprint_pprint_base__init_A_Unit16__O(); A_arbace_pprint_pprint_base__init_A_Unit17__O(); A_arbace_pprint_pprint_base__init_A_Unit18__O(); A_arbace_pprint_pprint_base__init_A_Unit19__O(); A_arbace_pprint_pprint_base__init_A_Unit20__O(); A_arbace_pprint_pprint_base__init_A_Unit21__O(); A_arbace_pprint_pprint_base__init_A_Unit22__O(); A_arbace_pprint_pprint_base__init_A_Unit23__O(); A_arbace_pprint_pprint_base__init_A_Unit24__O(); A_arbace_pprint_pprint_base__init_A_Unit25__O(); A_arbace_pprint_pprint_base__init_A_Unit26__O(); A_arbace_pprint_pprint_base__init_A_Unit27__O(); A_arbace_pprint_pprint_base__init_A_Unit28__O(); A_arbace_pprint_pprint_base__init_A_Unit29__O(); A_arbace_pprint_pprint_base__init_A_Unit30__O(); A_arbace_pprint_pprint_base__init_A_Unit31__O(); A_arbace_pprint_pprint_base__init_A_Unit32__O(); A_arbace_pprint_pprint_base__init_A_Unit33__O(); A_arbace_pprint_pprint_base__init_A_Unit34__O(); A_arbace_pprint_pprint_base__init_A_Unit35__O(); A_arbace_pprint_pprint_base__init_A_Unit36__O(); A_arbace_pprint_pprint_base__init_A_Unit37__O(); A_arbace_pprint_pprint_base__init_A_Unit38__O(); A_arbace_pprint_pprint_base__init_A_Unit39__O(); A_arbace_pprint_pprint_base__init_A_Unit40__O(); A_arbace_pprint_pprint_base__init_A_Unit41__O(); A_arbace_pprint_pprint_base__init_A_Unit42__O(); A_arbace_pprint_pprint_base__init_A_Unit43__O(); A_arbace_pprint_pprint_base__init_A_Unit44__O(); A_arbace_pprint_pprint_base__init_A_Unit45__O(); A_arbace_pprint_pprint_base__init_A_Unit46__O(); A_arbace_pprint_pprint_base__init_A_Unit47__O(); A_arbace_pprint_pprint_base__init_A_Unit48__O(); A_arbace_pprint_pprint_base__init_A_Unit49__O(); return nil }










func A_arbace_pprint_pprint_base__init_A_Unit0__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); return lang.IFn_Cast(A_arbace_pprint_pprint_base__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_pprint_base__init_A_const_1) }











func A_arbace_pprint_pprint_base__init_A_Unit1__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); A_arbace_pprint_pprint_base__init_A_const_2.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_3)); return A_arbace_pprint_pprint_base__init_A_const_2.SetDynamic_Z__Var(true).Ref() }



func A_arbace_pprint_pprint_base__init_A_Unit2__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); var v__1927001498__auto____1 any; A_arbace_pprint_pprint_base__init_A_const_4.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_5)); v__1927001498__auto____1 = A_arbace_pprint_pprint_base__init_A_const_4; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { A_arbace_pprint_pprint_base__init_A_const_4.SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_6)); A_arbace_pprint_pprint_base__init_A_const_4.BindRoot_O__V(nil); return A_arbace_pprint_pprint_base__init_A_const_4 } }





func A_arbace_pprint_pprint_base__init_A_Unit3__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_pprint_pprint_base__init_A_const_7.BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_8); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_9)); return A_arbace_pprint_pprint_base__init_A_const_7.SetDynamic_Z__Var(true).Ref() }






func A_arbace_pprint_pprint_base__init_A_Unit4__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); A_arbace_pprint_pprint_base__init_A_const_10.BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_11); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_12)); return A_arbace_pprint_pprint_base__init_A_const_10.SetDynamic_Z__Var(true).Ref() }
func A_arbace_pprint_pprint_base__init_A_Unit49__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); return nil }






func A_arbace_pprint_pprint_base__init_A_Unit5__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); A_arbace_pprint_pprint_base__init_A_const_13.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_13; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_14)); return A_arbace_pprint_pprint_base__init_A_const_13.SetDynamic_Z__Var(true).Ref() }





func A_arbace_pprint_pprint_base__init_A_Unit6__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); A_arbace_pprint_pprint_base__init_A_const_15.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_16)); return A_arbace_pprint_pprint_base__init_A_const_15.SetDynamic_Z__Var(true).Ref() }





func A_arbace_pprint_pprint_base__init_A_Unit7__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); A_arbace_pprint_pprint_base__init_A_const_17.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_18)); return A_arbace_pprint_pprint_base__init_A_const_17.SetDynamic_Z__Var(true).Ref() }




func A_arbace_pprint_pprint_base__init_A_Unit8__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); A_arbace_pprint_pprint_base__init_A_const_19.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_19; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_20)); return A_arbace_pprint_pprint_base__init_A_const_19.SetDynamic_Z__Var(true).Ref() }







func A_arbace_pprint_pprint_base__init_A_Unit9__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); A_arbace_pprint_pprint_base__init_A_const_21.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_22)); return A_arbace_pprint_pprint_base__init_A_const_21.SetDynamic_Z__Var(true).Ref() }






func A_arbace_pprint_pprint_base__init_A_Unit10__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); A_arbace_pprint_pprint_base__init_A_const_23.BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_24); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_25)); return A_arbace_pprint_pprint_base__init_A_const_23.SetDynamic_Z__Var(true).Ref() }









func A_arbace_pprint_pprint_base__init_A_Unit11__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); A_arbace_pprint_pprint_base__init_A_const_26.BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_27); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_28)); return A_arbace_pprint_pprint_base__init_A_const_26.SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_pprint_base__init_A_Unit12__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); A_arbace_pprint_pprint_base__init_A_const_29.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_30)); return A_arbace_pprint_pprint_base__init_A_const_29.SetDynamic_Z__Var(true).Ref() }







func A_arbace_pprint_pprint_base__init_A_Unit13__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_31; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_32)); return A_arbace_pprint_pprint_base__init_A_const_31 }

func A_arbace_pprint_pprint_base__init_A_Unit14__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_33; tmp1.BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_34.Get__O()); var tmp2 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_33; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_35)); return A_arbace_pprint_pprint_base__init_A_const_33 }

func A_arbace_pprint_pprint_base__init_A_Unit15__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = aot_arbace_pprint.A_arbace_pprint_pr_with_base_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pr_with_base_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); aot_arbace_pprint.A_arbace_pprint_pr_with_base_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_37)); return A_arbace_pprint_pprint_base__init_A_const_36 }




func A_arbace_pprint_pprint_base__init_A_Unit16__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); A_arbace_pprint_pprint_base__init_A_const_38.BindRoot_O__V(A_arbace_pprint_pprint_base__init_A_const_39); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_40)); return A_arbace_pprint_pprint_base__init_A_const_38 }

















func A_arbace_pprint_pprint_base__init_A_Unit17__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_41; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__4 any = aot_arbace_pprint.A_arbace_pprint_binding_map_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_binding_map_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, true, nil); aot_arbace_pprint.A_arbace_pprint_binding_map_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__4, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_42)); return A_arbace_pprint_pprint_base__init_A_const_41 }
//line :132:1
func A_arbace_pprint_pprint_base__init_A_Unit18__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); A_arbace_pprint_pprint_base__init_A_const_41.SetMacro__V(); return nil }
//line :132:1
func A_arbace_pprint_pprint_base__init_A_Unit19__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); return A_arbace_pprint_pprint_base__init_A_const_41 }








func A_arbace_pprint_pprint_base__init_A_Unit20__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = aot_arbace_pprint.A_arbace_pprint_table_ize_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_table_ize_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); aot_arbace_pprint.A_arbace_pprint_table_ize_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_44)); return A_arbace_pprint_pprint_base__init_A_const_43 }




func A_arbace_pprint_pprint_base__init_A_Unit21__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = aot_arbace_pprint.A_arbace_pprint_pretty_writer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pretty_writer_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); aot_arbace_pprint.A_arbace_pprint_pretty_writer_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_46)); return A_arbace_pprint_pprint_base__init_A_const_45 }



func A_arbace_pprint_pprint_base__init_A_Unit22__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(150, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = aot_arbace_pprint.A_arbace_pprint_make_pretty_writer_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_make_pretty_writer_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); aot_arbace_pprint.A_arbace_pprint_make_pretty_writer_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_48)); return A_arbace_pprint_pprint_base__init_A_const_47 }




func A_arbace_pprint_pprint_base__init_A_Unit23__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_49; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__12 any = aot_arbace_pprint.A_arbace_pprint_with_pretty_writer_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_with_pretty_writer_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, true, nil); aot_arbace_pprint.A_arbace_pprint_with_pretty_writer_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__12, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_50)); return A_arbace_pprint_pprint_base__init_A_const_49 }
//line :155:1
func A_arbace_pprint_pprint_base__init_A_Unit24__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); A_arbace_pprint_pprint_base__init_A_const_49.SetMacro__V(); return nil }
//line :155:1
func A_arbace_pprint_pprint_base__init_A_Unit25__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); return A_arbace_pprint_pprint_base__init_A_const_49 }









func A_arbace_pprint_pprint_base__init_A_Unit26__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = aot_arbace_pprint.A_arbace_pprint_write_out_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_out_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); aot_arbace_pprint.A_arbace_pprint_write_out_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_52)); return A_arbace_pprint_pprint_base__init_A_const_51 }

























func A_arbace_pprint_pprint_base__init_A_Unit27__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_53; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__16 any = aot_arbace_pprint.A_arbace_pprint_write_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_write_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, true, nil); aot_arbace_pprint.A_arbace_pprint_write_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__16, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_54)); return A_arbace_pprint_pprint_base__init_A_const_53 }










































func A_arbace_pprint_pprint_base__init_A_Unit28__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = aot_arbace_pprint.A_arbace_pprint_pprint_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_56)); return A_arbace_pprint_pprint_base__init_A_const_55 }












func A_arbace_pprint_pprint_base__init_A_Unit29__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = aot_arbace_pprint.A_arbace_pprint_pp_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pp_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); aot_arbace_pprint.A_arbace_pprint_pp_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_58)); return A_arbace_pprint_pprint_base__init_A_const_57 }
//line :247:1
func A_arbace_pprint_pprint_base__init_A_Unit30__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); A_arbace_pprint_pprint_base__init_A_const_57.SetMacro__V(); return nil }
//line :247:1
func A_arbace_pprint_pprint_base__init_A_Unit31__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); return A_arbace_pprint_pprint_base__init_A_const_57 }





func A_arbace_pprint_pprint_base__init_A_Unit32__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_60)); return A_arbace_pprint_pprint_base__init_A_const_59 }













func A_arbace_pprint_pprint_base__init_A_Unit33__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_61; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__24 any = aot_arbace_pprint.A_arbace_pprint_with_pprint_dispatch_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_with_pprint_dispatch_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, true, nil); aot_arbace_pprint.A_arbace_pprint_with_pprint_dispatch_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__24, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_62)); return A_arbace_pprint_pprint_base__init_A_const_61 }
//line :267:1
func A_arbace_pprint_pprint_base__init_A_Unit34__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); A_arbace_pprint_pprint_base__init_A_const_61.SetMacro__V(); return nil }
//line :267:1
func A_arbace_pprint_pprint_base__init_A_Unit35__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); return A_arbace_pprint_pprint_base__init_A_const_61 }










func A_arbace_pprint_pprint_base__init_A_Unit36__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(278, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = aot_arbace_pprint.A_arbace_pprint_parse_lb_options_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_parse_lb_options_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); aot_arbace_pprint.A_arbace_pprint_parse_lb_options_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_64)); return A_arbace_pprint_pprint_base__init_A_const_63 }






func A_arbace_pprint_pprint_base__init_A_Unit37__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(285, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = aot_arbace_pprint.A_arbace_pprint_check_enumerated_arg_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_check_enumerated_arg_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); aot_arbace_pprint.A_arbace_pprint_check_enumerated_arg_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_66)); return A_arbace_pprint_pprint_base__init_A_const_65 }






func A_arbace_pprint_pprint_base__init_A_Unit38__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = aot_arbace_pprint.A_arbace_pprint_level_exceeded_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_level_exceeded_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); aot_arbace_pprint.A_arbace_pprint_level_exceeded_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_68)); return A_arbace_pprint_pprint_base__init_A_const_67 }


func A_arbace_pprint_pprint_base__init_A_Unit39__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_69; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__32 any = aot_arbace_pprint.A_arbace_pprint_pprint_logical_block_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_logical_block_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, true, nil); aot_arbace_pprint.A_arbace_pprint_pprint_logical_block_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__32, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_70)); return A_arbace_pprint_pprint_base__init_A_const_69 }
//line :295:1
func A_arbace_pprint_pprint_base__init_A_Unit40__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); A_arbace_pprint_pprint_base__init_A_const_69.SetMacro__V(); return nil }
//line :295:1
func A_arbace_pprint_pprint_base__init_A_Unit41__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); return A_arbace_pprint_pprint_base__init_A_const_69 }


























func A_arbace_pprint_pprint_base__init_A_Unit42__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = aot_arbace_pprint.A_arbace_pprint_pprint_newline_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_newline_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); aot_arbace_pprint.A_arbace_pprint_pprint_newline_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_72)); return A_arbace_pprint_pprint_base__init_A_const_71 }











func A_arbace_pprint_pprint_base__init_A_Unit43__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = aot_arbace_pprint.A_arbace_pprint_pprint_indent_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_indent_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); aot_arbace_pprint.A_arbace_pprint_pprint_indent_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_74)); return A_arbace_pprint_pprint_base__init_A_const_73 }














func A_arbace_pprint_pprint_base__init_A_Unit44__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = aot_arbace_pprint.A_arbace_pprint_pprint_tab_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_tab_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); aot_arbace_pprint.A_arbace_pprint_pprint_tab_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_76)); return A_arbace_pprint_pprint_base__init_A_const_75 }






















func A_arbace_pprint_pprint_base__init_A_Unit45__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = aot_arbace_pprint.A_arbace_pprint_pll_mod_body_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pll_mod_body_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); aot_arbace_pprint.A_arbace_pprint_pll_mod_body_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_78)); return A_arbace_pprint_pprint_base__init_A_const_77 }










func A_arbace_pprint_pprint_base__init_A_Unit46__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(383, 1); var tmp1 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_79; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__42 any = aot_arbace_pprint.A_arbace_pprint_print_length_loop_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_print_length_loop_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, true, nil); aot_arbace_pprint.A_arbace_pprint_print_length_loop_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__42, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_pprint_base__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_pprint_base__init_A_const_80)); return A_arbace_pprint_pprint_base__init_A_const_79 }
//line :383:1
func A_arbace_pprint_pprint_base__init_A_Unit47__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(383, 1); A_arbace_pprint_pprint_base__init_A_const_79.SetMacro__V(); return nil }
//line :383:1
func A_arbace_pprint_pprint_base__init_A_Unit48__O() any { A_arbace_pprint_pprint_base__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(383, 1); return A_arbace_pprint_pprint_base__init_A_const_79 }







type A_arbace_pprint_pprint_base__init_A struct{ jrt.Object }

var A_arbace_pprint_pprint_base__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_pprint_base__init_A_const_0 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_1 any

var A_arbace_pprint_pprint_base__init_A_const_2 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_3 any

var A_arbace_pprint_pprint_base__init_A_const_4 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_5 any

var A_arbace_pprint_pprint_base__init_A_const_6 any

var A_arbace_pprint_pprint_base__init_A_const_7 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_8 any

var A_arbace_pprint_pprint_base__init_A_const_9 any

var A_arbace_pprint_pprint_base__init_A_const_10 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_11 any

var A_arbace_pprint_pprint_base__init_A_const_12 any

var A_arbace_pprint_pprint_base__init_A_const_13 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_14 any

var A_arbace_pprint_pprint_base__init_A_const_15 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_16 any

var A_arbace_pprint_pprint_base__init_A_const_17 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_18 any

var A_arbace_pprint_pprint_base__init_A_const_19 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_20 any

var A_arbace_pprint_pprint_base__init_A_const_21 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_22 any

var A_arbace_pprint_pprint_base__init_A_const_23 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_24 any

var A_arbace_pprint_pprint_base__init_A_const_25 any

var A_arbace_pprint_pprint_base__init_A_const_26 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_27 any

var A_arbace_pprint_pprint_base__init_A_const_28 any

var A_arbace_pprint_pprint_base__init_A_const_29 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_30 any

var A_arbace_pprint_pprint_base__init_A_const_31 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_32 any

var A_arbace_pprint_pprint_base__init_A_const_33 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_34 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_35 any

var A_arbace_pprint_pprint_base__init_A_const_36 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_37 any

var A_arbace_pprint_pprint_base__init_A_const_38 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_39 any

var A_arbace_pprint_pprint_base__init_A_const_40 any

var A_arbace_pprint_pprint_base__init_A_const_41 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_42 any

var A_arbace_pprint_pprint_base__init_A_const_43 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_44 any

var A_arbace_pprint_pprint_base__init_A_const_45 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_46 any

var A_arbace_pprint_pprint_base__init_A_const_47 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_48 any

var A_arbace_pprint_pprint_base__init_A_const_49 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_50 any

var A_arbace_pprint_pprint_base__init_A_const_51 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_52 any

var A_arbace_pprint_pprint_base__init_A_const_53 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_54 any

var A_arbace_pprint_pprint_base__init_A_const_55 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_56 any

var A_arbace_pprint_pprint_base__init_A_const_57 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_58 any

var A_arbace_pprint_pprint_base__init_A_const_59 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_60 any

var A_arbace_pprint_pprint_base__init_A_const_61 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_62 any

var A_arbace_pprint_pprint_base__init_A_const_63 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_64 any

var A_arbace_pprint_pprint_base__init_A_const_65 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_66 any

var A_arbace_pprint_pprint_base__init_A_const_67 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_68 any

var A_arbace_pprint_pprint_base__init_A_const_69 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_70 any

var A_arbace_pprint_pprint_base__init_A_const_71 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_72 any

var A_arbace_pprint_pprint_base__init_A_const_73 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_74 any

var A_arbace_pprint_pprint_base__init_A_const_75 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_76 any

var A_arbace_pprint_pprint_base__init_A_const_77 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_78 any

var A_arbace_pprint_pprint_base__init_A_const_79 *lang.Var

var A_arbace_pprint_pprint_base__init_A_const_80 any

var A_arbace_pprint_pprint_base__init_A_init jrt.ClassInit

func A_arbace_pprint_pprint_base__init_A_Init() { if !A_arbace_pprint_pprint_base__init_A_init.Done() { A_arbace_pprint_pprint_base__init_A_init.Run(A_arbace_pprint_pprint_base__init_A_clinit) } }

func A_arbace_pprint_pprint_base__init_A_clinit() { A_arbace_pprint_pprint_base__init_A_clinit_p0(); A_arbace_pprint_pprint_base__init_A_clinit_p1(); A_arbace_pprint_pprint_base__init_A_clinit_p2(); A_arbace_pprint_pprint_base__init_A_clinit_p3(); A_arbace_pprint_pprint_base__init_A_clinit_p4(); A_arbace_pprint_pprint_base__init_A_clinit_p5(); A_arbace_pprint_pprint_base__init_A_clinit_p6() }

func A_arbace_pprint_pprint_base__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_pprint_pprint_base__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 139); A_arbace_pprint_pprint_base__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[58]); A_arbace_pprint_pprint_base__init_A_const_1 = A_arbace_pprint_pprint_base__init_A_const_pool.A[59]; A_arbace_pprint_pprint_base__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[60]); A_arbace_pprint_pprint_base__init_A_const_3 = A_arbace_pprint_pprint_base__init_A_const_pool.A[61]; A_arbace_pprint_pprint_base__init_A_const_4 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[62]); A_arbace_pprint_pprint_base__init_A_const_5 = A_arbace_pprint_pprint_base__init_A_const_pool.A[63]; A_arbace_pprint_pprint_base__init_A_const_6 = A_arbace_pprint_pprint_base__init_A_const_pool.A[64]; A_arbace_pprint_pprint_base__init_A_const_7 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[65]); A_arbace_pprint_pprint_base__init_A_const_8 = A_arbace_pprint_pprint_base__init_A_const_pool.A[66]; A_arbace_pprint_pprint_base__init_A_const_9 = A_arbace_pprint_pprint_base__init_A_const_pool.A[67]; A_arbace_pprint_pprint_base__init_A_const_10 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[68]); A_arbace_pprint_pprint_base__init_A_const_11 = A_arbace_pprint_pprint_base__init_A_const_pool.A[69]; A_arbace_pprint_pprint_base__init_A_const_12 = A_arbace_pprint_pprint_base__init_A_const_pool.A[70] }

func A_arbace_pprint_pprint_base__init_A_clinit_p1() { A_arbace_pprint_pprint_base__init_A_const_13 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[71]); A_arbace_pprint_pprint_base__init_A_const_14 = A_arbace_pprint_pprint_base__init_A_const_pool.A[72]; A_arbace_pprint_pprint_base__init_A_const_15 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[73]); A_arbace_pprint_pprint_base__init_A_const_16 = A_arbace_pprint_pprint_base__init_A_const_pool.A[74]; A_arbace_pprint_pprint_base__init_A_const_17 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[75]); A_arbace_pprint_pprint_base__init_A_const_18 = A_arbace_pprint_pprint_base__init_A_const_pool.A[76]; A_arbace_pprint_pprint_base__init_A_const_19 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[77]); A_arbace_pprint_pprint_base__init_A_const_20 = A_arbace_pprint_pprint_base__init_A_const_pool.A[78]; A_arbace_pprint_pprint_base__init_A_const_21 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[79]); A_arbace_pprint_pprint_base__init_A_const_22 = A_arbace_pprint_pprint_base__init_A_const_pool.A[80]; A_arbace_pprint_pprint_base__init_A_const_23 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[81]); A_arbace_pprint_pprint_base__init_A_const_24 = A_arbace_pprint_pprint_base__init_A_const_pool.A[82]; A_arbace_pprint_pprint_base__init_A_const_25 = A_arbace_pprint_pprint_base__init_A_const_pool.A[83] }

func A_arbace_pprint_pprint_base__init_A_clinit_p2() { A_arbace_pprint_pprint_base__init_A_const_26 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[84]); A_arbace_pprint_pprint_base__init_A_const_27 = A_arbace_pprint_pprint_base__init_A_const_pool.A[85]; A_arbace_pprint_pprint_base__init_A_const_28 = A_arbace_pprint_pprint_base__init_A_const_pool.A[86]; A_arbace_pprint_pprint_base__init_A_const_29 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[87]); A_arbace_pprint_pprint_base__init_A_const_30 = A_arbace_pprint_pprint_base__init_A_const_pool.A[88]; A_arbace_pprint_pprint_base__init_A_const_31 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[89]); A_arbace_pprint_pprint_base__init_A_const_32 = A_arbace_pprint_pprint_base__init_A_const_pool.A[90]; A_arbace_pprint_pprint_base__init_A_const_33 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[91]); A_arbace_pprint_pprint_base__init_A_const_34 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[92]); A_arbace_pprint_pprint_base__init_A_const_35 = A_arbace_pprint_pprint_base__init_A_const_pool.A[93]; A_arbace_pprint_pprint_base__init_A_const_36 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[94]); A_arbace_pprint_pprint_base__init_A_const_37 = A_arbace_pprint_pprint_base__init_A_const_pool.A[95]; A_arbace_pprint_pprint_base__init_A_const_38 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[96]) }

func A_arbace_pprint_pprint_base__init_A_clinit_p3() { A_arbace_pprint_pprint_base__init_A_const_39 = A_arbace_pprint_pprint_base__init_A_const_pool.A[97]; A_arbace_pprint_pprint_base__init_A_const_40 = A_arbace_pprint_pprint_base__init_A_const_pool.A[98]; A_arbace_pprint_pprint_base__init_A_const_41 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[99]); A_arbace_pprint_pprint_base__init_A_const_42 = A_arbace_pprint_pprint_base__init_A_const_pool.A[100]; A_arbace_pprint_pprint_base__init_A_const_43 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[101]); A_arbace_pprint_pprint_base__init_A_const_44 = A_arbace_pprint_pprint_base__init_A_const_pool.A[102]; A_arbace_pprint_pprint_base__init_A_const_45 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[103]); A_arbace_pprint_pprint_base__init_A_const_46 = A_arbace_pprint_pprint_base__init_A_const_pool.A[104]; A_arbace_pprint_pprint_base__init_A_const_47 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[105]); A_arbace_pprint_pprint_base__init_A_const_48 = A_arbace_pprint_pprint_base__init_A_const_pool.A[106]; A_arbace_pprint_pprint_base__init_A_const_49 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[107]); A_arbace_pprint_pprint_base__init_A_const_50 = A_arbace_pprint_pprint_base__init_A_const_pool.A[108]; A_arbace_pprint_pprint_base__init_A_const_51 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[109]); A_arbace_pprint_pprint_base__init_A_const_52 = A_arbace_pprint_pprint_base__init_A_const_pool.A[110] }

func A_arbace_pprint_pprint_base__init_A_clinit_p4() { A_arbace_pprint_pprint_base__init_A_const_53 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[111]); A_arbace_pprint_pprint_base__init_A_const_54 = A_arbace_pprint_pprint_base__init_A_const_pool.A[112]; A_arbace_pprint_pprint_base__init_A_const_55 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[113]); A_arbace_pprint_pprint_base__init_A_const_56 = A_arbace_pprint_pprint_base__init_A_const_pool.A[114]; A_arbace_pprint_pprint_base__init_A_const_57 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[115]); A_arbace_pprint_pprint_base__init_A_const_58 = A_arbace_pprint_pprint_base__init_A_const_pool.A[116]; A_arbace_pprint_pprint_base__init_A_const_59 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[117]); A_arbace_pprint_pprint_base__init_A_const_60 = A_arbace_pprint_pprint_base__init_A_const_pool.A[118]; A_arbace_pprint_pprint_base__init_A_const_61 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[119]); A_arbace_pprint_pprint_base__init_A_const_62 = A_arbace_pprint_pprint_base__init_A_const_pool.A[120]; A_arbace_pprint_pprint_base__init_A_const_63 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[121]); A_arbace_pprint_pprint_base__init_A_const_64 = A_arbace_pprint_pprint_base__init_A_const_pool.A[122]; A_arbace_pprint_pprint_base__init_A_const_65 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[123]) }

func A_arbace_pprint_pprint_base__init_A_clinit_p5() { A_arbace_pprint_pprint_base__init_A_const_66 = A_arbace_pprint_pprint_base__init_A_const_pool.A[124]; A_arbace_pprint_pprint_base__init_A_const_67 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[125]); A_arbace_pprint_pprint_base__init_A_const_68 = A_arbace_pprint_pprint_base__init_A_const_pool.A[126]; A_arbace_pprint_pprint_base__init_A_const_69 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[127]); A_arbace_pprint_pprint_base__init_A_const_70 = A_arbace_pprint_pprint_base__init_A_const_pool.A[128]; A_arbace_pprint_pprint_base__init_A_const_71 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[129]); A_arbace_pprint_pprint_base__init_A_const_72 = A_arbace_pprint_pprint_base__init_A_const_pool.A[130]; A_arbace_pprint_pprint_base__init_A_const_73 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[131]); A_arbace_pprint_pprint_base__init_A_const_74 = A_arbace_pprint_pprint_base__init_A_const_pool.A[132]; A_arbace_pprint_pprint_base__init_A_const_75 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[133]); A_arbace_pprint_pprint_base__init_A_const_76 = A_arbace_pprint_pprint_base__init_A_const_pool.A[134]; A_arbace_pprint_pprint_base__init_A_const_77 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[135]); A_arbace_pprint_pprint_base__init_A_const_78 = A_arbace_pprint_pprint_base__init_A_const_pool.A[136] }

func A_arbace_pprint_pprint_base__init_A_clinit_p6() { A_arbace_pprint_pprint_base__init_A_const_79 = lang.Var_Cast(A_arbace_pprint_pprint_base__init_A_const_pool.A[137]); A_arbace_pprint_pprint_base__init_A_const_80 = A_arbace_pprint_pprint_base__init_A_const_pool.A[138] }

func A_arbace_pprint_pprint_base__init_A_New() *A_arbace_pprint_pprint_base__init_A { A_arbace_pprint_pprint_base__init_A_Init(); t := &A_arbace_pprint_pprint_base__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_pprint_base__init_A) Ctor() {}

func (t *A_arbace_pprint_pprint_base__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_pprint_base__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_pprint_base__init_A_class }

func (t *A_arbace_pprint_pprint_base__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_pprint_base__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_pprint_base__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_pprint_base__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_pprint_base__init_A); return ok }

func A_arbace_pprint_pprint_base__init_A_Cast(x any) *A_arbace_pprint_pprint_base__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_pprint_base__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_pprint_base__init_A_class)) }; return v }
