//line a2g_classes.ae:1
package aot_arbace_aot_main

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_aot_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_A_New()}; return nil }

var A_arbace_aot_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_main_A_new}

var A_arbace_aot_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_A"})

func init() { i := A_arbace_aot_main_A_class.Info(); i.IsInstance = A_arbace_aot_main_A_InstanceOf; i.Init = A_arbace_aot_main_A_Init; i.Table = A_arbace_aot_main_A_members; jrt.RegisterGoType(A_arbace_aot_main_A_class, reflect.TypeFor[A_arbace_aot_main_A]()) }

func A_arbace_aot_main_clean_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_clean_meta_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_clean_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_clean_meta_A_New()}; return nil }

func A_arbace_aot_main_clean_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_clean_meta_A_fn_class)}; return nil }

var A_arbace_aot_main_clean_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_clean_meta_A_invoke, New: A_arbace_aot_main_clean_meta_A_new, Get: A_arbace_aot_main_clean_meta_A_get}

var A_arbace_aot_main_clean_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$clean_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_A_class, Simple: "clean_meta", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_clean_meta_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_clean_meta_A_class.Info(); i.IsInstance = A_arbace_aot_main_clean_meta_A_InstanceOf; i.Init = A_arbace_aot_main_clean_meta_A_Init; i.Table = A_arbace_aot_main_clean_meta_A_members; jrt.RegisterGoType(A_arbace_aot_main_clean_meta_A_class, reflect.TypeFor[A_arbace_aot_main_clean_meta_A]()) }

func A_arbace_aot_main_compile_all_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_compile_all_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_A_New()}; return nil }

func A_arbace_aot_main_compile_all_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_A_invoke, New: A_arbace_aot_main_compile_all_A_new, Get: A_arbace_aot_main_compile_all_A_get}

var A_arbace_aot_main_compile_all_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_main_A_class, Simple: "compile_all", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_A_Init; i.Table = A_arbace_aot_main_compile_all_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_A]()) }

func A_arbace_aot_main_compile_all_fn__1684000132_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_fn__1684000132_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_fn__1684000132_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_fn__1684000132_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_fn__1684000132_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_fn__1684000132_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_fn__1684000132_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_fn__1684000132_A_invoke, New: A_arbace_aot_main_compile_all_fn__1684000132_A_new, Get: A_arbace_aot_main_compile_all_fn__1684000132_A_get}

var A_arbace_aot_main_compile_all_fn__1684000132_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$fn__1684000132", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_compile_all_A_class, Simple: "fn__1684000132", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_fn__1684000132_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_fn__1684000132_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_fn__1684000132_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_fn__1684000132_A_Init; i.Table = A_arbace_aot_main_compile_all_fn__1684000132_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_fn__1684000132_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_fn__1684000132_A]()) }

func A_arbace_aot_main_compile_all_fn__1684000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_fn__1684000137_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_fn__1684000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_fn__1684000137_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_fn__1684000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_fn__1684000137_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_fn__1684000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_fn__1684000137_A_invoke, New: A_arbace_aot_main_compile_all_fn__1684000137_A_new, Get: A_arbace_aot_main_compile_all_fn__1684000137_A_get}

var A_arbace_aot_main_compile_all_fn__1684000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$fn__1684000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_compile_all_A_class, Simple: "fn__1684000137", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_fn__1684000137_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_fn__1684000137_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_fn__1684000137_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_fn__1684000137_A_Init; i.Table = A_arbace_aot_main_compile_all_fn__1684000137_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_fn__1684000137_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_fn__1684000137_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_New()}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_get}

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000112__1684000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_compile_all_A_class, Simple: "iter__1684000112__1684000118", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_get}

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_A_class, Simple: "fn__1684000119", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_New()}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_get}

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_A_class, Simple: "iter__1684000114__1684000123", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_get}

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123$fn__1684000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_A_class, Simple: "fn__1684000124", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_get}

var A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123$fn__1684000124$fn__1684000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_A_class, Simple: "fn__1684000125", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000112__1684000118_fn__1684000119_iter__1684000114__1684000123_fn__1684000124_fn__1684000125_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_get}

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000139__1684000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_compile_all_A_class, Simple: "iter__1684000139__1684000143", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_get}

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_A_class, Simple: "fn__1684000144", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_New_O_O_O_I_O_O_O(args[0], args[1], args[2], args[3].(int32), args[4], args[5], args[6])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_get}

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_class, Simple: "fn__1684000145", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_get}

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000145$fn__1684000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_A_class, Simple: "fn__1684000149", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000145_fn__1684000149_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_get}

var A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000155", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_A_class, Simple: "fn__1684000155", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000139__1684000143_fn__1684000144_fn__1684000155_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_get}

var A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000159__1684000163", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_compile_all_A_class, Simple: "iter__1684000159__1684000163", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_get}

var A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000159__1684000163$fn__1684000164", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_A_class, Simple: "fn__1684000164", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_get}

var A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000159__1684000163$fn__1684000164$fn__1684000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_A_class, Simple: "fn__1684000165", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000159__1684000163_fn__1684000164_fn__1684000165_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_New()}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_get}

var A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000169__1684000173", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_compile_all_A_class, Simple: "iter__1684000169__1684000173", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_get}

var A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000169__1684000173$fn__1684000174", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_A_class, Simple: "fn__1684000174", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A]()) }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_fn_class)}; return nil }

var A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_invoke, New: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_new, Get: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_get}

var A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$compile_all$iter__1684000169__1684000173$fn__1684000174$fn__1684000175", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_A_class, Simple: "fn__1684000175", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_class.Info(); i.IsInstance = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_InstanceOf; i.Init = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_Init; i.Table = A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_members; jrt.RegisterGoType(A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A_class, reflect.TypeFor[A_arbace_aot_main_compile_all_iter__1684000169__1684000173_fn__1684000174_fn__1684000175_A]()) }

func A_arbace_aot_main_eval1684000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_eval1684000004_A_New()}; return nil }

var A_arbace_aot_main_eval1684000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_main_eval1684000004_A_new}

var A_arbace_aot_main_eval1684000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$eval1684000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_main_A_class, Simple: "eval1684000004", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_eval1684000004_A"})

func init() { i := A_arbace_aot_main_eval1684000004_A_class.Info(); i.IsInstance = A_arbace_aot_main_eval1684000004_A_InstanceOf; i.Table = A_arbace_aot_main_eval1684000004_A_members; jrt.RegisterGoType(A_arbace_aot_main_eval1684000004_A_class, reflect.TypeFor[A_arbace_aot_main_eval1684000004_A]()) }

func A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_New()}; return nil }

func A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_fn_class)}; return nil }

var A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_invoke, New: A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_new, Get: A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_get}

var A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$eval1684000004$loading__1927001464__auto____1684000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_eval1684000004_A_class, Simple: "loading__1927001464__auto____1684000005", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_class.Info(); i.IsInstance = A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_InstanceOf; i.Init = A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_Init; i.Table = A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_members; jrt.RegisterGoType(A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_class, reflect.TypeFor[A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A]()) }

func A_arbace_aot_main_eval1684000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_eval1684000008_A_New()}; return nil }

var A_arbace_aot_main_eval1684000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_main_eval1684000008_A_new}

var A_arbace_aot_main_eval1684000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$eval1684000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_main_A_class, Simple: "eval1684000008", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_eval1684000008_A"})

func init() { i := A_arbace_aot_main_eval1684000008_A_class.Info(); i.IsInstance = A_arbace_aot_main_eval1684000008_A_InstanceOf; i.Table = A_arbace_aot_main_eval1684000008_A_members; jrt.RegisterGoType(A_arbace_aot_main_eval1684000008_A_class, reflect.TypeFor[A_arbace_aot_main_eval1684000008_A]()) }

func A_arbace_aot_main_eval1684000008_fn__1684000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_eval1684000008_fn__1684000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_eval1684000008_fn__1684000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_eval1684000008_fn__1684000009_A_New()}; return nil }

func A_arbace_aot_main_eval1684000008_fn__1684000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_eval1684000008_fn__1684000009_A_fn_class)}; return nil }

var A_arbace_aot_main_eval1684000008_fn__1684000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_eval1684000008_fn__1684000009_A_invoke, New: A_arbace_aot_main_eval1684000008_fn__1684000009_A_new, Get: A_arbace_aot_main_eval1684000008_fn__1684000009_A_get}

var A_arbace_aot_main_eval1684000008_fn__1684000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$eval1684000008$fn__1684000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_eval1684000008_A_class, Simple: "fn__1684000009", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_eval1684000008_fn__1684000009_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_eval1684000008_fn__1684000009_A_class.Info(); i.IsInstance = A_arbace_aot_main_eval1684000008_fn__1684000009_A_InstanceOf; i.Init = A_arbace_aot_main_eval1684000008_fn__1684000009_A_Init; i.Table = A_arbace_aot_main_eval1684000008_fn__1684000009_A_members; jrt.RegisterGoType(A_arbace_aot_main_eval1684000008_fn__1684000009_A_class, reflect.TypeFor[A_arbace_aot_main_eval1684000008_fn__1684000009_A]()) }

func A_arbace_aot_main_events_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_events_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_events_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_events_A_New()}; return nil }

func A_arbace_aot_main_events_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_events_A_fn_class)}; return nil }

var A_arbace_aot_main_events_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_events_A_invoke, New: A_arbace_aot_main_events_A_new, Get: A_arbace_aot_main_events_A_get}

var A_arbace_aot_main_events_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$events", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_A_class, Simple: "events", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_events_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_events_A_class.Info(); i.IsInstance = A_arbace_aot_main_events_A_InstanceOf; i.Init = A_arbace_aot_main_events_A_Init; i.Table = A_arbace_aot_main_events_A_members; jrt.RegisterGoType(A_arbace_aot_main_events_A_class, reflect.TypeFor[A_arbace_aot_main_events_A]()) }

func A_arbace_aot_main_events_iter__1684000033__1684000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_events_iter__1684000033__1684000039_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_events_iter__1684000033__1684000039_A_New()}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_events_iter__1684000033__1684000039_A_fn_class)}; return nil }

var A_arbace_aot_main_events_iter__1684000033__1684000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_events_iter__1684000033__1684000039_A_invoke, New: A_arbace_aot_main_events_iter__1684000033__1684000039_A_new, Get: A_arbace_aot_main_events_iter__1684000033__1684000039_A_get}

var A_arbace_aot_main_events_iter__1684000033__1684000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$events$iter__1684000033__1684000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_events_A_class, Simple: "iter__1684000033__1684000039", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_events_iter__1684000033__1684000039_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_events_iter__1684000033__1684000039_A_class.Info(); i.IsInstance = A_arbace_aot_main_events_iter__1684000033__1684000039_A_InstanceOf; i.Init = A_arbace_aot_main_events_iter__1684000033__1684000039_A_Init; i.Table = A_arbace_aot_main_events_iter__1684000033__1684000039_A_members; jrt.RegisterGoType(A_arbace_aot_main_events_iter__1684000033__1684000039_A_class, reflect.TypeFor[A_arbace_aot_main_events_iter__1684000033__1684000039_A]()) }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_fn_class)}; return nil }

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_invoke, New: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_new, Get: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_get}

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_events_iter__1684000033__1684000039_A_class, Simple: "fn__1684000040", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_class.Info(); i.IsInstance = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_InstanceOf; i.Init = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_Init; i.Table = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_members; jrt.RegisterGoType(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_class, reflect.TypeFor[A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A]()) }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_New()}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_fn_class)}; return nil }

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_invoke, New: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_new, Get: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_get}

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_A_class, Simple: "iter__1684000035__1684000044", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_class.Info(); i.IsInstance = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_InstanceOf; i.Init = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_Init; i.Table = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_members; jrt.RegisterGoType(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_class, reflect.TypeFor[A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A]()) }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_fn_class)}; return nil }

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_invoke, New: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_new, Get: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_get}

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044$fn__1684000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_A_class, Simple: "fn__1684000045", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_class.Info(); i.IsInstance = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_InstanceOf; i.Init = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_Init; i.Table = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_members; jrt.RegisterGoType(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_class, reflect.TypeFor[A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A]()) }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_fn_class)}; return nil }

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_invoke, New: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_new, Get: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_get}

var A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044$fn__1684000045$fn__1684000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_A_class, Simple: "fn__1684000046", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_class.Info(); i.IsInstance = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_InstanceOf; i.Init = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_Init; i.Table = A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_members; jrt.RegisterGoType(A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A_class, reflect.TypeFor[A_arbace_aot_main_events_iter__1684000033__1684000039_fn__1684000040_iter__1684000035__1684000044_fn__1684000045_fn__1684000046_A]()) }

func A_arbace_aot_main_file_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_file_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_file_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_file_name_A_New()}; return nil }

func A_arbace_aot_main_file_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_file_name_A_fn_class)}; return nil }

var A_arbace_aot_main_file_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_file_name_A_invoke, New: A_arbace_aot_main_file_name_A_new, Get: A_arbace_aot_main_file_name_A_get}

var A_arbace_aot_main_file_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$file_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_A_class, Simple: "file_name", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_file_name_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_file_name_A_class.Info(); i.IsInstance = A_arbace_aot_main_file_name_A_InstanceOf; i.Init = A_arbace_aot_main_file_name_A_Init; i.Table = A_arbace_aot_main_file_name_A_members; jrt.RegisterGoType(A_arbace_aot_main_file_name_A_class, reflect.TypeFor[A_arbace_aot_main_file_name_A]()) }

func A_arbace_aot_main_forms__GT_lists_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_forms__GT_lists_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_aot_main_forms__GT_lists_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_forms__GT_lists_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_forms__GT_lists_A_New()}; return nil }

func A_arbace_aot_main_forms__GT_lists_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_forms__GT_lists_A_fn_class)}; return nil }

var A_arbace_aot_main_forms__GT_lists_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_forms__GT_lists_A_invoke, New: A_arbace_aot_main_forms__GT_lists_A_new, Get: A_arbace_aot_main_forms__GT_lists_A_get}

var A_arbace_aot_main_forms__GT_lists_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$forms__GT_lists", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_A_class, Simple: "forms__GT_lists", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_forms__GT_lists_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_forms__GT_lists_A_class.Info(); i.IsInstance = A_arbace_aot_main_forms__GT_lists_A_InstanceOf; i.Init = A_arbace_aot_main_forms__GT_lists_A_Init; i.Table = A_arbace_aot_main_forms__GT_lists_A_members; jrt.RegisterGoType(A_arbace_aot_main_forms__GT_lists_A_class, reflect.TypeFor[A_arbace_aot_main_forms__GT_lists_A]()) }

func A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_forms__GT_lists_fn__1684000104_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_fn_class)}; return nil }

var A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_invoke, New: A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_new, Get: A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_get}

var A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$forms__GT_lists$fn__1684000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_forms__GT_lists_A_class, Simple: "fn__1684000104", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_forms__GT_lists_fn__1684000104_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_class.Info(); i.IsInstance = A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_InstanceOf; i.Init = A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_Init; i.Table = A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_members; jrt.RegisterGoType(A_arbace_aot_main_forms__GT_lists_fn__1684000104_A_class, reflect.TypeFor[A_arbace_aot_main_forms__GT_lists_fn__1684000104_A]()) }

func A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_forms__GT_lists_fn__1684000106_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_fn_class)}; return nil }

var A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_invoke, New: A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_new, Get: A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_get}

var A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$forms__GT_lists$fn__1684000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_forms__GT_lists_A_class, Simple: "fn__1684000106", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_forms__GT_lists_fn__1684000106_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_class.Info(); i.IsInstance = A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_InstanceOf; i.Init = A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_Init; i.Table = A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_members; jrt.RegisterGoType(A_arbace_aot_main_forms__GT_lists_fn__1684000106_A_class, reflect.TypeFor[A_arbace_aot_main_forms__GT_lists_fn__1684000106_A]()) }

func A_arbace_aot_main_interfaces_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_A_New()}; return nil }

func A_arbace_aot_main_interfaces_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_A_invoke, New: A_arbace_aot_main_interfaces_A_new, Get: A_arbace_aot_main_interfaces_A_get}

var A_arbace_aot_main_interfaces_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_A_class, Simple: "interfaces", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_A_Init; i.Table = A_arbace_aot_main_interfaces_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_A]()) }

func A_arbace_aot_main_interfaces_fn__1684000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_fn__1684000066_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_fn__1684000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_fn__1684000066_A_New()}; return nil }

func A_arbace_aot_main_interfaces_fn__1684000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_fn__1684000066_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_fn__1684000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_fn__1684000066_A_invoke, New: A_arbace_aot_main_interfaces_fn__1684000066_A_new, Get: A_arbace_aot_main_interfaces_fn__1684000066_A_get}

var A_arbace_aot_main_interfaces_fn__1684000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$fn__1684000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_interfaces_A_class, Simple: "fn__1684000066", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_fn__1684000066_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_fn__1684000066_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_fn__1684000066_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_fn__1684000066_A_Init; i.Table = A_arbace_aot_main_interfaces_fn__1684000066_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_fn__1684000066_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_fn__1684000066_A]()) }

func A_arbace_aot_main_interfaces_fn__1684000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_fn__1684000068_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_fn__1684000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_fn__1684000068_A_New()}; return nil }

func A_arbace_aot_main_interfaces_fn__1684000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_fn__1684000068_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_fn__1684000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_fn__1684000068_A_invoke, New: A_arbace_aot_main_interfaces_fn__1684000068_A_new, Get: A_arbace_aot_main_interfaces_fn__1684000068_A_get}

var A_arbace_aot_main_interfaces_fn__1684000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$fn__1684000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_interfaces_A_class, Simple: "fn__1684000068", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_fn__1684000068_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_fn__1684000068_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_fn__1684000068_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_fn__1684000068_A_Init; i.Table = A_arbace_aot_main_interfaces_fn__1684000068_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_fn__1684000068_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_fn__1684000068_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_interfaces_A_class, Simple: "iter__1684000070__1684000074", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_A_class, Simple: "fn__1684000075", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_class, Simple: "fn__1684000076", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_New()}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_A_class, Simple: "iter__1684000077__1684000081", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081$fn__1684000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_A_class, Simple: "fn__1684000082", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081$fn__1684000082$fn__1684000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_A_class, Simple: "fn__1684000083", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_fn__1684000076_iter__1684000077__1684000081_fn__1684000082_fn__1684000083_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_New()}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_A_class, Simple: "iter__1684000088__1684000092", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092$fn__1684000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_A_class, Simple: "fn__1684000093", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A]()) }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_fn_class)}; return nil }

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_invoke, New: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_new, Get: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_get}

var A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092$fn__1684000093$fn__1684000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_A_class, Simple: "fn__1684000094", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_class.Info(); i.IsInstance = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_InstanceOf; i.Init = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_Init; i.Table = A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_members; jrt.RegisterGoType(A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A_class, reflect.TypeFor[A_arbace_aot_main_interfaces_iter__1684000070__1684000074_fn__1684000075_iter__1684000088__1684000092_fn__1684000093_fn__1684000094_A]()) }

func A_arbace_aot_main_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_A_New()}; return nil }

func A_arbace_aot_main_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_A_fn_class)}; return nil }

var A_arbace_aot_main_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_A_invoke, New: A_arbace_aot_main_run_A_new, Get: A_arbace_aot_main_run_A_get}

var A_arbace_aot_main_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_main_A_class, Simple: "run", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_A_InstanceOf; i.Init = A_arbace_aot_main_run_A_Init; i.Table = A_arbace_aot_main_run_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_A_class, reflect.TypeFor[A_arbace_aot_main_run_A]()) }

func A_arbace_aot_main_run_fn__1684000207_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000207_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_fn__1684000207_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000207_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_fn__1684000207_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000207_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000207_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000207_A_invoke, New: A_arbace_aot_main_run_fn__1684000207_A_new, Get: A_arbace_aot_main_run_fn__1684000207_A_get}

var A_arbace_aot_main_run_fn__1684000207_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000207", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "fn__1684000207", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000207_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000207_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000207_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000207_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000207_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000207_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000207_A]()) }

func A_arbace_aot_main_run_fn__1684000261_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000261_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_fn__1684000261_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000261_A_New()}; return nil }

func A_arbace_aot_main_run_fn__1684000261_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000261_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000261_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000261_A_invoke, New: A_arbace_aot_main_run_fn__1684000261_A_new, Get: A_arbace_aot_main_run_fn__1684000261_A_get}

var A_arbace_aot_main_run_fn__1684000261_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000261", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "fn__1684000261", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000261_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000261_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000261_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000261_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000261_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000261_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000261_A]()) }

func A_arbace_aot_main_run_fn__1684000263_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000263_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_fn__1684000263_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000263_A_New()}; return nil }

func A_arbace_aot_main_run_fn__1684000263_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000263_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000263_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000263_A_invoke, New: A_arbace_aot_main_run_fn__1684000263_A_new, Get: A_arbace_aot_main_run_fn__1684000263_A_get}

var A_arbace_aot_main_run_fn__1684000263_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000263", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "fn__1684000263", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000263_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000263_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000263_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000263_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000263_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000263_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000263_A]()) }

func A_arbace_aot_main_run_fn__1684000267_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000267_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_fn__1684000267_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000267_A_New()}; return nil }

func A_arbace_aot_main_run_fn__1684000267_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000267_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000267_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000267_A_invoke, New: A_arbace_aot_main_run_fn__1684000267_A_new, Get: A_arbace_aot_main_run_fn__1684000267_A_get}

var A_arbace_aot_main_run_fn__1684000267_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000267", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "fn__1684000267", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000267_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000267_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000267_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000267_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000267_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000267_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000267_A]()) }

func A_arbace_aot_main_run_fn__1684000269_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000269_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000269_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000269_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000269_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000269_A_invoke, New: A_arbace_aot_main_run_fn__1684000269_A_new, Get: A_arbace_aot_main_run_fn__1684000269_A_get}

var A_arbace_aot_main_run_fn__1684000269_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000269", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "fn__1684000269", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000269_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000269_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000269_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000269_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000269_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000269_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000269_A]()) }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_invoke, New: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_new, Get: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_get}

var A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_fn__1684000269_A_class, Simple: "iter__1684000270__1684000274", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A]()) }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_invoke, New: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_new, Get: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_get}

var A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274$fn__1684000275", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_A_class, Simple: "fn__1684000275", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A]()) }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_invoke, New: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_new, Get: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_get}

var A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274$fn__1684000275$fn__1684000276", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_A_class, Simple: "fn__1684000276", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000269_iter__1684000270__1684000274_fn__1684000275_fn__1684000276_A]()) }

func A_arbace_aot_main_run_fn__1684000291_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000291_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_fn__1684000291_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000291_A_New()}; return nil }

func A_arbace_aot_main_run_fn__1684000291_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000291_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000291_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000291_A_invoke, New: A_arbace_aot_main_run_fn__1684000291_A_new, Get: A_arbace_aot_main_run_fn__1684000291_A_get}

var A_arbace_aot_main_run_fn__1684000291_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000291", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "fn__1684000291", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000291_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000291_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000291_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000291_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000291_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000291_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000291_A]()) }

func A_arbace_aot_main_run_fn__1684000293_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_fn__1684000293_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_fn__1684000293_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_fn__1684000293_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_fn__1684000293_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_fn__1684000293_A_fn_class)}; return nil }

var A_arbace_aot_main_run_fn__1684000293_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_fn__1684000293_A_invoke, New: A_arbace_aot_main_run_fn__1684000293_A_new, Get: A_arbace_aot_main_run_fn__1684000293_A_get}

var A_arbace_aot_main_run_fn__1684000293_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$fn__1684000293", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "fn__1684000293", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_fn__1684000293_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_fn__1684000293_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_fn__1684000293_A_InstanceOf; i.Init = A_arbace_aot_main_run_fn__1684000293_A_Init; i.Table = A_arbace_aot_main_run_fn__1684000293_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_fn__1684000293_A_class, reflect.TypeFor[A_arbace_aot_main_run_fn__1684000293_A]()) }

func A_arbace_aot_main_run_iter__1684000187__1684000191_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000187__1684000191_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_iter__1684000187__1684000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000187__1684000191_A_New()}; return nil }

func A_arbace_aot_main_run_iter__1684000187__1684000191_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000187__1684000191_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000187__1684000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000187__1684000191_A_invoke, New: A_arbace_aot_main_run_iter__1684000187__1684000191_A_new, Get: A_arbace_aot_main_run_iter__1684000187__1684000191_A_get}

var A_arbace_aot_main_run_iter__1684000187__1684000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000187__1684000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "iter__1684000187__1684000191", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000187__1684000191_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000187__1684000191_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000187__1684000191_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000187__1684000191_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000187__1684000191_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000187__1684000191_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000187__1684000191_A]()) }

func A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_invoke, New: A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_new, Get: A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_get}

var A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000187__1684000191$fn__1684000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000187__1684000191_A_class, Simple: "fn__1684000192", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A]()) }

func A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_invoke, New: A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_new, Get: A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_get}

var A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000187__1684000191$fn__1684000192$fn__1684000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_A_class, Simple: "fn__1684000193", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000187__1684000191_fn__1684000192_fn__1684000193_A]()) }

func A_arbace_aot_main_run_iter__1684000197__1684000201_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000197__1684000201_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_iter__1684000197__1684000201_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000197__1684000201_A_New()}; return nil }

func A_arbace_aot_main_run_iter__1684000197__1684000201_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000197__1684000201_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000197__1684000201_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000197__1684000201_A_invoke, New: A_arbace_aot_main_run_iter__1684000197__1684000201_A_new, Get: A_arbace_aot_main_run_iter__1684000197__1684000201_A_get}

var A_arbace_aot_main_run_iter__1684000197__1684000201_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000197__1684000201", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "iter__1684000197__1684000201", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000197__1684000201_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000197__1684000201_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000197__1684000201_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000197__1684000201_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000197__1684000201_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000197__1684000201_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000197__1684000201_A]()) }

func A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_invoke, New: A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_new, Get: A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_get}

var A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000197__1684000201$fn__1684000202", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000197__1684000201_A_class, Simple: "fn__1684000202", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A]()) }

func A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_invoke, New: A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_new, Get: A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_get}

var A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000197__1684000201$fn__1684000202$fn__1684000203", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_A_class, Simple: "fn__1684000203", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000197__1684000201_fn__1684000202_fn__1684000203_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_A_New_O_O_O_J(args[0], args[1], args[2], args[3].(int64))}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "iter__1684000219__1684000223", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_New_O_O_O_O_O_J(args[0], args[1], args[2], args[3], args[4], args[5].(int64))}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_A_class, Simple: "fn__1684000224", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_New_O_O_O_I_O_J_O(args[0], args[1], args[2], args[3].(int32), args[4], args[5].(int64), args[6])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;JLjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_class, Simple: "fn__1684000225", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_New_O_O_O_O_J(args[0], args[1], args[2], args[3], args[4].(int64))}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_A_class, Simple: "fn__1684000226", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226$fn__1684000234", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_class, Simple: "fn__1684000234", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000234_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226$fn__1684000239", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_A_class, Simple: "fn__1684000239", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000225_fn__1684000226_fn__1684000239_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_New_O_O_O_O_J(args[0], args[1], args[2], args[3], args[4].(int64))}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_A_class, Simple: "fn__1684000243", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243$fn__1684000251", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_class, Simple: "fn__1684000251", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000251_A]()) }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_invoke, New: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_new, Get: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_get}

var A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243$fn__1684000256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_A_class, Simple: "fn__1684000256", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000219__1684000223_fn__1684000224_fn__1684000243_fn__1684000256_A]()) }

func A_arbace_aot_main_run_iter__1684000281__1684000285_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000281__1684000285_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_iter__1684000281__1684000285_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000281__1684000285_A_New()}; return nil }

func A_arbace_aot_main_run_iter__1684000281__1684000285_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000281__1684000285_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000281__1684000285_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000281__1684000285_A_invoke, New: A_arbace_aot_main_run_iter__1684000281__1684000285_A_new, Get: A_arbace_aot_main_run_iter__1684000281__1684000285_A_get}

var A_arbace_aot_main_run_iter__1684000281__1684000285_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000281__1684000285", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "iter__1684000281__1684000285", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000281__1684000285_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000281__1684000285_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000281__1684000285_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000281__1684000285_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000281__1684000285_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000281__1684000285_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000281__1684000285_A]()) }

func A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_invoke, New: A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_new, Get: A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_get}

var A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000281__1684000285$fn__1684000286", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000281__1684000285_A_class, Simple: "fn__1684000286", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A]()) }

func A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_fn_class)}; return nil }

var A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_invoke, New: A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_new, Get: A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_get}

var A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$iter__1684000281__1684000285$fn__1684000286$fn__1684000287", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_A_class, Simple: "fn__1684000287", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_InstanceOf; i.Init = A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_Init; i.Table = A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A_class, reflect.TypeFor[A_arbace_aot_main_run_iter__1684000281__1684000285_fn__1684000286_fn__1684000287_A]()) }

func A_arbace_aot_main_run_ns_of__1684000265_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_run_ns_of__1684000265_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_run_ns_of__1684000265_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_run_ns_of__1684000265_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_run_ns_of__1684000265_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_run_ns_of__1684000265_A_fn_class)}; return nil }

var A_arbace_aot_main_run_ns_of__1684000265_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_run_ns_of__1684000265_A_invoke, New: A_arbace_aot_main_run_ns_of__1684000265_A_new, Get: A_arbace_aot_main_run_ns_of__1684000265_A_get}

var A_arbace_aot_main_run_ns_of__1684000265_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$run$ns_of__1684000265", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_run_A_class, Simple: "ns_of__1684000265", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_run_ns_of__1684000265_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_run_ns_of__1684000265_A_class.Info(); i.IsInstance = A_arbace_aot_main_run_ns_of__1684000265_A_InstanceOf; i.Init = A_arbace_aot_main_run_ns_of__1684000265_A_Init; i.Table = A_arbace_aot_main_run_ns_of__1684000265_A_members; jrt.RegisterGoType(A_arbace_aot_main_run_ns_of__1684000265_A_class, reflect.TypeFor[A_arbace_aot_main_run_ns_of__1684000265_A]()) }

func A_arbace_aot_main_source_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_source_classes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_source_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_source_classes_A_New()}; return nil }

func A_arbace_aot_main_source_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_source_classes_A_fn_class)}; return nil }

var A_arbace_aot_main_source_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_source_classes_A_invoke, New: A_arbace_aot_main_source_classes_A_new, Get: A_arbace_aot_main_source_classes_A_get}

var A_arbace_aot_main_source_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$source_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_A_class, Simple: "source_classes", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_source_classes_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_source_classes_A_class.Info(); i.IsInstance = A_arbace_aot_main_source_classes_A_InstanceOf; i.Init = A_arbace_aot_main_source_classes_A_Init; i.Table = A_arbace_aot_main_source_classes_A_members; jrt.RegisterGoType(A_arbace_aot_main_source_classes_A_class, reflect.TypeFor[A_arbace_aot_main_source_classes_A]()) }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_New()}; return nil }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_fn_class)}; return nil }

var A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_invoke, New: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_new, Get: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_get}

var A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$source_classes$iter__1684000053__1684000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_source_classes_A_class, Simple: "iter__1684000053__1684000057", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_class.Info(); i.IsInstance = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_InstanceOf; i.Init = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_Init; i.Table = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_members; jrt.RegisterGoType(A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_class, reflect.TypeFor[A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A]()) }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_fn_class)}; return nil }

var A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_invoke, New: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_new, Get: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_get}

var A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$source_classes$iter__1684000053__1684000057$fn__1684000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_A_class, Simple: "fn__1684000058", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_class.Info(); i.IsInstance = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_InstanceOf; i.Init = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_Init; i.Table = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_members; jrt.RegisterGoType(A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_class, reflect.TypeFor[A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A]()) }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_fn_class)}; return nil }

var A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_invoke, New: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_new, Get: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_get}

var A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$source_classes$iter__1684000053__1684000057$fn__1684000058$fn__1684000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_A_class, Simple: "fn__1684000059", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_class.Info(); i.IsInstance = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_InstanceOf; i.Init = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_Init; i.Table = A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_members; jrt.RegisterGoType(A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A_class, reflect.TypeFor[A_arbace_aot_main_source_classes_iter__1684000053__1684000057_fn__1684000058_fn__1684000059_A]()) }

func A_arbace_aot_main_units_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_units_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_A_New()}; return nil }

func A_arbace_aot_main_units_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_A_fn_class)}; return nil }

var A_arbace_aot_main_units_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_A_invoke, New: A_arbace_aot_main_units_A_new, Get: A_arbace_aot_main_units_A_get}

var A_arbace_aot_main_units_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_A_class, Simple: "units", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_A_InstanceOf; i.Init = A_arbace_aot_main_units_A_Init; i.Table = A_arbace_aot_main_units_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_A_class, reflect.TypeFor[A_arbace_aot_main_units_A]()) }

func A_arbace_aot_main_units_fn__1684000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_fn__1684000014_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_units_fn__1684000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_fn__1684000014_A_New()}; return nil }

func A_arbace_aot_main_units_fn__1684000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_fn__1684000014_A_fn_class)}; return nil }

var A_arbace_aot_main_units_fn__1684000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_fn__1684000014_A_invoke, New: A_arbace_aot_main_units_fn__1684000014_A_new, Get: A_arbace_aot_main_units_fn__1684000014_A_get}

var A_arbace_aot_main_units_fn__1684000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units$fn__1684000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_units_A_class, Simple: "fn__1684000014", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_fn__1684000014_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_fn__1684000014_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_fn__1684000014_A_InstanceOf; i.Init = A_arbace_aot_main_units_fn__1684000014_A_Init; i.Table = A_arbace_aot_main_units_fn__1684000014_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_fn__1684000014_A_class, reflect.TypeFor[A_arbace_aot_main_units_fn__1684000014_A]()) }

func A_arbace_aot_main_units_fn__1684000016_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_fn__1684000016_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_units_fn__1684000016_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_fn__1684000016_A_New()}; return nil }

func A_arbace_aot_main_units_fn__1684000016_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_fn__1684000016_A_fn_class)}; return nil }

var A_arbace_aot_main_units_fn__1684000016_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_fn__1684000016_A_invoke, New: A_arbace_aot_main_units_fn__1684000016_A_new, Get: A_arbace_aot_main_units_fn__1684000016_A_get}

var A_arbace_aot_main_units_fn__1684000016_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units$fn__1684000016", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_units_A_class, Simple: "fn__1684000016", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_fn__1684000016_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_fn__1684000016_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_fn__1684000016_A_InstanceOf; i.Init = A_arbace_aot_main_units_fn__1684000016_A_Init; i.Table = A_arbace_aot_main_units_fn__1684000016_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_fn__1684000016_A_class, reflect.TypeFor[A_arbace_aot_main_units_fn__1684000016_A]()) }

func A_arbace_aot_main_units_iter__1684000018__1684000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_iter__1684000018__1684000022_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_iter__1684000018__1684000022_A_New_O(args[0])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_iter__1684000018__1684000022_A_fn_class)}; return nil }

var A_arbace_aot_main_units_iter__1684000018__1684000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_iter__1684000018__1684000022_A_invoke, New: A_arbace_aot_main_units_iter__1684000018__1684000022_A_new, Get: A_arbace_aot_main_units_iter__1684000018__1684000022_A_get}

var A_arbace_aot_main_units_iter__1684000018__1684000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units$iter__1684000018__1684000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_units_A_class, Simple: "iter__1684000018__1684000022", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_iter__1684000018__1684000022_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_iter__1684000018__1684000022_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_iter__1684000018__1684000022_A_InstanceOf; i.Init = A_arbace_aot_main_units_iter__1684000018__1684000022_A_Init; i.Table = A_arbace_aot_main_units_iter__1684000018__1684000022_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_iter__1684000018__1684000022_A_class, reflect.TypeFor[A_arbace_aot_main_units_iter__1684000018__1684000022_A]()) }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_fn_class)}; return nil }

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_invoke, New: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_new, Get: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_get}

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_units_iter__1684000018__1684000022_A_class, Simple: "fn__1684000023", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_InstanceOf; i.Init = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_Init; i.Table = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_class, reflect.TypeFor[A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A]()) }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_fn_class)}; return nil }

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_invoke, New: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_new, Get: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_get}

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000024", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_class, Simple: "fn__1684000024", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_InstanceOf; i.Init = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_Init; i.Table = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_class, reflect.TypeFor[A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A]()) }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_New()}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_fn_class)}; return nil }

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_invoke, New: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_new, Get: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_get}

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000024$fn__1684000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_A_class, Simple: "fn__1684000025", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_InstanceOf; i.Init = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_Init; i.Table = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A_class, reflect.TypeFor[A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000024_fn__1684000025_A]()) }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_New()}; return nil }

func A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_fn_class)}; return nil }

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_invoke, New: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_new, Get: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_get}

var A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_A_class, Simple: "fn__1684000028", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_class.Info(); i.IsInstance = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_InstanceOf; i.Init = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_Init; i.Table = A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_members; jrt.RegisterGoType(A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A_class, reflect.TypeFor[A_arbace_aot_main_units_iter__1684000018__1684000022_fn__1684000023_fn__1684000028_A]()) }

func A_arbace_aot_main_write_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_main_write_form_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_main_write_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main_write_form_A_New()}; return nil }

func A_arbace_aot_main_write_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_main_write_form_A_fn_class)}; return nil }

var A_arbace_aot_main_write_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_main_write_form_A_invoke, New: A_arbace_aot_main_write_form_A_new, Get: A_arbace_aot_main_write_form_A_get}

var A_arbace_aot_main_write_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main$write_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_main_A_class, Simple: "write_form", Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main_write_form_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main_write_form_A_class.Info(); i.IsInstance = A_arbace_aot_main_write_form_A_InstanceOf; i.Init = A_arbace_aot_main_write_form_A_Init; i.Table = A_arbace_aot_main_write_form_A_members; jrt.RegisterGoType(A_arbace_aot_main_write_form_A_class, reflect.TypeFor[A_arbace_aot_main_write_form_A]()) }

func A_arbace_aot_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_aot_main__init_A_Load__O(); case 1: return A_arbace_aot_main__init_A_Unit0__O(); case 2: return A_arbace_aot_main__init_A_Unit1__O(); case 3: return A_arbace_aot_main__init_A_Unit10__O(); case 4: return A_arbace_aot_main__init_A_Unit11__O(); case 5: return A_arbace_aot_main__init_A_Unit12__O(); case 6: return A_arbace_aot_main__init_A_Unit13__O(); case 7: return A_arbace_aot_main__init_A_Unit2__O(); case 8: return A_arbace_aot_main__init_A_Unit3__O(); case 9: return A_arbace_aot_main__init_A_Unit4__O(); case 10: return A_arbace_aot_main__init_A_Unit5__O(); case 11: return A_arbace_aot_main__init_A_Unit6__O(); case 12: return A_arbace_aot_main__init_A_Unit7__O(); case 13: return A_arbace_aot_main__init_A_Unit8__O(); case 14: return A_arbace_aot_main__init_A_Unit9__O()}; return nil }

func A_arbace_aot_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_main__init_A_New()}; return nil }

var A_arbace_aot_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_aot_main__init_A_invoke, New: A_arbace_aot_main__init_A_new}

var A_arbace_aot_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_main.A_arbace_aot_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_aot_main__init_A_class.Info(); i.IsInstance = A_arbace_aot_main__init_A_InstanceOf; i.Init = A_arbace_aot_main__init_A_Init; i.Table = A_arbace_aot_main__init_A_members; jrt.RegisterGoType(A_arbace_aot_main__init_A_class, reflect.TypeFor[A_arbace_aot_main__init_A]()) }
