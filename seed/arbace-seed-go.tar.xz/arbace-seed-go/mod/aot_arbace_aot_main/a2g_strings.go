//line a2g_strings.ae:1
package aot_arbace_aot_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn10,arbace.setyn14,arbace.java.ioyn2,ioyn15,arbace.aot.emityn1,ekn3,docks3,aot4,linekn4,linekn6,columnkn4,elsekn3,srckn6,loaderkn5,errorkn6,errorskn4,formkn4,namekn8,compiledkn6,failedkn7,classesyn2,nsyn6,arbaceyn4,loadkn6,holderkn4,kindyn5,in-nsyn5,quotev11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V1,R4,V3,R5,R2,R6,V3,R7,R2,R8,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.aot.mainm2,R9,s569,Standalone S6: compiles the namespaces the program prepared (Compiler$AST/units, recorded\n  with ARBACE_COMPILE set) to class forms (arbace.aot.emit), a tree a2g reads as one more input\n  (bin/a2g --input DIR).\n\n  (run OUT SOURCES): SOURCES the source paths to compile (arbace/walk.ae ...), or nil for every\n  source recorded. Writes OUT/arbace.ae (the namespace of the classes' package, loading the\n  others), one file per loader class (aot_SCRIPTBASE__init.ae) and per holder class\n  (aot_HOLDER.ae), and OUT/aot.edn (the sources compiled, those that failed and why).v11,arbace.core13,*loaded-libs*v11,arbace.core7,ex-infov11,arbace.core8,distinctv11,arbace.core8,group-byv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core4,mapvv11,arbace.core3,vecv11,arbace.core10,chunk-consv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core3,mapv11,arbace.core6,concatv11,arbace.core3,setv11,arbace.core7,string?v15,arbace.aot.emit6,destubv15,arbace.aot.main6,eventsv11,arbace.core4,intov11,arbace.core6,filterv15,arbace.aot.emit16,interface-recordR10,v11,arbace.core6,dissocv11,arbace.core5,assocv11,arbace.core9,not-emptyR11,R12,v11,arbace.core4,seq?v15,arbace.aot.main10,clean-metav11,arbace.core9,with-metav11,arbace.core7,vector?v11,arbace.core7,symbol?R13,v11,arbace.core5,applyv11,arbace.core3,notv11,arbace.core4,listv15,arbace.aot.main12,forms->listsv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core11,*print-dup*v11,arbace.core22,*print-namespace-maps*v11,arbace.core2,prv13,arbace.string7,replacev11,arbace.core6,removev11,arbace.core4,atomv11,arbace.core5,doallv11,arbace.core6,empty?v10,arbace.set5,unionv11,arbace.core4,compv15,arbace.aot.main14,source-classesv11,arbace.core6,secondv10,arbace.set10,differencev11,arbace.core5,mergev15,arbace.aot.main10,interfacesR14,R15,v15,arbace.aot.emit11,emit-sourceR16,v11,arbace.core6,pr-strv11,arbace.core6,reset!v11,arbace.core7,ex-datav11,arbace.core6,get-inR17,v15,arbace.aot.main5,unitsv15,arbace.aot.main11,compile-allv14,arbace.java.io4,filev15,arbace.aot.emit11,class-formsv15,arbace.aot.main9,file-nameR18,R19,v11,arbace.core3,strR20,R21,R22,v14,arbace.java.io6,writerv15,arbace.aot.main10,write-formML2,R23,R24,m4,R11,i127,R12,i22,R25,v11,arbace.core4,subsl0,v11,arbace.core4,nextv13,arbace.string10,ends-with?v11,arbace.core9,contains?R26,R27,v11,arbace.core4,spitC16,java.lang.Threadv11,arbace.core9,bound-fn*v11,arbace.core8,take-nthv11,arbace.core4,dropML2,R28,L2,R29,R24,m4,R11,i146,R12,i51,v11,arbace.core5,rangev11,arbace.core4,run!v11,arbace.core3,prnv11,arbace.core10,sorted-mapv11,arbace.core4,sortv11,arbace.core4,vals")

var Lit_1 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118")

var Lit_2 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$fn__1684000132")

var Lit_3 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$fn__1684000137")

var Lit_4 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143")

var Lit_5 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000159__1684000163")

var Lit_6 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000169__1684000173")

var Lit_7 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119")

var Lit_8 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123")

var Lit_9 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123$fn__1684000124")

var Lit_10 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123$fn__1684000124$fn__1684000125")

var Lit_11 *jrt.String = jrt.Intern("proxy")

var Lit_12 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144")

var Lit_13 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000145")

var Lit_14 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000155")

var Lit_15 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000145$fn__1684000149")

var Lit_16 *jrt.String = jrt.Intern(" ")

var Lit_17 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000159__1684000163$fn__1684000164")

var Lit_18 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000159__1684000163$fn__1684000164$fn__1684000165")

var Lit_19 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000169__1684000173$fn__1684000174")

var Lit_20 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000169__1684000173$fn__1684000174$fn__1684000175")

var Lit_21 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_22 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039")

var Lit_23 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040")

var Lit_24 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044")

var Lit_25 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044$fn__1684000045")

var Lit_26 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044$fn__1684000045$fn__1684000046")

var Lit_27 *jrt.String = jrt.Intern("aot_")

var Lit_28 *jrt.String = jrt.Intern(".ae")

var Lit_29 *jrt.String = jrt.Intern(".")

var Lit_30 *jrt.String = jrt.Intern("_")

var Lit_31 *jrt.String = jrt.Intern("arbace.aot.main$forms__GT_lists$fn__1684000104")

var Lit_32 *jrt.String = jrt.Intern("arbace.aot.main$forms__GT_lists$fn__1684000106")

var Lit_33 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$fn__1684000066")

var Lit_34 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$fn__1684000068")

var Lit_35 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074")

var Lit_36 *jrt.String = jrt.Intern("imethod")

var Lit_37 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075")

var Lit_38 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076")

var Lit_39 *jrt.String = jrt.Intern("iface")

var Lit_40 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092")

var Lit_41 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081")

var Lit_42 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081$fn__1684000082")

var Lit_43 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081$fn__1684000082$fn__1684000083")

var Lit_44 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092$fn__1684000093")

var Lit_45 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092$fn__1684000093$fn__1684000094")

var Lit_46 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000187__1684000191")

var Lit_47 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000197__1684000201")

var Lit_48 *jrt.String = jrt.Intern("arbace")

var Lit_49 *jrt.String = jrt.Intern("arbace.ae")

var Lit_50 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000207")

var Lit_51 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223")

var Lit_52 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000261")

var Lit_53 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000263")

var Lit_54 *jrt.String = jrt.Intern("arbace.aot.main$run$ns_of__1684000265")

var Lit_55 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000267")

var Lit_56 *jrt.String = jrt.Intern("packages.edn")

var Lit_57 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269")

var Lit_58 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000281__1684000285")

var Lit_59 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000291")

var Lit_60 *jrt.String = jrt.Intern("aot.edn")

var Lit_61 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000293")

var Lit_62 *jrt.String = jrt.Intern("arbace/")

var Lit_63 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274")

var Lit_64 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274$fn__1684000275")

var Lit_65 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274$fn__1684000275$fn__1684000276")

var Lit_66 *jrt.String = jrt.Intern("/")

var Lit_67 *jrt.String = jrt.Intern("-")

var Lit_68 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000187__1684000191$fn__1684000192")

var Lit_69 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000187__1684000191$fn__1684000192$fn__1684000193")

var Lit_70 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000197__1684000201$fn__1684000202")

var Lit_71 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000197__1684000201$fn__1684000202$fn__1684000203")

var Lit_72 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224")

var Lit_73 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225")

var Lit_74 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243")

var Lit_75 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226")

var Lit_76 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226$fn__1684000234")

var Lit_77 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226$fn__1684000239")

var Lit_78 *jrt.String = jrt.Intern(";; Compiled by arbace.aot (standalone S6)")

var Lit_79 *jrt.String = jrt.Intern(". Regenerated by the build.\n\n")

var Lit_80 *jrt.String = jrt.Intern(" from ")

var Lit_81 *jrt.String = jrt.Intern(": its loader")

var Lit_82 *jrt.String = jrt.Intern(": the classes of a namespace")

var Lit_83 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243$fn__1684000251")

var Lit_84 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243$fn__1684000256")

var Lit_85 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000281__1684000285$fn__1684000286")

var Lit_86 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000281__1684000285$fn__1684000286$fn__1684000287")

var Lit_87 *jrt.String = jrt.Intern("__init")

var Lit_88 *jrt.String = jrt.Intern("arbace.aot.main$source_classes$iter__1684000053__1684000057")

var Lit_89 *jrt.String = jrt.Intern("arbace.aot.main$source_classes$iter__1684000053__1684000057$fn__1684000058")

var Lit_90 *jrt.String = jrt.Intern("arbace.aot.main$source_classes$iter__1684000053__1684000057$fn__1684000058$fn__1684000059")

var Lit_91 *jrt.String = jrt.Intern("aot: no units recorded (ARBACE_COMPILE not set)")

var Lit_92 *jrt.String = jrt.Intern("arbace.aot.main$units$fn__1684000014")

var Lit_93 *jrt.String = jrt.Intern("arbace.aot.main$units$fn__1684000016")

var Lit_94 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022")

var Lit_95 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023")

var Lit_96 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000024")

var Lit_97 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000028")

var Lit_98 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000024$fn__1684000025")

var Lit_99 *jrt.String = jrt.Intern("\n\n")

var Lit_100 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn4,linekn6,columnkn4,filekn7,privateyn2,ssyn1,myn1,fyn4,linekn3,tagyn14,java.io.Writeryn6,Stringyn2,usyn4,wantyn3,outyn7,sourcesv11,arbace.core5,in-nsMyn15,arbace.aot.mainm2,R0,s569,Standalone S6: compiles the namespaces the program prepared (Compiler$AST/units, recorded\n  with ARBACE_COMPILE set) to class forms (arbace.aot.emit), a tree a2g reads as one more input\n  (bin/a2g --input DIR).\n\n  (run OUT SOURCES): SOURCES the source paths to compile (arbace/walk.ae ...), or nil for every\n  source recorded. Writes OUT/arbace.ae (the namespace of the classes' package, loading the\n  others), one file per loader class (aot_SCRIPTBASE__init.ae) and per holder class\n  (aot_HOLDER.ae), and OUT/aot.edn (the sources compiled, those that failed and why).m2,R0,s569,Standalone S6: compiles the namespaces the program prepared (Compiler$AST/units, recorded\n  with ARBACE_COMPILE set) to class forms (arbace.aot.emit), a tree a2g reads as one more input\n  (bin/a2g --input DIR).\n\n  (run OUT SOURCES): SOURCES the source paths to compile (arbace/walk.ae ...), or nil for every\n  source recorded. Writes OUT/arbace.ae (the namespace of the classes' package, loading the\n  others), one file per loader class (aot_SCRIPTBASE__init.ae) and per holder class\n  (aot_HOLDER.ae), and OUT/aot.edn (the sources compiled, those that failed and why).R1,v15,arbace.aot.main5,unitsm10,R2,L1,V0,R0,s92,The recorded units by source, in the order of their first unit: [[src [[unit um] ...]] ...].R3,i16,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main6,eventsm10,R6,TR2,L1,V1,R7,R3,i25,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main14,source-classesm12,R6,TR2,L1,V1,R7,R0,s107,The names of the classes the events of a source's units make at run time (deftypes,\n  interfaces, proxies).R3,i28,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main10,interfacesm12,R6,TR2,L1,V1,R7,R0,s95,The interfaces gen-interface made in a source's units (events iface, imethod): name →\n  record.R3,i37,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main10,clean-metam12,R6,TR2,L1,V1,R8,R0,s152,The metadata m of an emitted form for printing: the back end's line (:aot/line) as :line;\n  the reader's positions of the back end's own source dropped.R3,i49,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main12,forms->listsm12,R6,TR2,L2,V1,R9,V2,R9,R10,R0,s348,Form f with every seq a list, for printing; metadata as clean-meta leaves it, a list without\n  a line of its own given the enclosing form's (line): the class forms' analysis gives a form\n  without one the reader's line in the printed file, and a2g lays the Go text out on the lines\n  (A2G-SPEC §4.3), so lines that went back and forth would pad it.R3,i58,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main10,write-formm10,R6,TR2,L1,V2,Myn1,wm2,R11,R12,R9,R3,i74,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main9,file-namem10,R6,TR2,L1,V1,Myn5,cnamem2,R11,R13,R3,i80,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main11,compile-allm12,R6,TR2,L1,V2,R14,R15,R0,s373,Compiles the sources of us (each [src units]) whose names are in want: their results, and the\n  classes made (name → record). A class a source's events make is a class of the program when\n  that source compiles, else made at run time (named only by reflection); a source that fails\n  makes its classes run-time ones, and the others are compiled again until none fails anew.R3,i83,R4,i1,R5,s18,arbace/aot/main.aev15,arbace.aot.main3,runm10,R2,L1,V2,R16,R17,R0,s74,Compiles sources (or all recorded) into directory out; returns the report.R3,i114,R4,i1,R5,s18,arbace/aot/main.ae")

var Lit_101 *jrt.String = jrt.Intern("arbace.aot.main$eval1684000004$loading__1927001464__auto____1684000005")

var Lit_102 *jrt.String = jrt.Intern("arbace.aot.main$eval1684000008$fn__1684000009")

var Lit_103 *jrt.String = jrt.Intern("arbace.aot.main$units")

var Lit_104 *jrt.String = jrt.Intern("arbace.aot.main$events")

var Lit_105 *jrt.String = jrt.Intern("arbace.aot.main$source_classes")

var Lit_106 *jrt.String = jrt.Intern("arbace.aot.main$interfaces")

var Lit_107 *jrt.String = jrt.Intern("arbace.aot.main$clean_meta")

var Lit_108 *jrt.String = jrt.Intern("arbace.aot.main$forms__GT_lists")

var Lit_109 *jrt.String = jrt.Intern("arbace.aot.main$write_form")

var Lit_110 *jrt.String = jrt.Intern("arbace.aot.main$file_name")

var Lit_111 *jrt.String = jrt.Intern("arbace.aot.main$compile_all")

var Lit_112 *jrt.String = jrt.Intern("arbace.aot.main$run")
