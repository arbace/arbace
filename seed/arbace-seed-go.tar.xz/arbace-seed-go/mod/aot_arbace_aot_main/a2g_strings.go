//line a2g_strings.ae:1
package aot_arbace_aot_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.set")

var Lit_7 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_8 *jrt.String = jrt.Intern("io")

var Lit_9 *jrt.String = jrt.Intern("arbace.aot.emit")

var Lit_10 *jrt.String = jrt.Intern("e")

var Lit_11 *jrt.String = jrt.Intern("commute")

var Lit_12 *jrt.String = jrt.Intern("deref")

var Lit_13 *jrt.String = jrt.Intern("conj")

var Lit_14 *jrt.String = jrt.Intern("arbace.aot.main")

var Lit_15 *jrt.String = jrt.Intern("doc")

var Lit_16 *jrt.String = jrt.Intern("Standalone S6: compiles the namespaces the program prepared (Compiler$AST/units, recorded\n  with ARBACE_COMPILE set) to class forms (arbace.aot.emit), a tree a2g reads as one more input\n  (bin/a2g --input DIR).\n\n  (run OUT SOURCES): SOURCES the source paths to compile (arbace/walk.ae ...), or nil for every\n  source recorded. Writes OUT/arbace.ae (the namespace of the classes' package, loading the\n  others), one file per loader class (aot_SCRIPTBASE__init.ae) and per holder class\n  (aot_HOLDER.ae), and OUT/aot.edn (the sources compiled, those that failed and why).")

var Lit_17 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_18 *jrt.String = jrt.Intern("ex-info")

var Lit_19 *jrt.String = jrt.Intern("distinct")

var Lit_20 *jrt.String = jrt.Intern("group-by")

var Lit_21 *jrt.String = jrt.Intern("seq")

var Lit_22 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_23 *jrt.String = jrt.Intern("chunk-first")

var Lit_24 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_25 *jrt.String = jrt.Intern("chunk-append")

var Lit_26 *jrt.String = jrt.Intern("mapv")

var Lit_27 *jrt.String = jrt.Intern("vec")

var Lit_28 *jrt.String = jrt.Intern("chunk-cons")

var Lit_29 *jrt.String = jrt.Intern("first")

var Lit_30 *jrt.String = jrt.Intern("cons")

var Lit_31 *jrt.String = jrt.Intern("chunk")

var Lit_32 *jrt.String = jrt.Intern("chunk-rest")

var Lit_33 *jrt.String = jrt.Intern("rest")

var Lit_34 *jrt.String = jrt.Intern("map")

var Lit_35 *jrt.String = jrt.Intern("concat")

var Lit_36 *jrt.String = jrt.Intern("set")

var Lit_37 *jrt.String = jrt.Intern("string?")

var Lit_38 *jrt.String = jrt.Intern("destub")

var Lit_39 *jrt.String = jrt.Intern("events")

var Lit_40 *jrt.String = jrt.Intern("into")

var Lit_41 *jrt.String = jrt.Intern("filter")

var Lit_42 *jrt.String = jrt.Intern("interface-record")

var Lit_43 *jrt.String = jrt.Intern("aot")

var Lit_44 *jrt.String = jrt.Intern("line")

var Lit_45 *jrt.String = jrt.Intern("dissoc")

var Lit_46 *jrt.String = jrt.Intern("assoc")

var Lit_47 *jrt.String = jrt.Intern("not-empty")

var Lit_48 *jrt.String = jrt.Intern("column")

var Lit_49 *jrt.String = jrt.Intern("seq?")

var Lit_50 *jrt.String = jrt.Intern("clean-meta")

var Lit_51 *jrt.String = jrt.Intern("with-meta")

var Lit_52 *jrt.String = jrt.Intern("vector?")

var Lit_53 *jrt.String = jrt.Intern("symbol?")

var Lit_54 *jrt.String = jrt.Intern("else")

var Lit_55 *jrt.String = jrt.Intern("apply")

var Lit_56 *jrt.String = jrt.Intern("not")

var Lit_57 *jrt.String = jrt.Intern("list")

var Lit_58 *jrt.String = jrt.Intern("forms->lists")

var Lit_59 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_60 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_61 *jrt.String = jrt.Intern("hash-map")

var Lit_62 *jrt.String = jrt.Intern("*out*")

var Lit_63 *jrt.String = jrt.Intern("*print-meta*")

var Lit_64 *jrt.String = jrt.Intern("*print-length*")

var Lit_65 *jrt.String = jrt.Intern("*print-level*")

var Lit_66 *jrt.String = jrt.Intern("*print-dup*")

var Lit_67 *jrt.String = jrt.Intern("*print-namespace-maps*")

var Lit_68 *jrt.String = jrt.Intern("pr")

var Lit_69 *jrt.String = jrt.Intern("replace")

var Lit_70 *jrt.String = jrt.Intern("remove")

var Lit_71 *jrt.String = jrt.Intern("atom")

var Lit_72 *jrt.String = jrt.Intern("doall")

var Lit_73 *jrt.String = jrt.Intern("empty?")

var Lit_74 *jrt.String = jrt.Intern("union")

var Lit_75 *jrt.String = jrt.Intern("comp")

var Lit_76 *jrt.String = jrt.Intern("source-classes")

var Lit_77 *jrt.String = jrt.Intern("second")

var Lit_78 *jrt.String = jrt.Intern("difference")

var Lit_79 *jrt.String = jrt.Intern("merge")

var Lit_80 *jrt.String = jrt.Intern("interfaces")

var Lit_81 *jrt.String = jrt.Intern("src")

var Lit_82 *jrt.String = jrt.Intern("loader")

var Lit_83 *jrt.String = jrt.Intern("emit-source")

var Lit_84 *jrt.String = jrt.Intern("error")

var Lit_85 *jrt.String = jrt.Intern("pr-str")

var Lit_86 *jrt.String = jrt.Intern("reset!")

var Lit_87 *jrt.String = jrt.Intern("ex-data")

var Lit_88 *jrt.String = jrt.Intern("get-in")

var Lit_89 *jrt.String = jrt.Intern("errors")

var Lit_90 *jrt.String = jrt.Intern("units")

var Lit_91 *jrt.String = jrt.Intern("compile-all")

var Lit_92 *jrt.String = jrt.Intern("file")

var Lit_93 *jrt.String = jrt.Intern("class-forms")

var Lit_94 *jrt.String = jrt.Intern("file-name")

var Lit_95 *jrt.String = jrt.Intern("form")

var Lit_96 *jrt.String = jrt.Intern("name")

var Lit_97 *jrt.String = jrt.Intern("compiled")

var Lit_98 *jrt.String = jrt.Intern("failed")

var Lit_99 *jrt.String = jrt.Intern("classes")

var Lit_100 *jrt.String = jrt.Intern("writer")

var Lit_101 *jrt.String = jrt.Intern("write-form")

var Lit_102 *jrt.String = jrt.Intern("ns")

var Lit_103 *jrt.String = jrt.Intern("arbace")

var Lit_104 *jrt.String = jrt.Intern("load")

var Lit_105 *jrt.String = jrt.Intern("subs")

var Lit_106 *jrt.String = jrt.Intern("next")

var Lit_107 *jrt.String = jrt.Intern("ends-with?")

var Lit_108 *jrt.String = jrt.Intern("contains?")

var Lit_109 *jrt.String = jrt.Intern("holder")

var Lit_110 *jrt.String = jrt.Intern("kind")

var Lit_111 *jrt.String = jrt.Intern("spit")

var Lit_112 *jrt.String = jrt.Intern("java.lang.Thread")

var Lit_113 *jrt.String = jrt.Intern("bound-fn*")

var Lit_114 *jrt.String = jrt.Intern("take-nth")

var Lit_115 *jrt.String = jrt.Intern("drop")

var Lit_116 *jrt.String = jrt.Intern("in-ns")

var Lit_117 *jrt.String = jrt.Intern("quote")

var Lit_118 *jrt.String = jrt.Intern("range")

var Lit_119 *jrt.String = jrt.Intern("run!")

var Lit_120 *jrt.String = jrt.Intern("prn")

var Lit_121 *jrt.String = jrt.Intern("sorted-map")

var Lit_122 *jrt.String = jrt.Intern("sort")

var Lit_123 *jrt.String = jrt.Intern("vals")

var Lit_124 *jrt.String = jrt.Intern("arbace.aot.main$clean_meta")

var Lit_125 *jrt.String = jrt.Intern("arbace.aot.main$compile_all")

var Lit_126 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$fn__1684000132")

var Lit_127 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$fn__1684000137")

var Lit_128 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118")

var Lit_129 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119")

var Lit_130 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123")

var Lit_131 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123$fn__1684000124")

var Lit_132 *jrt.String = jrt.Intern("proxy")

var Lit_133 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000112__1684000118$fn__1684000119$iter__1684000114__1684000123$fn__1684000124$fn__1684000125")

var Lit_134 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143")

var Lit_135 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144")

var Lit_136 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000145")

var Lit_137 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000145$fn__1684000149")

var Lit_138 *jrt.String = jrt.Intern(" ")

var Lit_139 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000139__1684000143$fn__1684000144$fn__1684000155")

var Lit_140 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000159__1684000163")

var Lit_141 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000159__1684000163$fn__1684000164")

var Lit_142 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000159__1684000163$fn__1684000164$fn__1684000165")

var Lit_143 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000169__1684000173")

var Lit_144 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000169__1684000173$fn__1684000174")

var Lit_145 *jrt.String = jrt.Intern("arbace.aot.main$compile_all$iter__1684000169__1684000173$fn__1684000174$fn__1684000175")

var Lit_146 *jrt.String = jrt.Intern("arbace.aot.main$eval1684000004$loading__1927001464__auto____1684000005")

var Lit_147 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_148 *jrt.String = jrt.Intern("arbace.aot.main$eval1684000008$fn__1684000009")

var Lit_149 *jrt.String = jrt.Intern("arbace.aot.main$events")

var Lit_150 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039")

var Lit_151 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040")

var Lit_152 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044")

var Lit_153 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044$fn__1684000045")

var Lit_154 *jrt.String = jrt.Intern("arbace.aot.main$events$iter__1684000033__1684000039$fn__1684000040$iter__1684000035__1684000044$fn__1684000045$fn__1684000046")

var Lit_155 *jrt.String = jrt.Intern("arbace.aot.main$file_name")

var Lit_156 *jrt.String = jrt.Intern("aot_")

var Lit_157 *jrt.String = jrt.Intern(".ae")

var Lit_158 *jrt.String = jrt.Intern(".")

var Lit_159 *jrt.String = jrt.Intern("_")

var Lit_160 *jrt.String = jrt.Intern("arbace.aot.main$forms__GT_lists")

var Lit_161 *jrt.String = jrt.Intern("arbace.aot.main$forms__GT_lists$fn__1684000104")

var Lit_162 *jrt.String = jrt.Intern("arbace.aot.main$forms__GT_lists$fn__1684000106")

var Lit_163 *jrt.String = jrt.Intern("arbace.aot.main$interfaces")

var Lit_164 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$fn__1684000066")

var Lit_165 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$fn__1684000068")

var Lit_166 *jrt.String = jrt.Intern("imethod")

var Lit_167 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074")

var Lit_168 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075")

var Lit_169 *jrt.String = jrt.Intern("iface")

var Lit_170 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076")

var Lit_171 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081")

var Lit_172 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081$fn__1684000082")

var Lit_173 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$fn__1684000076$iter__1684000077__1684000081$fn__1684000082$fn__1684000083")

var Lit_174 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092")

var Lit_175 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092$fn__1684000093")

var Lit_176 *jrt.String = jrt.Intern("arbace.aot.main$interfaces$iter__1684000070__1684000074$fn__1684000075$iter__1684000088__1684000092$fn__1684000093$fn__1684000094")

var Lit_177 *jrt.String = jrt.Intern("arbace.aot.main$run")

var Lit_178 *jrt.String = jrt.Intern("arbace.ae")

var Lit_179 *jrt.String = jrt.Intern("packages.edn")

var Lit_180 *jrt.String = jrt.Intern("aot.edn")

var Lit_181 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000207")

var Lit_182 *jrt.String = jrt.Intern("arbace/")

var Lit_183 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000261")

var Lit_184 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000263")

var Lit_185 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000267")

var Lit_186 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269")

var Lit_187 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274")

var Lit_188 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274$fn__1684000275")

var Lit_189 *jrt.String = jrt.Intern("/")

var Lit_190 *jrt.String = jrt.Intern("-")

var Lit_191 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000269$iter__1684000270__1684000274$fn__1684000275$fn__1684000276")

var Lit_192 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000291")

var Lit_193 *jrt.String = jrt.Intern("arbace.aot.main$run$fn__1684000293")

var Lit_194 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000187__1684000191")

var Lit_195 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000187__1684000191$fn__1684000192")

var Lit_196 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000187__1684000191$fn__1684000192$fn__1684000193")

var Lit_197 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000197__1684000201")

var Lit_198 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000197__1684000201$fn__1684000202")

var Lit_199 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000197__1684000201$fn__1684000202$fn__1684000203")

var Lit_200 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223")

var Lit_201 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224")

var Lit_202 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225")

var Lit_203 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226")

var Lit_204 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226$fn__1684000234")

var Lit_205 *jrt.String = jrt.Intern(";; Compiled by arbace.aot (standalone S6)")

var Lit_206 *jrt.String = jrt.Intern(". Regenerated by the build.\n\n")

var Lit_207 *jrt.String = jrt.Intern(" from ")

var Lit_208 *jrt.String = jrt.Intern(": its loader")

var Lit_209 *jrt.String = jrt.Intern(": the classes of a namespace")

var Lit_210 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000225$fn__1684000226$fn__1684000239")

var Lit_211 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243")

var Lit_212 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243$fn__1684000251")

var Lit_213 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000219__1684000223$fn__1684000224$fn__1684000243$fn__1684000256")

var Lit_214 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000281__1684000285")

var Lit_215 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000281__1684000285$fn__1684000286")

var Lit_216 *jrt.String = jrt.Intern("arbace.aot.main$run$iter__1684000281__1684000285$fn__1684000286$fn__1684000287")

var Lit_217 *jrt.String = jrt.Intern("arbace.aot.main$run$ns_of__1684000265")

var Lit_218 *jrt.String = jrt.Intern("__init")

var Lit_219 *jrt.String = jrt.Intern("arbace.aot.main$source_classes")

var Lit_220 *jrt.String = jrt.Intern("arbace.aot.main$source_classes$iter__1684000053__1684000057")

var Lit_221 *jrt.String = jrt.Intern("arbace.aot.main$source_classes$iter__1684000053__1684000057$fn__1684000058")

var Lit_222 *jrt.String = jrt.Intern("arbace.aot.main$source_classes$iter__1684000053__1684000057$fn__1684000058$fn__1684000059")

var Lit_223 *jrt.String = jrt.Intern("arbace.aot.main$units")

var Lit_224 *jrt.String = jrt.Intern("aot: no units recorded (ARBACE_COMPILE not set)")

var Lit_225 *jrt.String = jrt.Intern("arbace.aot.main$units$fn__1684000014")

var Lit_226 *jrt.String = jrt.Intern("arbace.aot.main$units$fn__1684000016")

var Lit_227 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022")

var Lit_228 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023")

var Lit_229 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000024")

var Lit_230 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000024$fn__1684000025")

var Lit_231 *jrt.String = jrt.Intern("arbace.aot.main$units$iter__1684000018__1684000022$fn__1684000023$fn__1684000028")

var Lit_232 *jrt.String = jrt.Intern("arbace.aot.main$write_form")

var Lit_233 *jrt.String = jrt.Intern("\n\n")

var Lit_234 *jrt.String = jrt.Intern("arglists")

var Lit_235 *jrt.String = jrt.Intern("The recorded units by source, in the order of their first unit: [[src [[unit um] ...]] ...].")

var Lit_236 *jrt.String = jrt.Intern("arbace/aot/main.ae")

var Lit_237 *jrt.String = jrt.Intern("private")

var Lit_238 *jrt.String = jrt.Intern("ss")

var Lit_239 *jrt.String = jrt.Intern("The names of the classes the events of a source's units make at run time (deftypes,\n  interfaces, proxies).")

var Lit_240 *jrt.String = jrt.Intern("The interfaces gen-interface made in a source's units (events iface, imethod): name →\n  record.")

var Lit_241 *jrt.String = jrt.Intern("m")

var Lit_242 *jrt.String = jrt.Intern("The metadata m of an emitted form for printing: the back end's line (:aot/line) as :line;\n  the reader's positions of the back end's own source dropped.")

var Lit_243 *jrt.String = jrt.Intern("f")

var Lit_244 *jrt.String = jrt.Intern("Form f with every seq a list, for printing; metadata as clean-meta leaves it, a list without\n  a line of its own given the enclosing form's (line): the class forms' analysis gives a form\n  without one the reader's line in the printed file, and a2g lays the Go text out on the lines\n  (A2G-SPEC §4.3), so lines that went back and forth would pad it.")

var Lit_245 *jrt.String = jrt.Intern("w")

var Lit_246 *jrt.String = jrt.Intern("tag")

var Lit_247 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_248 *jrt.String = jrt.Intern("cname")

var Lit_249 *jrt.String = jrt.Intern("String")

var Lit_250 *jrt.String = jrt.Intern("us")

var Lit_251 *jrt.String = jrt.Intern("want")

var Lit_252 *jrt.String = jrt.Intern("Compiles the sources of us (each [src units]) whose names are in want: their results, and the\n  classes made (name → record). A class a source's events make is a class of the program when\n  that source compiles, else made at run time (named only by reflection); a source that fails\n  makes its classes run-time ones, and the others are compiled again until none fails anew.")

var Lit_253 *jrt.String = jrt.Intern("run")

var Lit_254 *jrt.String = jrt.Intern("out")

var Lit_255 *jrt.String = jrt.Intern("sources")

var Lit_256 *jrt.String = jrt.Intern("Compiles sources (or all recorded) into directory out; returns the report.")
