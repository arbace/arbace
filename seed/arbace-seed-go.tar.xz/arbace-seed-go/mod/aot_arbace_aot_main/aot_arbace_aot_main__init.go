//line aot_arbace_aot_main__init.ae:1
package aot_arbace_aot_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_aot_main__init_A_Unit0__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_aot_main__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_main__init_A_const_1) }
//line :1:1
func A_arbace_aot_main__init_A_Unit1__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_aot_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_2)) }
//line :1:1
func A_arbace_aot_main__init_A_Unit2__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_162, false); A_arbace_aot_main_eval1684000004_loading__1927001464__auto____1684000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_aot_main__init_A_Unit3__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_aot_main__init_A_const_1)).Equals_O__Z(A_arbace_aot_main__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_aot_main_eval1684000008_fn__1684000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_aot_main_eval1684000008_fn__1684000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, false); A_arbace_aot_main_eval1684000008_fn__1684000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_aot_main__init_A_Load__O() any { A_arbace_aot_main__init_A_Init(); A_arbace_aot_main__init_A_Unit0__O(); A_arbace_aot_main__init_A_Unit1__O(); A_arbace_aot_main__init_A_Unit2__O(); A_arbace_aot_main__init_A_Unit3__O(); A_arbace_aot_main__init_A_Unit4__O(); A_arbace_aot_main__init_A_Unit5__O(); A_arbace_aot_main__init_A_Unit6__O(); A_arbace_aot_main__init_A_Unit7__O(); A_arbace_aot_main__init_A_Unit8__O(); A_arbace_aot_main__init_A_Unit9__O(); A_arbace_aot_main__init_A_Unit10__O(); A_arbace_aot_main__init_A_Unit11__O(); A_arbace_aot_main__init_A_Unit12__O(); A_arbace_aot_main__init_A_Unit13__O(); A_arbace_aot_main__init_A_Unit14__O(); A_arbace_aot_main__init_A_Unit15__O(); A_arbace_aot_main__init_A_Unit16__O(); A_arbace_aot_main__init_A_Unit17__O(); A_arbace_aot_main__init_A_Unit18__O(); A_arbace_aot_main__init_A_Unit19__O(); A_arbace_aot_main__init_A_Unit20__O(); A_arbace_aot_main__init_A_Unit21__O(); A_arbace_aot_main__init_A_Unit22__O(); A_arbace_aot_main__init_A_Unit23__O(); A_arbace_aot_main__init_A_Unit24__O(); return nil }












func A_arbace_aot_main__init_A_Unit4__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_4; var tmp2 any = A_arbace_aot_main_units_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_aot_main_units_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_164, false); A_arbace_aot_main_units_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_5)); return A_arbace_aot_main__init_A_const_4 }








func A_arbace_aot_main__init_A_Unit5__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_6; var tmp2 any = A_arbace_aot_main_events_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_aot_main_events_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_165, false); A_arbace_aot_main_events_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_7)); return A_arbace_aot_main__init_A_const_6 }


func A_arbace_aot_main__init_A_Unit6__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_8; var tmp2 any = A_arbace_aot_main_source_classes_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_aot_main_source_classes_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, false); A_arbace_aot_main_source_classes_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_9)); return A_arbace_aot_main__init_A_const_8 }








func A_arbace_aot_main__init_A_Unit7__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_10; var tmp2 any = A_arbace_aot_main_interfaces_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_aot_main_interfaces_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_167, false); A_arbace_aot_main_interfaces_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_11)); return A_arbace_aot_main__init_A_const_10 }











func A_arbace_aot_main__init_A_Unit8__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_12; var tmp2 any = A_arbace_aot_main_clean_meta_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_aot_main_clean_meta_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_168, false); A_arbace_aot_main_clean_meta_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_13)); return A_arbace_aot_main__init_A_const_12 }








func A_arbace_aot_main__init_A_Unit9__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_14; var tmp2 any = A_arbace_aot_main_forms__GT_lists_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_aot_main_forms__GT_lists_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_169, false); A_arbace_aot_main_forms__GT_lists_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_15)); return A_arbace_aot_main__init_A_const_14 }















func A_arbace_aot_main__init_A_Unit10__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_16; var tmp2 any = A_arbace_aot_main_write_form_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_aot_main_write_form_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_170, false); A_arbace_aot_main_write_form_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_17)); return A_arbace_aot_main__init_A_const_16 }





func A_arbace_aot_main__init_A_Unit11__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_18; var tmp2 any = A_arbace_aot_main_fn__1684000110_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_aot_main_fn__1684000110_A_fn_class; if





	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_171, false); A_arbace_aot_main_fn__1684000110_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; /*line :82:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_19)); return A_arbace_aot_main__init_A_const_18 }







func A_arbace_aot_main__init_A_Unit12__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(90, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_20; var tmp2 any = A_arbace_aot_main_form_texts_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_aot_main_form_texts_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_172, false); A_arbace_aot_main_form_texts_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_21)); return A_arbace_aot_main__init_A_const_20 }


































func A_arbace_aot_main__init_A_Unit13__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_22; var tmp2 any = A_arbace_aot_main_file_name_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_aot_main_file_name_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_173, false); A_arbace_aot_main_file_name_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_23)); return A_arbace_aot_main__init_A_const_22 }


func A_arbace_aot_main__init_A_Unit14__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_24; var tmp2 any = A_arbace_aot_main_compile_all_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_aot_main_compile_all_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_174, false); A_arbace_aot_main_compile_all_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_25)); return A_arbace_aot_main__init_A_const_24 }






























func A_arbace_aot_main__init_A_Unit15__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(159, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_26; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_aot_main__init_A_const_26; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_27)); return A_arbace_aot_main__init_A_const_26.SetDynamic_Z__Var(true).Ref() }



func A_arbace_aot_main__init_A_Unit16__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_28; var tmp2 any = A_arbace_aot_main_path_source_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_aot_main_path_source_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_175, false); A_arbace_aot_main_path_source_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_29)); return A_arbace_aot_main__init_A_const_28 }











func A_arbace_aot_main__init_A_Unit17__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(175, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_30; var tmp2 any = A_arbace_aot_main_forms_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_aot_main_forms_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_176, false); A_arbace_aot_main_forms_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_31)); return A_arbace_aot_main__init_A_const_30 }












func A_arbace_aot_main__init_A_Unit18__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(188, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_32; var tmp2 any = A_arbace_aot_main_libs_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_aot_main_libs_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_177, false); A_arbace_aot_main_libs_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_33)); return A_arbace_aot_main__init_A_const_32 }













func A_arbace_aot_main__init_A_Unit19__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_34; var tmp2 any = A_arbace_aot_main_source_ns_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_aot_main_source_ns_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_178, false); A_arbace_aot_main_source_ns_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_35)); return A_arbace_aot_main__init_A_const_34 }










func A_arbace_aot_main__init_A_Unit20__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(213, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_36; var tmp2 any = A_arbace_aot_main_source_deps_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_aot_main_source_deps_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_179, false); A_arbace_aot_main_source_deps_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_37)); return A_arbace_aot_main__init_A_const_36 }













func A_arbace_aot_main__init_A_Unit21__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(227, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_38; var tmp2 any = A_arbace_aot_main_back_end_sources_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_aot_main_back_end_sources_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_180, false); A_arbace_aot_main_back_end_sources_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_39)); return A_arbace_aot_main__init_A_const_38 }
























func A_arbace_aot_main__init_A_Unit22__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(252, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_40; var tmp2 any = A_arbace_aot_main_compiled_back_end_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_aot_main_compiled_back_end_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_181, false); A_arbace_aot_main_compiled_back_end_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_41)); return A_arbace_aot_main__init_A_const_40 }










































func A_arbace_aot_main__init_A_Unit23__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(295, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_42; var tmp2 any = A_arbace_aot_main_run_STAR__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_aot_main_run_STAR__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_182, false); A_arbace_aot_main_run_STAR__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_43)); return A_arbace_aot_main__init_A_const_42 }






































































func A_arbace_aot_main__init_A_Unit24__O() any { A_arbace_aot_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(366, 1); var tmp1 *lang.Var = A_arbace_aot_main__init_A_const_44; var tmp2 any = A_arbace_aot_main_run_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_aot_main_run_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_183, false); A_arbace_aot_main_run_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_main__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_main__init_A_const_45)); return A_arbace_aot_main__init_A_const_44 }



type A_arbace_aot_main__init_A struct{ jrt.Object }

var A_arbace_aot_main__init_A_const_pool *jrt.RefArray

var A_arbace_aot_main__init_A_const_0 *lang.Var

var A_arbace_aot_main__init_A_const_1 any

var A_arbace_aot_main__init_A_const_2 any

var A_arbace_aot_main__init_A_const_3 any

var A_arbace_aot_main__init_A_const_4 *lang.Var

var A_arbace_aot_main__init_A_const_5 any

var A_arbace_aot_main__init_A_const_6 *lang.Var

var A_arbace_aot_main__init_A_const_7 any

var A_arbace_aot_main__init_A_const_8 *lang.Var

var A_arbace_aot_main__init_A_const_9 any

var A_arbace_aot_main__init_A_const_10 *lang.Var

var A_arbace_aot_main__init_A_const_11 any

var A_arbace_aot_main__init_A_const_12 *lang.Var

var A_arbace_aot_main__init_A_const_13 any

var A_arbace_aot_main__init_A_const_14 *lang.Var

var A_arbace_aot_main__init_A_const_15 any

var A_arbace_aot_main__init_A_const_16 *lang.Var

var A_arbace_aot_main__init_A_const_17 any

var A_arbace_aot_main__init_A_const_18 *lang.Var

var A_arbace_aot_main__init_A_const_19 any

var A_arbace_aot_main__init_A_const_20 *lang.Var

var A_arbace_aot_main__init_A_const_21 any

var A_arbace_aot_main__init_A_const_22 *lang.Var

var A_arbace_aot_main__init_A_const_23 any

var A_arbace_aot_main__init_A_const_24 *lang.Var

var A_arbace_aot_main__init_A_const_25 any

var A_arbace_aot_main__init_A_const_26 *lang.Var

var A_arbace_aot_main__init_A_const_27 any

var A_arbace_aot_main__init_A_const_28 *lang.Var

var A_arbace_aot_main__init_A_const_29 any

var A_arbace_aot_main__init_A_const_30 *lang.Var

var A_arbace_aot_main__init_A_const_31 any

var A_arbace_aot_main__init_A_const_32 *lang.Var

var A_arbace_aot_main__init_A_const_33 any

var A_arbace_aot_main__init_A_const_34 *lang.Var

var A_arbace_aot_main__init_A_const_35 any

var A_arbace_aot_main__init_A_const_36 *lang.Var

var A_arbace_aot_main__init_A_const_37 any

var A_arbace_aot_main__init_A_const_38 *lang.Var

var A_arbace_aot_main__init_A_const_39 any

var A_arbace_aot_main__init_A_const_40 *lang.Var

var A_arbace_aot_main__init_A_const_41 any

var A_arbace_aot_main__init_A_const_42 *lang.Var

var A_arbace_aot_main__init_A_const_43 any

var A_arbace_aot_main__init_A_const_44 *lang.Var

var A_arbace_aot_main__init_A_const_45 any

var A_arbace_aot_main__init_A_init jrt.ClassInit

func A_arbace_aot_main__init_A_Init() { if !A_arbace_aot_main__init_A_init.Done() { A_arbace_aot_main__init_A_init.Run(A_arbace_aot_main__init_A_clinit) } }

func A_arbace_aot_main__init_A_clinit() { A_arbace_aot_main__init_A_clinit_p0(); A_arbace_aot_main__init_A_clinit_p1(); A_arbace_aot_main__init_A_clinit_p2(); A_arbace_aot_main__init_A_clinit_p3() }

func A_arbace_aot_main__init_A_clinit_p0() { A_arbace_aot_main__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_161, 71); A_arbace_aot_main__init_A_const_0 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[25]); A_arbace_aot_main__init_A_const_1 = A_arbace_aot_main__init_A_const_pool.A[26]; A_arbace_aot_main__init_A_const_2 = A_arbace_aot_main__init_A_const_pool.A[27]; A_arbace_aot_main__init_A_const_3 = A_arbace_aot_main__init_A_const_pool.A[28]; A_arbace_aot_main__init_A_const_4 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[29]); A_arbace_aot_main__init_A_const_5 = A_arbace_aot_main__init_A_const_pool.A[30]; A_arbace_aot_main__init_A_const_6 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[31]); A_arbace_aot_main__init_A_const_7 = A_arbace_aot_main__init_A_const_pool.A[32]; A_arbace_aot_main__init_A_const_8 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[33]); A_arbace_aot_main__init_A_const_9 = A_arbace_aot_main__init_A_const_pool.A[34]; A_arbace_aot_main__init_A_const_10 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[35]); A_arbace_aot_main__init_A_const_11 = A_arbace_aot_main__init_A_const_pool.A[36]; A_arbace_aot_main__init_A_const_12 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[37]) }

func A_arbace_aot_main__init_A_clinit_p1() { A_arbace_aot_main__init_A_const_13 = A_arbace_aot_main__init_A_const_pool.A[38]; A_arbace_aot_main__init_A_const_14 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[39]); A_arbace_aot_main__init_A_const_15 = A_arbace_aot_main__init_A_const_pool.A[40]; A_arbace_aot_main__init_A_const_16 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[41]); A_arbace_aot_main__init_A_const_17 = A_arbace_aot_main__init_A_const_pool.A[42]; A_arbace_aot_main__init_A_const_18 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[43]); A_arbace_aot_main__init_A_const_19 = A_arbace_aot_main__init_A_const_pool.A[44]; A_arbace_aot_main__init_A_const_20 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[45]); A_arbace_aot_main__init_A_const_21 = A_arbace_aot_main__init_A_const_pool.A[46]; A_arbace_aot_main__init_A_const_22 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[47]); A_arbace_aot_main__init_A_const_23 = A_arbace_aot_main__init_A_const_pool.A[48]; A_arbace_aot_main__init_A_const_24 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[49]); A_arbace_aot_main__init_A_const_25 = A_arbace_aot_main__init_A_const_pool.A[50] }

func A_arbace_aot_main__init_A_clinit_p2() { A_arbace_aot_main__init_A_const_26 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[51]); A_arbace_aot_main__init_A_const_27 = A_arbace_aot_main__init_A_const_pool.A[52]; A_arbace_aot_main__init_A_const_28 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[53]); A_arbace_aot_main__init_A_const_29 = A_arbace_aot_main__init_A_const_pool.A[54]; A_arbace_aot_main__init_A_const_30 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[55]); A_arbace_aot_main__init_A_const_31 = A_arbace_aot_main__init_A_const_pool.A[56]; A_arbace_aot_main__init_A_const_32 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[57]); A_arbace_aot_main__init_A_const_33 = A_arbace_aot_main__init_A_const_pool.A[58]; A_arbace_aot_main__init_A_const_34 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[59]); A_arbace_aot_main__init_A_const_35 = A_arbace_aot_main__init_A_const_pool.A[60]; A_arbace_aot_main__init_A_const_36 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[61]); A_arbace_aot_main__init_A_const_37 = A_arbace_aot_main__init_A_const_pool.A[62]; A_arbace_aot_main__init_A_const_38 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[63]) }

func A_arbace_aot_main__init_A_clinit_p3() { A_arbace_aot_main__init_A_const_39 = A_arbace_aot_main__init_A_const_pool.A[64]; A_arbace_aot_main__init_A_const_40 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[65]); A_arbace_aot_main__init_A_const_41 = A_arbace_aot_main__init_A_const_pool.A[66]; A_arbace_aot_main__init_A_const_42 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[67]); A_arbace_aot_main__init_A_const_43 = A_arbace_aot_main__init_A_const_pool.A[68]; A_arbace_aot_main__init_A_const_44 = lang.Var_Cast(A_arbace_aot_main__init_A_const_pool.A[69]); A_arbace_aot_main__init_A_const_45 = A_arbace_aot_main__init_A_const_pool.A[70] }

func A_arbace_aot_main__init_A_New() *A_arbace_aot_main__init_A { A_arbace_aot_main__init_A_Init(); t := &A_arbace_aot_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_main__init_A) Ctor() {}

func (t *A_arbace_aot_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_aot_main__init_A_class }

func (t *A_arbace_aot_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_main__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_aot_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_main__init_A); return ok }

func A_arbace_aot_main__init_A_Cast(x any) *A_arbace_aot_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_main__init_A_class)) }; return v }
