//line aot_arbace_g2a_print.ae:1
package aot_arbace_g2a_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_New() *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A { A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_Init(); t := &A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_5; tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp13); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_263)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_264)); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_265)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_266)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_267)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_153)); var tmp20 *lang.Var; lang.RT_Init(); tmp20 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp20).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_268)); var tmp21 *lang.Var; lang.RT_Init(); tmp21 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp21).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_269)); var tmp22 *lang.Var; lang.RT_Init(); tmp22 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp22).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_270)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp23 != nil { panic(tmp23) }; return tmp3 }
//line :1:1
func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_New() *A_arbace_g2a_print_eval1580000008_fn__1580000009_A { A_arbace_g2a_print_eval1580000008_fn__1580000009_A_Init(); t := &A_arbace_g2a_print_eval1580000008_fn__1580000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_7; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_10; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_8; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_9; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }


































func A_arbace_g2a_print_read_forms_A_New() *A_arbace_g2a_print_read_forms_A { A_arbace_g2a_print_read_forms_A_Init(); t := &A_arbace_g2a_print_read_forms_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_g2a_print_read_forms_A) Ctor() {}
//line :36:1
func (t *A_arbace_g2a_print_read_forms_A) Invoke_O_O__O(self, path__0 any) any { var r__2 any; var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_11; r__2 = lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream_Charset(jrt.FileInputStream_New_String(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(path__0))), jrt.StandardCharsets_UTF_8)); var tmp2 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




	{ var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_14; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_15; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_16; var tmp8 any = tmp7.Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp8, tmp9.Ref())); tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :36:1
		{ var eof__7 any = jrt.Object_New(); var acc__8 any; lang.PersistentVector_Init(); acc__8 = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__9 any; var tmp10 *lang.Var







			A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_12; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_FALSE; f__9 = tmp11.Invoke_O_O_O__O(r__2, tmp12.Ref(), eof__7)
			if lang.Util_Identical_O_O__Z(f__9, eof__7) { tmp2 = acc__8 } else { var tmp13 *lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_8; acc__8 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(acc__8, f__9); continue L1 }
//line :36:1
			break L1
		}
		}


		return nil }(); var tmp15 *lang.Var; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O()
//line :36:1
		if tmp14 != nil { panic(tmp14) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :36:1*/ tmp16 != nil { panic(tmp16) }; return tmp2 }










func A_arbace_g2a_print_go_ns_aliases_A_New() *A_arbace_g2a_print_go_ns_aliases_A { A_arbace_g2a_print_go_ns_aliases_A_Init(); t := &A_arbace_g2a_print_go_ns_aliases_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_g2a_print_go_ns_aliases_A) Ctor() {}
//line :47:1
func (t *A_arbace_g2a_print_go_ns_aliases_A) Invoke_O_O__O(self, ns_form__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_18; var tmp4 any = tmp3; var tmp5 any; var iter__1927001039__auto____2 any; var tmp6 any = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_New(); var tmp7 *jrt.Class
	A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_Init(); tmp7 = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_30; tmp5 = tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(ns_form__0))
//line :50:1
	return tmp2.Invoke_O_O__O(tmp4, tmp5) }
func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_New() *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_Init(); t := &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) Ctor() {}
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) Invoke_O_O__O(self, s__1580000014__1 any) any { var tmp1 any = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_New_O_O(s__1580000014__1, self); var tmp2 *jrt.Class; A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_Init(); tmp2 = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_Init(); t := &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) Ctor_O_O(c__s__1580000014, c__iter__1580000013 any) { t.F_s__1580000014 = c__s__1580000014; t.F_iter__1580000013 = c__iter__1580000013 }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) Invoke_O__O(self any) any { { var s__1580000014__1 any; var t_ any = t.F_s__1580000014; t.F_s__1580000014 = nil; s__1580000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1580000014__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var clause__4 any; var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_20; clause__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp3 any; var and__1927000168__auto____5 any; var tmp4 *lang.Var
															A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_21; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(clause__4); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp5 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_22; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_20; tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(clause__4))).Ref() } else { tmp3 = and__1927000168__auto____5 }
//line :51:1
	if jrt.A2g_Truth(tmp3) { var iterys__1927001035__auto____5 any; var tmp8 any = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_New(); var tmp9 *jrt.Class; A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_Init(); tmp9 = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_fn_class; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var fs__1927001036__auto____6 any; var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_19; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp13 *lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_30; fs__1927001036__auto____6 = tmp11.Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(clause__4))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp14 *lang.Var; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_37; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1580000013); var tmp17 *lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_30; return tmp15.Invoke_O_O__O(fs__1927001036__auto____6, tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(s__1580000014__1))) } else { var tmp18 *lang.Var; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_30; s__1580000014__1 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(s__1580000014__1); continue L1 } } else { var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_30; s__1580000014__1 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(s__1580000014__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :51:1
func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_New() *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_Init(); t := &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) Ctor() {}
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) Invoke_O_O__O(self, s__1580000016__1 any) any { var tmp1 any = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_New_O_O(s__1580000016__1, self); var tmp2 *jrt.Class; A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_Init(); tmp2 = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_Init(); t := &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) Ctor_O_O(c__s__1580000016, c__iter__1580000015 any) { t.F_s__1580000016 = c__s__1580000016; t.F_iter__1580000015 = c__iter__1580000015 }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) Invoke_O__O(self any) any { { var s__1580000016__1 any; var t_ any = t.F_s__1580000016; t.F_s__1580000016 = nil; s__1580000016__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1580000016__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1580000016__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1580000016__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_24; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1580000016__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1580000018__6 any; var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_25; b__1580000018__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1580000018__6); var tmp6 *jrt.Class; A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_Init(); tmp6 = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_33; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_35; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1580000018__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1580000015); var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_36; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1580000016__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_33; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_35; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1580000018__6), nil) } } else { var spec__4 any; var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_20; spec__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1580000016__3); var tmp17 any; var and__1927000168__auto____5 any; var tmp18 *lang.Var


	A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_26; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(spec__4); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp19 any; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_27; var tmp20 any = tmp19; var tmp21 *lang.Var; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_20; tmp17 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(spec__4))).Ref() } else { tmp17 = and__1927000168__auto____5 }
//line :51:1
	if jrt.A2g_Truth(tmp17) { var m__5 any; var tmp22 *lang.Var



		A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_28; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_15; var tmp25 any = jrt.NN(tmp24).GetRawRoot__O(); var tmp26 *lang.Var; A_arbace_g2a_print_A_Init(); tmp26 = A_arbace_g2a_print_A_const_30; m__5 = tmp23.Invoke_O_O__O(tmp25, lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(spec__4))
//line :51:1
		var tmp27 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_29; if jrt.A2g_Truth(jrt.NN(tmp27).Invoke_O__O(m__5)) { var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_34; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_g2a_print_A_Init(); tmp30 = A_arbace_g2a_print_A_const_32; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp32 = A_arbace_g2a_print_A_const_29; var tmp33 any = tmp31.Invoke_O__O(jrt.NN(tmp32).Invoke_O__O(m__5)); var tmp34 lang.IFn = lang.IFn_Cast(t.F_iter__1580000015); var tmp35 *lang.Var; A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_30; return tmp29.Invoke_O_O__O(tmp33, tmp34.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(s__1580000016__3))) } else { var tmp36 *lang.Var; A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_30; s__1580000016__1 = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(s__1580000016__3); continue L1 } } else { var tmp37 *lang.Var; A_arbace_g2a_print_A_Init(); tmp37 = A_arbace_g2a_print_A_const_30; s__1580000016__1 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(s__1580000016__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :51:1
func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_Init(); t := &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1580000018 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1580000018 = c__b__1580000018 }
//line :51:1
func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) Invoke_O__O(self any) any { { var i__1580000017__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1580000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1580000017__1)); var tmp2 any; var and__1927000168__auto____3 any; var tmp3 *lang.Var


	A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_26; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(spec__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp4 any; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_27; var tmp5 any = tmp4; var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_20; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(spec__2))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :51:1
	if jrt.A2g_Truth(tmp2) { var m__3 any; var tmp7 *lang.Var



		A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_15; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_30; m__3 = tmp8.Invoke_O_O__O(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(spec__2))
//line :51:1
		var tmp12 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_29; if jrt.A2g_Truth(jrt.NN(tmp12).Invoke_O__O(m__3)) { var tmp13 *lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_31; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_b__1580000018; var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_32; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_29; tmp14.Invoke_O_O__O(tmp15, tmp17.Invoke_O__O(jrt.NN(tmp18).Invoke_O__O(m__3))); i__1580000017__1 = lang.Numbers_Unchecked_inc_J__J(i__1580000017__1); continue L1 } else { i__1580000017__1 = lang.Numbers_Unchecked_inc_J__J(i__1580000017__1); continue L1 } } else { i__1580000017__1 = lang.Numbers_Unchecked_inc_J__J(i__1580000017__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }









func A_arbace_g2a_print_add_form_A_New() *A_arbace_g2a_print_add_form_A { A_arbace_g2a_print_add_form_A_Init(); t := &A_arbace_g2a_print_add_form_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_g2a_print_add_form_A) Ctor() {}
//line :61:1
func (t *A_arbace_g2a_print_add_form_A) Invoke_O_O_O_O__O(self, state__0, f__1, load_fn__2 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_14; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_15; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_46; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_47; var tmp8 *lang.Keyword = tmp7; var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_7; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp8).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(state__0))))
//line :61:1
	var tmp10 any; tmp112 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var o__6 any; var tmp11 *lang.Var



		A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_21; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(f__1)) { var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_38; o__6 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(f__1) } else { o__6 = nil }
		if lang.Util_Equiv_O_O__Z(o__6, Lit_69) {
			var tmp13 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp14 *lang.Var; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_39; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp17 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_47; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_17; var tmp20 any = jrt.NN(tmp19).GetRawRoot__O(); var tmp21 *lang.Var; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_48; tmp10 = jrt.NN(tmp13).Reset_O__O(tmp15.Invoke_O_O_O_O__O(tmp16, tmp18, tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(f__1))) } else {
//line :66:1
				if lang.Util_Equiv_O_O__Z(o__6, Lit_198) { tmp10 = nil } else { if lang.Util_Equiv_O_O__Z(o__6, Lit_199) { var seq_1580000030__7 any; var tmp22 *lang.Var


					A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_19; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_30; seq_1580000030__7 = tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(f__1))
//line :66:1
					var chunk_1580000031__8 any; var count_1580000032__9 int64 = 0; var i_1580000033__10 int64 = 0; L1: for {


						if lang.Numbers_Lt_J_J__Z(i_1580000033__10, count_1580000032__9) { var p__11 any = lang.Indexed_Cast(chunk_1580000031__8).Nth_I__O(lang.RT_IntCast_J__I(i_1580000033__10)); var tmp25 lang.IFn = lang.IFn_Cast(load_fn__2); var tmp26 *lang.Var; A_arbace_g2a_print_A_Init(); tmp26 = A_arbace_g2a_print_A_const_11; tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(p__11)); seq_1580000030__7, chunk_1580000031__8, count_1580000032__9, i_1580000033__10 = seq_1580000030__7, chunk_1580000031__8, count_1580000032__9, lang.Numbers_Unchecked_inc_J__J(i_1580000033__10); continue L1 } else { var temp__1927000414__auto____11 any; var tmp27 *lang.Var; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____11 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_1580000030__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1580000030__12 any = temp__1927000414__auto____11; var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_1580000030__12)) { var c__1927000678__auto____13 any; var tmp29 *lang.Var; A_arbace_g2a_print_A_Init(); tmp29 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____13 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_1580000030__12); var tmp30 *lang.Var; A_arbace_g2a_print_A_Init(); tmp30 = A_arbace_g2a_print_A_const_36; seq_1580000030__7, chunk_1580000031__8, count_1580000032__9, i_1580000033__10 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq_1580000030__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var p__13 any; var tmp31 *lang.Var; A_arbace_g2a_print_A_Init(); tmp31 = A_arbace_g2a_print_A_const_20; p__13 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(seq_1580000030__12); var tmp32 lang.IFn = lang.IFn_Cast(load_fn__2); var tmp33 *lang.Var; A_arbace_g2a_print_A_Init(); tmp33 = A_arbace_g2a_print_A_const_11; tmp32.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(p__13)); var tmp34 *lang.Var; A_arbace_g2a_print_A_Init(); tmp34 = A_arbace_g2a_print_A_const_40; seq_1580000030__7, chunk_1580000031__8, count_1580000032__9, i_1580000033__10 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(seq_1580000030__12), nil, 0, 0; continue L1 } } else { tmp10 = nil } }
//line :66:1
						break L1 } } else { if lang.Util_Equiv_O_O__Z(o__6, Lit_200) { var vec__1580000034__7 any = f__1; var seq__1580000035__8 any; var tmp35 *lang.Var




							A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_19; seq__1580000035__8 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(vec__1580000034__7)
//line :66:1
							var first__1580000036__9 any; var tmp36 *lang.Var




							A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_20; first__1580000036__9 = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(seq__1580000035__8)
//line :66:1
							var seq__1580000035__10 any; var tmp37 *lang.Var




							A_arbace_g2a_print_A_Init(); tmp37 = A_arbace_g2a_print_A_const_40; seq__1580000035__10 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(seq__1580000035__8)
//line :66:1
							var ___11 any = first__1580000036__9; var first__1580000036__12 any; var tmp38 *lang.Var; _ = ___11




							A_arbace_g2a_print_A_Init(); tmp38 = A_arbace_g2a_print_A_const_20; first__1580000036__12 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(seq__1580000035__10)
//line :66:1
							var seq__1580000035__13 any; var tmp39 *lang.Var




							A_arbace_g2a_print_A_Init(); tmp39 = A_arbace_g2a_print_A_const_40; seq__1580000035__13 = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(seq__1580000035__10)
//line :66:1
							var nm__14 any = first__1580000036__12; var opts__15 any = seq__1580000035__13; var tmp40 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp41 *lang.Var





							A_arbace_g2a_print_A_Init(); tmp41 = A_arbace_g2a_print_A_const_41; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp44 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp44 = A_arbace_g2a_print_A_const_49; var tmp45 any = tmp44.Ref(); var tmp46 *lang.Var; A_arbace_g2a_print_A_Init(); tmp46 = A_arbace_g2a_print_A_const_28; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_g2a_print_A_Init(); tmp48 = A_arbace_g2a_print_A_const_15; var tmp49 any = tmp47.Invoke_O_O__O(jrt.NN(tmp48).GetRawRoot__O(), opts__15); var tmp50 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp50 = A_arbace_g2a_print_A_const_50; tmp10 = jrt.NN(tmp40).Reset_O__O(tmp42.Invoke_O_O_O_O_O__O(tmp43, tmp45, tmp49, tmp50.Ref(), nm__14)) } else {
//line :66:1
								if lang.Util_Equiv_O_O__Z(o__6, Lit_201) { var vec__1580000037__7 any = f__1; var seq__1580000038__8 any; var tmp51 *lang.Var







									A_arbace_g2a_print_A_Init(); tmp51 = A_arbace_g2a_print_A_const_19; seq__1580000038__8 = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(vec__1580000037__7)
//line :66:1
									var first__1580000039__9 any; var tmp52 *lang.Var







									A_arbace_g2a_print_A_Init(); tmp52 = A_arbace_g2a_print_A_const_20; first__1580000039__9 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(seq__1580000038__8)
//line :66:1
									var seq__1580000038__10 any; var tmp53 *lang.Var







									A_arbace_g2a_print_A_Init(); tmp53 = A_arbace_g2a_print_A_const_40; seq__1580000038__10 = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq__1580000038__8)
//line :66:1
									var ___11_2 any = first__1580000039__9; var first__1580000039__12 any; var tmp54 *lang.Var; _ = ___11_2







									A_arbace_g2a_print_A_Init(); tmp54 = A_arbace_g2a_print_A_const_20; first__1580000039__12 = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(seq__1580000038__10)
//line :66:1
									var seq__1580000038__13 any; var tmp55 *lang.Var







									A_arbace_g2a_print_A_Init(); tmp55 = A_arbace_g2a_print_A_const_40; seq__1580000038__13 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(seq__1580000038__10)
//line :66:1
									var nm__14_2 any = first__1580000039__12; var opts__15_2 any = seq__1580000038__13; var tmp56 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp57 *lang.Var








									A_arbace_g2a_print_A_Init(); tmp57 = A_arbace_g2a_print_A_const_39; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp60 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp60 = A_arbace_g2a_print_A_const_51; var tmp61 any = tmp60.Ref(); var tmp62 *lang.Var; A_arbace_g2a_print_A_Init(); tmp62 = A_arbace_g2a_print_A_const_8; var tmp63 any = jrt.NN(tmp62).GetRawRoot__O(); var tmp64 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp64 = A_arbace_g2a_print_A_const_50; var tmp65 any = tmp64.Ref(); var tmp66 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp66 = A_arbace_g2a_print_A_const_52; var tmp67 any = tmp66.Ref(); var tmp68 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp68 = A_arbace_g2a_print_A_const_53; var tmp69 any = tmp68.Ref(); var tmp70 *lang.Var; A_arbace_g2a_print_A_Init(); tmp70 = A_arbace_g2a_print_A_const_28; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Var; A_arbace_g2a_print_A_Init(); tmp72 = A_arbace_g2a_print_A_const_15; var tmp73 any = tmp71.Invoke_O_O__O(jrt.NN(tmp72).GetRawRoot__O(), opts__15_2); var tmp74 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp74 = A_arbace_g2a_print_A_const_54; var tmp75 any = tmp74.Ref(); var tmp76 *lang.PersistentVector; lang.PersistentVector_Init(); tmp76 = lang.PersistentVector_EMPTY; var tmp77 any = tmp76.Ref(); var tmp78 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp78 = A_arbace_g2a_print_A_const_55; var tmp79 any = tmp78.Ref(); var tmp80 *lang.Var; A_arbace_g2a_print_A_Init(); tmp80 = A_arbace_g2a_print_A_const_56; tmp10 = jrt.NN(tmp56).Reset_O__O(tmp58.Invoke_O_O_O_O__O(tmp59, tmp61, tmp63, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp65, nm__14_2, tmp67, f__1, tmp69, tmp73, tmp75, tmp77, tmp79, jrt.NN(tmp80).Get__O())))) } else {
//line :66:1
										var tmp81 any; var and__1927000168__auto____7 any; var tmp82 *lang.Var










										A_arbace_g2a_print_A_Init(); tmp82 = A_arbace_g2a_print_A_const_21; and__1927000168__auto____7 = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(f__1); if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp83 *lang.Var; A_arbace_g2a_print_A_Init(); tmp83 = A_arbace_g2a_print_A_const_42; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 *lang.Var; A_arbace_g2a_print_A_Init(); tmp85 = A_arbace_g2a_print_A_const_11; tmp81 = tmp84.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()).Invoke_O__O(o__6), Lit_202) } else { tmp81 = and__1927000168__auto____7 }
//line :66:1
										if jrt.A2g_Truth(tmp81) {











											var tmp86 *lang.Var; A_arbace_g2a_print_A_Init(); tmp86 = A_arbace_g2a_print_A_const_43; var tmp87 lang.IFn = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()); var tmp88 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp88 = A_arbace_g2a_print_A_const_51; var tmp89 *lang.Keyword = tmp88; var tmp90 *lang.Var; A_arbace_g2a_print_A_Init(); tmp90 = A_arbace_g2a_print_A_const_7; if jrt.A2g_Truth(tmp87.Invoke_O__O(jrt.NN(tmp89).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()).Invoke_O__O(state__0)))) { var tmp91 *lang.Var; A_arbace_g2a_print_A_Init(); tmp91 = A_arbace_g2a_print_A_const_44; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_203, nil); var tmp94 *lang.Var; A_arbace_g2a_print_A_Init(); tmp94 = A_arbace_g2a_print_A_const_57; var tmp95 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp93, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var tmp96 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp96 = A_arbace_g2a_print_A_const_58; panic(jrt.Thrown(jrt.Throwable_Cast(tmp92.Invoke_O_O__O(tmp95, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp96.Ref(), f__1)))))) } else {

												var tmp97 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp98 *lang.Var; A_arbace_g2a_print_A_Init(); tmp98 = A_arbace_g2a_print_A_const_39; var tmp99 lang.IFn = lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()); var tmp100 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp101 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp101 = A_arbace_g2a_print_A_const_51; var tmp102 any = tmp101.Ref(); var tmp103 any = A_arbace_g2a_print_add_form_fn__1580000040_A_New_O(f__1); var tmp104 *jrt.Class; A_arbace_g2a_print_add_form_fn__1580000040_A_Init(); tmp104 = A_arbace_g2a_print_add_form_fn__1580000040_A_fn_class; tmp10 = jrt.NN(tmp97).Reset_O__O(tmp99.Invoke_O_O_O__O(tmp100, tmp102, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp103, tmp104, nil))) } } else {
//line :66:1
													if lang.Util_Identical_O_O__Z(f__1, nil) { tmp10 = nil } else { var tmp105 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp105 = A_arbace_g2a_print_A_const_45; if tmp105 != nil { var tmp106 *lang.Var; A_arbace_g2a_print_A_Init(); tmp106 = A_arbace_g2a_print_A_const_44; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_204, nil); var tmp109 *lang.Var; A_arbace_g2a_print_A_Init(); tmp109 = A_arbace_g2a_print_A_const_57; var tmp110 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp108, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var tmp111 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp111 = A_arbace_g2a_print_A_const_58; panic(jrt.Thrown(jrt.Throwable_Cast(tmp107.Invoke_O_O__O(tmp110, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp111.Ref(), f__1)))))) } else { tmp10 = nil } } } } } } } } }; return nil }()
//line :61:1
	var tmp113 *lang.Var


	A_arbace_g2a_print_A_Init(); tmp113 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()).Invoke__O()
//line :61:1
	if tmp112 != nil { panic(tmp112) }; return tmp10
}

















func A_arbace_g2a_print_add_form_fn__1580000040_A_New_O(p0 any) *A_arbace_g2a_print_add_form_fn__1580000040_A { A_arbace_g2a_print_add_form_fn__1580000040_A_Init(); t := &A_arbace_g2a_print_add_form_fn__1580000040_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :80:1
func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_8; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_59; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(fs__1); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_39; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_60; var tmp8 any = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(fs__1); var tmp9 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_54; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_8; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O_O_O__O(tmp8, tmp10, jrt.NN(tmp11).GetRawRoot__O(), t.F_f)) }



func A_arbace_g2a_print_new_package_state_A_New() *A_arbace_g2a_print_new_package_state_A { A_arbace_g2a_print_new_package_state_A_Init(); t := &A_arbace_g2a_print_new_package_state_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_g2a_print_new_package_state_A) Ctor() {}
//line :84:1
func (t *A_arbace_g2a_print_new_package_state_A) Invoke_O__O(self any) any {
	var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_61; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_49; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_50; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_51; var tmp8 any = tmp7.Ref(); var tmp9 *lang.PersistentVector; lang.PersistentVector_Init(); tmp9 = lang.PersistentVector_EMPTY; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_47; var tmp12 any = tmp11.Ref(); var tmp13 any; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_62; return tmp2.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp6, nil, tmp8, tmp10, tmp12, tmp13)))
}
func A_arbace_g2a_print_collect_forms_A_New() *A_arbace_g2a_print_collect_forms_A { A_arbace_g2a_print_collect_forms_A_Init(); t := &A_arbace_g2a_print_collect_forms_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_g2a_print_collect_forms_A) Ctor() {}
//line :87:1
func (t *A_arbace_g2a_print_collect_forms_A) Invoke_O_O__O(self, forms__0 any) any { var state__2 any; var tmp1 *lang.Var;



	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_63; state__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O(); var seq_1580000044__3 any; var tmp2 /*line :87:1*/*lang.Var;




	A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_19; seq_1580000044__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(forms__0); var chunk_1580000045__4 any; var count_1580000046__5 int64 = 0; var i_1580000047__6 int64 = 0; L1:
//line :87:1
	for {




		if lang.Numbers_Lt_J_J__Z(i_1580000047__6, count_1580000046__5) { var f__7 any = lang.Indexed_Cast(chunk_1580000045__4).Nth_I__O(lang.RT_IntCast_J__I(i_1580000047__6)); var tmp3 *lang.Var
			A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_65; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_collect_forms_fn__1580000048_A_New(); var tmp6 *jrt.Class; A_arbace_g2a_print_collect_forms_fn__1580000048_A_Init(); tmp6 = A_arbace_g2a_print_collect_forms_fn__1580000048_A_fn_class; tmp4.Invoke_O_O_O__O(state__2, f__7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))
//line :92:1
			seq_1580000044__3, chunk_1580000045__4, count_1580000046__5, i_1580000047__6 = seq_1580000044__3, chunk_1580000045__4, count_1580000046__5, lang.Numbers_Unchecked_inc_J__J(i_1580000047__6); continue L1 } else { var temp__1927000414__auto____7 any; var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_1580000044__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1580000044__8 any = temp__1927000414__auto____7; var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_1580000044__8)) { var c__1927000678__auto____9 any; var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_1580000044__8); var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_36; seq_1580000044__3, chunk_1580000045__4, count_1580000046__5, i_1580000047__6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_1580000044__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__9 any; var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_20; f__9 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_1580000044__8)
				var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_65; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_g2a_print_collect_forms_fn__1580000050_A_New(); var tmp15 *jrt.Class; A_arbace_g2a_print_collect_forms_fn__1580000050_A_Init(); tmp15 = A_arbace_g2a_print_collect_forms_fn__1580000050_A_fn_class; tmp13.Invoke_O_O_O__O(state__2, f__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil))
//line :92:1
				var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_40; seq_1580000044__3, chunk_1580000045__4, count_1580000046__5, i_1580000047__6 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1580000044__8), nil, 0, 0; continue L1 } } }
//line :87:1
		break L1 }; var tmp17 /*line :94:1*/*lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_64; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_7; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(state__2); var tmp21 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_47; return tmp18.Invoke_O_O__O(tmp20, tmp21.Ref()) }
//line :93:1
func A_arbace_g2a_print_collect_forms_fn__1580000048_A_New() *A_arbace_g2a_print_collect_forms_fn__1580000048_A { A_arbace_g2a_print_collect_forms_fn__1580000048_A_Init(); t := &A_arbace_g2a_print_collect_forms_fn__1580000048_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) Ctor() {}
//line :93:1
func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_44; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_244, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(); var tmp4 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_66; panic(jrt.Thrown(jrt.Throwable_Cast(tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4.Ref(), p__1)))))) }
//line :93:1
func A_arbace_g2a_print_collect_forms_fn__1580000050_A_New() *A_arbace_g2a_print_collect_forms_fn__1580000050_A { A_arbace_g2a_print_collect_forms_fn__1580000050_A_Init(); t := &A_arbace_g2a_print_collect_forms_fn__1580000050_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) Ctor() {}
//line :93:1
func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_44; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_244, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(); var tmp4 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_66; panic(jrt.Thrown(jrt.Throwable_Cast(tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4.Ref(), p__1)))))) }


func A_arbace_g2a_print_collect_A_New() *A_arbace_g2a_print_collect_A { A_arbace_g2a_print_collect_A_Init(); t := &A_arbace_g2a_print_collect_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_g2a_print_collect_A) Ctor() {}
//line :96:1
func (t *A_arbace_g2a_print_collect_A) Invoke_O_O_O__O(self, path__0, read_fn__1 any) any { var state__3 any; var tmp1 *lang.Var;







	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_63; state__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O(); var root__4 any; var tmp2 /*line :96:1*/*lang.Var;








	A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_61; root__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(nil); var body_walk__5 /*line :96:1*/*A_arbace_g2a_print_collect_walk__1580000054_A = A_arbace_g2a_print_collect_walk__1580000054_A_New_O_O_O(state__3, read_fn__1, root__4); var walk__5 any; var tmp3 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_A_Init(); tmp3 = A_arbace_g2a_print_collect_walk__1580000054_A_fn_class; walk__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_walk__5.Ref(), tmp3, nil); var tmp4 lang.IFn =





















	lang.IFn_Cast(walk__5); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_11; tmp4.Invoke_O__O(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(path__0)))); var tmp6 /*line :119:1*/*lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_64; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_7; var tmp9 any = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(state__3); var tmp10 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_47; return tmp7.Invoke_O_O__O(tmp9, tmp10.Ref()) }
//line :96:1
func (t *A_arbace_g2a_print_collect_A) Invoke_O_O__O(self, path__0 any) any {





	var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_75; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_76; return tmp2.Invoke_O_O__O(path__0, jrt.NN(tmp3).GetRawRoot__O())
}


func A_arbace_g2a_print_collect_walk__1580000054_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_print_collect_walk__1580000054_A { A_arbace_g2a_print_collect_walk__1580000054_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :106:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_A) Ctor_O_O_O(c__state, c__read_fn, c__root any) { t.F_state = c__state; t.F_read_fn = c__read_fn; t.F_root = c__root }
//line :106:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_A) Invoke_O_O__O(self, file__1 any) any { { var seq_1580000055__2 any; var tmp1 *lang.Var
												A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_14; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_15; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_56; var tmp9 any = tmp8.Ref(); tmp5.Invoke_O__O(tmp7.Invoke_O_O__O(tmp9, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref())); var tmp10 any = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_New_O_O(t.F_read_fn, file__1); var tmp11 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_Init(); tmp11 = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_fn_class; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O(); seq_1580000055__2 = tmp2.Invoke_O__O(tmp3)
//line :106:1
	var chunk_1580000056__3 any; var count_1580000057__4 int64 = 0; var i_1580000058__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1580000058__5, count_1580000057__4) { var f__6 any = lang.Indexed_Cast(chunk_1580000056__3).Nth_I__O(lang.RT_IntCast_J__I(i_1580000058__5)); var tmp12 any; var and__1927000168__auto____7 bool; var tmp13 *lang.Var
			A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_7; and__1927000168__auto____7 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(t.F_root), nil); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var tmp14 *lang.Var; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_21; and__1927000168__auto____8 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(f__6); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp15 any; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_69; var tmp16 any = tmp15; var tmp17 *lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_20; tmp12 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp16, lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(f__6))).Ref() } else { tmp12 = and__1927000168__auto____8 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.A2g_Truth(tmp12) { var depth__7 int32; var tmp18 *lang.Var
				A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_70; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_72; var tmp21 any = tmp20; var tmp22 *lang.Var; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_11; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_73; depth__7 = lang.RT_Count_O__I(tmp19.Invoke_O_O__O(tmp21, tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(f__6))))
				var tmp25 *lang.Var; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_71; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any = t.F_root; var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_74; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_New(); var tmp31 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_Init(); tmp31 = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_fn_class; tmp26.Invoke_O_O__O(tmp27, lang.RT_Nth_O_I__O(tmp29.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil), jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref()), lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(int64(depth__7)))))
			}
			var tmp32 *lang.Var; A_arbace_g2a_print_A_Init(); tmp32 = A_arbace_g2a_print_A_const_14; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_g2a_print_A_Init(); tmp34 = A_arbace_g2a_print_A_const_15; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_56; var tmp37 any = tmp36.Ref(); tmp33.Invoke_O__O(tmp35.Invoke_O_O__O(tmp37, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref())); var tmp38 any = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_New_O_O_O_O_O(f__6, self, t.F_state, file__1, t.F_root); var tmp39 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_Init(); tmp39 = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil).Invoke__O()
//line :107:1
			seq_1580000055__2, chunk_1580000056__3, count_1580000057__4, i_1580000058__5 = seq_1580000055__2, chunk_1580000056__3, count_1580000057__4, lang.Numbers_Unchecked_inc_J__J(i_1580000058__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp40 *lang.Var; A_arbace_g2a_print_A_Init(); tmp40 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq_1580000055__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1580000055__7 any = temp__1927000414__auto____6; var tmp41 *lang.Var; A_arbace_g2a_print_A_Init(); tmp41 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_1580000055__7)) { var c__1927000678__auto____8 any; var tmp42 *lang.Var; A_arbace_g2a_print_A_Init(); tmp42 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_1580000055__7); var tmp43 *lang.Var; A_arbace_g2a_print_A_Init(); tmp43 = A_arbace_g2a_print_A_const_36; seq_1580000055__2, chunk_1580000056__3, count_1580000057__4, i_1580000058__5 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(seq_1580000055__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__8 any; var tmp44 *lang.Var; A_arbace_g2a_print_A_Init(); tmp44 = A_arbace_g2a_print_A_const_20; f__8 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq_1580000055__7)
				var tmp45 any; var and__1927000168__auto____9 bool; var tmp46 *lang.Var; A_arbace_g2a_print_A_Init(); tmp46 = A_arbace_g2a_print_A_const_7; and__1927000168__auto____9 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(t.F_root), nil); if and__1927000168__auto____9 { var and__1927000168__auto____10 any; var tmp47 *lang.Var; A_arbace_g2a_print_A_Init(); tmp47 = A_arbace_g2a_print_A_const_21; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(f__8); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp48 any; A_arbace_g2a_print_A_Init(); tmp48 = A_arbace_g2a_print_A_const_69; var tmp49 any = tmp48; var tmp50 *lang.Var; A_arbace_g2a_print_A_Init(); tmp50 = A_arbace_g2a_print_A_const_20; tmp45 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp49, lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(f__8))).Ref() } else { tmp45 = and__1927000168__auto____10 } } else { tmp45 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.A2g_Truth(tmp45) { var depth__9 int32; var tmp51 *lang.Var
					A_arbace_g2a_print_A_Init(); tmp51 = A_arbace_g2a_print_A_const_70; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; A_arbace_g2a_print_A_Init(); tmp53 = A_arbace_g2a_print_A_const_72; var tmp54 any = tmp53; var tmp55 *lang.Var; A_arbace_g2a_print_A_Init(); tmp55 = A_arbace_g2a_print_A_const_11; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_g2a_print_A_Init(); tmp57 = A_arbace_g2a_print_A_const_73; depth__9 = lang.RT_Count_O__I(tmp52.Invoke_O_O__O(tmp54, tmp56.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(f__8))))
					var tmp58 *lang.Var; A_arbace_g2a_print_A_Init(); tmp58 = A_arbace_g2a_print_A_const_71; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any = t.F_root; var tmp61 *lang.Var; A_arbace_g2a_print_A_Init(); tmp61 = A_arbace_g2a_print_A_const_74; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 any = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_New(); var tmp64 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_Init(); tmp64 = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_fn_class; tmp59.Invoke_O_O__O(tmp60, lang.RT_Nth_O_I__O(tmp62.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp63, tmp64, nil), jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref()), lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(int64(depth__9)))))
				}
				var tmp65 *lang.Var; A_arbace_g2a_print_A_Init(); tmp65 = A_arbace_g2a_print_A_const_14; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Var; A_arbace_g2a_print_A_Init(); tmp67 = A_arbace_g2a_print_A_const_15; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Var; A_arbace_g2a_print_A_Init(); tmp69 = A_arbace_g2a_print_A_const_56; var tmp70 any = tmp69.Ref(); tmp66.Invoke_O__O(tmp68.Invoke_O_O__O(tmp70, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref())); var tmp71 any = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_New_O_O_O_O_O(self, t.F_state, file__1, f__8, t.F_root); var tmp72 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_Init(); tmp72 = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil).Invoke__O()
//line :107:1
				var tmp73 *lang.Var; A_arbace_g2a_print_A_Init(); tmp73 = A_arbace_g2a_print_A_const_40; seq_1580000055__2, chunk_1580000056__3, count_1580000057__4, i_1580000058__5 = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(seq_1580000055__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :106:1*/panic("a2g: unreachable") }
func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :107:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) Ctor_O_O(c__read_fn, c__file any) { t.F_read_fn = c__read_fn; t.F_file = c__file }
//line :107:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_read_fn; t.F_read_fn = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_file; t.F_file = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_New() *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) Ctor() {}
//line :110:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) Invoke_O_O__O(self, p1__1580000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1580000053_SHARP___1)).GetParentFile__File().Ref() }
//line :110:1
func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_New() *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) Ctor() {}
//line :110:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) Invoke_O_O__O(self, p1__1580000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1580000053_SHARP___1)).GetParentFile__File().Ref() }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :112:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) Ctor_O_O_O_O_O(c__f, c__walk, c__state, c__file, c__root any) { t.F_f = c__f; t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_root = c__root }
//line :112:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_65; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_state; t.F_state = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var t__2 any = t.F_f; t.F_f = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp9 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_Init(); tmp9 = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_fn_class; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) }
//line :112:1
	return nil }(); var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }
//line :112:1
func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :112:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) Ctor_O_O_O_O_O(c__walk, c__state, c__file, c__f, c__root any) { t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_f = c__f; t.F_root = c__root }
//line :112:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_65; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_state; t.F_state = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var t__2 any = t.F_f; t.F_f = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp9 *jrt.Class; A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_Init(); tmp9 = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_fn_class; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) }
//line :112:1
	return nil }(); var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :114:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_42; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(p__1, Lit_196)) { var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_7; var tmp5 *jrt.File = jrt.File_Cast(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t.F_root)); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_238); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_67; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_68; tmp2 = jrt.File_New_File_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8.Invoke_O_O__O(p__1, tmp9), nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_238), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref()) }
//line :114:1
func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_Init(); t := &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :114:1
func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_42; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(p__1, Lit_196)) { var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_7; var tmp5 *jrt.File = jrt.File_Cast(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t.F_root)); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_238); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_67; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_68; tmp2 = jrt.File_New_File_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8.Invoke_O_O__O(p__1, tmp9), nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_238), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref())
}







func A_arbace_g2a_print_import_spec_A_New() *A_arbace_g2a_print_import_spec_A { A_arbace_g2a_print_import_spec_A_Init(); t := &A_arbace_g2a_print_import_spec_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_g2a_print_import_spec_A) Ctor() {}
//line :124:1
func (t *A_arbace_g2a_print_import_spec_A) Invoke_O_O__O(self, v__0 any) any { var vec__1580000075__2 any = v__0; var nm__3 any = lang.RT_Nth_O_I_O__O(vec__1580000075__2, lang.RT_IntCast_J__I(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O(vec__1580000075__2, lang.RT_IntCast_J__I(1), nil); var explicit_QMARK___5 any; var or__1927000174__auto____5 any; var tmp1 *lang.Keyword;

	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_77; var tmp2 *lang.Keyword = tmp1; or__1927000174__auto____5 = jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__0)); if jrt.A2g_Truth(or__1927000174__auto____5) { explicit_QMARK___5 = or__1927000174__auto____5 } else { var tmp3 any; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_78; var tmp4 lang.IFn = lang.IFn_Cast(tmp3); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_11; explicit_QMARK___5 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(nm__3)) }; if
	jrt.A2g_Truth(explicit_QMARK___5) { var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_79; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_11; tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(nm__3)); var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_80; lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke__O() }; var tmp10 /*line :128:1*/*lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_79; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_81; return tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(path__4)) }

func A_arbace_g2a_print_write_import_decl_A_New() *A_arbace_g2a_print_write_import_decl_A { A_arbace_g2a_print_write_import_decl_A_Init(); t := &A_arbace_g2a_print_write_import_decl_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_g2a_print_write_import_decl_A) Ctor() {}
//line :130:1
func (t *A_arbace_g2a_print_write_import_decl_A) Invoke_O_O__O(self, specs__0 any) any {
	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(specs__0))) {
		var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_79; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_308); var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_80; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke__O(); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_83; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_20; tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(specs__0)); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_82; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_84; return tmp7.Invoke_O__O(tmp8) } else {
			var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_79; lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(Lit_308); var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_80; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke__O(); var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_79; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(Lit_309)
			var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_82; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_68; tmp13.Invoke_O__O(tmp14)
//line :131:1
			var G__1580000082__2_ any = specs__0; var vec__1580000083__3 any = G__1580000082__2_; var seq__1580000084__4 any; var tmp15 *lang.Var



			A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_19; seq__1580000084__4 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(vec__1580000083__3)
//line :131:1
			var first__1580000085__5 any; var tmp16 *lang.Var



			A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_20; first__1580000085__5 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq__1580000084__4)
//line :131:1
			var seq__1580000084__6 any; var tmp17 *lang.Var



			A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_40; seq__1580000084__6 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq__1580000084__4)
//line :131:1
			var v__7 any = first__1580000085__5; var more__8 any = seq__1580000084__6; var prev__9 any; var G__1580000082__10_ any = G__1580000082__2_; var prev__11 any = prev__9; _ = v__7; _ = more__8; L1: for { var vec__1580000086__12 any = G__1580000082__10_; var seq__1580000087__13 any; var tmp18 *lang.Var



				A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_19; seq__1580000087__13 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(vec__1580000086__12)
//line :131:1
				var first__1580000088__14 any; var tmp19 *lang.Var



				A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_20; first__1580000088__14 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq__1580000087__13)
//line :131:1
				var seq__1580000087__15 any; var tmp20 *lang.Var



				A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_40; seq__1580000087__15 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq__1580000087__13)
//line :131:1
				var v__16 any = first__1580000088__14
				var more__17 any = seq__1580000087__15
				var prev__18 any = prev__11


				if jrt.A2g_Truth(v__16) {


					var tmp21 any; var and__1927000168__auto____19 any = prev__18; if jrt.A2g_Truth(and__1927000168__auto____19) { var tmp22 *lang.Var; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_11; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_73; var tmp25 any = tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(v__16)); var tmp26 *lang.Var; A_arbace_g2a_print_A_Init(); tmp26 = A_arbace_g2a_print_A_const_11; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_73; tmp21 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(tmp25, tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(prev__18)))))).Ref() } else { tmp21 = and__1927000168__auto____19 }; if jrt.A2g_Truth(tmp21) {
						var tmp29 *lang.Var; A_arbace_g2a_print_A_Init(); tmp29 = A_arbace_g2a_print_A_const_82; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_g2a_print_A_Init(); tmp31 = A_arbace_g2a_print_A_const_68; tmp30.Invoke_O__O(tmp31) }
					var tmp32 *lang.Var; A_arbace_g2a_print_A_Init(); tmp32 = A_arbace_g2a_print_A_const_83; lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(v__16)
					var tmp33 *lang.Var; A_arbace_g2a_print_A_Init(); tmp33 = A_arbace_g2a_print_A_const_82; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; if jrt.A2g_Truth(more__17) { A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_68 } else { A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_84 }; tmp34.Invoke_O__O(tmp35)
					G__1580000082__10_, prev__11 = more__17, v__16; continue L1 }
//line :131:1
				break L1
			}











			var tmp36 *lang.Var; A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_79; lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(Lit_310); var tmp37 *lang.Var; A_arbace_g2a_print_A_Init(); tmp37 = A_arbace_g2a_print_A_const_82; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_g2a_print_A_Init(); tmp39 = A_arbace_g2a_print_A_const_84; return tmp38.Invoke_O__O(tmp39)
		} }
func A_arbace_g2a_print_write_imports_A_New() *A_arbace_g2a_print_write_imports_A { A_arbace_g2a_print_write_imports_A_Init(); t := &A_arbace_g2a_print_write_imports_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_g2a_print_write_imports_A) Ctor() {}
//line :146:1
func (t *A_arbace_g2a_print_write_imports_A) Invoke_O_O__O(self, imports__0 any) any {



	{ var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(imports__0)) {
		var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_82; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_84; tmp3.Invoke_O__O(tmp4)
//line :150:1
		var directive_QMARK___2 any; var tmp5 any = A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_New(); var tmp6 *jrt.Class

		A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_Init(); tmp6 = A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_fn_class; directive_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :150:1
		var xs__3 any; var tmp7 *lang.Var


		A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_19; xs__3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(imports__0)
//line :150:1
	L1: for {



		if jrt.A2g_Truth(xs__3) {
			var tmp8 lang.IFn = lang.IFn_Cast(directive_QMARK___2); var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_20; if jrt.A2g_Truth(tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(xs__3))) {
				var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_86; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_11; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_73; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_20; var tmp17 any = tmp13.Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(xs__3))); var tmp18 any; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_84; tmp11.Invoke_O_O__O(tmp17, tmp18)
				var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_40; xs__3 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(xs__3); continue L1 } else {
//line :155:1
					var vec__1580000093__4 any; var tmp20 *lang.Var


					A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_85; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_87; vec__1580000093__4 = tmp21.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(directive_QMARK___2), xs__3)
//line :155:1
					var specs__5 any = lang.RT_Nth_O_I_O__O(vec__1580000093__4, lang.RT_IntCast_J__I(0), nil); var more__6 any = lang.RT_Nth_O_I_O__O(vec__1580000093__4, lang.RT_IntCast_J__I(1), nil); var tmp23 *lang.Var



					A_arbace_g2a_print_A_Init(); tmp23 = A_arbace_g2a_print_A_const_88; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_89; tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(specs__5))
					var tmp26 *lang.Var; A_arbace_g2a_print_A_Init(); tmp26 = A_arbace_g2a_print_A_const_19; xs__3 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(more__6); continue L1 } } else {
//line :154:1
						return nil } } } else {
//line :150:1
							return nil } }
//line :146:1
	panic("a2g: unreachable")
}




func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_New() *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A { A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_Init(); t := &A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) Ctor() {}
//line :152:1
func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) Invoke_O_O__O(self, p1__1580000090_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_21; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__1580000090_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_38; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p1__1580000090_SHARP___1), Lit_260)).Ref() } else { return and__1927000168__auto____2 } }









func A_arbace_g2a_print_one_line_func_QMARK__A_New() *A_arbace_g2a_print_one_line_func_QMARK__A { A_arbace_g2a_print_one_line_func_QMARK__A_Init(); t := &A_arbace_g2a_print_one_line_func_QMARK__A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_g2a_print_one_line_func_QMARK__A) Ctor() {}
//line :162:1
func (t *A_arbace_g2a_print_one_line_func_QMARK__A) Invoke_O_O_O_O__O(self, f__0, lines_QMARK___1, t__2 any) any { var and__1927000168__auto____4 any; var tmp1 any;



	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_90; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_38; and__1927000168__auto____4 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____4) {
		if jrt.A2g_Truth(lines_QMARK___1) { var and__1927000168__auto____5 any = t__2
			if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp4 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_91; var tmp5 *lang.Keyword = tmp4; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(jrt.NN(tmp5).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)), t__2)).Ref() } else { return and__1927000168__auto____5 } } else {
//line :167:1
				var vec__1580000097__5 any = f__0; var seq__1580000098__6 any; var tmp6 *lang.Var

				A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_19; seq__1580000098__6 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(vec__1580000097__5)
//line :167:1
				var first__1580000099__7 any; var tmp7 *lang.Var

				A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_20; first__1580000099__7 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__1580000098__6)
//line :167:1
				var seq__1580000098__8 any; var tmp8 *lang.Var

				A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_40; seq__1580000098__8 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__1580000098__6)
//line :167:1
				var ___9 any = first__1580000099__7; var first__1580000099__10 any; var tmp9 *lang.Var; _ = ___9

				A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_20; first__1580000099__10 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq__1580000098__8)
//line :167:1
				var seq__1580000098__11 any; var tmp10 *lang.Var

				A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_40; seq__1580000098__11 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq__1580000098__8)
//line :167:1
				var nm__12 any = first__1580000099__10; var xs__13 any = seq__1580000098__11; var vec__1580000100__14 any; var tmp11 *lang.Var


				A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_92; vec__1580000100__14 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(xs__13)
//line :167:1
				var ___15 any = lang.RT_Nth_O_I_O__O(vec__1580000100__14, lang.RT_IntCast_J__I(0), nil); var ___16 any = lang.RT_Nth_O_I_O__O(vec__1580000100__14, lang.RT_IntCast_J__I(1), nil); var xs__17 any = lang.RT_Nth_O_I_O__O(vec__1580000100__14, lang.RT_IntCast_J__I(2), nil); var body__18 any; var tmp12 *lang.Var; _ = ___15; _ = ___16



				A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_30; body__18 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(xs__17)
//line :167:1
				var body__19 any; var tmp13 *lang.Var




				A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_20; var tmp14 any = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(body__18); var tmp15 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_93; if lang.Util_Equiv_O_O__Z(tmp14, tmp15.Ref()) { var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_94; body__19 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(body__18) } else { body__19 = body__18 }
//line :167:1
				var and__1927000168__auto____20 any; var tmp17 *lang.Var





				A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_43; and__1927000168__auto____20 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(body__19); if jrt.A2g_Truth(and__1927000168__auto____20) { var tmp18 *lang.Var; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_95; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_96; var tmp21 *lang.Keyword = tmp20; return tmp19.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__12))) } else { return and__1927000168__auto____20 } } } else {
//line :166:1
					return and__1927000168__auto____4 } }








func A_arbace_g2a_print_decl_pre_A_New() *A_arbace_g2a_print_decl_pre_A { A_arbace_g2a_print_decl_pre_A_Init(); t := &A_arbace_g2a_print_decl_pre_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_g2a_print_decl_pre_A) Ctor() {}
//line :175:1
func (t *A_arbace_g2a_print_decl_pre_A) Invoke_O_O__O(self, f__0 any) any { var directive_QMARK___2 bool; var tmp1 *lang.Var;


	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_38; directive_QMARK___2 = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0), Lit_260); var vec__1580000104__3 any; if directive_QMARK___2 {
		var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; vec__1580000104__3 = lang.Tuple_Create_O_O__IPersistentVector(nil, tmp2.Ref()) } else { var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_97; vec__1580000104__3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(f__0) }; var doc__4 any = /*line :175:1*/lang.RT_Nth_O_I_O__O(vec__1580000104__3, lang.RT_IntCast_J__I(0), nil); var dirs__5 any = lang.RT_Nth_O_I_O__O(vec__1580000104__3, lang.RT_IntCast_J__I(1), nil); var tmp4 any = jrt.Boolean_ValueOf_Z__Boolean(directive_QMARK___2).Ref(); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_98; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp4, doc__4, dirs__5, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(doc__4, dirs__5)) }






func A_arbace_g2a_print_next_target_A_New() *A_arbace_g2a_print_next_target_A { A_arbace_g2a_print_next_target_A_Init(); t := &A_arbace_g2a_print_next_target_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_g2a_print_next_target_A) Ctor() {}
//line :182:1
func (t *A_arbace_g2a_print_next_target_A) Invoke_O_O_O__O(self, decls__0, i__1 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_99; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_next_target_fn__1580000108_A_New(); var tmp4 *jrt.Class; A_arbace_g2a_print_next_target_fn__1580000108_A_Init(); tmp4 = A_arbace_g2a_print_next_target_fn__1580000108_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_105; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(decls__0, lang.Numbers_Inc_O__Number(i__1))) }
//line :185:1
func A_arbace_g2a_print_next_target_fn__1580000108_A_New() *A_arbace_g2a_print_next_target_fn__1580000108_A { A_arbace_g2a_print_next_target_fn__1580000108_A_Init(); t := &A_arbace_g2a_print_next_target_fn__1580000108_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) Ctor() {}
//line :185:1
func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) Invoke_O_O__O(self, d__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_100; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O())) { var l__1256000046__auto____2 any; var tmp4 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_102; var tmp5 *lang.Keyword = tmp4; l__1256000046__auto____2 = jrt.NN(tmp5).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(d__1)); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____2)) { temp__1927000414__auto____2 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____2)).Ref() } else { temp__1927000414__auto____2 = nil } } else { temp__1927000414__auto____2 = nil }; if jrt.A2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var tmp7 int64 = lang.RT_LongCast_O__J(t__3); var tmp8 *lang.Var
												A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_104; return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(tmp7, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(d__1), lang.RT_IntCast_J__I(3))))).Ref() } else {
//line :185:1
		return nil } }



func A_arbace_g2a_print_decl_sep_BANG__A_New() *A_arbace_g2a_print_decl_sep_BANG__A { A_arbace_g2a_print_decl_sep_BANG__A_Init(); t := &A_arbace_g2a_print_decl_sep_BANG__A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_g2a_print_decl_sep_BANG__A) Ctor() {}
//line :189:1
func (t *A_arbace_g2a_print_decl_sep_BANG__A) Invoke_O_O_O_O_O__O(self, f__0, t__1, pre__2, lines_QMARK___3 any) any { { var ff__5 any; var or__1927000174__auto____5 any; var tmp1 *lang.Var





	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_95; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_106; or__1927000174__auto____5 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(f__0, lines_QMARK___3, t__1)); if jrt.A2g_Truth(or__1927000174__auto____5) { ff__5 = or__1927000174__auto____5 } else { var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_7; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_107; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_101; ff__5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(tmp5.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(jrt.NN(tmp8).Get__O())))).Ref() }
	var tmp9 any; var or__1927000174__auto____6 any; var tmp10 *lang.Var
	A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_95; or__1927000174__auto____6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(lines_QMARK___3); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(t__1, nil)).Ref() }
//line :196:1
	if jrt.A2g_Truth(tmp9) {
		var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_108; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Var; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(tmp12.Invoke_O__O(jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Get__O()))) { } else { var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_82; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_84; tmp17.Invoke_O_O__O(tmp18, ff__5) }; var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_82; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_84; return tmp20.Invoke_O_O__O(tmp21, ff__5) } else {
//line :196:1
			var tmp22 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_45; if tmp22 != nil { var want__6 int64 = lang.Numbers_Minus_J_J__J(lang.RT_LongCast_O__J(t__1), lang.RT_LongCast_O__J(pre__2)); var tmp23 *lang.Var


				A_arbace_g2a_print_A_Init(); tmp23 = A_arbace_g2a_print_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_108; var tmp26 *lang.Keyword = tmp25; var tmp27 *lang.Var; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(tmp24.Invoke_O__O(jrt.NN(tmp26).Invoke_O__O(jrt.NN(tmp27).Get__O()))) { } else { var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_82; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_g2a_print_A_Init(); tmp30 = A_arbace_g2a_print_A_const_84; tmp29.Invoke_O_O__O(tmp30, ff__5) }
//line :196:1
			L1: for {



				var tmp31 *lang.Var; A_arbace_g2a_print_A_Init(); tmp31 = A_arbace_g2a_print_A_const_7; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp33 = A_arbace_g2a_print_A_const_102; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Var; A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_101; if lang.Numbers_Lt_O_J__Z(tmp32.Invoke_O__O(jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Get__O())), want__6) { var tmp36 *lang.Var; A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_82; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any; A_arbace_g2a_print_A_Init(); tmp38 = A_arbace_g2a_print_A_const_84; tmp37.Invoke_O_O__O(tmp38, ff__5); continue L1 } else { return nil } } } else {
//line :196:1
					return nil } } }; /*line :189:1*/panic("a2g: unreachable") }












func A_arbace_g2a_print_print_decl_BANG__A_New() *A_arbace_g2a_print_print_decl_BANG__A { A_arbace_g2a_print_print_decl_BANG__A_Init(); t := &A_arbace_g2a_print_print_decl_BANG__A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_g2a_print_print_decl_BANG__A) Ctor() {}
//line :202:1
func (t *A_arbace_g2a_print_print_decl_BANG__A) Invoke_O_O_O_O_O_O__O(self, decls__0, i__1, lines_QMARK___2, popts__3, sep_QMARK___4 any) any { var f__6 any = lang.RT_Nth_O_I__O(decls__0, lang.RT_IntCast_O__I(i__1)); var t__7 any; var tmp1 *lang.Keyword;




	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_100; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O())) { var l__1256000046__auto____7 any; var tmp4 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_102; var tmp5 *lang.Keyword = tmp4; l__1256000046__auto____7 = jrt.NN(tmp5).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__6)); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____7)) { t__7 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____7)).Ref() } else { t__7 = nil } } else { t__7 = nil }; var vec__1580000112__8 any; var tmp7 /*line :202:1*/*lang.Var;





	A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_104; vec__1580000112__8 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(f__6); var directive_QMARK___9 any = /*line :202:1*/lang.RT_Nth_O_I_O__O(vec__1580000112__8, lang.RT_IntCast_J__I(0), nil); var doc__10 any = lang.RT_Nth_O_I_O__O(vec__1580000112__8, lang.RT_IntCast_J__I(1), nil); var dirs__11 any = lang.RT_Nth_O_I_O__O(vec__1580000112__8, lang.RT_IntCast_J__I(2), nil); var pre__12 any = lang.RT_Nth_O_I_O__O(vec__1580000112__8, lang.RT_IntCast_J__I(3), nil); var tmp8 *lang.Var;






	A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_14; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_15; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_110; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_111; tmp9.Invoke_O__O(tmp11.Invoke_O_O__O(tmp13, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(decls__0, i__1))); var tmp15 any; tmp58 := /*line :202:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		if jrt.A2g_Truth(sep_QMARK___4) { var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_112; lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O_O_O__O(f__6, t__7, pre__12, lines_QMARK___2) }
		if jrt.A2g_Truth(directive_QMARK___9) {
			var tmp17 *lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_86; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_11; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_73; var tmp22 any = tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(f__6)); var tmp23 any; A_arbace_g2a_print_A_Init(); tmp23 = A_arbace_g2a_print_A_const_84; tmp15 = tmp18.Invoke_O_O__O(tmp22, tmp23) } else {

				var tmp24 *lang.Var; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_113; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any; A_arbace_g2a_print_A_Init(); tmp26 = A_arbace_g2a_print_A_const_84; tmp25.Invoke_O_O_O__O(doc__10, dirs__11, tmp26)
				var tmp27 any; var and__1927000168__auto____15 any = lines_QMARK___2; if jrt.A2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any = t__7; if jrt.A2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_114; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(t__7)).Ref(); var tmp31 *lang.Var; A_arbace_g2a_print_A_Init(); tmp31 = A_arbace_g2a_print_A_const_7; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp33 = A_arbace_g2a_print_A_const_102; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Var; A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_101; and__1927000168__auto____17 = tmp29.Invoke_O_O__O(tmp30, tmp32.Invoke_O__O(jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Get__O()))); if jrt.A2g_Truth(and__1927000168__auto____17) { var tmp36 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_115; var tmp37 lang.IFn = Up_Keyword_IFn(tmp36); var tmp38 any; var or__1927000174__auto____18 any = popts__3; if jrt.A2g_Truth(or__1927000174__auto____18) { tmp38 = or__1927000174__auto____18 } else { lang.PersistentArrayMap_Init(); tmp38 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp39 any = tmp38; var tmp40 *jrt.Boolean; jrt.Boolean_Init(); tmp40 = jrt.Boolean_TRUE; tmp27 = tmp37.Invoke_O_O__O(tmp39, tmp40.Ref()) } else { tmp27 = and__1927000168__auto____17 } } else { tmp27 = and__1927000168__auto____16 } } else { tmp27 = and__1927000168__auto____15 }; if jrt.A2g_Truth(tmp27) {
					var tmp41 int64 = lang.RT_LongCast_O__J(t__7); var tmp42 *lang.Var; A_arbace_g2a_print_A_Init(); tmp42 = A_arbace_g2a_print_A_const_7; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp44 = A_arbace_g2a_print_A_const_102; var tmp45 *lang.Keyword = tmp44; var tmp46 *lang.Var; A_arbace_g2a_print_A_Init(); tmp46 = A_arbace_g2a_print_A_const_101; if lang.Numbers_Gt_J_O__Z(tmp41, tmp43.Invoke_O__O(jrt.NN(tmp45).Invoke_O__O(jrt.NN(tmp46).Get__O()))) { L1: for {
						var tmp47 *lang.Var; A_arbace_g2a_print_A_Init(); tmp47 = A_arbace_g2a_print_A_const_7; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp49 = A_arbace_g2a_print_A_const_102; var tmp50 *lang.Keyword = tmp49; var tmp51 *lang.Var; A_arbace_g2a_print_A_Init(); tmp51 = A_arbace_g2a_print_A_const_101; if lang.Numbers_Lt_O_J__Z(tmp48.Invoke_O__O(jrt.NN(tmp50).Invoke_O__O(jrt.NN(tmp51).Get__O())), lang.RT_LongCast_O__J(t__7)) { var tmp52 *lang.Var; A_arbace_g2a_print_A_Init(); tmp52 = A_arbace_g2a_print_A_const_82; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 any; A_arbace_g2a_print_A_Init(); tmp54 = A_arbace_g2a_print_A_const_84; tmp53.Invoke_O__O(tmp54); continue L1 }
//line :216:1
						break L1 } } else { var tmp55 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp55 = A_arbace_g2a_print_A_const_45; if tmp55 != nil {

							var tmp56 *lang.Var; A_arbace_g2a_print_A_Init(); tmp56 = A_arbace_g2a_print_A_const_116; lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(t__7) } } }
				var tmp57 *lang.Var; A_arbace_g2a_print_A_Init(); tmp57 = A_arbace_g2a_print_A_const_109; tmp15 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(f__6) }
//line :202:1
		return nil }(); var tmp59 *lang.Var;






	A_arbace_g2a_print_A_Init(); tmp59 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke__O(); if /*line :202:1*/ tmp58 != nil { panic(tmp58) }; return tmp15 }






















func A_arbace_g2a_print_chunk_starts_A_New() *A_arbace_g2a_print_chunk_starts_A { A_arbace_g2a_print_chunk_starts_A_Init(); t := &A_arbace_g2a_print_chunk_starts_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_g2a_print_chunk_starts_A) Ctor() {}
//line :225:1
func (t *A_arbace_g2a_print_chunk_starts_A) Invoke_O_O__O(self, decls__0 any) any { var n__2 int32 = lang.RT_Count_O__I(decls__0); var k__3 any; var tmp1 int64 = lang.Numbers_Multiply_J_J__J(2, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var tmp2 int64 = int64(n__2); var tmp3 *lang.Var;




	A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_117; k__3 = lang.Numbers_Min_J_O__O(tmp1, lang.Numbers_Quotient_J_O__Number(tmp2, jrt.NN(tmp3).GetRawRoot__O())); if
	lang.Numbers_Gte_O_J__Z(k__3, 2) { var size__4 any = lang.Numbers_Quotient_O_O__Number(lang.Numbers_Add_J_O__Number(int64(n__2), lang.Numbers_Dec_O__Number(k__3)), k__3); var tmp4 *lang.Var

		A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_17; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_118; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_120; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_g2a_print_chunk_starts_fn__1580000117_A_New_O_I(decls__0, n__2); var tmp13 *jrt.Class; A_arbace_g2a_print_chunk_starts_fn__1580000117_A_Init(); tmp13 = A_arbace_g2a_print_chunk_starts_fn__1580000117_A_fn_class; var tmp14 any = tmp11.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)); var tmp15 *lang.Var; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_121; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_124; var tmp18 any = tmp16.Invoke_O__O(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_122; var tmp20 any = tmp9.Invoke_O_O_O__O(tmp14, tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke__O()); var tmp21 *lang.Var; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_119; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_g2a_print_A_Init(); tmp23 = A_arbace_g2a_print_A_const_84; var tmp24 any = tmp23; return tmp5.Invoke_O_O_O__O(tmp7, tmp20, tmp22.Invoke_O_O_O__O(tmp24, jrt.Integer_ValueOf_I__Integer(n__2).Ref(), size__4)) } else {
//line :231:1
			return nil } }


func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_New_O_I(p0 any, p1 int32) *A_arbace_g2a_print_chunk_starts_fn__1580000117_A { A_arbace_g2a_print_chunk_starts_fn__1580000117_A_Init(); t := &A_arbace_g2a_print_chunk_starts_fn__1580000117_A{}; t.Ctor_O_I(p0, p1); return t }
//line :234:1
func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) Ctor_O_I(c__decls any, c__n int32) { t.F_decls = c__decls; t.F_n = c__n }
//line :234:1
func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_123; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_New_O(t.F_decls); var tmp6 *jrt.Class; A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_Init(); tmp6 = A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_119; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(a__1, jrt.Integer_ValueOf_I__Integer(t.F_n).Ref()))) }
//line :234:1
func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_New_O(p0 any) *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A { A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_Init(); t := &A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :234:1
func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) Invoke_O_O__O(self, p1__1580000116_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_100; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O())) { var l__1256000046__auto____2 any; var tmp4 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_102; var tmp5 *lang.Keyword = tmp4; var tmp6 any = t.F_decls; l__1256000046__auto____2 = jrt.NN(tmp5).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(lang.RT_Nth_O_I__O(tmp6, lang.RT_IntCast_O__I(p1__1580000116_SHARP___1)))); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____2)) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____2)).Ref() } else { return nil } } else { return nil } }




func A_arbace_g2a_print_print_file_A_New() *A_arbace_g2a_print_print_file_A { A_arbace_g2a_print_print_file_A_Init(); t := &A_arbace_g2a_print_print_file_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_g2a_print_print_file_A) Ctor() {}
//line :239:1
func (t *A_arbace_g2a_print_print_file_A) Invoke_O_O_O_O__O(self, p__1580000122__0, pkg_name__1, p__1580000123__2 any) any { var map__1580000124__4 any = p__1580000122__0; var map__1580000124__5 any; if lang.ISeq_InstanceOf(map__1580000124__4) { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1580000124__4)) { var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_125; map__1580000124__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1580000124__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1580000124__4)) { var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_20; map__1580000124__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1580000124__4) } else { lang.PersistentArrayMap_Init(); map__1580000124__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1580000124__5 = map__1580000124__4 }; var opts__6 any; var tmp5 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_53; opts__6 = lang.RT_Get_O_O__O(map__1580000124__5, tmp5.Ref()); var decls__7 any; var tmp6 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_54; decls__7 = lang.RT_Get_O_O__O(map__1580000124__5, tmp6.Ref()); var file__8 any; var tmp7 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_52; file__8 = lang.RT_Get_O_O__O(map__1580000124__5, tmp7.Ref()); var src__9 any; var tmp8 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_55; src__9 = lang.RT_Get_O_O__O(map__1580000124__5, tmp8.Ref()); var map__1580000126__10 any = p__1580000123__2; var map__1580000126__11 any; if lang.ISeq_InstanceOf(map__1580000126__10) { var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(map__1580000126__10)) { var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_125; map__1580000126__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(map__1580000126__10), jrt.Object_class.ArrayClass())).Ref() } else { var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(map__1580000126__10)) { var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_20; map__1580000126__11 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(map__1580000126__10) } else { lang.PersistentArrayMap_Init(); map__1580000126__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1580000126__11 = map__1580000126__10 }; var popts__12 any = map__1580000126__11; var layout__13 any; var tmp13 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_126; layout__13 = lang.RT_Get_O_O__O(map__1580000126__11, tmp13.Ref()); var line_directives_QMARK___14 any; var tmp14 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_115; line_directives_QMARK___14 = lang.RT_Get_O_O__O(map__1580000126__11, tmp14.Ref()); var line_file__15 any; var tmp15 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_127; line_file__15 = lang.RT_Get_O_O__O(map__1580000126__11, tmp15.Ref()); var lines_QMARK___16 any; var G__1580000128__16_ any = layout__13; L1:





switch { default: switch lang.Util_Hash_O__I(G__1580000128__16_) >> 6 & 1 { case 0: var tmp16 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_128; if any(G__1580000128__16_) == any(tmp16.Ref()) { jrt.Boolean_Init(); lines_QMARK___16 = jrt.Boolean_TRUE.Ref(); break L1 }; case 1: var tmp17 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_129; if any(G__1580000128__16_) == any(tmp17.Ref()) { jrt.Boolean_Init(); lines_QMARK___16 = jrt.Boolean_FALSE.Ref(); break L1 }; default:}
	var tmp18 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_102; var tmp19 *lang.Keyword = tmp18; lines_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp19).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(file__8)))).Ref()}; var state_opts__17 any; var tmp20 /*line :239:1*/*lang.Keyword; A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_100; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_115; var tmp23 any = tmp22.Ref(); var tmp24 any; if







	lang.Util_Identical_O_O__Z(line_directives_QMARK___14, nil) { jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE.Ref() } else { tmp24 = line_directives_QMARK___14 }; state_opts__17 = /*line :239:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, lines_QMARK___16, tmp23, tmp24)); var tmp25 /*line :248:1*/*lang.Var; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_14; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_15; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_g2a_print_A_Init(); tmp29 = A_arbace_g2a_print_A_const_101; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Var; A_arbace_g2a_print_A_Init(); tmp31 = A_arbace_g2a_print_A_const_131; var tmp32 any = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(state_opts__17); var tmp33 *lang.Var; A_arbace_g2a_print_A_Init(); tmp33 = A_arbace_g2a_print_A_const_110; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Var; A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_132; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Var; A_arbace_g2a_print_A_Init(); tmp37 = A_arbace_g2a_print_A_const_133; tmp26.Invoke_O__O(tmp28.Invoke_O_O_O_O_O_O__O(tmp30, tmp32, tmp34, nil, tmp36, lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(decls__7))); var tmp38 any; tmp223 := /*line :239:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)












		{ var tmp39 any; var and__1927000168__auto____20 any = lines_QMARK___16; if jrt.A2g_Truth(and__1927000168__auto____20) { var and__1927000168__auto____21 any = line_file__15; if jrt.A2g_Truth(and__1927000168__auto____21) { tmp39 = src__9 } else { tmp39 = and__1927000168__auto____21 } } else { tmp39 = and__1927000168__auto____20 }; if jrt.A2g_Truth(tmp39) {
			var tmp40 *lang.Var; A_arbace_g2a_print_A_Init(); tmp40 = A_arbace_g2a_print_A_const_86; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_294, nil, Lit_295), jrt.RefArrayOf(jrt.Object_class, nil, src__9, nil)).Ref(); var tmp43 any; A_arbace_g2a_print_A_Init(); tmp43 = A_arbace_g2a_print_A_const_84; tmp41.Invoke_O_O__O(tmp42, tmp43)
			var tmp44 *lang.Var; A_arbace_g2a_print_A_Init(); tmp44 = A_arbace_g2a_print_A_const_134; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 any; A_arbace_g2a_print_A_Init(); tmp46 = A_arbace_g2a_print_A_const_68; tmp45.Invoke_O__O(tmp46) }
//line :239:1
			var seq_1580000129__20 any; var tmp47 *lang.Var















			A_arbace_g2a_print_A_Init(); tmp47 = A_arbace_g2a_print_A_const_19; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp49 = A_arbace_g2a_print_A_const_139; seq_1580000129__20 = tmp48.Invoke_O__O(jrt.NN(tmp49).Invoke_O__O(opts__6))
//line :239:1
			var chunk_1580000130__21 any; var count_1580000131__22 int64 = 0; var i_1580000132__23 int64 = 0; L2: for {















				if lang.Numbers_Lt_J_J__Z(i_1580000132__23, count_1580000131__22) { var b__24 any = lang.Indexed_Cast(chunk_1580000130__21).Nth_I__O(lang.RT_IntCast_J__I(i_1580000132__23)); var tmp50 *lang.Var; A_arbace_g2a_print_A_Init(); tmp50 = A_arbace_g2a_print_A_const_86; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_g2a_print_A_Init(); tmp52 = A_arbace_g2a_print_A_const_11; var tmp53 any = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(b__24); var tmp54 any; A_arbace_g2a_print_A_Init(); tmp54 = A_arbace_g2a_print_A_const_84; tmp51.Invoke_O_O__O(tmp53, tmp54); seq_1580000129__20, chunk_1580000130__21, count_1580000131__22, i_1580000132__23 = seq_1580000129__20, chunk_1580000130__21, count_1580000131__22, lang.Numbers_Unchecked_inc_J__J(i_1580000132__23); continue L2 } else { var temp__1927000414__auto____24 any; var tmp55 *lang.Var; A_arbace_g2a_print_A_Init(); tmp55 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____24 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(seq_1580000129__20); if jrt.A2g_Truth(temp__1927000414__auto____24) { var seq_1580000129__25 any = temp__1927000414__auto____24; var tmp56 *lang.Var; A_arbace_g2a_print_A_Init(); tmp56 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(seq_1580000129__25)) { var c__1927000678__auto____26 any; var tmp57 *lang.Var; A_arbace_g2a_print_A_Init(); tmp57 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____26 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(seq_1580000129__25); var tmp58 *lang.Var; A_arbace_g2a_print_A_Init(); tmp58 = A_arbace_g2a_print_A_const_36; seq_1580000129__20, chunk_1580000130__21, count_1580000131__22, i_1580000132__23 = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke_O__O(seq_1580000129__25), c__1927000678__auto____26, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var b__26 any; var tmp59 *lang.Var; A_arbace_g2a_print_A_Init(); tmp59 = A_arbace_g2a_print_A_const_20; b__26 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(seq_1580000129__25); var tmp60 *lang.Var; A_arbace_g2a_print_A_Init(); tmp60 = A_arbace_g2a_print_A_const_86; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_g2a_print_A_Init(); tmp62 = A_arbace_g2a_print_A_const_11; var tmp63 any = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(b__26); var tmp64 any; A_arbace_g2a_print_A_Init(); tmp64 = A_arbace_g2a_print_A_const_84; tmp61.Invoke_O_O__O(tmp63, tmp64); var tmp65 *lang.Var; A_arbace_g2a_print_A_Init(); tmp65 = A_arbace_g2a_print_A_const_40; seq_1580000129__20, chunk_1580000130__21, count_1580000131__22, i_1580000132__23 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(seq_1580000129__25), nil, 0, 0; continue L2 } } }
//line :239:1
				break L2
			}















			var tmp66 *lang.Var; A_arbace_g2a_print_A_Init(); tmp66 = A_arbace_g2a_print_A_const_19; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp68 = A_arbace_g2a_print_A_const_139; if jrt.A2g_Truth(tmp67.Invoke_O__O(jrt.NN(tmp68).Invoke_O__O(opts__6))) { var tmp69 *lang.Var; A_arbace_g2a_print_A_Init(); tmp69 = A_arbace_g2a_print_A_const_82; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 any; A_arbace_g2a_print_A_Init(); tmp71 = A_arbace_g2a_print_A_const_84; tmp70.Invoke_O__O(tmp71) }
//line :239:1
			var seq_1580000133__20 any; var tmp72 *lang.Var

















			A_arbace_g2a_print_A_Init(); tmp72 = A_arbace_g2a_print_A_const_19; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp74 = A_arbace_g2a_print_A_const_140; seq_1580000133__20 = tmp73.Invoke_O__O(jrt.NN(tmp74).Invoke_O__O(opts__6))
//line :239:1
			var chunk_1580000134__21 any; var count_1580000135__22 int64 = 0; var i_1580000136__23 int64 = 0; L3: for {

















				if lang.Numbers_Lt_J_J__Z(i_1580000136__23, count_1580000135__22) { var d__24 any = lang.Indexed_Cast(chunk_1580000134__21).Nth_I__O(lang.RT_IntCast_J__I(i_1580000136__23)); var tmp75 *lang.Var; A_arbace_g2a_print_A_Init(); tmp75 = A_arbace_g2a_print_A_const_86; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Var; A_arbace_g2a_print_A_Init(); tmp77 = A_arbace_g2a_print_A_const_11; var tmp78 any = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke_O__O(d__24); var tmp79 any; A_arbace_g2a_print_A_Init(); tmp79 = A_arbace_g2a_print_A_const_84; tmp76.Invoke_O_O__O(tmp78, tmp79); seq_1580000133__20, chunk_1580000134__21, count_1580000135__22, i_1580000136__23 = seq_1580000133__20, chunk_1580000134__21, count_1580000135__22, lang.Numbers_Unchecked_inc_J__J(i_1580000136__23); continue L3 } else { var temp__1927000414__auto____24_2 any; var tmp80 *lang.Var; A_arbace_g2a_print_A_Init(); tmp80 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____24_2 = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(seq_1580000133__20); if jrt.A2g_Truth(temp__1927000414__auto____24_2) { var seq_1580000133__25 any = temp__1927000414__auto____24_2; var tmp81 *lang.Var; A_arbace_g2a_print_A_Init(); tmp81 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O__O(seq_1580000133__25)) { var c__1927000678__auto____26_2 any; var tmp82 *lang.Var; A_arbace_g2a_print_A_Init(); tmp82 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____26_2 = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(seq_1580000133__25); var tmp83 *lang.Var; A_arbace_g2a_print_A_Init(); tmp83 = A_arbace_g2a_print_A_const_36; seq_1580000133__20, chunk_1580000134__21, count_1580000135__22, i_1580000136__23 = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()).Invoke_O__O(seq_1580000133__25), c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var d__26 any; var tmp84 *lang.Var; A_arbace_g2a_print_A_Init(); tmp84 = A_arbace_g2a_print_A_const_20; d__26 = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke_O__O(seq_1580000133__25); var tmp85 *lang.Var; A_arbace_g2a_print_A_Init(); tmp85 = A_arbace_g2a_print_A_const_86; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Var; A_arbace_g2a_print_A_Init(); tmp87 = A_arbace_g2a_print_A_const_11; var tmp88 any = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()).Invoke_O__O(d__26); var tmp89 any; A_arbace_g2a_print_A_Init(); tmp89 = A_arbace_g2a_print_A_const_84; tmp86.Invoke_O_O__O(tmp88, tmp89); var tmp90 *lang.Var; A_arbace_g2a_print_A_Init(); tmp90 = A_arbace_g2a_print_A_const_40; seq_1580000133__20, chunk_1580000134__21, count_1580000135__22, i_1580000136__23 = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()).Invoke_O__O(seq_1580000133__25), nil, 0, 0; continue L3 } } }
//line :239:1
				break L3
			}

















			var tmp91 *lang.Var; A_arbace_g2a_print_A_Init(); tmp91 = A_arbace_g2a_print_A_const_19; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp93 = A_arbace_g2a_print_A_const_140; if jrt.A2g_Truth(tmp92.Invoke_O__O(jrt.NN(tmp93).Invoke_O__O(opts__6))) { var tmp94 *lang.Var; A_arbace_g2a_print_A_Init(); tmp94 = A_arbace_g2a_print_A_const_82; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 any; A_arbace_g2a_print_A_Init(); tmp96 = A_arbace_g2a_print_A_const_84; tmp95.Invoke_O__O(tmp96) }
			var tmp97 *lang.Var; A_arbace_g2a_print_A_Init(); tmp97 = A_arbace_g2a_print_A_const_135; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp99 = A_arbace_g2a_print_A_const_141; var tmp100 any = jrt.NN(tmp99).Invoke_O__O(opts__6); var tmp101 any; A_arbace_g2a_print_A_Init(); tmp101 = A_arbace_g2a_print_A_const_84; tmp98.Invoke_O_O__O(tmp100, tmp101)
			var tmp102 *lang.Var; A_arbace_g2a_print_A_Init(); tmp102 = A_arbace_g2a_print_A_const_79; lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()).Invoke_O__O(Lit_52); var tmp103 *lang.Var; A_arbace_g2a_print_A_Init(); tmp103 = A_arbace_g2a_print_A_const_80; lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()).Invoke__O(); var tmp104 *lang.Var; A_arbace_g2a_print_A_Init(); tmp104 = A_arbace_g2a_print_A_const_79; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 *lang.Var; A_arbace_g2a_print_A_Init(); tmp106 = A_arbace_g2a_print_A_const_11; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 any; var or__1927000174__auto____20 any; var tmp109 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp109 = A_arbace_g2a_print_A_const_49; or__1927000174__auto____20 = jrt.NN(tmp109).Invoke_O__O(opts__6); if jrt.A2g_Truth(or__1927000174__auto____20) { tmp108 = or__1927000174__auto____20 } else { tmp108 = pkg_name__1 }; tmp105.Invoke_O__O(tmp107.Invoke_O__O(tmp108))
			var tmp110 *lang.Var; A_arbace_g2a_print_A_Init(); tmp110 = A_arbace_g2a_print_A_const_82; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 any; A_arbace_g2a_print_A_Init(); tmp112 = A_arbace_g2a_print_A_const_84; tmp111.Invoke_O__O(tmp112)
			var tmp113 *lang.Var; A_arbace_g2a_print_A_Init(); tmp113 = A_arbace_g2a_print_A_const_136; var tmp114 lang.IFn = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()); var tmp115 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp115 = A_arbace_g2a_print_A_const_142; tmp114.Invoke_O__O(jrt.NN(tmp115).Invoke_O__O(opts__6))
//line :239:1
			var decls__20 any; var tmp116 *lang.Var























			A_arbace_g2a_print_A_Init(); tmp116 = A_arbace_g2a_print_A_const_89; decls__20 = lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()).Invoke_O__O(decls__7)
//line :239:1
			var n__21 int32 = lang.RT_Count_O__I(decls__20); var starts__22 any

























			if jrt.A2g_Truth(lines_QMARK___16) { var tmp117 *lang.Var; A_arbace_g2a_print_A_Init(); tmp117 = A_arbace_g2a_print_A_const_137; starts__22 = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke_O__O(decls__20) } else { starts__22 = nil }
			var tmp118 *lang.Var; A_arbace_g2a_print_A_Init(); tmp118 = A_arbace_g2a_print_A_const_43; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()).Invoke_O__O(starts__22)) { var n__1927000701__auto____23 int64 = lang.RT_LongCast_I__J(n__21); var i__24 int64 = 0; L4: for {
				if lang.Numbers_Lt_J_J__Z(i__24, n__1927000701__auto____23) { var tmp119 *lang.Var; A_arbace_g2a_print_A_Init(); tmp119 = A_arbace_g2a_print_A_const_143; var tmp120 lang.IFn = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()); var tmp121 any = jrt.Long_ValueOf_J__Long(i__24).Ref(); var tmp122 *jrt.Boolean; jrt.Boolean_Init(); tmp122 = jrt.Boolean_TRUE; tmp120.Invoke_O_O_O_O_O__O(decls__20, tmp121, lines_QMARK___16, popts__12, tmp122.Ref()); i__24 = lang.Numbers_Unchecked_inc_J__J(i__24); continue L4 }
//line :266:1
				break L4 } } else { var chunks__23 any; var tmp123 *lang.Var

					A_arbace_g2a_print_A_Init(); tmp123 = A_arbace_g2a_print_A_const_120; var tmp124 lang.IFn = lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()); var tmp125 *lang.Var; A_arbace_g2a_print_A_Init(); tmp125 = A_arbace_g2a_print_A_const_144; var tmp126 any = jrt.NN(tmp125).GetRawRoot__O(); var tmp127 *lang.Var; A_arbace_g2a_print_A_Init(); tmp127 = A_arbace_g2a_print_A_const_8; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 *lang.Var; A_arbace_g2a_print_A_Init(); tmp129 = A_arbace_g2a_print_A_const_105; var tmp130 lang.IFn = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()); var tmp131 any; A_arbace_g2a_print_A_Init(); tmp131 = A_arbace_g2a_print_A_const_68; chunks__23 = tmp124.Invoke_O_O_O__O(tmp126, starts__22, tmp128.Invoke_O_O__O(tmp130.Invoke_O_O__O(starts__22, tmp131), jrt.Integer_ValueOf_I__Integer(n__21).Ref()))
//line :266:1
					var first_line__24 any; var tmp132 any = A_arbace_g2a_print_print_file_first_line__1580000137_A_New_O(decls__20); var tmp133 *jrt.Class



					A_arbace_g2a_print_print_file_first_line__1580000137_A_Init(); tmp133 = A_arbace_g2a_print_print_file_first_line__1580000137_A_fn_class; first_line__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp132, tmp133, nil)
//line :266:1
					var printed__25 any; var tmp134 *lang.Var





					A_arbace_g2a_print_A_Init(); tmp134 = A_arbace_g2a_print_A_const_138; var tmp135 lang.IFn = lang.IFn_Cast(jrt.NN(tmp134).GetRawRoot__O()); var tmp136 any = A_arbace_g2a_print_print_file_fn__1580000140_A_New_O_O_O_O_O(popts__12, first_line__24, lines_QMARK___16, decls__20, state_opts__17); var tmp137 *jrt.Class; A_arbace_g2a_print_print_file_fn__1580000140_A_Init(); tmp137 = A_arbace_g2a_print_print_file_fn__1580000140_A_fn_class; printed__25 = tmp135.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp136, tmp137, nil), chunks__23)
//line :266:1
					var n__1927000701__auto____26 int64; var tmp138 *lang.Var













					A_arbace_g2a_print_A_Init(); tmp138 = A_arbace_g2a_print_A_const_20; n__1927000701__auto____26 = lang.RT_LongCast_O__J(lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()).Invoke_O__O(starts__22))
//line :266:1
					var i__27 int64 = 0; L5: for {













						if lang.Numbers_Lt_J_J__Z(i__27, n__1927000701__auto____26) { var tmp139 *lang.Var; A_arbace_g2a_print_A_Init(); tmp139 = A_arbace_g2a_print_A_const_143; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 any = jrt.Long_ValueOf_J__Long(i__27).Ref(); var tmp142 *jrt.Boolean; jrt.Boolean_Init(); tmp142 = jrt.Boolean_TRUE; tmp140.Invoke_O_O_O_O_O__O(decls__20, tmp141, lines_QMARK___16, popts__12, tmp142.Ref()); i__27 = lang.Numbers_Unchecked_inc_J__J(i__27); continue L5 }
//line :266:1
						break L5 }; var seq_1580000149__26 any; var tmp143 *lang.Var















					A_arbace_g2a_print_A_Init(); tmp143 = A_arbace_g2a_print_A_const_19; var tmp144 lang.IFn = lang.IFn_Cast(jrt.NN(tmp143).GetRawRoot__O()); var tmp145 *lang.Var; A_arbace_g2a_print_A_Init(); tmp145 = A_arbace_g2a_print_A_const_120; var tmp146 lang.IFn = lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()); var tmp147 *lang.Var; A_arbace_g2a_print_A_Init(); tmp147 = A_arbace_g2a_print_A_const_144; seq_1580000149__26 = tmp144.Invoke_O__O(tmp146.Invoke_O_O_O__O(jrt.NN(tmp147).GetRawRoot__O(), chunks__23, printed__25))
//line :266:1
					var chunk_1580000150__27 any; var count_1580000151__28 int64 = 0; var i_1580000152__29 int64 = 0; L6: for {















						if lang.Numbers_Lt_J_J__Z(i_1580000152__29, count_1580000151__28) { var vec__1580000153__30 any = lang.Indexed_Cast(chunk_1580000150__27).Nth_I__O(lang.RT_IntCast_J__I(i_1580000152__29)); var vec__1580000156__31 any = lang.RT_Nth_O_I_O__O(vec__1580000153__30, lang.RT_IntCast_J__I(0), nil); var a__32 any = lang.RT_Nth_O_I_O__O(vec__1580000156__31, lang.RT_IntCast_J__I(0), nil); var b__33 any = lang.RT_Nth_O_I_O__O(vec__1580000156__31, lang.RT_IntCast_J__I(1), nil); var c__34 any = lang.RT_Nth_O_I_O__O(vec__1580000153__30, lang.RT_IntCast_J__I(1), nil); var f__35 any = lang.RT_Nth_O_I__O(decls__20, lang.RT_IntCast_O__I(a__32)); var tmp148 *lang.Var

							A_arbace_g2a_print_A_Init(); tmp148 = A_arbace_g2a_print_A_const_112; var tmp149 lang.IFn = lang.IFn_Cast(jrt.NN(tmp148).GetRawRoot__O()); var tmp150 *jrt.Long; var tmp151 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp151 = A_arbace_g2a_print_A_const_100; var tmp152 *lang.Keyword = tmp151; var tmp153 *lang.Var; A_arbace_g2a_print_A_Init(); tmp153 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(jrt.NN(tmp152).Invoke_O__O(jrt.NN(tmp153).Get__O())) { var l__1256000046__auto____36 any; var tmp154 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp154 = A_arbace_g2a_print_A_const_102; var tmp155 *lang.Keyword = tmp154; l__1256000046__auto____36 = jrt.NN(tmp155).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__35)); var tmp156 *lang.Var; A_arbace_g2a_print_A_Init(); tmp156 = A_arbace_g2a_print_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____36)) { tmp150 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____36)) } else { tmp150 = nil } } else { tmp150 = nil }; var tmp157 any = tmp150.Ref(); var tmp158 *lang.Var; A_arbace_g2a_print_A_Init(); tmp158 = A_arbace_g2a_print_A_const_104; tmp149.Invoke_O_O_O_O__O(f__35, tmp157, lang.RT_Nth_O_I__O(lang.IFn_Cast(jrt.NN(tmp158).GetRawRoot__O()).Invoke_O__O(f__35), lang.RT_IntCast_J__I(3)), lines_QMARK___16)
							var tmp159 *lang.Var; A_arbace_g2a_print_A_Init(); tmp159 = A_arbace_g2a_print_A_const_147; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()).Invoke_O_O__O(c__34, lang.IFn_Cast(first_line__24).Invoke_O__O(a__32))) { } else {
								var tmp160 *lang.Var; A_arbace_g2a_print_A_Init(); tmp160 = A_arbace_g2a_print_A_const_143; var tmp161 lang.IFn = lang.IFn_Cast(jrt.NN(tmp160).GetRawRoot__O()); var tmp162 *jrt.Boolean; jrt.Boolean_Init(); tmp162 = jrt.Boolean_FALSE; tmp161.Invoke_O_O_O_O_O__O(decls__20, a__32, lines_QMARK___16, popts__12, tmp162.Ref())
//line :285:1
								var seq_1580000159__35 any; var tmp163 *lang.Var

								A_arbace_g2a_print_A_Init(); tmp163 = A_arbace_g2a_print_A_const_19; var tmp164 lang.IFn = lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()); var tmp165 *lang.Var; A_arbace_g2a_print_A_Init(); tmp165 = A_arbace_g2a_print_A_const_119; seq_1580000159__35 = tmp164.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Inc_O__Number(a__32), b__33))
//line :285:1
								var chunk_1580000160__36 any; var count_1580000161__37 int64 = 0; var i_1580000162__38 int64 = 0; L7: for {

									if lang.Numbers_Lt_J_J__Z(i_1580000162__38, count_1580000161__37) { var i__39 any = lang.Indexed_Cast(chunk_1580000160__36).Nth_I__O(lang.RT_IntCast_J__I(i_1580000162__38)); var tmp166 *lang.Var; A_arbace_g2a_print_A_Init(); tmp166 = A_arbace_g2a_print_A_const_143; var tmp167 lang.IFn = lang.IFn_Cast(jrt.NN(tmp166).GetRawRoot__O()); var tmp168 *jrt.Boolean; jrt.Boolean_Init(); tmp168 = jrt.Boolean_TRUE; tmp167.Invoke_O_O_O_O_O__O(decls__20, i__39, lines_QMARK___16, popts__12, tmp168.Ref()); seq_1580000159__35, chunk_1580000160__36, count_1580000161__37, i_1580000162__38 = seq_1580000159__35, chunk_1580000160__36, count_1580000161__37, lang.Numbers_Unchecked_inc_J__J(i_1580000162__38); continue L7 } else { var temp__1927000414__auto____39 any; var tmp169 *lang.Var; A_arbace_g2a_print_A_Init(); tmp169 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____39 = lang.IFn_Cast(jrt.NN(tmp169).GetRawRoot__O()).Invoke_O__O(seq_1580000159__35); if jrt.A2g_Truth(temp__1927000414__auto____39) { var seq_1580000159__40 any = temp__1927000414__auto____39; var tmp170 *lang.Var; A_arbace_g2a_print_A_Init(); tmp170 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp170).GetRawRoot__O()).Invoke_O__O(seq_1580000159__40)) { var c__1927000678__auto____41 any; var tmp171 *lang.Var; A_arbace_g2a_print_A_Init(); tmp171 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____41 = lang.IFn_Cast(jrt.NN(tmp171).GetRawRoot__O()).Invoke_O__O(seq_1580000159__40); var tmp172 *lang.Var; A_arbace_g2a_print_A_Init(); tmp172 = A_arbace_g2a_print_A_const_36; seq_1580000159__35, chunk_1580000160__36, count_1580000161__37, i_1580000162__38 = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()).Invoke_O__O(seq_1580000159__40), c__1927000678__auto____41, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I(0)); continue L7 } else { var i__41 any; var tmp173 *lang.Var; A_arbace_g2a_print_A_Init(); tmp173 = A_arbace_g2a_print_A_const_20; i__41 = lang.IFn_Cast(jrt.NN(tmp173).GetRawRoot__O()).Invoke_O__O(seq_1580000159__40); var tmp174 *lang.Var; A_arbace_g2a_print_A_Init(); tmp174 = A_arbace_g2a_print_A_const_143; var tmp175 lang.IFn = lang.IFn_Cast(jrt.NN(tmp174).GetRawRoot__O()); var tmp176 *jrt.Boolean; jrt.Boolean_Init(); tmp176 = jrt.Boolean_TRUE; tmp175.Invoke_O_O_O_O_O__O(decls__20, i__41, lines_QMARK___16, popts__12, tmp176.Ref()); var tmp177 *lang.Var; A_arbace_g2a_print_A_Init(); tmp177 = A_arbace_g2a_print_A_const_40; seq_1580000159__35, chunk_1580000160__36, count_1580000161__37, i_1580000162__38 = lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()).Invoke_O__O(seq_1580000159__40), nil, 0, 0; continue L7 } } }
//line :285:1
									break L7 } }
//line :282:1
							seq_1580000149__26, chunk_1580000150__27, count_1580000151__28, i_1580000152__29 = seq_1580000149__26, chunk_1580000150__27, count_1580000151__28, lang.Numbers_Unchecked_inc_J__J(i_1580000152__29); continue L6 } else { var temp__1927000414__auto____30 any; var tmp178 *lang.Var; A_arbace_g2a_print_A_Init(); tmp178 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____30 = lang.IFn_Cast(jrt.NN(tmp178).GetRawRoot__O()).Invoke_O__O(seq_1580000149__26); if jrt.A2g_Truth(temp__1927000414__auto____30) { var seq_1580000149__31 any = temp__1927000414__auto____30; var tmp179 *lang.Var; A_arbace_g2a_print_A_Init(); tmp179 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp179).GetRawRoot__O()).Invoke_O__O(seq_1580000149__31)) { var c__1927000678__auto____32 any; var tmp180 *lang.Var; A_arbace_g2a_print_A_Init(); tmp180 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____32 = lang.IFn_Cast(jrt.NN(tmp180).GetRawRoot__O()).Invoke_O__O(seq_1580000149__31); var tmp181 *lang.Var; A_arbace_g2a_print_A_Init(); tmp181 = A_arbace_g2a_print_A_const_36; seq_1580000149__26, chunk_1580000150__27, count_1580000151__28, i_1580000152__29 = lang.IFn_Cast(jrt.NN(tmp181).GetRawRoot__O()).Invoke_O__O(seq_1580000149__31), c__1927000678__auto____32, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____32))), int64(lang.RT_IntCast_J__I(0)); continue L6 } else { var vec__1580000163__32 any; var tmp182 *lang.Var; A_arbace_g2a_print_A_Init(); tmp182 = A_arbace_g2a_print_A_const_20; vec__1580000163__32 = lang.IFn_Cast(jrt.NN(tmp182).GetRawRoot__O()).Invoke_O__O(seq_1580000149__31); var vec__1580000166__33 any = lang.RT_Nth_O_I_O__O(vec__1580000163__32, lang.RT_IntCast_J__I(0), nil); var a__34 any = lang.RT_Nth_O_I_O__O(vec__1580000166__33, lang.RT_IntCast_J__I(0), nil); var b__35 any = lang.RT_Nth_O_I_O__O(vec__1580000166__33, lang.RT_IntCast_J__I(1), nil); var c__36 any = lang.RT_Nth_O_I_O__O(vec__1580000163__32, lang.RT_IntCast_J__I(1), nil); var f__37 any = lang.RT_Nth_O_I__O(decls__20, lang.RT_IntCast_O__I(a__34)); var tmp183 *lang.Var

								A_arbace_g2a_print_A_Init(); tmp183 = A_arbace_g2a_print_A_const_112; var tmp184 lang.IFn = lang.IFn_Cast(jrt.NN(tmp183).GetRawRoot__O()); var tmp185 *jrt.Long; var tmp186 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp186 = A_arbace_g2a_print_A_const_100; var tmp187 *lang.Keyword = tmp186; var tmp188 *lang.Var; A_arbace_g2a_print_A_Init(); tmp188 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(jrt.NN(tmp187).Invoke_O__O(jrt.NN(tmp188).Get__O())) { var l__1256000046__auto____38 any; var tmp189 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp189 = A_arbace_g2a_print_A_const_102; var tmp190 *lang.Keyword = tmp189; l__1256000046__auto____38 = jrt.NN(tmp190).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__37)); var tmp191 *lang.Var; A_arbace_g2a_print_A_Init(); tmp191 = A_arbace_g2a_print_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp191).GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____38)) { tmp185 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____38)) } else { tmp185 = nil } } else { tmp185 = nil }; var tmp192 any = tmp185.Ref(); var tmp193 *lang.Var; A_arbace_g2a_print_A_Init(); tmp193 = A_arbace_g2a_print_A_const_104; tmp184.Invoke_O_O_O_O__O(f__37, tmp192, lang.RT_Nth_O_I__O(lang.IFn_Cast(jrt.NN(tmp193).GetRawRoot__O()).Invoke_O__O(f__37), lang.RT_IntCast_J__I(3)), lines_QMARK___16)
								var tmp194 *lang.Var; A_arbace_g2a_print_A_Init(); tmp194 = A_arbace_g2a_print_A_const_147; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp194).GetRawRoot__O()).Invoke_O_O__O(c__36, lang.IFn_Cast(first_line__24).Invoke_O__O(a__34))) { } else {
									var tmp195 *lang.Var; A_arbace_g2a_print_A_Init(); tmp195 = A_arbace_g2a_print_A_const_143; var tmp196 lang.IFn = lang.IFn_Cast(jrt.NN(tmp195).GetRawRoot__O()); var tmp197 *jrt.Boolean; jrt.Boolean_Init(); tmp197 = jrt.Boolean_FALSE; tmp196.Invoke_O_O_O_O_O__O(decls__20, a__34, lines_QMARK___16, popts__12, tmp197.Ref())
//line :285:1
									var seq_1580000169__37 any; var tmp198 *lang.Var

									A_arbace_g2a_print_A_Init(); tmp198 = A_arbace_g2a_print_A_const_19; var tmp199 lang.IFn = lang.IFn_Cast(jrt.NN(tmp198).GetRawRoot__O()); var tmp200 *lang.Var; A_arbace_g2a_print_A_Init(); tmp200 = A_arbace_g2a_print_A_const_119; seq_1580000169__37 = tmp199.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp200).GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Inc_O__Number(a__34), b__35))
//line :285:1
									var chunk_1580000170__38 any; var count_1580000171__39 int64 = 0; var i_1580000172__40 int64 = 0; L8: for {

										if lang.Numbers_Lt_J_J__Z(i_1580000172__40, count_1580000171__39) { var i__41_2 any = lang.Indexed_Cast(chunk_1580000170__38).Nth_I__O(lang.RT_IntCast_J__I(i_1580000172__40)); var tmp201 *lang.Var; A_arbace_g2a_print_A_Init(); tmp201 = A_arbace_g2a_print_A_const_143; var tmp202 lang.IFn = lang.IFn_Cast(jrt.NN(tmp201).GetRawRoot__O()); var tmp203 *jrt.Boolean; jrt.Boolean_Init(); tmp203 = jrt.Boolean_TRUE; tmp202.Invoke_O_O_O_O_O__O(decls__20, i__41_2, lines_QMARK___16, popts__12, tmp203.Ref()); seq_1580000169__37, chunk_1580000170__38, count_1580000171__39, i_1580000172__40 = seq_1580000169__37, chunk_1580000170__38, count_1580000171__39, lang.Numbers_Unchecked_inc_J__J(i_1580000172__40); continue L8 } else { var temp__1927000414__auto____41 any; var tmp204 *lang.Var; A_arbace_g2a_print_A_Init(); tmp204 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____41 = lang.IFn_Cast(jrt.NN(tmp204).GetRawRoot__O()).Invoke_O__O(seq_1580000169__37); if jrt.A2g_Truth(temp__1927000414__auto____41) { var seq_1580000169__42 any = temp__1927000414__auto____41; var tmp205 *lang.Var; A_arbace_g2a_print_A_Init(); tmp205 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp205).GetRawRoot__O()).Invoke_O__O(seq_1580000169__42)) { var c__1927000678__auto____43 any; var tmp206 *lang.Var; A_arbace_g2a_print_A_Init(); tmp206 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____43 = lang.IFn_Cast(jrt.NN(tmp206).GetRawRoot__O()).Invoke_O__O(seq_1580000169__42); var tmp207 *lang.Var; A_arbace_g2a_print_A_Init(); tmp207 = A_arbace_g2a_print_A_const_36; seq_1580000169__37, chunk_1580000170__38, count_1580000171__39, i_1580000172__40 = lang.IFn_Cast(jrt.NN(tmp207).GetRawRoot__O()).Invoke_O__O(seq_1580000169__42), c__1927000678__auto____43, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____43))), int64(lang.RT_IntCast_J__I(0)); continue L8 } else { var i__43 any; var tmp208 *lang.Var; A_arbace_g2a_print_A_Init(); tmp208 = A_arbace_g2a_print_A_const_20; i__43 = lang.IFn_Cast(jrt.NN(tmp208).GetRawRoot__O()).Invoke_O__O(seq_1580000169__42); var tmp209 *lang.Var; A_arbace_g2a_print_A_Init(); tmp209 = A_arbace_g2a_print_A_const_143; var tmp210 lang.IFn = lang.IFn_Cast(jrt.NN(tmp209).GetRawRoot__O()); var tmp211 *jrt.Boolean; jrt.Boolean_Init(); tmp211 = jrt.Boolean_TRUE; tmp210.Invoke_O_O_O_O_O__O(decls__20, i__43, lines_QMARK___16, popts__12, tmp211.Ref()); var tmp212 *lang.Var; A_arbace_g2a_print_A_Init(); tmp212 = A_arbace_g2a_print_A_const_40; seq_1580000169__37, chunk_1580000170__38, count_1580000171__39, i_1580000172__40 = lang.IFn_Cast(jrt.NN(tmp212).GetRawRoot__O()).Invoke_O__O(seq_1580000169__42), nil, 0, 0; continue L8 } } }
//line :285:1
										break L8 } }
//line :282:1
								var tmp213 *lang.Var; A_arbace_g2a_print_A_Init(); tmp213 = A_arbace_g2a_print_A_const_40; seq_1580000149__26, chunk_1580000150__27, count_1580000151__28, i_1580000152__29 = lang.IFn_Cast(jrt.NN(tmp213).GetRawRoot__O()).Invoke_O__O(seq_1580000149__31), nil, 0, 0; continue L6 } } }
//line :266:1
						break L6
					}
				}



















			var tmp214 *lang.Var; A_arbace_g2a_print_A_Init(); tmp214 = A_arbace_g2a_print_A_const_7; var tmp215 lang.IFn = lang.IFn_Cast(jrt.NN(tmp214).GetRawRoot__O()); var tmp216 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp216 = A_arbace_g2a_print_A_const_108; var tmp217 *lang.Keyword = tmp216; var tmp218 *lang.Var; A_arbace_g2a_print_A_Init(); tmp218 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(tmp215.Invoke_O__O(jrt.NN(tmp217).Invoke_O__O(jrt.NN(tmp218).Get__O()))) { } else { var tmp219 *lang.Var; A_arbace_g2a_print_A_Init(); tmp219 = A_arbace_g2a_print_A_const_82; var tmp220 lang.IFn = lang.IFn_Cast(jrt.NN(tmp219).GetRawRoot__O()); var tmp221 any; A_arbace_g2a_print_A_Init(); tmp221 = A_arbace_g2a_print_A_const_84; tmp220.Invoke_O__O(tmp221) }
			var tmp222 *lang.Var; A_arbace_g2a_print_A_Init(); tmp222 = A_arbace_g2a_print_A_const_130; tmp38 = lang.IFn_Cast(jrt.NN(tmp222).GetRawRoot__O()).Invoke__O() }
//line :239:1
		return nil }(); var tmp224 *lang.Var;








	A_arbace_g2a_print_A_Init(); tmp224 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp224).GetRawRoot__O()).Invoke__O(); if /*line :239:1*/ tmp223 != nil { panic(tmp223) }; return tmp38 }






























func A_arbace_g2a_print_print_file_first_line__1580000137_A_New_O(p0 any) *A_arbace_g2a_print_print_file_first_line__1580000137_A { A_arbace_g2a_print_print_file_first_line__1580000137_A_Init(); t := &A_arbace_g2a_print_print_file_first_line__1580000137_A{}; t.Ctor_O(p0); return t }
//line :270:1
func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :270:1
func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 any = t.F_decls; var f__2 any = lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(a__1)); var tmp2 *jrt.Long; var tmp3 *lang.Keyword;
													A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_100; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_101; if jrt.A2g_Truth(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O())) { var l__1256000046__auto____3 any; var tmp6 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_102; var tmp7 *lang.Keyword = tmp6; l__1256000046__auto____3 = jrt.NN(tmp7).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__2)); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____3)) { tmp2 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____3)) } else { tmp2 = nil } } else { tmp2 = nil }; var tmp9 int64 = lang.RT_LongCast_O__J(tmp2.Ref()); var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_104; return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(tmp9, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(f__2), lang.RT_IntCast_J__I(3))))).Ref() }
func A_arbace_g2a_print_print_file_fn__1580000140_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_print_print_file_fn__1580000140_A { A_arbace_g2a_print_print_file_fn__1580000140_A_Init(); t := &A_arbace_g2a_print_print_file_fn__1580000140_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :272:1
func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) Ctor_O_O_O_O_O(c__popts, c__first_line, c__lines_QMARK_, c__decls, c__state_opts any) { t.F_popts = c__popts; t.F_first_line = c__first_line; t.F_lines_QMARK_ = c__lines_QMARK_; t.F_decls = c__decls; t.F_state_opts = c__state_opts }
//line :272:1
func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) Invoke_O_O__O(self, p__1580000139__1 any) any { var vec__1580000141__2 any = p__1580000139__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1580000141__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1580000141__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var;
													A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_14; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_15; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_101; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_131; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(t.F_state_opts))); var tmp8 any; tmp38 := /*line :272:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_146; lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_first_line).Invoke_O__O(a__3))
			var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_143; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = t.F_decls; var tmp13 any = t.F_lines_QMARK_; var tmp14 any = t.F_popts; var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_FALSE; tmp11.Invoke_O_O_O_O_O__O(tmp12, a__3, tmp13, tmp14, tmp15.Ref())
//line :272:1
			var seq_1580000144__7 any; var tmp16 *lang.Var



			A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_19; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_119; seq_1580000144__7 = tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Inc_O__Number(a__3), b__4))
//line :272:1
			var chunk_1580000145__8 any; var count_1580000146__9 int64 = 0; var i_1580000147__10 int64 = 0; L1: for {



				if lang.Numbers_Lt_J_J__Z(i_1580000147__10, count_1580000146__9) { var i__11 any = lang.Indexed_Cast(chunk_1580000145__8).Nth_I__O(lang.RT_IntCast_J__I(i_1580000147__10)); var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_143; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = t.F_decls; var tmp22 any = t.F_lines_QMARK_; var tmp23 any = t.F_popts; var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; tmp20.Invoke_O_O_O_O_O__O(tmp21, i__11, tmp22, tmp23, tmp24.Ref()); seq_1580000144__7, chunk_1580000145__8, count_1580000146__9, i_1580000147__10 = seq_1580000144__7, chunk_1580000145__8, count_1580000146__9, lang.Numbers_Unchecked_inc_J__J(i_1580000147__10); continue L1 } else { var temp__1927000414__auto____11 any; var tmp25 *lang.Var; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____11 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_1580000144__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1580000144__12 any = temp__1927000414__auto____11; var tmp26 *lang.Var; A_arbace_g2a_print_A_Init(); tmp26 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_1580000144__12)) { var c__1927000678__auto____13 any; var tmp27 *lang.Var; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____13 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_1580000144__12); var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_36; seq_1580000144__7, chunk_1580000145__8, count_1580000146__9, i_1580000147__10 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_1580000144__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var i__13 any; var tmp29 *lang.Var; A_arbace_g2a_print_A_Init(); tmp29 = A_arbace_g2a_print_A_const_20; i__13 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_1580000144__12); var tmp30 *lang.Var; A_arbace_g2a_print_A_Init(); tmp30 = A_arbace_g2a_print_A_const_143; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any = t.F_decls; var tmp33 any = t.F_lines_QMARK_; var tmp34 any = t.F_popts; var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; tmp31.Invoke_O_O_O_O_O__O(tmp32, i__13, tmp33, tmp34, tmp35.Ref()); var tmp36 *lang.Var; A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_40; seq_1580000144__7, chunk_1580000145__8, count_1580000146__9, i_1580000147__10 = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(seq_1580000144__12), nil, 0, 0; continue L1 } } }
//line :272:1
				break L1
			}



			var tmp37 *lang.Var; A_arbace_g2a_print_A_Init(); tmp37 = A_arbace_g2a_print_A_const_145; tmp8 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke__O() }
//line :272:1
		return nil }(); var tmp39 *lang.Var;
	A_arbace_g2a_print_A_Init(); tmp39 = A_arbace_g2a_print_A_const_13; lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke__O(); if /*line :272:1*/ tmp38 != nil { panic(tmp38) }; return tmp8 }


















func A_arbace_g2a_print_print_forms_A_New() *A_arbace_g2a_print_print_forms_A { A_arbace_g2a_print_print_forms_A_Init(); t := &A_arbace_g2a_print_print_forms_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_g2a_print_print_forms_A) Ctor() {}
//line :291:1
func (t *A_arbace_g2a_print_print_forms_A) Invoke_O_O_O__O(self, pkg__0, opts__1 any) any {



	var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_148; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O(); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_138; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_print_forms_fn__1580000174_A_New_O_O(pkg__0, opts__1); var tmp8 *jrt.Class; A_arbace_g2a_print_print_forms_fn__1580000174_A_Init(); tmp8 = A_arbace_g2a_print_print_forms_fn__1580000174_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_51; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp9, jrt.NN(tmp10).Invoke_O__O(pkg__0))) }
func A_arbace_g2a_print_print_forms_fn__1580000174_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_print_forms_fn__1580000174_A { A_arbace_g2a_print_print_forms_fn__1580000174_A_Init(); t := &A_arbace_g2a_print_print_forms_fn__1580000174_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) Ctor_O_O(c__pkg, c__opts any) { t.F_pkg = c__pkg; t.F_opts = c__opts }
//line :296:1
func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) Invoke_O_O__O(self, fl__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_50; var tmp4 any = tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(fl__1)); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_149; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_50; return lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp6.Invoke_O_O_O__O(fl__1, jrt.NN(tmp7).Invoke_O__O(t.F_pkg), t.F_opts)) }





func A_arbace_g2a_print_sha256_A_New() *A_arbace_g2a_print_sha256_A { A_arbace_g2a_print_sha256_A_Init(); t := &A_arbace_g2a_print_sha256_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_g2a_print_sha256_A) Ctor() {}
//line :302:1
func (t *A_arbace_g2a_print_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_304); var bs__3 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path()).Ref(); var tmp1 *lang.Var;


	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_11; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_120; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_g2a_print_sha256_fn__1580000178_A_New(); var tmp8 *jrt.Class; A_arbace_g2a_print_sha256_fn__1580000178_A_Init(); tmp8 = A_arbace_g2a_print_sha256_fn__1580000178_A_fn_class; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.A2g_CastArray[*jrt.ByteArray](bs__3, jrt.Prim_byte.ArrayClass())).Ref())) }
//line :305:1
func A_arbace_g2a_print_sha256_fn__1580000178_A_New() *A_arbace_g2a_print_sha256_fn__1580000178_A { A_arbace_g2a_print_sha256_fn__1580000178_A_Init(); t := &A_arbace_g2a_print_sha256_fn__1580000178_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) Ctor() {}
//line :305:1
func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) Invoke_O_O__O(self, p1__1580000177_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_150; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(Lit_306, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__1580000177_SHARP___1, 255)).Ref()) }

func A_arbace_g2a_print_copy_file_A_New() *A_arbace_g2a_print_copy_file_A { A_arbace_g2a_print_copy_file_A_Init(); t := &A_arbace_g2a_print_copy_file_A{}; t.Ctor(); return t }
//line :307:1
func (t *A_arbace_g2a_print_copy_file_A) Ctor() {}
//line :307:1
func (t *A_arbace_g2a_print_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_151; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *jrt.Class; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_152; var tmp6 any = tmp5.Ref(); var tmp7 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp7 = jrt.StandardCopyOption_REPLACE_EXISTING; return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.A2g_CastArray[*jrt.RefArray](tmp4.Invoke_O_O__O(tmp6, lang.Tuple_Create_O__IPersistentVector(tmp7.Ref())), jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_g2a_print_json_string_A_New() *A_arbace_g2a_print_json_string_A { A_arbace_g2a_print_json_string_A_Init(); t := &A_arbace_g2a_print_json_string_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_g2a_print_json_string_A) Ctor() {}
//line :312:1
func (t *A_arbace_g2a_print_json_string_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_284, nil, Lit_284); var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_153; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_153; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_11; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O_O__O(tmp5.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(s__0), Lit_285, Lit_286), Lit_284, Lit_287), nil)).Ref()
}
func A_arbace_g2a_print_copy_files_A_New() *A_arbace_g2a_print_copy_files_A { A_arbace_g2a_print_copy_files_A_Init(); t := &A_arbace_g2a_print_copy_files_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_g2a_print_copy_files_A) Ctor() {}
//line :315:1
func (t *A_arbace_g2a_print_copy_files_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, written__3 any) any { var opts__5 any; var tmp1 *lang.Keyword;



	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_49; opts__5 = jrt.NN(tmp1).Invoke_O__O(pkg__0); var seq_1580000183__6 any; var tmp2 /*line :315:1*/*lang.Var;




	A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_19; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_155; seq_1580000183__6 = tmp3.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(opts__5)); var chunk_1580000184__7 any; var count_1580000185__8 int64 = 0; var i_1580000186__9 int64 = 0; L1:
//line :315:1
	for {




		if lang.Numbers_Lt_J_J__Z(i_1580000186__9, count_1580000185__8) { var f__10 any = lang.Indexed_Cast(chunk_1580000184__7).Nth_I__O(lang.RT_IntCast_J__I(i_1580000186__9)); var tmp5 *lang.Var
			A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_156; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *jrt.File = jrt.File_Cast(src__1); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_11; var tmp9 any = jrt.File_New_File_String(tmp7, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(f__10))); var tmp10 *jrt.File = jrt.File_Cast(out__2); var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_11; tmp6.Invoke_O_O__O(tmp9, jrt.File_New_File_String(tmp10, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(f__10))))
//line :320:1
			seq_1580000183__6, chunk_1580000184__7, count_1580000185__8, i_1580000186__9 = seq_1580000183__6, chunk_1580000184__7, count_1580000185__8, lang.Numbers_Unchecked_inc_J__J(i_1580000186__9); continue L1 } else { var temp__1927000414__auto____10 any; var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____10 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_1580000183__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_1580000183__11 any = temp__1927000414__auto____10; var tmp13 *lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_1580000183__11)) { var c__1927000678__auto____12 any; var tmp14 *lang.Var; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____12 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_1580000183__11); var tmp15 *lang.Var; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_36; seq_1580000183__6, chunk_1580000184__7, count_1580000185__8, i_1580000186__9 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_1580000183__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__12 any; var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_20; f__12 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1580000183__11)
				var tmp17 *lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_156; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.File = jrt.File_Cast(src__1); var tmp20 *lang.Var; A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_11; var tmp21 any = jrt.File_New_File_String(tmp19, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(f__12))); var tmp22 *jrt.File = jrt.File_Cast(out__2); var tmp23 *lang.Var; A_arbace_g2a_print_A_Init(); tmp23 = A_arbace_g2a_print_A_const_11; tmp18.Invoke_O_O__O(tmp21, jrt.File_New_File_String(tmp22, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(f__12))))
//line :320:1
				var tmp24 *lang.Var; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_40; seq_1580000183__6, chunk_1580000184__7, count_1580000185__8, i_1580000186__9 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_1580000183__11), nil, 0, 0; continue L1 } } }
//line :315:1
		break L1 }; var seq_1580000187__6 any; var tmp25 *lang.Var;






	A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_19; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_157; seq_1580000187__6 = tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(opts__5)); var chunk_1580000188__7 any; var count_1580000189__8 int64 = 0; var i_1580000190__9 int64 = 0; L2:
//line :315:1
	for {






		if lang.Numbers_Lt_J_J__Z(i_1580000190__9, count_1580000189__8) { var vec__1580000191__10 any = lang.Indexed_Cast(chunk_1580000188__7).Nth_I__O(lang.RT_IntCast_J__I(i_1580000190__9)); var f__11 any = lang.RT_Nth_O_I_O__O(vec__1580000191__10, lang.RT_IntCast_J__I(0), nil); var h__12 any = lang.RT_Nth_O_I_O__O(vec__1580000191__10, lang.RT_IntCast_J__I(1), nil); var from__13 any; var tmp28 *jrt.File = jrt.File_Cast(src__1); var tmp29 *lang.Var; A_arbace_g2a_print_A_Init(); tmp29 = A_arbace_g2a_print_A_const_11; from__13 = jrt.File_New_File_String(tmp28, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(f__11))); var got__14 any; var tmp30 *lang.Var

			A_arbace_g2a_print_A_Init(); tmp30 = A_arbace_g2a_print_A_const_158; got__14 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(from__13)
			var tmp31 any; var and__1927000168__auto____15 any = h__12; if jrt.A2g_Truth(and__1927000168__auto____15) { var tmp32 *lang.Var; A_arbace_g2a_print_A_Init(); tmp32 = A_arbace_g2a_print_A_const_114; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_g2a_print_A_Init(); tmp34 = A_arbace_g2a_print_A_const_11; tmp31 = tmp33.Invoke_O_O__O(got__14, lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(h__12)) } else { tmp31 = and__1927000168__auto____15 }; if jrt.A2g_Truth(tmp31) { var tmp35 *lang.Var; A_arbace_g2a_print_A_Init(); tmp35 = A_arbace_g2a_print_A_const_44; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_248, nil, Lit_249, nil, Lit_250, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__11, nil, got__14, nil, h__12)).Ref(); var tmp38 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp38 = A_arbace_g2a_print_A_const_52; panic(jrt.Thrown(jrt.Throwable_Cast(tmp36.Invoke_O_O__O(tmp37, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp38.Ref(), f__11))))))
			}
			var tmp39 *lang.Var; A_arbace_g2a_print_A_Init(); tmp39 = A_arbace_g2a_print_A_const_156; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *jrt.File = jrt.File_Cast(out__2); var tmp42 *lang.Var; A_arbace_g2a_print_A_Init(); tmp42 = A_arbace_g2a_print_A_const_11; tmp40.Invoke_O_O__O(from__13, jrt.File_New_File_String(tmp41, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(f__11))))
//line :322:1
			seq_1580000187__6, chunk_1580000188__7, count_1580000189__8, i_1580000190__9 = seq_1580000187__6, chunk_1580000188__7, count_1580000189__8, lang.Numbers_Unchecked_inc_J__J(i_1580000190__9); continue L2 } else { var temp__1927000414__auto____10_2 any; var tmp43 *lang.Var; A_arbace_g2a_print_A_Init(); tmp43 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____10_2 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(seq_1580000187__6); if jrt.A2g_Truth(temp__1927000414__auto____10_2) { var seq_1580000187__11 any = temp__1927000414__auto____10_2; var tmp44 *lang.Var; A_arbace_g2a_print_A_Init(); tmp44 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq_1580000187__11)) { var c__1927000678__auto____12_2 any; var tmp45 *lang.Var; A_arbace_g2a_print_A_Init(); tmp45 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____12_2 = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(seq_1580000187__11); var tmp46 *lang.Var; A_arbace_g2a_print_A_Init(); tmp46 = A_arbace_g2a_print_A_const_36; seq_1580000187__6, chunk_1580000188__7, count_1580000189__8, i_1580000190__9 = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(seq_1580000187__11), c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var vec__1580000194__12 any; var tmp47 *lang.Var; A_arbace_g2a_print_A_Init(); tmp47 = A_arbace_g2a_print_A_const_20; vec__1580000194__12 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(seq_1580000187__11); var f__13 any = lang.RT_Nth_O_I_O__O(vec__1580000194__12, lang.RT_IntCast_J__I(0), nil); var h__14 any = lang.RT_Nth_O_I_O__O(vec__1580000194__12, lang.RT_IntCast_J__I(1), nil); var from__15 any; var tmp48 *jrt.File = jrt.File_Cast(src__1); var tmp49 *lang.Var; A_arbace_g2a_print_A_Init(); tmp49 = A_arbace_g2a_print_A_const_11; from__15 = jrt.File_New_File_String(tmp48, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(f__13))); var got__16 any; var tmp50 *lang.Var

				A_arbace_g2a_print_A_Init(); tmp50 = A_arbace_g2a_print_A_const_158; got__16 = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(from__15)
				var tmp51 any; var and__1927000168__auto____17 any = h__14; if jrt.A2g_Truth(and__1927000168__auto____17) { var tmp52 *lang.Var; A_arbace_g2a_print_A_Init(); tmp52 = A_arbace_g2a_print_A_const_114; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_g2a_print_A_Init(); tmp54 = A_arbace_g2a_print_A_const_11; tmp51 = tmp53.Invoke_O_O__O(got__16, lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(h__14)) } else { tmp51 = and__1927000168__auto____17 }; if jrt.A2g_Truth(tmp51) { var tmp55 *lang.Var; A_arbace_g2a_print_A_Init(); tmp55 = A_arbace_g2a_print_A_const_44; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_248, nil, Lit_249, nil, Lit_250, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__13, nil, got__16, nil, h__14)).Ref(); var tmp58 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp58 = A_arbace_g2a_print_A_const_52; panic(jrt.Thrown(jrt.Throwable_Cast(tmp56.Invoke_O_O__O(tmp57, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58.Ref(), f__13))))))
				}
				var tmp59 *lang.Var; A_arbace_g2a_print_A_Init(); tmp59 = A_arbace_g2a_print_A_const_156; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *jrt.File = jrt.File_Cast(out__2); var tmp62 *lang.Var; A_arbace_g2a_print_A_Init(); tmp62 = A_arbace_g2a_print_A_const_11; tmp60.Invoke_O_O__O(from__15, jrt.File_New_File_String(tmp61, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(f__13))))
//line :322:1
				var tmp63 *lang.Var; A_arbace_g2a_print_A_Init(); tmp63 = A_arbace_g2a_print_A_const_40; seq_1580000187__6, chunk_1580000188__7, count_1580000189__8, i_1580000190__9 = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_1580000187__11), nil, 0, 0; continue L2 } } }
//line :315:1
		break L2 }; var tmp64 /*line :328:1*/*lang.Var; A_arbace_g2a_print_A_Init(); tmp64 = A_arbace_g2a_print_A_const_154; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_210); var tmp67 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_251, nil, Lit_252); var tmp68 *lang.Var; A_arbace_g2a_print_A_Init(); tmp68 = A_arbace_g2a_print_A_const_159; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 any; var iter__1927001039__auto____9 any; var tmp71 any = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_New_O_O(src__1, out__2); var tmp72 *jrt.Class;

	A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_Init(); tmp72 = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_fn_class; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil); tmp70 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(written__3); return /*line :328:1*/ tmp65.Invoke_O_O__O(tmp66, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp67, jrt.RefArrayOf(jrt.Object_class, nil, tmp69.Invoke_O_O__O(Lit_253, tmp70), nil)).Ref()) }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_Init(); t := &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A{}; t.Ctor_O_O(p0, p1); return t }
//line :330:1
func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) Ctor_O_O(c__src, c__out any) { t.F_src = c__src; t.F_out = c__out }
//line :330:1
func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) Invoke_O_O__O(self, s__1580000198__1 any) any { var tmp1 any = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_New_O_O_O_O(t.F_src, t.F_out, s__1580000198__1, self); var tmp2 *jrt.Class; A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_Init(); tmp2 = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :330:1
func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_Init(); t := &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :330:1
func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) Ctor_O_O_O_O(c__src, c__out, c__s__1580000198, c__iter__1580000197 any) { t.F_src = c__src; t.F_out = c__out; t.F_s__1580000198 = c__s__1580000198; t.F_iter__1580000197 = c__iter__1580000197 }
//line :330:1
func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) Invoke_O__O(self any) any { { var s__1580000198__1 any; var t_ any = t.F_s__1580000198; t.F_s__1580000198 = nil; s__1580000198__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1580000198__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1580000198__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1580000198__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_24; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1580000198__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1580000200__6 any; var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_25; b__1580000200__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_New_O_O_O_I_O(t.F_src, t.F_out, b__1580000200__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_Init(); tmp6 = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_33; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_35; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1580000200__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1580000197); var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_36; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1580000198__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_33; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_35; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1580000200__6), nil) } } else { var n__4 any; var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_20; n__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1580000198__3); var tmp17 *lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_34; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_256, nil, Lit_257, nil); var tmp20 *lang.Var; A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_160; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *jrt.File = jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(); var tmp23 *lang.Var; A_arbace_g2a_print_A_Init(); tmp23 = A_arbace_g2a_print_A_const_11; var tmp24 any = tmp21.Invoke_O__O(jrt.File_New_File_String(tmp22, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(n__4))).GetPath__String().Ref()); var tmp25 *lang.Var; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_160; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *jrt.File = jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(); var tmp28 *lang.Var; A_arbace_g2a_print_A_Init(); tmp28 = A_arbace_g2a_print_A_const_11; var tmp29 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp24, nil, tmp26.Invoke_O__O(jrt.File_New_File_String(tmp27, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(n__4))).GetPath__String().Ref()))).Ref(); var tmp30 lang.IFn = lang.IFn_Cast(t.F_iter__1580000197); var tmp31 *lang.Var; A_arbace_g2a_print_A_Init(); tmp31 = A_arbace_g2a_print_A_const_30; return tmp18.Invoke_O_O__O(tmp29, tmp30.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(s__1580000198__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :330:1
func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_Init(); t := &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :330:1
func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) Ctor_O_O_O_I_O(c__src, c__out, c__b__1580000200 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_src = c__src; t.F_out = c__out; t.F_b__1580000200 = c__b__1580000200; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :330:1
func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) Invoke_O__O(self any) any { { var i__1580000199__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1580000199__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1580000199__1)); var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1580000200; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_256, nil, Lit_257, nil); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_160; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *jrt.File = jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(); var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_11; var tmp10 any = tmp7.Invoke_O__O(jrt.File_New_File_String(tmp8, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(n__2))).GetPath__String().Ref()); var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_160; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *jrt.File = jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(); var tmp14 *lang.Var; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_11; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp12.Invoke_O__O(jrt.File_New_File_String(tmp13, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(n__2))).GetPath__String().Ref()))).Ref()); i__1580000199__1 = lang.Numbers_Unchecked_inc_J__J(i__1580000199__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_g2a_print_build_env_A_New() *A_arbace_g2a_print_build_env_A { A_arbace_g2a_print_build_env_A_Init(); t := &A_arbace_g2a_print_build_env_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_g2a_print_build_env_A) Ctor() {}
//line :335:1
func (t *A_arbace_g2a_print_build_env_A) Invoke_O_O_O__O(self, config__0, goroot__1 any) any { var G__1580000208__3_ any; var tmp1 *jrt.String; var tmp2 *lang.Keyword;



	A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_161; if jrt.A2g_Truth(jrt.NN(tmp2).Invoke_O__O(config__0)) { tmp1 = Lit_222 } else { tmp1 = Lit_223 }; G__1580000208__3_ = /*line :335:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_214, goroot__1, Lit_215, Lit_216, Lit_217, Lit_218, Lit_219, Lit_220, Lit_221, tmp1.Ref())); var G__1580000208__4_ any; var tmp3 *lang.Keyword;


	A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_162; if jrt.A2g_Truth(jrt.NN(tmp3).Invoke_O__O(config__0)) {

		var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_41; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_162; G__1580000208__4_ = tmp5.Invoke_O_O_O__O(G__1580000208__3_, Lit_224, jrt.NN(tmp6).Invoke_O__O(config__0)) } else {
//line :338:1
			G__1580000208__4_ = G__1580000208__3_ }; var G__1580000208__5_ any; var tmp7 /*line :335:1*/*lang.Keyword;


	A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_163; if jrt.A2g_Truth(jrt.NN(tmp7).Invoke_O__O(config__0)) {


		var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_41; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_163; G__1580000208__5_ = tmp9.Invoke_O_O_O__O(G__1580000208__4_, Lit_225, jrt.NN(tmp10).Invoke_O__O(config__0)) } else {
//line :338:1
			G__1580000208__5_ = G__1580000208__4_ }; var G__1580000208__6_ any; var tmp11 /*line :335:1*/*lang.Keyword;


	A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_164; if jrt.A2g_Truth(jrt.NN(tmp11).Invoke_O__O(config__0)) {



		var tmp12 *lang.Var; A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_41; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp14 = A_arbace_g2a_print_A_const_164; G__1580000208__6_ = tmp13.Invoke_O_O_O__O(G__1580000208__5_, Lit_226, jrt.NN(tmp14).Invoke_O__O(config__0)) } else {
//line :338:1
			G__1580000208__6_ = G__1580000208__5_ }; var G__1580000208__7_ any; var tmp15 /*line :335:1*/*lang.Keyword;


	A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_165; if jrt.A2g_Truth(jrt.NN(tmp15).Invoke_O__O(config__0)) {




		var tmp16 *lang.Var; A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_41; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_165; G__1580000208__7_ = tmp17.Invoke_O_O_O__O(G__1580000208__6_, Lit_227, jrt.NN(tmp18).Invoke_O__O(config__0)) } else {
//line :338:1
			G__1580000208__7_ = G__1580000208__6_ }; var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_166; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_167; if jrt.A2g_Truth(tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(config__0))) {





				var tmp22 *lang.Var; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_41; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_167; return tmp23.Invoke_O_O_O__O(G__1580000208__7_, Lit_228, jrt.NN(tmp24).Invoke_O__O(config__0)) } else {
//line :338:1
					return G__1580000208__7_ } }







func A_arbace_g2a_print_run_A_New() *A_arbace_g2a_print_run_A { A_arbace_g2a_print_run_A_Init(); t := &A_arbace_g2a_print_run_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_g2a_print_run_A) Ctor() {}
//line :346:1
func (t *A_arbace_g2a_print_run_A) Invoke_O_O_O_O__O(self, cmd__0, dir__1, env__2 any) any { var pb__4 any; var tmp1 *lang.Var; A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_120; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_11; pb__4 = jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), cmd__0)));

	jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__5 any = /*line :346:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Environment__Map(); var seq_1580000210__6 any; var tmp4 *lang.Var;



	A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_19; seq_1580000210__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(env__2); var chunk_1580000211__7 any; var count_1580000212__8 int64 = 0; var i_1580000213__9 int64 = 0; L1:
//line :346:1
	for {



		if lang.Numbers_Lt_J_J__Z(i_1580000213__9, count_1580000212__8) { var vec__1580000214__10 any = lang.Indexed_Cast(chunk_1580000211__7).Nth_I__O(lang.RT_IntCast_J__I(i_1580000213__9)); var k__11 any = lang.RT_Nth_O_I_O__O(vec__1580000214__10, lang.RT_IntCast_J__I(0), nil); var v__12 any = lang.RT_Nth_O_I_O__O(vec__1580000214__10, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__11, v__12); seq_1580000210__6, chunk_1580000211__7, count_1580000212__8, i_1580000213__9 = seq_1580000210__6, chunk_1580000211__7, count_1580000212__8, lang.Numbers_Unchecked_inc_J__J(i_1580000213__9); continue L1 } else { var temp__1927000414__auto____10 any; var tmp5 *lang.Var; A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____10 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq_1580000210__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_1580000210__11 any = temp__1927000414__auto____10; var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_1580000210__11)) { var c__1927000678__auto____12 any; var tmp7 *lang.Var; A_arbace_g2a_print_A_Init(); tmp7 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____12 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_1580000210__11); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_36; seq_1580000210__6, chunk_1580000211__7, count_1580000212__8, i_1580000213__9 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_1580000210__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1580000217__12 any; var tmp9 *lang.Var; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_20; vec__1580000217__12 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_1580000210__11); var k__13 any = lang.RT_Nth_O_I_O__O(vec__1580000217__12, lang.RT_IntCast_J__I(0), nil); var v__14 any = lang.RT_Nth_O_I_O__O(vec__1580000217__12, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__13, v__14); var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_40; seq_1580000210__6, chunk_1580000211__7, count_1580000212__8, i_1580000213__9 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_1580000210__11), nil, 0, 0; continue L1 } } }
//line :346:1
		break L1 }; var tmp11 /*line :351:1*/*jrt.ProcessBuilder = jrt.ProcessBuilder_Cast(pb__4); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; jrt.NN(tmp11).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(tmp12).BooleanValue__Z()); var p__5 any = /*line :346:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Start__Process(); var out__6 any; var tmp13 *lang.Var;






	A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_168; out__6 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(p__5).GetInputStream__InputStream()); return /*line :346:1*/ lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.Process_Cast(p__5).WaitFor__I()).Ref(), out__6) }









func A_arbace_g2a_print_build_A_New() *A_arbace_g2a_print_build_A { A_arbace_g2a_print_build_A_Init(); t := &A_arbace_g2a_print_build_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_g2a_print_build_A) Ctor() {}
//line :356:1
func (t *A_arbace_g2a_print_build_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, goroot__3 any) any { var config__5 any; var tmp1 *lang.Keyword;


	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_169; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_49; config__5 = jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(pkg__0)); var tags__6 any; var tmp4 /*line :356:1*/*lang.Keyword;



	A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_170; tags__6 = jrt.NN(tmp4).Invoke_O__O(config__5); var cmd__7 any; var tmp5 /*line :356:1*/*lang.Var;




	A_arbace_g2a_print_A_Init(); tmp5 = A_arbace_g2a_print_A_const_37; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_207), jrt.RefArrayOf(jrt.Object_class, goroot__3, nil)).Ref(), Lit_141, Lit_208, Lit_209, jrt.File_New_File_String(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File(), Lit_210).GetPath__String().Ref()); var tmp8 lang.IPersistentVector; var tmp9 *lang.Var;

	A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(tags__6)) { var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_159; tmp8 = lang.Tuple_Create_O_O__IPersistentVector(Lit_211, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(Lit_212, tags__6)) } else { tmp8 = nil }; var tmp11 any = tmp8; var tmp12 any; /*line :361:1*/A_arbace_g2a_print_A_Init(); tmp12 = A_arbace_g2a_print_A_const_172; cmd__7 = tmp6.Invoke_O_O_O__O(tmp7, tmp11, tmp12); var tmp13 /*line :365:1*/*lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_171; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_173; return tmp14.Invoke_O_O_O__O(cmd__7, src__1, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(config__5, goroot__3)) }

func A_arbace_g2a_print_print_package_A_New() *A_arbace_g2a_print_print_package_A { A_arbace_g2a_print_print_package_A_Init(); t := &A_arbace_g2a_print_print_package_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_g2a_print_print_package_A) Ctor() {}
//line :367:1
func (t *A_arbace_g2a_print_print_package_A) Invoke_O_O_O_O__O(self, path__0, out_dir__1, opts__2 any) any { var pkg__4 any; var tmp1 *lang.Var;


	A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_75; pkg__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(path__0); var out__5 any; var tmp2 /*line :367:1*/*lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_11; out__5 = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(out_dir__1))); var layout__6 any; var tmp3 *lang.Keyword;




	A_arbace_g2a_print_A_Init(); tmp3 = A_arbace_g2a_print_A_const_126; layout__6 = jrt.NN(tmp3).Invoke_O__O(opts__2); var files__7 any; var tmp4 /*line :367:1*/*lang.Var;





	A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_174; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_41; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_126; var tmp9 any = tmp8.Ref(); var tmp10 any; var or__1927000174__auto____7 any = layout__6; if jrt.A2g_Truth(or__1927000174__auto____7) { tmp10 = or__1927000174__auto____7 } else { var tmp11 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_176; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_177; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_49; if lang.Util_Equiv_O_O__Z(tmp12, jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(pkg__4))) { A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_128.Ref() } else { tmp10 = nil } }; files__7 = tmp5.Invoke_O_O__O(pkg__4, tmp7.Invoke_O_O_O__O(opts__2, tmp9, tmp10));
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(out__5)).Mkdirs__Z()); var seq_1580000222__8 any; var tmp16 /*line :367:1*/*lang.Var;







	A_arbace_g2a_print_A_Init(); tmp16 = A_arbace_g2a_print_A_const_19; seq_1580000222__8 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(files__7); var chunk_1580000223__9 any; var count_1580000224__10 int64 = 0; var i_1580000225__11 int64 = 0; L1:
//line :367:1
	for {







		if lang.Numbers_Lt_J_J__Z(i_1580000225__11, count_1580000224__10) { var vec__1580000226__12 any = lang.Indexed_Cast(chunk_1580000223__9).Nth_I__O(lang.RT_IntCast_J__I(i_1580000225__11)); var n__13 any = lang.RT_Nth_O_I_O__O(vec__1580000226__12, lang.RT_IntCast_J__I(0), nil); var text__14 any = lang.RT_Nth_O_I_O__O(vec__1580000226__12, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var
			A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_154; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__13)), text__14)
//line :375:1
			seq_1580000222__8, chunk_1580000223__9, count_1580000224__10, i_1580000225__11 = seq_1580000222__8, chunk_1580000223__9, count_1580000224__10, lang.Numbers_Unchecked_inc_J__J(i_1580000225__11); continue L1 } else { var temp__1927000414__auto____12 any; var tmp18 *lang.Var; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____12 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_1580000222__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_1580000222__13 any = temp__1927000414__auto____12; var tmp19 *lang.Var; A_arbace_g2a_print_A_Init(); tmp19 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_1580000222__13)) { var c__1927000678__auto____14 any; var tmp20 *lang.Var; A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____14 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_1580000222__13); var tmp21 *lang.Var; A_arbace_g2a_print_A_Init(); tmp21 = A_arbace_g2a_print_A_const_36; seq_1580000222__8, chunk_1580000223__9, count_1580000224__10, i_1580000225__11 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_1580000222__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1580000229__14 any; var tmp22 *lang.Var; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_20; vec__1580000229__14 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_1580000222__13); var n__15 any = lang.RT_Nth_O_I_O__O(vec__1580000229__14, lang.RT_IntCast_J__I(0), nil); var text__16 any = lang.RT_Nth_O_I_O__O(vec__1580000229__14, lang.RT_IntCast_J__I(1), nil); var tmp23 *lang.Var
				A_arbace_g2a_print_A_Init(); tmp23 = A_arbace_g2a_print_A_const_154; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__15)), text__16)
//line :375:1
				var tmp24 *lang.Var; A_arbace_g2a_print_A_Init(); tmp24 = A_arbace_g2a_print_A_const_40; seq_1580000222__8, chunk_1580000223__9, count_1580000224__10, i_1580000225__11 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_1580000222__13), nil, 0, 0; continue L1 } } }
//line :367:1
		break L1 }; var tmp25 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_49; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_51; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Var; A_arbace_g2a_print_A_Init(); tmp29 = A_arbace_g2a_print_A_const_175; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, pkg__4, tmp28, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(files__7))) }











func A_arbace_g2a_print_gofmt_file_A_New() *A_arbace_g2a_print_gofmt_file_A { A_arbace_g2a_print_gofmt_file_A_Init(); t := &A_arbace_g2a_print_gofmt_file_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_g2a_print_gofmt_file_A) Ctor() {}
//line :379:1
func (t *A_arbace_g2a_print_gofmt_file_A) Invoke_O_O_O__O(self, goroot__0, f__1 any) any { var vec__1580000233__3 any; var tmp1 *lang.Var;
												A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_171; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_279), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_280, jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetPath__String().Ref()); var tmp4 any = jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetParentFile__File().Ref(); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; vec__1580000233__3 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Ref()); var status__4 any = /*line :379:1*/lang.RT_Nth_O_I_O__O(vec__1580000233__3, lang.RT_IntCast_J__I(0), nil); var out__5 any = lang.RT_Nth_O_I_O__O(vec__1580000233__3, lang.RT_IntCast_J__I(1), nil); if

	lang.Numbers_IsZero_O__Z(status__4) { return nil } else { var tmp6 *lang.Var; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_44; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_281, nil, Lit_257, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1, nil, out__5)).Ref(); var tmp9 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp9 = A_arbace_g2a_print_A_const_52; panic(jrt.Thrown(jrt.Throwable_Cast(tmp7.Invoke_O_O__O(tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9.Ref(), f__1)))))) } }


func A_arbace_g2a_print__main_A_New() *A_arbace_g2a_print__main_A { A_arbace_g2a_print__main_A_Init(); t := &A_arbace_g2a_print__main_A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_g2a_print__main_A) Ctor() {}
//line :384:1
func (t *A_arbace_g2a_print__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_187).Ref()
										if jrt.A2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_188 }
//line :384:1
	var as__3 any = argv__0; var opts__4 any; lang.PersistentArrayMap_Init(); opts__4 = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var G__1580000237__5_ any; var tmp1 *lang.Var


		A_arbace_g2a_print_A_Init(); tmp1 = A_arbace_g2a_print_A_const_20; G__1580000237__5_ = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(as__3); switch lang.Util_Hash_O__I(G__1580000237__5_) >> 7 & 15 { case 1: if lang.Util_Equiv_O_O__Z(G__1580000237__5_, Lit_189) {
			var tmp2 *lang.Var; A_arbace_g2a_print_A_Init(); tmp2 = A_arbace_g2a_print_A_const_94; var tmp3 any = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(as__3); var tmp4 *lang.Var; A_arbace_g2a_print_A_Init(); tmp4 = A_arbace_g2a_print_A_const_41; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp6 = A_arbace_g2a_print_A_const_126; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_g2a_print_A_Init(); tmp8 = A_arbace_g2a_print_A_const_180; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_print_A_Init(); tmp10 = A_arbace_g2a_print_A_const_73; as__3, opts__4 = tmp3, tmp5.Invoke_O_O_O__O(opts__4, tmp7, tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(as__3))); continue L1 }
//line :387:1
		case 8: if lang.Util_Equiv_O_O__Z(G__1580000237__5_, Lit_190) {


			var tmp11 *lang.Var; A_arbace_g2a_print_A_Init(); tmp11 = A_arbace_g2a_print_A_const_94; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(as__3); var tmp13 *lang.Var; A_arbace_g2a_print_A_Init(); tmp13 = A_arbace_g2a_print_A_const_41; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp15 = A_arbace_g2a_print_A_const_55; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_g2a_print_A_Init(); tmp17 = A_arbace_g2a_print_A_const_73; as__3, opts__4 = tmp12, tmp14.Invoke_O_O_O__O(opts__4, tmp16, lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(as__3)); continue L1 }
//line :387:1
		case 9: if lang.Util_Equiv_O_O__Z(G__1580000237__5_, Lit_191) {



			var tmp18 *lang.Var; A_arbace_g2a_print_A_Init(); tmp18 = A_arbace_g2a_print_A_const_40; var tmp19 any = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(as__3); var tmp20 *lang.Var; A_arbace_g2a_print_A_Init(); tmp20 = A_arbace_g2a_print_A_const_41; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp22 = A_arbace_g2a_print_A_const_139; var tmp23 any = tmp22.Ref(); var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; as__3, opts__4 = tmp19, tmp21.Invoke_O_O_O__O(opts__4, tmp23, tmp24.Ref()); continue L1 }
//line :387:1
		case 10: if lang.Util_Equiv_O_O__Z(G__1580000237__5_, Lit_192) {




			var tmp25 *lang.Var; A_arbace_g2a_print_A_Init(); tmp25 = A_arbace_g2a_print_A_const_40; var tmp26 any = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(as__3); var tmp27 *lang.Var; A_arbace_g2a_print_A_Init(); tmp27 = A_arbace_g2a_print_A_const_41; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp29 = A_arbace_g2a_print_A_const_129; var tmp30 any = tmp29.Ref(); var tmp31 *jrt.Boolean; jrt.Boolean_Init(); tmp31 = jrt.Boolean_TRUE; as__3, opts__4 = tmp26, tmp28.Invoke_O_O_O__O(opts__4, tmp30, tmp31.Ref()); continue L1 }
//line :387:1
		case 12: if lang.Util_Equiv_O_O__Z(G__1580000237__5_, Lit_193) {





			var tmp32 *lang.Var; A_arbace_g2a_print_A_Init(); tmp32 = A_arbace_g2a_print_A_const_40; var tmp33 any = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(as__3); var tmp34 *lang.Var; A_arbace_g2a_print_A_Init(); tmp34 = A_arbace_g2a_print_A_const_41; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp36 = A_arbace_g2a_print_A_const_127; var tmp37 any = tmp36.Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; as__3, opts__4 = tmp33, tmp35.Invoke_O_O_O__O(opts__4, tmp37, tmp38.Ref()); continue L1 }
//line :387:1
		case 14: if lang.Util_Equiv_O_O__Z(G__1580000237__5_, Lit_194) {

			var tmp39 *lang.Var; A_arbace_g2a_print_A_Init(); tmp39 = A_arbace_g2a_print_A_const_40; var tmp40 any = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(as__3); var tmp41 *lang.Var; A_arbace_g2a_print_A_Init(); tmp41 = A_arbace_g2a_print_A_const_41; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp43 = A_arbace_g2a_print_A_const_115; var tmp44 any = tmp43.Ref(); var tmp45 *jrt.Boolean; jrt.Boolean_Init(); tmp45 = jrt.Boolean_FALSE; as__3, opts__4 = tmp40, tmp42.Invoke_O_O_O__O(opts__4, tmp44, tmp45.Ref()); continue L1 }
//line :387:1
		default:}; var vec__1580000238__6 any = as__3; var forms__7 any = lang.RT_Nth_O_I_O__O(vec__1580000238__6, lang.RT_IntCast_J__I(0), nil); var out__8 any = lang.RT_Nth_O_I_O__O(vec__1580000238__6, lang.RT_IntCast_J__I(1), nil); var tmp46 any
		var and__1927000168__auto____9 any = forms__7






		if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = out__8; if jrt.A2g_Truth(and__1927000168__auto____10) { tmp46 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(as__3)))).Ref() } else { tmp46 = and__1927000168__auto____10 } } else { tmp46 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp46) { } else {
			var tmp47 *lang.Var; A_arbace_g2a_print_A_Init(); tmp47 = A_arbace_g2a_print_A_const_181; lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(Lit_195)
			jrt.System_Exit_I__V(lang.RT_IntCast_J__I(2)) }
//line :387:1
		var map__1580000241__9 any; var tmp48 *lang.Var










		A_arbace_g2a_print_A_Init(); tmp48 = A_arbace_g2a_print_A_const_178; map__1580000241__9 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O_O_O__O(forms__7, out__8, opts__4)
//line :387:1
		var map__1580000241__10 any










		if lang.ISeq_InstanceOf(map__1580000241__9) { var tmp49 *lang.Var; A_arbace_g2a_print_A_Init(); tmp49 = A_arbace_g2a_print_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(map__1580000241__9)) { var tmp50 *lang.Var; A_arbace_g2a_print_A_Init(); tmp50 = A_arbace_g2a_print_A_const_125; map__1580000241__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(map__1580000241__9), jrt.Object_class.ArrayClass())).Ref() } else { var tmp51 *lang.Var; A_arbace_g2a_print_A_Init(); tmp51 = A_arbace_g2a_print_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(map__1580000241__9)) { var tmp52 *lang.Var; A_arbace_g2a_print_A_Init(); tmp52 = A_arbace_g2a_print_A_const_20; map__1580000241__10 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(map__1580000241__9) } else { lang.PersistentArrayMap_Init(); map__1580000241__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1580000241__10 = map__1580000241__9 }
//line :387:1
		var package__11 any; var tmp53 *lang.Keyword










		A_arbace_g2a_print_A_Init(); tmp53 = A_arbace_g2a_print_A_const_49; package__11 = lang.RT_Get_O_O__O(map__1580000241__10, tmp53.Ref())
//line :387:1
		var files__12 any; var tmp54 *lang.Keyword










		A_arbace_g2a_print_A_Init(); tmp54 = A_arbace_g2a_print_A_const_51; files__12 = lang.RT_Get_O_O__O(map__1580000241__10, tmp54.Ref())
//line :387:1
		var outf__13 any = jrt.File_New_String(jrt.String_Cast(out__8)); var seq_1580000243__14 any; var tmp55 *lang.Var












		A_arbace_g2a_print_A_Init(); tmp55 = A_arbace_g2a_print_A_const_19; seq_1580000243__14 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(files__12)
//line :387:1
		var chunk_1580000244__15 any; var count_1580000245__16 int64 = 0; var i_1580000246__17 int64 = 0; L3: for {












			if lang.Numbers_Lt_J_J__Z(i_1580000246__17, count_1580000245__16) { var f__18 any = lang.Indexed_Cast(chunk_1580000244__15).Nth_I__O(lang.RT_IntCast_J__I(i_1580000246__17)); var tmp56 *lang.Var; A_arbace_g2a_print_A_Init(); tmp56 = A_arbace_g2a_print_A_const_181; lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_196, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__18)).Ref()); seq_1580000243__14, chunk_1580000244__15, count_1580000245__16, i_1580000246__17 = seq_1580000243__14, chunk_1580000244__15, count_1580000245__16, lang.Numbers_Unchecked_inc_J__J(i_1580000246__17); continue L3 } else { var temp__1927000414__auto____18 any; var tmp57 *lang.Var; A_arbace_g2a_print_A_Init(); tmp57 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____18 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(seq_1580000243__14); if jrt.A2g_Truth(temp__1927000414__auto____18) { var seq_1580000243__19 any = temp__1927000414__auto____18; var tmp58 *lang.Var; A_arbace_g2a_print_A_Init(); tmp58 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke_O__O(seq_1580000243__19)) { var c__1927000678__auto____20 any; var tmp59 *lang.Var; A_arbace_g2a_print_A_Init(); tmp59 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____20 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(seq_1580000243__19); var tmp60 *lang.Var; A_arbace_g2a_print_A_Init(); tmp60 = A_arbace_g2a_print_A_const_36; seq_1580000243__14, chunk_1580000244__15, count_1580000245__16, i_1580000246__17 = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(seq_1580000243__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var f__20 any; var tmp61 *lang.Var; A_arbace_g2a_print_A_Init(); tmp61 = A_arbace_g2a_print_A_const_20; f__20 = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(seq_1580000243__19); var tmp62 *lang.Var; A_arbace_g2a_print_A_Init(); tmp62 = A_arbace_g2a_print_A_const_181; lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_196, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__20)).Ref()); var tmp63 *lang.Var; A_arbace_g2a_print_A_Init(); tmp63 = A_arbace_g2a_print_A_const_40; seq_1580000243__14, chunk_1580000244__15, count_1580000245__16, i_1580000246__17 = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_1580000243__19), nil, 0, 0; continue L3 } } }
//line :387:1
			break L3
		}












		var tmp64 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp64 = A_arbace_g2a_print_A_const_129; if jrt.A2g_Truth(jrt.NN(tmp64).Invoke_O__O(opts__4)) { var seq_1580000247__14 any; var tmp65 *lang.Var
			A_arbace_g2a_print_A_Init(); tmp65 = A_arbace_g2a_print_A_const_19; seq_1580000247__14 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(files__12)
//line :401:1
			var chunk_1580000248__15 any; var count_1580000249__16 int64 = 0; var i_1580000250__17 int64 = 0; L4: for {
				if lang.Numbers_Lt_J_J__Z(i_1580000250__17, count_1580000249__16) { var f__18_2 any = lang.Indexed_Cast(chunk_1580000248__15).Nth_I__O(lang.RT_IntCast_J__I(i_1580000250__17)); var tmp66 *lang.Var; A_arbace_g2a_print_A_Init(); tmp66 = A_arbace_g2a_print_A_const_183; lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O_O__O(goroot__2, jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__18_2))); seq_1580000247__14, chunk_1580000248__15, count_1580000249__16, i_1580000250__17 = seq_1580000247__14, chunk_1580000248__15, count_1580000249__16, lang.Numbers_Unchecked_inc_J__J(i_1580000250__17); continue L4 } else { var temp__1927000414__auto____18_2 any; var tmp67 *lang.Var; A_arbace_g2a_print_A_Init(); tmp67 = A_arbace_g2a_print_A_const_19; temp__1927000414__auto____18_2 = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(seq_1580000247__14); if jrt.A2g_Truth(temp__1927000414__auto____18_2) { var seq_1580000247__19 any = temp__1927000414__auto____18_2; var tmp68 *lang.Var; A_arbace_g2a_print_A_Init(); tmp68 = A_arbace_g2a_print_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(seq_1580000247__19)) { var c__1927000678__auto____20_2 any; var tmp69 *lang.Var; A_arbace_g2a_print_A_Init(); tmp69 = A_arbace_g2a_print_A_const_24; c__1927000678__auto____20_2 = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(seq_1580000247__19); var tmp70 *lang.Var; A_arbace_g2a_print_A_Init(); tmp70 = A_arbace_g2a_print_A_const_36; seq_1580000247__14, chunk_1580000248__15, count_1580000249__16, i_1580000250__17 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(seq_1580000247__19), c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var f__20_2 any; var tmp71 *lang.Var; A_arbace_g2a_print_A_Init(); tmp71 = A_arbace_g2a_print_A_const_20; f__20_2 = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(seq_1580000247__19); var tmp72 *lang.Var; A_arbace_g2a_print_A_Init(); tmp72 = A_arbace_g2a_print_A_const_183; lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O_O__O(goroot__2, jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__20_2))); var tmp73 *lang.Var; A_arbace_g2a_print_A_Init(); tmp73 = A_arbace_g2a_print_A_const_40; seq_1580000247__14, chunk_1580000248__15, count_1580000249__16, i_1580000250__17 = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(seq_1580000247__19), nil, 0, 0; continue L4 } } }
//line :401:1
				break L4 } }
//line :387:1
		var temp__1927000414__auto____14 any; var tmp74 *lang.Keyword















		A_arbace_g2a_print_A_Init(); tmp74 = A_arbace_g2a_print_A_const_55; temp__1927000414__auto____14 = jrt.NN(tmp74).Invoke_O__O(opts__4); if jrt.A2g_Truth(temp__1927000414__auto____14) { var src__15 any = temp__1927000414__auto____14; var tmp75 *lang.Var
			A_arbace_g2a_print_A_Init(); tmp75 = A_arbace_g2a_print_A_const_184; lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O_O_O_O__O(package__11, jrt.File_New_String(jrt.String_Cast(src__15)), outf__13, files__12)
			var tmp76 *lang.Keyword; A_arbace_g2a_print_A_Init(); tmp76 = A_arbace_g2a_print_A_const_139; if jrt.A2g_Truth(jrt.NN(tmp76).Invoke_O__O(opts__4)) { var vec__1580000251__16 any; var tmp77 *lang.Var
				A_arbace_g2a_print_A_Init(); tmp77 = A_arbace_g2a_print_A_const_182; vec__1580000251__16 = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke_O_O_O_O__O(package__11, jrt.File_New_String(jrt.String_Cast(src__15)), outf__13, goroot__2)
//line :405:1
				var status__17 any = lang.RT_Nth_O_I_O__O(vec__1580000251__16, lang.RT_IntCast_J__I(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O(vec__1580000251__16, lang.RT_IntCast_J__I(1), nil); var tmp78 *lang.Var

				A_arbace_g2a_print_A_Init(); tmp78 = A_arbace_g2a_print_A_const_185; lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()).Invoke_O__O(text__18)
				var tmp79 *lang.Var; A_arbace_g2a_print_A_Init(); tmp79 = A_arbace_g2a_print_A_const_186; lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke__O()
				if lang.Numbers_IsZero_O__Z(status__17) { } else { jrt.System_Exit_I__V(lang.RT_IntCast_J__I(1)) } } }
		var tmp80 *lang.Var; A_arbace_g2a_print_A_Init(); tmp80 = A_arbace_g2a_print_A_const_179; return lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke__O() } }; /*line :384:1*/panic("a2g: unreachable") }







type A_arbace_g2a_print_A struct{ jrt.Object }

var A_arbace_g2a_print_A_const_0 *lang.Var

var A_arbace_g2a_print_A_const_1 *lang.Var

var A_arbace_g2a_print_A_const_2 any

var A_arbace_g2a_print_A_const_3 any

var A_arbace_g2a_print_A_const_4 any

var A_arbace_g2a_print_A_const_5 any

var A_arbace_g2a_print_A_const_6 *lang.Var

var A_arbace_g2a_print_A_const_7 *lang.Var

var A_arbace_g2a_print_A_const_8 *lang.Var

var A_arbace_g2a_print_A_const_9 any

var A_arbace_g2a_print_A_const_10 *lang.Var

var A_arbace_g2a_print_A_const_11 *lang.Var

var A_arbace_g2a_print_A_const_12 *lang.Var

var A_arbace_g2a_print_A_const_13 *lang.Var

var A_arbace_g2a_print_A_const_14 *lang.Var

var A_arbace_g2a_print_A_const_15 *lang.Var

var A_arbace_g2a_print_A_const_16 *lang.Var

var A_arbace_g2a_print_A_const_17 *lang.Var

var A_arbace_g2a_print_A_const_18 any

var A_arbace_g2a_print_A_const_19 *lang.Var

var A_arbace_g2a_print_A_const_20 *lang.Var

var A_arbace_g2a_print_A_const_21 *lang.Var

var A_arbace_g2a_print_A_const_22 *lang.Keyword

var A_arbace_g2a_print_A_const_23 *lang.Var

var A_arbace_g2a_print_A_const_24 *lang.Var

var A_arbace_g2a_print_A_const_25 *lang.Var

var A_arbace_g2a_print_A_const_26 *lang.Var

var A_arbace_g2a_print_A_const_27 any

var A_arbace_g2a_print_A_const_28 *lang.Var

var A_arbace_g2a_print_A_const_29 *lang.Keyword

var A_arbace_g2a_print_A_const_30 *lang.Var

var A_arbace_g2a_print_A_const_31 *lang.Var

var A_arbace_g2a_print_A_const_32 *lang.Var

var A_arbace_g2a_print_A_const_33 *lang.Var

var A_arbace_g2a_print_A_const_34 *lang.Var

var A_arbace_g2a_print_A_const_35 *lang.Var

var A_arbace_g2a_print_A_const_36 *lang.Var

var A_arbace_g2a_print_A_const_37 *lang.Var

var A_arbace_g2a_print_A_const_38 *lang.Var

var A_arbace_g2a_print_A_const_39 *lang.Var

var A_arbace_g2a_print_A_const_40 *lang.Var

var A_arbace_g2a_print_A_const_41 *lang.Var

var A_arbace_g2a_print_A_const_42 *lang.Var

var A_arbace_g2a_print_A_const_43 *lang.Var

var A_arbace_g2a_print_A_const_44 *lang.Var

var A_arbace_g2a_print_A_const_45 *lang.Keyword

var A_arbace_g2a_print_A_const_46 *lang.Var

var A_arbace_g2a_print_A_const_47 *lang.Keyword

var A_arbace_g2a_print_A_const_48 *lang.Var

var A_arbace_g2a_print_A_const_49 *lang.Keyword

var A_arbace_g2a_print_A_const_50 *lang.Keyword

var A_arbace_g2a_print_A_const_51 *lang.Keyword

var A_arbace_g2a_print_A_const_52 *lang.Keyword

var A_arbace_g2a_print_A_const_53 *lang.Keyword

var A_arbace_g2a_print_A_const_54 *lang.Keyword

var A_arbace_g2a_print_A_const_55 *lang.Keyword

var A_arbace_g2a_print_A_const_56 *lang.Var

var A_arbace_g2a_print_A_const_57 *lang.Var

var A_arbace_g2a_print_A_const_58 *lang.Keyword

var A_arbace_g2a_print_A_const_59 *lang.Var

var A_arbace_g2a_print_A_const_60 *lang.Var

var A_arbace_g2a_print_A_const_61 *lang.Var

var A_arbace_g2a_print_A_const_62 any

var A_arbace_g2a_print_A_const_63 *lang.Var

var A_arbace_g2a_print_A_const_64 *lang.Var

var A_arbace_g2a_print_A_const_65 *lang.Var

var A_arbace_g2a_print_A_const_66 *lang.Keyword

var A_arbace_g2a_print_A_const_67 *lang.Var

var A_arbace_g2a_print_A_const_68 any

var A_arbace_g2a_print_A_const_69 any

var A_arbace_g2a_print_A_const_70 *lang.Var

var A_arbace_g2a_print_A_const_71 *lang.Var

var A_arbace_g2a_print_A_const_72 any

var A_arbace_g2a_print_A_const_73 *lang.Var

var A_arbace_g2a_print_A_const_74 *lang.Var

var A_arbace_g2a_print_A_const_75 *lang.Var

var A_arbace_g2a_print_A_const_76 *lang.Var

var A_arbace_g2a_print_A_const_77 *lang.Keyword

var A_arbace_g2a_print_A_const_78 any

var A_arbace_g2a_print_A_const_79 *lang.Var

var A_arbace_g2a_print_A_const_80 *lang.Var

var A_arbace_g2a_print_A_const_81 *lang.Var

var A_arbace_g2a_print_A_const_82 *lang.Var

var A_arbace_g2a_print_A_const_83 *lang.Var

var A_arbace_g2a_print_A_const_84 any

var A_arbace_g2a_print_A_const_85 *lang.Var

var A_arbace_g2a_print_A_const_86 *lang.Var

var A_arbace_g2a_print_A_const_87 *lang.Var

var A_arbace_g2a_print_A_const_88 *lang.Var

var A_arbace_g2a_print_A_const_89 *lang.Var

var A_arbace_g2a_print_A_const_90 any

var A_arbace_g2a_print_A_const_91 *lang.Keyword

var A_arbace_g2a_print_A_const_92 *lang.Var

var A_arbace_g2a_print_A_const_93 *lang.Keyword

var A_arbace_g2a_print_A_const_94 *lang.Var

var A_arbace_g2a_print_A_const_95 *lang.Var

var A_arbace_g2a_print_A_const_96 *lang.Keyword

var A_arbace_g2a_print_A_const_97 *lang.Var

var A_arbace_g2a_print_A_const_98 *lang.Var

var A_arbace_g2a_print_A_const_99 *lang.Var

var A_arbace_g2a_print_A_const_100 *lang.Keyword

var A_arbace_g2a_print_A_const_101 *lang.Var

var A_arbace_g2a_print_A_const_102 *lang.Keyword

var A_arbace_g2a_print_A_const_103 *lang.Var

var A_arbace_g2a_print_A_const_104 *lang.Var

var A_arbace_g2a_print_A_const_105 *lang.Var

var A_arbace_g2a_print_A_const_106 *lang.Var

var A_arbace_g2a_print_A_const_107 *lang.Keyword

var A_arbace_g2a_print_A_const_108 *lang.Keyword

var A_arbace_g2a_print_A_const_109 *lang.Var

var A_arbace_g2a_print_A_const_110 *lang.Var

var A_arbace_g2a_print_A_const_111 *lang.Var

var A_arbace_g2a_print_A_const_112 *lang.Var

var A_arbace_g2a_print_A_const_113 *lang.Var

var A_arbace_g2a_print_A_const_114 *lang.Var

var A_arbace_g2a_print_A_const_115 *lang.Keyword

var A_arbace_g2a_print_A_const_116 *lang.Var

var A_arbace_g2a_print_A_const_117 *lang.Var

var A_arbace_g2a_print_A_const_118 *lang.Var

var A_arbace_g2a_print_A_const_119 *lang.Var

var A_arbace_g2a_print_A_const_120 *lang.Var

var A_arbace_g2a_print_A_const_121 *lang.Var

var A_arbace_g2a_print_A_const_122 *lang.Var

var A_arbace_g2a_print_A_const_123 *lang.Var

var A_arbace_g2a_print_A_const_124 *lang.Var

var A_arbace_g2a_print_A_const_125 *lang.Var

var A_arbace_g2a_print_A_const_126 *lang.Keyword

var A_arbace_g2a_print_A_const_127 *lang.Keyword

var A_arbace_g2a_print_A_const_128 *lang.Keyword

var A_arbace_g2a_print_A_const_129 *lang.Keyword

var A_arbace_g2a_print_A_const_130 *lang.Var

var A_arbace_g2a_print_A_const_131 *lang.Var

var A_arbace_g2a_print_A_const_132 *lang.Var

var A_arbace_g2a_print_A_const_133 *lang.Var

var A_arbace_g2a_print_A_const_134 *lang.Var

var A_arbace_g2a_print_A_const_135 *lang.Var

var A_arbace_g2a_print_A_const_136 *lang.Var

var A_arbace_g2a_print_A_const_137 *lang.Var

var A_arbace_g2a_print_A_const_138 *lang.Var

var A_arbace_g2a_print_A_const_139 *lang.Keyword

var A_arbace_g2a_print_A_const_140 *lang.Keyword

var A_arbace_g2a_print_A_const_141 *lang.Keyword

var A_arbace_g2a_print_A_const_142 *lang.Keyword

var A_arbace_g2a_print_A_const_143 *lang.Var

var A_arbace_g2a_print_A_const_144 *lang.Var

var A_arbace_g2a_print_A_const_145 *lang.Var

var A_arbace_g2a_print_A_const_146 *lang.Var

var A_arbace_g2a_print_A_const_147 *lang.Var

var A_arbace_g2a_print_A_const_148 *lang.Var

var A_arbace_g2a_print_A_const_149 *lang.Var

var A_arbace_g2a_print_A_const_150 *lang.Var

var A_arbace_g2a_print_A_const_151 *lang.Var

var A_arbace_g2a_print_A_const_152 *jrt.Class

var A_arbace_g2a_print_A_const_153 *lang.Var

var A_arbace_g2a_print_A_const_154 *lang.Var

var A_arbace_g2a_print_A_const_155 *lang.Keyword

var A_arbace_g2a_print_A_const_156 *lang.Var

var A_arbace_g2a_print_A_const_157 *lang.Keyword

var A_arbace_g2a_print_A_const_158 *lang.Var

var A_arbace_g2a_print_A_const_159 *lang.Var

var A_arbace_g2a_print_A_const_160 *lang.Var

var A_arbace_g2a_print_A_const_161 *lang.Keyword

var A_arbace_g2a_print_A_const_162 *lang.Keyword

var A_arbace_g2a_print_A_const_163 *lang.Keyword

var A_arbace_g2a_print_A_const_164 *lang.Keyword

var A_arbace_g2a_print_A_const_165 *lang.Keyword

var A_arbace_g2a_print_A_const_166 *lang.Var

var A_arbace_g2a_print_A_const_167 *lang.Keyword

var A_arbace_g2a_print_A_const_168 *lang.Var

var A_arbace_g2a_print_A_const_169 *lang.Keyword

var A_arbace_g2a_print_A_const_170 *lang.Keyword

var A_arbace_g2a_print_A_const_171 *lang.Var

var A_arbace_g2a_print_A_const_172 any

var A_arbace_g2a_print_A_const_173 *lang.Var

var A_arbace_g2a_print_A_const_174 *lang.Var

var A_arbace_g2a_print_A_const_175 *lang.Var

var A_arbace_g2a_print_A_const_176 *lang.Keyword

var A_arbace_g2a_print_A_const_177 *lang.Keyword

var A_arbace_g2a_print_A_const_178 *lang.Var

var A_arbace_g2a_print_A_const_179 *lang.Var

var A_arbace_g2a_print_A_const_180 *lang.Var

var A_arbace_g2a_print_A_const_181 *lang.Var

var A_arbace_g2a_print_A_const_182 *lang.Var

var A_arbace_g2a_print_A_const_183 *lang.Var

var A_arbace_g2a_print_A_const_184 *lang.Var

var A_arbace_g2a_print_A_const_185 *lang.Var

var A_arbace_g2a_print_A_const_186 *lang.Var

var A_arbace_g2a_print_A_init jrt.ClassInit

func A_arbace_g2a_print_A_Init() { if !A_arbace_g2a_print_A_init.Done() { A_arbace_g2a_print_A_init.Run(A_arbace_g2a_print_A_clinit) } }

func A_arbace_g2a_print_A_clinit() { A_arbace_g2a_print_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_g2a_print_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_g2a_print_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_print_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_g2a_print_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_g2a_print_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_g2a_print_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_g2a_print_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_g2a_print_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_g2a_print_A_const_9 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_g2a_print_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_g2a_print_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_g2a_print_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_g2a_print_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_g2a_print_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_g2a_print_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_g2a_print_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_g2a_print_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_g2a_print_A_const_18 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_23, Lit_24)).Ref(); A_arbace_g2a_print_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_g2a_print_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_g2a_print_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_g2a_print_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_2); A_arbace_g2a_print_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_g2a_print_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_g2a_print_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_g2a_print_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_g2a_print_A_const_27 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref(); A_arbace_g2a_print_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_g2a_print_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_4); A_arbace_g2a_print_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_g2a_print_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_g2a_print_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_g2a_print_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_g2a_print_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_g2a_print_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_g2a_print_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_g2a_print_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_g2a_print_A_const_38 = lang.RT_Var_String_String__Var(Lit_3, Lit_41); A_arbace_g2a_print_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_g2a_print_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_g2a_print_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_g2a_print_A_const_42 = lang.RT_Var_String_String__Var(Lit_8, Lit_45); A_arbace_g2a_print_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_g2a_print_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_g2a_print_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_g2a_print_A_const_46 = lang.RT_Var_String_String__Var(Lit_3, Lit_49); A_arbace_g2a_print_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_g2a_print_A_const_48 = lang.RT_Var_String_String__Var(Lit_13, Lit_51); A_arbace_g2a_print_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_g2a_print_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_g2a_print_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_g2a_print_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_g2a_print_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_g2a_print_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_g2a_print_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_g2a_print_A_const_56 = lang.RT_Var_String_String__Var(Lit_13, Lit_58); A_arbace_g2a_print_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_g2a_print_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_g2a_print_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_g2a_print_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_g2a_print_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_g2a_print_A_const_62 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_23, Lit_24)).Ref(); A_arbace_g2a_print_A_const_63 = lang.RT_Var_String_String__Var(Lit_13, Lit_64); A_arbace_g2a_print_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_g2a_print_A_const_65 = lang.RT_Var_String_String__Var(Lit_13, Lit_66); A_arbace_g2a_print_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_g2a_print_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_g2a_print_A_const_68 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_g2a_print_A_const_69 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_g2a_print_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_g2a_print_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_g2a_print_A_const_72 = jrt.Pattern_Compile_String__Pattern(Lit_72).Ref(); A_arbace_g2a_print_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_g2a_print_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_g2a_print_A_const_75 = lang.RT_Var_String_String__Var(Lit_13, Lit_75); A_arbace_g2a_print_A_const_76 = lang.RT_Var_String_String__Var(Lit_13, Lit_76); A_arbace_g2a_print_A_const_77 = lang.RT_Keyword_String_String__Keyword(nil, Lit_77); A_arbace_g2a_print_A_const_78 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_78, Lit_79)).Ref(); A_arbace_g2a_print_A_const_79 = lang.RT_Var_String_String__Var(Lit_6, Lit_80); A_arbace_g2a_print_A_const_80 = lang.RT_Var_String_String__Var(Lit_6, Lit_81); A_arbace_g2a_print_A_const_81 = lang.RT_Var_String_String__Var(Lit_82, Lit_83); A_arbace_g2a_print_A_const_82 = lang.RT_Var_String_String__Var(Lit_6, Lit_84); A_arbace_g2a_print_A_const_83 = lang.RT_Var_String_String__Var(Lit_13, Lit_85); A_arbace_g2a_print_A_const_84 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_g2a_print_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_g2a_print_A_const_86 = lang.RT_Var_String_String__Var(Lit_6, Lit_87); A_arbace_g2a_print_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_g2a_print_A_const_88 = lang.RT_Var_String_String__Var(Lit_13, Lit_89); A_arbace_g2a_print_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_g2a_print_A_const_90 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_91, Lit_92)).Ref(); A_arbace_g2a_print_A_const_91 = lang.RT_Keyword_String_String__Keyword(Lit_24, Lit_93); A_arbace_g2a_print_A_const_92 = lang.RT_Var_String_String__Var(Lit_3, Lit_94); A_arbace_g2a_print_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_g2a_print_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_g2a_print_A_const_95 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_g2a_print_A_const_96 = lang.RT_Keyword_String_String__Keyword(nil, Lit_98); A_arbace_g2a_print_A_const_97 = lang.RT_Var_String_String__Var(Lit_3, Lit_99); A_arbace_g2a_print_A_const_98 = lang.RT_Var_String_String__Var(Lit_3, Lit_100); A_arbace_g2a_print_A_const_99 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_g2a_print_A_const_100 = lang.RT_Keyword_String_String__Keyword(nil, Lit_102); A_arbace_g2a_print_A_const_101 = lang.RT_Var_String_String__Var(Lit_6, Lit_103); A_arbace_g2a_print_A_const_102 = lang.RT_Keyword_String_String__Keyword(nil, Lit_104); A_arbace_g2a_print_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_g2a_print_A_const_104 = lang.RT_Var_String_String__Var(Lit_13, Lit_106); A_arbace_g2a_print_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_g2a_print_A_const_106 = lang.RT_Var_String_String__Var(Lit_13, Lit_108); A_arbace_g2a_print_A_const_107 = lang.RT_Keyword_String_String__Keyword(nil, Lit_109); A_arbace_g2a_print_A_const_108 = lang.RT_Keyword_String_String__Keyword(nil, Lit_110); A_arbace_g2a_print_A_const_109 = lang.RT_Var_String_String__Var(Lit_3, Lit_111); A_arbace_g2a_print_A_const_110 = lang.RT_Var_String_String__Var(Lit_6, Lit_112); A_arbace_g2a_print_A_const_111 = lang.RT_Var_String_String__Var(Lit_13, Lit_113); A_arbace_g2a_print_A_const_112 = lang.RT_Var_String_String__Var(Lit_13, Lit_114); A_arbace_g2a_print_A_const_113 = lang.RT_Var_String_String__Var(Lit_3, Lit_115); A_arbace_g2a_print_A_const_114 = lang.RT_Var_String_String__Var(Lit_0, Lit_116); A_arbace_g2a_print_A_const_115 = lang.RT_Keyword_String_String__Keyword(nil, Lit_117); A_arbace_g2a_print_A_const_116 = lang.RT_Var_String_String__Var(Lit_6, Lit_118); A_arbace_g2a_print_A_const_117 = lang.RT_Var_String_String__Var(Lit_13, Lit_119); A_arbace_g2a_print_A_const_118 = lang.RT_Var_String_String__Var(Lit_0, Lit_120); A_arbace_g2a_print_A_const_119 = lang.RT_Var_String_String__Var(Lit_0, Lit_121); A_arbace_g2a_print_A_const_120 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_g2a_print_A_const_121 = lang.RT_Var_String_String__Var(Lit_0, Lit_123); A_arbace_g2a_print_A_const_122 = lang.RT_Var_String_String__Var(Lit_0, Lit_124); A_arbace_g2a_print_A_const_123 = lang.RT_Var_String_String__Var(Lit_0, Lit_125); A_arbace_g2a_print_A_const_124 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_g2a_print_A_const_125 = lang.RT_Var_String_String__Var(Lit_0, Lit_127); A_arbace_g2a_print_A_const_126 = lang.RT_Keyword_String_String__Keyword(nil, Lit_128); A_arbace_g2a_print_A_const_127 = lang.RT_Keyword_String_String__Keyword(nil, Lit_129); A_arbace_g2a_print_A_const_128 = lang.RT_Keyword_String_String__Keyword(nil, Lit_130); A_arbace_g2a_print_A_const_129 = lang.RT_Keyword_String_String__Keyword(nil, Lit_131); A_arbace_g2a_print_A_const_130 = lang.RT_Var_String_String__Var(Lit_6, Lit_132); A_arbace_g2a_print_A_const_131 = lang.RT_Var_String_String__Var(Lit_6, Lit_133); A_arbace_g2a_print_A_const_132 = lang.RT_Var_String_String__Var(Lit_3, Lit_134); A_arbace_g2a_print_A_const_133 = lang.RT_Var_String_String__Var(Lit_3, Lit_135); A_arbace_g2a_print_A_const_134 = lang.RT_Var_String_String__Var(Lit_6, Lit_136); A_arbace_g2a_print_A_const_135 = lang.RT_Var_String_String__Var(Lit_3, Lit_137); A_arbace_g2a_print_A_const_136 = lang.RT_Var_String_String__Var(Lit_13, Lit_138); A_arbace_g2a_print_A_const_137 = lang.RT_Var_String_String__Var(Lit_13, Lit_139); A_arbace_g2a_print_A_const_138 = lang.RT_Var_String_String__Var(Lit_0, Lit_140); A_arbace_g2a_print_A_const_139 = lang.RT_Keyword_String_String__Keyword(nil, Lit_141); A_arbace_g2a_print_A_const_140 = lang.RT_Keyword_String_String__Keyword(nil, Lit_142); A_arbace_g2a_print_A_const_141 = lang.RT_Keyword_String_String__Keyword(nil, Lit_14); A_arbace_g2a_print_A_const_142 = lang.RT_Keyword_String_String__Keyword(nil, Lit_143); A_arbace_g2a_print_A_const_143 = lang.RT_Var_String_String__Var(Lit_13, Lit_144); A_arbace_g2a_print_A_const_144 = lang.RT_Var_String_String__Var(Lit_0, Lit_145); A_arbace_g2a_print_A_const_145 = lang.RT_Var_String_String__Var(Lit_6, Lit_146); A_arbace_g2a_print_A_const_146 = lang.RT_Var_String_String__Var(Lit_6, Lit_147); A_arbace_g2a_print_A_const_147 = lang.RT_Var_String_String__Var(Lit_6, Lit_148); A_arbace_g2a_print_A_const_148 = lang.RT_Var_String_String__Var(Lit_0, Lit_149); A_arbace_g2a_print_A_const_149 = lang.RT_Var_String_String__Var(Lit_13, Lit_150); A_arbace_g2a_print_A_const_150 = lang.RT_Var_String_String__Var(Lit_0, Lit_151); A_arbace_g2a_print_A_const_151 = lang.RT_Var_String_String__Var(Lit_0, Lit_152); A_arbace_g2a_print_A_const_152 = lang.RT_ClassForNameNonLoading_String__Class(Lit_153); A_arbace_g2a_print_A_const_153 = lang.RT_Var_String_String__Var(Lit_8, Lit_154); A_arbace_g2a_print_A_const_154 = lang.RT_Var_String_String__Var(Lit_0, Lit_155); A_arbace_g2a_print_A_const_155 = lang.RT_Keyword_String_String__Keyword(nil, Lit_156); A_arbace_g2a_print_A_const_156 = lang.RT_Var_String_String__Var(Lit_13, Lit_157); A_arbace_g2a_print_A_const_157 = lang.RT_Keyword_String_String__Keyword(nil, Lit_158); A_arbace_g2a_print_A_const_158 = lang.RT_Var_String_String__Var(Lit_13, Lit_159); A_arbace_g2a_print_A_const_159 = lang.RT_Var_String_String__Var(Lit_8, Lit_160); A_arbace_g2a_print_A_const_160 = lang.RT_Var_String_String__Var(Lit_13, Lit_161); A_arbace_g2a_print_A_const_161 = lang.RT_Keyword_String_String__Keyword(nil, Lit_162); A_arbace_g2a_print_A_const_162 = lang.RT_Keyword_String_String__Keyword(nil, Lit_163); A_arbace_g2a_print_A_const_163 = lang.RT_Keyword_String_String__Keyword(nil, Lit_164); A_arbace_g2a_print_A_const_164 = lang.RT_Keyword_String_String__Keyword(nil, Lit_165); A_arbace_g2a_print_A_const_165 = lang.RT_Keyword_String_String__Keyword(nil, Lit_166); A_arbace_g2a_print_A_const_166 = lang.RT_Var_String_String__Var(Lit_0, Lit_167); A_arbace_g2a_print_A_const_167 = lang.RT_Keyword_String_String__Keyword(nil, Lit_168); A_arbace_g2a_print_A_const_168 = lang.RT_Var_String_String__Var(Lit_0, Lit_169); A_arbace_g2a_print_A_const_169 = lang.RT_Keyword_String_String__Keyword(nil, Lit_170); A_arbace_g2a_print_A_const_170 = lang.RT_Keyword_String_String__Keyword(nil, Lit_171); A_arbace_g2a_print_A_const_171 = lang.RT_Var_String_String__Var(Lit_13, Lit_172); A_arbace_g2a_print_A_const_172 = lang.Tuple_Create_O__IPersistentVector(Lit_79); A_arbace_g2a_print_A_const_173 = lang.RT_Var_String_String__Var(Lit_13, Lit_173); A_arbace_g2a_print_A_const_174 = lang.RT_Var_String_String__Var(Lit_13, Lit_174); A_arbace_g2a_print_A_const_175 = lang.RT_Var_String_String__Var(Lit_0, Lit_175); A_arbace_g2a_print_A_const_176 = lang.RT_Keyword_String_String__Keyword(nil, Lit_176); A_arbace_g2a_print_A_const_177 = lang.RT_Keyword_String_String__Keyword(nil, Lit_177); A_arbace_g2a_print_A_const_178 = lang.RT_Var_String_String__Var(Lit_13, Lit_178); A_arbace_g2a_print_A_const_179 = lang.RT_Var_String_String__Var(Lit_0, Lit_179); A_arbace_g2a_print_A_const_180 = lang.RT_Var_String_String__Var(Lit_0, Lit_180); A_arbace_g2a_print_A_const_181 = lang.RT_Var_String_String__Var(Lit_0, Lit_181); A_arbace_g2a_print_A_const_182 = lang.RT_Var_String_String__Var(Lit_13, Lit_141); A_arbace_g2a_print_A_const_183 = lang.RT_Var_String_String__Var(Lit_13, Lit_182); A_arbace_g2a_print_A_const_184 = lang.RT_Var_String_String__Var(Lit_13, Lit_183); A_arbace_g2a_print_A_const_185 = lang.RT_Var_String_String__Var(Lit_0, Lit_184); A_arbace_g2a_print_A_const_186 = lang.RT_Var_String_String__Var(Lit_0, Lit_185) }

func A_arbace_g2a_print_A_New() *A_arbace_g2a_print_A { A_arbace_g2a_print_A_Init(); t := &A_arbace_g2a_print_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_A) Ctor() {}

func (t *A_arbace_g2a_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_A_class }

func (t *A_arbace_g2a_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_A); return ok }

func A_arbace_g2a_print_A_Cast(x any) *A_arbace_g2a_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_A_class)) }; return v }



type A_arbace_g2a_print__main_A struct{ jrt.Object }

func (t *A_arbace_g2a_print__main_A) Is_Compiler_AOTR0() {}

var A_arbace_g2a_print__main_A_fn_class *jrt.Class

var A_arbace_g2a_print__main_A_init jrt.ClassInit

func A_arbace_g2a_print__main_A_Init() { if !A_arbace_g2a_print__main_A_init.Done() { A_arbace_g2a_print__main_A_init.Run(A_arbace_g2a_print__main_A_clinit) } }

func A_arbace_g2a_print__main_A_clinit() { A_arbace_g2a_print__main_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_186, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_g2a_print__main_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print__main_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print__main_A_class }

func (t *A_arbace_g2a_print__main_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print__main_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print__main_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print__main_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print__main_A); return ok }

func A_arbace_g2a_print__main_A_Cast(x any) *A_arbace_g2a_print__main_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print__main_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print__main_A_class)) }; return v }



type A_arbace_g2a_print_add_form_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_add_form_A) Is_Compiler_AOTF3() {}

var A_arbace_g2a_print_add_form_A_fn_class *jrt.Class

var A_arbace_g2a_print_add_form_A_init jrt.ClassInit

func A_arbace_g2a_print_add_form_A_Init() { if !A_arbace_g2a_print_add_form_A_init.Done() { A_arbace_g2a_print_add_form_A_init.Run(A_arbace_g2a_print_add_form_A_clinit) } }

func A_arbace_g2a_print_add_form_A_clinit() { A_arbace_g2a_print_add_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_add_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_add_form_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_add_form_A_class }

func (t *A_arbace_g2a_print_add_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_add_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_add_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_add_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_add_form_A); return ok }

func A_arbace_g2a_print_add_form_A_Cast(x any) *A_arbace_g2a_print_add_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_add_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_add_form_A_class)) }; return v }



type A_arbace_g2a_print_add_form_fn__1580000040_A struct{ jrt.Object; F_f any }

func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_add_form_fn__1580000040_A_fn_class *jrt.Class

var A_arbace_g2a_print_add_form_fn__1580000040_A_init jrt.ClassInit

func A_arbace_g2a_print_add_form_fn__1580000040_A_Init() { if !A_arbace_g2a_print_add_form_fn__1580000040_A_init.Done() { A_arbace_g2a_print_add_form_fn__1580000040_A_init.Run(A_arbace_g2a_print_add_form_fn__1580000040_A_clinit) } }

func A_arbace_g2a_print_add_form_fn__1580000040_A_clinit() { A_arbace_g2a_print_add_form_fn__1580000040_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_add_form_fn__1580000040_A_class }

func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_add_form_fn__1580000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_add_form_fn__1580000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_add_form_fn__1580000040_A); return ok }

func A_arbace_g2a_print_add_form_fn__1580000040_A_Cast(x any) *A_arbace_g2a_print_add_form_fn__1580000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_add_form_fn__1580000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_add_form_fn__1580000040_A_class)) }; return v }



type A_arbace_g2a_print_build_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_build_A) Is_Compiler_AOTF4() {}

var A_arbace_g2a_print_build_A_fn_class *jrt.Class

var A_arbace_g2a_print_build_A_init jrt.ClassInit

func A_arbace_g2a_print_build_A_Init() { if !A_arbace_g2a_print_build_A_init.Done() { A_arbace_g2a_print_build_A_init.Run(A_arbace_g2a_print_build_A_clinit) } }

func A_arbace_g2a_print_build_A_clinit() { A_arbace_g2a_print_build_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_build_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_build_A_class }

func (t *A_arbace_g2a_print_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_build_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_build_A); return ok }

func A_arbace_g2a_print_build_A_Cast(x any) *A_arbace_g2a_print_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_build_A_class)) }; return v }



type A_arbace_g2a_print_build_env_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_build_env_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_build_env_A_fn_class *jrt.Class

var A_arbace_g2a_print_build_env_A_init jrt.ClassInit

func A_arbace_g2a_print_build_env_A_Init() { if !A_arbace_g2a_print_build_env_A_init.Done() { A_arbace_g2a_print_build_env_A_init.Run(A_arbace_g2a_print_build_env_A_clinit) } }

func A_arbace_g2a_print_build_env_A_clinit() { A_arbace_g2a_print_build_env_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_build_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_build_env_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_build_env_A_class }

func (t *A_arbace_g2a_print_build_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_build_env_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_build_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_build_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_build_env_A); return ok }

func A_arbace_g2a_print_build_env_A_Cast(x any) *A_arbace_g2a_print_build_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_build_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_build_env_A_class)) }; return v }



type A_arbace_g2a_print_chunk_starts_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_chunk_starts_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_chunk_starts_A_fn_class *jrt.Class

var A_arbace_g2a_print_chunk_starts_A_init jrt.ClassInit

func A_arbace_g2a_print_chunk_starts_A_Init() { if !A_arbace_g2a_print_chunk_starts_A_init.Done() { A_arbace_g2a_print_chunk_starts_A_init.Run(A_arbace_g2a_print_chunk_starts_A_clinit) } }

func A_arbace_g2a_print_chunk_starts_A_clinit() { A_arbace_g2a_print_chunk_starts_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_229, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_chunk_starts_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_chunk_starts_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_chunk_starts_A_class }

func (t *A_arbace_g2a_print_chunk_starts_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_chunk_starts_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_chunk_starts_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_chunk_starts_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_chunk_starts_A); return ok }

func A_arbace_g2a_print_chunk_starts_A_Cast(x any) *A_arbace_g2a_print_chunk_starts_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_chunk_starts_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_chunk_starts_A_class)) }; return v }



type A_arbace_g2a_print_chunk_starts_fn__1580000117_A struct{ jrt.Object; F_decls any; F_n int32 }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_chunk_starts_fn__1580000117_A_fn_class *jrt.Class

var A_arbace_g2a_print_chunk_starts_fn__1580000117_A_init jrt.ClassInit

func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_Init() { if !A_arbace_g2a_print_chunk_starts_fn__1580000117_A_init.Done() { A_arbace_g2a_print_chunk_starts_fn__1580000117_A_init.Run(A_arbace_g2a_print_chunk_starts_fn__1580000117_A_clinit) } }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_clinit() { A_arbace_g2a_print_chunk_starts_fn__1580000117_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_230, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_chunk_starts_fn__1580000117_A); return ok }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_Cast(x any) *A_arbace_g2a_print_chunk_starts_fn__1580000117_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_chunk_starts_fn__1580000117_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class)) }; return v }



type A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A struct{ jrt.Object; F_decls any }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_fn_class *jrt.Class

var A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_init jrt.ClassInit

func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_Init() { if !A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_init.Done() { A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_init.Run(A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_clinit) } }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_clinit() { A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_231, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_class }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A); return ok }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_Cast(x any) *A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_class)) }; return v }



type A_arbace_g2a_print_collect_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_collect_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_g2a_print_collect_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_A_Init() { if !A_arbace_g2a_print_collect_A_init.Done() { A_arbace_g2a_print_collect_A_init.Run(A_arbace_g2a_print_collect_A_clinit) } }

func A_arbace_g2a_print_collect_A_clinit() { A_arbace_g2a_print_collect_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_232, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_A_class }

func (t *A_arbace_g2a_print_collect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_A); return ok }

func A_arbace_g2a_print_collect_A_Cast(x any) *A_arbace_g2a_print_collect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_A struct{ jrt.Object; F_state, F_read_fn, F_root any }

func (t *A_arbace_g2a_print_collect_walk__1580000054_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_walk__1580000054_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_233, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A struct{ jrt.Object; F_read_fn, F_file any }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A struct{ jrt.Object; F_f, F_walk, F_state, F_file, F_root any }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A struct{ jrt.Object; F_walk, F_file, F_root any }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_237, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A struct{ jrt.Object; F_walk, F_state, F_file, F_f, F_root any }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class)) }; return v }



type A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A struct{ jrt.Object; F_walk, F_file, F_root any }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_Init() { if !A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_init.Done() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_init.Run(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_clinit) } }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_clinit() { A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_class }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A); return ok }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_Cast(x any) *A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_class)) }; return v }



type A_arbace_g2a_print_collect_forms_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_collect_forms_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_forms_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_forms_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_forms_A_Init() { if !A_arbace_g2a_print_collect_forms_A_init.Done() { A_arbace_g2a_print_collect_forms_A_init.Run(A_arbace_g2a_print_collect_forms_A_clinit) } }

func A_arbace_g2a_print_collect_forms_A_clinit() { A_arbace_g2a_print_collect_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_forms_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_forms_A_class }

func (t *A_arbace_g2a_print_collect_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_forms_A); return ok }

func A_arbace_g2a_print_collect_forms_A_Cast(x any) *A_arbace_g2a_print_collect_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_forms_A_class)) }; return v }



type A_arbace_g2a_print_collect_forms_fn__1580000048_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_forms_fn__1580000048_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_forms_fn__1580000048_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_forms_fn__1580000048_A_Init() { if !A_arbace_g2a_print_collect_forms_fn__1580000048_A_init.Done() { A_arbace_g2a_print_collect_forms_fn__1580000048_A_init.Run(A_arbace_g2a_print_collect_forms_fn__1580000048_A_clinit) } }

func A_arbace_g2a_print_collect_forms_fn__1580000048_A_clinit() { A_arbace_g2a_print_collect_forms_fn__1580000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_243, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_forms_fn__1580000048_A_class }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_forms_fn__1580000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_forms_fn__1580000048_A); return ok }

func A_arbace_g2a_print_collect_forms_fn__1580000048_A_Cast(x any) *A_arbace_g2a_print_collect_forms_fn__1580000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_forms_fn__1580000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_forms_fn__1580000048_A_class)) }; return v }



type A_arbace_g2a_print_collect_forms_fn__1580000050_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_collect_forms_fn__1580000050_A_fn_class *jrt.Class

var A_arbace_g2a_print_collect_forms_fn__1580000050_A_init jrt.ClassInit

func A_arbace_g2a_print_collect_forms_fn__1580000050_A_Init() { if !A_arbace_g2a_print_collect_forms_fn__1580000050_A_init.Done() { A_arbace_g2a_print_collect_forms_fn__1580000050_A_init.Run(A_arbace_g2a_print_collect_forms_fn__1580000050_A_clinit) } }

func A_arbace_g2a_print_collect_forms_fn__1580000050_A_clinit() { A_arbace_g2a_print_collect_forms_fn__1580000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_collect_forms_fn__1580000050_A_class }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_collect_forms_fn__1580000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_collect_forms_fn__1580000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_collect_forms_fn__1580000050_A); return ok }

func A_arbace_g2a_print_collect_forms_fn__1580000050_A_Cast(x any) *A_arbace_g2a_print_collect_forms_fn__1580000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_collect_forms_fn__1580000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_collect_forms_fn__1580000050_A_class)) }; return v }



type A_arbace_g2a_print_copy_file_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_copy_file_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_copy_file_A_fn_class *jrt.Class

var A_arbace_g2a_print_copy_file_A_init jrt.ClassInit

func A_arbace_g2a_print_copy_file_A_Init() { if !A_arbace_g2a_print_copy_file_A_init.Done() { A_arbace_g2a_print_copy_file_A_init.Run(A_arbace_g2a_print_copy_file_A_clinit) } }

func A_arbace_g2a_print_copy_file_A_clinit() { A_arbace_g2a_print_copy_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_246, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_copy_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_copy_file_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_copy_file_A_class }

func (t *A_arbace_g2a_print_copy_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_copy_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_copy_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_copy_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_copy_file_A); return ok }

func A_arbace_g2a_print_copy_file_A_Cast(x any) *A_arbace_g2a_print_copy_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_copy_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_copy_file_A_class)) }; return v }



type A_arbace_g2a_print_copy_files_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_copy_files_A) Is_Compiler_AOTF4() {}

var A_arbace_g2a_print_copy_files_A_fn_class *jrt.Class

var A_arbace_g2a_print_copy_files_A_init jrt.ClassInit

func A_arbace_g2a_print_copy_files_A_Init() { if !A_arbace_g2a_print_copy_files_A_init.Done() { A_arbace_g2a_print_copy_files_A_init.Run(A_arbace_g2a_print_copy_files_A_clinit) } }

func A_arbace_g2a_print_copy_files_A_clinit() { A_arbace_g2a_print_copy_files_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_247, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_copy_files_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_copy_files_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_copy_files_A_class }

func (t *A_arbace_g2a_print_copy_files_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_copy_files_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_copy_files_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_copy_files_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_copy_files_A); return ok }

func A_arbace_g2a_print_copy_files_A_Cast(x any) *A_arbace_g2a_print_copy_files_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_copy_files_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_copy_files_A_class)) }; return v }



type A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A struct{ jrt.Object; F_src, F_out any }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_fn_class *jrt.Class

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_init jrt.ClassInit

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_Init() { if !A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_init.Done() { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_init.Run(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_clinit) } }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_clinit() { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_254, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A); return ok }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_Cast(x any) *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class)) }; return v }



type A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A struct{ jrt.Object; F_src, F_out, F_s__1580000198, F_iter__1580000197 any }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_fn_class *jrt.Class

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_init jrt.ClassInit

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_Init() { if !A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_init.Done() { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_init.Run(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_clinit) } }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_clinit() { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A); return ok }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_Cast(x any) *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class)) }; return v }



type A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A struct{ jrt.Object; F_src, F_out, F_b__1580000200 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_fn_class *jrt.Class

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_init jrt.ClassInit

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_Init() { if !A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_init.Done() { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_init.Run(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_clinit) } }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_clinit() { A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_258, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_class }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A); return ok }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_Cast(x any) *A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_class)) }; return v }



type A_arbace_g2a_print_decl_pre_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_decl_pre_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_decl_pre_A_fn_class *jrt.Class

var A_arbace_g2a_print_decl_pre_A_init jrt.ClassInit

func A_arbace_g2a_print_decl_pre_A_Init() { if !A_arbace_g2a_print_decl_pre_A_init.Done() { A_arbace_g2a_print_decl_pre_A_init.Run(A_arbace_g2a_print_decl_pre_A_clinit) } }

func A_arbace_g2a_print_decl_pre_A_clinit() { A_arbace_g2a_print_decl_pre_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_decl_pre_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_decl_pre_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_decl_pre_A_class }

func (t *A_arbace_g2a_print_decl_pre_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_decl_pre_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_decl_pre_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_decl_pre_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_decl_pre_A); return ok }

func A_arbace_g2a_print_decl_pre_A_Cast(x any) *A_arbace_g2a_print_decl_pre_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_decl_pre_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_decl_pre_A_class)) }; return v }



type A_arbace_g2a_print_decl_sep_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_decl_sep_BANG__A) Is_Compiler_AOTF4() {}

var A_arbace_g2a_print_decl_sep_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_decl_sep_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_decl_sep_BANG__A_Init() { if !A_arbace_g2a_print_decl_sep_BANG__A_init.Done() { A_arbace_g2a_print_decl_sep_BANG__A_init.Run(A_arbace_g2a_print_decl_sep_BANG__A_clinit) } }

func A_arbace_g2a_print_decl_sep_BANG__A_clinit() { A_arbace_g2a_print_decl_sep_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_decl_sep_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_decl_sep_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_decl_sep_BANG__A_class }

func (t *A_arbace_g2a_print_decl_sep_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_decl_sep_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_decl_sep_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_decl_sep_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_decl_sep_BANG__A); return ok }

func A_arbace_g2a_print_decl_sep_BANG__A_Cast(x any) *A_arbace_g2a_print_decl_sep_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_decl_sep_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_decl_sep_BANG__A_class)) }; return v }



type A_arbace_g2a_print_eval1580000004_A struct{ jrt.Object }

func A_arbace_g2a_print_eval1580000004_A_New() *A_arbace_g2a_print_eval1580000004_A { t := &A_arbace_g2a_print_eval1580000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_eval1580000004_A) Ctor() {}

func (t *A_arbace_g2a_print_eval1580000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_eval1580000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_eval1580000004_A_class }

func (t *A_arbace_g2a_print_eval1580000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_eval1580000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_eval1580000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_eval1580000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_eval1580000004_A); return ok }

func A_arbace_g2a_print_eval1580000004_A_Cast(x any) *A_arbace_g2a_print_eval1580000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_eval1580000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_eval1580000004_A_class)) }; return v }



type A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_fn_class *jrt.Class

var A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_init jrt.ClassInit

func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_Init() { if !A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_init.Done() { A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_init.Run(A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_clinit) } }

func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_clinit() { A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_262, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_class }

func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A); return ok }

func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_Cast(x any) *A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_class)) }; return v }



type A_arbace_g2a_print_eval1580000008_A struct{ jrt.Object }

func A_arbace_g2a_print_eval1580000008_A_New() *A_arbace_g2a_print_eval1580000008_A { t := &A_arbace_g2a_print_eval1580000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_eval1580000008_A) Ctor() {}

func (t *A_arbace_g2a_print_eval1580000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_eval1580000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_eval1580000008_A_class }

func (t *A_arbace_g2a_print_eval1580000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_eval1580000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_eval1580000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_eval1580000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_eval1580000008_A); return ok }

func A_arbace_g2a_print_eval1580000008_A_Cast(x any) *A_arbace_g2a_print_eval1580000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_eval1580000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_eval1580000008_A_class)) }; return v }



type A_arbace_g2a_print_eval1580000008_fn__1580000009_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_eval1580000008_fn__1580000009_A_fn_class *jrt.Class

var A_arbace_g2a_print_eval1580000008_fn__1580000009_A_init jrt.ClassInit

func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_Init() { if !A_arbace_g2a_print_eval1580000008_fn__1580000009_A_init.Done() { A_arbace_g2a_print_eval1580000008_fn__1580000009_A_init.Run(A_arbace_g2a_print_eval1580000008_fn__1580000009_A_clinit) } }

func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_clinit() { A_arbace_g2a_print_eval1580000008_fn__1580000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_271, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_eval1580000008_fn__1580000009_A_class }

func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_eval1580000008_fn__1580000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_eval1580000008_fn__1580000009_A); return ok }

func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_Cast(x any) *A_arbace_g2a_print_eval1580000008_fn__1580000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_eval1580000008_fn__1580000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_eval1580000008_fn__1580000009_A_class)) }; return v }



type A_arbace_g2a_print_go_ns_aliases_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_go_ns_aliases_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_go_ns_aliases_A_fn_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_A_init jrt.ClassInit

func A_arbace_g2a_print_go_ns_aliases_A_Init() { if !A_arbace_g2a_print_go_ns_aliases_A_init.Done() { A_arbace_g2a_print_go_ns_aliases_A_init.Run(A_arbace_g2a_print_go_ns_aliases_A_clinit) } }

func A_arbace_g2a_print_go_ns_aliases_A_clinit() { A_arbace_g2a_print_go_ns_aliases_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_272, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_go_ns_aliases_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_go_ns_aliases_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_go_ns_aliases_A_class }

func (t *A_arbace_g2a_print_go_ns_aliases_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_go_ns_aliases_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_go_ns_aliases_A); return ok }

func A_arbace_g2a_print_go_ns_aliases_A_Cast(x any) *A_arbace_g2a_print_go_ns_aliases_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_go_ns_aliases_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_go_ns_aliases_A_class)) }; return v }



type A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_fn_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_init jrt.ClassInit

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_Init() { if !A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_init.Done() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_init.Run(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_clinit) } }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_clinit() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_273, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A); return ok }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_Cast(x any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class)) }; return v }



type A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A struct{ jrt.Object; F_s__1580000014, F_iter__1580000013 any }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_fn_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_init jrt.ClassInit

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_Init() { if !A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_init.Done() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_init.Run(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_clinit) } }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_clinit() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_274, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A); return ok }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_Cast(x any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class)) }; return v }



type A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_fn_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_init jrt.ClassInit

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_Init() { if !A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_init.Done() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_init.Run(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_clinit) } }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_clinit() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_275, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A); return ok }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_Cast(x any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class)) }; return v }



type A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A struct{ jrt.Object; F_s__1580000016, F_iter__1580000015 any }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_fn_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_init jrt.ClassInit

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_Init() { if !A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_init.Done() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_init.Run(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_clinit) } }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_clinit() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_276, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A); return ok }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_Cast(x any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class)) }; return v }



type A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A struct{ jrt.Object; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1580000018 any }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_fn_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_init jrt.ClassInit

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_Init() { if !A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_init.Done() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_init.Run(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_clinit) } }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_clinit() { A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_277, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_class }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A); return ok }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_Cast(x any) *A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_class)) }; return v }



type A_arbace_g2a_print_gofmt_file_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_gofmt_file_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_gofmt_file_A_fn_class *jrt.Class

var A_arbace_g2a_print_gofmt_file_A_init jrt.ClassInit

func A_arbace_g2a_print_gofmt_file_A_Init() { if !A_arbace_g2a_print_gofmt_file_A_init.Done() { A_arbace_g2a_print_gofmt_file_A_init.Run(A_arbace_g2a_print_gofmt_file_A_clinit) } }

func A_arbace_g2a_print_gofmt_file_A_clinit() { A_arbace_g2a_print_gofmt_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_278, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_gofmt_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_gofmt_file_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_gofmt_file_A_class }

func (t *A_arbace_g2a_print_gofmt_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_gofmt_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_gofmt_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_gofmt_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_gofmt_file_A); return ok }

func A_arbace_g2a_print_gofmt_file_A_Cast(x any) *A_arbace_g2a_print_gofmt_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_gofmt_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_gofmt_file_A_class)) }; return v }



type A_arbace_g2a_print_import_spec_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_import_spec_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_import_spec_A_fn_class *jrt.Class

var A_arbace_g2a_print_import_spec_A_init jrt.ClassInit

func A_arbace_g2a_print_import_spec_A_Init() { if !A_arbace_g2a_print_import_spec_A_init.Done() { A_arbace_g2a_print_import_spec_A_init.Run(A_arbace_g2a_print_import_spec_A_clinit) } }

func A_arbace_g2a_print_import_spec_A_clinit() { A_arbace_g2a_print_import_spec_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_282, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_import_spec_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_import_spec_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_import_spec_A_class }

func (t *A_arbace_g2a_print_import_spec_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_import_spec_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_import_spec_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_import_spec_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_import_spec_A); return ok }

func A_arbace_g2a_print_import_spec_A_Cast(x any) *A_arbace_g2a_print_import_spec_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_import_spec_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_import_spec_A_class)) }; return v }



type A_arbace_g2a_print_json_string_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_json_string_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_json_string_A_fn_class *jrt.Class

var A_arbace_g2a_print_json_string_A_init jrt.ClassInit

func A_arbace_g2a_print_json_string_A_Init() { if !A_arbace_g2a_print_json_string_A_init.Done() { A_arbace_g2a_print_json_string_A_init.Run(A_arbace_g2a_print_json_string_A_clinit) } }

func A_arbace_g2a_print_json_string_A_clinit() { A_arbace_g2a_print_json_string_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_283, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_json_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_json_string_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_json_string_A_class }

func (t *A_arbace_g2a_print_json_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_json_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_json_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_json_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_json_string_A); return ok }

func A_arbace_g2a_print_json_string_A_Cast(x any) *A_arbace_g2a_print_json_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_json_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_json_string_A_class)) }; return v }



type A_arbace_g2a_print_new_package_state_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_new_package_state_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_new_package_state_A_fn_class *jrt.Class

var A_arbace_g2a_print_new_package_state_A_init jrt.ClassInit

func A_arbace_g2a_print_new_package_state_A_Init() { if !A_arbace_g2a_print_new_package_state_A_init.Done() { A_arbace_g2a_print_new_package_state_A_init.Run(A_arbace_g2a_print_new_package_state_A_clinit) } }

func A_arbace_g2a_print_new_package_state_A_clinit() { A_arbace_g2a_print_new_package_state_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_288, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_new_package_state_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_new_package_state_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_new_package_state_A_class }

func (t *A_arbace_g2a_print_new_package_state_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_new_package_state_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_new_package_state_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_new_package_state_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_new_package_state_A); return ok }

func A_arbace_g2a_print_new_package_state_A_Cast(x any) *A_arbace_g2a_print_new_package_state_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_new_package_state_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_new_package_state_A_class)) }; return v }



type A_arbace_g2a_print_next_target_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_next_target_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_next_target_A_fn_class *jrt.Class

var A_arbace_g2a_print_next_target_A_init jrt.ClassInit

func A_arbace_g2a_print_next_target_A_Init() { if !A_arbace_g2a_print_next_target_A_init.Done() { A_arbace_g2a_print_next_target_A_init.Run(A_arbace_g2a_print_next_target_A_clinit) } }

func A_arbace_g2a_print_next_target_A_clinit() { A_arbace_g2a_print_next_target_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_289, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_next_target_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_next_target_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_next_target_A_class }

func (t *A_arbace_g2a_print_next_target_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_next_target_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_next_target_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_next_target_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_next_target_A); return ok }

func A_arbace_g2a_print_next_target_A_Cast(x any) *A_arbace_g2a_print_next_target_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_next_target_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_next_target_A_class)) }; return v }



type A_arbace_g2a_print_next_target_fn__1580000108_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_next_target_fn__1580000108_A_fn_class *jrt.Class

var A_arbace_g2a_print_next_target_fn__1580000108_A_init jrt.ClassInit

func A_arbace_g2a_print_next_target_fn__1580000108_A_Init() { if !A_arbace_g2a_print_next_target_fn__1580000108_A_init.Done() { A_arbace_g2a_print_next_target_fn__1580000108_A_init.Run(A_arbace_g2a_print_next_target_fn__1580000108_A_clinit) } }

func A_arbace_g2a_print_next_target_fn__1580000108_A_clinit() { A_arbace_g2a_print_next_target_fn__1580000108_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_290, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_next_target_fn__1580000108_A_class }

func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_next_target_fn__1580000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_next_target_fn__1580000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_next_target_fn__1580000108_A); return ok }

func A_arbace_g2a_print_next_target_fn__1580000108_A_Cast(x any) *A_arbace_g2a_print_next_target_fn__1580000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_next_target_fn__1580000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_next_target_fn__1580000108_A_class)) }; return v }



type A_arbace_g2a_print_one_line_func_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_one_line_func_QMARK__A) Is_Compiler_AOTF3() {}

var A_arbace_g2a_print_one_line_func_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_one_line_func_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_one_line_func_QMARK__A_Init() { if !A_arbace_g2a_print_one_line_func_QMARK__A_init.Done() { A_arbace_g2a_print_one_line_func_QMARK__A_init.Run(A_arbace_g2a_print_one_line_func_QMARK__A_clinit) } }

func A_arbace_g2a_print_one_line_func_QMARK__A_clinit() { A_arbace_g2a_print_one_line_func_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_291, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_one_line_func_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_one_line_func_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_one_line_func_QMARK__A_class }

func (t *A_arbace_g2a_print_one_line_func_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_one_line_func_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_one_line_func_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_one_line_func_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_one_line_func_QMARK__A); return ok }

func A_arbace_g2a_print_one_line_func_QMARK__A_Cast(x any) *A_arbace_g2a_print_one_line_func_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_one_line_func_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_one_line_func_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_print_decl_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_print_decl_BANG__A) Is_Compiler_AOTF5() {}

var A_arbace_g2a_print_print_decl_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_print_decl_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_print_decl_BANG__A_Init() { if !A_arbace_g2a_print_print_decl_BANG__A_init.Done() { A_arbace_g2a_print_print_decl_BANG__A_init.Run(A_arbace_g2a_print_print_decl_BANG__A_clinit) } }

func A_arbace_g2a_print_print_decl_BANG__A_clinit() { A_arbace_g2a_print_print_decl_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_292, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_print_decl_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_print_decl_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_print_decl_BANG__A_class }

func (t *A_arbace_g2a_print_print_decl_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_print_decl_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_print_decl_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_print_decl_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_print_decl_BANG__A); return ok }

func A_arbace_g2a_print_print_decl_BANG__A_Cast(x any) *A_arbace_g2a_print_print_decl_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_print_decl_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_print_decl_BANG__A_class)) }; return v }



type A_arbace_g2a_print_print_file_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_print_file_A) Is_Compiler_AOTF3() {}

var A_arbace_g2a_print_print_file_A_fn_class *jrt.Class

var A_arbace_g2a_print_print_file_A_init jrt.ClassInit

func A_arbace_g2a_print_print_file_A_Init() { if !A_arbace_g2a_print_print_file_A_init.Done() { A_arbace_g2a_print_print_file_A_init.Run(A_arbace_g2a_print_print_file_A_clinit) } }

func A_arbace_g2a_print_print_file_A_clinit() { A_arbace_g2a_print_print_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_293, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_print_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_print_file_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_print_file_A_class }

func (t *A_arbace_g2a_print_print_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_print_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_print_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_print_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_print_file_A); return ok }

func A_arbace_g2a_print_print_file_A_Cast(x any) *A_arbace_g2a_print_print_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_print_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_print_file_A_class)) }; return v }



type A_arbace_g2a_print_print_file_first_line__1580000137_A struct{ jrt.Object; F_decls any }

func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_print_file_first_line__1580000137_A_fn_class *jrt.Class

var A_arbace_g2a_print_print_file_first_line__1580000137_A_init jrt.ClassInit

func A_arbace_g2a_print_print_file_first_line__1580000137_A_Init() { if !A_arbace_g2a_print_print_file_first_line__1580000137_A_init.Done() { A_arbace_g2a_print_print_file_first_line__1580000137_A_init.Run(A_arbace_g2a_print_print_file_first_line__1580000137_A_clinit) } }

func A_arbace_g2a_print_print_file_first_line__1580000137_A_clinit() { A_arbace_g2a_print_print_file_first_line__1580000137_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_296, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_print_file_first_line__1580000137_A_class }

func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_print_file_first_line__1580000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_print_file_first_line__1580000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_print_file_first_line__1580000137_A); return ok }

func A_arbace_g2a_print_print_file_first_line__1580000137_A_Cast(x any) *A_arbace_g2a_print_print_file_first_line__1580000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_print_file_first_line__1580000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_print_file_first_line__1580000137_A_class)) }; return v }



type A_arbace_g2a_print_print_file_fn__1580000140_A struct{ jrt.Object; F_popts, F_first_line, F_lines_QMARK_, F_decls, F_state_opts any }

func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_print_file_fn__1580000140_A_fn_class *jrt.Class

var A_arbace_g2a_print_print_file_fn__1580000140_A_init jrt.ClassInit

func A_arbace_g2a_print_print_file_fn__1580000140_A_Init() { if !A_arbace_g2a_print_print_file_fn__1580000140_A_init.Done() { A_arbace_g2a_print_print_file_fn__1580000140_A_init.Run(A_arbace_g2a_print_print_file_fn__1580000140_A_clinit) } }

func A_arbace_g2a_print_print_file_fn__1580000140_A_clinit() { A_arbace_g2a_print_print_file_fn__1580000140_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_297, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_print_file_fn__1580000140_A_class }

func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_print_file_fn__1580000140_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_print_file_fn__1580000140_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_print_file_fn__1580000140_A); return ok }

func A_arbace_g2a_print_print_file_fn__1580000140_A_Cast(x any) *A_arbace_g2a_print_print_file_fn__1580000140_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_print_file_fn__1580000140_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_print_file_fn__1580000140_A_class)) }; return v }



type A_arbace_g2a_print_print_forms_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_print_forms_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_print_forms_A_fn_class *jrt.Class

var A_arbace_g2a_print_print_forms_A_init jrt.ClassInit

func A_arbace_g2a_print_print_forms_A_Init() { if !A_arbace_g2a_print_print_forms_A_init.Done() { A_arbace_g2a_print_print_forms_A_init.Run(A_arbace_g2a_print_print_forms_A_clinit) } }

func A_arbace_g2a_print_print_forms_A_clinit() { A_arbace_g2a_print_print_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_298, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_print_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_print_forms_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_print_forms_A_class }

func (t *A_arbace_g2a_print_print_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_print_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_print_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_print_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_print_forms_A); return ok }

func A_arbace_g2a_print_print_forms_A_Cast(x any) *A_arbace_g2a_print_print_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_print_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_print_forms_A_class)) }; return v }



type A_arbace_g2a_print_print_forms_fn__1580000174_A struct{ jrt.Object; F_pkg, F_opts any }

func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_print_forms_fn__1580000174_A_fn_class *jrt.Class

var A_arbace_g2a_print_print_forms_fn__1580000174_A_init jrt.ClassInit

func A_arbace_g2a_print_print_forms_fn__1580000174_A_Init() { if !A_arbace_g2a_print_print_forms_fn__1580000174_A_init.Done() { A_arbace_g2a_print_print_forms_fn__1580000174_A_init.Run(A_arbace_g2a_print_print_forms_fn__1580000174_A_clinit) } }

func A_arbace_g2a_print_print_forms_fn__1580000174_A_clinit() { A_arbace_g2a_print_print_forms_fn__1580000174_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_299, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_print_forms_fn__1580000174_A_class }

func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_print_forms_fn__1580000174_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_print_forms_fn__1580000174_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_print_forms_fn__1580000174_A); return ok }

func A_arbace_g2a_print_print_forms_fn__1580000174_A_Cast(x any) *A_arbace_g2a_print_print_forms_fn__1580000174_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_print_forms_fn__1580000174_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_print_forms_fn__1580000174_A_class)) }; return v }



type A_arbace_g2a_print_print_package_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_print_package_A) Is_Compiler_AOTF3() {}

var A_arbace_g2a_print_print_package_A_fn_class *jrt.Class

var A_arbace_g2a_print_print_package_A_init jrt.ClassInit

func A_arbace_g2a_print_print_package_A_Init() { if !A_arbace_g2a_print_print_package_A_init.Done() { A_arbace_g2a_print_print_package_A_init.Run(A_arbace_g2a_print_print_package_A_clinit) } }

func A_arbace_g2a_print_print_package_A_clinit() { A_arbace_g2a_print_print_package_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_300, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_print_package_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_print_package_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_print_package_A_class }

func (t *A_arbace_g2a_print_print_package_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_print_package_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_print_package_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_print_package_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_print_package_A); return ok }

func A_arbace_g2a_print_print_package_A_Cast(x any) *A_arbace_g2a_print_print_package_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_print_package_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_print_package_A_class)) }; return v }



type A_arbace_g2a_print_read_forms_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_read_forms_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_read_forms_A_fn_class *jrt.Class

var A_arbace_g2a_print_read_forms_A_init jrt.ClassInit

func A_arbace_g2a_print_read_forms_A_Init() { if !A_arbace_g2a_print_read_forms_A_init.Done() { A_arbace_g2a_print_read_forms_A_init.Run(A_arbace_g2a_print_read_forms_A_clinit) } }

func A_arbace_g2a_print_read_forms_A_clinit() { A_arbace_g2a_print_read_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_301, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_read_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_read_forms_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_read_forms_A_class }

func (t *A_arbace_g2a_print_read_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_read_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_read_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_read_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_read_forms_A); return ok }

func A_arbace_g2a_print_read_forms_A_Cast(x any) *A_arbace_g2a_print_read_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_read_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_read_forms_A_class)) }; return v }



type A_arbace_g2a_print_run_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_run_A) Is_Compiler_AOTF3() {}

var A_arbace_g2a_print_run_A_fn_class *jrt.Class

var A_arbace_g2a_print_run_A_init jrt.ClassInit

func A_arbace_g2a_print_run_A_Init() { if !A_arbace_g2a_print_run_A_init.Done() { A_arbace_g2a_print_run_A_init.Run(A_arbace_g2a_print_run_A_clinit) } }

func A_arbace_g2a_print_run_A_clinit() { A_arbace_g2a_print_run_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_302, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_run_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_run_A_class }

func (t *A_arbace_g2a_print_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_run_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_run_A); return ok }

func A_arbace_g2a_print_run_A_Cast(x any) *A_arbace_g2a_print_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_run_A_class)) }; return v }



type A_arbace_g2a_print_sha256_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_sha256_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_sha256_A_fn_class *jrt.Class

var A_arbace_g2a_print_sha256_A_init jrt.ClassInit

func A_arbace_g2a_print_sha256_A_Init() { if !A_arbace_g2a_print_sha256_A_init.Done() { A_arbace_g2a_print_sha256_A_init.Run(A_arbace_g2a_print_sha256_A_clinit) } }

func A_arbace_g2a_print_sha256_A_clinit() { A_arbace_g2a_print_sha256_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_303, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_sha256_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_sha256_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_sha256_A_class }

func (t *A_arbace_g2a_print_sha256_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_sha256_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_sha256_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_sha256_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_sha256_A); return ok }

func A_arbace_g2a_print_sha256_A_Cast(x any) *A_arbace_g2a_print_sha256_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_sha256_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_sha256_A_class)) }; return v }



type A_arbace_g2a_print_sha256_fn__1580000178_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_sha256_fn__1580000178_A_fn_class *jrt.Class

var A_arbace_g2a_print_sha256_fn__1580000178_A_init jrt.ClassInit

func A_arbace_g2a_print_sha256_fn__1580000178_A_Init() { if !A_arbace_g2a_print_sha256_fn__1580000178_A_init.Done() { A_arbace_g2a_print_sha256_fn__1580000178_A_init.Run(A_arbace_g2a_print_sha256_fn__1580000178_A_clinit) } }

func A_arbace_g2a_print_sha256_fn__1580000178_A_clinit() { A_arbace_g2a_print_sha256_fn__1580000178_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_305, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_sha256_fn__1580000178_A_class }

func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_sha256_fn__1580000178_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_sha256_fn__1580000178_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_sha256_fn__1580000178_A); return ok }

func A_arbace_g2a_print_sha256_fn__1580000178_A_Cast(x any) *A_arbace_g2a_print_sha256_fn__1580000178_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_sha256_fn__1580000178_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_sha256_fn__1580000178_A_class)) }; return v }



type A_arbace_g2a_print_write_import_decl_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_write_import_decl_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_write_import_decl_A_fn_class *jrt.Class

var A_arbace_g2a_print_write_import_decl_A_init jrt.ClassInit

func A_arbace_g2a_print_write_import_decl_A_Init() { if !A_arbace_g2a_print_write_import_decl_A_init.Done() { A_arbace_g2a_print_write_import_decl_A_init.Run(A_arbace_g2a_print_write_import_decl_A_clinit) } }

func A_arbace_g2a_print_write_import_decl_A_clinit() { A_arbace_g2a_print_write_import_decl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_307, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_write_import_decl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_write_import_decl_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_write_import_decl_A_class }

func (t *A_arbace_g2a_print_write_import_decl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_write_import_decl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_write_import_decl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_write_import_decl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_write_import_decl_A); return ok }

func A_arbace_g2a_print_write_import_decl_A_Cast(x any) *A_arbace_g2a_print_write_import_decl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_write_import_decl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_write_import_decl_A_class)) }; return v }



type A_arbace_g2a_print_write_imports_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_write_imports_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_write_imports_A_fn_class *jrt.Class

var A_arbace_g2a_print_write_imports_A_init jrt.ClassInit

func A_arbace_g2a_print_write_imports_A_Init() { if !A_arbace_g2a_print_write_imports_A_init.Done() { A_arbace_g2a_print_write_imports_A_init.Run(A_arbace_g2a_print_write_imports_A_clinit) } }

func A_arbace_g2a_print_write_imports_A_clinit() { A_arbace_g2a_print_write_imports_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_311, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_write_imports_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_write_imports_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_write_imports_A_class }

func (t *A_arbace_g2a_print_write_imports_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_write_imports_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_write_imports_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_write_imports_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_write_imports_A); return ok }

func A_arbace_g2a_print_write_imports_A_Cast(x any) *A_arbace_g2a_print_write_imports_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_write_imports_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_write_imports_A_class)) }; return v }



type A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_fn_class *jrt.Class

var A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_init jrt.ClassInit

func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_Init() { if !A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_init.Done() { A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_init.Run(A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_clinit) } }

func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_clinit() { A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_312, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_class }

func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A); return ok }

func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_Cast(x any) *A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_class)) }; return v }
