//line aot_arbace_g2a_print__init.ae:1
package aot_arbace_g2a_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print__init_A_Unit0__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_g2a_print__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print__init_A_const_1) }
//line :1:1
func A_arbace_g2a_print__init_A_Unit1__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_print__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_print__init_A_Unit2__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_print__init_A_Unit3__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_print__init_A_const_1)).Equals_O__Z(A_arbace_g2a_print__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_print_eval1580000008_fn__1580000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_print_eval1580000008_fn__1580000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_g2a_print_eval1580000008_fn__1580000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_print__init_A_Load__O() any { A_arbace_g2a_print__init_A_Init(); A_arbace_g2a_print__init_A_Unit0__O(); A_arbace_g2a_print__init_A_Unit1__O(); A_arbace_g2a_print__init_A_Unit2__O(); A_arbace_g2a_print__init_A_Unit3__O(); A_arbace_g2a_print__init_A_Unit4__O(); A_arbace_g2a_print__init_A_Unit5__O(); A_arbace_g2a_print__init_A_Unit6__O(); A_arbace_g2a_print__init_A_Unit7__O(); A_arbace_g2a_print__init_A_Unit8__O(); A_arbace_g2a_print__init_A_Unit9__O(); A_arbace_g2a_print__init_A_Unit10__O(); A_arbace_g2a_print__init_A_Unit11__O(); A_arbace_g2a_print__init_A_Unit12__O(); A_arbace_g2a_print__init_A_Unit13__O(); A_arbace_g2a_print__init_A_Unit14__O(); A_arbace_g2a_print__init_A_Unit15__O(); A_arbace_g2a_print__init_A_Unit16__O(); A_arbace_g2a_print__init_A_Unit17__O(); A_arbace_g2a_print__init_A_Unit18__O(); A_arbace_g2a_print__init_A_Unit19__O(); A_arbace_g2a_print__init_A_Unit20__O(); A_arbace_g2a_print__init_A_Unit21__O(); A_arbace_g2a_print__init_A_Unit22__O(); A_arbace_g2a_print__init_A_Unit23__O(); A_arbace_g2a_print__init_A_Unit24__O(); A_arbace_g2a_print__init_A_Unit25__O(); A_arbace_g2a_print__init_A_Unit26__O(); A_arbace_g2a_print__init_A_Unit27__O(); A_arbace_g2a_print__init_A_Unit28__O(); A_arbace_g2a_print__init_A_Unit29__O(); A_arbace_g2a_print__init_A_Unit30__O(); A_arbace_g2a_print__init_A_Unit31__O(); A_arbace_g2a_print__init_A_Unit32__O(); return nil }






























func A_arbace_g2a_print__init_A_Unit4__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_4; var tmp2 any = A_arbace_g2a_print_read_forms_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_print_read_forms_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_g2a_print_read_forms_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_5)); return A_arbace_g2a_print__init_A_const_4 }










func A_arbace_g2a_print__init_A_Unit5__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_6; var tmp2 any = A_arbace_g2a_print_go_ns_aliases_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_print_go_ns_aliases_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_g2a_print_go_ns_aliases_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_7)); return A_arbace_g2a_print__init_A_const_6 }











func A_arbace_g2a_print__init_A_Unit6__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); A_arbace_g2a_print__init_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_9)); return A_arbace_g2a_print__init_A_const_8.SetDynamic_Z__Var(true).Ref() }

func A_arbace_g2a_print__init_A_Unit7__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(61, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_10; var tmp2 any = A_arbace_g2a_print_add_form_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_print_add_form_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_g2a_print_add_form_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_11)); return A_arbace_g2a_print__init_A_const_10 }






















func A_arbace_g2a_print__init_A_Unit8__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(84, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_12; var tmp2 any = A_arbace_g2a_print_new_package_state_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_print_new_package_state_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_g2a_print_new_package_state_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_13)); return A_arbace_g2a_print__init_A_const_12 }


func A_arbace_g2a_print__init_A_Unit9__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_14; var tmp2 any = A_arbace_g2a_print_collect_forms_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_print_collect_forms_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_g2a_print_collect_forms_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_15)); return A_arbace_g2a_print__init_A_const_14 }








func A_arbace_g2a_print__init_A_Unit10__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_16; var tmp2 any = A_arbace_g2a_print_collect_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_print_collect_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_g2a_print_collect_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_17)); return A_arbace_g2a_print__init_A_const_16 }



























func A_arbace_g2a_print__init_A_Unit11__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_18; var tmp2 any = A_arbace_g2a_print_import_spec_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_print_import_spec_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_112, false); A_arbace_g2a_print_import_spec_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_19)); return A_arbace_g2a_print__init_A_const_18 }





func A_arbace_g2a_print__init_A_Unit12__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_20; var tmp2 any = A_arbace_g2a_print_write_import_decl_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_print_write_import_decl_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); A_arbace_g2a_print_write_import_decl_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_21)); return A_arbace_g2a_print__init_A_const_20 }















func A_arbace_g2a_print__init_A_Unit13__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(146, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_22; var tmp2 any = A_arbace_g2a_print_write_imports_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_print_write_imports_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_g2a_print_write_imports_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_23)); return A_arbace_g2a_print__init_A_const_22 }















func A_arbace_g2a_print__init_A_Unit14__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_24; var tmp2 any = A_arbace_g2a_print_one_line_func_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_g2a_print_one_line_func_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_g2a_print_one_line_func_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_25)); return A_arbace_g2a_print__init_A_const_24 }












func A_arbace_g2a_print__init_A_Unit15__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(175, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_26; var tmp2 any = A_arbace_g2a_print_decl_pre_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_print_decl_pre_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_g2a_print_decl_pre_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_27)); return A_arbace_g2a_print__init_A_const_26 }






func A_arbace_g2a_print__init_A_Unit16__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_28; var tmp2 any = A_arbace_g2a_print_next_target_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_g2a_print_next_target_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_g2a_print_next_target_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_29)); return A_arbace_g2a_print__init_A_const_28 }






func A_arbace_g2a_print__init_A_Unit17__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(189, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_30; var tmp2 any = A_arbace_g2a_print_decl_sep_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_print_decl_sep_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_g2a_print_decl_sep_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_31)); return A_arbace_g2a_print__init_A_const_30 }












func A_arbace_g2a_print__init_A_Unit18__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_32; var tmp2 any = A_arbace_g2a_print_print_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_g2a_print_print_decl_BANG__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_g2a_print_print_decl_BANG__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_33)); return A_arbace_g2a_print__init_A_const_32 }


















func A_arbace_g2a_print__init_A_Unit19__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(221, 1); A_arbace_g2a_print__init_A_const_34.BindRoot_O__V(A_arbace_g2a_print__init_A_const_35); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_36)); return A_arbace_g2a_print__init_A_const_34 }



func A_arbace_g2a_print__init_A_Unit20__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(225, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_37; var tmp2 any = A_arbace_g2a_print_chunk_starts_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_print_chunk_starts_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_g2a_print_chunk_starts_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_38)); return A_arbace_g2a_print__init_A_const_37 }













func A_arbace_g2a_print__init_A_Unit21__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(239, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_39; var tmp2 any = A_arbace_g2a_print_print_file_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_g2a_print_print_file_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_g2a_print_print_file_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_40)); return A_arbace_g2a_print__init_A_const_39 }



















































func A_arbace_g2a_print__init_A_Unit22__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(291, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_41; var tmp2 any = A_arbace_g2a_print_print_forms_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_print_print_forms_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_g2a_print_print_forms_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_42)); return A_arbace_g2a_print__init_A_const_41 }










func A_arbace_g2a_print__init_A_Unit23__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(302, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_43; var tmp2 any = A_arbace_g2a_print_sha256_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_print_sha256_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); A_arbace_g2a_print_sha256_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_44)); return A_arbace_g2a_print__init_A_const_43 }




func A_arbace_g2a_print__init_A_Unit24__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(307, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_45; var tmp2 any = A_arbace_g2a_print_copy_file_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_g2a_print_copy_file_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_124, false); A_arbace_g2a_print_copy_file_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_46)); return A_arbace_g2a_print__init_A_const_45 }




func A_arbace_g2a_print__init_A_Unit25__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(312, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_47; var tmp2 any = A_arbace_g2a_print_json_string_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_g2a_print_json_string_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_125, false); A_arbace_g2a_print_json_string_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_48)); return A_arbace_g2a_print__init_A_const_47 }


func A_arbace_g2a_print__init_A_Unit26__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(315, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_49; var tmp2 any = A_arbace_g2a_print_copy_files_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_g2a_print_copy_files_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_g2a_print_copy_files_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_50)); return A_arbace_g2a_print__init_A_const_49 }



















func A_arbace_g2a_print__init_A_Unit27__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(335, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_51; var tmp2 any = A_arbace_g2a_print_build_env_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_g2a_print_build_env_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_g2a_print_build_env_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_52)); return A_arbace_g2a_print__init_A_const_51 }










func A_arbace_g2a_print__init_A_Unit28__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(346, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_53; var tmp2 any = A_arbace_g2a_print_run_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_g2a_print_run_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_g2a_print_run_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_54)); return A_arbace_g2a_print__init_A_const_53 }









func A_arbace_g2a_print__init_A_Unit29__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(356, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_55; var tmp2 any = A_arbace_g2a_print_build_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_g2a_print_build_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_g2a_print_build_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_56)); return A_arbace_g2a_print__init_A_const_55 }










func A_arbace_g2a_print__init_A_Unit30__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(367, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_57; var tmp2 any = A_arbace_g2a_print_print_package_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_g2a_print_print_package_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_g2a_print_print_package_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_58)); return A_arbace_g2a_print__init_A_const_57 }











func A_arbace_g2a_print__init_A_Unit31__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(379, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_59; var tmp2 any = A_arbace_g2a_print_gofmt_file_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_g2a_print_gofmt_file_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_g2a_print_gofmt_file_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_60)); return A_arbace_g2a_print__init_A_const_59 }




func A_arbace_g2a_print__init_A_Unit32__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(384, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_61; var tmp2 any = A_arbace_g2a_print__main_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_g2a_print__main_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, true); A_arbace_g2a_print__main_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_62)); return A_arbace_g2a_print__init_A_const_61 }



type A_arbace_g2a_print__init_A struct{ jrt.Object }

var A_arbace_g2a_print__init_A_const_pool *jrt.RefArray

var A_arbace_g2a_print__init_A_const_0 *lang.Var

var A_arbace_g2a_print__init_A_const_1 any

var A_arbace_g2a_print__init_A_const_2 any

var A_arbace_g2a_print__init_A_const_3 any

var A_arbace_g2a_print__init_A_const_4 *lang.Var

var A_arbace_g2a_print__init_A_const_5 any

var A_arbace_g2a_print__init_A_const_6 *lang.Var

var A_arbace_g2a_print__init_A_const_7 any

var A_arbace_g2a_print__init_A_const_8 *lang.Var

var A_arbace_g2a_print__init_A_const_9 any

var A_arbace_g2a_print__init_A_const_10 *lang.Var

var A_arbace_g2a_print__init_A_const_11 any

var A_arbace_g2a_print__init_A_const_12 *lang.Var

var A_arbace_g2a_print__init_A_const_13 any

var A_arbace_g2a_print__init_A_const_14 *lang.Var

var A_arbace_g2a_print__init_A_const_15 any

var A_arbace_g2a_print__init_A_const_16 *lang.Var

var A_arbace_g2a_print__init_A_const_17 any

var A_arbace_g2a_print__init_A_const_18 *lang.Var

var A_arbace_g2a_print__init_A_const_19 any

var A_arbace_g2a_print__init_A_const_20 *lang.Var

var A_arbace_g2a_print__init_A_const_21 any

var A_arbace_g2a_print__init_A_const_22 *lang.Var

var A_arbace_g2a_print__init_A_const_23 any

var A_arbace_g2a_print__init_A_const_24 *lang.Var

var A_arbace_g2a_print__init_A_const_25 any

var A_arbace_g2a_print__init_A_const_26 *lang.Var

var A_arbace_g2a_print__init_A_const_27 any

var A_arbace_g2a_print__init_A_const_28 *lang.Var

var A_arbace_g2a_print__init_A_const_29 any

var A_arbace_g2a_print__init_A_const_30 *lang.Var

var A_arbace_g2a_print__init_A_const_31 any

var A_arbace_g2a_print__init_A_const_32 *lang.Var

var A_arbace_g2a_print__init_A_const_33 any

var A_arbace_g2a_print__init_A_const_34 *lang.Var

var A_arbace_g2a_print__init_A_const_35 any

var A_arbace_g2a_print__init_A_const_36 any

var A_arbace_g2a_print__init_A_const_37 *lang.Var

var A_arbace_g2a_print__init_A_const_38 any

var A_arbace_g2a_print__init_A_const_39 *lang.Var

var A_arbace_g2a_print__init_A_const_40 any

var A_arbace_g2a_print__init_A_const_41 *lang.Var

var A_arbace_g2a_print__init_A_const_42 any

var A_arbace_g2a_print__init_A_const_43 *lang.Var

var A_arbace_g2a_print__init_A_const_44 any

var A_arbace_g2a_print__init_A_const_45 *lang.Var

var A_arbace_g2a_print__init_A_const_46 any

var A_arbace_g2a_print__init_A_const_47 *lang.Var

var A_arbace_g2a_print__init_A_const_48 any

var A_arbace_g2a_print__init_A_const_49 *lang.Var

var A_arbace_g2a_print__init_A_const_50 any

var A_arbace_g2a_print__init_A_const_51 *lang.Var

var A_arbace_g2a_print__init_A_const_52 any

var A_arbace_g2a_print__init_A_const_53 *lang.Var

var A_arbace_g2a_print__init_A_const_54 any

var A_arbace_g2a_print__init_A_const_55 *lang.Var

var A_arbace_g2a_print__init_A_const_56 any

var A_arbace_g2a_print__init_A_const_57 *lang.Var

var A_arbace_g2a_print__init_A_const_58 any

var A_arbace_g2a_print__init_A_const_59 *lang.Var

var A_arbace_g2a_print__init_A_const_60 any

var A_arbace_g2a_print__init_A_const_61 *lang.Var

var A_arbace_g2a_print__init_A_const_62 any

var A_arbace_g2a_print__init_A_init jrt.ClassInit

func A_arbace_g2a_print__init_A_Init() { if !A_arbace_g2a_print__init_A_init.Done() { A_arbace_g2a_print__init_A_init.Run(A_arbace_g2a_print__init_A_clinit) } }

func A_arbace_g2a_print__init_A_clinit() { A_arbace_g2a_print__init_A_clinit_p0(); A_arbace_g2a_print__init_A_clinit_p1(); A_arbace_g2a_print__init_A_clinit_p2(); A_arbace_g2a_print__init_A_clinit_p3(); A_arbace_g2a_print__init_A_clinit_p4() }

func A_arbace_g2a_print__init_A_clinit_p0() { A_arbace_g2a_print__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_103, 109); A_arbace_g2a_print__init_A_const_0 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[46]); A_arbace_g2a_print__init_A_const_1 = A_arbace_g2a_print__init_A_const_pool.A[47]; A_arbace_g2a_print__init_A_const_2 = A_arbace_g2a_print__init_A_const_pool.A[48]; A_arbace_g2a_print__init_A_const_3 = A_arbace_g2a_print__init_A_const_pool.A[49]; A_arbace_g2a_print__init_A_const_4 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[50]); A_arbace_g2a_print__init_A_const_5 = A_arbace_g2a_print__init_A_const_pool.A[51]; A_arbace_g2a_print__init_A_const_6 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[52]); A_arbace_g2a_print__init_A_const_7 = A_arbace_g2a_print__init_A_const_pool.A[53]; A_arbace_g2a_print__init_A_const_8 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[54]); A_arbace_g2a_print__init_A_const_9 = A_arbace_g2a_print__init_A_const_pool.A[55]; A_arbace_g2a_print__init_A_const_10 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[56]); A_arbace_g2a_print__init_A_const_11 = A_arbace_g2a_print__init_A_const_pool.A[57]; A_arbace_g2a_print__init_A_const_12 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[58]) }

func A_arbace_g2a_print__init_A_clinit_p1() { A_arbace_g2a_print__init_A_const_13 = A_arbace_g2a_print__init_A_const_pool.A[59]; A_arbace_g2a_print__init_A_const_14 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[60]); A_arbace_g2a_print__init_A_const_15 = A_arbace_g2a_print__init_A_const_pool.A[61]; A_arbace_g2a_print__init_A_const_16 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[62]); A_arbace_g2a_print__init_A_const_17 = A_arbace_g2a_print__init_A_const_pool.A[63]; A_arbace_g2a_print__init_A_const_18 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[64]); A_arbace_g2a_print__init_A_const_19 = A_arbace_g2a_print__init_A_const_pool.A[65]; A_arbace_g2a_print__init_A_const_20 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[66]); A_arbace_g2a_print__init_A_const_21 = A_arbace_g2a_print__init_A_const_pool.A[67]; A_arbace_g2a_print__init_A_const_22 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[68]); A_arbace_g2a_print__init_A_const_23 = A_arbace_g2a_print__init_A_const_pool.A[69]; A_arbace_g2a_print__init_A_const_24 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[70]); A_arbace_g2a_print__init_A_const_25 = A_arbace_g2a_print__init_A_const_pool.A[71] }

func A_arbace_g2a_print__init_A_clinit_p2() { A_arbace_g2a_print__init_A_const_26 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[72]); A_arbace_g2a_print__init_A_const_27 = A_arbace_g2a_print__init_A_const_pool.A[73]; A_arbace_g2a_print__init_A_const_28 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[74]); A_arbace_g2a_print__init_A_const_29 = A_arbace_g2a_print__init_A_const_pool.A[75]; A_arbace_g2a_print__init_A_const_30 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[76]); A_arbace_g2a_print__init_A_const_31 = A_arbace_g2a_print__init_A_const_pool.A[77]; A_arbace_g2a_print__init_A_const_32 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[78]); A_arbace_g2a_print__init_A_const_33 = A_arbace_g2a_print__init_A_const_pool.A[79]; A_arbace_g2a_print__init_A_const_34 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[80]); A_arbace_g2a_print__init_A_const_35 = A_arbace_g2a_print__init_A_const_pool.A[81]; A_arbace_g2a_print__init_A_const_36 = A_arbace_g2a_print__init_A_const_pool.A[82]; A_arbace_g2a_print__init_A_const_37 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[83]); A_arbace_g2a_print__init_A_const_38 = A_arbace_g2a_print__init_A_const_pool.A[84] }

func A_arbace_g2a_print__init_A_clinit_p3() { A_arbace_g2a_print__init_A_const_39 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[85]); A_arbace_g2a_print__init_A_const_40 = A_arbace_g2a_print__init_A_const_pool.A[86]; A_arbace_g2a_print__init_A_const_41 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[87]); A_arbace_g2a_print__init_A_const_42 = A_arbace_g2a_print__init_A_const_pool.A[88]; A_arbace_g2a_print__init_A_const_43 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[89]); A_arbace_g2a_print__init_A_const_44 = A_arbace_g2a_print__init_A_const_pool.A[90]; A_arbace_g2a_print__init_A_const_45 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[91]); A_arbace_g2a_print__init_A_const_46 = A_arbace_g2a_print__init_A_const_pool.A[92]; A_arbace_g2a_print__init_A_const_47 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[93]); A_arbace_g2a_print__init_A_const_48 = A_arbace_g2a_print__init_A_const_pool.A[94]; A_arbace_g2a_print__init_A_const_49 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[95]); A_arbace_g2a_print__init_A_const_50 = A_arbace_g2a_print__init_A_const_pool.A[96]; A_arbace_g2a_print__init_A_const_51 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[97]) }

func A_arbace_g2a_print__init_A_clinit_p4() { A_arbace_g2a_print__init_A_const_52 = A_arbace_g2a_print__init_A_const_pool.A[98]; A_arbace_g2a_print__init_A_const_53 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[99]); A_arbace_g2a_print__init_A_const_54 = A_arbace_g2a_print__init_A_const_pool.A[100]; A_arbace_g2a_print__init_A_const_55 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[101]); A_arbace_g2a_print__init_A_const_56 = A_arbace_g2a_print__init_A_const_pool.A[102]; A_arbace_g2a_print__init_A_const_57 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[103]); A_arbace_g2a_print__init_A_const_58 = A_arbace_g2a_print__init_A_const_pool.A[104]; A_arbace_g2a_print__init_A_const_59 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[105]); A_arbace_g2a_print__init_A_const_60 = A_arbace_g2a_print__init_A_const_pool.A[106]; A_arbace_g2a_print__init_A_const_61 = lang.Var_Cast(A_arbace_g2a_print__init_A_const_pool.A[107]); A_arbace_g2a_print__init_A_const_62 = A_arbace_g2a_print__init_A_const_pool.A[108] }

func A_arbace_g2a_print__init_A_New() *A_arbace_g2a_print__init_A { A_arbace_g2a_print__init_A_Init(); t := &A_arbace_g2a_print__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print__init_A) Ctor() {}

func (t *A_arbace_g2a_print__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print__init_A_class }

func (t *A_arbace_g2a_print__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print__init_A); return ok }

func A_arbace_g2a_print__init_A_Cast(x any) *A_arbace_g2a_print__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print__init_A_class)) }; return v }
