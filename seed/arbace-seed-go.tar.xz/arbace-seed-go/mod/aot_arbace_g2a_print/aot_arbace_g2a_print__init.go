//line aot_arbace_g2a_print__init.ae:1
package aot_arbace_g2a_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print__init_A_Unit0__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_print__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print__init_A_const_1) }
//line :1:1
func A_arbace_g2a_print__init_A_Unit1__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_print__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_print__init_A_Unit2__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_Init(); tmp2 = A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_print__init_A_Unit3__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_print__init_A_const_1)).Equals_O__Z(A_arbace_g2a_print__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_print_eval1580000008_fn__1580000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_print_eval1580000008_fn__1580000009_A_Init(); tmp2 = A_arbace_g2a_print_eval1580000008_fn__1580000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_print__init_A_Load__O() any { A_arbace_g2a_print__init_A_Init(); A_arbace_g2a_print__init_A_Unit0__O(); A_arbace_g2a_print__init_A_Unit1__O(); A_arbace_g2a_print__init_A_Unit2__O(); A_arbace_g2a_print__init_A_Unit3__O(); A_arbace_g2a_print__init_A_Unit4__O(); A_arbace_g2a_print__init_A_Unit5__O(); A_arbace_g2a_print__init_A_Unit6__O(); A_arbace_g2a_print__init_A_Unit7__O(); A_arbace_g2a_print__init_A_Unit8__O(); A_arbace_g2a_print__init_A_Unit9__O(); A_arbace_g2a_print__init_A_Unit10__O(); A_arbace_g2a_print__init_A_Unit11__O(); A_arbace_g2a_print__init_A_Unit12__O(); A_arbace_g2a_print__init_A_Unit13__O(); A_arbace_g2a_print__init_A_Unit14__O(); A_arbace_g2a_print__init_A_Unit15__O(); A_arbace_g2a_print__init_A_Unit16__O(); A_arbace_g2a_print__init_A_Unit17__O(); A_arbace_g2a_print__init_A_Unit18__O(); A_arbace_g2a_print__init_A_Unit19__O(); A_arbace_g2a_print__init_A_Unit20__O(); A_arbace_g2a_print__init_A_Unit21__O(); A_arbace_g2a_print__init_A_Unit22__O(); A_arbace_g2a_print__init_A_Unit23__O(); A_arbace_g2a_print__init_A_Unit24__O(); A_arbace_g2a_print__init_A_Unit25__O(); A_arbace_g2a_print__init_A_Unit26__O(); A_arbace_g2a_print__init_A_Unit27__O(); A_arbace_g2a_print__init_A_Unit28__O(); A_arbace_g2a_print__init_A_Unit29__O(); A_arbace_g2a_print__init_A_Unit30__O(); A_arbace_g2a_print__init_A_Unit31__O(); A_arbace_g2a_print__init_A_Unit32__O(); return nil }






























func A_arbace_g2a_print__init_A_Unit4__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_4; var tmp2 any = A_arbace_g2a_print_read_forms_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_read_forms_A_Init(); tmp3 = A_arbace_g2a_print_read_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_5)); return A_arbace_g2a_print__init_A_const_4.Ref() }










func A_arbace_g2a_print__init_A_Unit5__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_6; var tmp2 any = A_arbace_g2a_print_go_ns_aliases_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_go_ns_aliases_A_Init(); tmp3 = A_arbace_g2a_print_go_ns_aliases_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_7)); return A_arbace_g2a_print__init_A_const_6.Ref() }











func A_arbace_g2a_print__init_A_Unit6__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); jrt.NN(A_arbace_g2a_print__init_A_const_8).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_8; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_9)); return jrt.NN(A_arbace_g2a_print__init_A_const_8).SetDynamic_Z__Var(true).Ref() }

func A_arbace_g2a_print__init_A_Unit7__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(61, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_10; var tmp2 any = A_arbace_g2a_print_add_form_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_add_form_A_Init(); tmp3 = A_arbace_g2a_print_add_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_11)); return A_arbace_g2a_print__init_A_const_10.Ref() }






















func A_arbace_g2a_print__init_A_Unit8__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(84, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_12; var tmp2 any = A_arbace_g2a_print_new_package_state_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_new_package_state_A_Init(); tmp3 = A_arbace_g2a_print_new_package_state_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_13)); return A_arbace_g2a_print__init_A_const_12.Ref() }


func A_arbace_g2a_print__init_A_Unit9__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_14; var tmp2 any = A_arbace_g2a_print_collect_forms_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_collect_forms_A_Init(); tmp3 = A_arbace_g2a_print_collect_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_15)); return A_arbace_g2a_print__init_A_const_14.Ref() }








func A_arbace_g2a_print__init_A_Unit10__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_16; var tmp2 any = A_arbace_g2a_print_collect_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_collect_A_Init(); tmp3 = A_arbace_g2a_print_collect_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_17)); return A_arbace_g2a_print__init_A_const_16.Ref() }



























func A_arbace_g2a_print__init_A_Unit11__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_18; var tmp2 any = A_arbace_g2a_print_import_spec_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_import_spec_A_Init(); tmp3 = A_arbace_g2a_print_import_spec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_19)); return A_arbace_g2a_print__init_A_const_18.Ref() }





func A_arbace_g2a_print__init_A_Unit12__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_20; var tmp2 any = A_arbace_g2a_print_write_import_decl_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_write_import_decl_A_Init(); tmp3 = A_arbace_g2a_print_write_import_decl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_21)); return A_arbace_g2a_print__init_A_const_20.Ref() }















func A_arbace_g2a_print__init_A_Unit13__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(146, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_22; var tmp2 any = A_arbace_g2a_print_write_imports_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_write_imports_A_Init(); tmp3 = A_arbace_g2a_print_write_imports_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_23)); return A_arbace_g2a_print__init_A_const_22.Ref() }















func A_arbace_g2a_print__init_A_Unit14__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_24; var tmp2 any = A_arbace_g2a_print_one_line_func_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_one_line_func_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_one_line_func_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_25)); return A_arbace_g2a_print__init_A_const_24.Ref() }












func A_arbace_g2a_print__init_A_Unit15__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(175, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_26; var tmp2 any = A_arbace_g2a_print_decl_pre_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_decl_pre_A_Init(); tmp3 = A_arbace_g2a_print_decl_pre_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_27)); return A_arbace_g2a_print__init_A_const_26.Ref() }






func A_arbace_g2a_print__init_A_Unit16__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_28; var tmp2 any = A_arbace_g2a_print_next_target_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_next_target_A_Init(); tmp3 = A_arbace_g2a_print_next_target_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_29)); return A_arbace_g2a_print__init_A_const_28.Ref() }






func A_arbace_g2a_print__init_A_Unit17__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(189, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_30; var tmp2 any = A_arbace_g2a_print_decl_sep_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_decl_sep_BANG__A_Init(); tmp3 = A_arbace_g2a_print_decl_sep_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_31)); return A_arbace_g2a_print__init_A_const_30.Ref() }












func A_arbace_g2a_print__init_A_Unit18__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_32; var tmp2 any = A_arbace_g2a_print_print_decl_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_print_decl_BANG__A_Init(); tmp3 = A_arbace_g2a_print_print_decl_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_33)); return A_arbace_g2a_print__init_A_const_32.Ref() }


















func A_arbace_g2a_print__init_A_Unit19__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(221, 1); jrt.NN(A_arbace_g2a_print__init_A_const_34).BindRoot_O__V(A_arbace_g2a_print__init_A_const_35); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_34; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_36)); return A_arbace_g2a_print__init_A_const_34.Ref() }



func A_arbace_g2a_print__init_A_Unit20__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(225, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_37; var tmp2 any = A_arbace_g2a_print_chunk_starts_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_chunk_starts_A_Init(); tmp3 = A_arbace_g2a_print_chunk_starts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_38)); return A_arbace_g2a_print__init_A_const_37.Ref() }













func A_arbace_g2a_print__init_A_Unit21__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(239, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_39; var tmp2 any = A_arbace_g2a_print_print_file_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_print_file_A_Init(); tmp3 = A_arbace_g2a_print_print_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_40)); return A_arbace_g2a_print__init_A_const_39.Ref() }



















































func A_arbace_g2a_print__init_A_Unit22__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(291, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_41; var tmp2 any = A_arbace_g2a_print_print_forms_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_print_forms_A_Init(); tmp3 = A_arbace_g2a_print_print_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_42)); return A_arbace_g2a_print__init_A_const_41.Ref() }










func A_arbace_g2a_print__init_A_Unit23__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(302, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_43; var tmp2 any = A_arbace_g2a_print_sha256_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_sha256_A_Init(); tmp3 = A_arbace_g2a_print_sha256_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_44)); return A_arbace_g2a_print__init_A_const_43.Ref() }




func A_arbace_g2a_print__init_A_Unit24__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(307, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_45; var tmp2 any = A_arbace_g2a_print_copy_file_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_copy_file_A_Init(); tmp3 = A_arbace_g2a_print_copy_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_46)); return A_arbace_g2a_print__init_A_const_45.Ref() }




func A_arbace_g2a_print__init_A_Unit25__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(312, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_47; var tmp2 any = A_arbace_g2a_print_json_string_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_json_string_A_Init(); tmp3 = A_arbace_g2a_print_json_string_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_48)); return A_arbace_g2a_print__init_A_const_47.Ref() }


func A_arbace_g2a_print__init_A_Unit26__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(315, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_49; var tmp2 any = A_arbace_g2a_print_copy_files_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_copy_files_A_Init(); tmp3 = A_arbace_g2a_print_copy_files_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_50)); return A_arbace_g2a_print__init_A_const_49.Ref() }



















func A_arbace_g2a_print__init_A_Unit27__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(335, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_51; var tmp2 any = A_arbace_g2a_print_build_env_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_build_env_A_Init(); tmp3 = A_arbace_g2a_print_build_env_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_52)); return A_arbace_g2a_print__init_A_const_51.Ref() }










func A_arbace_g2a_print__init_A_Unit28__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(346, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_53; var tmp2 any = A_arbace_g2a_print_run_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_run_A_Init(); tmp3 = A_arbace_g2a_print_run_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_54)); return A_arbace_g2a_print__init_A_const_53.Ref() }









func A_arbace_g2a_print__init_A_Unit29__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(356, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_55; var tmp2 any = A_arbace_g2a_print_build_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_build_A_Init(); tmp3 = A_arbace_g2a_print_build_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_56)); return A_arbace_g2a_print__init_A_const_55.Ref() }










func A_arbace_g2a_print__init_A_Unit30__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(367, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_57; var tmp2 any = A_arbace_g2a_print_print_package_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_print_package_A_Init(); tmp3 = A_arbace_g2a_print_print_package_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_58)); return A_arbace_g2a_print__init_A_const_57.Ref() }











func A_arbace_g2a_print__init_A_Unit31__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(379, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_59; var tmp2 any = A_arbace_g2a_print_gofmt_file_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_gofmt_file_A_Init(); tmp3 = A_arbace_g2a_print_gofmt_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_59; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_60)); return A_arbace_g2a_print__init_A_const_59.Ref() }




func A_arbace_g2a_print__init_A_Unit32__O() any { A_arbace_g2a_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(384, 1); var tmp1 *lang.Var = A_arbace_g2a_print__init_A_const_61; var tmp2 any = A_arbace_g2a_print__main_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print__main_A_Init(); tmp3 = A_arbace_g2a_print__main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_g2a_print__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print__init_A_const_62)); return A_arbace_g2a_print__init_A_const_61.Ref() }



type A_arbace_g2a_print__init_A struct{ jrt.Object }

var A_arbace_g2a_print__init_A_const_0 *lang.Var

var A_arbace_g2a_print__init_A_const_1 any

var A_arbace_g2a_print__init_A_const_2 any

var A_arbace_g2a_print__init_A_const_3 any

var A_arbace_g2a_print__init_A_const_4 *lang.Var

var A_arbace_g2a_print__init_A_const_5 any

var A_arbace_g2a_print__init_A_const_6 *lang.Var

var A_arbace_g2a_print__init_A_const_7 any

var A_arbace_g2a_print__init_A_const_8 *lang.Var

var A_arbace_g2a_print__init_A_const_9 any

var A_arbace_g2a_print__init_A_const_10 *lang.Var

var A_arbace_g2a_print__init_A_const_11 any

var A_arbace_g2a_print__init_A_const_12 *lang.Var

var A_arbace_g2a_print__init_A_const_13 any

var A_arbace_g2a_print__init_A_const_14 *lang.Var

var A_arbace_g2a_print__init_A_const_15 any

var A_arbace_g2a_print__init_A_const_16 *lang.Var

var A_arbace_g2a_print__init_A_const_17 any

var A_arbace_g2a_print__init_A_const_18 *lang.Var

var A_arbace_g2a_print__init_A_const_19 any

var A_arbace_g2a_print__init_A_const_20 *lang.Var

var A_arbace_g2a_print__init_A_const_21 any

var A_arbace_g2a_print__init_A_const_22 *lang.Var

var A_arbace_g2a_print__init_A_const_23 any

var A_arbace_g2a_print__init_A_const_24 *lang.Var

var A_arbace_g2a_print__init_A_const_25 any

var A_arbace_g2a_print__init_A_const_26 *lang.Var

var A_arbace_g2a_print__init_A_const_27 any

var A_arbace_g2a_print__init_A_const_28 *lang.Var

var A_arbace_g2a_print__init_A_const_29 any

var A_arbace_g2a_print__init_A_const_30 *lang.Var

var A_arbace_g2a_print__init_A_const_31 any

var A_arbace_g2a_print__init_A_const_32 *lang.Var

var A_arbace_g2a_print__init_A_const_33 any

var A_arbace_g2a_print__init_A_const_34 *lang.Var

var A_arbace_g2a_print__init_A_const_35 any

var A_arbace_g2a_print__init_A_const_36 any

var A_arbace_g2a_print__init_A_const_37 *lang.Var

var A_arbace_g2a_print__init_A_const_38 any

var A_arbace_g2a_print__init_A_const_39 *lang.Var

var A_arbace_g2a_print__init_A_const_40 any

var A_arbace_g2a_print__init_A_const_41 *lang.Var

var A_arbace_g2a_print__init_A_const_42 any

var A_arbace_g2a_print__init_A_const_43 *lang.Var

var A_arbace_g2a_print__init_A_const_44 any

var A_arbace_g2a_print__init_A_const_45 *lang.Var

var A_arbace_g2a_print__init_A_const_46 any

var A_arbace_g2a_print__init_A_const_47 *lang.Var

var A_arbace_g2a_print__init_A_const_48 any

var A_arbace_g2a_print__init_A_const_49 *lang.Var

var A_arbace_g2a_print__init_A_const_50 any

var A_arbace_g2a_print__init_A_const_51 *lang.Var

var A_arbace_g2a_print__init_A_const_52 any

var A_arbace_g2a_print__init_A_const_53 *lang.Var

var A_arbace_g2a_print__init_A_const_54 any

var A_arbace_g2a_print__init_A_const_55 *lang.Var

var A_arbace_g2a_print__init_A_const_56 any

var A_arbace_g2a_print__init_A_const_57 *lang.Var

var A_arbace_g2a_print__init_A_const_58 any

var A_arbace_g2a_print__init_A_const_59 *lang.Var

var A_arbace_g2a_print__init_A_const_60 any

var A_arbace_g2a_print__init_A_const_61 *lang.Var

var A_arbace_g2a_print__init_A_const_62 any

var A_arbace_g2a_print__init_A_init jrt.ClassInit

func A_arbace_g2a_print__init_A_Init() { if !A_arbace_g2a_print__init_A_init.Done() { A_arbace_g2a_print__init_A_init.Run(A_arbace_g2a_print__init_A_clinit) } }

func A_arbace_g2a_print__init_A_clinit() { A_arbace_g2a_print__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_198); A_arbace_g2a_print__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_g2a_print__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_g2a_print__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_print__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_13, Lit_76); A_arbace_g2a_print__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_314, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_13, Lit_51); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_print__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_318).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_319, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_13, Lit_58); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_g2a_print__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_321)); A_arbace_g2a_print__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_13, Lit_66); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_g2a_print__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_322).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_323).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_324).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_325, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(61).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_13, Lit_64); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_g2a_print__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(84).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_13, Lit_326); A_arbace_g2a_print__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_327).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_328, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_13, Lit_75); A_arbace_g2a_print__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_329).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_330, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_13, Lit_85); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_g2a_print__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_331).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_13, Lit_89); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_g2a_print__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_332).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_13, Lit_138); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_g2a_print__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_143).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_333, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(146).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_13, Lit_108); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_g2a_print__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_323).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_334).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_335, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(162).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_13, Lit_106); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_g2a_print__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_323).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_336, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(175).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_13, Lit_113); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_g2a_print__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_338, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(182).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_13, Lit_114); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_g2a_print__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_323).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_334).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_339).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_340, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(189).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_13, Lit_144); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_g2a_print__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_342).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_343, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(202).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_13, Lit_119); A_arbace_g2a_print__init_A_const_35 = jrt.Long_ValueOf_J__Long(48).Ref(); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_g2a_print__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(221).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_344)); A_arbace_g2a_print__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_13, Lit_139); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_g2a_print__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_345, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(225).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_13, Lit_150); A_arbace_g2a_print__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_54).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_346).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_117).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_129).Ref()), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_347, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(239).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_13, Lit_174); A_arbace_g2a_print__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_348).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_349, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(291).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_13, Lit_159); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_g2a_print__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_323)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(302).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_13, Lit_157); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_g2a_print__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_352)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_353)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(307).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_13, Lit_161); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_g2a_print__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_354).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(312).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_13, Lit_183); A_arbace_g2a_print__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_348).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_57)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_355)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_356).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_357, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(315).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_13, Lit_173); A_arbace_g2a_print__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_170).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_358).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_359, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(335).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_13, Lit_172); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_g2a_print__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_360).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_361)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_362).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(346).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_13, Lit_141); A_arbace_g2a_print__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_348).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_57)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_355)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_358).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_363, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_13, Lit_178); A_arbace_g2a_print__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_364).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_365, lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(367).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_13, Lit_182); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_g2a_print__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_358).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_323)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(379).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)); A_arbace_g2a_print__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_13, Lit_366); A_arbace_g2a_print__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_313).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_367).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_368).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(384).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), Lit_316)) }

func A_arbace_g2a_print__init_A_New() *A_arbace_g2a_print__init_A { A_arbace_g2a_print__init_A_Init(); t := &A_arbace_g2a_print__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print__init_A) Ctor() {}

func (t *A_arbace_g2a_print__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print__init_A_class }

func (t *A_arbace_g2a_print__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print__init_A); return ok }

func A_arbace_g2a_print__init_A_Cast(x any) *A_arbace_g2a_print__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print__init_A_class)) }; return v }
