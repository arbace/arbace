//line a2g_classes.ae:1
package aot_arbace_g2a_print

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_print_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_A_New()}; return nil }

var A_arbace_g2a_print_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_A_new}

var A_arbace_g2a_print_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_A"})

func init() { i := A_arbace_g2a_print_A_class.Info(); i.IsInstance = A_arbace_g2a_print_A_InstanceOf; i.Init = A_arbace_g2a_print_A_Init; i.Table = A_arbace_g2a_print_A_members; jrt.RegisterGoType(A_arbace_g2a_print_A_class, reflect.TypeFor[A_arbace_g2a_print_A]()) }

func A_arbace_g2a_print__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print__main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print__main_A_New()}; return nil }

func A_arbace_g2a_print__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print__main_A_fn_class)}; return nil }

var A_arbace_g2a_print__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print__main_A_invoke, New: A_arbace_g2a_print__main_A_new, Get: A_arbace_g2a_print__main_A_get}

var A_arbace_g2a_print__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "_main", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print__main_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print__main_A_class.Info(); i.IsInstance = A_arbace_g2a_print__main_A_InstanceOf; i.Init = A_arbace_g2a_print__main_A_Init; i.Table = A_arbace_g2a_print__main_A_members; jrt.RegisterGoType(A_arbace_g2a_print__main_A_class, reflect.TypeFor[A_arbace_g2a_print__main_A]()) }

func A_arbace_g2a_print_add_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_add_form_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_add_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_add_form_A_New()}; return nil }

func A_arbace_g2a_print_add_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_add_form_A_fn_class)}; return nil }

var A_arbace_g2a_print_add_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_add_form_A_invoke, New: A_arbace_g2a_print_add_form_A_new, Get: A_arbace_g2a_print_add_form_A_get}

var A_arbace_g2a_print_add_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$add_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "add_form", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_add_form_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_add_form_A_class.Info(); i.IsInstance = A_arbace_g2a_print_add_form_A_InstanceOf; i.Init = A_arbace_g2a_print_add_form_A_Init; i.Table = A_arbace_g2a_print_add_form_A_members; jrt.RegisterGoType(A_arbace_g2a_print_add_form_A_class, reflect.TypeFor[A_arbace_g2a_print_add_form_A]()) }

func A_arbace_g2a_print_add_form_fn__1580000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_add_form_fn__1580000040_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_add_form_fn__1580000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_add_form_fn__1580000040_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_add_form_fn__1580000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_add_form_fn__1580000040_A_fn_class)}; return nil }

var A_arbace_g2a_print_add_form_fn__1580000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_add_form_fn__1580000040_A_invoke, New: A_arbace_g2a_print_add_form_fn__1580000040_A_new, Get: A_arbace_g2a_print_add_form_fn__1580000040_A_get}

var A_arbace_g2a_print_add_form_fn__1580000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$add_form$fn__1580000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_add_form_A_class, Simple: "fn__1580000040", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_add_form_fn__1580000040_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_add_form_fn__1580000040_A_class.Info(); i.IsInstance = A_arbace_g2a_print_add_form_fn__1580000040_A_InstanceOf; i.Init = A_arbace_g2a_print_add_form_fn__1580000040_A_Init; i.Table = A_arbace_g2a_print_add_form_fn__1580000040_A_members; jrt.RegisterGoType(A_arbace_g2a_print_add_form_fn__1580000040_A_class, reflect.TypeFor[A_arbace_g2a_print_add_form_fn__1580000040_A]()) }

func A_arbace_g2a_print_build_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_build_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_build_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_build_A_New()}; return nil }

func A_arbace_g2a_print_build_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_build_A_fn_class)}; return nil }

var A_arbace_g2a_print_build_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_build_A_invoke, New: A_arbace_g2a_print_build_A_new, Get: A_arbace_g2a_print_build_A_get}

var A_arbace_g2a_print_build_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$build", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "build", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_build_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_build_A_class.Info(); i.IsInstance = A_arbace_g2a_print_build_A_InstanceOf; i.Init = A_arbace_g2a_print_build_A_Init; i.Table = A_arbace_g2a_print_build_A_members; jrt.RegisterGoType(A_arbace_g2a_print_build_A_class, reflect.TypeFor[A_arbace_g2a_print_build_A]()) }

func A_arbace_g2a_print_build_env_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_build_env_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_build_env_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_build_env_A_New()}; return nil }

func A_arbace_g2a_print_build_env_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_build_env_A_fn_class)}; return nil }

var A_arbace_g2a_print_build_env_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_build_env_A_invoke, New: A_arbace_g2a_print_build_env_A_new, Get: A_arbace_g2a_print_build_env_A_get}

var A_arbace_g2a_print_build_env_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$build_env", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "build_env", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_build_env_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_build_env_A_class.Info(); i.IsInstance = A_arbace_g2a_print_build_env_A_InstanceOf; i.Init = A_arbace_g2a_print_build_env_A_Init; i.Table = A_arbace_g2a_print_build_env_A_members; jrt.RegisterGoType(A_arbace_g2a_print_build_env_A_class, reflect.TypeFor[A_arbace_g2a_print_build_env_A]()) }

func A_arbace_g2a_print_chunk_starts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_chunk_starts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_chunk_starts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_chunk_starts_A_New()}; return nil }

func A_arbace_g2a_print_chunk_starts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_chunk_starts_A_fn_class)}; return nil }

var A_arbace_g2a_print_chunk_starts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_chunk_starts_A_invoke, New: A_arbace_g2a_print_chunk_starts_A_new, Get: A_arbace_g2a_print_chunk_starts_A_get}

var A_arbace_g2a_print_chunk_starts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$chunk_starts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "chunk_starts", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_chunk_starts_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_chunk_starts_A_class.Info(); i.IsInstance = A_arbace_g2a_print_chunk_starts_A_InstanceOf; i.Init = A_arbace_g2a_print_chunk_starts_A_Init; i.Table = A_arbace_g2a_print_chunk_starts_A_members; jrt.RegisterGoType(A_arbace_g2a_print_chunk_starts_A_class, reflect.TypeFor[A_arbace_g2a_print_chunk_starts_A]()) }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_chunk_starts_fn__1580000117_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_chunk_starts_fn__1580000117_A_New_O_I(args[0], args[1].(int32))}; return nil }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_chunk_starts_fn__1580000117_A_fn_class)}; return nil }

var A_arbace_g2a_print_chunk_starts_fn__1580000117_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;I)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_chunk_starts_fn__1580000117_A_invoke, New: A_arbace_g2a_print_chunk_starts_fn__1580000117_A_new, Get: A_arbace_g2a_print_chunk_starts_fn__1580000117_A_get}

var A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$chunk_starts$fn__1580000117", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_chunk_starts_A_class, Simple: "fn__1580000117", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_chunk_starts_fn__1580000117_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class.Info(); i.IsInstance = A_arbace_g2a_print_chunk_starts_fn__1580000117_A_InstanceOf; i.Init = A_arbace_g2a_print_chunk_starts_fn__1580000117_A_Init; i.Table = A_arbace_g2a_print_chunk_starts_fn__1580000117_A_members; jrt.RegisterGoType(A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class, reflect.TypeFor[A_arbace_g2a_print_chunk_starts_fn__1580000117_A]()) }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_fn_class)}; return nil }

var A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_invoke, New: A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_new, Get: A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_get}

var A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$chunk_starts$fn__1580000117$fn__1580000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class, Simple: "fn__1580000118", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_class.Info(); i.IsInstance = A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_InstanceOf; i.Init = A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_Init; i.Table = A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_members; jrt.RegisterGoType(A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_class, reflect.TypeFor[A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A]()) }

func A_arbace_g2a_print_collect_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_g2a_print_collect_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_collect_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_A_New()}; return nil }

func A_arbace_g2a_print_collect_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_A_invoke, New: A_arbace_g2a_print_collect_A_new, Get: A_arbace_g2a_print_collect_A_get}

var A_arbace_g2a_print_collect_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "collect", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_A_Init; i.Table = A_arbace_g2a_print_collect_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_collect_A_class, Simple: "walk__1580000054", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_collect_walk__1580000054_A_class, Simple: "fn__1580000059", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_New()}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_collect_walk__1580000054_A_class, Simple: "fn__1580000061", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_collect_walk__1580000054_A_class, Simple: "fn__1580000063", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000063$fn__1580000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class, Simple: "fn__1580000064", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_New()}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_collect_walk__1580000054_A_class, Simple: "fn__1580000067", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_collect_walk__1580000054_A_class, Simple: "fn__1580000069", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A]()) }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_invoke, New: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_new, Get: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_get}

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000069$fn__1580000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class, Simple: "fn__1580000070", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_Init; i.Table = A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A]()) }

func A_arbace_g2a_print_collect_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_forms_A_New()}; return nil }

func A_arbace_g2a_print_collect_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_forms_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_forms_A_invoke, New: A_arbace_g2a_print_collect_forms_A_new, Get: A_arbace_g2a_print_collect_forms_A_get}

var A_arbace_g2a_print_collect_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "collect_forms", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_forms_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_forms_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_forms_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_forms_A_Init; i.Table = A_arbace_g2a_print_collect_forms_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_forms_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_forms_A]()) }

func A_arbace_g2a_print_collect_forms_fn__1580000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_forms_fn__1580000048_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_forms_fn__1580000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_forms_fn__1580000048_A_New()}; return nil }

func A_arbace_g2a_print_collect_forms_fn__1580000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_forms_fn__1580000048_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_forms_fn__1580000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_forms_fn__1580000048_A_invoke, New: A_arbace_g2a_print_collect_forms_fn__1580000048_A_new, Get: A_arbace_g2a_print_collect_forms_fn__1580000048_A_get}

var A_arbace_g2a_print_collect_forms_fn__1580000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect_forms$fn__1580000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_collect_forms_A_class, Simple: "fn__1580000048", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_forms_fn__1580000048_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_forms_fn__1580000048_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_forms_fn__1580000048_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_forms_fn__1580000048_A_Init; i.Table = A_arbace_g2a_print_collect_forms_fn__1580000048_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_forms_fn__1580000048_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_forms_fn__1580000048_A]()) }

func A_arbace_g2a_print_collect_forms_fn__1580000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_collect_forms_fn__1580000050_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_collect_forms_fn__1580000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_collect_forms_fn__1580000050_A_New()}; return nil }

func A_arbace_g2a_print_collect_forms_fn__1580000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_collect_forms_fn__1580000050_A_fn_class)}; return nil }

var A_arbace_g2a_print_collect_forms_fn__1580000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_collect_forms_fn__1580000050_A_invoke, New: A_arbace_g2a_print_collect_forms_fn__1580000050_A_new, Get: A_arbace_g2a_print_collect_forms_fn__1580000050_A_get}

var A_arbace_g2a_print_collect_forms_fn__1580000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$collect_forms$fn__1580000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_collect_forms_A_class, Simple: "fn__1580000050", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_forms_fn__1580000050_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_collect_forms_fn__1580000050_A_class.Info(); i.IsInstance = A_arbace_g2a_print_collect_forms_fn__1580000050_A_InstanceOf; i.Init = A_arbace_g2a_print_collect_forms_fn__1580000050_A_Init; i.Table = A_arbace_g2a_print_collect_forms_fn__1580000050_A_members; jrt.RegisterGoType(A_arbace_g2a_print_collect_forms_fn__1580000050_A_class, reflect.TypeFor[A_arbace_g2a_print_collect_forms_fn__1580000050_A]()) }

func A_arbace_g2a_print_copy_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_copy_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_copy_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_copy_file_A_New()}; return nil }

func A_arbace_g2a_print_copy_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_copy_file_A_fn_class)}; return nil }

var A_arbace_g2a_print_copy_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_copy_file_A_invoke, New: A_arbace_g2a_print_copy_file_A_new, Get: A_arbace_g2a_print_copy_file_A_get}

var A_arbace_g2a_print_copy_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$copy_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "copy_file", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_file_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_copy_file_A_class.Info(); i.IsInstance = A_arbace_g2a_print_copy_file_A_InstanceOf; i.Init = A_arbace_g2a_print_copy_file_A_Init; i.Table = A_arbace_g2a_print_copy_file_A_members; jrt.RegisterGoType(A_arbace_g2a_print_copy_file_A_class, reflect.TypeFor[A_arbace_g2a_print_copy_file_A]()) }

func A_arbace_g2a_print_copy_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_copy_files_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_copy_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_copy_files_A_New()}; return nil }

func A_arbace_g2a_print_copy_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_copy_files_A_fn_class)}; return nil }

var A_arbace_g2a_print_copy_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_copy_files_A_invoke, New: A_arbace_g2a_print_copy_files_A_new, Get: A_arbace_g2a_print_copy_files_A_get}

var A_arbace_g2a_print_copy_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$copy_files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "copy_files", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_copy_files_A_class.Info(); i.IsInstance = A_arbace_g2a_print_copy_files_A_InstanceOf; i.Init = A_arbace_g2a_print_copy_files_A_Init; i.Table = A_arbace_g2a_print_copy_files_A_members; jrt.RegisterGoType(A_arbace_g2a_print_copy_files_A_class, reflect.TypeFor[A_arbace_g2a_print_copy_files_A]()) }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_fn_class)}; return nil }

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_invoke, New: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_new, Get: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_get}

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$copy_files$iter__1580000197__1580000201", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_copy_files_A_class, Simple: "iter__1580000197__1580000201", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class.Info(); i.IsInstance = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_InstanceOf; i.Init = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_Init; i.Table = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_members; jrt.RegisterGoType(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class, reflect.TypeFor[A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A]()) }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_fn_class)}; return nil }

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_invoke, New: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_new, Get: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_get}

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$copy_files$iter__1580000197__1580000201$fn__1580000202", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class, Simple: "fn__1580000202", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class.Info(); i.IsInstance = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_InstanceOf; i.Init = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_Init; i.Table = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_members; jrt.RegisterGoType(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class, reflect.TypeFor[A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A]()) }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_fn_class)}; return nil }

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_invoke, New: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_new, Get: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_get}

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$copy_files$iter__1580000197__1580000201$fn__1580000202$fn__1580000203", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class, Simple: "fn__1580000203", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_class.Info(); i.IsInstance = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_InstanceOf; i.Init = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_Init; i.Table = A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_members; jrt.RegisterGoType(A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_class, reflect.TypeFor[A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A]()) }

func A_arbace_g2a_print_decl_pre_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_decl_pre_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_decl_pre_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_decl_pre_A_New()}; return nil }

func A_arbace_g2a_print_decl_pre_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_decl_pre_A_fn_class)}; return nil }

var A_arbace_g2a_print_decl_pre_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_decl_pre_A_invoke, New: A_arbace_g2a_print_decl_pre_A_new, Get: A_arbace_g2a_print_decl_pre_A_get}

var A_arbace_g2a_print_decl_pre_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$decl_pre", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "decl_pre", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_decl_pre_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_decl_pre_A_class.Info(); i.IsInstance = A_arbace_g2a_print_decl_pre_A_InstanceOf; i.Init = A_arbace_g2a_print_decl_pre_A_Init; i.Table = A_arbace_g2a_print_decl_pre_A_members; jrt.RegisterGoType(A_arbace_g2a_print_decl_pre_A_class, reflect.TypeFor[A_arbace_g2a_print_decl_pre_A]()) }

func A_arbace_g2a_print_decl_sep_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_decl_sep_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_decl_sep_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_decl_sep_BANG__A_New()}; return nil }

func A_arbace_g2a_print_decl_sep_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_decl_sep_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_decl_sep_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_decl_sep_BANG__A_invoke, New: A_arbace_g2a_print_decl_sep_BANG__A_new, Get: A_arbace_g2a_print_decl_sep_BANG__A_get}

var A_arbace_g2a_print_decl_sep_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$decl_sep_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "decl_sep_BANG_", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_decl_sep_BANG__A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_decl_sep_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_decl_sep_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_decl_sep_BANG__A_Init; i.Table = A_arbace_g2a_print_decl_sep_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_decl_sep_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_decl_sep_BANG__A]()) }

func A_arbace_g2a_print_eval1580000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_eval1580000004_A_New()}; return nil }

var A_arbace_g2a_print_eval1580000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_eval1580000004_A_new}

var A_arbace_g2a_print_eval1580000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$eval1580000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_A_class, Simple: "eval1580000004", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000004_A"})

func init() { i := A_arbace_g2a_print_eval1580000004_A_class.Info(); i.IsInstance = A_arbace_g2a_print_eval1580000004_A_InstanceOf; i.Table = A_arbace_g2a_print_eval1580000004_A_members; jrt.RegisterGoType(A_arbace_g2a_print_eval1580000004_A_class, reflect.TypeFor[A_arbace_g2a_print_eval1580000004_A]()) }

func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_New()}; return nil }

func A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_fn_class)}; return nil }

var A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_invoke, New: A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_new, Get: A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_get}

var A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$eval1580000004$loading__1927001464__auto____1580000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_eval1580000004_A_class, Simple: "loading__1927001464__auto____1580000005", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_class.Info(); i.IsInstance = A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_InstanceOf; i.Init = A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_Init; i.Table = A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_members; jrt.RegisterGoType(A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_class, reflect.TypeFor[A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A]()) }

func A_arbace_g2a_print_eval1580000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_eval1580000008_A_New()}; return nil }

var A_arbace_g2a_print_eval1580000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_eval1580000008_A_new}

var A_arbace_g2a_print_eval1580000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$eval1580000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_A_class, Simple: "eval1580000008", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000008_A"})

func init() { i := A_arbace_g2a_print_eval1580000008_A_class.Info(); i.IsInstance = A_arbace_g2a_print_eval1580000008_A_InstanceOf; i.Table = A_arbace_g2a_print_eval1580000008_A_members; jrt.RegisterGoType(A_arbace_g2a_print_eval1580000008_A_class, reflect.TypeFor[A_arbace_g2a_print_eval1580000008_A]()) }

func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_eval1580000008_fn__1580000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_eval1580000008_fn__1580000009_A_New()}; return nil }

func A_arbace_g2a_print_eval1580000008_fn__1580000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_eval1580000008_fn__1580000009_A_fn_class)}; return nil }

var A_arbace_g2a_print_eval1580000008_fn__1580000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_eval1580000008_fn__1580000009_A_invoke, New: A_arbace_g2a_print_eval1580000008_fn__1580000009_A_new, Get: A_arbace_g2a_print_eval1580000008_fn__1580000009_A_get}

var A_arbace_g2a_print_eval1580000008_fn__1580000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$eval1580000008$fn__1580000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_eval1580000008_A_class, Simple: "fn__1580000009", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000008_fn__1580000009_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_eval1580000008_fn__1580000009_A_class.Info(); i.IsInstance = A_arbace_g2a_print_eval1580000008_fn__1580000009_A_InstanceOf; i.Init = A_arbace_g2a_print_eval1580000008_fn__1580000009_A_Init; i.Table = A_arbace_g2a_print_eval1580000008_fn__1580000009_A_members; jrt.RegisterGoType(A_arbace_g2a_print_eval1580000008_fn__1580000009_A_class, reflect.TypeFor[A_arbace_g2a_print_eval1580000008_fn__1580000009_A]()) }

func A_arbace_g2a_print_go_ns_aliases_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_go_ns_aliases_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_go_ns_aliases_A_New()}; return nil }

func A_arbace_g2a_print_go_ns_aliases_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_go_ns_aliases_A_fn_class)}; return nil }

var A_arbace_g2a_print_go_ns_aliases_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_go_ns_aliases_A_invoke, New: A_arbace_g2a_print_go_ns_aliases_A_new, Get: A_arbace_g2a_print_go_ns_aliases_A_get}

var A_arbace_g2a_print_go_ns_aliases_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$go_ns_aliases", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "go_ns_aliases", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_go_ns_aliases_A_class.Info(); i.IsInstance = A_arbace_g2a_print_go_ns_aliases_A_InstanceOf; i.Init = A_arbace_g2a_print_go_ns_aliases_A_Init; i.Table = A_arbace_g2a_print_go_ns_aliases_A_members; jrt.RegisterGoType(A_arbace_g2a_print_go_ns_aliases_A_class, reflect.TypeFor[A_arbace_g2a_print_go_ns_aliases_A]()) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_New()}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_fn_class)}; return nil }

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_invoke, New: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_new, Get: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_get}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_go_ns_aliases_A_class, Simple: "iter__1580000013__1580000019", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class.Info(); i.IsInstance = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_InstanceOf; i.Init = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_Init; i.Table = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_members; jrt.RegisterGoType(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class, reflect.TypeFor[A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A]()) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_fn_class)}; return nil }

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_invoke, New: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_new, Get: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_get}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class, Simple: "fn__1580000020", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class.Info(); i.IsInstance = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_InstanceOf; i.Init = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_Init; i.Table = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_members; jrt.RegisterGoType(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class, reflect.TypeFor[A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A]()) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_New()}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_fn_class)}; return nil }

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_invoke, New: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_new, Get: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_get}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class, Simple: "iter__1580000015__1580000021", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class.Info(); i.IsInstance = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_InstanceOf; i.Init = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_Init; i.Table = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_members; jrt.RegisterGoType(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class, reflect.TypeFor[A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A]()) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_fn_class)}; return nil }

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_invoke, New: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_new, Get: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_get}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021$fn__1580000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class, Simple: "fn__1580000022", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class.Info(); i.IsInstance = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_InstanceOf; i.Init = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_Init; i.Table = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_members; jrt.RegisterGoType(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class, reflect.TypeFor[A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A]()) }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_fn_class)}; return nil }

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_invoke, New: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_new, Get: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_get}

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021$fn__1580000022$fn__1580000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class, Simple: "fn__1580000023", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_class.Info(); i.IsInstance = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_InstanceOf; i.Init = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_Init; i.Table = A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_members; jrt.RegisterGoType(A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_class, reflect.TypeFor[A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A]()) }

func A_arbace_g2a_print_gofmt_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_gofmt_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_gofmt_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_gofmt_file_A_New()}; return nil }

func A_arbace_g2a_print_gofmt_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_gofmt_file_A_fn_class)}; return nil }

var A_arbace_g2a_print_gofmt_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_gofmt_file_A_invoke, New: A_arbace_g2a_print_gofmt_file_A_new, Get: A_arbace_g2a_print_gofmt_file_A_get}

var A_arbace_g2a_print_gofmt_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$gofmt_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "gofmt_file", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_gofmt_file_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_gofmt_file_A_class.Info(); i.IsInstance = A_arbace_g2a_print_gofmt_file_A_InstanceOf; i.Init = A_arbace_g2a_print_gofmt_file_A_Init; i.Table = A_arbace_g2a_print_gofmt_file_A_members; jrt.RegisterGoType(A_arbace_g2a_print_gofmt_file_A_class, reflect.TypeFor[A_arbace_g2a_print_gofmt_file_A]()) }

func A_arbace_g2a_print_import_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_import_spec_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_import_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_import_spec_A_New()}; return nil }

func A_arbace_g2a_print_import_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_import_spec_A_fn_class)}; return nil }

var A_arbace_g2a_print_import_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_import_spec_A_invoke, New: A_arbace_g2a_print_import_spec_A_new, Get: A_arbace_g2a_print_import_spec_A_get}

var A_arbace_g2a_print_import_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$import_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "import_spec", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_import_spec_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_import_spec_A_class.Info(); i.IsInstance = A_arbace_g2a_print_import_spec_A_InstanceOf; i.Init = A_arbace_g2a_print_import_spec_A_Init; i.Table = A_arbace_g2a_print_import_spec_A_members; jrt.RegisterGoType(A_arbace_g2a_print_import_spec_A_class, reflect.TypeFor[A_arbace_g2a_print_import_spec_A]()) }

func A_arbace_g2a_print_json_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_json_string_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_json_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_json_string_A_New()}; return nil }

func A_arbace_g2a_print_json_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_json_string_A_fn_class)}; return nil }

var A_arbace_g2a_print_json_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_json_string_A_invoke, New: A_arbace_g2a_print_json_string_A_new, Get: A_arbace_g2a_print_json_string_A_get}

var A_arbace_g2a_print_json_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$json_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "json_string", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_json_string_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_json_string_A_class.Info(); i.IsInstance = A_arbace_g2a_print_json_string_A_InstanceOf; i.Init = A_arbace_g2a_print_json_string_A_Init; i.Table = A_arbace_g2a_print_json_string_A_members; jrt.RegisterGoType(A_arbace_g2a_print_json_string_A_class, reflect.TypeFor[A_arbace_g2a_print_json_string_A]()) }

func A_arbace_g2a_print_new_package_state_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_new_package_state_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_new_package_state_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_new_package_state_A_New()}; return nil }

func A_arbace_g2a_print_new_package_state_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_new_package_state_A_fn_class)}; return nil }

var A_arbace_g2a_print_new_package_state_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_new_package_state_A_invoke, New: A_arbace_g2a_print_new_package_state_A_new, Get: A_arbace_g2a_print_new_package_state_A_get}

var A_arbace_g2a_print_new_package_state_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$new_package_state", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "new_package_state", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_new_package_state_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_new_package_state_A_class.Info(); i.IsInstance = A_arbace_g2a_print_new_package_state_A_InstanceOf; i.Init = A_arbace_g2a_print_new_package_state_A_Init; i.Table = A_arbace_g2a_print_new_package_state_A_members; jrt.RegisterGoType(A_arbace_g2a_print_new_package_state_A_class, reflect.TypeFor[A_arbace_g2a_print_new_package_state_A]()) }

func A_arbace_g2a_print_next_target_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_next_target_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_next_target_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_next_target_A_New()}; return nil }

func A_arbace_g2a_print_next_target_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_next_target_A_fn_class)}; return nil }

var A_arbace_g2a_print_next_target_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_next_target_A_invoke, New: A_arbace_g2a_print_next_target_A_new, Get: A_arbace_g2a_print_next_target_A_get}

var A_arbace_g2a_print_next_target_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$next_target", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "next_target", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_next_target_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_next_target_A_class.Info(); i.IsInstance = A_arbace_g2a_print_next_target_A_InstanceOf; i.Init = A_arbace_g2a_print_next_target_A_Init; i.Table = A_arbace_g2a_print_next_target_A_members; jrt.RegisterGoType(A_arbace_g2a_print_next_target_A_class, reflect.TypeFor[A_arbace_g2a_print_next_target_A]()) }

func A_arbace_g2a_print_next_target_fn__1580000108_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_next_target_fn__1580000108_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_next_target_fn__1580000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_next_target_fn__1580000108_A_New()}; return nil }

func A_arbace_g2a_print_next_target_fn__1580000108_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_next_target_fn__1580000108_A_fn_class)}; return nil }

var A_arbace_g2a_print_next_target_fn__1580000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_next_target_fn__1580000108_A_invoke, New: A_arbace_g2a_print_next_target_fn__1580000108_A_new, Get: A_arbace_g2a_print_next_target_fn__1580000108_A_get}

var A_arbace_g2a_print_next_target_fn__1580000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$next_target$fn__1580000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_next_target_A_class, Simple: "fn__1580000108", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_next_target_fn__1580000108_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_next_target_fn__1580000108_A_class.Info(); i.IsInstance = A_arbace_g2a_print_next_target_fn__1580000108_A_InstanceOf; i.Init = A_arbace_g2a_print_next_target_fn__1580000108_A_Init; i.Table = A_arbace_g2a_print_next_target_fn__1580000108_A_members; jrt.RegisterGoType(A_arbace_g2a_print_next_target_fn__1580000108_A_class, reflect.TypeFor[A_arbace_g2a_print_next_target_fn__1580000108_A]()) }

func A_arbace_g2a_print_one_line_func_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_one_line_func_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_one_line_func_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_one_line_func_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_one_line_func_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_one_line_func_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_one_line_func_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_one_line_func_QMARK__A_invoke, New: A_arbace_g2a_print_one_line_func_QMARK__A_new, Get: A_arbace_g2a_print_one_line_func_QMARK__A_get}

var A_arbace_g2a_print_one_line_func_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$one_line_func_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "one_line_func_QMARK_", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_one_line_func_QMARK__A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_one_line_func_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_one_line_func_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_one_line_func_QMARK__A_Init; i.Table = A_arbace_g2a_print_one_line_func_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_one_line_func_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_one_line_func_QMARK__A]()) }

func A_arbace_g2a_print_print_decl_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_g2a_print_print_decl_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_print_decl_BANG__A_New()}; return nil }

func A_arbace_g2a_print_print_decl_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_print_decl_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_print_decl_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_print_decl_BANG__A_invoke, New: A_arbace_g2a_print_print_decl_BANG__A_new, Get: A_arbace_g2a_print_print_decl_BANG__A_get}

var A_arbace_g2a_print_print_decl_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$print_decl_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "print_decl_BANG_", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_decl_BANG__A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_print_decl_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_print_decl_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_print_decl_BANG__A_Init; i.Table = A_arbace_g2a_print_print_decl_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_print_decl_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_print_decl_BANG__A]()) }

func A_arbace_g2a_print_print_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_print_file_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_print_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_print_file_A_New()}; return nil }

func A_arbace_g2a_print_print_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_print_file_A_fn_class)}; return nil }

var A_arbace_g2a_print_print_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_print_file_A_invoke, New: A_arbace_g2a_print_print_file_A_new, Get: A_arbace_g2a_print_print_file_A_get}

var A_arbace_g2a_print_print_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$print_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "print_file", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_file_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_print_file_A_class.Info(); i.IsInstance = A_arbace_g2a_print_print_file_A_InstanceOf; i.Init = A_arbace_g2a_print_print_file_A_Init; i.Table = A_arbace_g2a_print_print_file_A_members; jrt.RegisterGoType(A_arbace_g2a_print_print_file_A_class, reflect.TypeFor[A_arbace_g2a_print_print_file_A]()) }

func A_arbace_g2a_print_print_file_first_line__1580000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_print_file_first_line__1580000137_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_print_file_first_line__1580000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_print_file_first_line__1580000137_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_print_file_first_line__1580000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_print_file_first_line__1580000137_A_fn_class)}; return nil }

var A_arbace_g2a_print_print_file_first_line__1580000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_print_file_first_line__1580000137_A_invoke, New: A_arbace_g2a_print_print_file_first_line__1580000137_A_new, Get: A_arbace_g2a_print_print_file_first_line__1580000137_A_get}

var A_arbace_g2a_print_print_file_first_line__1580000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$print_file$first_line__1580000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_print_file_A_class, Simple: "first_line__1580000137", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_file_first_line__1580000137_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_print_file_first_line__1580000137_A_class.Info(); i.IsInstance = A_arbace_g2a_print_print_file_first_line__1580000137_A_InstanceOf; i.Init = A_arbace_g2a_print_print_file_first_line__1580000137_A_Init; i.Table = A_arbace_g2a_print_print_file_first_line__1580000137_A_members; jrt.RegisterGoType(A_arbace_g2a_print_print_file_first_line__1580000137_A_class, reflect.TypeFor[A_arbace_g2a_print_print_file_first_line__1580000137_A]()) }

func A_arbace_g2a_print_print_file_fn__1580000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_print_file_fn__1580000140_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_print_file_fn__1580000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_print_file_fn__1580000140_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_print_file_fn__1580000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_print_file_fn__1580000140_A_fn_class)}; return nil }

var A_arbace_g2a_print_print_file_fn__1580000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_print_file_fn__1580000140_A_invoke, New: A_arbace_g2a_print_print_file_fn__1580000140_A_new, Get: A_arbace_g2a_print_print_file_fn__1580000140_A_get}

var A_arbace_g2a_print_print_file_fn__1580000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$print_file$fn__1580000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_print_file_A_class, Simple: "fn__1580000140", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_file_fn__1580000140_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_print_file_fn__1580000140_A_class.Info(); i.IsInstance = A_arbace_g2a_print_print_file_fn__1580000140_A_InstanceOf; i.Init = A_arbace_g2a_print_print_file_fn__1580000140_A_Init; i.Table = A_arbace_g2a_print_print_file_fn__1580000140_A_members; jrt.RegisterGoType(A_arbace_g2a_print_print_file_fn__1580000140_A_class, reflect.TypeFor[A_arbace_g2a_print_print_file_fn__1580000140_A]()) }

func A_arbace_g2a_print_print_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_print_forms_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_print_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_print_forms_A_New()}; return nil }

func A_arbace_g2a_print_print_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_print_forms_A_fn_class)}; return nil }

var A_arbace_g2a_print_print_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_print_forms_A_invoke, New: A_arbace_g2a_print_print_forms_A_new, Get: A_arbace_g2a_print_print_forms_A_get}

var A_arbace_g2a_print_print_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$print_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "print_forms", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_forms_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_print_forms_A_class.Info(); i.IsInstance = A_arbace_g2a_print_print_forms_A_InstanceOf; i.Init = A_arbace_g2a_print_print_forms_A_Init; i.Table = A_arbace_g2a_print_print_forms_A_members; jrt.RegisterGoType(A_arbace_g2a_print_print_forms_A_class, reflect.TypeFor[A_arbace_g2a_print_print_forms_A]()) }

func A_arbace_g2a_print_print_forms_fn__1580000174_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_print_forms_fn__1580000174_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_print_forms_fn__1580000174_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_print_forms_fn__1580000174_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_print_forms_fn__1580000174_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_print_forms_fn__1580000174_A_fn_class)}; return nil }

var A_arbace_g2a_print_print_forms_fn__1580000174_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_print_forms_fn__1580000174_A_invoke, New: A_arbace_g2a_print_print_forms_fn__1580000174_A_new, Get: A_arbace_g2a_print_print_forms_fn__1580000174_A_get}

var A_arbace_g2a_print_print_forms_fn__1580000174_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$print_forms$fn__1580000174", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_print_forms_A_class, Simple: "fn__1580000174", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_forms_fn__1580000174_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_print_forms_fn__1580000174_A_class.Info(); i.IsInstance = A_arbace_g2a_print_print_forms_fn__1580000174_A_InstanceOf; i.Init = A_arbace_g2a_print_print_forms_fn__1580000174_A_Init; i.Table = A_arbace_g2a_print_print_forms_fn__1580000174_A_members; jrt.RegisterGoType(A_arbace_g2a_print_print_forms_fn__1580000174_A_class, reflect.TypeFor[A_arbace_g2a_print_print_forms_fn__1580000174_A]()) }

func A_arbace_g2a_print_print_package_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_print_package_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_print_package_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_print_package_A_New()}; return nil }

func A_arbace_g2a_print_print_package_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_print_package_A_fn_class)}; return nil }

var A_arbace_g2a_print_print_package_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_print_package_A_invoke, New: A_arbace_g2a_print_print_package_A_new, Get: A_arbace_g2a_print_print_package_A_get}

var A_arbace_g2a_print_print_package_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$print_package", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "print_package", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_package_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_print_package_A_class.Info(); i.IsInstance = A_arbace_g2a_print_print_package_A_InstanceOf; i.Init = A_arbace_g2a_print_print_package_A_Init; i.Table = A_arbace_g2a_print_print_package_A_members; jrt.RegisterGoType(A_arbace_g2a_print_print_package_A_class, reflect.TypeFor[A_arbace_g2a_print_print_package_A]()) }

func A_arbace_g2a_print_read_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_read_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_read_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_read_forms_A_New()}; return nil }

func A_arbace_g2a_print_read_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_read_forms_A_fn_class)}; return nil }

var A_arbace_g2a_print_read_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_read_forms_A_invoke, New: A_arbace_g2a_print_read_forms_A_new, Get: A_arbace_g2a_print_read_forms_A_get}

var A_arbace_g2a_print_read_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$read_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "read_forms", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_read_forms_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_read_forms_A_class.Info(); i.IsInstance = A_arbace_g2a_print_read_forms_A_InstanceOf; i.Init = A_arbace_g2a_print_read_forms_A_Init; i.Table = A_arbace_g2a_print_read_forms_A_members; jrt.RegisterGoType(A_arbace_g2a_print_read_forms_A_class, reflect.TypeFor[A_arbace_g2a_print_read_forms_A]()) }

func A_arbace_g2a_print_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_run_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_run_A_New()}; return nil }

func A_arbace_g2a_print_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_run_A_fn_class)}; return nil }

var A_arbace_g2a_print_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_run_A_invoke, New: A_arbace_g2a_print_run_A_new, Get: A_arbace_g2a_print_run_A_get}

var A_arbace_g2a_print_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "run", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_run_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_run_A_class.Info(); i.IsInstance = A_arbace_g2a_print_run_A_InstanceOf; i.Init = A_arbace_g2a_print_run_A_Init; i.Table = A_arbace_g2a_print_run_A_members; jrt.RegisterGoType(A_arbace_g2a_print_run_A_class, reflect.TypeFor[A_arbace_g2a_print_run_A]()) }

func A_arbace_g2a_print_sha256_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_sha256_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_sha256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_sha256_A_New()}; return nil }

func A_arbace_g2a_print_sha256_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_sha256_A_fn_class)}; return nil }

var A_arbace_g2a_print_sha256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_sha256_A_invoke, New: A_arbace_g2a_print_sha256_A_new, Get: A_arbace_g2a_print_sha256_A_get}

var A_arbace_g2a_print_sha256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$sha256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "sha256", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_sha256_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_sha256_A_class.Info(); i.IsInstance = A_arbace_g2a_print_sha256_A_InstanceOf; i.Init = A_arbace_g2a_print_sha256_A_Init; i.Table = A_arbace_g2a_print_sha256_A_members; jrt.RegisterGoType(A_arbace_g2a_print_sha256_A_class, reflect.TypeFor[A_arbace_g2a_print_sha256_A]()) }

func A_arbace_g2a_print_sha256_fn__1580000178_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_sha256_fn__1580000178_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_sha256_fn__1580000178_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_sha256_fn__1580000178_A_New()}; return nil }

func A_arbace_g2a_print_sha256_fn__1580000178_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_sha256_fn__1580000178_A_fn_class)}; return nil }

var A_arbace_g2a_print_sha256_fn__1580000178_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_sha256_fn__1580000178_A_invoke, New: A_arbace_g2a_print_sha256_fn__1580000178_A_new, Get: A_arbace_g2a_print_sha256_fn__1580000178_A_get}

var A_arbace_g2a_print_sha256_fn__1580000178_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$sha256$fn__1580000178", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_sha256_A_class, Simple: "fn__1580000178", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_sha256_fn__1580000178_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_sha256_fn__1580000178_A_class.Info(); i.IsInstance = A_arbace_g2a_print_sha256_fn__1580000178_A_InstanceOf; i.Init = A_arbace_g2a_print_sha256_fn__1580000178_A_Init; i.Table = A_arbace_g2a_print_sha256_fn__1580000178_A_members; jrt.RegisterGoType(A_arbace_g2a_print_sha256_fn__1580000178_A_class, reflect.TypeFor[A_arbace_g2a_print_sha256_fn__1580000178_A]()) }

func A_arbace_g2a_print_write_import_decl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_write_import_decl_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_write_import_decl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_write_import_decl_A_New()}; return nil }

func A_arbace_g2a_print_write_import_decl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_write_import_decl_A_fn_class)}; return nil }

var A_arbace_g2a_print_write_import_decl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_write_import_decl_A_invoke, New: A_arbace_g2a_print_write_import_decl_A_new, Get: A_arbace_g2a_print_write_import_decl_A_get}

var A_arbace_g2a_print_write_import_decl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$write_import_decl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "write_import_decl", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_write_import_decl_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_write_import_decl_A_class.Info(); i.IsInstance = A_arbace_g2a_print_write_import_decl_A_InstanceOf; i.Init = A_arbace_g2a_print_write_import_decl_A_Init; i.Table = A_arbace_g2a_print_write_import_decl_A_members; jrt.RegisterGoType(A_arbace_g2a_print_write_import_decl_A_class, reflect.TypeFor[A_arbace_g2a_print_write_import_decl_A]()) }

func A_arbace_g2a_print_write_imports_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_write_imports_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_write_imports_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_write_imports_A_New()}; return nil }

func A_arbace_g2a_print_write_imports_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_write_imports_A_fn_class)}; return nil }

var A_arbace_g2a_print_write_imports_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_write_imports_A_invoke, New: A_arbace_g2a_print_write_imports_A_new, Get: A_arbace_g2a_print_write_imports_A_get}

var A_arbace_g2a_print_write_imports_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$write_imports", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_A_class, Simple: "write_imports", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_write_imports_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_write_imports_A_class.Info(); i.IsInstance = A_arbace_g2a_print_write_imports_A_InstanceOf; i.Init = A_arbace_g2a_print_write_imports_A_Init; i.Table = A_arbace_g2a_print_write_imports_A_members; jrt.RegisterGoType(A_arbace_g2a_print_write_imports_A_class, reflect.TypeFor[A_arbace_g2a_print_write_imports_A]()) }

func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_New()}; return nil }

func A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_fn_class)}; return nil }

var A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_invoke, New: A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_new, Get: A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_get}

var A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$write_imports$directive_QMARK___1580000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_write_imports_A_class, Simple: "directive_QMARK___1580000091", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_class.Info(); i.IsInstance = A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_InstanceOf; i.Init = A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_Init; i.Table = A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_members; jrt.RegisterGoType(A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_class, reflect.TypeFor[A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A]()) }

func A_arbace_g2a_print__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_print__init_A_Load__O(); case 1: return A_arbace_g2a_print__init_A_Unit0__O(); case 2: return A_arbace_g2a_print__init_A_Unit1__O(); case 3: return A_arbace_g2a_print__init_A_Unit10__O(); case 4: return A_arbace_g2a_print__init_A_Unit11__O(); case 5: return A_arbace_g2a_print__init_A_Unit12__O(); case 6: return A_arbace_g2a_print__init_A_Unit13__O(); case 7: return A_arbace_g2a_print__init_A_Unit14__O(); case 8: return A_arbace_g2a_print__init_A_Unit15__O(); case 9: return A_arbace_g2a_print__init_A_Unit16__O(); case 10: return A_arbace_g2a_print__init_A_Unit17__O(); case 11: return A_arbace_g2a_print__init_A_Unit18__O(); case 12: return A_arbace_g2a_print__init_A_Unit19__O(); case 13: return A_arbace_g2a_print__init_A_Unit2__O(); case 14: return A_arbace_g2a_print__init_A_Unit20__O(); case 15: return A_arbace_g2a_print__init_A_Unit21__O(); case 16: return A_arbace_g2a_print__init_A_Unit22__O(); case 17: return A_arbace_g2a_print__init_A_Unit23__O(); case 18: return A_arbace_g2a_print__init_A_Unit24__O(); case 19: return A_arbace_g2a_print__init_A_Unit25__O(); case 20: return A_arbace_g2a_print__init_A_Unit26__O(); case 21: return A_arbace_g2a_print__init_A_Unit27__O(); case 22: return A_arbace_g2a_print__init_A_Unit28__O(); case 23: return A_arbace_g2a_print__init_A_Unit29__O(); case 24: return A_arbace_g2a_print__init_A_Unit3__O(); case 25: return A_arbace_g2a_print__init_A_Unit30__O(); case 26: return A_arbace_g2a_print__init_A_Unit31__O(); case 27: return A_arbace_g2a_print__init_A_Unit32__O(); case 28: return A_arbace_g2a_print__init_A_Unit4__O(); case 29: return A_arbace_g2a_print__init_A_Unit5__O(); case 30: return A_arbace_g2a_print__init_A_Unit6__O(); case 31: return A_arbace_g2a_print__init_A_Unit7__O(); case 32: return A_arbace_g2a_print__init_A_Unit8__O(); case 33: return A_arbace_g2a_print__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_print__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print__init_A_New()}; return nil }

var A_arbace_g2a_print__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_print__init_A_invoke, New: A_arbace_g2a_print__init_A_new}

var A_arbace_g2a_print__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print__init_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print__init_A_class.Info(); i.IsInstance = A_arbace_g2a_print__init_A_InstanceOf; i.Init = A_arbace_g2a_print__init_A_Init; i.Table = A_arbace_g2a_print__init_A_members; jrt.RegisterGoType(A_arbace_g2a_print__init_A_class, reflect.TypeFor[A_arbace_g2a_print__init_A]()) }
