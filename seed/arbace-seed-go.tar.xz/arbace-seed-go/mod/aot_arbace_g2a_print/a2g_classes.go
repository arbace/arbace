//line a2g_classes.ae:1
package aot_arbace_g2a_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_g2a_print__main_A_class, Name: "arbace.g2a.print$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print__main_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_add_form_A_class, Name: "arbace.g2a.print$add_form", Modifiers: 25, Simple: "add_form", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_add_form_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_add_form_fn__1580000040_A_class, Name: "arbace.g2a.print$add_form$fn__1580000040", Modifiers: 25, Simple: "fn__1580000040", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_add_form_fn__1580000040_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_add_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_build_A_class, Name: "arbace.g2a.print$build", Modifiers: 25, Simple: "build", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_build_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_build_env_A_class, Name: "arbace.g2a.print$build_env", Modifiers: 25, Simple: "build_env", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_build_env_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_chunk_starts_A_class, Name: "arbace.g2a.print$chunk_starts", Modifiers: 25, Simple: "chunk_starts", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_chunk_starts_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class, Name: "arbace.g2a.print$chunk_starts$fn__1580000117", Modifiers: 25, Simple: "fn__1580000117", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_chunk_starts_fn__1580000117_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_chunk_starts_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_class, Name: "arbace.g2a.print$chunk_starts$fn__1580000117$fn__1580000118", Modifiers: 25, Simple: "fn__1580000118", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_A_class, Name: "arbace.g2a.print$collect", Modifiers: 25, Simple: "collect", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_A_class, Name: "arbace.g2a.print$collect$walk__1580000054", Modifiers: 25, Simple: "walk__1580000054", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_class, Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000059", Modifiers: 25, Simple: "fn__1580000059", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_walk__1580000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_class, Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000061", Modifiers: 25, Simple: "fn__1580000061", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_walk__1580000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class, Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000063", Modifiers: 25, Simple: "fn__1580000063", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_walk__1580000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_class, Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000063$fn__1580000064", Modifiers: 25, Simple: "fn__1580000064", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_class, Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000067", Modifiers: 25, Simple: "fn__1580000067", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_walk__1580000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class, Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000069", Modifiers: 25, Simple: "fn__1580000069", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_walk__1580000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_class, Name: "arbace.g2a.print$collect$walk__1580000054$fn__1580000069$fn__1580000070", Modifiers: 25, Simple: "fn__1580000070", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_forms_A_class, Name: "arbace.g2a.print$collect_forms", Modifiers: 25, Simple: "collect_forms", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_forms_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_forms_fn__1580000048_A_class, Name: "arbace.g2a.print$collect_forms$fn__1580000048", Modifiers: 25, Simple: "fn__1580000048", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_forms_fn__1580000048_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_forms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_collect_forms_fn__1580000050_A_class, Name: "arbace.g2a.print$collect_forms$fn__1580000050", Modifiers: 25, Simple: "fn__1580000050", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_collect_forms_fn__1580000050_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_collect_forms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_copy_file_A_class, Name: "arbace.g2a.print$copy_file", Modifiers: 25, Simple: "copy_file", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_file_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_copy_files_A_class, Name: "arbace.g2a.print$copy_files", Modifiers: 25, Simple: "copy_files", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class, Name: "arbace.g2a.print$copy_files$iter__1580000197__1580000201", Modifiers: 25, Simple: "iter__1580000197__1580000201", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_copy_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class, Name: "arbace.g2a.print$copy_files$iter__1580000197__1580000201$fn__1580000202", Modifiers: 25, Simple: "fn__1580000202", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_class, Name: "arbace.g2a.print$copy_files$iter__1580000197__1580000201$fn__1580000202$fn__1580000203", Modifiers: 25, Simple: "fn__1580000203", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_decl_pre_A_class, Name: "arbace.g2a.print$decl_pre", Modifiers: 25, Simple: "decl_pre", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_decl_pre_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_decl_sep_BANG__A_class, Name: "arbace.g2a.print$decl_sep_BANG_", Modifiers: 25, Simple: "decl_sep_BANG_", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_decl_sep_BANG__A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_class, Name: "arbace.g2a.print$eval1580000004$loading__1927001464__auto____1580000005", Modifiers: 25, Simple: "loading__1927001464__auto____1580000005", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_eval1580000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_eval1580000008_fn__1580000009_A_class, Name: "arbace.g2a.print$eval1580000008$fn__1580000009", Modifiers: 25, Simple: "fn__1580000009", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000008_fn__1580000009_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_eval1580000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_go_ns_aliases_A_class, Name: "arbace.g2a.print$go_ns_aliases", Modifiers: 25, Simple: "go_ns_aliases", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class, Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019", Modifiers: 25, Simple: "iter__1580000013__1580000019", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_go_ns_aliases_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class, Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020", Modifiers: 25, Simple: "fn__1580000020", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class, Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021", Modifiers: 25, Simple: "iter__1580000015__1580000021", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class, Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021$fn__1580000022", Modifiers: 25, Simple: "fn__1580000022", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_class, Name: "arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021$fn__1580000022$fn__1580000023", Modifiers: 25, Simple: "fn__1580000023", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_gofmt_file_A_class, Name: "arbace.g2a.print$gofmt_file", Modifiers: 25, Simple: "gofmt_file", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_gofmt_file_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_import_spec_A_class, Name: "arbace.g2a.print$import_spec", Modifiers: 25, Simple: "import_spec", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_import_spec_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_json_string_A_class, Name: "arbace.g2a.print$json_string", Modifiers: 25, Simple: "json_string", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_json_string_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_new_package_state_A_class, Name: "arbace.g2a.print$new_package_state", Modifiers: 25, Simple: "new_package_state", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_new_package_state_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_next_target_A_class, Name: "arbace.g2a.print$next_target", Modifiers: 25, Simple: "next_target", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_next_target_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_next_target_fn__1580000108_A_class, Name: "arbace.g2a.print$next_target$fn__1580000108", Modifiers: 25, Simple: "fn__1580000108", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_next_target_fn__1580000108_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_next_target_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_one_line_func_QMARK__A_class, Name: "arbace.g2a.print$one_line_func_QMARK_", Modifiers: 25, Simple: "one_line_func_QMARK_", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_one_line_func_QMARK__A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_print_decl_BANG__A_class, Name: "arbace.g2a.print$print_decl_BANG_", Modifiers: 25, Simple: "print_decl_BANG_", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_decl_BANG__A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_print_file_A_class, Name: "arbace.g2a.print$print_file", Modifiers: 25, Simple: "print_file", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_file_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_print_file_first_line__1580000137_A_class, Name: "arbace.g2a.print$print_file$first_line__1580000137", Modifiers: 25, Simple: "first_line__1580000137", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_file_first_line__1580000137_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_print_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_print_file_fn__1580000140_A_class, Name: "arbace.g2a.print$print_file$fn__1580000140", Modifiers: 25, Simple: "fn__1580000140", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_file_fn__1580000140_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_print_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_print_forms_A_class, Name: "arbace.g2a.print$print_forms", Modifiers: 25, Simple: "print_forms", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_forms_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_print_forms_fn__1580000174_A_class, Name: "arbace.g2a.print$print_forms$fn__1580000174", Modifiers: 25, Simple: "fn__1580000174", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_forms_fn__1580000174_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_print_forms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_print_package_A_class, Name: "arbace.g2a.print$print_package", Modifiers: 25, Simple: "print_package", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_print_package_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_read_forms_A_class, Name: "arbace.g2a.print$read_forms", Modifiers: 25, Simple: "read_forms", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_read_forms_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_run_A_class, Name: "arbace.g2a.print$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_run_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_sha256_A_class, Name: "arbace.g2a.print$sha256", Modifiers: 25, Simple: "sha256", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_sha256_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_sha256_fn__1580000178_A_class, Name: "arbace.g2a.print$sha256$fn__1580000178", Modifiers: 25, Simple: "fn__1580000178", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_sha256_fn__1580000178_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_sha256_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_write_import_decl_A_class, Name: "arbace.g2a.print$write_import_decl", Modifiers: 25, Simple: "write_import_decl", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_write_import_decl_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_write_imports_A_class, Name: "arbace.g2a.print$write_imports", Modifiers: 25, Simple: "write_imports", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_write_imports_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_class, Name: "arbace.g2a.print$write_imports$directive_QMARK___1580000091", Modifiers: 25, Simple: "directive_QMARK___1580000091", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A", Source: "print.ae", Declaring: &A_arbace_g2a_print_write_imports_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_g2a_print_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_A_New()}; return nil }

var A_arbace_g2a_print_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_A_new}

var A_arbace_g2a_print_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_A"})

func init() { i := A_arbace_g2a_print_A_class.Info(); i.IsInstance = A_arbace_g2a_print_A_InstanceOf; i.Init = A_arbace_g2a_print_A_Init; i.Table = A_arbace_g2a_print_A_members }

var A_arbace_g2a_print__main_A_class *jrt.Class

var A_arbace_g2a_print_add_form_A_class *jrt.Class

var A_arbace_g2a_print_add_form_fn__1580000040_A_class *jrt.Class

var A_arbace_g2a_print_build_A_class *jrt.Class

var A_arbace_g2a_print_build_env_A_class *jrt.Class

var A_arbace_g2a_print_chunk_starts_A_class *jrt.Class

var A_arbace_g2a_print_chunk_starts_fn__1580000117_A_class *jrt.Class

var A_arbace_g2a_print_chunk_starts_fn__1580000117_fn__1580000118_A_class *jrt.Class

var A_arbace_g2a_print_collect_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000059_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000061_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000063_fn__1580000064_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000067_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_A_class *jrt.Class

var A_arbace_g2a_print_collect_walk__1580000054_fn__1580000069_fn__1580000070_A_class *jrt.Class

var A_arbace_g2a_print_collect_forms_A_class *jrt.Class

var A_arbace_g2a_print_collect_forms_fn__1580000048_A_class *jrt.Class

var A_arbace_g2a_print_collect_forms_fn__1580000050_A_class *jrt.Class

var A_arbace_g2a_print_copy_file_A_class *jrt.Class

var A_arbace_g2a_print_copy_files_A_class *jrt.Class

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_A_class *jrt.Class

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_A_class *jrt.Class

var A_arbace_g2a_print_copy_files_iter__1580000197__1580000201_fn__1580000202_fn__1580000203_A_class *jrt.Class

var A_arbace_g2a_print_decl_pre_A_class *jrt.Class

var A_arbace_g2a_print_decl_sep_BANG__A_class *jrt.Class

func A_arbace_g2a_print_eval1580000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_eval1580000004_A_New()}; return nil }

var A_arbace_g2a_print_eval1580000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_eval1580000004_A_new}

var A_arbace_g2a_print_eval1580000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$eval1580000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_A_class, Simple: "eval1580000004", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000004_A"})

func init() { i := A_arbace_g2a_print_eval1580000004_A_class.Info(); i.IsInstance = A_arbace_g2a_print_eval1580000004_A_InstanceOf; i.Table = A_arbace_g2a_print_eval1580000004_A_members }

var A_arbace_g2a_print_eval1580000004_loading__1927001464__auto____1580000005_A_class *jrt.Class

func A_arbace_g2a_print_eval1580000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_eval1580000008_A_New()}; return nil }

var A_arbace_g2a_print_eval1580000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_eval1580000008_A_new}

var A_arbace_g2a_print_eval1580000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print$eval1580000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_A_class, Simple: "eval1580000008", Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print_eval1580000008_A"})

func init() { i := A_arbace_g2a_print_eval1580000008_A_class.Info(); i.IsInstance = A_arbace_g2a_print_eval1580000008_A_InstanceOf; i.Table = A_arbace_g2a_print_eval1580000008_A_members }

var A_arbace_g2a_print_eval1580000008_fn__1580000009_A_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_A_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_A_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_A_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_A_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_A_class *jrt.Class

var A_arbace_g2a_print_go_ns_aliases_iter__1580000013__1580000019_fn__1580000020_iter__1580000015__1580000021_fn__1580000022_fn__1580000023_A_class *jrt.Class

var A_arbace_g2a_print_gofmt_file_A_class *jrt.Class

var A_arbace_g2a_print_import_spec_A_class *jrt.Class

var A_arbace_g2a_print_json_string_A_class *jrt.Class

var A_arbace_g2a_print_new_package_state_A_class *jrt.Class

var A_arbace_g2a_print_next_target_A_class *jrt.Class

var A_arbace_g2a_print_next_target_fn__1580000108_A_class *jrt.Class

var A_arbace_g2a_print_one_line_func_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_print_decl_BANG__A_class *jrt.Class

var A_arbace_g2a_print_print_file_A_class *jrt.Class

var A_arbace_g2a_print_print_file_first_line__1580000137_A_class *jrt.Class

var A_arbace_g2a_print_print_file_fn__1580000140_A_class *jrt.Class

var A_arbace_g2a_print_print_forms_A_class *jrt.Class

var A_arbace_g2a_print_print_forms_fn__1580000174_A_class *jrt.Class

var A_arbace_g2a_print_print_package_A_class *jrt.Class

var A_arbace_g2a_print_read_forms_A_class *jrt.Class

var A_arbace_g2a_print_run_A_class *jrt.Class

var A_arbace_g2a_print_sha256_A_class *jrt.Class

var A_arbace_g2a_print_sha256_fn__1580000178_A_class *jrt.Class

var A_arbace_g2a_print_write_import_decl_A_class *jrt.Class

var A_arbace_g2a_print_write_imports_A_class *jrt.Class

var A_arbace_g2a_print_write_imports_directive_QMARK___1580000091_A_class *jrt.Class

func A_arbace_g2a_print__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_print__init_A_Load__O()}; return nil }

func A_arbace_g2a_print__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print__init_A_New()}; return nil }

var A_arbace_g2a_print__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_print__init_A_invoke, New: A_arbace_g2a_print__init_A_new}

var A_arbace_g2a_print__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print.A_arbace_g2a_print__init_A", Source: "print.ae"})

func init() { i := A_arbace_g2a_print__init_A_class.Info(); i.IsInstance = A_arbace_g2a_print__init_A_InstanceOf; i.Init = A_arbace_g2a_print__init_A_Init; i.Table = A_arbace_g2a_print__init_A_members }
