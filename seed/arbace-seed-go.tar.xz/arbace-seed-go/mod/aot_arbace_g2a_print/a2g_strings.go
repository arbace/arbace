//line a2g_strings.ae:1
package aot_arbace_g2a_print

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.print-code")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("code")

var Lit_6 *jrt.String = jrt.Intern("arbace.g2a.print-emit")

var Lit_7 *jrt.String = jrt.Intern("e")

var Lit_8 *jrt.String = jrt.Intern("arbace.string")

var Lit_9 *jrt.String = jrt.Intern("str")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.g2a.print")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("g2a's printer: Go forms (doc/go/SPEC.md) to Go source, milestone G2\n  (doc/go/PRINTER-NOTES.md).\n\n  bin/g2a-print [OPTIONS] FORMS.ae OUTDIR\n    Reads the package file FORMS.ae (its ns, go/package and load forms, and the files it\n    loads; or one file holding go/file forms and declarations) with *read-eval* false and\n    writes one Go file per go/file into OUTDIR.\n    --layout lines|gofmt  lines (default when the forms carry lines): each form on its\n                          recorded line (§10.1, §12.3); gofmt: gofmt's layout, lines ignored\n    --no-line-directives  never write //line or /*line*/ directives for lines layout cannot\n                          reach\n    --src DIR             the original package directory: copies :other-files and\n                          :embed-files (hashes checked) into OUTDIR, and writes\n                          OUTDIR/overlay.json mapping DIR's Go files to the printed ones\n    --build               then compiles the package as §12.4 says: the toolchain of\n                          $G2A_GOROOT (default /root/tamago-go), the :config's environment,\n                          -trimpath, go build -overlay, in DIR\n    --gofmt               run each printed file through $G2A_GOROOT/bin/gofmt\n    --line-file           (layout lines) start each file with //line FORMS-FILE:1, so that\n                          gc's positions name the forms file and its lines (§12.3)\n\n  The library: print-package, print-forms (forms in memory to {name text}), print-file.")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("read")

var Lit_18 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_19 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_20 *jrt.String = jrt.Intern("hash-map")

var Lit_21 *jrt.String = jrt.Intern("*read-eval*")

var Lit_22 *jrt.String = jrt.Intern("into")

var Lit_23 *jrt.String = jrt.Intern("arbace.go")

var Lit_24 *jrt.String = jrt.Intern("go")

var Lit_25 *jrt.String = jrt.Intern("seq")

var Lit_26 *jrt.String = jrt.Intern("first")

var Lit_27 *jrt.String = jrt.Intern("seq?")

var Lit_28 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_29 *jrt.String = jrt.Intern("chunk-first")

var Lit_30 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_31 *jrt.String = jrt.Intern("vector?")

var Lit_32 *jrt.String = jrt.Intern("apply")

var Lit_33 *jrt.String = jrt.Intern("rest")

var Lit_34 *jrt.String = jrt.Intern("chunk-append")

var Lit_35 *jrt.String = jrt.Intern("name")

var Lit_36 *jrt.String = jrt.Intern("chunk-cons")

var Lit_37 *jrt.String = jrt.Intern("cons")

var Lit_38 *jrt.String = jrt.Intern("chunk")

var Lit_39 *jrt.String = jrt.Intern("chunk-rest")

var Lit_40 *jrt.String = jrt.Intern("concat")

var Lit_41 *jrt.String = jrt.Intern("op")

var Lit_42 *jrt.String = jrt.Intern("update")

var Lit_43 *jrt.String = jrt.Intern("next")

var Lit_44 *jrt.String = jrt.Intern("assoc")

var Lit_45 *jrt.String = jrt.Intern("starts-with?")

var Lit_46 *jrt.String = jrt.Intern("empty?")

var Lit_47 *jrt.String = jrt.Intern("ex-info")

var Lit_48 *jrt.String = jrt.Intern("else")

var Lit_49 *jrt.String = jrt.Intern("*go-ns*")

var Lit_50 *jrt.String = jrt.Intern("aliases")

var Lit_51 *jrt.String = jrt.Intern("go-ns-aliases")

var Lit_52 *jrt.String = jrt.Intern("package")

var Lit_53 *jrt.String = jrt.Intern("files")

var Lit_54 *jrt.String = jrt.Intern("file")

var Lit_55 *jrt.String = jrt.Intern("opts")

var Lit_56 *jrt.String = jrt.Intern("decls")

var Lit_57 *jrt.String = jrt.Intern("src")

var Lit_58 *jrt.String = jrt.Intern("*src*")

var Lit_59 *jrt.String = jrt.Intern("pr-str")

var Lit_60 *jrt.String = jrt.Intern("form")

var Lit_61 *jrt.String = jrt.Intern("pop")

var Lit_62 *jrt.String = jrt.Intern("peek")

var Lit_63 *jrt.String = jrt.Intern("volatile!")

var Lit_64 *jrt.String = jrt.Intern("new-package-state")

var Lit_65 *jrt.String = jrt.Intern("dissoc")

var Lit_66 *jrt.String = jrt.Intern("add-form")

var Lit_67 *jrt.String = jrt.Intern("path")

var Lit_68 *jrt.String = jrt.Intern("subs")

var Lit_69 *jrt.String = jrt.Intern("ns")

var Lit_70 *jrt.String = jrt.Intern("re-seq")

var Lit_71 *jrt.String = jrt.Intern("vreset!")

var Lit_72 *jrt.String = jrt.Intern("\\.")

var Lit_73 *jrt.String = jrt.Intern("second")

var Lit_74 *jrt.String = jrt.Intern("iterate")

var Lit_75 *jrt.String = jrt.Intern("collect")

var Lit_76 *jrt.String = jrt.Intern("read-forms")

var Lit_77 *jrt.String = jrt.Intern("alias")

var Lit_78 *jrt.String = jrt.Intern("_")

var Lit_79 *jrt.String = jrt.Intern(".")

var Lit_80 *jrt.String = jrt.Intern("tok")

var Lit_81 *jrt.String = jrt.Intern("sp")

var Lit_82 *jrt.String = jrt.Intern("arbace.g2a.print-text")

var Lit_83 *jrt.String = jrt.Intern("go-string")

var Lit_84 *jrt.String = jrt.Intern("nl")

var Lit_85 *jrt.String = jrt.Intern("import-spec")

var Lit_86 *jrt.String = jrt.Intern("split-with")

var Lit_87 *jrt.String = jrt.Intern("comment-line")

var Lit_88 *jrt.String = jrt.Intern("complement")

var Lit_89 *jrt.String = jrt.Intern("write-import-decl")

var Lit_90 *jrt.String = jrt.Intern("vec")

var Lit_91 *jrt.String = jrt.Intern("go/method")

var Lit_92 *jrt.String = jrt.Intern("go/func")

var Lit_93 *jrt.String = jrt.Intern("end")

var Lit_94 *jrt.String = jrt.Intern("parse-decl-head")

var Lit_95 *jrt.String = jrt.Intern("results")

var Lit_96 *jrt.String = jrt.Intern("nnext")

var Lit_97 *jrt.String = jrt.Intern("not")

var Lit_98 *jrt.String = jrt.Intern("extern")

var Lit_99 *jrt.String = jrt.Intern("decl-doc-and-directives")

var Lit_100 *jrt.String = jrt.Intern("pre-lines")

var Lit_101 *jrt.String = jrt.Intern("some")

var Lit_102 *jrt.String = jrt.Intern("lines?")

var Lit_103 *jrt.String = jrt.Intern("*p*")

var Lit_104 *jrt.String = jrt.Intern("line")

var Lit_105 *jrt.String = jrt.Intern("integer?")

var Lit_106 *jrt.String = jrt.Intern("decl-pre")

var Lit_107 *jrt.String = jrt.Intern("subvec")

var Lit_108 *jrt.String = jrt.Intern("one-line-func?")

var Lit_109 *jrt.String = jrt.Intern("cur-indent")

var Lit_110 *jrt.String = jrt.Intern("bol")

var Lit_111 *jrt.String = jrt.Intern("top-decl")

var Lit_112 *jrt.String = jrt.Intern("*next*")

var Lit_113 *jrt.String = jrt.Intern("next-target")

var Lit_114 *jrt.String = jrt.Intern("decl-sep!")

var Lit_115 *jrt.String = jrt.Intern("write-pre")

var Lit_116 *jrt.String = jrt.Intern("not=")

var Lit_117 *jrt.String = jrt.Intern("line-directives?")

var Lit_118 *jrt.String = jrt.Intern("line-directive-own")

var Lit_119 *jrt.String = jrt.Intern("chunk-min")

var Lit_120 *jrt.String = jrt.Intern("comp")

var Lit_121 *jrt.String = jrt.Intern("range")

var Lit_122 *jrt.String = jrt.Intern("map")

var Lit_123 *jrt.String = jrt.Intern("remove")

var Lit_124 *jrt.String = jrt.Intern("distinct")

var Lit_125 *jrt.String = jrt.Intern("filter")

var Lit_126 *jrt.String = jrt.Intern("nil?")

var Lit_127 *jrt.String = jrt.Intern("to-array")

var Lit_128 *jrt.String = jrt.Intern("layout")

var Lit_129 *jrt.String = jrt.Intern("line-file")

var Lit_130 *jrt.String = jrt.Intern("lines")

var Lit_131 *jrt.String = jrt.Intern("gofmt")

var Lit_132 *jrt.String = jrt.Intern("result")

var Lit_133 *jrt.String = jrt.Intern("new-state")

var Lit_134 *jrt.String = jrt.Intern("*explicit-groups*")

var Lit_135 *jrt.String = jrt.Intern("uses-grouped?")

var Lit_136 *jrt.String = jrt.Intern("set-line!")

var Lit_137 *jrt.String = jrt.Intern("write-doc")

var Lit_138 *jrt.String = jrt.Intern("write-imports")

var Lit_139 *jrt.String = jrt.Intern("chunk-starts")

var Lit_140 *jrt.String = jrt.Intern("pmap")

var Lit_141 *jrt.String = jrt.Intern("build")

var Lit_142 *jrt.String = jrt.Intern("directives")

var Lit_143 *jrt.String = jrt.Intern("imports")

var Lit_144 *jrt.String = jrt.Intern("print-decl!")

var Lit_145 *jrt.String = jrt.Intern("vector")

var Lit_146 *jrt.String = jrt.Intern("chunk-state")

var Lit_147 *jrt.String = jrt.Intern("start-at!")

var Lit_148 *jrt.String = jrt.Intern("join!")

var Lit_149 *jrt.String = jrt.Intern("sorted-map")

var Lit_150 *jrt.String = jrt.Intern("print-file")

var Lit_151 *jrt.String = jrt.Intern("format")

var Lit_152 *jrt.String = jrt.Intern("into-array")

var Lit_153 *jrt.String = jrt.Intern("java.nio.file.CopyOption")

var Lit_154 *jrt.String = jrt.Intern("replace")

var Lit_155 *jrt.String = jrt.Intern("spit")

var Lit_156 *jrt.String = jrt.Intern("other-files")

var Lit_157 *jrt.String = jrt.Intern("copy-file")

var Lit_158 *jrt.String = jrt.Intern("embed-files")

var Lit_159 *jrt.String = jrt.Intern("sha256")

var Lit_160 *jrt.String = jrt.Intern("join")

var Lit_161 *jrt.String = jrt.Intern("json-string")

var Lit_162 *jrt.String = jrt.Intern("cgo")

var Lit_163 *jrt.String = jrt.Intern("goos")

var Lit_164 *jrt.String = jrt.Intern("goarch")

var Lit_165 *jrt.String = jrt.Intern("goamd64")

var Lit_166 *jrt.String = jrt.Intern("goarm64")

var Lit_167 *jrt.String = jrt.Intern("some?")

var Lit_168 *jrt.String = jrt.Intern("goexperiment")

var Lit_169 *jrt.String = jrt.Intern("slurp")

var Lit_170 *jrt.String = jrt.Intern("config")

var Lit_171 *jrt.String = jrt.Intern("tags")

var Lit_172 *jrt.String = jrt.Intern("run")

var Lit_173 *jrt.String = jrt.Intern("build-env")

var Lit_174 *jrt.String = jrt.Intern("print-forms")

var Lit_175 *jrt.String = jrt.Intern("keys")

var Lit_176 *jrt.String = jrt.Intern("full")

var Lit_177 *jrt.String = jrt.Intern("positions")

var Lit_178 *jrt.String = jrt.Intern("print-package")

var Lit_179 *jrt.String = jrt.Intern("shutdown-agents")

var Lit_180 *jrt.String = jrt.Intern("keyword")

var Lit_181 *jrt.String = jrt.Intern("println")

var Lit_182 *jrt.String = jrt.Intern("gofmt-file")

var Lit_183 *jrt.String = jrt.Intern("copy-files")

var Lit_184 *jrt.String = jrt.Intern("print")

var Lit_185 *jrt.String = jrt.Intern("flush")

var Lit_186 *jrt.String = jrt.Intern("arbace.g2a.print$_main")

var Lit_187 *jrt.String = jrt.Intern("G2A_GOROOT")

var Lit_188 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_189 *jrt.String = jrt.Intern("--layout")

var Lit_190 *jrt.String = jrt.Intern("--src")

var Lit_191 *jrt.String = jrt.Intern("--build")

var Lit_192 *jrt.String = jrt.Intern("--gofmt")

var Lit_193 *jrt.String = jrt.Intern("--line-file")

var Lit_194 *jrt.String = jrt.Intern("--no-line-directives")

var Lit_195 *jrt.String = jrt.Intern("usage: bin/g2a-print [--layout lines|gofmt] [--no-line-directives] [--line-file] [--src DIR [--build]] [--gofmt] FORMS.ae OUTDIR")

var Lit_196 *jrt.String = jrt.Intern("/")

var Lit_197 *jrt.String = jrt.Intern("arbace.g2a.print$add_form")

var Lit_198 *jrt.String = jrt.Intern("in-ns")

var Lit_199 *jrt.String = jrt.Intern("load")

var Lit_200 *jrt.String = jrt.Intern("go/package")

var Lit_201 *jrt.String = jrt.Intern("go/file")

var Lit_202 *jrt.String = jrt.Intern("go/")

var Lit_203 *jrt.String = jrt.Intern("a declaration before any go/file: ")

var Lit_204 *jrt.String = jrt.Intern("not a Go forms top-level form: ")

var Lit_205 *jrt.String = jrt.Intern("arbace.g2a.print$add_form$fn__1580000040")

var Lit_206 *jrt.String = jrt.Intern("arbace.g2a.print$build")

var Lit_207 *jrt.String = jrt.Intern("/bin/go")

var Lit_208 *jrt.String = jrt.Intern("-trimpath")

var Lit_209 *jrt.String = jrt.Intern("-overlay")

var Lit_210 *jrt.String = jrt.Intern("overlay.json")

var Lit_211 *jrt.String = jrt.Intern("-tags")

var Lit_212 *jrt.String = jrt.Intern(",")

var Lit_213 *jrt.String = jrt.Intern("arbace.g2a.print$build_env")

var Lit_214 *jrt.String = jrt.Intern("GOROOT")

var Lit_215 *jrt.String = jrt.Intern("GOTOOLCHAIN")

var Lit_216 *jrt.String = jrt.Intern("local")

var Lit_217 *jrt.String = jrt.Intern("GOFLAGS")

var Lit_218 *jrt.String = jrt.Intern("")

var Lit_219 *jrt.String = jrt.Intern("GOWORK")

var Lit_220 *jrt.String = jrt.Intern("off")

var Lit_221 *jrt.String = jrt.Intern("CGO_ENABLED")

var Lit_222 *jrt.String = jrt.Intern("1")

var Lit_223 *jrt.String = jrt.Intern("0")

var Lit_224 *jrt.String = jrt.Intern("GOOS")

var Lit_225 *jrt.String = jrt.Intern("GOARCH")

var Lit_226 *jrt.String = jrt.Intern("GOAMD64")

var Lit_227 *jrt.String = jrt.Intern("GOARM64")

var Lit_228 *jrt.String = jrt.Intern("GOEXPERIMENT")

var Lit_229 *jrt.String = jrt.Intern("arbace.g2a.print$chunk_starts")

var Lit_230 *jrt.String = jrt.Intern("arbace.g2a.print$chunk_starts$fn__1580000117")

var Lit_231 *jrt.String = jrt.Intern("arbace.g2a.print$chunk_starts$fn__1580000117$fn__1580000118")

var Lit_232 *jrt.String = jrt.Intern("arbace.g2a.print$collect")

var Lit_233 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054")

var Lit_234 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054$fn__1580000059")

var Lit_235 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054$fn__1580000061")

var Lit_236 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054$fn__1580000063")

var Lit_237 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054$fn__1580000063$fn__1580000064")

var Lit_238 *jrt.String = jrt.Intern(".ae")

var Lit_239 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054$fn__1580000067")

var Lit_240 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054$fn__1580000069")

var Lit_241 *jrt.String = jrt.Intern("arbace.g2a.print$collect$walk__1580000054$fn__1580000069$fn__1580000070")

var Lit_242 *jrt.String = jrt.Intern("arbace.g2a.print$collect_forms")

var Lit_243 *jrt.String = jrt.Intern("arbace.g2a.print$collect_forms$fn__1580000048")

var Lit_244 *jrt.String = jrt.Intern("load in forms in memory: ")

var Lit_245 *jrt.String = jrt.Intern("arbace.g2a.print$collect_forms$fn__1580000050")

var Lit_246 *jrt.String = jrt.Intern("arbace.g2a.print$copy_file")

var Lit_247 *jrt.String = jrt.Intern("arbace.g2a.print$copy_files")

var Lit_248 *jrt.String = jrt.Intern("embedded file ")

var Lit_249 *jrt.String = jrt.Intern(": sha256 ")

var Lit_250 *jrt.String = jrt.Intern(", the forms say ")

var Lit_251 *jrt.String = jrt.Intern("{\"Replace\": {\n")

var Lit_252 *jrt.String = jrt.Intern("\n}}\n")

var Lit_253 *jrt.String = jrt.Intern(",\n")

var Lit_254 *jrt.String = jrt.Intern("arbace.g2a.print$copy_files$iter__1580000197__1580000201")

var Lit_255 *jrt.String = jrt.Intern("arbace.g2a.print$copy_files$iter__1580000197__1580000201$fn__1580000202")

var Lit_256 *jrt.String = jrt.Intern("  ")

var Lit_257 *jrt.String = jrt.Intern(": ")

var Lit_258 *jrt.String = jrt.Intern("arbace.g2a.print$copy_files$iter__1580000197__1580000201$fn__1580000202$fn__1580000203")

var Lit_259 *jrt.String = jrt.Intern("arbace.g2a.print$decl_pre")

var Lit_260 *jrt.String = jrt.Intern("go/directive")

var Lit_261 *jrt.String = jrt.Intern("arbace.g2a.print$decl_sep_BANG_")

var Lit_262 *jrt.String = jrt.Intern("arbace.g2a.print$eval1580000004$loading__1927001464__auto____1580000005")

var Lit_263 *jrt.String = jrt.Intern("java.io.File")

var Lit_264 *jrt.String = jrt.Intern("java.io.FileInputStream")

var Lit_265 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_266 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_267 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_268 *jrt.String = jrt.Intern("java.nio.file.StandardCopyOption")

var Lit_269 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_270 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_271 *jrt.String = jrt.Intern("arbace.g2a.print$eval1580000008$fn__1580000009")

var Lit_272 *jrt.String = jrt.Intern("arbace.g2a.print$go_ns_aliases")

var Lit_273 *jrt.String = jrt.Intern("arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019")

var Lit_274 *jrt.String = jrt.Intern("arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020")

var Lit_275 *jrt.String = jrt.Intern("arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021")

var Lit_276 *jrt.String = jrt.Intern("arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021$fn__1580000022")

var Lit_277 *jrt.String = jrt.Intern("arbace.g2a.print$go_ns_aliases$iter__1580000013__1580000019$fn__1580000020$iter__1580000015__1580000021$fn__1580000022$fn__1580000023")

var Lit_278 *jrt.String = jrt.Intern("arbace.g2a.print$gofmt_file")

var Lit_279 *jrt.String = jrt.Intern("/bin/gofmt")

var Lit_280 *jrt.String = jrt.Intern("-w")

var Lit_281 *jrt.String = jrt.Intern("gofmt ")

var Lit_282 *jrt.String = jrt.Intern("arbace.g2a.print$import_spec")

var Lit_283 *jrt.String = jrt.Intern("arbace.g2a.print$json_string")

var Lit_284 *jrt.String = jrt.Intern("\"")

var Lit_285 *jrt.String = jrt.Intern("\\")

var Lit_286 *jrt.String = jrt.Intern("\\\\")

var Lit_287 *jrt.String = jrt.Intern("\\\"")

var Lit_288 *jrt.String = jrt.Intern("arbace.g2a.print$new_package_state")

var Lit_289 *jrt.String = jrt.Intern("arbace.g2a.print$next_target")

var Lit_290 *jrt.String = jrt.Intern("arbace.g2a.print$next_target$fn__1580000108")

var Lit_291 *jrt.String = jrt.Intern("arbace.g2a.print$one_line_func_QMARK_")

var Lit_292 *jrt.String = jrt.Intern("arbace.g2a.print$print_decl_BANG_")

var Lit_293 *jrt.String = jrt.Intern("arbace.g2a.print$print_file")

var Lit_294 *jrt.String = jrt.Intern("//line ")

var Lit_295 *jrt.String = jrt.Intern(":1")

var Lit_296 *jrt.String = jrt.Intern("arbace.g2a.print$print_file$first_line__1580000137")

var Lit_297 *jrt.String = jrt.Intern("arbace.g2a.print$print_file$fn__1580000140")

var Lit_298 *jrt.String = jrt.Intern("arbace.g2a.print$print_forms")

var Lit_299 *jrt.String = jrt.Intern("arbace.g2a.print$print_forms$fn__1580000174")

var Lit_300 *jrt.String = jrt.Intern("arbace.g2a.print$print_package")

var Lit_301 *jrt.String = jrt.Intern("arbace.g2a.print$read_forms")

var Lit_302 *jrt.String = jrt.Intern("arbace.g2a.print$run")

var Lit_303 *jrt.String = jrt.Intern("arbace.g2a.print$sha256")

var Lit_304 *jrt.String = jrt.Intern("SHA-256")

var Lit_305 *jrt.String = jrt.Intern("arbace.g2a.print$sha256$fn__1580000178")

var Lit_306 *jrt.String = jrt.Intern("%02x")

var Lit_307 *jrt.String = jrt.Intern("arbace.g2a.print$write_import_decl")

var Lit_308 *jrt.String = jrt.Intern("import")

var Lit_309 *jrt.String = jrt.Intern("(")

var Lit_310 *jrt.String = jrt.Intern(")")

var Lit_311 *jrt.String = jrt.Intern("arbace.g2a.print$write_imports")

var Lit_312 *jrt.String = jrt.Intern("arbace.g2a.print$write_imports$directive_QMARK___1580000091")

var Lit_313 *jrt.String = jrt.Intern("arglists")

var Lit_314 *jrt.String = jrt.Intern("The forms of a file, read with line numbers and *read-eval* false.")

var Lit_315 *jrt.String = jrt.Intern("column")

var Lit_316 *jrt.String = jrt.Intern("arbace/g2a/print.ae")

var Lit_317 *jrt.String = jrt.Intern("private")

var Lit_318 *jrt.String = jrt.Intern("ns-form")

var Lit_319 *jrt.String = jrt.Intern("The qualifiers naming arbace.go in an ns form's :require.")

var Lit_320 *jrt.String = jrt.Intern("dynamic")

var Lit_321 *jrt.String = jrt.Intern("The forms file being collected.")

var Lit_322 *jrt.String = jrt.Intern("state")

var Lit_323 *jrt.String = jrt.Intern("f")

var Lit_324 *jrt.String = jrt.Intern("load-fn")

var Lit_325 *jrt.String = jrt.Intern("Adds one top-level form to the collected package state; load-fn handles load forms.")

var Lit_326 *jrt.String = jrt.Intern("collect-forms")

var Lit_327 *jrt.String = jrt.Intern("forms")

var Lit_328 *jrt.String = jrt.Intern("The package of top-level forms in memory (the converter's output: ns, go/package, go/file\n  and declaration forms, no load), as collect gives it.")

var Lit_329 *jrt.String = jrt.Intern("read-fn")

var Lit_330 *jrt.String = jrt.Intern("The package of a forms file: {:package {opts} :name sym :files [{:name :file :opts\n  :decls}]}, following load forms (relative to the loading file's directory, which is\n  Clojure's rule for the package file's namespace, or with a leading / to the root the ns\n  name implies). read-fn (default read-forms) gives a file's forms: a cache of files read\n  beforehand (arbace.g2a.build reads a program's files once, in parallel).")

var Lit_331 *jrt.String = jrt.Intern("v")

var Lit_332 *jrt.String = jrt.Intern("specs")

var Lit_333 *jrt.String = jrt.Intern("The imports: [name path] specs, and (go/directive \"...\") forms among them (C4), in\n  order; the specs between two directives are one import declaration.")

var Lit_334 *jrt.String = jrt.Intern("t")

var Lit_335 *jrt.String = jrt.Intern("Whether a declaration is a function printed on one line: its closing brace on its first\n  line (mode :lines), or an empty body (gofmt's layout).")

var Lit_336 *jrt.String = jrt.Intern("[directive? doc directives pre-lines] of a top-level declaration.")

var Lit_337 *jrt.String = jrt.Intern("i")

var Lit_338 *jrt.String = jrt.Intern("The line the declaration after decls' i-th is placed on (its doc first), when known.")

var Lit_339 *jrt.String = jrt.Intern("pre")

var Lit_340 *jrt.String = jrt.Intern("The separation of a declaration (recorded line t, pre comment lines before it) from what\n  precedes it: a new alignment section (form feed) unless a one-line function follows a line\n  at the left margin (go/printer's declList: one-line functions in a row align their\n  bodies); in mode :lines down to its line.")

var Lit_341 *jrt.String = jrt.Intern("popts")

var Lit_342 *jrt.String = jrt.Intern("sep?")

var Lit_343 *jrt.String = jrt.Intern("Prints decls' i-th declaration, after its separation from what precedes it unless\n  sep? is false (a chunk's first: start-at! placed it).")

var Lit_344 *jrt.String = jrt.Intern("The fewest declarations of a chunk: a file of fewer than twice as many is printed whole.")

var Lit_345 *jrt.String = jrt.Intern("The first declarations of decls' chunks (mode :lines): about two chunks per processor,\n  each starting at a declaration with a recorded line; none for a file of few declarations.")

var Lit_346 *jrt.String = jrt.Intern("pkg-name")

var Lit_347 *jrt.String = jrt.Intern("The Go text of one file: {:name :opts :decls} as collect gives it. pkg-name is the\n  package clause's name unless the file's :package says otherwise. In mode :lines a file of\n  many declarations is printed in chunks, in parallel (print-emit's join!); the text is the\n  same.")

var Lit_348 *jrt.String = jrt.Intern("pkg")

var Lit_349 *jrt.String = jrt.Intern("The Go files of a collected package: {name text}, printed in parallel (each file's\n  printing is independent: its own emitter state).")

var Lit_350 *jrt.String = jrt.Intern("tag")

var Lit_351 *jrt.String = jrt.Intern("File")

var Lit_352 *jrt.String = jrt.Intern("from")

var Lit_353 *jrt.String = jrt.Intern("to")

var Lit_354 *jrt.String = jrt.Intern("s")

var Lit_355 *jrt.String = jrt.Intern("out")

var Lit_356 *jrt.String = jrt.Intern("written")

var Lit_357 *jrt.String = jrt.Intern("Copies the package's :other-files and :embed-files (checking the hashes) from src to\n  out; writes out/overlay.json for go build -overlay (src's Go files to out's).")

var Lit_358 *jrt.String = jrt.Intern("goroot")

var Lit_359 *jrt.String = jrt.Intern("The environment of the package's configuration (§4.2, §12.4).")

var Lit_360 *jrt.String = jrt.Intern("cmd")

var Lit_361 *jrt.String = jrt.Intern("dir")

var Lit_362 *jrt.String = jrt.Intern("env")

var Lit_363 *jrt.String = jrt.Intern("go build -trimpath -overlay out/overlay.json in src, under the package's configuration.")

var Lit_364 *jrt.String = jrt.Intern("out-dir")

var Lit_365 *jrt.String = jrt.Intern("Prints the package of the forms file at path into out-dir; returns the file names.")

var Lit_366 *jrt.String = jrt.Intern("-main")

var Lit_367 *jrt.String = jrt.Intern("&")

var Lit_368 *jrt.String = jrt.Intern("argv")
