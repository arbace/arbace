//line a2g_strings.ae:1
package aot_arbace_classes_lower

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.lower")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("Clojure's special forms that the class forms compiler compiles by rewriting them into class\n  forms and other forms it knows (SPEC §5.13, §9.5): fn*, reify*, deftype*, letfn*, case* and def. These\n  are pure form-to-form functions; arbace.classes.analyze analyzes their results.\n\n  - (fn* ...) becomes an anonymous subclass of arbace.lang.AFunction (or RestFn when it has a\n    variadic arity) with an invoke method per arity (doInvoke and getRequiredArity for the\n    variadic one), as arbace.lang.Compiler's fn classes have them. Its body has Clojure's\n    meaning: the parameters are Object, recur goes to the top of the arity, the fn's name is the\n    instance. `fn-methods` makes the members; arbace.classes.native uses them for the top-level\n    class of a fn that arbace.lang.Compiler hands over.\n  - (reify* [interfaces] methods) becomes a local class implementing them and IObj, its methods\n    choosing the interface method they implement as arbace.lang.Compiler does (`clojure-method`).\n  - (deftype* ...) gives the class form of the deftype class (`deftype-class-form`), which\n    arbace.classes.native compiles when arbace.lang.Compiler hands a deftype over.\n  - (letfn* [f (fn* f ...) ...] body) binds boxes first, then the fns, whose bodies read the\n    others from their boxes, then fills the boxes.\n  - (case* ...) becomes a switch on the hash (or int value) inside a label, with the equality\n    test in each arm and the default after the switch, as arbace.lang.Compiler's CaseExpr.\n  - (def ...) becomes calls of the var's bindRoot, setMeta and setDynamic.")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("symbol")

var Lit_14 *jrt.String = jrt.Intern("swap!")

var Lit_15 *jrt.String = jrt.Intern("ids")

var Lit_16 *jrt.String = jrt.Intern("inc")

var Lit_17 *jrt.String = jrt.Intern("seq")

var Lit_18 *jrt.String = jrt.Intern("first")

var Lit_19 *jrt.String = jrt.Intern("next")

var Lit_20 *jrt.String = jrt.Intern("symbol?")

var Lit_21 *jrt.String = jrt.Intern("vector?")

var Lit_22 *jrt.String = jrt.Intern("name")

var Lit_23 *jrt.String = jrt.Intern("arities")

var Lit_24 *jrt.String = jrt.Intern("mapv")

var Lit_25 *jrt.String = jrt.Intern("rest")

var Lit_26 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_27 *jrt.String = jrt.Intern("chunk-first")

var Lit_28 *jrt.String = jrt.Intern("seq?")

var Lit_29 *jrt.String = jrt.Intern("ex-info")

var Lit_30 *jrt.String = jrt.Intern("pr-str")

var Lit_31 *jrt.String = jrt.Intern("arbace")

var Lit_32 *jrt.String = jrt.Intern("compile-error")

var Lit_33 *jrt.String = jrt.Intern("chunk-rest")

var Lit_34 *jrt.String = jrt.Intern("namespace")

var Lit_35 *jrt.String = jrt.Intern("prim-tags")

var Lit_36 *jrt.String = jrt.Intern("some")

var Lit_37 *jrt.String = jrt.Intern("&")

var Lit_38 *jrt.String = jrt.Intern("long")

var Lit_39 *jrt.String = jrt.Intern("double")

var Lit_40 *jrt.String = jrt.Intern("prim-tag?")

var Lit_41 *jrt.String = jrt.Intern("else")

var Lit_42 *jrt.String = jrt.Intern("variadic?")

var Lit_43 *jrt.String = jrt.Intern("apply")

var Lit_44 *jrt.String = jrt.Intern("re-find")

var Lit_45 *jrt.String = jrt.Intern("concat")

var Lit_46 *jrt.String = jrt.Intern("map")

var Lit_47 *jrt.String = jrt.Intern("class-char")

var Lit_48 *jrt.String = jrt.Intern("tag")

var Lit_49 *jrt.String = jrt.Intern("[LD]")

var Lit_50 *jrt.String = jrt.Intern("vec")

var Lit_51 *jrt.String = jrt.Intern("distinct")

var Lit_52 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_53 *jrt.String = jrt.Intern("prim-sig")

var Lit_54 *jrt.String = jrt.Intern("chunk-append")

var Lit_55 *jrt.String = jrt.Intern("arbace.lang.IFn")

var Lit_56 *jrt.String = jrt.Intern("chunk-cons")

var Lit_57 *jrt.String = jrt.Intern("cons")

var Lit_58 *jrt.String = jrt.Intern("chunk")

var Lit_59 *jrt.String = jrt.Intern("filter")

var Lit_60 *jrt.String = jrt.Intern("mapcat")

var Lit_61 *jrt.String = jrt.Intern("split-with")

var Lit_62 *jrt.String = jrt.Intern("list")

var Lit_63 *jrt.String = jrt.Intern("sig-types")

var Lit_64 *jrt.String = jrt.Intern("with-meta")

var Lit_65 *jrt.String = jrt.Intern("not=")

var Lit_66 *jrt.String = jrt.Intern("gsym")

var Lit_67 *jrt.String = jrt.Intern("vary-meta")

var Lit_68 *jrt.String = jrt.Intern("dissoc")

var Lit_69 *jrt.String = jrt.Intern("let*")

var Lit_70 *jrt.String = jrt.Intern("list*")

var Lit_71 *jrt.String = jrt.Intern("loop*")

var Lit_72 *jrt.String = jrt.Intern("arbace.classes")

var Lit_73 *jrt.String = jrt.Intern("fn-body")

var Lit_74 *jrt.String = jrt.Intern("comp")

var Lit_75 *jrt.String = jrt.Intern("butlast")

var Lit_76 *jrt.String = jrt.Intern("last")

var Lit_77 *jrt.String = jrt.Intern("method")

var Lit_78 *jrt.String = jrt.Intern("invokePrim")

var Lit_79 *jrt.String = jrt.Intern("public")

var Lit_80 *jrt.String = jrt.Intern("invoke")

var Lit_81 *jrt.String = jrt.Intern(".invokePrim")

var Lit_82 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_83 *jrt.String = jrt.Intern("longCast")

var Lit_84 *jrt.String = jrt.Intern("doubleCast")

var Lit_85 *jrt.String = jrt.Intern("doInvoke")

var Lit_86 *jrt.String = jrt.Intern("protected")

var Lit_87 *jrt.String = jrt.Intern("take-while")

var Lit_88 *jrt.String = jrt.Intern("getRequiredArity")

var Lit_89 *jrt.String = jrt.Intern("int")

var Lit_90 *jrt.String = jrt.Intern("line")

var Lit_91 *jrt.String = jrt.Intern("column")

var Lit_92 *jrt.String = jrt.Intern("file")

var Lit_93 *jrt.String = jrt.Intern("rettag")

var Lit_94 *jrt.String = jrt.Intern("end-line")

var Lit_95 *jrt.String = jrt.Intern("end-column")

var Lit_96 *jrt.String = jrt.Intern("fn-parts")

var Lit_97 *jrt.String = jrt.Intern("to-array")

var Lit_98 *jrt.String = jrt.Intern("arbace.lang.RestFn")

var Lit_99 *jrt.String = jrt.Intern("arbace.lang.AFunction")

var Lit_100 *jrt.String = jrt.Intern("prim-interfaces")

var Lit_101 *jrt.String = jrt.Intern("fn-meta")

var Lit_102 *jrt.String = jrt.Intern("class*")

var Lit_103 *jrt.String = jrt.Intern("local")

var Lit_104 *jrt.String = jrt.Intern("extends")

var Lit_105 *jrt.String = jrt.Intern("implements")

var Lit_106 *jrt.String = jrt.Intern("fn-methods")

var Lit_107 *jrt.String = jrt.Intern("clojure-fn")

var Lit_108 *jrt.String = jrt.Intern("final")

var Lit_109 *jrt.String = jrt.Intern("new")

var Lit_110 *jrt.String = jrt.Intern("anon")

var Lit_111 *jrt.String = jrt.Intern("contains?")

var Lit_112 *jrt.String = jrt.Intern("assoc")

var Lit_113 *jrt.String = jrt.Intern("munge")

var Lit_114 *jrt.String = jrt.Intern("clojure-method")

var Lit_115 *jrt.String = jrt.Intern("symbols-in")

var Lit_116 *jrt.String = jrt.Intern("recur")

var Lit_117 *jrt.String = jrt.Intern("do")

var Lit_118 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_119 *jrt.String = jrt.Intern("clojure-type")

var Lit_120 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_121 *jrt.String = jrt.Intern("field")

var Lit_122 *jrt.String = jrt.Intern("__meta")

var Lit_123 *jrt.String = jrt.Intern("private")

var Lit_124 *jrt.String = jrt.Intern("constructor")

var Lit_125 *jrt.String = jrt.Intern("set!")

var Lit_126 *jrt.String = jrt.Intern(".-__meta")

var Lit_127 *jrt.String = jrt.Intern("meta")

var Lit_128 *jrt.String = jrt.Intern("withMeta")

var Lit_129 *jrt.String = jrt.Intern("into")

var Lit_130 *jrt.String = jrt.Intern("key")

var Lit_131 *jrt.String = jrt.Intern("keyword?")

var Lit_132 *jrt.String = jrt.Intern("second")

var Lit_133 *jrt.String = jrt.Intern("nnext")

var Lit_134 *jrt.String = jrt.Intern("subs")

var Lit_135 *jrt.String = jrt.Intern("subvec")

var Lit_136 *jrt.String = jrt.Intern("take")

var Lit_137 *jrt.String = jrt.Intern("this.")

var Lit_138 *jrt.String = jrt.Intern("alt-ctor-fields")

var Lit_139 *jrt.String = jrt.Intern("rseq")

var Lit_140 *jrt.String = jrt.Intern("quote")

var Lit_141 *jrt.String = jrt.Intern("merge")

var Lit_142 *jrt.String = jrt.Intern("annotation-meta")

var Lit_143 *jrt.String = jrt.Intern("volatile-mutable")

var Lit_144 *jrt.String = jrt.Intern("volatile")

var Lit_145 *jrt.String = jrt.Intern("unsynchronized-mutable")

var Lit_146 *jrt.String = jrt.Intern("some?")

var Lit_147 *jrt.String = jrt.Intern("clojure-tag")

var Lit_148 *jrt.String = jrt.Intern("package")

var Lit_149 *jrt.String = jrt.Intern("reflection")

var Lit_150 *jrt.String = jrt.Intern("clojure")

var Lit_151 *jrt.String = jrt.Intern("super.")

var Lit_152 *jrt.String = jrt.Intern("getBasis")

var Lit_153 *jrt.String = jrt.Intern("static")

var Lit_154 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_155 *jrt.String = jrt.Intern("range")

var Lit_156 *jrt.String = jrt.Intern("create")

var Lit_157 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_158 *jrt.String = jrt.Intern("intern")

var Lit_159 *jrt.String = jrt.Intern(".")

var Lit_160 *jrt.String = jrt.Intern("valAt")

var Lit_161 *jrt.String = jrt.Intern("without")

var Lit_162 *jrt.String = jrt.Intern("cast")

var Lit_163 *jrt.String = jrt.Intern("boxes")

var Lit_164 *jrt.String = jrt.Intern("seqOrElse")

var Lit_165 *jrt.String = jrt.Intern("peek")

var Lit_166 *jrt.String = jrt.Intern("set?")

var Lit_167 *jrt.String = jrt.Intern("reduce")

var Lit_168 *jrt.String = jrt.Intern("map?")

var Lit_169 *jrt.String = jrt.Intern("identity")

var Lit_170 *jrt.String = jrt.Intern("partition")

var Lit_171 *jrt.String = jrt.Intern("zipmap")

var Lit_172 *jrt.String = jrt.Intern("fn*")

var Lit_173 *jrt.String = jrt.Intern("remove")

var Lit_174 *jrt.String = jrt.Intern("set")

var Lit_175 *jrt.String = jrt.Intern(".-val")

var Lit_176 *jrt.String = jrt.Intern("arbace.lang.Box")

var Lit_177 *jrt.String = jrt.Intern("keyword")

var Lit_178 *jrt.String = jrt.Intern("bit-and-int")

var Lit_179 *jrt.String = jrt.Intern("bit-shift-right-int")

var Lit_180 *jrt.String = jrt.Intern("switch*")

var Lit_181 *jrt.String = jrt.Intern("hash-identity")

var Lit_182 *jrt.String = jrt.Intern("break*")

var Lit_183 *jrt.String = jrt.Intern("if")

var Lit_184 *jrt.String = jrt.Intern("==")

var Lit_185 *jrt.String = jrt.Intern("arbace.lang.Util")

var Lit_186 *jrt.String = jrt.Intern("equiv")

var Lit_187 *jrt.String = jrt.Intern("identical?")

var Lit_188 *jrt.String = jrt.Intern("sort-by")

var Lit_189 *jrt.String = jrt.Intern("label*")

var Lit_190 *jrt.String = jrt.Intern("hash")

var Lit_191 *jrt.String = jrt.Intern("unchecked-int")

var Lit_192 *jrt.String = jrt.Intern("instance?")

var Lit_193 *jrt.String = jrt.Intern("java.lang.Number")

var Lit_194 *jrt.String = jrt.Intern(".intValue")

var Lit_195 *jrt.String = jrt.Intern("var")

var Lit_196 *jrt.String = jrt.Intern("bindRoot")

var Lit_197 *jrt.String = jrt.Intern("setMeta")

var Lit_198 *jrt.String = jrt.Intern("setDynamic")

var Lit_199 *jrt.String = jrt.Intern("dynamic")

var Lit_200 *jrt.String = jrt.Intern("arbace.classes.lower$annotation_meta")

var Lit_201 *jrt.String = jrt.Intern("arbace.classes.lower$class_char")

var Lit_202 *jrt.String = jrt.Intern("L")

var Lit_203 *jrt.String = jrt.Intern("D")

var Lit_204 *jrt.String = jrt.Intern("Only long and double primitives are supported")

var Lit_205 *jrt.String = jrt.Intern("O")

var Lit_206 *jrt.String = jrt.Intern("arbace.classes.lower$clojure_method")

var Lit_207 *jrt.String = jrt.Intern("Must supply at least one argument for 'this' in: ")

var Lit_208 *jrt.String = jrt.Intern("params must be Symbols")

var Lit_209 *jrt.String = jrt.Intern("arbace.classes.lower$clojure_method$fn__1304000104")

var Lit_210 *jrt.String = jrt.Intern("arbace.classes.lower$clojure_method$fn__1304000106")

var Lit_211 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form")

var Lit_212 *jrt.String = jrt.Intern("")

var Lit_213 *jrt.String = jrt.Intern("this")

var Lit_214 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$ctor__1304000133")

var Lit_215 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000123")

var Lit_216 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000125")

var Lit_217 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000185")

var Lit_218 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000187")

var Lit_219 *jrt.String = jrt.Intern("Value")

var Lit_220 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fname__1304000127")

var Lit_221 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000135__1304000139")

var Lit_222 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000135__1304000139$fn__1304000140")

var Lit_223 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000135__1304000139$fn__1304000140$fn__1304000141")

var Lit_224 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000145__1304000149")

var Lit_225 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000145__1304000149$fn__1304000150")

var Lit_226 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000145__1304000149$fn__1304000150$fn__1304000151")

var Lit_227 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000155__1304000159")

var Lit_228 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000155__1304000159$fn__1304000160")

var Lit_229 *jrt.String = jrt.Intern(".-")

var Lit_230 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000155__1304000159$fn__1304000160$fn__1304000161")

var Lit_231 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000165__1304000169")

var Lit_232 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000165__1304000169$fn__1304000170")

var Lit_233 *jrt.String = jrt.Intern("m")

var Lit_234 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000165__1304000169$fn__1304000170$fn__1304000171")

var Lit_235 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000175__1304000179")

var Lit_236 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000175__1304000179$fn__1304000180")

var Lit_237 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000175__1304000179$fn__1304000180$fn__1304000181")

var Lit_238 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$param__1304000131")

var Lit_239 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$ptag__1304000129")

var Lit_240 *jrt.String = jrt.Intern("arbace.classes.lower$eval1304000004$loading__1927001464__auto____1304000005")

var Lit_241 *jrt.String = jrt.Intern("arbace.classes.lower$eval1304000008$fn__1304000009")

var Lit_242 *jrt.String = jrt.Intern("arbace.classes.lower$fn_meta")

var Lit_243 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods")

var Lit_244 *jrt.String = jrt.Intern("Can't have more than 1 variadic overload")

var Lit_245 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000060")

var Lit_246 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000070")

var Lit_247 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000072")

var Lit_248 *jrt.String = jrt.Intern("p")

var Lit_249 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000074")

var Lit_250 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000078")

var Lit_251 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000060$typed__1304000076")

var Lit_252 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000085")

var Lit_253 *jrt.String = jrt.Intern("arbace.classes.lower$fn_parts")

var Lit_254 *jrt.String = jrt.Intern("Bad fn form: ")

var Lit_255 *jrt.String = jrt.Intern("arbace.classes.lower$fn_parts$fn__1304000025")

var Lit_256 *jrt.String = jrt.Intern("arbace.classes.lower$gsym")

var Lit_257 *jrt.String = jrt.Intern("__")

var Lit_258 *jrt.String = jrt.Intern("__auto__")

var Lit_259 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case")

var Lit_260 *jrt.String = jrt.Intern("case")

var Lit_261 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case$fn__1304000248")

var Lit_262 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case$sm__1304000245")

var Lit_263 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case$sw__1304000256")

var Lit_264 *jrt.String = jrt.Intern("arbace.classes.lower$lower_def")

var Lit_265 *jrt.String = jrt.Intern("Too many arguments to def")

var Lit_266 *jrt.String = jrt.Intern("arbace.classes.lower$lower_fn")

var Lit_267 *jrt.String = jrt.Intern("fn")

var Lit_268 *jrt.String = jrt.Intern("Fn")

var Lit_269 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn")

var Lit_270 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$fn__1304000196")

var Lit_271 *jrt.String = jrt.Intern("box_")

var Lit_272 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$fn__1304000222")

var Lit_273 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$fn__1304000225")

var Lit_274 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$iter__1304000230__1304000234")

var Lit_275 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$iter__1304000230__1304000234$fn__1304000235")

var Lit_276 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$iter__1304000230__1304000234$fn__1304000235$fn__1304000236")

var Lit_277 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000198")

var Lit_278 *jrt.String = jrt.Intern("letfn binding is not a fn: ")

var Lit_279 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205")

var Lit_280 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206")

var Lit_281 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206$fn__1304000207")

var Lit_282 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206$fn__1304000207$fn__1304000211")

var Lit_283 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206$fn__1304000217")

var Lit_284 *jrt.String = jrt.Intern("arbace.classes.lower$lower_reify")

var Lit_285 *jrt.String = jrt.Intern("Reify")

var Lit_286 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces")

var Lit_287 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces$iter__1304000046__1304000050")

var Lit_288 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces$iter__1304000046__1304000050$fn__1304000051")

var Lit_289 *jrt.String = jrt.Intern("$")

var Lit_290 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces$iter__1304000046__1304000050$fn__1304000051$fn__1304000052")

var Lit_291 *jrt.String = jrt.Intern("arbace.classes.lower$prim_sig")

var Lit_292 *jrt.String = jrt.Intern("fns taking primitives support only 4 or fewer args")

var Lit_293 *jrt.String = jrt.Intern("arbace.classes.lower$prim_sig$fn__1304000043")

var Lit_294 *jrt.String = jrt.Intern("arbace.classes.lower$prim_tag_QMARK_")

var Lit_295 *jrt.String = jrt.Intern("arbace.classes.lower$symbols_in")

var Lit_296 *jrt.String = jrt.Intern("arbace.classes.lower$variadic_QMARK_")

var Lit_297 *jrt.String = jrt.Intern("in-ns")

var Lit_298 *jrt.String = jrt.Intern("atom")

var Lit_299 *jrt.String = jrt.Intern("arbace/classes/lower.ae")

var Lit_300 *jrt.String = jrt.Intern("arglists")

var Lit_301 *jrt.String = jrt.Intern("prefix")

var Lit_302 *jrt.String = jrt.Intern("_")

var Lit_303 *jrt.String = jrt.Intern("more")

var Lit_304 *jrt.String = jrt.Intern("form")

var Lit_305 *jrt.String = jrt.Intern("(fn* name? [params] body*) or (fn* name? ([params] body*)+) as {:name :arities [[pv body]]}.")

var Lit_306 *jrt.String = jrt.Intern("boolean")

var Lit_307 *jrt.String = jrt.Intern("char")

var Lit_308 *jrt.String = jrt.Intern("short")

var Lit_309 *jrt.String = jrt.Intern("float")

var Lit_310 *jrt.String = jrt.Intern("byte")

var Lit_311 *jrt.String = jrt.Intern("x")

var Lit_312 *jrt.String = jrt.Intern("pv")

var Lit_313 *jrt.String = jrt.Intern("Compiler.classChar: L for long, D for double, O for anything else that is no primitive.")

var Lit_314 *jrt.String = jrt.Intern("arity")

var Lit_315 *jrt.String = jrt.Intern("The primitive signature of a fixed arity (\"LO\" for ^long x returning Object), as\n  arbace.lang.Compiler's FnMethod.primInterface, or nil when it has none.")

var Lit_316 *jrt.String = jrt.Intern("The IFn$... interfaces of the primitive signatures of the arities.")

var Lit_317 *jrt.String = jrt.Intern("rcv")

var Lit_318 *jrt.String = jrt.Intern("nm")

var Lit_319 *jrt.String = jrt.Intern("binds")

var Lit_320 *jrt.String = jrt.Intern("The members of the class of a fn: an invoke (or doInvoke) method per arity, and\n  getRequiredArity when variadic. `binds` are bindings [sym init ...] made at the start of every\n  arity, before the fn's name (bound to the instance) and the parameters (initializers may use\n  the receiver `rcv`). An arity with a primitive signature (prim-sig) has its body in invokePrim\n  of its IFn$... interface, and invoke converts the arguments and calls it, as\n  arbace.lang.Compiler's fn classes do.")

var Lit_321 *jrt.String = jrt.Intern("The metadata of a fn* form that the fn object gets (without source positions), or nil.")

var Lit_322 *jrt.String = jrt.Intern("lower-fn")

var Lit_323 *jrt.String = jrt.Intern("(fn* ...) in code compiled by the class forms compiler: an anonymous AFunction or RestFn, or\n  with primitive signatures a local class that also implements their IFn$... interfaces.")

var Lit_324 *jrt.String = jrt.Intern("declared")

var Lit_325 *jrt.String = jrt.Intern("body")

var Lit_326 *jrt.String = jrt.Intern("A method (name [this params*] body*) of reify* or deftype* as a class form method: public,\n  its name munged, marked :clojure-method so that arbace.classes.analyze picks the interface\n  method it implements as arbace.lang.Compiler does (by name and arity, then by the hints of the\n  parameters and of the name), with recur to the top of the method when its body uses recur.")

var Lit_327 *jrt.String = jrt.Intern("lower-reify")

var Lit_328 *jrt.String = jrt.Intern("ifaces")

var Lit_329 *jrt.String = jrt.Intern("methods")

var Lit_330 *jrt.String = jrt.Intern("(reify* [interface*] (method [this params*] body*)*): a local class implementing the\n  interfaces and arbace.lang.IObj (its metadata in __meta, withMeta making a copy), its methods\n  `clojure-method`s. Evaluates to an instance with the form's metadata (without source\n  positions).")

var Lit_331 *jrt.String = jrt.Intern("java.lang.Integer")

var Lit_332 *jrt.String = jrt.Intern("java.lang.Long")

var Lit_333 *jrt.String = jrt.Intern("java.lang.Float")

var Lit_334 *jrt.String = jrt.Intern("java.lang.Double")

var Lit_335 *jrt.String = jrt.Intern("java.lang.Character")

var Lit_336 *jrt.String = jrt.Intern("java.lang.Short")

var Lit_337 *jrt.String = jrt.Intern("java.lang.Byte")

var Lit_338 *jrt.String = jrt.Intern("java.lang.Boolean")

var Lit_339 *jrt.String = jrt.Intern("deftype-class-form")

var Lit_340 *jrt.String = jrt.Intern("_tagname")

var Lit_341 *jrt.String = jrt.Intern("classname")

var Lit_342 *jrt.String = jrt.Intern("fields")

var Lit_343 *jrt.String = jrt.Intern("The class form (the rest of a defclass form) of (deftype* tagname classname [field*]\n  :implements [interface*] option* method*), with the shape arbace.lang.Compiler gives a\n  deftype (NewInstanceExpr): a public final class implementing the interfaces; a field per\n  field, public final, or volatile for ^:volatile-mutable, package-private for\n  ^:unsynchronized-mutable, primitive for a primitive hint and otherwise Object (a reference\n  hint stays a hint of the field, :clojure-tag); a constructor taking the fields; for records\n  (fields ending in __meta __extmap __hash __hasheq) the two shorter constructors and the\n  static create(IPersistentMap); the static getBasis(); the methods as `clojure-method`s.")

var Lit_344 *jrt.String = jrt.Intern("The unqualified symbols occurring in form (any position).")

var Lit_345 *jrt.String = jrt.Intern("lower-letfn")

var Lit_346 *jrt.String = jrt.Intern("bindings")

var Lit_347 *jrt.String = jrt.Intern("expand")

var Lit_348 *jrt.String = jrt.Intern("(letfn* [f (fn f ...) ...] body*): each fn reads the others from boxes filled after all\n  are created. `expand` macroexpands an initializer to its fn* form.")

var Lit_349 *jrt.String = jrt.Intern("lower-case")

var Lit_350 *jrt.String = jrt.Intern("ge")

var Lit_351 *jrt.String = jrt.Intern("shift")

var Lit_352 *jrt.String = jrt.Intern("mask")

var Lit_353 *jrt.String = jrt.Intern("default")

var Lit_354 *jrt.String = jrt.Intern("imap")

var Lit_355 *jrt.String = jrt.Intern("_switch-type")

var Lit_356 *jrt.String = jrt.Intern("test-type")

var Lit_357 *jrt.String = jrt.Intern("skip-check")

var Lit_358 *jrt.String = jrt.Intern("prim-int?")

var Lit_359 *jrt.String = jrt.Intern("(case* ge shift mask default imap switch-type test-type skip-check?), as CaseExpr compiles\n  it: the int value (test-type :int) or hash of ge, shifted and masked, selects an arm, which\n  tests ge against the arm's constant (= or, for :hash-identity, identical?) and on success\n  leaves the case with the arm's value; otherwise the default. `prim-int?` says whether ge is a\n  local of an integral primitive type.")

var Lit_360 *jrt.String = jrt.Intern("lower-def")

var Lit_361 *jrt.String = jrt.Intern("sym")

var Lit_362 *jrt.String = jrt.Intern("(def sym), (def sym init), (def sym doc init) as calls on the var (already interned): binds\n  the root when there is an initializer, sets the metadata (with the source position and doc)\n  and the dynamic flag, as DefExpr does. Returns the var.")
