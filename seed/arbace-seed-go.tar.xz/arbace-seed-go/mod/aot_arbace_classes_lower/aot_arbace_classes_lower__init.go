//line aot_arbace_classes_lower__init.ae:1
package aot_arbace_classes_lower

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_lower__init_A_Unit0__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_classes_lower__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_classes_lower__init_A_const_1) }
//line :1:1
func A_arbace_classes_lower__init_A_Unit1__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_classes_lower__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_2)) }
//line :1:1
func A_arbace_classes_lower__init_A_Unit2__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_New(); var tmp2 *jrt.Class; A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_Init(); tmp2 = A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_lower__init_A_Unit3__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_lower__init_A_const_1)).Equals_O__Z(A_arbace_classes_lower__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_lower_eval1304000008_fn__1304000009_A_New(); var tmp2 *jrt.Class; A_arbace_classes_lower_eval1304000008_fn__1304000009_A_Init(); tmp2 = A_arbace_classes_lower_eval1304000008_fn__1304000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_lower__init_A_Load__O() any { A_arbace_classes_lower__init_A_Init(); A_arbace_classes_lower__init_A_Unit0__O(); A_arbace_classes_lower__init_A_Unit1__O(); A_arbace_classes_lower__init_A_Unit2__O(); A_arbace_classes_lower__init_A_Unit3__O(); A_arbace_classes_lower__init_A_Unit4__O(); A_arbace_classes_lower__init_A_Unit5__O(); A_arbace_classes_lower__init_A_Unit6__O(); A_arbace_classes_lower__init_A_Unit7__O(); A_arbace_classes_lower__init_A_Unit8__O(); A_arbace_classes_lower__init_A_Unit9__O(); A_arbace_classes_lower__init_A_Unit10__O(); A_arbace_classes_lower__init_A_Unit11__O(); A_arbace_classes_lower__init_A_Unit12__O(); A_arbace_classes_lower__init_A_Unit13__O(); A_arbace_classes_lower__init_A_Unit14__O(); A_arbace_classes_lower__init_A_Unit15__O(); A_arbace_classes_lower__init_A_Unit16__O(); A_arbace_classes_lower__init_A_Unit17__O(); A_arbace_classes_lower__init_A_Unit18__O(); A_arbace_classes_lower__init_A_Unit19__O(); A_arbace_classes_lower__init_A_Unit20__O(); A_arbace_classes_lower__init_A_Unit21__O(); A_arbace_classes_lower__init_A_Unit22__O(); A_arbace_classes_lower__init_A_Unit23__O(); A_arbace_classes_lower__init_A_Unit24__O(); A_arbace_classes_lower__init_A_Unit25__O(); A_arbace_classes_lower__init_A_Unit26__O(); A_arbace_classes_lower__init_A_Unit27__O(); return nil }

















func A_arbace_classes_lower__init_A_Unit4__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_4; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_classes_lower__init_A_const_5).GetRawRoot__O()).Invoke_O__O(A_arbace_classes_lower__init_A_const_7)); var tmp2 *lang.Var = A_arbace_classes_lower__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_6)); return A_arbace_classes_lower__init_A_const_4.Ref() }

func A_arbace_classes_lower__init_A_Unit5__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_8; var tmp2 any = A_arbace_classes_lower_gsym_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_gsym_A_Init(); tmp3 = A_arbace_classes_lower_gsym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_9)); return A_arbace_classes_lower__init_A_const_8.Ref() }




func A_arbace_classes_lower__init_A_Unit6__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_10; var tmp2 any = A_arbace_classes_lower_fn_parts_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_fn_parts_A_Init(); tmp3 = A_arbace_classes_lower_fn_parts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_11)); return A_arbace_classes_lower__init_A_const_10.Ref() }









func A_arbace_classes_lower__init_A_Unit7__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(40, 1); jrt.NN(A_arbace_classes_lower__init_A_const_12).BindRoot_O__V(A_arbace_classes_lower__init_A_const_13); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_12; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_14)); return A_arbace_classes_lower__init_A_const_12.Ref() }

func A_arbace_classes_lower__init_A_Unit8__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_15; var tmp2 any = A_arbace_classes_lower_prim_tag_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_prim_tag_QMARK__A_Init(); tmp3 = A_arbace_classes_lower_prim_tag_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_16)); return A_arbace_classes_lower__init_A_const_15.Ref() }

func A_arbace_classes_lower__init_A_Unit9__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_17; var tmp2 any = A_arbace_classes_lower_variadic_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_variadic_QMARK__A_Init(); tmp3 = A_arbace_classes_lower_variadic_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_18)); return A_arbace_classes_lower__init_A_const_17.Ref() }

func A_arbace_classes_lower__init_A_Unit10__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_19; var tmp2 any = A_arbace_classes_lower_class_char_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_class_char_A_Init(); tmp3 = A_arbace_classes_lower_class_char_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_20)); return A_arbace_classes_lower__init_A_const_19.Ref() }








func A_arbace_classes_lower__init_A_Unit11__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(55, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_21; var tmp2 any = A_arbace_classes_lower_prim_sig_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_prim_sig_A_Init(); tmp3 = A_arbace_classes_lower_prim_sig_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_22)); return A_arbace_classes_lower__init_A_const_21.Ref() }










func A_arbace_classes_lower__init_A_Unit12__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_23; var tmp2 any = A_arbace_classes_lower_prim_interfaces_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_prim_interfaces_A_Init(); tmp3 = A_arbace_classes_lower_prim_interfaces_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_24)); return A_arbace_classes_lower__init_A_const_23.Ref() }




func A_arbace_classes_lower__init_A_Unit13__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); jrt.NN(A_arbace_classes_lower__init_A_const_25).BindRoot_O__V(A_arbace_classes_lower__init_A_const_26); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_25; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_27)); return A_arbace_classes_lower__init_A_const_25.Ref() }

func A_arbace_classes_lower__init_A_Unit14__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_28; var tmp2 any = A_arbace_classes_lower_fn_methods_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_fn_methods_A_Init(); tmp3 = A_arbace_classes_lower_fn_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_29)); return A_arbace_classes_lower__init_A_const_28.Ref() }












































func A_arbace_classes_lower__init_A_Unit15__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_30; var tmp2 any = A_arbace_classes_lower_fn_meta_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_fn_meta_A_Init(); tmp3 = A_arbace_classes_lower_fn_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_31)); return A_arbace_classes_lower__init_A_const_30.Ref() }





func A_arbace_classes_lower__init_A_Unit16__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_32; var tmp2 any = A_arbace_classes_lower_lower_fn_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_lower_fn_A_Init(); tmp3 = A_arbace_classes_lower_lower_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_33)); return A_arbace_classes_lower__init_A_const_32.Ref() }






















func A_arbace_classes_lower__init_A_Unit17__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_34; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_35)); return A_arbace_classes_lower__init_A_const_34.Ref() }

func A_arbace_classes_lower__init_A_Unit18__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_36; var tmp2 any = A_arbace_classes_lower_clojure_method_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_clojure_method_A_Init(); tmp3 = A_arbace_classes_lower_clojure_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_37)); return A_arbace_classes_lower__init_A_const_36.Ref() }





















func A_arbace_classes_lower__init_A_Unit19__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(171, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_38; var tmp2 any = A_arbace_classes_lower_lower_reify_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_lower_reify_A_Init(); tmp3 = A_arbace_classes_lower_lower_reify_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_39)); return A_arbace_classes_lower__init_A_const_38.Ref() }
























func A_arbace_classes_lower__init_A_Unit20__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(196, 1); jrt.NN(A_arbace_classes_lower__init_A_const_40).BindRoot_O__V(A_arbace_classes_lower__init_A_const_41); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_40; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_42)); return A_arbace_classes_lower__init_A_const_40.Ref() }

func A_arbace_classes_lower__init_A_Unit21__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); jrt.NN(A_arbace_classes_lower__init_A_const_43).BindRoot_O__V(A_arbace_classes_lower__init_A_const_44); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_43; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_45)); return A_arbace_classes_lower__init_A_const_43.Ref() }



func A_arbace_classes_lower__init_A_Unit22__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_46; var tmp2 any = A_arbace_classes_lower_annotation_meta_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_annotation_meta_A_Init(); tmp3 = A_arbace_classes_lower_annotation_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_47)); return A_arbace_classes_lower__init_A_const_46.Ref() }

func A_arbace_classes_lower__init_A_Unit23__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(204, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_48; var tmp2 any = A_arbace_classes_lower_deftype_class_form_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_deftype_class_form_A_Init(); tmp3 = A_arbace_classes_lower_deftype_class_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_49)); return A_arbace_classes_lower__init_A_const_48.Ref() }














































































func A_arbace_classes_lower__init_A_Unit24__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(283, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_34; var tmp2 any = A_arbace_classes_lower_symbols_in_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_symbols_in_A_Init(); tmp3 = A_arbace_classes_lower_symbols_in_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_50)); return A_arbace_classes_lower__init_A_const_34.Ref() }








func A_arbace_classes_lower__init_A_Unit25__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(292, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_51; var tmp2 any = A_arbace_classes_lower_lower_letfn_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_lower_letfn_A_Init(); tmp3 = A_arbace_classes_lower_lower_letfn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_52)); return A_arbace_classes_lower__init_A_const_51.Ref() }





























func A_arbace_classes_lower__init_A_Unit26__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(322, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_53; var tmp2 any = A_arbace_classes_lower_lower_case_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_lower_case_A_Init(); tmp3 = A_arbace_classes_lower_lower_case_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_54)); return A_arbace_classes_lower__init_A_const_53.Ref() }







































func A_arbace_classes_lower__init_A_Unit27__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V(362, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_55; var tmp2 any = A_arbace_classes_lower_lower_def_A_New(); var tmp3 *jrt.Class; A_arbace_classes_lower_lower_def_A_Init(); tmp3 = A_arbace_classes_lower_lower_def_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_56)); return A_arbace_classes_lower__init_A_const_55.Ref() }



type A_arbace_classes_lower__init_A struct{ jrt.Object }

var A_arbace_classes_lower__init_A_const_0 *lang.Var

var A_arbace_classes_lower__init_A_const_1 any

var A_arbace_classes_lower__init_A_const_2 any

var A_arbace_classes_lower__init_A_const_3 any

var A_arbace_classes_lower__init_A_const_4 *lang.Var

var A_arbace_classes_lower__init_A_const_5 *lang.Var

var A_arbace_classes_lower__init_A_const_6 any

var A_arbace_classes_lower__init_A_const_7 any

var A_arbace_classes_lower__init_A_const_8 *lang.Var

var A_arbace_classes_lower__init_A_const_9 any

var A_arbace_classes_lower__init_A_const_10 *lang.Var

var A_arbace_classes_lower__init_A_const_11 any

var A_arbace_classes_lower__init_A_const_12 *lang.Var

var A_arbace_classes_lower__init_A_const_13 any

var A_arbace_classes_lower__init_A_const_14 any

var A_arbace_classes_lower__init_A_const_15 *lang.Var

var A_arbace_classes_lower__init_A_const_16 any

var A_arbace_classes_lower__init_A_const_17 *lang.Var

var A_arbace_classes_lower__init_A_const_18 any

var A_arbace_classes_lower__init_A_const_19 *lang.Var

var A_arbace_classes_lower__init_A_const_20 any

var A_arbace_classes_lower__init_A_const_21 *lang.Var

var A_arbace_classes_lower__init_A_const_22 any

var A_arbace_classes_lower__init_A_const_23 *lang.Var

var A_arbace_classes_lower__init_A_const_24 any

var A_arbace_classes_lower__init_A_const_25 *lang.Var

var A_arbace_classes_lower__init_A_const_26 any

var A_arbace_classes_lower__init_A_const_27 any

var A_arbace_classes_lower__init_A_const_28 *lang.Var

var A_arbace_classes_lower__init_A_const_29 any

var A_arbace_classes_lower__init_A_const_30 *lang.Var

var A_arbace_classes_lower__init_A_const_31 any

var A_arbace_classes_lower__init_A_const_32 *lang.Var

var A_arbace_classes_lower__init_A_const_33 any

var A_arbace_classes_lower__init_A_const_34 *lang.Var

var A_arbace_classes_lower__init_A_const_35 any

var A_arbace_classes_lower__init_A_const_36 *lang.Var

var A_arbace_classes_lower__init_A_const_37 any

var A_arbace_classes_lower__init_A_const_38 *lang.Var

var A_arbace_classes_lower__init_A_const_39 any

var A_arbace_classes_lower__init_A_const_40 *lang.Var

var A_arbace_classes_lower__init_A_const_41 any

var A_arbace_classes_lower__init_A_const_42 any

var A_arbace_classes_lower__init_A_const_43 *lang.Var

var A_arbace_classes_lower__init_A_const_44 any

var A_arbace_classes_lower__init_A_const_45 any

var A_arbace_classes_lower__init_A_const_46 *lang.Var

var A_arbace_classes_lower__init_A_const_47 any

var A_arbace_classes_lower__init_A_const_48 *lang.Var

var A_arbace_classes_lower__init_A_const_49 any

var A_arbace_classes_lower__init_A_const_50 any

var A_arbace_classes_lower__init_A_const_51 *lang.Var

var A_arbace_classes_lower__init_A_const_52 any

var A_arbace_classes_lower__init_A_const_53 *lang.Var

var A_arbace_classes_lower__init_A_const_54 any

var A_arbace_classes_lower__init_A_const_55 *lang.Var

var A_arbace_classes_lower__init_A_const_56 any

var A_arbace_classes_lower__init_A_init jrt.ClassInit

func A_arbace_classes_lower__init_A_Init() { if !A_arbace_classes_lower__init_A_init.Done() { A_arbace_classes_lower__init_A_init.Run(A_arbace_classes_lower__init_A_clinit) } }

func A_arbace_classes_lower__init_A_clinit() { A_arbace_classes_lower__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_297); A_arbace_classes_lower__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_classes_lower__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11)); A_arbace_classes_lower__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_lower__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_9, Lit_15); A_arbace_classes_lower__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_298); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_classes_lower__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_7 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_lower__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_9, Lit_66); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_classes_lower__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_301).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_96); A_arbace_classes_lower__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_303).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_304).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_305, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_9, Lit_35); A_arbace_classes_lower__init_A_const_13 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_306).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_307).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_308).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_309).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_310).Ref())).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_classes_lower__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_9, Lit_40); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_classes_lower__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_311).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_9, Lit_42); A_arbace_classes_lower__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_312).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_9, Lit_47); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_classes_lower__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_48).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_313, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_9, Lit_53); A_arbace_classes_lower__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_312).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_314).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_315, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_9, Lit_100); A_arbace_classes_lower__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_316, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_9, Lit_63); A_arbace_classes_lower__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_202, lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), Lit_203, lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), Lit_205, nil)); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_classes_lower__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(71).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_9, Lit_106); A_arbace_classes_lower__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_317).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_318).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_319).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_320, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(73).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_9, Lit_101); A_arbace_classes_lower__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_304).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_321, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(118).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_9, Lit_322); A_arbace_classes_lower__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_304).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_323, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_9, Lit_115); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_324).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_classes_lower__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(147).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_9, Lit_114); A_arbace_classes_lower__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_318).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_312).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_325).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_326, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(149).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_9, Lit_327); A_arbace_classes_lower__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_328).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_329).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_304).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_330, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(171).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_9, Lit_138); A_arbace_classes_lower__init_A_const_41 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,4,s6:__hashs8:__hasheqs8:__extmaps6:__meta", []*jrt.Class{jrt.Object_class})).Ref(); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_classes_lower__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(196).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_9, Lit_163); A_arbace_classes_lower__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_332).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_309).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_333).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_334).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_307).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_335).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_308).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_310).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_306).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_338).Ref())); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_classes_lower__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(198).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_9, Lit_142); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_classes_lower__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_233).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(202).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_9, Lit_339); A_arbace_classes_lower__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_340).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_342).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_303).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_343, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(204).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_304).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_344, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(283).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_9, Lit_345); A_arbace_classes_lower__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_346).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_325).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_347).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_348, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(292).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_9, Lit_349); A_arbace_classes_lower__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_350).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_352).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_353).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_354).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_355).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_356).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_357).Ref())), lang.Symbol_Intern_String_String__Symbol(nil, Lit_358).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_359, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(322).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)); A_arbace_classes_lower__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_9, Lit_360); A_arbace_classes_lower__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_300).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_361).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_303).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_362, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(362).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_299)) }

func A_arbace_classes_lower__init_A_New() *A_arbace_classes_lower__init_A { A_arbace_classes_lower__init_A_Init(); t := &A_arbace_classes_lower__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_lower__init_A) Ctor() {}

func (t *A_arbace_classes_lower__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower__init_A_class }

func (t *A_arbace_classes_lower__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower__init_A); return ok }

func A_arbace_classes_lower__init_A_Cast(x any) *A_arbace_classes_lower__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower__init_A_class)) }; return v }
