//line aot_arbace_classes_lower__init.ae:1
package aot_arbace_classes_lower

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_lower__init_A_Unit0__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_lower__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_lower__init_A_const_1) }
//line :1:1
func A_arbace_classes_lower__init_A_Unit1__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_lower__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_2)) }
//line :1:1
func A_arbace_classes_lower__init_A_Unit2__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_lower__init_A_Unit3__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_lower__init_A_const_1)).Equals_O__Z(A_arbace_classes_lower__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_lower_eval1304000008_fn__1304000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_lower_eval1304000008_fn__1304000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_classes_lower_eval1304000008_fn__1304000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_lower__init_A_Load__O() any { A_arbace_classes_lower__init_A_Init(); jrt.StartCheck(); A_arbace_classes_lower__init_A_Unit0__O(); A_arbace_classes_lower__init_A_Unit1__O(); A_arbace_classes_lower__init_A_Unit2__O(); A_arbace_classes_lower__init_A_Unit3__O(); A_arbace_classes_lower__init_A_Unit4__O(); A_arbace_classes_lower__init_A_Unit5__O(); A_arbace_classes_lower__init_A_Unit6__O(); A_arbace_classes_lower__init_A_Unit7__O(); A_arbace_classes_lower__init_A_Unit8__O(); A_arbace_classes_lower__init_A_Unit9__O(); A_arbace_classes_lower__init_A_Unit10__O(); A_arbace_classes_lower__init_A_Unit11__O(); A_arbace_classes_lower__init_A_Unit12__O(); A_arbace_classes_lower__init_A_Unit13__O(); A_arbace_classes_lower__init_A_Unit14__O(); A_arbace_classes_lower__init_A_Unit15__O(); A_arbace_classes_lower__init_A_Unit16__O(); A_arbace_classes_lower__init_A_Unit17__O(); A_arbace_classes_lower__init_A_Unit18__O(); A_arbace_classes_lower__init_A_Unit19__O(); A_arbace_classes_lower__init_A_Unit20__O(); A_arbace_classes_lower__init_A_Unit21__O(); A_arbace_classes_lower__init_A_Unit22__O(); A_arbace_classes_lower__init_A_Unit23__O(); A_arbace_classes_lower__init_A_Unit24__O(); A_arbace_classes_lower__init_A_Unit25__O(); A_arbace_classes_lower__init_A_Unit26__O(); A_arbace_classes_lower__init_A_Unit27__O(); return nil }






















func A_arbace_classes_lower__init_A_Unit4__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_4; var tmp2 any = A_arbace_classes_lower_next_id_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_lower_next_id_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_classes_lower_next_id_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_5)); return A_arbace_classes_lower__init_A_const_4 }

func A_arbace_classes_lower__init_A_Unit5__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_6; var tmp2 any = A_arbace_classes_lower_gsym_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_lower_gsym_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_classes_lower_gsym_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_7)); return A_arbace_classes_lower__init_A_const_6 }




func A_arbace_classes_lower__init_A_Unit6__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_8; var tmp2 any = A_arbace_classes_lower_fn_parts_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_lower_fn_parts_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_classes_lower_fn_parts_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_9)); return A_arbace_classes_lower__init_A_const_8 }









func A_arbace_classes_lower__init_A_Unit7__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); A_arbace_classes_lower__init_A_const_10.BindRoot_O__V(A_arbace_classes_lower__init_A_const_11); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_12)); return A_arbace_classes_lower__init_A_const_10 }

func A_arbace_classes_lower__init_A_Unit8__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_13; var tmp2 any = A_arbace_classes_lower_prim_tag_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_lower_prim_tag_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_classes_lower_prim_tag_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_14)); return A_arbace_classes_lower__init_A_const_13 }

func A_arbace_classes_lower__init_A_Unit9__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_15; var tmp2 any = A_arbace_classes_lower_variadic_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_lower_variadic_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_classes_lower_variadic_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_16)); return A_arbace_classes_lower__init_A_const_15 }

func A_arbace_classes_lower__init_A_Unit10__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_17; var tmp2 any = A_arbace_classes_lower_class_char_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_lower_class_char_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_classes_lower_class_char_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_18)); return A_arbace_classes_lower__init_A_const_17 }








func A_arbace_classes_lower__init_A_Unit11__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_19; var tmp2 any = A_arbace_classes_lower_prim_sig_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_lower_prim_sig_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_classes_lower_prim_sig_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_20)); return A_arbace_classes_lower__init_A_const_19 }










func A_arbace_classes_lower__init_A_Unit12__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_21; var tmp2 any = A_arbace_classes_lower_prim_interfaces_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_lower_prim_interfaces_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_classes_lower_prim_interfaces_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_22)); return A_arbace_classes_lower__init_A_const_21 }




func A_arbace_classes_lower__init_A_Unit13__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); A_arbace_classes_lower__init_A_const_23.BindRoot_O__V(A_arbace_classes_lower__init_A_const_24); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_25)); return A_arbace_classes_lower__init_A_const_23 }

func A_arbace_classes_lower__init_A_Unit14__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_26; var tmp2 any = A_arbace_classes_lower_fn_methods_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_lower_fn_methods_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_classes_lower_fn_methods_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_27)); return A_arbace_classes_lower__init_A_const_26 }












































func A_arbace_classes_lower__init_A_Unit15__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_28; var tmp2 any = A_arbace_classes_lower_fn_meta_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_lower_fn_meta_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_classes_lower_fn_meta_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_29)); return A_arbace_classes_lower__init_A_const_28 }





func A_arbace_classes_lower__init_A_Unit16__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_30; var tmp2 any = A_arbace_classes_lower_lower_fn_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_lower_lower_fn_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_classes_lower_lower_fn_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_31)); return A_arbace_classes_lower__init_A_const_30 }






















func A_arbace_classes_lower__init_A_Unit17__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_33)); return A_arbace_classes_lower__init_A_const_32 }

func A_arbace_classes_lower__init_A_Unit18__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_34; var tmp2 any = A_arbace_classes_lower_clojure_method_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_lower_clojure_method_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_classes_lower_clojure_method_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_35)); return A_arbace_classes_lower__init_A_const_34 }





















func A_arbace_classes_lower__init_A_Unit19__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_36; var tmp2 any = A_arbace_classes_lower_lower_reify_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_lower_lower_reify_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_classes_lower_lower_reify_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_37)); return A_arbace_classes_lower__init_A_const_36 }
























func A_arbace_classes_lower__init_A_Unit20__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); A_arbace_classes_lower__init_A_const_38.BindRoot_O__V(A_arbace_classes_lower__init_A_const_39); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_40)); return A_arbace_classes_lower__init_A_const_38 }

func A_arbace_classes_lower__init_A_Unit21__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); A_arbace_classes_lower__init_A_const_41.BindRoot_O__V(A_arbace_classes_lower__init_A_const_42); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_43)); return A_arbace_classes_lower__init_A_const_41 }



func A_arbace_classes_lower__init_A_Unit22__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_44; var tmp2 any = A_arbace_classes_lower_annotation_meta_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_lower_annotation_meta_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_classes_lower_annotation_meta_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_45)); return A_arbace_classes_lower__init_A_const_44 }

func A_arbace_classes_lower__init_A_Unit23__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_46; var tmp2 any = A_arbace_classes_lower_deftype_class_form_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_lower_deftype_class_form_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_classes_lower_deftype_class_form_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_47)); return A_arbace_classes_lower__init_A_const_46 }














































































func A_arbace_classes_lower__init_A_Unit24__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_32; var tmp2 any = A_arbace_classes_lower_symbols_in_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_lower_symbols_in_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_classes_lower_symbols_in_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_48)); return A_arbace_classes_lower__init_A_const_32 }








func A_arbace_classes_lower__init_A_Unit25__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_49; var tmp2 any = A_arbace_classes_lower_lower_letfn_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_lower_lower_letfn_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_classes_lower_lower_letfn_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_50)); return A_arbace_classes_lower__init_A_const_49 }





























func A_arbace_classes_lower__init_A_Unit26__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(327, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_51; var tmp2 any = A_arbace_classes_lower_lower_case_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_lower_lower_case_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_classes_lower_lower_case_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_52)); return A_arbace_classes_lower__init_A_const_51 }







































func A_arbace_classes_lower__init_A_Unit27__O() any { A_arbace_classes_lower__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.Var = A_arbace_classes_lower__init_A_const_53; var tmp2 any = A_arbace_classes_lower_lower_def_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_lower_lower_def_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_classes_lower_lower_def_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_lower__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_lower__init_A_const_54)); return A_arbace_classes_lower__init_A_const_53 }



type A_arbace_classes_lower__init_A struct{ jrt.Object }

var A_arbace_classes_lower__init_A_const_pool *jrt.RefArray

var A_arbace_classes_lower__init_A_const_0 *lang.Var

var A_arbace_classes_lower__init_A_const_1 any

var A_arbace_classes_lower__init_A_const_2 any

var A_arbace_classes_lower__init_A_const_3 any

var A_arbace_classes_lower__init_A_const_4 *lang.Var

var A_arbace_classes_lower__init_A_const_5 any

var A_arbace_classes_lower__init_A_const_6 *lang.Var

var A_arbace_classes_lower__init_A_const_7 any

var A_arbace_classes_lower__init_A_const_8 *lang.Var

var A_arbace_classes_lower__init_A_const_9 any

var A_arbace_classes_lower__init_A_const_10 *lang.Var

var A_arbace_classes_lower__init_A_const_11 any

var A_arbace_classes_lower__init_A_const_12 any

var A_arbace_classes_lower__init_A_const_13 *lang.Var

var A_arbace_classes_lower__init_A_const_14 any

var A_arbace_classes_lower__init_A_const_15 *lang.Var

var A_arbace_classes_lower__init_A_const_16 any

var A_arbace_classes_lower__init_A_const_17 *lang.Var

var A_arbace_classes_lower__init_A_const_18 any

var A_arbace_classes_lower__init_A_const_19 *lang.Var

var A_arbace_classes_lower__init_A_const_20 any

var A_arbace_classes_lower__init_A_const_21 *lang.Var

var A_arbace_classes_lower__init_A_const_22 any

var A_arbace_classes_lower__init_A_const_23 *lang.Var

var A_arbace_classes_lower__init_A_const_24 any

var A_arbace_classes_lower__init_A_const_25 any

var A_arbace_classes_lower__init_A_const_26 *lang.Var

var A_arbace_classes_lower__init_A_const_27 any

var A_arbace_classes_lower__init_A_const_28 *lang.Var

var A_arbace_classes_lower__init_A_const_29 any

var A_arbace_classes_lower__init_A_const_30 *lang.Var

var A_arbace_classes_lower__init_A_const_31 any

var A_arbace_classes_lower__init_A_const_32 *lang.Var

var A_arbace_classes_lower__init_A_const_33 any

var A_arbace_classes_lower__init_A_const_34 *lang.Var

var A_arbace_classes_lower__init_A_const_35 any

var A_arbace_classes_lower__init_A_const_36 *lang.Var

var A_arbace_classes_lower__init_A_const_37 any

var A_arbace_classes_lower__init_A_const_38 *lang.Var

var A_arbace_classes_lower__init_A_const_39 any

var A_arbace_classes_lower__init_A_const_40 any

var A_arbace_classes_lower__init_A_const_41 *lang.Var

var A_arbace_classes_lower__init_A_const_42 any

var A_arbace_classes_lower__init_A_const_43 any

var A_arbace_classes_lower__init_A_const_44 *lang.Var

var A_arbace_classes_lower__init_A_const_45 any

var A_arbace_classes_lower__init_A_const_46 *lang.Var

var A_arbace_classes_lower__init_A_const_47 any

var A_arbace_classes_lower__init_A_const_48 any

var A_arbace_classes_lower__init_A_const_49 *lang.Var

var A_arbace_classes_lower__init_A_const_50 any

var A_arbace_classes_lower__init_A_const_51 *lang.Var

var A_arbace_classes_lower__init_A_const_52 any

var A_arbace_classes_lower__init_A_const_53 *lang.Var

var A_arbace_classes_lower__init_A_const_54 any

var A_arbace_classes_lower__init_A_init jrt.ClassInit

func A_arbace_classes_lower__init_A_Init() { if !A_arbace_classes_lower__init_A_init.Done() { A_arbace_classes_lower__init_A_init.Run(A_arbace_classes_lower__init_A_clinit) } }

func A_arbace_classes_lower__init_A_clinit() { A_arbace_classes_lower__init_A_clinit_p0(); A_arbace_classes_lower__init_A_clinit_p1(); A_arbace_classes_lower__init_A_clinit_p2(); A_arbace_classes_lower__init_A_clinit_p3(); A_arbace_classes_lower__init_A_clinit_p4() }

func A_arbace_classes_lower__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_lower__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_81, 115); A_arbace_classes_lower__init_A_const_0 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[60]); A_arbace_classes_lower__init_A_const_1 = A_arbace_classes_lower__init_A_const_pool.A[61]; A_arbace_classes_lower__init_A_const_2 = A_arbace_classes_lower__init_A_const_pool.A[62]; A_arbace_classes_lower__init_A_const_3 = A_arbace_classes_lower__init_A_const_pool.A[63]; A_arbace_classes_lower__init_A_const_4 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[64]); A_arbace_classes_lower__init_A_const_5 = A_arbace_classes_lower__init_A_const_pool.A[65]; A_arbace_classes_lower__init_A_const_6 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[66]); A_arbace_classes_lower__init_A_const_7 = A_arbace_classes_lower__init_A_const_pool.A[67]; A_arbace_classes_lower__init_A_const_8 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[68]); A_arbace_classes_lower__init_A_const_9 = A_arbace_classes_lower__init_A_const_pool.A[69]; A_arbace_classes_lower__init_A_const_10 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[70]); A_arbace_classes_lower__init_A_const_11 = A_arbace_classes_lower__init_A_const_pool.A[71]; A_arbace_classes_lower__init_A_const_12 = A_arbace_classes_lower__init_A_const_pool.A[72] }

func A_arbace_classes_lower__init_A_clinit_p1() { A_arbace_classes_lower__init_A_const_13 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[73]); A_arbace_classes_lower__init_A_const_14 = A_arbace_classes_lower__init_A_const_pool.A[74]; A_arbace_classes_lower__init_A_const_15 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[75]); A_arbace_classes_lower__init_A_const_16 = A_arbace_classes_lower__init_A_const_pool.A[76]; A_arbace_classes_lower__init_A_const_17 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[77]); A_arbace_classes_lower__init_A_const_18 = A_arbace_classes_lower__init_A_const_pool.A[78]; A_arbace_classes_lower__init_A_const_19 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[79]); A_arbace_classes_lower__init_A_const_20 = A_arbace_classes_lower__init_A_const_pool.A[80]; A_arbace_classes_lower__init_A_const_21 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[81]); A_arbace_classes_lower__init_A_const_22 = A_arbace_classes_lower__init_A_const_pool.A[82]; A_arbace_classes_lower__init_A_const_23 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[83]); A_arbace_classes_lower__init_A_const_24 = A_arbace_classes_lower__init_A_const_pool.A[84]; A_arbace_classes_lower__init_A_const_25 = A_arbace_classes_lower__init_A_const_pool.A[85] }

func A_arbace_classes_lower__init_A_clinit_p2() { A_arbace_classes_lower__init_A_const_26 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[86]); A_arbace_classes_lower__init_A_const_27 = A_arbace_classes_lower__init_A_const_pool.A[87]; A_arbace_classes_lower__init_A_const_28 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[88]); A_arbace_classes_lower__init_A_const_29 = A_arbace_classes_lower__init_A_const_pool.A[89]; A_arbace_classes_lower__init_A_const_30 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[90]); A_arbace_classes_lower__init_A_const_31 = A_arbace_classes_lower__init_A_const_pool.A[91]; A_arbace_classes_lower__init_A_const_32 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[92]); A_arbace_classes_lower__init_A_const_33 = A_arbace_classes_lower__init_A_const_pool.A[93]; A_arbace_classes_lower__init_A_const_34 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[94]); A_arbace_classes_lower__init_A_const_35 = A_arbace_classes_lower__init_A_const_pool.A[95]; A_arbace_classes_lower__init_A_const_36 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[96]); A_arbace_classes_lower__init_A_const_37 = A_arbace_classes_lower__init_A_const_pool.A[97]; A_arbace_classes_lower__init_A_const_38 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[98]) }

func A_arbace_classes_lower__init_A_clinit_p3() { A_arbace_classes_lower__init_A_const_39 = A_arbace_classes_lower__init_A_const_pool.A[99]; A_arbace_classes_lower__init_A_const_40 = A_arbace_classes_lower__init_A_const_pool.A[100]; A_arbace_classes_lower__init_A_const_41 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[101]); A_arbace_classes_lower__init_A_const_42 = A_arbace_classes_lower__init_A_const_pool.A[102]; A_arbace_classes_lower__init_A_const_43 = A_arbace_classes_lower__init_A_const_pool.A[103]; A_arbace_classes_lower__init_A_const_44 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[104]); A_arbace_classes_lower__init_A_const_45 = A_arbace_classes_lower__init_A_const_pool.A[105]; A_arbace_classes_lower__init_A_const_46 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[106]); A_arbace_classes_lower__init_A_const_47 = A_arbace_classes_lower__init_A_const_pool.A[107]; A_arbace_classes_lower__init_A_const_48 = A_arbace_classes_lower__init_A_const_pool.A[108]; A_arbace_classes_lower__init_A_const_49 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[109]); A_arbace_classes_lower__init_A_const_50 = A_arbace_classes_lower__init_A_const_pool.A[110]; A_arbace_classes_lower__init_A_const_51 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[111]); A_arbace_classes_lower__init_A_const_52 = A_arbace_classes_lower__init_A_const_pool.A[112] }

func A_arbace_classes_lower__init_A_clinit_p4() { A_arbace_classes_lower__init_A_const_53 = lang.Var_Cast(A_arbace_classes_lower__init_A_const_pool.A[113]); A_arbace_classes_lower__init_A_const_54 = A_arbace_classes_lower__init_A_const_pool.A[114] }

func A_arbace_classes_lower__init_A_New() *A_arbace_classes_lower__init_A { A_arbace_classes_lower__init_A_Init(); t := &A_arbace_classes_lower__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_lower__init_A) Ctor() {}

func (t *A_arbace_classes_lower__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower__init_A_class }

func (t *A_arbace_classes_lower__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_lower__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower__init_A); return ok }

func A_arbace_classes_lower__init_A_Cast(x any) *A_arbace_classes_lower__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower__init_A_class)) }; return v }
