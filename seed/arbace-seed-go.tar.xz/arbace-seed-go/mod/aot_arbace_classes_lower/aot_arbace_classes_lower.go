//line aot_arbace_classes_lower.ae:1
package aot_arbace_classes_lower

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_New() *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A { A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_Init(); t := &A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :1:1
func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_New() *A_arbace_classes_lower_eval1304000008_fn__1304000009_A { A_arbace_classes_lower_eval1304000008_fn__1304000009_A_Init(); t := &A_arbace_classes_lower_eval1304000008_fn__1304000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }























func A_arbace_classes_lower_gsym_A_New() *A_arbace_classes_lower_gsym_A { A_arbace_classes_lower_gsym_A_Init(); t := &A_arbace_classes_lower_gsym_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_classes_lower_gsym_A) Ctor() {}
//line :25:1
func (t *A_arbace_classes_lower_gsym_A) Invoke_O_O__O(self, prefix__0 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_257, nil, Lit_258); var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_10; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_11; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 *lang.Var; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_12; return tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, prefix__0, nil, tmp5.Invoke_O_O__O(tmp7, jrt.NN(tmp8).GetRawRoot__O()), nil)).Ref()) }




func A_arbace_classes_lower_fn_parts_A_New() *A_arbace_classes_lower_fn_parts_A { A_arbace_classes_lower_fn_parts_A_Init(); t := &A_arbace_classes_lower_fn_parts_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_classes_lower_fn_parts_A) Ctor() {}
//line :30:1
func (t *A_arbace_classes_lower_fn_parts_A) Invoke_O_O__O(self, p__1304000013__0 any) any { var vec__1304000014__2 any = p__1304000013__0; var seq__1304000015__3 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; seq__1304000015__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1304000014__2); var first__1304000016__4 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_14; first__1304000016__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1304000015__3); var seq__1304000015__5 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_15; seq__1304000015__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1304000015__3); var ___6 any = first__1304000016__4; var more__7 any = seq__1304000015__5; var form__8 any = vec__1304000014__2; var vec__1304000017__9 any; var tmp4 *lang.Var; _ = ___6;


	A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_16; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_14; if jrt.A2g_Truth(tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(more__7))) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_14; var tmp8 any = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(more__7); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_21; vec__1304000017__9 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(more__7)) } else { vec__1304000017__9 = lang.Tuple_Create_O_O__IPersistentVector(nil, more__7) }; var nm__10 any = /*line :30:1*/lang.RT_Nth_O_I_O__O(vec__1304000017__9, lang.RT_IntCast_J__I(0), nil); var more__11 any = lang.RT_Nth_O_I_O__O(vec__1304000017__9, lang.RT_IntCast_J__I(1), nil); var arities__12 any; var tmp10 *lang.Var;



	A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_17; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_14; if jrt.A2g_Truth(tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(more__11))) { arities__12 = lang.Tuple_Create_O__IPersistentVector(more__11) } else { arities__12 = more__11 }; var seq_1304000020__13 any; var tmp13 /*line :30:1*/*lang.Var;




	A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_13; seq_1304000020__13 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(arities__12); var chunk_1304000021__14 any; var count_1304000022__15 int64 = 0; var i_1304000023__16 int64 = 0; L1:
//line :30:1
	for {




		if lang.Numbers_Lt_J_J__Z(i_1304000023__16, count_1304000022__15) { var a__17 any = lang.Indexed_Cast(chunk_1304000021__14).Nth_I__O(lang.RT_IntCast_J__I(i_1304000023__16)); var tmp14 any; var and__1927000168__auto____18 any; var tmp15 *lang.Var
			A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_24; and__1927000168__auto____18 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(a__17); if jrt.A2g_Truth(and__1927000168__auto____18) { var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_17; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_14; tmp14 = tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(a__17)) } else { tmp14 = and__1927000168__auto____18 }; if jrt.A2g_Truth(tmp14) { } else { var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_25; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_254, nil); var tmp22 *lang.Var; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_26; var tmp23 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(form__8))).Ref(); var tmp24 any; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_27; panic(jrt.Thrown(jrt.Throwable_Cast(tmp20.Invoke_O_O__O(tmp23, tmp24)))) }
//line :35:1
			seq_1304000020__13, chunk_1304000021__14, count_1304000022__15, i_1304000023__16 = seq_1304000020__13, chunk_1304000021__14, count_1304000022__15, lang.Numbers_Unchecked_inc_J__J(i_1304000023__16); continue L1 } else { var temp__1927000414__auto____17 any; var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____17 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_1304000020__13); if jrt.A2g_Truth(temp__1927000414__auto____17) { var seq_1304000020__18 any = temp__1927000414__auto____17; var tmp26 *lang.Var; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_1304000020__18)) { var c__1927000678__auto____19 any; var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_23; c__1927000678__auto____19 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_1304000020__18); var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_28; seq_1304000020__13, chunk_1304000021__14, count_1304000022__15, i_1304000023__16 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_1304000020__18), c__1927000678__auto____19, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var a__19 any; var tmp29 *lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_14; a__19 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_1304000020__18)
				var tmp30 any; var and__1927000168__auto____20 any; var tmp31 *lang.Var; A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_24; and__1927000168__auto____20 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(a__19); if jrt.A2g_Truth(and__1927000168__auto____20) { var tmp32 *lang.Var; A_arbace_classes_lower_A_Init(); tmp32 = A_arbace_classes_lower_A_const_17; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_classes_lower_A_Init(); tmp34 = A_arbace_classes_lower_A_const_14; tmp30 = tmp33.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(a__19)) } else { tmp30 = and__1927000168__auto____20 }; if jrt.A2g_Truth(tmp30) { } else { var tmp35 *lang.Var; A_arbace_classes_lower_A_Init(); tmp35 = A_arbace_classes_lower_A_const_25; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_254, nil); var tmp38 *lang.Var; A_arbace_classes_lower_A_Init(); tmp38 = A_arbace_classes_lower_A_const_26; var tmp39 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(form__8))).Ref(); var tmp40 any; A_arbace_classes_lower_A_Init(); tmp40 = A_arbace_classes_lower_A_const_29; panic(jrt.Thrown(jrt.Throwable_Cast(tmp36.Invoke_O_O__O(tmp39, tmp40)))) }
//line :35:1
				var tmp41 *lang.Var; A_arbace_classes_lower_A_Init(); tmp41 = A_arbace_classes_lower_A_const_15; seq_1304000020__13, chunk_1304000021__14, count_1304000022__15, i_1304000023__16 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_1304000020__18), nil, 0, 0; continue L1 } } }
//line :30:1
		break L1 }; var tmp42 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp42 = A_arbace_classes_lower_A_const_18; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp44 = A_arbace_classes_lower_A_const_19; var tmp45 any = tmp44.Ref(); var tmp46 *lang.Var; A_arbace_classes_lower_A_Init(); tmp46 = A_arbace_classes_lower_A_const_20; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any = A_arbace_classes_lower_fn_parts_fn__1304000025_A_New(); var tmp49 *jrt.Class; A_arbace_classes_lower_fn_parts_fn__1304000025_A_Init(); tmp49 = A_arbace_classes_lower_fn_parts_fn__1304000025_A_fn_class; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, nm__10, tmp45, tmp47.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp48, tmp49, nil), arities__12))) }







func A_arbace_classes_lower_fn_parts_fn__1304000025_A_New() *A_arbace_classes_lower_fn_parts_fn__1304000025_A { A_arbace_classes_lower_fn_parts_fn__1304000025_A_Init(); t := &A_arbace_classes_lower_fn_parts_fn__1304000025_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) Invoke_O_O__O(self, p__1304000024__1 any) any { var vec__1304000026__2 any = p__1304000024__1; var seq__1304000027__3 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; seq__1304000027__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1304000026__2); var first__1304000028__4 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_14; first__1304000028__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1304000027__3); var seq__1304000027__5 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_15; seq__1304000027__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1304000027__3); var pv__6 any = first__1304000028__4; var body__7 any = seq__1304000027__5; return lang.Tuple_Create_O_O__IPersistentVector(pv__6, body__7) }



func A_arbace_classes_lower_prim_tag_QMARK__A_New() *A_arbace_classes_lower_prim_tag_QMARK__A { A_arbace_classes_lower_prim_tag_QMARK__A_Init(); t := &A_arbace_classes_lower_prim_tag_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_classes_lower_prim_tag_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_classes_lower_prim_tag_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_16; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_30; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0), nil); if and__1927000168__auto____3 { var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_31; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_classes_lower_variadic_QMARK__A_New() *A_arbace_classes_lower_variadic_QMARK__A { A_arbace_classes_lower_variadic_QMARK__A_Init(); t := &A_arbace_classes_lower_variadic_QMARK__A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_classes_lower_variadic_QMARK__A) Ctor() {}
//line :44:1
func (t *A_arbace_classes_lower_variadic_QMARK__A) Invoke_O_O__O(self, p__1304000032__0 any) any { var vec__1304000033__2 any = p__1304000032__0; var pv__3 any = lang.RT_Nth_O_I_O__O(vec__1304000033__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1304000033__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; _ = ___4; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_32; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_33; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp2.Invoke_O_O__O(tmp3, pv__3))).Ref() }

func A_arbace_classes_lower_class_char_A_New() *A_arbace_classes_lower_class_char_A { A_arbace_classes_lower_class_char_A_Init(); t := &A_arbace_classes_lower_class_char_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_lower_class_char_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_lower_class_char_A) Invoke_O_O__O(self, tag__0 any) any {


	var tmp1 any; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_34; if lang.Util_Equiv_O_O__Z(tmp1, tag__0) { return Lit_202 } else { var tmp2 any; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_35; if lang.Util_Equiv_O_O__Z(tmp2, tag__0) { return Lit_203 } else { var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(tag__0)) { var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_25; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_38; panic(jrt.Thrown(jrt.Throwable_Cast(tmp5.Invoke_O_O__O(Lit_204, tmp6)))) } else { var tmp7 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_37; if tmp7 != nil { return Lit_205 } else { return nil
	}
	}
	}
	}
}
func A_arbace_classes_lower_prim_sig_A_New() *A_arbace_classes_lower_prim_sig_A { A_arbace_classes_lower_prim_sig_A_Init(); t := &A_arbace_classes_lower_prim_sig_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_classes_lower_prim_sig_A) Ctor() {}
//line :55:1
func (t *A_arbace_classes_lower_prim_sig_A) Invoke_O_O__O(self, p__1304000039__0 any) any { var vec__1304000040__2 any = p__1304000039__0; var pv__3 any = lang.RT_Nth_O_I_O__O(vec__1304000040__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1304000040__2, lang.RT_IntCast_J__I(1), nil); var arity__5 any = vec__1304000040__2; var tmp1 *lang.Var; _ = ___4;



	A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(arity__5)) { return nil } else { var sig__6 any; var tmp2 *lang.Var
		A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_40; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_42; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_43; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_44; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_classes_lower_prim_sig_fn__1304000043_A_New(); var tmp11 *jrt.Class; A_arbace_classes_lower_prim_sig_fn__1304000043_A_Init(); tmp11 = A_arbace_classes_lower_prim_sig_fn__1304000043_A_fn_class; var tmp12 any = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), pv__3); var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_45; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_46; var tmp16 *lang.Keyword = tmp15; sig__6 = tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp12, lang.Tuple_Create_O__IPersistentVector(tmp14.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(pv__3))))))
		var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_41; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_47; if jrt.A2g_Truth(tmp18.Invoke_O_O__O(tmp19, sig__6)) {
			if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(pv__3)), 4) { var tmp20 *lang.Var; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_25; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_48; panic(jrt.Thrown(jrt.Throwable_Cast(tmp21.Invoke_O_O__O(Lit_292, tmp22)))) }
//line :61:1
			return sig__6 } else { return nil } } }
//line :60:1
func A_arbace_classes_lower_prim_sig_fn__1304000043_A_New() *A_arbace_classes_lower_prim_sig_fn__1304000043_A { A_arbace_classes_lower_prim_sig_fn__1304000043_A_Init(); t := &A_arbace_classes_lower_prim_sig_fn__1304000043_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) Invoke_O_O__O(self, p1__1304000038_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_46; var tmp4 *lang.Keyword = tmp3; return tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1304000038_SHARP___1))) }





func A_arbace_classes_lower_prim_interfaces_A_New() *A_arbace_classes_lower_prim_interfaces_A { A_arbace_classes_lower_prim_interfaces_A_Init(); t := &A_arbace_classes_lower_prim_interfaces_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_classes_lower_prim_interfaces_A) Ctor() {}
//line :66:1
func (t *A_arbace_classes_lower_prim_interfaces_A) Invoke_O_O__O(self, arities__0 any) any {


	var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var iter__1927001039__auto____2 any; var tmp6 any = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_New(); var tmp7 *jrt.Class; A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_Init(); tmp7 = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(arities__0); return tmp2.Invoke_O__O(tmp4.Invoke_O__O(tmp5)) }
//line :69:1
func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_New() *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_Init(); t := &A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) Ctor() {}
//line :69:1
func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) Invoke_O_O__O(self, s__1304000047__1 any) any { var tmp1 any = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_New_O_O(self, s__1304000047__1); var tmp2 *jrt.Class; A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_Init(); tmp2 = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :69:1
func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_New_O_O(p0, p1 any) *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_Init(); t := &A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) Ctor_O_O(c__iter__1304000046, c__s__1304000047 any) { t.F_iter__1304000046 = c__iter__1304000046; t.F_s__1304000047 = c__s__1304000047 }
//line :69:1
func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) Invoke_O__O(self any) any { { var s__1304000047__1 any; var t_ any = t.F_s__1304000047; t.F_s__1304000047 = nil; s__1304000047__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000047__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000047__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000047__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000047__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000049__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000049__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_New_O_I_O(b__1304000049__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_Init(); tmp6 = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000049__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000046); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000047__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000049__6), nil) } } else { var a__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; a__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000047__3); var sig__5 any; var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_52; sig__5 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(a__4); if jrt.A2g_Truth(sig__5) { var tmp18 *lang.Var; A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_56; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_9; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_289, nil); var tmp23 any; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_54; var tmp24 any = tmp21.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, nil, sig__5)).Ref()); var tmp25 lang.IFn = lang.IFn_Cast(t.F_iter__1304000046); var tmp26 *lang.Var; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_21; return tmp19.Invoke_O_O__O(tmp24, tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(s__1304000047__3))) } else { var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_21; s__1304000047__1 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__1304000047__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :69:1
func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_Init(); t := &A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :69:1
func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) Ctor_O_I_O(c__b__1304000049 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000049 = c__b__1304000049; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :69:1
func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) Invoke_O__O(self any) any { { var i__1304000048__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000048__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var a__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000048__1)); var sig__3 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_52; sig__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(a__2); if jrt.A2g_Truth(sig__3) { var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_53; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_b__1304000049; var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_9; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_289, nil); var tmp9 any; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_54; tmp4.Invoke_O_O__O(tmp5, tmp7.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, sig__3)).Ref())); i__1304000048__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000048__1); continue L1 } else { i__1304000048__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000048__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_classes_lower_fn_methods_A_New() *A_arbace_classes_lower_fn_methods_A { A_arbace_classes_lower_fn_methods_A_Init(); t := &A_arbace_classes_lower_fn_methods_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_classes_lower_fn_methods_A) Ctor() {}
//line :73:1
func (t *A_arbace_classes_lower_fn_methods_A) Invoke_O_O_O_O_O__O(self, rcv__0, nm__1, arities__2, binds__3 any) any { var vs__5 any; var tmp1 *lang.Var;







	A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_58; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_39; vs__5 = tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), arities__2); if
	lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(vs__5)), 1) { var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_25; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_59; panic(jrt.Thrown(jrt.Throwable_Cast(tmp5.Invoke_O_O__O(Lit_244, tmp6)))) }; var tmp7 /*line :84:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_43; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_60; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_classes_lower_fn_methods_fn__1304000060_A_New_O_O_O(rcv__0, binds__3, nm__1); var tmp12 *jrt.Class; A_arbace_classes_lower_fn_methods_fn__1304000060_A_Init(); tmp12 = A_arbace_classes_lower_fn_methods_fn__1304000060_A_fn_class; var tmp13 any = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), arities__2); var tmp14 lang.IPersistentVector; var temp__1927000414__auto____6 any; var tmp15 *lang.Var;





























	A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_14; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(vs__5); if jrt.A2g_Truth(temp__1927000414__auto____6) { var vec__1304000082__7 any = temp__1927000414__auto____6; var pv__8 any = lang.RT_Nth_O_I_O__O(vec__1304000082__7, lang.RT_IntCast_J__I(0), nil); var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_62; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_93; var tmp19 any = tmp18; var tmp20 *lang.Var; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_64; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_95; var tmp23 any = tmp22; var tmp24 any; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_96; var tmp25 any = tmp21.Invoke_O_O__O(tmp23, tmp24); var tmp26 *lang.Var; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_64; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 any = lang.Tuple_Create_O__IPersistentVector(rcv__0); var tmp29 any; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_97; var tmp30 any = tmp27.Invoke_O_O__O(tmp28, tmp29); var tmp31 *lang.Var; A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_94; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any = A_arbace_classes_lower_fn_methods_fn__1304000085_A_New(); var tmp34 *jrt.Class; A_arbace_classes_lower_fn_methods_fn__1304000085_A_Init(); tmp34 = A_arbace_classes_lower_fn_methods_fn__1304000085_A_fn_class; tmp14 = lang.Tuple_Create_O__IPersistentVector(tmp17.Invoke_O_O_O_O__O(tmp19, tmp25, tmp30, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp32.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil), pv__8))).Ref())) } else { tmp14 = nil }; return /*line :84:1*/ tmp8.Invoke_O_O__O(tmp13, tmp14) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_lower_fn_methods_fn__1304000060_A { A_arbace_classes_lower_fn_methods_fn__1304000060_A_Init(); t := &A_arbace_classes_lower_fn_methods_fn__1304000060_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :86:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) Ctor_O_O_O(c__rcv, c__binds, c__nm any) { t.F_rcv = c__rcv; t.F_binds = c__binds; t.F_nm = c__nm }
//line :86:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) Invoke_O_O__O(self, p__1304000059__1 any) any { var vec__1304000061__2 any = p__1304000059__1; var pv__3 any = lang.RT_Nth_O_I_O__O(vec__1304000061__2, lang.RT_IntCast_J__I(0), nil); var body__4 any = lang.RT_Nth_O_I_O__O(vec__1304000061__2, lang.RT_IntCast_J__I(1), nil); var arity__5 any = vec__1304000061__2; var vec__1304000064__6 any; var tmp1 *lang.Var;
														A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_61; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_New(); var tmp4 *jrt.Class; A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_Init(); tmp4 = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_fn_class; vec__1304000064__6 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), pv__3); var fixed__7 any = /*line :86:1*/lang.RT_Nth_O_I_O__O(vec__1304000064__6, lang.RT_IntCast_J__I(0), nil); var vec__1304000067__8 any = lang.RT_Nth_O_I_O__O(vec__1304000064__6, lang.RT_IntCast_J__I(1), nil); var ___9 any = lang.RT_Nth_O_I_O__O(vec__1304000067__8, lang.RT_IntCast_J__I(0), nil); var rest_p__10 any = lang.RT_Nth_O_I_O__O(vec__1304000067__8, lang.RT_IntCast_J__I(1), nil); var params__11 any; var tmp5 *lang.Var; _ = ___9;

	A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_49; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_43; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 lang.IPersistentVector; if jrt.A2g_Truth(rest_p__10) { tmp9 = lang.Tuple_Create_O__IPersistentVector(rest_p__10) } else { tmp9 = nil }; params__11 = tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(fixed__7, tmp9)); var args__12 any; var tmp10 /*line :86:1*/*lang.Var;


	A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_20; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_New(); var tmp13 *jrt.Class; A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_Init(); tmp13 = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_fn_class; args__12 = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), params__11); var sig__13 any; var tmp14 /*line :86:1*/*lang.Var;



	A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_52; sig__13 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(arity__5); var lbinds__14 any; var tmp15 /*line :86:1*/*lang.Var;





	A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_49; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_60; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_New_O(rest_p__10); var tmp20 *jrt.Class; A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_Init(); tmp20 = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_fn_class; lbinds__14 = tmp16.Invoke_O__O(tmp18.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), params__11, args__12)); var body_form__15 any; var tmp21 /*line :86:1*/*lang.Var;







	A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_62; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_70; var tmp24 any = tmp23; var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_49; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_43; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any = t.F_binds; var tmp30 lang.IPersistentVector; if jrt.A2g_Truth(t.F_nm) { tmp30 = lang.Tuple_Create_O_O__IPersistentVector(t.F_nm, t.F_rcv) } else { tmp30 = nil }; var tmp31 any = tmp26.Invoke_O__O(tmp28.Invoke_O_O__O(tmp29, tmp30)); var tmp32 *lang.Var; A_arbace_classes_lower_A_Init(); tmp32 = A_arbace_classes_lower_A_const_71; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_classes_lower_A_Init(); tmp34 = A_arbace_classes_lower_A_const_64; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any; A_arbace_classes_lower_A_Init(); tmp36 = A_arbace_classes_lower_A_const_72; var tmp37 any = tmp36; var tmp38 any; A_arbace_classes_lower_A_Init(); tmp38 = A_arbace_classes_lower_A_const_73; body_form__15 = tmp22.Invoke_O_O_O__O(tmp24, tmp31, tmp33.Invoke_O_O_O__O(tmp35.Invoke_O_O__O(tmp37, tmp38), lbinds__14, body__4)); if

	jrt.A2g_Truth(sig__13) { var ptypes__16 any; var tmp39 *lang.Var
		A_arbace_classes_lower_A_Init(); tmp39 = A_arbace_classes_lower_A_const_44; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_classes_lower_A_Init(); tmp41 = A_arbace_classes_lower_A_const_74; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_classes_lower_A_Init(); tmp43 = A_arbace_classes_lower_A_const_63; var tmp44 any = jrt.NN(tmp43).GetRawRoot__O(); var tmp45 *lang.Var; A_arbace_classes_lower_A_Init(); tmp45 = A_arbace_classes_lower_A_const_42; var tmp46 any = tmp42.Invoke_O_O__O(tmp44, jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_classes_lower_A_Init(); tmp47 = A_arbace_classes_lower_A_const_75; ptypes__16 = tmp40.Invoke_O_O__O(tmp46, lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(sig__13))
//line :96:1
		var rtype__17 any; var tmp48 *lang.Var

		A_arbace_classes_lower_A_Init(); tmp48 = A_arbace_classes_lower_A_const_63; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_classes_lower_A_Init(); tmp50 = A_arbace_classes_lower_A_const_42; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_classes_lower_A_Init(); tmp52 = A_arbace_classes_lower_A_const_76; rtype__17 = tmp49.Invoke_O__O(tmp51.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(sig__13)))
//line :96:1
		var typed__18 any; var tmp53 any = A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_New(); var tmp54 *jrt.Class


		A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_Init(); tmp54 = A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_fn_class; typed__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil)
//line :96:1
		var tmp55 *lang.Var; A_arbace_classes_lower_A_Init(); tmp55 = A_arbace_classes_lower_A_const_62; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any; A_arbace_classes_lower_A_Init(); tmp57 = A_arbace_classes_lower_A_const_77; var tmp58 any = tmp57; var tmp59 *lang.Var; A_arbace_classes_lower_A_Init(); tmp59 = A_arbace_classes_lower_A_const_64; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_classes_lower_A_Init(); tmp61 = A_arbace_classes_lower_A_const_78; var tmp62 any = tmp61; var tmp63 any; A_arbace_classes_lower_A_Init(); tmp63 = A_arbace_classes_lower_A_const_79; var tmp64 any = tmp60.Invoke_O_O__O(tmp62, tmp63); var tmp65 *lang.Var; A_arbace_classes_lower_A_Init(); tmp65 = A_arbace_classes_lower_A_const_64; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Var; A_arbace_classes_lower_A_Init(); tmp67 = A_arbace_classes_lower_A_const_49; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Var; A_arbace_classes_lower_A_Init(); tmp69 = A_arbace_classes_lower_A_const_56; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 any = t.F_rcv; var tmp72 *lang.Var; A_arbace_classes_lower_A_Init(); tmp72 = A_arbace_classes_lower_A_const_44; var tmp73 any = tmp68.Invoke_O__O(tmp70.Invoke_O_O__O(tmp71, lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O_O_O__O(typed__18, args__12, ptypes__16))); var tmp74 lang.IPersistentMap




		if jrt.A2g_Truth(rtype__17) { var tmp75 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp75 = A_arbace_classes_lower_A_const_46; tmp74 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp75.Ref(), rtype__17)) } else { lang.PersistentArrayMap_Init(); tmp74 = Up_PersistentArrayMap_IPersistentMap(lang.PersistentArrayMap_EMPTY) }
//line :96:1
		var tmp76 any = tmp56.Invoke_O_O_O_O__O(tmp58, tmp64, tmp66.Invoke_O_O__O(tmp73, tmp74), body_form__15); var tmp77 *lang.Var; A_arbace_classes_lower_A_Init(); tmp77 = A_arbace_classes_lower_A_const_62; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 any; A_arbace_classes_lower_A_Init(); tmp79 = A_arbace_classes_lower_A_const_80; var tmp80 any = tmp79; var tmp81 *lang.Var; A_arbace_classes_lower_A_Init(); tmp81 = A_arbace_classes_lower_A_const_64; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 any; A_arbace_classes_lower_A_Init(); tmp83 = A_arbace_classes_lower_A_const_81; var tmp84 any = tmp83; var tmp85 any; A_arbace_classes_lower_A_Init(); tmp85 = A_arbace_classes_lower_A_const_82; var tmp86 any = tmp82.Invoke_O_O__O(tmp84, tmp85); var tmp87 *lang.Var; A_arbace_classes_lower_A_Init(); tmp87 = A_arbace_classes_lower_A_const_49; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 *lang.Var; A_arbace_classes_lower_A_Init(); tmp89 = A_arbace_classes_lower_A_const_56; var tmp90 any = tmp88.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()).Invoke_O_O__O(t.F_rcv, args__12)); var tmp91 *lang.Var; A_arbace_classes_lower_A_Init(); tmp91 = A_arbace_classes_lower_A_const_71; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 any; A_arbace_classes_lower_A_Init(); tmp93 = A_arbace_classes_lower_A_const_83; var tmp94 any = tmp93; var tmp95 any = t.F_rcv; var tmp96 *lang.Var; A_arbace_classes_lower_A_Init(); tmp96 = A_arbace_classes_lower_A_const_44; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 any = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_New(); var tmp99 *jrt.Class; A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_Init(); tmp99 = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_fn_class; return lang.Tuple_Create_O_O__IPersistentVector(tmp76, tmp78.Invoke_O_O_O_O__O(tmp80, tmp86, tmp90, tmp92.Invoke_O_O_O__O(tmp94, tmp95, tmp97.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp98, tmp99, nil), args__12, ptypes__16)))) } else { var tmp100 *lang.Var; A_arbace_classes_lower_A_Init(); tmp100 = A_arbace_classes_lower_A_const_62; var tmp101 lang.IFn = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()); var tmp102 any; A_arbace_classes_lower_A_Init(); tmp102 = A_arbace_classes_lower_A_const_88; var tmp103 any = tmp102; var tmp104 *lang.Var; A_arbace_classes_lower_A_Init(); tmp104 = A_arbace_classes_lower_A_const_64; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 any













			if jrt.A2g_Truth(rest_p__10) { A_arbace_classes_lower_A_Init(); tmp106 = A_arbace_classes_lower_A_const_89 } else { A_arbace_classes_lower_A_Init(); tmp106 = A_arbace_classes_lower_A_const_90 }
//line :96:1
			var tmp107 any = tmp106; var tmp108 *lang.Keyword













			if jrt.A2g_Truth(rest_p__10) { A_arbace_classes_lower_A_Init(); tmp108 = A_arbace_classes_lower_A_const_91 } else { A_arbace_classes_lower_A_Init(); tmp108 = A_arbace_classes_lower_A_const_92 }
//line :96:1
			var tmp109 any = tmp108.Ref(); var tmp110 *jrt.Boolean; jrt.Boolean_Init(); tmp110 = jrt.Boolean_TRUE; var tmp111 any = tmp105.Invoke_O_O__O(tmp107, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp109, tmp110.Ref()))); var tmp112 *lang.Var; A_arbace_classes_lower_A_Init(); tmp112 = A_arbace_classes_lower_A_const_49; var tmp113 lang.IFn = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()); var tmp114 *lang.Var; A_arbace_classes_lower_A_Init(); tmp114 = A_arbace_classes_lower_A_const_56; return lang.Tuple_Create_O__IPersistentVector(tmp101.Invoke_O_O_O_O__O(tmp103, tmp111, tmp113.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp114).GetRawRoot__O()).Invoke_O_O__O(t.F_rcv, args__12)), body_form__15)) } }
//line :87:1
func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_New() *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_Init(); t := &A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) Ctor() {}
//line :87:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) Invoke_O_O__O(self, p1__1304000057_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_65; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_66; return tmp2.Invoke_O_O__O(tmp3, p1__1304000057_SHARP___1) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_New() *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_Init(); t := &A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) Ctor() {}
//line :89:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) Invoke_O_O__O(self, ___1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_67; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_248) }


func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_New_O(p0 any) *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_Init(); t := &A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) Ctor_O(c__rest_p any) { t.F_rest_p = c__rest_p }
//line :92:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) Invoke_O_O_O__O(self, p__1, a__2 any) any { var tmp1 any; if lang.Util_Equiv_O_O__Z(p__1, t.F_rest_p) { var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_68; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_69; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_46; tmp1 = tmp3.Invoke_O_O_O__O(p__1, tmp5, tmp6.Ref()) } else { tmp1 = p__1 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, a__2) }






func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_New() *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A { A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_Init(); t := &A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) Ctor() {}
//line :99:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) Invoke_O_O_O__O(self, a__1, t__2 any) any { if jrt.A2g_Truth(t__2) { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_64; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_46; return tmp2.Invoke_O_O__O(a__1, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3.Ref(), t__2))) } else { return a__1 } }





func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_New() *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_Init(); t := &A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) Ctor() {}
//line :105:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) Invoke_O_O_O__O(self, a__1, t__2 any) any { var G__1304000079__3_ any = t__2; switch lang.Util_Hash_O__I(G__1304000079__3_) >> 3 & 1 { case 0: var tmp1 any; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_84; if lang.Util_Equiv_O_O__Z(G__1304000079__3_, tmp1) {
															var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_62; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_86; return tmp3.Invoke_O_O__O(tmp4, a__1) }
//line :105:1
case 1: var tmp5 any; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_85; if lang.Util_Equiv_O_O__Z(G__1304000079__3_, tmp5) {

	var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_62; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_87; return tmp7.Invoke_O_O__O(tmp8, a__1) }
//line :105:1
default:}; return a__1 }










func A_arbace_classes_lower_fn_methods_fn__1304000085_A_New() *A_arbace_classes_lower_fn_methods_fn__1304000085_A { A_arbace_classes_lower_fn_methods_fn__1304000085_A_Init(); t := &A_arbace_classes_lower_fn_methods_fn__1304000085_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) Ctor() {}
//line :116:1
func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) Invoke_O_O__O(self, p1__1304000058_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_65; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_98; return tmp2.Invoke_O_O__O(tmp3, p1__1304000058_SHARP___1) }

func A_arbace_classes_lower_fn_meta_A_New() *A_arbace_classes_lower_fn_meta_A { A_arbace_classes_lower_fn_meta_A_Init(); t := &A_arbace_classes_lower_fn_meta_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_lower_fn_meta_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_lower_fn_meta_A) Invoke_O_O__O(self, form__0 any) any { var m__2 any; var tmp1 *lang.Var;


	A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.RT_Meta_O__IPersistentMap(form__0); var tmp4 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_99; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_100; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_101; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_102; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_103; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_104; m__2 = tmp2.Invoke_O_O_O_O_O_O_O__O(tmp3, tmp5, tmp7, tmp9, tmp11, tmp13, tmp14.Ref()); var tmp15 /*line :122:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(m__2)) { return m__2 } else { return nil } }

func A_arbace_classes_lower_lower_fn_A_New() *A_arbace_classes_lower_lower_fn_A { A_arbace_classes_lower_lower_fn_A_Init(); t := &A_arbace_classes_lower_lower_fn_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_classes_lower_lower_fn_A) Ctor() {}
//line :124:1
func (t *A_arbace_classes_lower_lower_fn_A) Invoke_O_O__O(self, form__0 any) any { var map__1304000089__2 any; var tmp1 *lang.Var;



	A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_105; map__1304000089__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__0); var map__1304000089__3 any; if lang.ISeq_InstanceOf(map__1304000089__2) { var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1304000089__2)) { var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_106; map__1304000089__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1304000089__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1304000089__2)) { var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_14; map__1304000089__3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1304000089__2) } else { lang.PersistentArrayMap_Init(); map__1304000089__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1304000089__3 = map__1304000089__2 }; var nm__4 any; var tmp6 /*line :124:1*/*lang.Keyword;



	A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_18; nm__4 = lang.RT_Get_O_O__O(map__1304000089__3, tmp6.Ref()); var arities__5 any; var tmp7 /*line :124:1*/*lang.Keyword;



	A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_19; arities__5 = lang.RT_Get_O_O__O(map__1304000089__3, tmp7.Ref()); var rcv__6 any; var tmp8 /*line :124:1*/*lang.Var;




	A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_67; rcv__6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(Lit_267); var super__7 any; var tmp9 /*line :124:1*/*lang.Var;





	A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_32; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_39; if jrt.A2g_Truth(tmp10.Invoke_O_O__O(jrt.NN(tmp11).GetRawRoot__O(), arities__5)) { A_arbace_classes_lower_A_Init(); super__7 = A_arbace_classes_lower_A_const_107 } else { A_arbace_classes_lower_A_Init(); super__7 = A_arbace_classes_lower_A_const_108 }; var ifaces__8 any; var tmp12 /*line :124:1*/*lang.Var;






	A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_109; ifaces__8 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(arities__5); var anon__9 any; var tmp13 /*line :124:1*/*lang.Var;







	A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(ifaces__8)) { var cn__9 any; var tmp14 *lang.Var
		A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_9; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_268, nil); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_10; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_11; var tmp20 any = jrt.NN(tmp19).GetRawRoot__O(); var tmp21 *lang.Var; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_12; cn__9 = tmp15.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp18.Invoke_O_O__O(tmp20, jrt.NN(tmp21).GetRawRoot__O()))).Ref())
		var tmp22 *lang.Var; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_62; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_111; var tmp25 any = tmp24; var tmp26 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_112; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_71; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_classes_lower_A_Init(); tmp30 = A_arbace_classes_lower_A_const_64; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any; A_arbace_classes_lower_A_Init(); tmp32 = A_arbace_classes_lower_A_const_116; var tmp33 any = tmp31.Invoke_O_O__O(cn__9, tmp32); var tmp34 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp34 = A_arbace_classes_lower_A_const_113; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp36 = A_arbace_classes_lower_A_const_114; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Var; A_arbace_classes_lower_A_Init(); tmp38 = A_arbace_classes_lower_A_const_115; var tmp39 any = lang.Tuple_Create_O__IPersistentVector(tmp29.Invoke_O_O_O_O_O_O__O(tmp33, tmp35, super__7, tmp37, ifaces__8, lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O_O_O_O__O(rcv__6, nm__4, arities__5, nil))); var tmp40 *lang.Var; A_arbace_classes_lower_A_Init(); tmp40 = A_arbace_classes_lower_A_const_62; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 any; A_arbace_classes_lower_A_Init(); tmp42 = A_arbace_classes_lower_A_const_117; anon__9 = tmp23.Invoke_O_O_O_O__O(tmp25, tmp27, tmp39, tmp41.Invoke_O_O__O(tmp42, cn__9)) } else {



			var tmp43 *lang.Var; A_arbace_classes_lower_A_Init(); tmp43 = A_arbace_classes_lower_A_const_71; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 any; A_arbace_classes_lower_A_Init(); tmp45 = A_arbace_classes_lower_A_const_118; var tmp46 any = tmp45; var tmp47 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp47 = A_arbace_classes_lower_A_const_119; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Var; A_arbace_classes_lower_A_Init(); tmp49 = A_arbace_classes_lower_A_const_64; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 any; A_arbace_classes_lower_A_Init(); tmp51 = A_arbace_classes_lower_A_const_120; var tmp52 any = tmp50.Invoke_O_O__O(super__7, tmp51); var tmp53 *lang.PersistentVector; lang.PersistentVector_Init(); tmp53 = lang.PersistentVector_EMPTY; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Var; A_arbace_classes_lower_A_Init(); tmp55 = A_arbace_classes_lower_A_const_115; anon__9 = tmp44.Invoke_O_O_O_O_O__O(tmp46, tmp48, tmp52, tmp54, lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O_O_O_O__O(rcv__6, nm__4, arities__5, nil)) }; var temp__1927000408__auto____10 any; var tmp56 /*line :124:1*/*lang.Var;















	A_arbace_classes_lower_A_Init(); tmp56 = A_arbace_classes_lower_A_const_110; temp__1927000408__auto____10 = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(form__0); if jrt.A2g_Truth(temp__1927000408__auto____10) { var m__11 any = temp__1927000408__auto____10; var tmp57 *lang.Var
		A_arbace_classes_lower_A_Init(); tmp57 = A_arbace_classes_lower_A_const_62; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 any; A_arbace_classes_lower_A_Init(); tmp59 = A_arbace_classes_lower_A_const_121; return tmp58.Invoke_O_O_O__O(tmp59, anon__9, m__11) } else {
//line :140:1
			return anon__9 } }








func A_arbace_classes_lower_clojure_method_A_New() *A_arbace_classes_lower_clojure_method_A { A_arbace_classes_lower_clojure_method_A_Init(); t := &A_arbace_classes_lower_clojure_method_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_classes_lower_clojure_method_A) Ctor() {}
//line :149:1
func (t *A_arbace_classes_lower_clojure_method_A) Invoke_O_O__O(self, p__1304000093__0 any) any { var vec__1304000094__2 any = p__1304000093__0; var seq__1304000095__3 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; seq__1304000095__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1304000094__2); var first__1304000096__4 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_14; first__1304000096__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1304000095__3); var seq__1304000095__5 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_15; seq__1304000095__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1304000095__3); var nm__6 any = first__1304000096__4; var first__1304000096__7 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_14; first__1304000096__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1304000095__5); var seq__1304000095__8 any; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_15; seq__1304000095__8 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1304000095__5); var pv__9 any = first__1304000096__7; var body__10 any = seq__1304000095__8; var tmp6 any; var and__1927000168__auto____11 any; var tmp7 *lang.Var;





	A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_17; and__1927000168__auto____11 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(pv__9); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp8 *lang.Var; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_13; tmp6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(pv__9) } else { tmp6 = and__1927000168__auto____11 }; if jrt.A2g_Truth(tmp6) { } else { var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_25; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_207, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__6)).Ref(); var tmp12 any; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_122; panic(jrt.Thrown(jrt.Throwable_Cast(tmp10.Invoke_O_O__O(tmp11, tmp12)))) }; var seq_1304000097__11 any; var tmp13 /*line :149:1*/*lang.Var;








	A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_13; seq_1304000097__11 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(pv__9); var chunk_1304000098__12 any; var count_1304000099__13 int64 = 0; var i_1304000100__14 int64 = 0; L1:
//line :149:1
	for {








		if lang.Numbers_Lt_J_J__Z(i_1304000100__14, count_1304000099__13) { var p__15 any = lang.Indexed_Cast(chunk_1304000098__12).Nth_I__O(lang.RT_IntCast_J__I(i_1304000100__14)); var tmp14 *lang.Var
			A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(p__15)) { } else { var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_25; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_123; panic(jrt.Thrown(jrt.Throwable_Cast(tmp16.Invoke_O_O__O(Lit_208, tmp17)))) }
//line :158:1
			seq_1304000097__11, chunk_1304000098__12, count_1304000099__13, i_1304000100__14 = seq_1304000097__11, chunk_1304000098__12, count_1304000099__13, lang.Numbers_Unchecked_inc_J__J(i_1304000100__14); continue L1 } else { var temp__1927000414__auto____15 any; var tmp18 *lang.Var; A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____15 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_1304000097__11); if jrt.A2g_Truth(temp__1927000414__auto____15) { var seq_1304000097__16 any = temp__1927000414__auto____15; var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_1304000097__16)) { var c__1927000678__auto____17 any; var tmp20 *lang.Var; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_23; c__1927000678__auto____17 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_1304000097__16); var tmp21 *lang.Var; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_28; seq_1304000097__11, chunk_1304000098__12, count_1304000099__13, i_1304000100__14 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_1304000097__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var p__17 any; var tmp22 *lang.Var; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_14; p__17 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_1304000097__16)
				var tmp23 *lang.Var; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(p__17)) { } else { var tmp24 *lang.Var; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_25; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_124; panic(jrt.Thrown(jrt.Throwable_Cast(tmp25.Invoke_O_O__O(Lit_208, tmp26)))) }
//line :158:1
				var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_15; seq_1304000097__11, chunk_1304000098__12, count_1304000099__13, i_1304000100__14 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_1304000097__16), nil, 0, 0; continue L1 } } }
//line :149:1
		break L1 }; var vec__1304000101__11 any = pv__9; var seq__1304000102__12 any; var tmp28 *lang.Var;











	A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_13; seq__1304000102__12 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(vec__1304000101__11); var first__1304000103__13 any; var tmp29 /*line :149:1*/*lang.Var;











	A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_14; first__1304000103__13 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq__1304000102__12); var seq__1304000102__14 any; var tmp30 /*line :149:1*/*lang.Var;











	A_arbace_classes_lower_A_Init(); tmp30 = A_arbace_classes_lower_A_const_15; seq__1304000102__14 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq__1304000102__12); var this__15 any = first__1304000103__13; var ps__16 any = seq__1304000102__14; var ps__17 any; var tmp31 /*line :149:1*/*lang.Var;












	A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_44; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any = A_arbace_classes_lower_clojure_method_fn__1304000104_A_New(); var tmp34 *jrt.Class; A_arbace_classes_lower_clojure_method_fn__1304000104_A_Init(); tmp34 = A_arbace_classes_lower_clojure_method_fn__1304000104_A_fn_class; ps__17 = tmp32.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil), ps__16); var tmp35 /*line :163:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp35 = A_arbace_classes_lower_A_const_62; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_classes_lower_A_Init(); tmp37 = A_arbace_classes_lower_A_const_126; var tmp38 any = tmp37; var tmp39 *lang.Var; A_arbace_classes_lower_A_Init(); tmp39 = A_arbace_classes_lower_A_const_64; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_classes_lower_A_Init(); tmp41 = A_arbace_classes_lower_A_const_9; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_classes_lower_A_Init(); tmp43 = A_arbace_classes_lower_A_const_129; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_classes_lower_A_Init(); tmp45 = A_arbace_classes_lower_A_const_125; var tmp46 any = tmp42.Invoke_O__O(tmp44.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(nm__6))); var tmp47 *lang.Var; A_arbace_classes_lower_A_Init(); tmp47 = A_arbace_classes_lower_A_const_128; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 any = lang.RT_Meta_O__IPersistentMap(nm__6); var tmp50 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp50 = A_arbace_classes_lower_A_const_92; var tmp51 any = tmp50.Ref(); var tmp52 *jrt.Boolean; jrt.Boolean_Init(); tmp52 = jrt.Boolean_TRUE; var tmp53 any = tmp52.Ref(); var tmp54 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp54 = A_arbace_classes_lower_A_const_130; var tmp55 any = tmp54.Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp40.Invoke_O_O__O(tmp46, tmp48.Invoke_O_O_O_O_O__O(tmp49, tmp51, tmp53, tmp55, tmp56.Ref())); var tmp58 *lang.Var; A_arbace_classes_lower_A_Init(); tmp58 = A_arbace_classes_lower_A_const_49; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Var; A_arbace_classes_lower_A_Init(); tmp60 = A_arbace_classes_lower_A_const_56; var tmp61 any = tmp59.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O_O__O(this__15, ps__17)); var tmp62 any; var tmp63 *lang.Var;

	A_arbace_classes_lower_A_Init(); tmp63 = A_arbace_classes_lower_A_const_127; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Var; A_arbace_classes_lower_A_Init(); tmp65 = A_arbace_classes_lower_A_const_131; var tmp66 any = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(body__10); var tmp67 any; A_arbace_classes_lower_A_Init(); tmp67 = A_arbace_classes_lower_A_const_132; if jrt.A2g_Truth(tmp64.Invoke_O_O__O(tmp66, tmp67)) {
		var tmp68 *lang.Var; A_arbace_classes_lower_A_Init(); tmp68 = A_arbace_classes_lower_A_const_71; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 *lang.Var; A_arbace_classes_lower_A_Init(); tmp70 = A_arbace_classes_lower_A_const_64; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 any; A_arbace_classes_lower_A_Init(); tmp72 = A_arbace_classes_lower_A_const_133; var tmp73 any = tmp72; var tmp74 any; A_arbace_classes_lower_A_Init(); tmp74 = A_arbace_classes_lower_A_const_134; var tmp75 any = tmp71.Invoke_O_O__O(tmp73, tmp74); var tmp76 *lang.Var; A_arbace_classes_lower_A_Init(); tmp76 = A_arbace_classes_lower_A_const_49; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 *lang.Var; A_arbace_classes_lower_A_Init(); tmp78 = A_arbace_classes_lower_A_const_60; var tmp79 lang.IFn = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()); var tmp80 any = A_arbace_classes_lower_clojure_method_fn__1304000106_A_New(); var tmp81 *jrt.Class; A_arbace_classes_lower_clojure_method_fn__1304000106_A_Init(); tmp81 = A_arbace_classes_lower_clojure_method_fn__1304000106_A_fn_class; tmp62 = tmp69.Invoke_O_O_O__O(tmp75, tmp77.Invoke_O__O(tmp79.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp80, tmp81, nil), ps__17)), body__10) } else {


			var tmp82 *lang.Var; A_arbace_classes_lower_A_Init(); tmp82 = A_arbace_classes_lower_A_const_71; var tmp83 lang.IFn = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()); var tmp84 any; A_arbace_classes_lower_A_Init(); tmp84 = A_arbace_classes_lower_A_const_135; tmp62 = tmp83.Invoke_O_O__O(tmp84, body__10) }; return /*line :163:1*/ tmp36.Invoke_O_O_O_O__O(tmp38, tmp57, tmp61, tmp62) }
//line :162:1
func A_arbace_classes_lower_clojure_method_fn__1304000104_A_New() *A_arbace_classes_lower_clojure_method_fn__1304000104_A { A_arbace_classes_lower_clojure_method_fn__1304000104_A_Init(); t := &A_arbace_classes_lower_clojure_method_fn__1304000104_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) Ctor() {}
//line :162:1
func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) Invoke_O_O__O(self, p1__1304000092_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__1304000092_SHARP___1)) { var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_64; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_9; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_125; return tmp3.Invoke_O_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(p1__1304000092_SHARP___1)), lang.RT_Meta_O__IPersistentMap(p1__1304000092_SHARP___1)) } else { return p1__1304000092_SHARP___1 } }




func A_arbace_classes_lower_clojure_method_fn__1304000106_A_New() *A_arbace_classes_lower_clojure_method_fn__1304000106_A { A_arbace_classes_lower_clojure_method_fn__1304000106_A_Init(); t := &A_arbace_classes_lower_clojure_method_fn__1304000106_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) Ctor() {}
//line :167:1
func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_68; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_69; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_46; return lang.Tuple_Create_O_O__IPersistentVector(tmp2.Invoke_O_O_O__O(p__1, tmp4, tmp5.Ref()), p__1) }



func A_arbace_classes_lower_lower_reify_A_New() *A_arbace_classes_lower_lower_reify_A { A_arbace_classes_lower_lower_reify_A_Init(); t := &A_arbace_classes_lower_lower_reify_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_classes_lower_lower_reify_A) Ctor() {}
//line :171:1
func (t *A_arbace_classes_lower_lower_reify_A) Invoke_O_O__O(self, p__1304000109__0 any) any { var vec__1304000110__2 any = p__1304000109__0; var seq__1304000111__3 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; seq__1304000111__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1304000110__2); var first__1304000112__4 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_14; first__1304000112__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1304000111__3); var seq__1304000111__5 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_15; seq__1304000111__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1304000111__3); var ___6 any = first__1304000112__4; var first__1304000112__7 any; var tmp4 *lang.Var; _ = ___6; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_14; first__1304000112__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1304000111__5); var seq__1304000111__8 any; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_15; seq__1304000111__8 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1304000111__5); var ifaces__9 any = first__1304000112__7; var methods__10 any = seq__1304000111__8; var form__11 any = vec__1304000110__2; var cn__12 any; var tmp6 *lang.Var;





	A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_9; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_285, nil); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_10; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_11; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_12; cn__12 = tmp7.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp10.Invoke_O_O__O(tmp12, jrt.NN(tmp13).GetRawRoot__O()))).Ref()); var pm__13 any; /*line :171:1*/A_arbace_classes_lower_A_Init(); pm__13 = A_arbace_classes_lower_A_const_136; var mm__14 any; var tmp14 *lang.Var;







	A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_67; mm__14 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(Lit_127); var rcv__15 any; var tmp15 /*line :171:1*/*lang.Var;








	A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_67; rcv__15 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(Lit_213); var m__16 any; var tmp16 /*line :171:1*/*lang.Var;









	A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_110; m__16 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(form__11); var tmp17 /*line :182:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_62; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_137; var tmp20 any = tmp19; var tmp21 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_112; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_43; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_64; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_138; var tmp28 any = tmp26.Invoke_O_O__O(cn__12, tmp27); var tmp29 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_114; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Var; A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_6; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_classes_lower_A_Init(); tmp33 = A_arbace_classes_lower_A_const_49; var tmp34 any = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(ifaces__9); var tmp35 any; A_arbace_classes_lower_A_Init(); tmp35 = A_arbace_classes_lower_A_const_139; var tmp36 any = tmp32.Invoke_O_O__O(tmp34, tmp35); var tmp37 *lang.Var; A_arbace_classes_lower_A_Init(); tmp37 = A_arbace_classes_lower_A_const_62; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_classes_lower_A_Init(); tmp39 = A_arbace_classes_lower_A_const_140; var tmp40 any = tmp39; var tmp41 *lang.Var; A_arbace_classes_lower_A_Init(); tmp41 = A_arbace_classes_lower_A_const_64; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 any; A_arbace_classes_lower_A_Init(); tmp43 = A_arbace_classes_lower_A_const_141; var tmp44 any = tmp43; var tmp45 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp45 = A_arbace_classes_lower_A_const_46; var tmp46 any = tmp45.Ref(); var tmp47 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp47 = A_arbace_classes_lower_A_const_142; var tmp48 any = tmp47.Ref(); var tmp49 *jrt.Boolean; jrt.Boolean_Init(); tmp49 = jrt.Boolean_TRUE; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp51 = A_arbace_classes_lower_A_const_143; var tmp52 any = tmp51.Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp38.Invoke_O_O__O(tmp40, tmp42.Invoke_O_O__O(tmp44, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, pm__13, tmp48, tmp50, tmp52, tmp53.Ref())))); var tmp55 *lang.Var; A_arbace_classes_lower_A_Init(); tmp55 = A_arbace_classes_lower_A_const_62; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any; A_arbace_classes_lower_A_Init(); tmp57 = A_arbace_classes_lower_A_const_144; var tmp58 any = tmp57; var tmp59 *lang.Var; A_arbace_classes_lower_A_Init(); tmp59 = A_arbace_classes_lower_A_const_64; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Var; A_arbace_classes_lower_A_Init(); tmp61 = A_arbace_classes_lower_A_const_64; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp63 = A_arbace_classes_lower_A_const_46; var tmp64 any = lang.Tuple_Create_O_O__IPersistentVector(rcv__15, tmp62.Invoke_O_O__O(mm__14, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp63.Ref(), pm__13)))); var tmp65 any; A_arbace_classes_lower_A_Init(); tmp65 = A_arbace_classes_lower_A_const_145; var tmp66 any = tmp60.Invoke_O_O__O(tmp64, tmp65); var tmp67 *lang.Var; A_arbace_classes_lower_A_Init(); tmp67 = A_arbace_classes_lower_A_const_62; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 any; A_arbace_classes_lower_A_Init(); tmp69 = A_arbace_classes_lower_A_const_146; var tmp70 any = tmp69; var tmp71 *lang.Var; A_arbace_classes_lower_A_Init(); tmp71 = A_arbace_classes_lower_A_const_62; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 any; A_arbace_classes_lower_A_Init(); tmp73 = A_arbace_classes_lower_A_const_147; var tmp74 any = tmp56.Invoke_O_O_O__O(tmp58, tmp66, tmp68.Invoke_O_O_O__O(tmp70, tmp72.Invoke_O_O__O(tmp73, rcv__15), mm__14)); var tmp75 *lang.Var; A_arbace_classes_lower_A_Init(); tmp75 = A_arbace_classes_lower_A_const_62; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 any; A_arbace_classes_lower_A_Init(); tmp77 = A_arbace_classes_lower_A_const_148; var tmp78 any = tmp77; var tmp79 *lang.Var; A_arbace_classes_lower_A_Init(); tmp79 = A_arbace_classes_lower_A_const_64; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 any; A_arbace_classes_lower_A_Init(); tmp81 = A_arbace_classes_lower_A_const_149; var tmp82 any = tmp81; var tmp83 any; A_arbace_classes_lower_A_Init(); tmp83 = A_arbace_classes_lower_A_const_150; var tmp84 any = tmp80.Invoke_O_O__O(tmp82, tmp83); var tmp85 *lang.Var; A_arbace_classes_lower_A_Init(); tmp85 = A_arbace_classes_lower_A_const_64; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 any = lang.Tuple_Create_O__IPersistentVector(rcv__15); var tmp88 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp88 = A_arbace_classes_lower_A_const_46; var tmp89 any = tmp86.Invoke_O_O__O(tmp87, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp88.Ref(), pm__13))); var tmp90 *lang.Var; A_arbace_classes_lower_A_Init(); tmp90 = A_arbace_classes_lower_A_const_62; var tmp91 lang.IFn = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()); var tmp92 any; A_arbace_classes_lower_A_Init(); tmp92 = A_arbace_classes_lower_A_const_151; var tmp93 any = tmp76.Invoke_O_O_O_O__O(tmp78, tmp84, tmp89, tmp91.Invoke_O_O__O(tmp92, rcv__15)); var tmp94 *lang.Var; A_arbace_classes_lower_A_Init(); tmp94 = A_arbace_classes_lower_A_const_62; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 any; A_arbace_classes_lower_A_Init(); tmp96 = A_arbace_classes_lower_A_const_152; var tmp97 any = tmp96; var tmp98 *lang.Var; A_arbace_classes_lower_A_Init(); tmp98 = A_arbace_classes_lower_A_const_64; var tmp99 lang.IFn = lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()); var tmp100 any; A_arbace_classes_lower_A_Init(); tmp100 = A_arbace_classes_lower_A_const_153; var tmp101 any = tmp100; var tmp102 any; A_arbace_classes_lower_A_Init(); tmp102 = A_arbace_classes_lower_A_const_154; var tmp103 any = tmp99.Invoke_O_O__O(tmp101, tmp102); var tmp104 *lang.Var; A_arbace_classes_lower_A_Init(); tmp104 = A_arbace_classes_lower_A_const_64; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 *lang.Var; A_arbace_classes_lower_A_Init(); tmp106 = A_arbace_classes_lower_A_const_64; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp108 = A_arbace_classes_lower_A_const_46; var tmp109 any = lang.Tuple_Create_O_O__IPersistentVector(rcv__15, tmp107.Invoke_O_O__O(mm__14, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp108.Ref(), pm__13)))); var tmp110 any; A_arbace_classes_lower_A_Init(); tmp110 = A_arbace_classes_lower_A_const_155; var tmp111 any = tmp105.Invoke_O_O__O(tmp109, tmp110); var tmp112 *lang.Var; A_arbace_classes_lower_A_Init(); tmp112 = A_arbace_classes_lower_A_const_62; var tmp113 lang.IFn = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()); var tmp114 any; A_arbace_classes_lower_A_Init(); tmp114 = A_arbace_classes_lower_A_const_156; var tmp115 any = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, tmp36, tmp54, tmp74, tmp93, tmp95.Invoke_O_O_O_O__O(tmp97, tmp103, tmp111, tmp113.Invoke_O_O_O__O(tmp114, cn__12, mm__14)))); var tmp116 *lang.Var; A_arbace_classes_lower_A_Init(); tmp116 = A_arbace_classes_lower_A_const_44; var tmp117 lang.IFn = lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()); var tmp118 *lang.Var; A_arbace_classes_lower_A_Init(); tmp118 = A_arbace_classes_lower_A_const_157; var tmp119 any = lang.Tuple_Create_O__IPersistentVector(tmp24.Invoke_O_O__O(tmp115, tmp117.Invoke_O_O__O(jrt.NN(tmp118).GetRawRoot__O(), methods__10))); var tmp120 *lang.Var; A_arbace_classes_lower_A_Init(); tmp120 = A_arbace_classes_lower_A_const_62; var tmp121 lang.IFn = lang.IFn_Cast(jrt.NN(tmp120).GetRawRoot__O()); var tmp122 any; A_arbace_classes_lower_A_Init(); tmp122 = A_arbace_classes_lower_A_const_158; return tmp18.Invoke_O_O_O_O__O(tmp20, tmp22, tmp119, tmp121.Invoke_O_O_O__O(tmp122, cn__12, m__16)) }



















func A_arbace_classes_lower_annotation_meta_A_New() *A_arbace_classes_lower_annotation_meta_A { A_arbace_classes_lower_annotation_meta_A_Init(); t := &A_arbace_classes_lower_annotation_meta_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_classes_lower_annotation_meta_A) Ctor() {}
//line :202:1
func (t *A_arbace_classes_lower_annotation_meta_A) Invoke_O_O__O(self, m__0 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_159; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_58; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_74; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_16; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_160; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp8.Invoke_O_O__O(tmp10, jrt.NN(tmp11).GetRawRoot__O()), m__0)) }

func A_arbace_classes_lower_deftype_class_form_A_New() *A_arbace_classes_lower_deftype_class_form_A { A_arbace_classes_lower_deftype_class_form_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_classes_lower_deftype_class_form_A) Ctor() {}
//line :204:1
func (t *A_arbace_classes_lower_deftype_class_form_A) Invoke_O_O__O(self, p__1304000116__0 any) any { var vec__1304000117__2 any = p__1304000116__0; var seq__1304000118__3 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; seq__1304000118__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1304000117__2); var first__1304000119__4 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_14; first__1304000119__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1304000118__3); var seq__1304000118__5 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_15; seq__1304000118__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1304000118__3); var ___6 any = first__1304000119__4; var first__1304000119__7 any; var tmp4 *lang.Var; _ = ___6; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_14; first__1304000119__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1304000118__5); var seq__1304000118__8 any; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_15; seq__1304000118__8 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1304000118__5); var _tagname__9 any = first__1304000119__7; var first__1304000119__10 any; var tmp6 *lang.Var; _ = _tagname__9; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_14; first__1304000119__10 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__1304000118__8); var seq__1304000118__11 any; var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_15; seq__1304000118__11 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__1304000118__8); var classname__12 any = first__1304000119__10; var first__1304000119__13 any; var tmp8 *lang.Var; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_14; first__1304000119__13 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__1304000118__11); var seq__1304000118__14 any; var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_15; seq__1304000118__14 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq__1304000118__11); var fields__15 any = first__1304000119__13; var more__16 any = seq__1304000118__14; var vec__1304000120__17 any; var tmp10 any = A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_New_O(more__16); var tmp11 *jrt.Class;









	A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_Init(); tmp11 = A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_fn_class; vec__1304000120__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O(); var opts__18 any = /*line :204:1*/lang.RT_Nth_O_I_O__O(vec__1304000120__17, lang.RT_IntCast_J__I(0), nil); var methods__19 any = lang.RT_Nth_O_I_O__O(vec__1304000120__17, lang.RT_IntCast_J__I(1), nil); var cname__20 any; var tmp12 *lang.Var;











	A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_42; cname__20 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(classname__12); var i__21 int32 = /*line :204:1*/jrt.NN(jrt.String_Cast(cname__20)).LastIndexOf_String__I(Lit_159); var pkg__22 any; if













	lang.Numbers_IsNeg_J__Z(int64(i__21)) { pkg__22 = Lit_212 } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_164; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_170; var tmp16 any = tmp15; pkg__22 = tmp14.Invoke_O_O_O__O(cname__20, tmp16, jrt.Integer_ValueOf_I__Integer(i__21).Ref()) }; var simple__23 any; var tmp17 /*line :204:1*/*lang.Var;














	A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_9; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_164; simple__23 = tmp18.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O_O__O(cname__20, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(i__21))).Ref())); var rcv__24 any; var tmp20 /*line :204:1*/*lang.Var;















	A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_67; rcv__24 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(Lit_213); var fields__25 any; var tmp21 /*line :204:1*/*lang.Var;
















	A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_49; fields__25 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(fields__15); var drops__26 int32; var tmp22 /*line :204:1*/*lang.Var;

















	A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_94; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any = A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_New(); var tmp25 *jrt.Class; A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_Init(); tmp25 = A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_fn_class; var tmp26 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_172; drops__26 = lang.RT_Count_O__I(tmp23.Invoke_O_O__O(tmp26, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(fields__25))); var hinted__27 any; var tmp28 /*line :204:1*/*lang.Var;


















	A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_165; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_classes_lower_A_Init(); tmp30 = A_arbace_classes_lower_A_const_170; var tmp31 any = tmp30; hinted__27 = tmp29.Invoke_O_O_O__O(fields__25, tmp31, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(fields__25)), int64(drops__26))).Ref()); var fname__28 any; var tmp32 any = /*line :204:1*/A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_New(); var tmp33 *jrt.Class;



















	A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_Init(); tmp33 = A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_fn_class; fname__28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var ptag__29 any; var tmp34 any = /*line :204:1*/A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_New(); var tmp35 *jrt.Class;




















	A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_Init(); tmp35 = A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_fn_class; ptag__29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); var param__30 any; var tmp36 any = /*line :204:1*/A_arbace_classes_lower_deftype_class_form_param__1304000131_A_New_O_O(ptag__29, fname__28); var tmp37 *jrt.Class;





















	A_arbace_classes_lower_deftype_class_form_param__1304000131_A_Init(); tmp37 = A_arbace_classes_lower_deftype_class_form_param__1304000131_A_fn_class; param__30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); var n__31 int32 = /*line :204:1*/lang.RT_Count_O__I(fields__25); var ctor__32 any; var tmp38 any = A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_New_O_O_O_O(fields__25, rcv__24, param__30, fname__28); var tmp39 *jrt.Class;























	A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_Init(); tmp39 = A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_fn_class; ctor__32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var basis__33 any; var tmp40 /*line :204:1*/*lang.Var;


























	A_arbace_classes_lower_A_Init(); tmp40 = A_arbace_classes_lower_A_const_49; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 any; var iter__1927001039__auto____33 any; var tmp43 any = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_New(); var tmp44 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_Init(); tmp44 = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_fn_class; iter__1927001039__auto____33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil); tmp42 = lang.IFn_Cast(iter__1927001039__auto____33).Invoke_O__O(hinted__27); basis__33 = tmp41.Invoke_O__O(tmp42); var tmp45 /*line :235:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp45 = A_arbace_classes_lower_A_const_43; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_classes_lower_A_Init(); tmp47 = A_arbace_classes_lower_A_const_64; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_classes_lower_A_Init(); tmp49 = A_arbace_classes_lower_A_const_178; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_classes_lower_A_Init(); tmp51 = A_arbace_classes_lower_A_const_179; var tmp52 any = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(classname__12)); var tmp53 any; A_arbace_classes_lower_A_Init(); tmp53 = A_arbace_classes_lower_A_const_189; var tmp54 any = tmp48.Invoke_O_O__O(simple__23, tmp50.Invoke_O_O__O(tmp52, tmp53)); var tmp55 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp55 = A_arbace_classes_lower_A_const_188; var tmp56 any = tmp55.Ref(); var tmp57 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp57 = A_arbace_classes_lower_A_const_114; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Var; A_arbace_classes_lower_A_Init(); tmp59 = A_arbace_classes_lower_A_const_49; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp61 = A_arbace_classes_lower_A_const_114; var tmp62 any = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp54, tmp56, pkg__22, tmp58, tmp60.Invoke_O__O(jrt.NN(tmp61).Invoke_O__O(opts__18))); var tmp63 any; var iter__1927001039__auto____34 any; var tmp64 any = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_New_O_O(ptag__29, fname__28); var tmp65 *jrt.Class;





	A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_Init(); tmp65 = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_fn_class; iter__1927001039__auto____34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil); tmp63 = lang.IFn_Cast(iter__1927001039__auto____34).Invoke_O__O(fields__25); var tmp66 any = tmp63; var tmp67 /*line :235:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp67 = A_arbace_classes_lower_A_const_71; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 any; A_arbace_classes_lower_A_Init(); tmp69 = A_arbace_classes_lower_A_const_190; var tmp70 any = tmp69; var tmp71 *lang.Var; A_arbace_classes_lower_A_Init(); tmp71 = A_arbace_classes_lower_A_const_64; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_classes_lower_A_Init(); tmp73 = A_arbace_classes_lower_A_const_49; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_classes_lower_A_Init(); tmp75 = A_arbace_classes_lower_A_const_56; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Var; A_arbace_classes_lower_A_Init(); tmp77 = A_arbace_classes_lower_A_const_44; var tmp78 any = tmp74.Invoke_O__O(tmp76.Invoke_O_O__O(rcv__24, lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke_O_O__O(param__30, fields__25))); var tmp79 any; A_arbace_classes_lower_A_Init(); tmp79 = A_arbace_classes_lower_A_const_192; var tmp80 any = tmp72.Invoke_O_O__O(tmp78, tmp79); var tmp81 *lang.Var; A_arbace_classes_lower_A_Init(); tmp81 = A_arbace_classes_lower_A_const_62; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 any; A_arbace_classes_lower_A_Init(); tmp83 = A_arbace_classes_lower_A_const_193; var tmp84 any = tmp82.Invoke_O__O(tmp83); var tmp85 any; var iter__1927001039__auto____34_2 any; var tmp86 any = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_New_O_O(rcv__24, fname__28); var tmp87 *jrt.Class;
















	A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_Init(); tmp87 = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_fn_class; iter__1927001039__auto____34_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp86, tmp87, nil); tmp85 = lang.IFn_Cast(iter__1927001039__auto____34_2).Invoke_O__O(fields__25); var tmp88 any = /*line :235:1*/lang.Tuple_Create_O__IPersistentVector(tmp68.Invoke_O_O_O_O__O(tmp70, tmp80, tmp84, tmp85)); var tmp89 lang.IPersistentVector; if

















	lang.Util_Equiv_J_J__Z(4, int64(drops__26)) { var tmp90 lang.IFn = lang.IFn_Cast(ctor__32); var tmp91 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(n__31), 4)).Ref(); var tmp92 any; A_arbace_classes_lower_A_Init(); tmp92 = A_arbace_classes_lower_A_const_194; var tmp93 any = tmp90.Invoke_O_O__O(tmp91, tmp92); var tmp94 lang.IFn = lang.IFn_Cast(ctor__32); var tmp95 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(n__31), 2)).Ref(); var tmp96 any; A_arbace_classes_lower_A_Init(); tmp96 = A_arbace_classes_lower_A_const_195; tmp89 = lang.Tuple_Create_O_O__IPersistentVector(tmp93, tmp94.Invoke_O_O__O(tmp95, tmp96)) } else { tmp89 = nil }; var tmp97 any = tmp89; var tmp98 /*line :235:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp98 = A_arbace_classes_lower_A_const_62; var tmp99 lang.IFn = lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()); var tmp100 any; A_arbace_classes_lower_A_Init(); tmp100 = A_arbace_classes_lower_A_const_196; var tmp101 any = tmp100; var tmp102 *lang.Var; A_arbace_classes_lower_A_Init(); tmp102 = A_arbace_classes_lower_A_const_64; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 any; A_arbace_classes_lower_A_Init(); tmp104 = A_arbace_classes_lower_A_const_197; var tmp105 any = tmp104; var tmp106 any; A_arbace_classes_lower_A_Init(); tmp106 = A_arbace_classes_lower_A_const_198; var tmp107 any = tmp103.Invoke_O_O__O(tmp105, tmp106); var tmp108 *lang.Var; A_arbace_classes_lower_A_Init(); tmp108 = A_arbace_classes_lower_A_const_64; var tmp109 lang.IFn = lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()); var tmp110 *lang.PersistentVector; lang.PersistentVector_Init(); tmp110 = lang.PersistentVector_EMPTY; var tmp111 any = tmp110.Ref(); var tmp112 any; A_arbace_classes_lower_A_Init(); tmp112 = A_arbace_classes_lower_A_const_199; var tmp113 any = lang.Tuple_Create_O__IPersistentVector(tmp99.Invoke_O_O_O_O__O(tmp101, tmp107, tmp109.Invoke_O_O__O(tmp111, tmp112), basis__33)); var tmp114 lang.IPersistentVector; if























	lang.Util_Equiv_J_J__Z(4, int64(drops__26)) { var ms__34 any; var tmp115 *lang.Var
		A_arbace_classes_lower_A_Init(); tmp115 = A_arbace_classes_lower_A_const_49; var tmp116 lang.IFn = lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()); var tmp117 any; var iter__1927001039__auto____34_3 any; var tmp118 any = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_New(); var tmp119 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_Init(); tmp119 = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_fn_class; iter__1927001039__auto____34_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp118, tmp119, nil); var tmp120 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____34_3); var tmp121 *lang.Var; A_arbace_classes_lower_A_Init(); tmp121 = A_arbace_classes_lower_A_const_200; tmp117 = tmp120.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(hinted__27)))).Ref())); ms__34 = tmp116.Invoke_O__O(tmp117)
//line :259:1
		var vs__35 any; var tmp122 *lang.Var

		A_arbace_classes_lower_A_Init(); tmp122 = A_arbace_classes_lower_A_const_49; var tmp123 lang.IFn = lang.IFn_Cast(jrt.NN(tmp122).GetRawRoot__O()); var tmp124 any; var iter__1927001039__auto____35 any; var tmp125 any = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_New_O(fname__28); var tmp126 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_Init(); tmp126 = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_fn_class; iter__1927001039__auto____35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp125, tmp126, nil); tmp124 = lang.IFn_Cast(iter__1927001039__auto____35).Invoke_O__O(hinted__27); vs__35 = tmp123.Invoke_O__O(tmp124)
//line :259:1
		var tmp127 *lang.Var; A_arbace_classes_lower_A_Init(); tmp127 = A_arbace_classes_lower_A_const_62; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 any; A_arbace_classes_lower_A_Init(); tmp129 = A_arbace_classes_lower_A_const_201; var tmp130 any = tmp129; var tmp131 *lang.Var; A_arbace_classes_lower_A_Init(); tmp131 = A_arbace_classes_lower_A_const_64; var tmp132 lang.IFn = lang.IFn_Cast(jrt.NN(tmp131).GetRawRoot__O()); var tmp133 any; A_arbace_classes_lower_A_Init(); tmp133 = A_arbace_classes_lower_A_const_202; var tmp134 any = tmp133; var tmp135 any; A_arbace_classes_lower_A_Init(); tmp135 = A_arbace_classes_lower_A_const_203; var tmp136 any = tmp132.Invoke_O_O__O(tmp134, tmp135); var tmp137 *lang.Var; A_arbace_classes_lower_A_Init(); tmp137 = A_arbace_classes_lower_A_const_64; var tmp138 lang.IFn = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()); var tmp139 *lang.Var; A_arbace_classes_lower_A_Init(); tmp139 = A_arbace_classes_lower_A_const_64; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 lang.IFn = lang.IFn_Cast(ms__34); var tmp142 any; A_arbace_classes_lower_A_Init(); tmp142 = A_arbace_classes_lower_A_const_170; var tmp143 any = tmp141.Invoke_O__O(tmp142); var tmp144 any; A_arbace_classes_lower_A_Init(); tmp144 = A_arbace_classes_lower_A_const_204; var tmp145 any = lang.Tuple_Create_O__IPersistentVector(tmp140.Invoke_O_O__O(tmp143, tmp144)); var tmp146 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp146 = A_arbace_classes_lower_A_const_46; var tmp147 any = tmp138.Invoke_O_O__O(tmp145, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp146.Ref(), simple__23))); var tmp148 *lang.Var; A_arbace_classes_lower_A_Init(); tmp148 = A_arbace_classes_lower_A_const_62; var tmp149 lang.IFn = lang.IFn_Cast(jrt.NN(tmp148).GetRawRoot__O()); var tmp150 any; A_arbace_classes_lower_A_Init(); tmp150 = A_arbace_classes_lower_A_const_205; var tmp151 any = tmp150; var tmp152 *lang.Var; A_arbace_classes_lower_A_Init(); tmp152 = A_arbace_classes_lower_A_const_49; var tmp153 lang.IFn = lang.IFn_Cast(jrt.NN(tmp152).GetRawRoot__O()); var tmp154 *lang.Var; A_arbace_classes_lower_A_Init(); tmp154 = A_arbace_classes_lower_A_const_60; var tmp155 lang.IFn = lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()); var tmp156 any = A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_New(); var tmp157 *jrt.Class; A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_Init(); tmp157 = A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_fn_class; var tmp158 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp156, tmp157, nil); var tmp159 *lang.Var; A_arbace_classes_lower_A_Init(); tmp159 = A_arbace_classes_lower_A_const_21; var tmp160 any = tmp153.Invoke_O__O(tmp155.Invoke_O_O_O_O_O__O(tmp158, hinted__27, vs__35, ms__34, lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()).Invoke_O__O(ms__34))); var tmp161 *lang.Var; A_arbace_classes_lower_A_Init(); tmp161 = A_arbace_classes_lower_A_const_71; var tmp162 lang.IFn = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()); var tmp163 any; A_arbace_classes_lower_A_Init(); tmp163 = A_arbace_classes_lower_A_const_211; var tmp164 any = tmp163; var tmp165 *lang.Var; A_arbace_classes_lower_A_Init(); tmp165 = A_arbace_classes_lower_A_const_43; var tmp166 lang.IFn = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()); var tmp167 *lang.Var; A_arbace_classes_lower_A_Init(); tmp167 = A_arbace_classes_lower_A_const_44; var tmp168 lang.IFn = lang.IFn_Cast(jrt.NN(tmp167).GetRawRoot__O()); var tmp169 any = A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_New_O(ptag__29); var tmp170 *jrt.Class; A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_Init(); tmp170 = A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_fn_class; var tmp171 any = tmp168.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp169, tmp170, nil), hinted__27, vs__35); var tmp172 *lang.Var; A_arbace_classes_lower_A_Init(); tmp172 = A_arbace_classes_lower_A_const_62; var tmp173 lang.IFn = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()); var tmp174 any; A_arbace_classes_lower_A_Init(); tmp174 = A_arbace_classes_lower_A_const_217; var tmp175 any = tmp174; var tmp176 *lang.Var; A_arbace_classes_lower_A_Init(); tmp176 = A_arbace_classes_lower_A_const_218; var tmp177 any = tmp173.Invoke_O_O__O(tmp175, lang.IFn_Cast(jrt.NN(tmp176).GetRawRoot__O()).Invoke_O__O(ms__34)); var tmp178 any; A_arbace_classes_lower_A_Init(); tmp178 = A_arbace_classes_lower_A_const_215; var tmp179 any = tmp178; var tmp180 any; A_arbace_classes_lower_A_Init(); tmp180 = A_arbace_classes_lower_A_const_216; tmp114 = lang.Tuple_Create_O__IPersistentVector(tmp128.Invoke_O_O_O_O__O(tmp130, tmp136, tmp147, tmp149.Invoke_O_O_O__O(tmp151, tmp160, tmp162.Invoke_O_O_O__O(tmp164, simple__23, tmp166.Invoke_O_O__O(tmp171, lang.Tuple_Create_O_O_O_O__IPersistentVector(nil, tmp177, tmp179, tmp180)))))) } else { tmp114 = nil }; var tmp181 any = tmp114; var tmp182 /*line :235:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp182 = A_arbace_classes_lower_A_const_44; var tmp183 lang.IFn = lang.IFn_Cast(jrt.NN(tmp182).GetRawRoot__O()); var tmp184 *lang.Var; A_arbace_classes_lower_A_Init(); tmp184 = A_arbace_classes_lower_A_const_157; return tmp46.Invoke_O_O_O_O_O_O_O__O(tmp62, tmp66, tmp88, tmp97, tmp113, tmp181, tmp183.Invoke_O_O__O(jrt.NN(tmp184).GetRawRoot__O(), methods__19)) }
//line :214:1
func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_New_O(p0 any) *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A { A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_fn__1304000123_A{}; t.Ctor_O(p0); return t }
//line :214:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :214:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) Invoke_O__O(self any) any { { var opts__1 any; lang.PersistentArrayMap_Init(); opts__1 = lang.PersistentArrayMap_EMPTY.Ref(); var s__2 any; var t_ any = t.F_more; t.F_more = nil; s__2 = t_; L1: for {
												var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_161; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_14; if jrt.A2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__2))) { var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_128; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_14; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(s__2); var tmp8 *lang.Var; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_162; var tmp9 any = tmp5.Invoke_O_O_O__O(opts__1, tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(s__2)); var tmp10 *lang.Var; A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_163; opts__1, s__2 = tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(s__2); continue L1 } else { return lang.Tuple_Create_O_O__IPersistentVector(opts__1, s__2) } } }; /*line :214:1*/panic("a2g: unreachable") }







func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_New() *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A { A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_fn__1304000125_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) Ctor() {}
//line :222:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) Invoke_O_O__O(self, p1__1304000115_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_171; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_125; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__1304000115_SHARP___1)) }

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_New() *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A { A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_fname__1304000127_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) Ctor() {}
//line :224:1
func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_129; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_125; return tmp2.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__1))) }
func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_New() *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A { A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) Ctor() {}
//line :225:1
func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) Invoke_O_O__O(self, f__1 any) any { var t__2 any; var tmp1 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_46; var tmp2 *lang.Keyword = tmp1; t__2 = jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__1)); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t__2)) { return t__2 } else { return nil } }
func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_New_O_O(p0, p1 any) *A_arbace_classes_lower_deftype_class_form_param__1304000131_A { A_arbace_classes_lower_deftype_class_form_param__1304000131_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_param__1304000131_A{}; t.Ctor_O_O(p0, p1); return t }
//line :226:1
func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) Ctor_O_O(c__ptag, c__fname any) { t.F_ptag = c__ptag; t.F_fname = c__fname }
//line :226:1
func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) Invoke_O_O__O(self, f__1 any) any { var temp__1927000408__auto____2 any = lang.IFn_Cast(t.F_ptag).Invoke_O__O(f__1); if jrt.A2g_Truth(temp__1927000408__auto____2) { var t__3 any = temp__1927000408__auto____2; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_64; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(t.F_fname).Invoke_O__O(f__1); var tmp4 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_46; return tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4.Ref(), t__3))) } else { return lang.IFn_Cast(t.F_fname).Invoke_O__O(f__1) } }

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A { A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :228:1
func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) Ctor_O_O_O_O(c__fields, c__rcv, c__param, c__fname any) { t.F_fields = c__fields; t.F_rcv = c__rcv; t.F_param = c__param; t.F_fname = c__fname }
//line :228:1
func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) Invoke_O_O_O__O(self, k__1, tail__2 any) any {
	var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_166; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_64; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_49; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_56; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = t.F_rcv; var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_44; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = t.F_param; var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_168; var tmp16 any = tmp8.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(k__1, t.F_fields)))); var tmp17 any; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_167; var tmp18 any = tmp6.Invoke_O_O__O(tmp16, tmp17); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_71; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_169; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_43; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_44; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any = t.F_fname; var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_168; return tmp2.Invoke_O_O_O__O(tmp4, tmp18, tmp20.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O_O__O(k__1, t.F_fields)), tail__2)))
}
func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_New() *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) Ctor() {}
//line :231:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) Invoke_O_O__O(self, s__1304000136__1 any) any { var tmp1 any = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_New_O_O(self, s__1304000136__1); var tmp2 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_Init(); tmp2 = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :231:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_New_O_O(p0, p1 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A{}; t.Ctor_O_O(p0, p1); return t }
//line :231:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) Ctor_O_O(c__iter__1304000135, c__s__1304000136 any) { t.F_iter__1304000135 = c__iter__1304000135; t.F_s__1304000136 = c__s__1304000136 }
//line :231:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) Invoke_O__O(self any) any { { var s__1304000136__1 any; var t_ any = t.F_s__1304000136; t.F_s__1304000136 = nil; s__1304000136__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000136__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000136__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000136__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000136__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000138__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000138__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_New_O_I_O(b__1304000138__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_Init(); tmp6 = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000138__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000135); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000136__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000138__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000136__3); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_56; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; var tmp20 *lang.Var
																A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__4))) {
																	var tmp21 *lang.Var; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_62; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_173; var tmp24 any = tmp23; var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_62; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_174; var tmp28 any = tmp27; var tmp29 *lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_9; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_125; var tmp32 any = tmp26.Invoke_O_O__O(tmp28, tmp30.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(f__4))); var tmp33 *lang.Var; A_arbace_classes_lower_A_Init(); tmp33 = A_arbace_classes_lower_A_const_62; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_classes_lower_A_Init(); tmp35 = A_arbace_classes_lower_A_const_175; var tmp36 any = tmp35; tmp19 = tmp22.Invoke_O_O_O__O(tmp24, tmp32, tmp34.Invoke_O_O__O(tmp36, lang.RT_Meta_O__IPersistentMap(f__4))) } else {
																		var tmp37 *lang.Var; A_arbace_classes_lower_A_Init(); tmp37 = A_arbace_classes_lower_A_const_62; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_classes_lower_A_Init(); tmp39 = A_arbace_classes_lower_A_const_176; var tmp40 any = tmp39; var tmp41 *lang.Var; A_arbace_classes_lower_A_Init(); tmp41 = A_arbace_classes_lower_A_const_9; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_classes_lower_A_Init(); tmp43 = A_arbace_classes_lower_A_const_125; tmp19 = tmp38.Invoke_O_O__O(tmp40, tmp42.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(f__4))) }
//line :231:1
	var tmp44 any = tmp19; var tmp45 lang.IFn = lang.IFn_Cast(t.F_iter__1304000135); var tmp46 *lang.Var; A_arbace_classes_lower_A_Init(); tmp46 = A_arbace_classes_lower_A_const_21; return tmp18.Invoke_O_O__O(tmp44, tmp45.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(s__1304000136__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :231:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :231:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) Ctor_O_I_O(c__b__1304000138 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000138 = c__b__1304000138; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :231:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) Invoke_O__O(self any) any { { var i__1304000137__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000137__1)); var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_53; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1304000138; var tmp5 any; var tmp6 *lang.Var
																		A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__2))) {
																			var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_62; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_173; var tmp10 any = tmp9; var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_62; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_174; var tmp14 any = tmp13; var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_125; var tmp18 any = tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(f__2))); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_62; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_175; var tmp22 any = tmp21; tmp5 = tmp8.Invoke_O_O_O__O(tmp10, tmp18, tmp20.Invoke_O_O__O(tmp22, lang.RT_Meta_O__IPersistentMap(f__2))) } else {
																				var tmp23 *lang.Var; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_62; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_176; var tmp26 any = tmp25; var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_125; tmp5 = tmp24.Invoke_O_O__O(tmp26, tmp28.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(f__2))) }
//line :231:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__1304000137__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000137__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }









func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_New_O_O(p0, p1 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) Ctor_O_O(c__ptag, c__fname any) { t.F_ptag = c__ptag; t.F_fname = c__fname }
//line :241:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) Invoke_O_O__O(self, s__1304000146__1 any) any { var tmp1 any = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_New_O_O_O_O(self, t.F_ptag, t.F_fname, s__1304000146__1); var tmp2 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_Init(); tmp2 = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :241:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :241:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) Ctor_O_O_O_O(c__iter__1304000145, c__ptag, c__fname, c__s__1304000146 any) { t.F_iter__1304000145 = c__iter__1304000145; t.F_ptag = c__ptag; t.F_fname = c__fname; t.F_s__1304000146 = c__s__1304000146 }
//line :241:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) Invoke_O__O(self any) any { { var s__1304000146__1 any; var t_ any = t.F_s__1304000146; t.F_s__1304000146 = nil; s__1304000146__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000146__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000146__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000146__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000146__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000148__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000148__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_New_O_O_O_I_O(b__1304000148__6, t.F_ptag, t.F_fname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_Init(); tmp6 = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000148__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000145); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000146__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000148__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000146__3); var m__5 any = lang.RT_Meta_O__IPersistentMap(f__4); var t__6 any; var tmp17 *lang.Keyword
																A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_46; t__6 = jrt.NN(tmp17).Invoke_O__O(m__5)
//line :241:1
	var tmp18 *lang.Var; A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_56; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_62; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_177; var tmp23 any = tmp22; var tmp24 *lang.Var; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_64; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any = lang.IFn_Cast(t.F_fname).Invoke_O__O(f__4); var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_178; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_179; var tmp30 any = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(m__5); var tmp31 any; var tmp32 *lang.Keyword



	A_arbace_classes_lower_A_Init(); tmp32 = A_arbace_classes_lower_A_const_180; if jrt.A2g_Truth(jrt.NN(tmp32).Invoke_O__O(m__5)) { A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_186 } else { var tmp33 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp33 = A_arbace_classes_lower_A_const_182; if jrt.A2g_Truth(jrt.NN(tmp33).Invoke_O__O(m__5)) { lang.PersistentArrayMap_Init(); tmp31 = lang.PersistentArrayMap_EMPTY.Ref() } else { var tmp34 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp34 = A_arbace_classes_lower_A_const_37; if tmp34 != nil { A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_187 } else { tmp31 = nil } } }
//line :241:1
	var tmp35 any = tmp31; var tmp36 lang.IPersistentMap






	if jrt.A2g_Truth(lang.IFn_Cast(t.F_ptag).Invoke_O__O(f__4)) { var tmp37 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp37 = A_arbace_classes_lower_A_const_46; tmp36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37.Ref(), t__6)) } else { var tmp38 *lang.Var; A_arbace_classes_lower_A_Init(); tmp38 = A_arbace_classes_lower_A_const_184; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(t__6)) { var tmp39 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp39 = A_arbace_classes_lower_A_const_185; tmp36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp39.Ref(), t__6)) } else { tmp36 = nil } }
//line :241:1
	var tmp40 any = tmp21.Invoke_O_O__O(tmp23, tmp25.Invoke_O_O__O(tmp26, tmp28.Invoke_O_O_O__O(tmp30, tmp35, tmp36))); var tmp41 lang.IFn = lang.IFn_Cast(t.F_iter__1304000145); var tmp42 *lang.Var; A_arbace_classes_lower_A_Init(); tmp42 = A_arbace_classes_lower_A_const_21; return tmp19.Invoke_O_O__O(tmp40, tmp41.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(s__1304000146__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :241:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :241:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) Ctor_O_O_O_I_O(c__b__1304000148, c__ptag, c__fname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000148 = c__b__1304000148; t.F_ptag = c__ptag; t.F_fname = c__fname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :241:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) Invoke_O__O(self any) any { { var i__1304000147__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000147__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000147__1)); var m__3 any = lang.RT_Meta_O__IPersistentMap(f__2); var t__4 any; var tmp2 *lang.Keyword
																		A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_46; t__4 = jrt.NN(tmp2).Invoke_O__O(m__3)
//line :241:1
	var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_53; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_b__1304000148; var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_62; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_177; var tmp9 any = tmp8; var tmp10 *lang.Var; A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_64; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = lang.IFn_Cast(t.F_fname).Invoke_O__O(f__2); var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_178; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_179; var tmp16 any = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(m__3); var tmp17 any; var tmp18 *lang.Keyword



	A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_180; if jrt.A2g_Truth(jrt.NN(tmp18).Invoke_O__O(m__3)) { A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_181 } else { var tmp19 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_182; if jrt.A2g_Truth(jrt.NN(tmp19).Invoke_O__O(m__3)) { lang.PersistentArrayMap_Init(); tmp17 = lang.PersistentArrayMap_EMPTY.Ref() } else { var tmp20 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_37; if tmp20 != nil { A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_183 } else { tmp17 = nil } } }
//line :241:1
	var tmp21 any = tmp17; var tmp22 lang.IPersistentMap






	if jrt.A2g_Truth(lang.IFn_Cast(t.F_ptag).Invoke_O__O(f__2)) { var tmp23 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_46; tmp22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp23.Ref(), t__4)) } else { var tmp24 *lang.Var; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_184; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(t__4)) { var tmp25 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_185; tmp22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25.Ref(), t__4)) } else { tmp22 = nil } }
//line :241:1
	tmp4.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp9, tmp11.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O_O__O(tmp16, tmp21, tmp22)))); i__1304000147__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000147__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_New_O_O(p0, p1 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A{}; t.Ctor_O_O(p0, p1); return t }
//line :252:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) Ctor_O_O(c__rcv, c__fname any) { t.F_rcv = c__rcv; t.F_fname = c__fname }
//line :252:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) Invoke_O_O__O(self, s__1304000156__1 any) any { var tmp1 any = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_New_O_O_O_O(t.F_rcv, t.F_fname, s__1304000156__1, self); var tmp2 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_Init(); tmp2 = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :252:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :252:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) Ctor_O_O_O_O(c__rcv, c__fname, c__s__1304000156, c__iter__1304000155 any) { t.F_rcv = c__rcv; t.F_fname = c__fname; t.F_s__1304000156 = c__s__1304000156; t.F_iter__1304000155 = c__iter__1304000155 }
//line :252:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) Invoke_O__O(self any) any { { var s__1304000156__1 any; var t_ any = t.F_s__1304000156; t.F_s__1304000156 = nil; s__1304000156__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000156__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000156__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000156__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000156__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000158__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000158__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_New_O_O_O_I_O(b__1304000158__6, t.F_rcv, t.F_fname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_Init(); tmp6 = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000158__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000155); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000156__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000158__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000156__3); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_56; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_62; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_191; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_62; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_9; var tmp26 any = tmp20.Invoke_O_O_O__O(tmp22, tmp24.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_229, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(t.F_fname).Invoke_O__O(f__4))).Ref()), t.F_rcv), lang.IFn_Cast(t.F_fname).Invoke_O__O(f__4)); var tmp27 lang.IFn = lang.IFn_Cast(t.F_iter__1304000155); var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_21; return tmp18.Invoke_O_O__O(tmp26, tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(s__1304000156__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :252:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :252:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) Ctor_O_O_O_I_O(c__b__1304000158, c__rcv, c__fname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000158 = c__b__1304000158; t.F_rcv = c__rcv; t.F_fname = c__fname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :252:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) Invoke_O__O(self any) any { { var i__1304000157__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000157__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000157__1)); var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_53; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1304000158; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_62; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_191; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_62; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_9; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_229, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(t.F_fname).Invoke_O__O(f__2))).Ref()), t.F_rcv), lang.IFn_Cast(t.F_fname).Invoke_O__O(f__2))); i__1304000157__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000157__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }







func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_New() *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) Ctor() {}
//line :260:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) Invoke_O_O__O(self, s__1304000166__1 any) any { var tmp1 any = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_New_O_O(s__1304000166__1, self); var tmp2 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_Init(); tmp2 = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :260:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_New_O_O(p0, p1 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A{}; t.Ctor_O_O(p0, p1); return t }
//line :260:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) Ctor_O_O(c__s__1304000166, c__iter__1304000165 any) { t.F_s__1304000166 = c__s__1304000166; t.F_iter__1304000165 = c__iter__1304000165 }
//line :260:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) Invoke_O__O(self any) any { { var s__1304000166__1 any; var t_ any = t.F_s__1304000166; t.F_s__1304000166 = nil; s__1304000166__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000166__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000166__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000166__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000166__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000168__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000168__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_New_O_I_O(b__1304000168__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_Init(); tmp6 = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000168__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000165); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000166__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000168__6), nil) } } else { var k__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; k__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000166__3); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_56; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_67; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_233, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__4)).Ref()); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1304000165); var tmp22 *lang.Var; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_21; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1304000166__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :260:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :260:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) Ctor_O_I_O(c__b__1304000168 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000168 = c__b__1304000168; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :260:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) Invoke_O__O(self any) any { { var i__1304000167__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000167__1)); var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_53; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1304000168; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_67; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_233, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__2)).Ref())); i__1304000167__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000167__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_New_O(p0 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A{}; t.Ctor_O(p0); return t }
//line :261:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :261:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) Invoke_O_O__O(self, s__1304000176__1 any) any { var tmp1 any = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_New_O_O_O(t.F_fname, s__1304000176__1, self); var tmp2 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_Init(); tmp2 = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :261:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :261:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) Ctor_O_O_O(c__fname, c__s__1304000176, c__iter__1304000175 any) { t.F_fname = c__fname; t.F_s__1304000176 = c__s__1304000176; t.F_iter__1304000175 = c__iter__1304000175 }
//line :261:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) Invoke_O__O(self any) any { { var s__1304000176__1 any; var t_ any = t.F_s__1304000176; t.F_s__1304000176 = nil; s__1304000176__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000176__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000176__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000176__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000176__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000178__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000178__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_New_O_O_I_O(b__1304000178__6, t.F_fname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_Init(); tmp6 = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000178__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000175); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000176__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000178__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000176__3); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_56; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_67; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_125; var tmp22 any = tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_fname).Invoke_O__O(f__4))); var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__1304000175); var tmp24 *lang.Var; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_21; return tmp18.Invoke_O_O__O(tmp22, tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(s__1304000176__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :261:1
func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :261:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) Ctor_O_O_I_O(c__b__1304000178, c__fname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000178 = c__b__1304000178; t.F_fname = c__fname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :261:1
func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) Invoke_O__O(self any) any { { var i__1304000177__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000177__1)); var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_53; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1304000178; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_67; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_125; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_fname).Invoke_O__O(f__2)))); i__1304000177__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000177__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_New() *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A { A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_fn__1304000185_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) Ctor() {}
//line :265:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) Invoke_O_O_O_O_O__O(self, f__1, v__2, m0__3, m1__4 any) any { var k__5 any; var tmp1 *lang.Var;
																	A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_206; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_125; k__5 = tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__1)); var tmp6 /*line :265:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_62; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_207; var tmp9 any = tmp8; var tmp10 any; A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_208; var tmp11 any = tmp7.Invoke_O_O_O_O_O__O(tmp9, m0__3, tmp10, k__5, nil); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_62; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_209; var tmp15 any = tmp14; var tmp16 any; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_210; return lang.Tuple_Create_O_O_O_O__IPersistentVector(v__2, tmp11, m1__4, tmp13.Invoke_O_O_O_O__O(tmp15, m0__3, tmp16, k__5)) }





func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_New_O(p0 any) *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A { A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_Init(); t := &A_arbace_classes_lower_deftype_class_form_fn__1304000187_A{}; t.Ctor_O(p0); return t }
//line :271:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) Ctor_O(c__ptag any) { t.F_ptag = c__ptag }
//line :271:1
func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) Invoke_O_O_O__O(self, f__1, v__2 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(t.F_ptag).Invoke_O__O(f__1); if
														jrt.A2g_Truth(temp__1927000408__auto____3) { var t__4 any = temp__1927000408__auto____3; var tmp1 *lang.Var
															A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_212; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_62; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_213; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_214; var tmp10 any = tmp6.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(t__4), v__2); var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_9; return tmp2.Invoke_O_O_O__O(tmp4, tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_219), jrt.RefArrayOf(jrt.Object_class, t__4, nil)).Ref())) } else {
//line :272:1
			return v__2 } }










func A_arbace_classes_lower_symbols_in_A_New() *A_arbace_classes_lower_symbols_in_A { A_arbace_classes_lower_symbols_in_A_Init(); t := &A_arbace_classes_lower_symbols_in_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_classes_lower_symbols_in_A) Ctor() {}
//line :283:1
func (t *A_arbace_classes_lower_symbols_in_A) Invoke_O_O__O(self, form__0 any) any {


	var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__0)) {
		var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(form__0)) { lang.PersistentHashSet_Init(); return lang.PersistentHashSet_EMPTY.Ref() } else { return lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, form__0)) } } else {
//line :286:1
			var tmp3 any; var or__1927000174__auto____2 any; var tmp4 *lang.Var

			A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_24; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(form__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp3 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_17; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(form__0); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_219; tmp3 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(form__0) } }
//line :286:1
			if jrt.A2g_Truth(tmp3) {

				var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_220; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_159; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp11 = lang.PersistentHashSet_EMPTY; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_44; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_131; return tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp14.Invoke_O_O__O(jrt.NN(tmp15).GetRawRoot__O(), form__0)) } else {
//line :286:1
					var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_221; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(form__0)) {


						var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_220; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_159; var tmp20 any = jrt.NN(tmp19).GetRawRoot__O(); var tmp21 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp21 = lang.PersistentHashSet_EMPTY; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_44; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_131; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Var; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_60; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_222; return tmp18.Invoke_O_O_O__O(tmp20, tmp22, tmp24.Invoke_O_O__O(tmp26, tmp28.Invoke_O_O__O(jrt.NN(tmp29).GetRawRoot__O(), form__0))) } else {
//line :286:1
							var tmp30 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp30 = A_arbace_classes_lower_A_const_37; if tmp30 != nil { lang.PersistentHashSet_Init(); return lang.PersistentHashSet_EMPTY.Ref() } else { return nil
							}
						}
				}
		}
}
func A_arbace_classes_lower_lower_letfn_A_New() *A_arbace_classes_lower_lower_letfn_A { A_arbace_classes_lower_lower_letfn_A_Init(); t := &A_arbace_classes_lower_lower_letfn_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_classes_lower_lower_letfn_A) Ctor() {}
//line :292:1
func (t *A_arbace_classes_lower_lower_letfn_A) Invoke_O_O_O__O(self, p__1304000192__0, expand__1 any) any { var vec__1304000193__3 any = p__1304000192__0; var seq__1304000194__4 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; seq__1304000194__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1304000193__3); var first__1304000195__5 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_14; first__1304000195__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1304000194__4); var seq__1304000194__6 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_15; seq__1304000194__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1304000194__4); var ___7 any = first__1304000195__5; var first__1304000195__8 any; var tmp4 *lang.Var; _ = ___7; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_14; first__1304000195__8 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1304000194__6); var seq__1304000194__9 any; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_15; seq__1304000194__9 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1304000194__6); var bindings__10 any = first__1304000195__8; var body__11 any = seq__1304000194__9; var pairs__12 any; var tmp6 *lang.Var;



	A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_223; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_232; pairs__12 = tmp7.Invoke_O_O__O(tmp8, bindings__10); var names__13 any; var tmp9 /*line :292:1*/*lang.Var;




	A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_44; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_14; names__13 = tmp10.Invoke_O_O__O(jrt.NN(tmp11).GetRawRoot__O(), pairs__12); var boxes__14 any; var tmp12 /*line :292:1*/*lang.Var;





	A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_224; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_44; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = A_arbace_classes_lower_lower_letfn_fn__1304000196_A_New(); var tmp17 *jrt.Class; A_arbace_classes_lower_lower_letfn_fn__1304000196_A_Init(); tmp17 = A_arbace_classes_lower_lower_letfn_fn__1304000196_A_fn_class; boxes__14 = tmp13.Invoke_O_O__O(names__13, tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), names__13)); var with_others__15 any; var tmp18 any = /*line :292:1*/A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_New_O_O_O(boxes__14, expand__1, names__13); var tmp19 *jrt.Class;






	A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_Init(); tmp19 = A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_fn_class; with_others__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp20 /*line :314:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_71; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_233; var tmp23 any = tmp22; var tmp24 *lang.Var; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_49; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_43; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_60; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any = A_arbace_classes_lower_lower_letfn_fn__1304000222_A_New_O(boxes__14); var tmp31 *jrt.Class; A_arbace_classes_lower_lower_letfn_fn__1304000222_A_Init(); tmp31 = A_arbace_classes_lower_lower_letfn_fn__1304000222_A_fn_class; var tmp32 any = tmp29.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil), names__13); var tmp33 *lang.Var; A_arbace_classes_lower_A_Init(); tmp33 = A_arbace_classes_lower_A_const_60; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any = A_arbace_classes_lower_lower_letfn_fn__1304000225_A_New_O(with_others__15); var tmp36 *jrt.Class; A_arbace_classes_lower_lower_letfn_fn__1304000225_A_Init(); tmp36 = A_arbace_classes_lower_lower_letfn_fn__1304000225_A_fn_class; var tmp37 any = tmp25.Invoke_O__O(tmp27.Invoke_O_O__O(tmp32, tmp34.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil), pairs__12))); var tmp38 *lang.Var; A_arbace_classes_lower_A_Init(); tmp38 = A_arbace_classes_lower_A_const_43; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; var iter__1927001039__auto____16 any; var tmp41 any = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_New_O(boxes__14); var tmp42 *jrt.Class;

	A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_Init(); tmp42 = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_fn_class; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil); tmp40 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(names__13); return /*line :314:1*/ tmp21.Invoke_O_O_O__O(tmp23, tmp37, tmp39.Invoke_O_O__O(tmp40, body__11)) }
//line :298:1
func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_New() *A_arbace_classes_lower_lower_letfn_fn__1304000196_A { A_arbace_classes_lower_lower_letfn_fn__1304000196_A_Init(); t := &A_arbace_classes_lower_lower_letfn_fn__1304000196_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) Ctor() {}
//line :298:1
func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) Invoke_O_O__O(self, p1__1304000191_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_67; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_271, nil); var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_125; return tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(p1__1304000191_SHARP___1))).Ref()) }
func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A { A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_Init(); t := &A_arbace_classes_lower_lower_letfn_with_others__1304000198_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :299:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) Ctor_O_O_O(c__boxes, c__expand, c__names any) { t.F_boxes = c__boxes; t.F_expand = c__expand; t.F_names = c__names }
//line :299:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) Invoke_O_O_O__O(self, self__1, init__2 any) any { var fn_form__3 any = lang.IFn_Cast(t.F_expand).Invoke_O__O(init__2); var ___4 any; var tmp1 any; var and__1927000168__auto____4 any; var tmp2 *lang.Var; _ = ___4;

	A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_24; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(fn_form__3); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_225; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_14; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(fn_form__3))).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) { ___4 = nil } else { var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_25; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_278, nil); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_26; var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(init__2))).Ref(); var tmp11 any; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_227; panic(jrt.Thrown(jrt.Throwable_Cast(tmp7.Invoke_O_O__O(tmp10, tmp11)))) }; var map__1304000199__5 any; var tmp12 /*line :299:1*/*lang.Var;




	A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_105; map__1304000199__5 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(fn_form__3); var map__1304000199__6 any; if /*line :300:1*/ lang.ISeq_InstanceOf(map__1304000199__5) { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(map__1304000199__5)) { var tmp14 *lang.Var; A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_106; map__1304000199__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(map__1304000199__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(map__1304000199__5)) { var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; map__1304000199__6 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(map__1304000199__5) } else { lang.PersistentArrayMap_Init(); map__1304000199__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1304000199__6 = map__1304000199__5 }; var nm__7 any; var tmp17 /*line :299:1*/*lang.Keyword;
	A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_18; nm__7 = lang.RT_Get_O_O__O(map__1304000199__6, tmp17.Ref()); var arities__8 any; var tmp18 /*line :299:1*/*lang.Keyword;
	A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_19; arities__8 = lang.RT_Get_O_O__O(map__1304000199__6, tmp18.Ref()); var others__9 any; var tmp19 /*line :299:1*/*lang.Var;





	A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_226; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_228; others__9 = tmp20.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(self__1, nm__7)), t.F_names); var tmp22 /*line :306:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_64; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_71; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_229; var tmp27 any = tmp26; var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_43; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 lang.IPersistentVector; if
	jrt.A2g_Truth(nm__7) { tmp30 = lang.Tuple_Create_O__IPersistentVector(nm__7) } else { tmp30 = nil }; var tmp31 any = tmp30; var tmp32 any; var iter__1927001039__auto____10 any; var tmp33 any = /*line :306:1*/A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_New_O_O(t.F_boxes, others__9); var tmp34 *jrt.Class;

	A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_Init(); tmp34 = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_fn_class; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); tmp32 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(arities__8); return /*line :306:1*/ tmp23.Invoke_O_O__O(tmp25.Invoke_O_O__O(tmp27, tmp29.Invoke_O_O__O(tmp31, tmp32)), lang.RT_Meta_O__IPersistentMap(fn_form__3)) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_New_O_O(p0, p1 any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_Init(); t := &A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A{}; t.Ctor_O_O(p0, p1); return t }
//line :308:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) Ctor_O_O(c__boxes, c__others any) { t.F_boxes = c__boxes; t.F_others = c__others }
//line :308:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) Invoke_O_O__O(self, s__1304000202__1 any) any { var tmp1 any = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_New_O_O_O_O(self, t.F_boxes, t.F_others, s__1304000202__1); var tmp2 *jrt.Class; A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_Init(); tmp2 = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :308:1
func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_Init(); t := &A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :308:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) Ctor_O_O_O_O(c__iter__1304000201, c__boxes, c__others, c__s__1304000202 any) { t.F_iter__1304000201 = c__iter__1304000201; t.F_boxes = c__boxes; t.F_others = c__others; t.F_s__1304000202 = c__s__1304000202 }
//line :308:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) Invoke_O__O(self any) any { { var s__1304000202__1 any; var t_ any = t.F_s__1304000202; t.F_s__1304000202 = nil; s__1304000202__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000202__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000202__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000202__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000202__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000204__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000204__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_New_O_O_O_I_O(b__1304000204__6, t.F_boxes, t.F_others, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_Init(); tmp6 = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000204__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000201); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000202__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000204__6), nil) } } else { var vec__1304000214__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; vec__1304000214__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000202__3); var pv__5 any = lang.RT_Nth_O_I_O__O(vec__1304000214__4, lang.RT_IntCast_J__I(0), nil); var body__6 any = lang.RT_Nth_O_I_O__O(vec__1304000214__4, lang.RT_IntCast_J__I(1), nil); var ps__7 any; var tmp17 *lang.Var
																		A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_228; ps__7 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(pv__5)
//line :308:1
	var bs__8 any; var tmp18 *lang.Var

	A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_49; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_60; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_New_O(t.F_boxes); var tmp23 *jrt.Class; A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_Init(); tmp23 = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_fn_class; var tmp24 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_226; bs__8 = tmp19.Invoke_O__O(tmp21.Invoke_O_O__O(tmp24, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(ps__7, t.F_others)))
//line :308:1
	var tmp26 *lang.Var; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_56; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_62; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_classes_lower_A_Init(); tmp30 = A_arbace_classes_lower_A_const_71; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any; A_arbace_classes_lower_A_Init(); tmp32 = A_arbace_classes_lower_A_const_231; var tmp33 any = tmp29.Invoke_O_O__O(pv__5, tmp31.Invoke_O_O_O__O(tmp32, bs__8, body__6)); var tmp34 lang.IFn = lang.IFn_Cast(t.F_iter__1304000201); var tmp35 *lang.Var; A_arbace_classes_lower_A_Init(); tmp35 = A_arbace_classes_lower_A_const_21; return tmp27.Invoke_O_O__O(tmp33, tmp34.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(s__1304000202__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :308:1
func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_Init(); t := &A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :308:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) Ctor_O_O_O_I_O(c__b__1304000204, c__boxes, c__others any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000204 = c__b__1304000204; t.F_boxes = c__boxes; t.F_others = c__others; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :308:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) Invoke_O__O(self any) any { { var i__1304000203__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000203__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1304000208__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000203__1)); var pv__3 any = lang.RT_Nth_O_I_O__O(vec__1304000208__2, lang.RT_IntCast_J__I(0), nil); var body__4 any = lang.RT_Nth_O_I_O__O(vec__1304000208__2, lang.RT_IntCast_J__I(1), nil); var ps__5 any; var tmp2 *lang.Var
																				A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_228; ps__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(pv__3)
//line :308:1
	var bs__6 any; var tmp3 *lang.Var

	A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_49; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_60; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_New_O(t.F_boxes); var tmp8 *jrt.Class; A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_Init(); tmp8 = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Var; A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_226; bs__6 = tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(ps__5, t.F_others)))
//line :308:1
	var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_53; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = t.F_b__1304000204; var tmp14 *lang.Var; A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_62; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_71; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_231; tmp12.Invoke_O_O__O(tmp13, tmp15.Invoke_O_O__O(pv__3, tmp17.Invoke_O_O_O__O(tmp18, bs__6, body__4))); i__1304000203__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000203__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_New_O(p0 any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_Init(); t := &A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) Ctor_O(c__boxes any) { t.F_boxes = c__boxes }
//line :310:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) Invoke_O_O__O(self, o__1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_230; var tmp4 any = tmp3; return lang.Tuple_Create_O_O__IPersistentVector(o__1, tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(t.F_boxes).Invoke_O__O(o__1))) }
//line :310:1
func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_New_O(p0 any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_Init(); t := &A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) Ctor_O(c__boxes any) { t.F_boxes = c__boxes }
//line :310:1
func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) Invoke_O_O__O(self, o__1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_230; var tmp4 any = tmp3; return lang.Tuple_Create_O_O__IPersistentVector(o__1, tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(t.F_boxes).Invoke_O__O(o__1))) }



func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_New_O(p0 any) *A_arbace_classes_lower_lower_letfn_fn__1304000222_A { A_arbace_classes_lower_lower_letfn_fn__1304000222_A_Init(); t := &A_arbace_classes_lower_lower_letfn_fn__1304000222_A{}; t.Ctor_O(p0); return t }
//line :314:1
func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) Ctor_O(c__boxes any) { t.F_boxes = c__boxes }
//line :314:1
func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any = lang.IFn_Cast(t.F_boxes).Invoke_O__O(n__1); var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_62; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_234; var tmp5 any = tmp4; var tmp6 any; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_235; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp3.Invoke_O_O_O__O(tmp5, tmp6, nil)) }
func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_New_O(p0 any) *A_arbace_classes_lower_lower_letfn_fn__1304000225_A { A_arbace_classes_lower_lower_letfn_fn__1304000225_A_Init(); t := &A_arbace_classes_lower_lower_letfn_fn__1304000225_A{}; t.Ctor_O(p0); return t }
//line :315:1
func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) Ctor_O(c__with_others any) { t.F_with_others = c__with_others }
//line :315:1
func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) Invoke_O_O__O(self, p__1304000224__1 any) any { var vec__1304000226__2 any = p__1304000224__1; var n__3 any = lang.RT_Nth_O_I_O__O(vec__1304000226__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__1304000226__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(n__3, lang.IFn_Cast(t.F_with_others).Invoke_O_O__O(n__3, f__4)) }
func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_New_O(p0 any) *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_Init(); t := &A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A{}; t.Ctor_O(p0); return t }
//line :316:1
func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) Ctor_O(c__boxes any) { t.F_boxes = c__boxes }
//line :316:1
func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) Invoke_O_O__O(self, s__1304000231__1 any) any { var tmp1 any = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_New_O_O_O(t.F_boxes, s__1304000231__1, self); var tmp2 *jrt.Class; A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_Init(); tmp2 = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :316:1
func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_Init(); t := &A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :316:1
func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) Ctor_O_O_O(c__boxes, c__s__1304000231, c__iter__1304000230 any) { t.F_boxes = c__boxes; t.F_s__1304000231 = c__s__1304000231; t.F_iter__1304000230 = c__iter__1304000230 }
//line :316:1
func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) Invoke_O__O(self any) any { { var s__1304000231__1 any; var t_ any = t.F_s__1304000231; t.F_s__1304000231 = nil; s__1304000231__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1304000231__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1304000231__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1304000231__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1304000231__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1304000233__6 any; var tmp4 *lang.Var; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_51; b__1304000233__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_New_O_O_I_O(b__1304000233__6, t.F_boxes, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_Init(); tmp6 = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_55; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_57; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1304000233__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1304000230); var tmp12 *lang.Var; A_arbace_classes_lower_A_Init(); tmp12 = A_arbace_classes_lower_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1304000231__3))) } else { var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_55; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_lower_A_Init(); tmp15 = A_arbace_classes_lower_A_const_57; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1304000233__6), nil) } } else { var n__4 any; var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_14; n__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1304000231__3); var tmp17 *lang.Var; A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_56; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_62; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_236; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_classes_lower_A_Init(); tmp23 = A_arbace_classes_lower_A_const_62; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_237; var tmp26 any = tmp25; var tmp27 any = tmp20.Invoke_O_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp26, lang.IFn_Cast(t.F_boxes).Invoke_O__O(n__4)), n__4); var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__1304000230); var tmp29 *lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_21; return tmp18.Invoke_O_O__O(tmp27, tmp28.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(s__1304000231__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :316:1
func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_Init(); t := &A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :316:1
func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) Ctor_O_O_I_O(c__b__1304000233, c__boxes any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1304000233 = c__b__1304000233; t.F_boxes = c__boxes; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :316:1
func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) Invoke_O__O(self any) any { { var i__1304000232__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1304000232__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1304000232__1)); var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_53; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1304000233; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_62; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_236; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_62; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_237; var tmp12 any = tmp11; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O_O__O(tmp12, lang.IFn_Cast(t.F_boxes).Invoke_O__O(n__2)), n__2)); i__1304000232__1 = lang.Numbers_Unchecked_inc_J__J(i__1304000232__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_classes_lower_lower_case_A_New() *A_arbace_classes_lower_lower_case_A { A_arbace_classes_lower_lower_case_A_Init(); t := &A_arbace_classes_lower_lower_case_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_classes_lower_lower_case_A) Ctor() {}
//line :322:1
func (t *A_arbace_classes_lower_lower_case_A) Invoke_O_O_O__O(self, p__1304000241__0, prim_int_QMARK___1 any) any { var vec__1304000242__3 any = p__1304000241__0; var ___4 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(0), nil); var ge__5 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(1), nil); var shift__6 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(2), nil); var mask__7 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(3), nil); var default__8 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(4), nil); var imap__9 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(5), nil); var _switch_type__10 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(6), nil); var test_type__11 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(7), nil); var skip_check__12 any = lang.RT_Nth_O_I_O__O(vec__1304000242__3, lang.RT_IntCast_J__I(8), nil); var L__13_ any; var tmp1 *lang.Var; _ = ___4; _ = _switch_type__10;






	A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_238; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_125; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_67; L__13_ = tmp2.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(Lit_260))); var shift__14 int32 = /*line :322:1*/lang.RT_IntCast_O__I(shift__6); var mask__15 int32 = lang.RT_IntCast_O__I(mask__7); var sm__16 any; var tmp6 any = A_arbace_classes_lower_lower_case_sm__1304000245_A_New_I_I(shift__14, mask__15); var tmp7 *jrt.Class;








	A_arbace_classes_lower_lower_case_sm__1304000245_A_Init(); tmp7 = A_arbace_classes_lower_lower_case_sm__1304000245_A_fn_class; sm__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var skip__17 any; var tmp8 /*line :322:1*/*lang.Var;











	A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_228; skip__17 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(skip_check__12); var arms__18 any; var tmp9 /*line :322:1*/*lang.Var;












	A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_60; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_classes_lower_lower_case_fn__1304000248_A_New_O_O_O_O_O(prim_int_QMARK___1, skip__17, ge__5, test_type__11, L__13_); var tmp12 *jrt.Class; A_arbace_classes_lower_lower_case_fn__1304000248_A_Init(); tmp12 = A_arbace_classes_lower_lower_case_fn__1304000248_A_fn_class; var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 *lang.Var; A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_258; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_160; arms__18 = tmp10.Invoke_O_O__O(tmp13, tmp15.Invoke_O_O__O(jrt.NN(tmp16).GetRawRoot__O(), imap__9)); var sw__19 any; var tmp17 any = /*line :322:1*/A_arbace_classes_lower_lower_case_sw__1304000256_A_New_O(arms__18); var tmp18 *jrt.Class;


























	A_arbace_classes_lower_lower_case_sw__1304000256_A_Init(); tmp18 = A_arbace_classes_lower_lower_case_sw__1304000256_A_fn_class; sw__19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var tmp19 /*line :350:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_62; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_259; var tmp22 any = tmp21; var tmp23 any; var tmp24 *lang.Var;
	A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_65; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_242; if jrt.A2g_Truth(tmp25.Invoke_O_O__O(test_type__11, tmp26.Ref())) {
		var tmp27 lang.IFn = lang.IFn_Cast(sw__19); var tmp28 lang.IFn = lang.IFn_Cast(sm__16); var tmp29 *lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_62; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_260; tmp23 = tmp27.Invoke_O__O(tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(tmp31, ge__5))) } else {
//line :351:1
			if jrt.A2g_Truth(prim_int_QMARK___1) {

				var tmp32 lang.IFn = lang.IFn_Cast(sw__19); var tmp33 lang.IFn = lang.IFn_Cast(sm__16); var tmp34 *lang.Var; A_arbace_classes_lower_A_Init(); tmp34 = A_arbace_classes_lower_A_const_62; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any; A_arbace_classes_lower_A_Init(); tmp36 = A_arbace_classes_lower_A_const_261; tmp23 = tmp32.Invoke_O__O(tmp33.Invoke_O__O(tmp35.Invoke_O_O__O(tmp36, ge__5))) } else {
//line :351:1
					var tmp37 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp37 = A_arbace_classes_lower_A_const_37; if tmp37 != nil {


						var tmp38 *lang.Var; A_arbace_classes_lower_A_Init(); tmp38 = A_arbace_classes_lower_A_const_62; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; A_arbace_classes_lower_A_Init(); tmp40 = A_arbace_classes_lower_A_const_262; var tmp41 any = tmp40; var tmp42 *lang.Var; A_arbace_classes_lower_A_Init(); tmp42 = A_arbace_classes_lower_A_const_62; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 any; A_arbace_classes_lower_A_Init(); tmp44 = A_arbace_classes_lower_A_const_263; var tmp45 any = tmp44; var tmp46 any; A_arbace_classes_lower_A_Init(); tmp46 = A_arbace_classes_lower_A_const_264; var tmp47 any = tmp43.Invoke_O_O_O__O(tmp45, tmp46, ge__5); var tmp48 lang.IFn = lang.IFn_Cast(sw__19); var tmp49 lang.IFn = lang.IFn_Cast(sm__16); var tmp50 *lang.Var; A_arbace_classes_lower_A_Init(); tmp50 = A_arbace_classes_lower_A_const_62; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any; A_arbace_classes_lower_A_Init(); tmp52 = A_arbace_classes_lower_A_const_265; var tmp53 any = tmp52; var tmp54 *lang.Var; A_arbace_classes_lower_A_Init(); tmp54 = A_arbace_classes_lower_A_const_62; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 any; A_arbace_classes_lower_A_Init(); tmp56 = A_arbace_classes_lower_A_const_266; var tmp57 any = tmp56; var tmp58 any; A_arbace_classes_lower_A_Init(); tmp58 = A_arbace_classes_lower_A_const_267; tmp23 = tmp39.Invoke_O_O_O_O__O(tmp41, tmp47, tmp48.Invoke_O__O(tmp49.Invoke_O__O(tmp51.Invoke_O_O__O(tmp53, tmp55.Invoke_O_O_O__O(tmp57, tmp58, ge__5)))), nil) } else {
//line :351:1
							tmp23 = nil } } }; return /*line :350:1*/ tmp20.Invoke_O_O_O_O__O(tmp22, L__13_, tmp23, default__8) }
//line :331:1
func A_arbace_classes_lower_lower_case_sm__1304000245_A_New_I_I(p0, p1 int32) *A_arbace_classes_lower_lower_case_sm__1304000245_A { A_arbace_classes_lower_lower_case_sm__1304000245_A_Init(); t := &A_arbace_classes_lower_lower_case_sm__1304000245_A{}; t.Ctor_I_I(p0, p1); return t }
//line :331:1
func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) Ctor_I_I(c__shift, c__mask int32) { t.F_shift = c__shift; t.F_mask = c__mask }
//line :331:1
func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) Invoke_O_O__O(self, h__1 any) any { if lang.Numbers_IsZero_J__Z(int64(t.F_mask)) { return h__1 } else {

	var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_239; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_62; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_classes_lower_A_Init(); tmp7 = A_arbace_classes_lower_A_const_240; var tmp8 any = tmp7; return tmp2.Invoke_O_O_O__O(tmp4, tmp6.Invoke_O_O_O__O(tmp8, h__1, jrt.Integer_ValueOf_I__Integer(t.F_shift).Ref()), jrt.Integer_ValueOf_I__Integer(t.F_mask).Ref()) } }

func A_arbace_classes_lower_lower_case_fn__1304000248_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_classes_lower_lower_case_fn__1304000248_A { A_arbace_classes_lower_lower_case_fn__1304000248_A_Init(); t := &A_arbace_classes_lower_lower_case_fn__1304000248_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :335:1
func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) Ctor_O_O_O_O_O(c__prim_int_QMARK_, c__skip, c__ge, c__test_type, c__L any) { t.F_prim_int_QMARK_ = c__prim_int_QMARK_; t.F_skip = c__skip; t.F_ge = c__ge; t.F_test_type = c__test_type; t.F_L = c__L }
//line :335:1
func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) Invoke_O_O__O(self, p__1304000247__1 any) any { var vec__1304000249__2 any = p__1304000247__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1304000249__2, lang.RT_IntCast_J__I(0), nil); var vec__1304000252__4 any = lang.RT_Nth_O_I_O__O(vec__1304000249__2, lang.RT_IntCast_J__I(1), nil); var test__5 any = lang.RT_Nth_O_I_O__O(vec__1304000252__4, lang.RT_IntCast_J__I(0), nil); var then__6 any = lang.RT_Nth_O_I_O__O(vec__1304000252__4, lang.RT_IntCast_J__I(1), nil); var tmp1 any = jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(k__3)).Ref(); var tmp2 any; var tmp3 *lang.Var;

	A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_127; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_skip; if jrt.A2g_Truth(tmp4.Invoke_O_O__O(tmp5, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(k__3)).Ref())) {
		var tmp6 *lang.Var; A_arbace_classes_lower_A_Init(); tmp6 = A_arbace_classes_lower_A_const_62; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_244; tmp2 = tmp7.Invoke_O_O_O__O(tmp8, t.F_L, then__6) } else {
//line :337:1
			var tmp9 any = t.F_test_type; var tmp10 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp10 = A_arbace_classes_lower_A_const_242; if lang.Util_Equiv_O_O__Z(tmp9, tmp10.Ref()) {


				var tmp11 *lang.Var; A_arbace_classes_lower_A_Init(); tmp11 = A_arbace_classes_lower_A_const_62; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_245; var tmp14 any = tmp13; var tmp15 any; if jrt.A2g_Truth(t.F_prim_int_QMARK_) {
					var tmp16 *lang.Var; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_62; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; A_arbace_classes_lower_A_Init(); tmp18 = A_arbace_classes_lower_A_const_246; tmp15 = tmp17.Invoke_O_O_O__O(tmp18, t.F_ge, test__5) } else {
						var tmp19 *lang.Var; A_arbace_classes_lower_A_Init(); tmp19 = A_arbace_classes_lower_A_const_62; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_lower_A_Init(); tmp21 = A_arbace_classes_lower_A_const_247; var tmp22 any = tmp21; var tmp23 any = t.F_ge; var tmp24 *lang.Var; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_62; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any; A_arbace_classes_lower_A_Init(); tmp26 = A_arbace_classes_lower_A_const_248; tmp15 = tmp20.Invoke_O_O_O__O(tmp22, tmp23, tmp25.Invoke_O_O__O(tmp26, test__5)) }
//line :340:1
				var tmp27 any = tmp15; var tmp28 *lang.Var; A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_62; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_classes_lower_A_Init(); tmp30 = A_arbace_classes_lower_A_const_249; tmp2 = tmp12.Invoke_O_O_O_O__O(tmp14, tmp27, tmp29.Invoke_O_O_O__O(tmp30, t.F_L, then__6), nil) } else {
//line :337:1
					var tmp31 any = t.F_test_type; var tmp32 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp32 = A_arbace_classes_lower_A_const_243; if lang.Util_Equiv_O_O__Z(tmp31, tmp32.Ref()) {







						var tmp33 *lang.Var; A_arbace_classes_lower_A_Init(); tmp33 = A_arbace_classes_lower_A_const_62; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_classes_lower_A_Init(); tmp35 = A_arbace_classes_lower_A_const_250; var tmp36 any = tmp35; var tmp37 *lang.Var; A_arbace_classes_lower_A_Init(); tmp37 = A_arbace_classes_lower_A_const_62; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_classes_lower_A_Init(); tmp39 = A_arbace_classes_lower_A_const_251; var tmp40 any = tmp39; var tmp41 any = t.F_ge; var tmp42 *lang.Var; A_arbace_classes_lower_A_Init(); tmp42 = A_arbace_classes_lower_A_const_62; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 any; A_arbace_classes_lower_A_Init(); tmp44 = A_arbace_classes_lower_A_const_252; var tmp45 any = tmp38.Invoke_O_O_O__O(tmp40, tmp41, tmp43.Invoke_O_O__O(tmp44, test__5)); var tmp46 *lang.Var; A_arbace_classes_lower_A_Init(); tmp46 = A_arbace_classes_lower_A_const_62; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any; A_arbace_classes_lower_A_Init(); tmp48 = A_arbace_classes_lower_A_const_253; tmp2 = tmp34.Invoke_O_O_O_O__O(tmp36, tmp45, tmp47.Invoke_O_O_O__O(tmp48, t.F_L, then__6), nil) } else {
//line :337:1
							var tmp49 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp49 = A_arbace_classes_lower_A_const_37; if tmp49 != nil {









								var tmp50 *lang.Var; A_arbace_classes_lower_A_Init(); tmp50 = A_arbace_classes_lower_A_const_62; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any; A_arbace_classes_lower_A_Init(); tmp52 = A_arbace_classes_lower_A_const_254; var tmp53 any = tmp52; var tmp54 *lang.Var; A_arbace_classes_lower_A_Init(); tmp54 = A_arbace_classes_lower_A_const_62; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 any; A_arbace_classes_lower_A_Init(); tmp56 = A_arbace_classes_lower_A_const_255; var tmp57 any = tmp56; var tmp58 any = t.F_ge; var tmp59 *lang.Var; A_arbace_classes_lower_A_Init(); tmp59 = A_arbace_classes_lower_A_const_62; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_classes_lower_A_Init(); tmp61 = A_arbace_classes_lower_A_const_256; var tmp62 any = tmp55.Invoke_O_O_O__O(tmp57, tmp58, tmp60.Invoke_O_O__O(tmp61, test__5)); var tmp63 *lang.Var; A_arbace_classes_lower_A_Init(); tmp63 = A_arbace_classes_lower_A_const_62; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 any; A_arbace_classes_lower_A_Init(); tmp65 = A_arbace_classes_lower_A_const_257; tmp2 = tmp51.Invoke_O_O_O_O__O(tmp53, tmp62, tmp64.Invoke_O_O_O__O(tmp65, t.F_L, then__6), nil) } else {
//line :337:1
									tmp2 = nil } } } }; return /*line :335:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }













func A_arbace_classes_lower_lower_case_sw__1304000256_A_New_O(p0 any) *A_arbace_classes_lower_lower_case_sw__1304000256_A { A_arbace_classes_lower_lower_case_sw__1304000256_A_Init(); t := &A_arbace_classes_lower_lower_case_sw__1304000256_A{}; t.Ctor_O(p0); return t }
//line :349:1
func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) Ctor_O(c__arms any) { t.F_arms = c__arms }
//line :349:1
func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) Invoke_O_O__O(self, sel__1 any) any { var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_71; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_241; return tmp2.Invoke_O_O_O__O(tmp3, sel__1, t.F_arms) }












func A_arbace_classes_lower_lower_def_A_New() *A_arbace_classes_lower_lower_def_A { A_arbace_classes_lower_lower_def_A_Init(); t := &A_arbace_classes_lower_lower_def_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_classes_lower_lower_def_A) Ctor() {}
//line :362:1
func (t *A_arbace_classes_lower_lower_def_A) Invoke_O_O_O_O_O__O(self, p__1304000259__0, file__1, line__2, column__3 any) any { var vec__1304000260__5 any = p__1304000259__0; var seq__1304000261__6 any; var tmp1 *lang.Var; A_arbace_classes_lower_A_Init(); tmp1 = A_arbace_classes_lower_A_const_13; seq__1304000261__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1304000260__5); var first__1304000262__7 any; var tmp2 *lang.Var; A_arbace_classes_lower_A_Init(); tmp2 = A_arbace_classes_lower_A_const_14; first__1304000262__7 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1304000261__6); var seq__1304000261__8 any; var tmp3 *lang.Var; A_arbace_classes_lower_A_Init(); tmp3 = A_arbace_classes_lower_A_const_15; seq__1304000261__8 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1304000261__6); var ___9 any = first__1304000262__7; var first__1304000262__10 any; var tmp4 *lang.Var; _ = ___9; A_arbace_classes_lower_A_Init(); tmp4 = A_arbace_classes_lower_A_const_14; first__1304000262__10 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1304000261__8); var seq__1304000261__11 any; var tmp5 *lang.Var; A_arbace_classes_lower_A_Init(); tmp5 = A_arbace_classes_lower_A_const_15; seq__1304000261__11 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1304000261__8); var sym__12 any = first__1304000262__10; var more__13 any = seq__1304000261__11; var vec__1304000263__14 any; var G__1304000266__14_ int32 = lang.RT_Count_O__I(more__13); L1:




switch { default: switch G__1304000266__14_ { case 0: A_arbace_classes_lower_A_Init(); vec__1304000263__14 = A_arbace_classes_lower_A_const_268; break L1; case 1: var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_classes_lower_A_Init(); tmp8 = A_arbace_classes_lower_A_const_14; vec__1304000263__14 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(more__13)); break L1; case 2: var tmp9 *lang.Var; A_arbace_classes_lower_A_Init(); tmp9 = A_arbace_classes_lower_A_const_14; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(more__13); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Var; A_arbace_classes_lower_A_Init(); tmp13 = A_arbace_classes_lower_A_const_162; vec__1304000263__14 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(more__13)); break L1; default:}; var tmp14 *lang.Var; A_arbace_classes_lower_A_Init(); tmp14 = A_arbace_classes_lower_A_const_25; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any; A_arbace_classes_lower_A_Init(); tmp16 = A_arbace_classes_lower_A_const_269; panic(jrt.Thrown(jrt.Throwable_Cast(tmp15.Invoke_O_O__O(Lit_265, tmp16))))}; var doc__15 any = /*line :362:1*/lang.RT_Nth_O_I_O__O(vec__1304000263__14, lang.RT_IntCast_J__I(0), nil); var init_QMARK___16 any = lang.RT_Nth_O_I_O__O(vec__1304000263__14, lang.RT_IntCast_J__I(1), nil); var init__17 any = lang.RT_Nth_O_I_O__O(vec__1304000263__14, lang.RT_IntCast_J__I(2), nil); var m__18 any; var G__1304000267__18_ any; var tmp17 *lang.Var;










	A_arbace_classes_lower_A_Init(); tmp17 = A_arbace_classes_lower_A_const_128; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.RT_Meta_O__IPersistentMap(sym__12); var tmp20 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp20 = A_arbace_classes_lower_A_const_99; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp22 = A_arbace_classes_lower_A_const_100; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp24 = A_arbace_classes_lower_A_const_101; G__1304000267__18_ = tmp18.Invoke_O_O_O_O_O_O_O__O(tmp19, tmp21, line__2, tmp23, column__3, tmp24.Ref(), file__1); if jrt.A2g_Truth(doc__15) {
		var tmp25 *lang.Var; A_arbace_classes_lower_A_Init(); tmp25 = A_arbace_classes_lower_A_const_128; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp27 = A_arbace_classes_lower_A_const_270; m__18 = tmp26.Invoke_O_O_O__O(G__1304000267__18_, tmp27.Ref(), doc__15) } else {
//line :373:1
			m__18 = G__1304000267__18_ }; var v__19 any; var tmp28 /*line :362:1*/*lang.Var;












	A_arbace_classes_lower_A_Init(); tmp28 = A_arbace_classes_lower_A_const_67; v__19 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(Lit_195); var tmp29 /*line :376:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp29 = A_arbace_classes_lower_A_const_62; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_classes_lower_A_Init(); tmp31 = A_arbace_classes_lower_A_const_271; var tmp32 any = tmp31; var tmp33 *lang.Var; A_arbace_classes_lower_A_Init(); tmp33 = A_arbace_classes_lower_A_const_62; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_classes_lower_A_Init(); tmp35 = A_arbace_classes_lower_A_const_272; var tmp36 any = lang.Tuple_Create_O_O__IPersistentVector(v__19, tmp34.Invoke_O_O__O(tmp35, sym__12)); var tmp37 any; if
	jrt.A2g_Truth(init_QMARK___16) { var tmp38 *lang.Var; A_arbace_classes_lower_A_Init(); tmp38 = A_arbace_classes_lower_A_const_62; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; A_arbace_classes_lower_A_Init(); tmp40 = A_arbace_classes_lower_A_const_273; var tmp41 any = tmp40; var tmp42 any; A_arbace_classes_lower_A_Init(); tmp42 = A_arbace_classes_lower_A_const_274; tmp37 = tmp39.Invoke_O_O_O_O__O(tmp41, v__19, tmp42, init__17) } else { tmp37 = nil }; var tmp43 any = tmp37; var tmp44 /*line :376:1*/*lang.Var; A_arbace_classes_lower_A_Init(); tmp44 = A_arbace_classes_lower_A_const_62; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 any; A_arbace_classes_lower_A_Init(); tmp46 = A_arbace_classes_lower_A_const_275; var tmp47 any = tmp46; var tmp48 any; A_arbace_classes_lower_A_Init(); tmp48 = A_arbace_classes_lower_A_const_276; var tmp49 any = tmp45.Invoke_O_O_O_O__O(tmp47, v__19, tmp48, m__18); var tmp50 *lang.Var; A_arbace_classes_lower_A_Init(); tmp50 = A_arbace_classes_lower_A_const_62; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any; A_arbace_classes_lower_A_Init(); tmp52 = A_arbace_classes_lower_A_const_277; var tmp53 any = tmp52; var tmp54 any; A_arbace_classes_lower_A_Init(); tmp54 = A_arbace_classes_lower_A_const_278; var tmp55 any = tmp54; var tmp56 *lang.Keyword; A_arbace_classes_lower_A_Init(); tmp56 = A_arbace_classes_lower_A_const_279; var tmp57 *lang.Keyword = tmp56; return tmp30.Invoke_O_O_O_O_O_O__O(tmp32, tmp36, tmp43, tmp49, tmp51.Invoke_O_O_O_O__O(tmp53, v__19, tmp55, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp57).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(sym__12)))).Ref()), v__19) }





























































































type A_arbace_classes_lower_A struct{ jrt.Object }

var A_arbace_classes_lower_A_const_0 *lang.Var

var A_arbace_classes_lower_A_const_1 *lang.Var

var A_arbace_classes_lower_A_const_2 any

var A_arbace_classes_lower_A_const_3 any

var A_arbace_classes_lower_A_const_4 *lang.Var

var A_arbace_classes_lower_A_const_5 *lang.Var

var A_arbace_classes_lower_A_const_6 *lang.Var

var A_arbace_classes_lower_A_const_7 any

var A_arbace_classes_lower_A_const_8 *lang.Var

var A_arbace_classes_lower_A_const_9 *lang.Var

var A_arbace_classes_lower_A_const_10 *lang.Var

var A_arbace_classes_lower_A_const_11 *lang.Var

var A_arbace_classes_lower_A_const_12 *lang.Var

var A_arbace_classes_lower_A_const_13 *lang.Var

var A_arbace_classes_lower_A_const_14 *lang.Var

var A_arbace_classes_lower_A_const_15 *lang.Var

var A_arbace_classes_lower_A_const_16 *lang.Var

var A_arbace_classes_lower_A_const_17 *lang.Var

var A_arbace_classes_lower_A_const_18 *lang.Keyword

var A_arbace_classes_lower_A_const_19 *lang.Keyword

var A_arbace_classes_lower_A_const_20 *lang.Var

var A_arbace_classes_lower_A_const_21 *lang.Var

var A_arbace_classes_lower_A_const_22 *lang.Var

var A_arbace_classes_lower_A_const_23 *lang.Var

var A_arbace_classes_lower_A_const_24 *lang.Var

var A_arbace_classes_lower_A_const_25 *lang.Var

var A_arbace_classes_lower_A_const_26 *lang.Var

var A_arbace_classes_lower_A_const_27 any

var A_arbace_classes_lower_A_const_28 *lang.Var

var A_arbace_classes_lower_A_const_29 any

var A_arbace_classes_lower_A_const_30 *lang.Var

var A_arbace_classes_lower_A_const_31 *lang.Var

var A_arbace_classes_lower_A_const_32 *lang.Var

var A_arbace_classes_lower_A_const_33 any

var A_arbace_classes_lower_A_const_34 any

var A_arbace_classes_lower_A_const_35 any

var A_arbace_classes_lower_A_const_36 *lang.Var

var A_arbace_classes_lower_A_const_37 *lang.Keyword

var A_arbace_classes_lower_A_const_38 any

var A_arbace_classes_lower_A_const_39 *lang.Var

var A_arbace_classes_lower_A_const_40 *lang.Var

var A_arbace_classes_lower_A_const_41 *lang.Var

var A_arbace_classes_lower_A_const_42 *lang.Var

var A_arbace_classes_lower_A_const_43 *lang.Var

var A_arbace_classes_lower_A_const_44 *lang.Var

var A_arbace_classes_lower_A_const_45 *lang.Var

var A_arbace_classes_lower_A_const_46 *lang.Keyword

var A_arbace_classes_lower_A_const_47 any

var A_arbace_classes_lower_A_const_48 any

var A_arbace_classes_lower_A_const_49 *lang.Var

var A_arbace_classes_lower_A_const_50 *lang.Var

var A_arbace_classes_lower_A_const_51 *lang.Var

var A_arbace_classes_lower_A_const_52 *lang.Var

var A_arbace_classes_lower_A_const_53 *lang.Var

var A_arbace_classes_lower_A_const_54 any

var A_arbace_classes_lower_A_const_55 *lang.Var

var A_arbace_classes_lower_A_const_56 *lang.Var

var A_arbace_classes_lower_A_const_57 *lang.Var

var A_arbace_classes_lower_A_const_58 *lang.Var

var A_arbace_classes_lower_A_const_59 any

var A_arbace_classes_lower_A_const_60 *lang.Var

var A_arbace_classes_lower_A_const_61 *lang.Var

var A_arbace_classes_lower_A_const_62 *lang.Var

var A_arbace_classes_lower_A_const_63 *lang.Var

var A_arbace_classes_lower_A_const_64 *lang.Var

var A_arbace_classes_lower_A_const_65 *lang.Var

var A_arbace_classes_lower_A_const_66 any

var A_arbace_classes_lower_A_const_67 *lang.Var

var A_arbace_classes_lower_A_const_68 *lang.Var

var A_arbace_classes_lower_A_const_69 *lang.Var

var A_arbace_classes_lower_A_const_70 any

var A_arbace_classes_lower_A_const_71 *lang.Var

var A_arbace_classes_lower_A_const_72 any

var A_arbace_classes_lower_A_const_73 any

var A_arbace_classes_lower_A_const_74 *lang.Var

var A_arbace_classes_lower_A_const_75 *lang.Var

var A_arbace_classes_lower_A_const_76 *lang.Var

var A_arbace_classes_lower_A_const_77 any

var A_arbace_classes_lower_A_const_78 any

var A_arbace_classes_lower_A_const_79 any

var A_arbace_classes_lower_A_const_80 any

var A_arbace_classes_lower_A_const_81 any

var A_arbace_classes_lower_A_const_82 any

var A_arbace_classes_lower_A_const_83 any

var A_arbace_classes_lower_A_const_84 any

var A_arbace_classes_lower_A_const_85 any

var A_arbace_classes_lower_A_const_86 any

var A_arbace_classes_lower_A_const_87 any

var A_arbace_classes_lower_A_const_88 any

var A_arbace_classes_lower_A_const_89 any

var A_arbace_classes_lower_A_const_90 any

var A_arbace_classes_lower_A_const_91 *lang.Keyword

var A_arbace_classes_lower_A_const_92 *lang.Keyword

var A_arbace_classes_lower_A_const_93 any

var A_arbace_classes_lower_A_const_94 *lang.Var

var A_arbace_classes_lower_A_const_95 any

var A_arbace_classes_lower_A_const_96 any

var A_arbace_classes_lower_A_const_97 any

var A_arbace_classes_lower_A_const_98 any

var A_arbace_classes_lower_A_const_99 *lang.Keyword

var A_arbace_classes_lower_A_const_100 *lang.Keyword

var A_arbace_classes_lower_A_const_101 *lang.Keyword

var A_arbace_classes_lower_A_const_102 *lang.Keyword

var A_arbace_classes_lower_A_const_103 *lang.Keyword

var A_arbace_classes_lower_A_const_104 *lang.Keyword

var A_arbace_classes_lower_A_const_105 *lang.Var

var A_arbace_classes_lower_A_const_106 *lang.Var

var A_arbace_classes_lower_A_const_107 any

var A_arbace_classes_lower_A_const_108 any

var A_arbace_classes_lower_A_const_109 *lang.Var

var A_arbace_classes_lower_A_const_110 *lang.Var

var A_arbace_classes_lower_A_const_111 any

var A_arbace_classes_lower_A_const_112 *lang.Keyword

var A_arbace_classes_lower_A_const_113 *lang.Keyword

var A_arbace_classes_lower_A_const_114 *lang.Keyword

var A_arbace_classes_lower_A_const_115 *lang.Var

var A_arbace_classes_lower_A_const_116 any

var A_arbace_classes_lower_A_const_117 any

var A_arbace_classes_lower_A_const_118 any

var A_arbace_classes_lower_A_const_119 *lang.Keyword

var A_arbace_classes_lower_A_const_120 any

var A_arbace_classes_lower_A_const_121 any

var A_arbace_classes_lower_A_const_122 any

var A_arbace_classes_lower_A_const_123 any

var A_arbace_classes_lower_A_const_124 any

var A_arbace_classes_lower_A_const_125 *lang.Var

var A_arbace_classes_lower_A_const_126 any

var A_arbace_classes_lower_A_const_127 *lang.Var

var A_arbace_classes_lower_A_const_128 *lang.Var

var A_arbace_classes_lower_A_const_129 *lang.Var

var A_arbace_classes_lower_A_const_130 *lang.Keyword

var A_arbace_classes_lower_A_const_131 *lang.Var

var A_arbace_classes_lower_A_const_132 any

var A_arbace_classes_lower_A_const_133 any

var A_arbace_classes_lower_A_const_134 any

var A_arbace_classes_lower_A_const_135 any

var A_arbace_classes_lower_A_const_136 any

var A_arbace_classes_lower_A_const_137 any

var A_arbace_classes_lower_A_const_138 any

var A_arbace_classes_lower_A_const_139 any

var A_arbace_classes_lower_A_const_140 any

var A_arbace_classes_lower_A_const_141 any

var A_arbace_classes_lower_A_const_142 *lang.Keyword

var A_arbace_classes_lower_A_const_143 *lang.Keyword

var A_arbace_classes_lower_A_const_144 any

var A_arbace_classes_lower_A_const_145 any

var A_arbace_classes_lower_A_const_146 any

var A_arbace_classes_lower_A_const_147 any

var A_arbace_classes_lower_A_const_148 any

var A_arbace_classes_lower_A_const_149 any

var A_arbace_classes_lower_A_const_150 any

var A_arbace_classes_lower_A_const_151 any

var A_arbace_classes_lower_A_const_152 any

var A_arbace_classes_lower_A_const_153 any

var A_arbace_classes_lower_A_const_154 any

var A_arbace_classes_lower_A_const_155 any

var A_arbace_classes_lower_A_const_156 any

var A_arbace_classes_lower_A_const_157 *lang.Var

var A_arbace_classes_lower_A_const_158 any

var A_arbace_classes_lower_A_const_159 *lang.Var

var A_arbace_classes_lower_A_const_160 *lang.Var

var A_arbace_classes_lower_A_const_161 *lang.Var

var A_arbace_classes_lower_A_const_162 *lang.Var

var A_arbace_classes_lower_A_const_163 *lang.Var

var A_arbace_classes_lower_A_const_164 *lang.Var

var A_arbace_classes_lower_A_const_165 *lang.Var

var A_arbace_classes_lower_A_const_166 any

var A_arbace_classes_lower_A_const_167 any

var A_arbace_classes_lower_A_const_168 *lang.Var

var A_arbace_classes_lower_A_const_169 any

var A_arbace_classes_lower_A_const_170 any

var A_arbace_classes_lower_A_const_171 *lang.Var

var A_arbace_classes_lower_A_const_172 *lang.Var

var A_arbace_classes_lower_A_const_173 any

var A_arbace_classes_lower_A_const_174 any

var A_arbace_classes_lower_A_const_175 any

var A_arbace_classes_lower_A_const_176 any

var A_arbace_classes_lower_A_const_177 any

var A_arbace_classes_lower_A_const_178 *lang.Var

var A_arbace_classes_lower_A_const_179 *lang.Var

var A_arbace_classes_lower_A_const_180 *lang.Keyword

var A_arbace_classes_lower_A_const_181 any

var A_arbace_classes_lower_A_const_182 *lang.Keyword

var A_arbace_classes_lower_A_const_183 any

var A_arbace_classes_lower_A_const_184 *lang.Var

var A_arbace_classes_lower_A_const_185 *lang.Keyword

var A_arbace_classes_lower_A_const_186 any

var A_arbace_classes_lower_A_const_187 any

var A_arbace_classes_lower_A_const_188 *lang.Keyword

var A_arbace_classes_lower_A_const_189 any

var A_arbace_classes_lower_A_const_190 any

var A_arbace_classes_lower_A_const_191 any

var A_arbace_classes_lower_A_const_192 any

var A_arbace_classes_lower_A_const_193 any

var A_arbace_classes_lower_A_const_194 any

var A_arbace_classes_lower_A_const_195 any

var A_arbace_classes_lower_A_const_196 any

var A_arbace_classes_lower_A_const_197 any

var A_arbace_classes_lower_A_const_198 any

var A_arbace_classes_lower_A_const_199 any

var A_arbace_classes_lower_A_const_200 *lang.Var

var A_arbace_classes_lower_A_const_201 any

var A_arbace_classes_lower_A_const_202 any

var A_arbace_classes_lower_A_const_203 any

var A_arbace_classes_lower_A_const_204 any

var A_arbace_classes_lower_A_const_205 any

var A_arbace_classes_lower_A_const_206 any

var A_arbace_classes_lower_A_const_207 any

var A_arbace_classes_lower_A_const_208 any

var A_arbace_classes_lower_A_const_209 any

var A_arbace_classes_lower_A_const_210 any

var A_arbace_classes_lower_A_const_211 any

var A_arbace_classes_lower_A_const_212 any

var A_arbace_classes_lower_A_const_213 any

var A_arbace_classes_lower_A_const_214 *lang.Var

var A_arbace_classes_lower_A_const_215 any

var A_arbace_classes_lower_A_const_216 any

var A_arbace_classes_lower_A_const_217 any

var A_arbace_classes_lower_A_const_218 *lang.Var

var A_arbace_classes_lower_A_const_219 *lang.Var

var A_arbace_classes_lower_A_const_220 *lang.Var

var A_arbace_classes_lower_A_const_221 *lang.Var

var A_arbace_classes_lower_A_const_222 *lang.Var

var A_arbace_classes_lower_A_const_223 *lang.Var

var A_arbace_classes_lower_A_const_224 *lang.Var

var A_arbace_classes_lower_A_const_225 any

var A_arbace_classes_lower_A_const_226 *lang.Var

var A_arbace_classes_lower_A_const_227 any

var A_arbace_classes_lower_A_const_228 *lang.Var

var A_arbace_classes_lower_A_const_229 any

var A_arbace_classes_lower_A_const_230 any

var A_arbace_classes_lower_A_const_231 any

var A_arbace_classes_lower_A_const_232 any

var A_arbace_classes_lower_A_const_233 any

var A_arbace_classes_lower_A_const_234 any

var A_arbace_classes_lower_A_const_235 any

var A_arbace_classes_lower_A_const_236 any

var A_arbace_classes_lower_A_const_237 any

var A_arbace_classes_lower_A_const_238 *lang.Var

var A_arbace_classes_lower_A_const_239 any

var A_arbace_classes_lower_A_const_240 any

var A_arbace_classes_lower_A_const_241 any

var A_arbace_classes_lower_A_const_242 *lang.Keyword

var A_arbace_classes_lower_A_const_243 *lang.Keyword

var A_arbace_classes_lower_A_const_244 any

var A_arbace_classes_lower_A_const_245 any

var A_arbace_classes_lower_A_const_246 any

var A_arbace_classes_lower_A_const_247 any

var A_arbace_classes_lower_A_const_248 any

var A_arbace_classes_lower_A_const_249 any

var A_arbace_classes_lower_A_const_250 any

var A_arbace_classes_lower_A_const_251 any

var A_arbace_classes_lower_A_const_252 any

var A_arbace_classes_lower_A_const_253 any

var A_arbace_classes_lower_A_const_254 any

var A_arbace_classes_lower_A_const_255 any

var A_arbace_classes_lower_A_const_256 any

var A_arbace_classes_lower_A_const_257 any

var A_arbace_classes_lower_A_const_258 *lang.Var

var A_arbace_classes_lower_A_const_259 any

var A_arbace_classes_lower_A_const_260 any

var A_arbace_classes_lower_A_const_261 any

var A_arbace_classes_lower_A_const_262 any

var A_arbace_classes_lower_A_const_263 any

var A_arbace_classes_lower_A_const_264 any

var A_arbace_classes_lower_A_const_265 any

var A_arbace_classes_lower_A_const_266 any

var A_arbace_classes_lower_A_const_267 any

var A_arbace_classes_lower_A_const_268 any

var A_arbace_classes_lower_A_const_269 any

var A_arbace_classes_lower_A_const_270 *lang.Keyword

var A_arbace_classes_lower_A_const_271 any

var A_arbace_classes_lower_A_const_272 any

var A_arbace_classes_lower_A_const_273 any

var A_arbace_classes_lower_A_const_274 any

var A_arbace_classes_lower_A_const_275 any

var A_arbace_classes_lower_A_const_276 any

var A_arbace_classes_lower_A_const_277 any

var A_arbace_classes_lower_A_const_278 any

var A_arbace_classes_lower_A_const_279 *lang.Keyword

var A_arbace_classes_lower_A_init jrt.ClassInit

func A_arbace_classes_lower_A_Init() { if !A_arbace_classes_lower_A_init.Done() { A_arbace_classes_lower_A_init.Run(A_arbace_classes_lower_A_clinit) } }

func A_arbace_classes_lower_A_clinit() { A_arbace_classes_lower_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_classes_lower_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_classes_lower_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_lower_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_classes_lower_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_classes_lower_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_classes_lower_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_classes_lower_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_classes_lower_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_classes_lower_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_classes_lower_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_classes_lower_A_const_11 = lang.RT_Var_String_String__Var(Lit_9, Lit_15); A_arbace_classes_lower_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_classes_lower_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_classes_lower_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_classes_lower_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_classes_lower_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_classes_lower_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_classes_lower_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_22); A_arbace_classes_lower_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_23); A_arbace_classes_lower_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_classes_lower_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_classes_lower_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_classes_lower_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_classes_lower_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_classes_lower_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_classes_lower_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); var tmp1 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2.Ref())); A_arbace_classes_lower_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); var tmp3 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())); A_arbace_classes_lower_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_classes_lower_A_const_31 = lang.RT_Var_String_String__Var(Lit_9, Lit_35); A_arbace_classes_lower_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_classes_lower_A_const_33 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())).Ref(); A_arbace_classes_lower_A_const_34 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(); A_arbace_classes_lower_A_const_35 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(); A_arbace_classes_lower_A_const_36 = lang.RT_Var_String_String__Var(Lit_9, Lit_40); A_arbace_classes_lower_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); var tmp5 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref())); A_arbace_classes_lower_A_const_39 = lang.RT_Var_String_String__Var(Lit_9, Lit_42); A_arbace_classes_lower_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_classes_lower_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_classes_lower_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_classes_lower_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_classes_lower_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_classes_lower_A_const_45 = lang.RT_Var_String_String__Var(Lit_9, Lit_47); A_arbace_classes_lower_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_classes_lower_A_const_47 = jrt.Pattern_Compile_String__Pattern(Lit_49).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8.Ref())); A_arbace_classes_lower_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_classes_lower_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_classes_lower_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_classes_lower_A_const_52 = lang.RT_Var_String_String__Var(Lit_9, Lit_53); A_arbace_classes_lower_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_classes_lower_A_const_54 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(); A_arbace_classes_lower_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_classes_lower_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_classes_lower_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_classes_lower_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); var tmp9 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10.Ref())); A_arbace_classes_lower_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_classes_lower_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_classes_lower_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_classes_lower_A_const_63 = lang.RT_Var_String_String__Var(Lit_9, Lit_63); A_arbace_classes_lower_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_classes_lower_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_classes_lower_A_const_66 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(); A_arbace_classes_lower_A_const_67 = lang.RT_Var_String_String__Var(Lit_9, Lit_66); A_arbace_classes_lower_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_classes_lower_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_classes_lower_A_const_70 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_classes_lower_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_classes_lower_A_const_72 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(); var tmp11 any = lang.RT_Keyword_String_String__Keyword(Lit_72, Lit_73).Ref(); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12.Ref())); A_arbace_classes_lower_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_classes_lower_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_classes_lower_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_classes_lower_A_const_77 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_78 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref(); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14.Ref())); A_arbace_classes_lower_A_const_80 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_81 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); var tmp15 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_82 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16.Ref())); A_arbace_classes_lower_A_const_83 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_81).Ref(); A_arbace_classes_lower_A_const_84 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(); A_arbace_classes_lower_A_const_85 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(); A_arbace_classes_lower_A_const_86 = lang.Symbol_Intern_String_String__Symbol(Lit_82, Lit_83).Ref(); A_arbace_classes_lower_A_const_87 = lang.Symbol_Intern_String_String__Symbol(Lit_82, Lit_84).Ref(); A_arbace_classes_lower_A_const_88 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_89 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(); A_arbace_classes_lower_A_const_90 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); A_arbace_classes_lower_A_const_91 = lang.RT_Keyword_String_String__Keyword(nil, Lit_86); A_arbace_classes_lower_A_const_92 = lang.RT_Keyword_String_String__Keyword(nil, Lit_79); A_arbace_classes_lower_A_const_93 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_classes_lower_A_const_95 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(); var tmp17 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_96 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18.Ref())); A_arbace_classes_lower_A_const_97 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())); A_arbace_classes_lower_A_const_98 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(); A_arbace_classes_lower_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_90); A_arbace_classes_lower_A_const_100 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_classes_lower_A_const_101 = lang.RT_Keyword_String_String__Keyword(nil, Lit_92); A_arbace_classes_lower_A_const_102 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_classes_lower_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_classes_lower_A_const_104 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_classes_lower_A_const_105 = lang.RT_Var_String_String__Var(Lit_9, Lit_96); A_arbace_classes_lower_A_const_106 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_classes_lower_A_const_107 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_98).Ref(); A_arbace_classes_lower_A_const_108 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(); A_arbace_classes_lower_A_const_109 = lang.RT_Var_String_String__Var(Lit_9, Lit_100); A_arbace_classes_lower_A_const_110 = lang.RT_Var_String_String__Var(Lit_9, Lit_101); A_arbace_classes_lower_A_const_111 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(); A_arbace_classes_lower_A_const_112 = lang.RT_Keyword_String_String__Keyword(nil, Lit_103); A_arbace_classes_lower_A_const_113 = lang.RT_Keyword_String_String__Keyword(nil, Lit_104); A_arbace_classes_lower_A_const_114 = lang.RT_Keyword_String_String__Keyword(nil, Lit_105); A_arbace_classes_lower_A_const_115 = lang.RT_Var_String_String__Var(Lit_9, Lit_106); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_116 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, tmp22, tmp23.Ref())); A_arbace_classes_lower_A_const_117 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(); A_arbace_classes_lower_A_const_118 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(); A_arbace_classes_lower_A_const_119 = lang.RT_Keyword_String_String__Keyword(nil, Lit_110); var tmp24 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(); var tmp25 *jrt.Boolean; jrt.Boolean_Init(); tmp25 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_120 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp25.Ref())); A_arbace_classes_lower_A_const_121 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_64).Ref(); var tmp26 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp27 *jrt.Boolean; jrt.Boolean_Init(); tmp27 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_122 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp27.Ref())); var tmp28 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_123 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp29.Ref())); var tmp30 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp31 *jrt.Boolean; jrt.Boolean_Init(); tmp31 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_124 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp31.Ref())); A_arbace_classes_lower_A_const_125 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_classes_lower_A_const_126 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_127 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_classes_lower_A_const_128 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_classes_lower_A_const_129 = lang.RT_Var_String_String__Var(Lit_0, Lit_113); A_arbace_classes_lower_A_const_130 = lang.RT_Keyword_String_String__Keyword(nil, Lit_114); A_arbace_classes_lower_A_const_131 = lang.RT_Var_String_String__Var(Lit_9, Lit_115); A_arbace_classes_lower_A_const_132 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_116).Ref(); A_arbace_classes_lower_A_const_133 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(); var tmp32 any = lang.RT_Keyword_String_String__Keyword(Lit_72, Lit_73).Ref(); var tmp33 *jrt.Boolean; jrt.Boolean_Init(); tmp33 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_134 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp32, tmp33.Ref())); A_arbace_classes_lower_A_const_135 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_117).Ref(); A_arbace_classes_lower_A_const_136 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_118).Ref(); A_arbace_classes_lower_A_const_137 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_138 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, tmp37, tmp39, tmp40, tmp41.Ref())); A_arbace_classes_lower_A_const_139 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref(); A_arbace_classes_lower_A_const_140 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref(); A_arbace_classes_lower_A_const_141 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_122).Ref(); A_arbace_classes_lower_A_const_142 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_classes_lower_A_const_143 = lang.RT_Keyword_String_String__Keyword(nil, Lit_123); A_arbace_classes_lower_A_const_144 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref(); var tmp42 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp43 *jrt.Boolean; jrt.Boolean_Init(); tmp43 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_145 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp42, tmp43.Ref())); A_arbace_classes_lower_A_const_146 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(); A_arbace_classes_lower_A_const_147 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(); A_arbace_classes_lower_A_const_148 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_149 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_127).Ref(); var tmp44 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp45 *jrt.Boolean; jrt.Boolean_Init(); tmp45 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_150 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp44, tmp45.Ref())); A_arbace_classes_lower_A_const_151 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(); A_arbace_classes_lower_A_const_152 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_153 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_128).Ref(); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_154 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp47.Ref())); A_arbace_classes_lower_A_const_155 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref())); A_arbace_classes_lower_A_const_156 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(); A_arbace_classes_lower_A_const_157 = lang.RT_Var_String_String__Var(Lit_9, Lit_114); A_arbace_classes_lower_A_const_158 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(); A_arbace_classes_lower_A_const_159 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_classes_lower_A_const_160 = lang.RT_Var_String_String__Var(Lit_0, Lit_130); A_arbace_classes_lower_A_const_161 = lang.RT_Var_String_String__Var(Lit_0, Lit_131); A_arbace_classes_lower_A_const_162 = lang.RT_Var_String_String__Var(Lit_0, Lit_132); A_arbace_classes_lower_A_const_163 = lang.RT_Var_String_String__Var(Lit_0, Lit_133); A_arbace_classes_lower_A_const_164 = lang.RT_Var_String_String__Var(Lit_0, Lit_134); A_arbace_classes_lower_A_const_165 = lang.RT_Var_String_String__Var(Lit_0, Lit_135); A_arbace_classes_lower_A_const_166 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref(); var tmp48 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp49 *jrt.Boolean; jrt.Boolean_Init(); tmp49 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_167 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49.Ref())); A_arbace_classes_lower_A_const_168 = lang.RT_Var_String_String__Var(Lit_0, Lit_136); A_arbace_classes_lower_A_const_169 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(); A_arbace_classes_lower_A_const_170 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_lower_A_const_171 = lang.RT_Var_String_String__Var(Lit_9, Lit_138); A_arbace_classes_lower_A_const_172 = lang.RT_Var_String_String__Var(Lit_0, Lit_139); A_arbace_classes_lower_A_const_173 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_64).Ref(); A_arbace_classes_lower_A_const_174 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(); A_arbace_classes_lower_A_const_175 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(); A_arbace_classes_lower_A_const_176 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(); A_arbace_classes_lower_A_const_177 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref(); A_arbace_classes_lower_A_const_178 = lang.RT_Var_String_String__Var(Lit_0, Lit_141); A_arbace_classes_lower_A_const_179 = lang.RT_Var_String_String__Var(Lit_9, Lit_142); A_arbace_classes_lower_A_const_180 = lang.RT_Keyword_String_String__Keyword(nil, Lit_143); var tmp50 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_144).Ref(); var tmp51 *jrt.Boolean; jrt.Boolean_Init(); tmp51 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_181 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp51.Ref())); A_arbace_classes_lower_A_const_182 = lang.RT_Keyword_String_String__Keyword(nil, Lit_145); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_183 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, tmp55, tmp56.Ref())); A_arbace_classes_lower_A_const_184 = lang.RT_Var_String_String__Var(Lit_0, Lit_146); A_arbace_classes_lower_A_const_185 = lang.RT_Keyword_String_String__Keyword(nil, Lit_147); var tmp57 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_144).Ref(); var tmp58 *jrt.Boolean; jrt.Boolean_Init(); tmp58 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_186 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp57, tmp58.Ref())); var tmp59 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp60 *jrt.Boolean; jrt.Boolean_Init(); tmp60 = jrt.Boolean_TRUE; var tmp61 any = tmp60.Ref(); var tmp62 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(); var tmp63 *jrt.Boolean; jrt.Boolean_Init(); tmp63 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_187 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp59, tmp61, tmp62, tmp63.Ref())); A_arbace_classes_lower_A_const_188 = lang.RT_Keyword_String_String__Keyword(nil, Lit_148); var tmp64 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp65 *jrt.Boolean; jrt.Boolean_Init(); tmp65 = jrt.Boolean_TRUE; var tmp66 any = tmp65.Ref(); var tmp67 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; var tmp69 any = tmp68.Ref(); var tmp70 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(); var tmp71 *jrt.Boolean; jrt.Boolean_Init(); tmp71 = jrt.Boolean_TRUE; var tmp72 any = tmp71.Ref(); var tmp73 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(); var tmp74 *jrt.Boolean; jrt.Boolean_Init(); tmp74 = jrt.Boolean_TRUE; var tmp75 any = tmp74.Ref(); A_arbace_classes_lower_A_const_189 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, tmp67, tmp69, tmp70, tmp72, tmp73, tmp75, lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref())); A_arbace_classes_lower_A_const_190 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref(); A_arbace_classes_lower_A_const_191 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(); var tmp76 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp77 *jrt.Boolean; jrt.Boolean_Init(); tmp77 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_192 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp76, tmp77.Ref())); A_arbace_classes_lower_A_const_193 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(); A_arbace_classes_lower_A_const_194 = lang.Tuple_Create_O_O_O_O__IPersistentVector(nil, nil, lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_89).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(254).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_89).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(254).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(55).Ref())))); A_arbace_classes_lower_A_const_195 = lang.Tuple_Create_O_O__IPersistentVector(lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_89).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(255).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_89).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(255).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref())))); A_arbace_classes_lower_A_const_196 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_197 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref(); var tmp78 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp79 *jrt.Boolean; jrt.Boolean_Init(); tmp79 = jrt.Boolean_TRUE; var tmp80 any = tmp79.Ref(); var tmp81 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(); var tmp82 *jrt.Boolean; jrt.Boolean_Init(); tmp82 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_198 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp78, tmp80, tmp81, tmp82.Ref())); A_arbace_classes_lower_A_const_199 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_154).Ref())); A_arbace_classes_lower_A_const_200 = lang.RT_Var_String_String__Var(Lit_0, Lit_155); A_arbace_classes_lower_A_const_201 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(); A_arbace_classes_lower_A_const_202 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_156).Ref(); var tmp83 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(); var tmp84 *jrt.Boolean; jrt.Boolean_Init(); tmp84 = jrt.Boolean_TRUE; var tmp85 any = tmp84.Ref(); var tmp86 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(); var tmp87 *jrt.Boolean; jrt.Boolean_Init(); tmp87 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_203 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp83, tmp85, tmp86, tmp87.Ref())); A_arbace_classes_lower_A_const_204 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_118).Ref())); A_arbace_classes_lower_A_const_205 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_classes_lower_A_const_206 = lang.Symbol_Intern_String_String__Symbol(Lit_157, Lit_158).Ref(); A_arbace_classes_lower_A_const_207 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(); A_arbace_classes_lower_A_const_208 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref(); A_arbace_classes_lower_A_const_209 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(); A_arbace_classes_lower_A_const_210 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref(); A_arbace_classes_lower_A_const_211 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(); A_arbace_classes_lower_A_const_212 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(); A_arbace_classes_lower_A_const_213 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_162).Ref(); A_arbace_classes_lower_A_const_214 = lang.RT_Var_String_String__Var(Lit_9, Lit_163); A_arbace_classes_lower_A_const_215 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_89).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(277).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref()))); A_arbace_classes_lower_A_const_216 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_89).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), jrt.Integer_ValueOf_I__Integer(277).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref()))); A_arbace_classes_lower_A_const_217 = lang.Symbol_Intern_String_String__Symbol(Lit_82, Lit_164).Ref(); A_arbace_classes_lower_A_const_218 = lang.RT_Var_String_String__Var(Lit_0, Lit_165); A_arbace_classes_lower_A_const_219 = lang.RT_Var_String_String__Var(Lit_0, Lit_166); A_arbace_classes_lower_A_const_220 = lang.RT_Var_String_String__Var(Lit_0, Lit_167); A_arbace_classes_lower_A_const_221 = lang.RT_Var_String_String__Var(Lit_0, Lit_168); A_arbace_classes_lower_A_const_222 = lang.RT_Var_String_String__Var(Lit_0, Lit_169); A_arbace_classes_lower_A_const_223 = lang.RT_Var_String_String__Var(Lit_0, Lit_170); A_arbace_classes_lower_A_const_224 = lang.RT_Var_String_String__Var(Lit_0, Lit_171); A_arbace_classes_lower_A_const_225 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref(); A_arbace_classes_lower_A_const_226 = lang.RT_Var_String_String__Var(Lit_0, Lit_173); var tmp88 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp89 *jrt.Boolean; jrt.Boolean_Init(); tmp89 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_227 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp88, tmp89.Ref())); A_arbace_classes_lower_A_const_228 = lang.RT_Var_String_String__Var(Lit_0, Lit_174); A_arbace_classes_lower_A_const_229 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref(); A_arbace_classes_lower_A_const_230 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_175).Ref(); A_arbace_classes_lower_A_const_231 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_classes_lower_A_const_232 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_classes_lower_A_const_233 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_classes_lower_A_const_234 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(); A_arbace_classes_lower_A_const_235 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_176).Ref(); A_arbace_classes_lower_A_const_236 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(); A_arbace_classes_lower_A_const_237 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_175).Ref(); A_arbace_classes_lower_A_const_238 = lang.RT_Var_String_String__Var(Lit_0, Lit_177); A_arbace_classes_lower_A_const_239 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_178).Ref(); A_arbace_classes_lower_A_const_240 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_179).Ref(); A_arbace_classes_lower_A_const_241 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_180).Ref(); A_arbace_classes_lower_A_const_242 = lang.RT_Keyword_String_String__Keyword(nil, Lit_89); A_arbace_classes_lower_A_const_243 = lang.RT_Keyword_String_String__Keyword(nil, Lit_181); A_arbace_classes_lower_A_const_244 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(); A_arbace_classes_lower_A_const_245 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref(); A_arbace_classes_lower_A_const_246 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_184).Ref(); A_arbace_classes_lower_A_const_247 = lang.Symbol_Intern_String_String__Symbol(Lit_185, Lit_186).Ref(); A_arbace_classes_lower_A_const_248 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(); A_arbace_classes_lower_A_const_249 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(); A_arbace_classes_lower_A_const_250 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref(); A_arbace_classes_lower_A_const_251 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_187).Ref(); A_arbace_classes_lower_A_const_252 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(); A_arbace_classes_lower_A_const_253 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(); A_arbace_classes_lower_A_const_254 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref(); A_arbace_classes_lower_A_const_255 = lang.Symbol_Intern_String_String__Symbol(Lit_185, Lit_186).Ref(); A_arbace_classes_lower_A_const_256 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(); A_arbace_classes_lower_A_const_257 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(); A_arbace_classes_lower_A_const_258 = lang.RT_Var_String_String__Var(Lit_0, Lit_188); A_arbace_classes_lower_A_const_259 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref(); A_arbace_classes_lower_A_const_260 = lang.Symbol_Intern_String_String__Symbol(Lit_185, Lit_190).Ref(); A_arbace_classes_lower_A_const_261 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_191).Ref(); A_arbace_classes_lower_A_const_262 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref(); A_arbace_classes_lower_A_const_263 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_192).Ref(); A_arbace_classes_lower_A_const_264 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_193).Ref(); A_arbace_classes_lower_A_const_265 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(); A_arbace_classes_lower_A_const_266 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_162).Ref(); A_arbace_classes_lower_A_const_267 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_193).Ref(); var tmp90 *jrt.Boolean; jrt.Boolean_Init(); tmp90 = jrt.Boolean_FALSE; A_arbace_classes_lower_A_const_268 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, tmp90.Ref(), nil); var tmp91 any = lang.RT_Keyword_String_String__Keyword(Lit_31, Lit_32).Ref(); var tmp92 *jrt.Boolean; jrt.Boolean_Init(); tmp92 = jrt.Boolean_TRUE; A_arbace_classes_lower_A_const_269 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp91, tmp92.Ref())); A_arbace_classes_lower_A_const_270 = lang.RT_Keyword_String_String__Keyword(nil, Lit_10); A_arbace_classes_lower_A_const_271 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_classes_lower_A_const_272 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_195).Ref(); A_arbace_classes_lower_A_const_273 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(); A_arbace_classes_lower_A_const_274 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_196).Ref(); A_arbace_classes_lower_A_const_275 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(); A_arbace_classes_lower_A_const_276 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_197).Ref(); A_arbace_classes_lower_A_const_277 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(); A_arbace_classes_lower_A_const_278 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_198).Ref(); A_arbace_classes_lower_A_const_279 = lang.RT_Keyword_String_String__Keyword(nil, Lit_199) }

func A_arbace_classes_lower_A_New() *A_arbace_classes_lower_A { A_arbace_classes_lower_A_Init(); t := &A_arbace_classes_lower_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_lower_A) Ctor() {}

func (t *A_arbace_classes_lower_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_A_class }

func (t *A_arbace_classes_lower_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_A); return ok }

func A_arbace_classes_lower_A_Cast(x any) *A_arbace_classes_lower_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_A_class)) }; return v }



type A_arbace_classes_lower_annotation_meta_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_annotation_meta_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_annotation_meta_A_fn_class *jrt.Class

var A_arbace_classes_lower_annotation_meta_A_init jrt.ClassInit

func A_arbace_classes_lower_annotation_meta_A_Init() { if !A_arbace_classes_lower_annotation_meta_A_init.Done() { A_arbace_classes_lower_annotation_meta_A_init.Run(A_arbace_classes_lower_annotation_meta_A_clinit) } }

func A_arbace_classes_lower_annotation_meta_A_clinit() { A_arbace_classes_lower_annotation_meta_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_annotation_meta_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_annotation_meta_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_annotation_meta_A_class }

func (t *A_arbace_classes_lower_annotation_meta_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_annotation_meta_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_annotation_meta_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_annotation_meta_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_annotation_meta_A); return ok }

func A_arbace_classes_lower_annotation_meta_A_Cast(x any) *A_arbace_classes_lower_annotation_meta_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_annotation_meta_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_annotation_meta_A_class)) }; return v }



type A_arbace_classes_lower_class_char_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_class_char_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_class_char_A_fn_class *jrt.Class

var A_arbace_classes_lower_class_char_A_init jrt.ClassInit

func A_arbace_classes_lower_class_char_A_Init() { if !A_arbace_classes_lower_class_char_A_init.Done() { A_arbace_classes_lower_class_char_A_init.Run(A_arbace_classes_lower_class_char_A_clinit) } }

func A_arbace_classes_lower_class_char_A_clinit() { A_arbace_classes_lower_class_char_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_class_char_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_class_char_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_class_char_A_class }

func (t *A_arbace_classes_lower_class_char_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_class_char_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_class_char_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_class_char_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_class_char_A); return ok }

func A_arbace_classes_lower_class_char_A_Cast(x any) *A_arbace_classes_lower_class_char_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_class_char_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_class_char_A_class)) }; return v }



type A_arbace_classes_lower_clojure_method_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_clojure_method_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_clojure_method_A_fn_class *jrt.Class

var A_arbace_classes_lower_clojure_method_A_init jrt.ClassInit

func A_arbace_classes_lower_clojure_method_A_Init() { if !A_arbace_classes_lower_clojure_method_A_init.Done() { A_arbace_classes_lower_clojure_method_A_init.Run(A_arbace_classes_lower_clojure_method_A_clinit) } }

func A_arbace_classes_lower_clojure_method_A_clinit() { A_arbace_classes_lower_clojure_method_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_clojure_method_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_clojure_method_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_clojure_method_A_class }

func (t *A_arbace_classes_lower_clojure_method_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_clojure_method_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_clojure_method_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_clojure_method_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_clojure_method_A); return ok }

func A_arbace_classes_lower_clojure_method_A_Cast(x any) *A_arbace_classes_lower_clojure_method_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_clojure_method_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_clojure_method_A_class)) }; return v }



type A_arbace_classes_lower_clojure_method_fn__1304000104_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_clojure_method_fn__1304000104_A_fn_class *jrt.Class

var A_arbace_classes_lower_clojure_method_fn__1304000104_A_init jrt.ClassInit

func A_arbace_classes_lower_clojure_method_fn__1304000104_A_Init() { if !A_arbace_classes_lower_clojure_method_fn__1304000104_A_init.Done() { A_arbace_classes_lower_clojure_method_fn__1304000104_A_init.Run(A_arbace_classes_lower_clojure_method_fn__1304000104_A_clinit) } }

func A_arbace_classes_lower_clojure_method_fn__1304000104_A_clinit() { A_arbace_classes_lower_clojure_method_fn__1304000104_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_209, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_clojure_method_fn__1304000104_A_class }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000104_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_clojure_method_fn__1304000104_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_clojure_method_fn__1304000104_A); return ok }

func A_arbace_classes_lower_clojure_method_fn__1304000104_A_Cast(x any) *A_arbace_classes_lower_clojure_method_fn__1304000104_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_clojure_method_fn__1304000104_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_clojure_method_fn__1304000104_A_class)) }; return v }



type A_arbace_classes_lower_clojure_method_fn__1304000106_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_clojure_method_fn__1304000106_A_fn_class *jrt.Class

var A_arbace_classes_lower_clojure_method_fn__1304000106_A_init jrt.ClassInit

func A_arbace_classes_lower_clojure_method_fn__1304000106_A_Init() { if !A_arbace_classes_lower_clojure_method_fn__1304000106_A_init.Done() { A_arbace_classes_lower_clojure_method_fn__1304000106_A_init.Run(A_arbace_classes_lower_clojure_method_fn__1304000106_A_clinit) } }

func A_arbace_classes_lower_clojure_method_fn__1304000106_A_clinit() { A_arbace_classes_lower_clojure_method_fn__1304000106_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_clojure_method_fn__1304000106_A_class }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_clojure_method_fn__1304000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_clojure_method_fn__1304000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_clojure_method_fn__1304000106_A); return ok }

func A_arbace_classes_lower_clojure_method_fn__1304000106_A_Cast(x any) *A_arbace_classes_lower_clojure_method_fn__1304000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_clojure_method_fn__1304000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_clojure_method_fn__1304000106_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_deftype_class_form_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_A_Init() { if !A_arbace_classes_lower_deftype_class_form_A_init.Done() { A_arbace_classes_lower_deftype_class_form_A_init.Run(A_arbace_classes_lower_deftype_class_form_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_A_clinit() { A_arbace_classes_lower_deftype_class_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_A); return ok }

func A_arbace_classes_lower_deftype_class_form_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A struct{ jrt.Object; F_fields, F_rcv, F_param, F_fname any }

func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_Init() { if !A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_init.Done() { A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_init.Run(A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_clinit() { A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A); return ok }

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_fn__1304000123_A struct{ jrt.Object; F_more any }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_Init() { if !A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_init.Done() { A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_init.Run(A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_clinit() { A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000123_A); return ok }

func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_fn__1304000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_fn__1304000125_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_Init() { if !A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_init.Done() { A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_init.Run(A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_clinit() { A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000125_A); return ok }

func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_fn__1304000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_fn__1304000185_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) Is_Compiler_AOTF4() {}

var A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_Init() { if !A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_init.Done() { A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_init.Run(A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_clinit() { A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000185_A); return ok }

func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_fn__1304000185_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000185_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_fn__1304000187_A struct{ jrt.Object; F_ptag any }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_Init() { if !A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_init.Done() { A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_init.Run(A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_clinit() { A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000187_A); return ok }

func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_fn__1304000187_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_fn__1304000187_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_fname__1304000127_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_Init() { if !A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_init.Done() { A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_init.Run(A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_clinit() { A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_fname__1304000127_A); return ok }

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_fname__1304000127_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_fname__1304000127_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_221, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A struct{ jrt.Object; F_iter__1304000135, F_s__1304000136 any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A struct{ jrt.Object; F_b__1304000138 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_223, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A struct{ jrt.Object; F_ptag, F_fname any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_224, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A struct{ jrt.Object; F_iter__1304000145, F_ptag, F_fname, F_s__1304000146 any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_225, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A struct{ jrt.Object; F_b__1304000148, F_ptag, F_fname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_226, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A struct{ jrt.Object; F_rcv, F_fname any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_227, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A struct{ jrt.Object; F_rcv, F_fname, F_s__1304000156, F_iter__1304000155 any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_228, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A struct{ jrt.Object; F_b__1304000158, F_rcv, F_fname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_230, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_231, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A struct{ jrt.Object; F_s__1304000166, F_iter__1304000165 any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_232, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A struct{ jrt.Object; F_b__1304000168 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A struct{ jrt.Object; F_fname any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A struct{ jrt.Object; F_fname, F_s__1304000176, F_iter__1304000175 any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A struct{ jrt.Object; F_b__1304000178, F_fname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_Init() { if !A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_init.Done() { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_init.Run(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_clinit() { A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_237, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A); return ok }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_param__1304000131_A struct{ jrt.Object; F_ptag, F_fname any }

func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_param__1304000131_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_param__1304000131_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_Init() { if !A_arbace_classes_lower_deftype_class_form_param__1304000131_A_init.Done() { A_arbace_classes_lower_deftype_class_form_param__1304000131_A_init.Run(A_arbace_classes_lower_deftype_class_form_param__1304000131_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_clinit() { A_arbace_classes_lower_deftype_class_form_param__1304000131_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_238, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_param__1304000131_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_param__1304000131_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_param__1304000131_A); return ok }

func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_param__1304000131_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_param__1304000131_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_param__1304000131_A_class)) }; return v }



type A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_fn_class *jrt.Class

var A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_init jrt.ClassInit

func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_Init() { if !A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_init.Done() { A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_init.Run(A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_clinit) } }

func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_clinit() { A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_class }

func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A); return ok }

func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_Cast(x any) *A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_class)) }; return v }



type A_arbace_classes_lower_eval1304000004_A struct{ jrt.Object }

func A_arbace_classes_lower_eval1304000004_A_New() *A_arbace_classes_lower_eval1304000004_A { t := &A_arbace_classes_lower_eval1304000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_lower_eval1304000004_A) Ctor() {}

func (t *A_arbace_classes_lower_eval1304000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_eval1304000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_eval1304000004_A_class }

func (t *A_arbace_classes_lower_eval1304000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_eval1304000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_eval1304000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_eval1304000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_eval1304000004_A); return ok }

func A_arbace_classes_lower_eval1304000004_A_Cast(x any) *A_arbace_classes_lower_eval1304000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_eval1304000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_eval1304000004_A_class)) }; return v }



type A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_fn_class *jrt.Class

var A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_init jrt.ClassInit

func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_Init() { if !A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_init.Done() { A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_init.Run(A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_clinit) } }

func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_clinit() { A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_class }

func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A); return ok }

func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_Cast(x any) *A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_class)) }; return v }



type A_arbace_classes_lower_eval1304000008_A struct{ jrt.Object }

func A_arbace_classes_lower_eval1304000008_A_New() *A_arbace_classes_lower_eval1304000008_A { t := &A_arbace_classes_lower_eval1304000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_lower_eval1304000008_A) Ctor() {}

func (t *A_arbace_classes_lower_eval1304000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_eval1304000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_eval1304000008_A_class }

func (t *A_arbace_classes_lower_eval1304000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_eval1304000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_eval1304000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_eval1304000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_eval1304000008_A); return ok }

func A_arbace_classes_lower_eval1304000008_A_Cast(x any) *A_arbace_classes_lower_eval1304000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_eval1304000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_eval1304000008_A_class)) }; return v }



type A_arbace_classes_lower_eval1304000008_fn__1304000009_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_eval1304000008_fn__1304000009_A_fn_class *jrt.Class

var A_arbace_classes_lower_eval1304000008_fn__1304000009_A_init jrt.ClassInit

func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_Init() { if !A_arbace_classes_lower_eval1304000008_fn__1304000009_A_init.Done() { A_arbace_classes_lower_eval1304000008_fn__1304000009_A_init.Run(A_arbace_classes_lower_eval1304000008_fn__1304000009_A_clinit) } }

func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_clinit() { A_arbace_classes_lower_eval1304000008_fn__1304000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_eval1304000008_fn__1304000009_A_class }

func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_eval1304000008_fn__1304000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_eval1304000008_fn__1304000009_A); return ok }

func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_Cast(x any) *A_arbace_classes_lower_eval1304000008_fn__1304000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_eval1304000008_fn__1304000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_eval1304000008_fn__1304000009_A_class)) }; return v }



type A_arbace_classes_lower_fn_meta_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_meta_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_fn_meta_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_meta_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_meta_A_Init() { if !A_arbace_classes_lower_fn_meta_A_init.Done() { A_arbace_classes_lower_fn_meta_A_init.Run(A_arbace_classes_lower_fn_meta_A_clinit) } }

func A_arbace_classes_lower_fn_meta_A_clinit() { A_arbace_classes_lower_fn_meta_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_meta_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_meta_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_meta_A_class }

func (t *A_arbace_classes_lower_fn_meta_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_meta_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_meta_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_meta_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_meta_A); return ok }

func A_arbace_classes_lower_fn_meta_A_Cast(x any) *A_arbace_classes_lower_fn_meta_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_meta_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_meta_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_methods_A) Is_Compiler_AOTF4() {}

var A_arbace_classes_lower_fn_methods_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_A_Init() { if !A_arbace_classes_lower_fn_methods_A_init.Done() { A_arbace_classes_lower_fn_methods_A_init.Run(A_arbace_classes_lower_fn_methods_A_clinit) } }

func A_arbace_classes_lower_fn_methods_A_clinit() { A_arbace_classes_lower_fn_methods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_243, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_A_class }

func (t *A_arbace_classes_lower_fn_methods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_A); return ok }

func A_arbace_classes_lower_fn_methods_A_Cast(x any) *A_arbace_classes_lower_fn_methods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_fn__1304000060_A struct{ jrt.Object; F_rcv, F_binds, F_nm any }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_fn_methods_fn__1304000060_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_fn__1304000060_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_Init() { if !A_arbace_classes_lower_fn_methods_fn__1304000060_A_init.Done() { A_arbace_classes_lower_fn_methods_fn__1304000060_A_init.Run(A_arbace_classes_lower_fn_methods_fn__1304000060_A_clinit) } }

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_clinit() { A_arbace_classes_lower_fn_methods_fn__1304000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_fn__1304000060_A_class }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_A); return ok }

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_Cast(x any) *A_arbace_classes_lower_fn_methods_fn__1304000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_fn__1304000060_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_Init() { if !A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_init.Done() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_init.Run(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_clinit) } }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_clinit() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_246, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_class }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A); return ok }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_Cast(x any) *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_Init() { if !A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_init.Done() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_init.Run(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_clinit) } }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_clinit() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_247, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_class }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A); return ok }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_Cast(x any) *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A struct{ jrt.Object; F_rest_p any }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_Init() { if !A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_init.Done() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_init.Run(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_clinit) } }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_clinit() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_249, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_class }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A); return ok }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_Cast(x any) *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_Init() { if !A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_init.Done() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_init.Run(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_clinit) } }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_clinit() { A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_class }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A); return ok }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_Cast(x any) *A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_Init() { if !A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_init.Done() { A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_init.Run(A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_clinit) } }

func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_clinit() { A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_class }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A); return ok }

func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_Cast(x any) *A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_class)) }; return v }



type A_arbace_classes_lower_fn_methods_fn__1304000085_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_fn_methods_fn__1304000085_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_methods_fn__1304000085_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_methods_fn__1304000085_A_Init() { if !A_arbace_classes_lower_fn_methods_fn__1304000085_A_init.Done() { A_arbace_classes_lower_fn_methods_fn__1304000085_A_init.Run(A_arbace_classes_lower_fn_methods_fn__1304000085_A_clinit) } }

func A_arbace_classes_lower_fn_methods_fn__1304000085_A_clinit() { A_arbace_classes_lower_fn_methods_fn__1304000085_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_methods_fn__1304000085_A_class }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_methods_fn__1304000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_methods_fn__1304000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000085_A); return ok }

func A_arbace_classes_lower_fn_methods_fn__1304000085_A_Cast(x any) *A_arbace_classes_lower_fn_methods_fn__1304000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_methods_fn__1304000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_methods_fn__1304000085_A_class)) }; return v }



type A_arbace_classes_lower_fn_parts_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_parts_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_fn_parts_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_parts_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_parts_A_Init() { if !A_arbace_classes_lower_fn_parts_A_init.Done() { A_arbace_classes_lower_fn_parts_A_init.Run(A_arbace_classes_lower_fn_parts_A_clinit) } }

func A_arbace_classes_lower_fn_parts_A_clinit() { A_arbace_classes_lower_fn_parts_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_253, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_parts_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_parts_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_parts_A_class }

func (t *A_arbace_classes_lower_fn_parts_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_parts_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_parts_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_parts_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_parts_A); return ok }

func A_arbace_classes_lower_fn_parts_A_Cast(x any) *A_arbace_classes_lower_fn_parts_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_parts_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_parts_A_class)) }; return v }



type A_arbace_classes_lower_fn_parts_fn__1304000025_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_fn_parts_fn__1304000025_A_fn_class *jrt.Class

var A_arbace_classes_lower_fn_parts_fn__1304000025_A_init jrt.ClassInit

func A_arbace_classes_lower_fn_parts_fn__1304000025_A_Init() { if !A_arbace_classes_lower_fn_parts_fn__1304000025_A_init.Done() { A_arbace_classes_lower_fn_parts_fn__1304000025_A_init.Run(A_arbace_classes_lower_fn_parts_fn__1304000025_A_clinit) } }

func A_arbace_classes_lower_fn_parts_fn__1304000025_A_clinit() { A_arbace_classes_lower_fn_parts_fn__1304000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_fn_parts_fn__1304000025_A_class }

func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_fn_parts_fn__1304000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_fn_parts_fn__1304000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_fn_parts_fn__1304000025_A); return ok }

func A_arbace_classes_lower_fn_parts_fn__1304000025_A_Cast(x any) *A_arbace_classes_lower_fn_parts_fn__1304000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_fn_parts_fn__1304000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_fn_parts_fn__1304000025_A_class)) }; return v }



type A_arbace_classes_lower_gsym_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_gsym_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_gsym_A_fn_class *jrt.Class

var A_arbace_classes_lower_gsym_A_init jrt.ClassInit

func A_arbace_classes_lower_gsym_A_Init() { if !A_arbace_classes_lower_gsym_A_init.Done() { A_arbace_classes_lower_gsym_A_init.Run(A_arbace_classes_lower_gsym_A_clinit) } }

func A_arbace_classes_lower_gsym_A_clinit() { A_arbace_classes_lower_gsym_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_256, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_gsym_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_gsym_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_gsym_A_class }

func (t *A_arbace_classes_lower_gsym_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_gsym_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_gsym_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_gsym_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_gsym_A); return ok }

func A_arbace_classes_lower_gsym_A_Cast(x any) *A_arbace_classes_lower_gsym_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_gsym_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_gsym_A_class)) }; return v }



type A_arbace_classes_lower_lower_case_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_lower_case_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_lower_case_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_case_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_case_A_Init() { if !A_arbace_classes_lower_lower_case_A_init.Done() { A_arbace_classes_lower_lower_case_A_init.Run(A_arbace_classes_lower_lower_case_A_clinit) } }

func A_arbace_classes_lower_lower_case_A_clinit() { A_arbace_classes_lower_lower_case_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_case_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_case_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_case_A_class }

func (t *A_arbace_classes_lower_lower_case_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_case_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_case_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_case_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_case_A); return ok }

func A_arbace_classes_lower_lower_case_A_Cast(x any) *A_arbace_classes_lower_lower_case_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_case_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_case_A_class)) }; return v }



type A_arbace_classes_lower_lower_case_fn__1304000248_A struct{ jrt.Object; F_prim_int_QMARK_, F_skip, F_ge, F_test_type, F_L any }

func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_case_fn__1304000248_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_case_fn__1304000248_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_case_fn__1304000248_A_Init() { if !A_arbace_classes_lower_lower_case_fn__1304000248_A_init.Done() { A_arbace_classes_lower_lower_case_fn__1304000248_A_init.Run(A_arbace_classes_lower_lower_case_fn__1304000248_A_clinit) } }

func A_arbace_classes_lower_lower_case_fn__1304000248_A_clinit() { A_arbace_classes_lower_lower_case_fn__1304000248_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_case_fn__1304000248_A_class }

func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_case_fn__1304000248_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_case_fn__1304000248_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_case_fn__1304000248_A); return ok }

func A_arbace_classes_lower_lower_case_fn__1304000248_A_Cast(x any) *A_arbace_classes_lower_lower_case_fn__1304000248_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_case_fn__1304000248_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_case_fn__1304000248_A_class)) }; return v }



type A_arbace_classes_lower_lower_case_sm__1304000245_A struct{ jrt.Object; F_shift, F_mask int32 }

func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_case_sm__1304000245_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_case_sm__1304000245_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_case_sm__1304000245_A_Init() { if !A_arbace_classes_lower_lower_case_sm__1304000245_A_init.Done() { A_arbace_classes_lower_lower_case_sm__1304000245_A_init.Run(A_arbace_classes_lower_lower_case_sm__1304000245_A_clinit) } }

func A_arbace_classes_lower_lower_case_sm__1304000245_A_clinit() { A_arbace_classes_lower_lower_case_sm__1304000245_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_262, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_case_sm__1304000245_A_class }

func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_case_sm__1304000245_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_case_sm__1304000245_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_case_sm__1304000245_A); return ok }

func A_arbace_classes_lower_lower_case_sm__1304000245_A_Cast(x any) *A_arbace_classes_lower_lower_case_sm__1304000245_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_case_sm__1304000245_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_case_sm__1304000245_A_class)) }; return v }



type A_arbace_classes_lower_lower_case_sw__1304000256_A struct{ jrt.Object; F_arms any }

func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_case_sw__1304000256_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_case_sw__1304000256_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_case_sw__1304000256_A_Init() { if !A_arbace_classes_lower_lower_case_sw__1304000256_A_init.Done() { A_arbace_classes_lower_lower_case_sw__1304000256_A_init.Run(A_arbace_classes_lower_lower_case_sw__1304000256_A_clinit) } }

func A_arbace_classes_lower_lower_case_sw__1304000256_A_clinit() { A_arbace_classes_lower_lower_case_sw__1304000256_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_263, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_case_sw__1304000256_A_class }

func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_case_sw__1304000256_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_case_sw__1304000256_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_case_sw__1304000256_A); return ok }

func A_arbace_classes_lower_lower_case_sw__1304000256_A_Cast(x any) *A_arbace_classes_lower_lower_case_sw__1304000256_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_case_sw__1304000256_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_case_sw__1304000256_A_class)) }; return v }



type A_arbace_classes_lower_lower_def_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_lower_def_A) Is_Compiler_AOTF4() {}

var A_arbace_classes_lower_lower_def_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_def_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_def_A_Init() { if !A_arbace_classes_lower_lower_def_A_init.Done() { A_arbace_classes_lower_lower_def_A_init.Run(A_arbace_classes_lower_lower_def_A_clinit) } }

func A_arbace_classes_lower_lower_def_A_clinit() { A_arbace_classes_lower_lower_def_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_264, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_def_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_def_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_def_A_class }

func (t *A_arbace_classes_lower_lower_def_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_def_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_def_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_def_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_def_A); return ok }

func A_arbace_classes_lower_lower_def_A_Cast(x any) *A_arbace_classes_lower_lower_def_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_def_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_def_A_class)) }; return v }



type A_arbace_classes_lower_lower_fn_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_lower_fn_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_fn_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_fn_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_fn_A_Init() { if !A_arbace_classes_lower_lower_fn_A_init.Done() { A_arbace_classes_lower_lower_fn_A_init.Run(A_arbace_classes_lower_lower_fn_A_clinit) } }

func A_arbace_classes_lower_lower_fn_A_clinit() { A_arbace_classes_lower_lower_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_266, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_fn_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_fn_A_class }

func (t *A_arbace_classes_lower_lower_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_fn_A); return ok }

func A_arbace_classes_lower_lower_fn_A_Cast(x any) *A_arbace_classes_lower_lower_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_fn_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_lower_letfn_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_lower_letfn_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_A_Init() { if !A_arbace_classes_lower_lower_letfn_A_init.Done() { A_arbace_classes_lower_lower_letfn_A_init.Run(A_arbace_classes_lower_lower_letfn_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_A_clinit() { A_arbace_classes_lower_lower_letfn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_269, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_A_class }

func (t *A_arbace_classes_lower_lower_letfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_A); return ok }

func A_arbace_classes_lower_lower_letfn_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_fn__1304000196_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_letfn_fn__1304000196_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_fn__1304000196_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_Init() { if !A_arbace_classes_lower_lower_letfn_fn__1304000196_A_init.Done() { A_arbace_classes_lower_lower_letfn_fn__1304000196_A_init.Run(A_arbace_classes_lower_lower_letfn_fn__1304000196_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_clinit() { A_arbace_classes_lower_lower_letfn_fn__1304000196_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_270, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_fn__1304000196_A_class }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000196_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_fn__1304000196_A); return ok }

func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_fn__1304000196_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_fn__1304000196_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_fn__1304000196_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_fn__1304000222_A struct{ jrt.Object; F_boxes any }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_letfn_fn__1304000222_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_fn__1304000222_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_Init() { if !A_arbace_classes_lower_lower_letfn_fn__1304000222_A_init.Done() { A_arbace_classes_lower_lower_letfn_fn__1304000222_A_init.Run(A_arbace_classes_lower_lower_letfn_fn__1304000222_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_clinit() { A_arbace_classes_lower_lower_letfn_fn__1304000222_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_272, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_fn__1304000222_A_class }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000222_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_fn__1304000222_A); return ok }

func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_fn__1304000222_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_fn__1304000222_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_fn__1304000222_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_fn__1304000225_A struct{ jrt.Object; F_with_others any }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_letfn_fn__1304000225_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_fn__1304000225_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_Init() { if !A_arbace_classes_lower_lower_letfn_fn__1304000225_A_init.Done() { A_arbace_classes_lower_lower_letfn_fn__1304000225_A_init.Run(A_arbace_classes_lower_lower_letfn_fn__1304000225_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_clinit() { A_arbace_classes_lower_lower_letfn_fn__1304000225_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_273, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_fn__1304000225_A_class }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_fn__1304000225_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_fn__1304000225_A); return ok }

func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_fn__1304000225_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_fn__1304000225_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_fn__1304000225_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A struct{ jrt.Object; F_boxes any }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_Init() { if !A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_init.Done() { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_init.Run(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_clinit() { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_274, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_class }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A); return ok }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A struct{ jrt.Object; F_boxes, F_s__1304000231, F_iter__1304000230 any }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_Init() { if !A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_init.Done() { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_init.Run(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_clinit() { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_275, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_class }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A); return ok }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A struct{ jrt.Object; F_b__1304000233, F_boxes any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_Init() { if !A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_init.Done() { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_init.Run(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_clinit() { A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_276, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_class }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A); return ok }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_with_others__1304000198_A struct{ jrt.Object; F_boxes, F_expand, F_names any }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_Init() { if !A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_init.Done() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_init.Run(A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_clinit() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_277, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_class }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_A); return ok }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A struct{ jrt.Object; F_boxes, F_others any }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_Init() { if !A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_init.Done() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_init.Run(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_clinit() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_279, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_class }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A); return ok }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A struct{ jrt.Object; F_iter__1304000201, F_boxes, F_others, F_s__1304000202 any }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_Init() { if !A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_init.Done() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_init.Run(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_clinit() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_280, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_class }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A); return ok }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A struct{ jrt.Object; F_b__1304000204, F_boxes, F_others any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_Init() { if !A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_init.Done() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_init.Run(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_clinit() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_281, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_class }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A); return ok }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A struct{ jrt.Object; F_boxes any }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_Init() { if !A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_init.Done() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_init.Run(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_clinit() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_282, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_class }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A); return ok }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_class)) }; return v }



type A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A struct{ jrt.Object; F_boxes any }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_Init() { if !A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_init.Done() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_init.Run(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_clinit) } }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_clinit() { A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_283, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_class }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A); return ok }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_Cast(x any) *A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_class)) }; return v }



type A_arbace_classes_lower_lower_reify_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_lower_reify_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_lower_reify_A_fn_class *jrt.Class

var A_arbace_classes_lower_lower_reify_A_init jrt.ClassInit

func A_arbace_classes_lower_lower_reify_A_Init() { if !A_arbace_classes_lower_lower_reify_A_init.Done() { A_arbace_classes_lower_lower_reify_A_init.Run(A_arbace_classes_lower_lower_reify_A_clinit) } }

func A_arbace_classes_lower_lower_reify_A_clinit() { A_arbace_classes_lower_lower_reify_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_284, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_lower_reify_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_lower_reify_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_lower_reify_A_class }

func (t *A_arbace_classes_lower_lower_reify_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_lower_reify_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_lower_reify_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_lower_reify_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_lower_reify_A); return ok }

func A_arbace_classes_lower_lower_reify_A_Cast(x any) *A_arbace_classes_lower_lower_reify_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_lower_reify_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_lower_reify_A_class)) }; return v }



type A_arbace_classes_lower_prim_interfaces_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_prim_interfaces_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_prim_interfaces_A_fn_class *jrt.Class

var A_arbace_classes_lower_prim_interfaces_A_init jrt.ClassInit

func A_arbace_classes_lower_prim_interfaces_A_Init() { if !A_arbace_classes_lower_prim_interfaces_A_init.Done() { A_arbace_classes_lower_prim_interfaces_A_init.Run(A_arbace_classes_lower_prim_interfaces_A_clinit) } }

func A_arbace_classes_lower_prim_interfaces_A_clinit() { A_arbace_classes_lower_prim_interfaces_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_286, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_prim_interfaces_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_prim_interfaces_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_prim_interfaces_A_class }

func (t *A_arbace_classes_lower_prim_interfaces_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_prim_interfaces_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_prim_interfaces_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_prim_interfaces_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_prim_interfaces_A); return ok }

func A_arbace_classes_lower_prim_interfaces_A_Cast(x any) *A_arbace_classes_lower_prim_interfaces_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_prim_interfaces_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_prim_interfaces_A_class)) }; return v }



type A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_fn_class *jrt.Class

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_init jrt.ClassInit

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_Init() { if !A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_init.Done() { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_init.Run(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_clinit) } }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_clinit() { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_287, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_class }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A); return ok }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_Cast(x any) *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_class)) }; return v }



type A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A struct{ jrt.Object; F_iter__1304000046, F_s__1304000047 any }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_fn_class *jrt.Class

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_init jrt.ClassInit

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_Init() { if !A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_init.Done() { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_init.Run(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_clinit) } }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_clinit() { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_288, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_class }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A); return ok }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_Cast(x any) *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_class)) }; return v }



type A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A struct{ jrt.Object; F_b__1304000049 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_fn_class *jrt.Class

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_init jrt.ClassInit

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_Init() { if !A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_init.Done() { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_init.Run(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_clinit) } }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_clinit() { A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_290, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_class }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A); return ok }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_Cast(x any) *A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_class)) }; return v }



type A_arbace_classes_lower_prim_sig_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_prim_sig_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_prim_sig_A_fn_class *jrt.Class

var A_arbace_classes_lower_prim_sig_A_init jrt.ClassInit

func A_arbace_classes_lower_prim_sig_A_Init() { if !A_arbace_classes_lower_prim_sig_A_init.Done() { A_arbace_classes_lower_prim_sig_A_init.Run(A_arbace_classes_lower_prim_sig_A_clinit) } }

func A_arbace_classes_lower_prim_sig_A_clinit() { A_arbace_classes_lower_prim_sig_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_291, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_prim_sig_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_prim_sig_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_prim_sig_A_class }

func (t *A_arbace_classes_lower_prim_sig_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_prim_sig_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_prim_sig_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_prim_sig_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_prim_sig_A); return ok }

func A_arbace_classes_lower_prim_sig_A_Cast(x any) *A_arbace_classes_lower_prim_sig_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_prim_sig_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_prim_sig_A_class)) }; return v }



type A_arbace_classes_lower_prim_sig_fn__1304000043_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_prim_sig_fn__1304000043_A_fn_class *jrt.Class

var A_arbace_classes_lower_prim_sig_fn__1304000043_A_init jrt.ClassInit

func A_arbace_classes_lower_prim_sig_fn__1304000043_A_Init() { if !A_arbace_classes_lower_prim_sig_fn__1304000043_A_init.Done() { A_arbace_classes_lower_prim_sig_fn__1304000043_A_init.Run(A_arbace_classes_lower_prim_sig_fn__1304000043_A_clinit) } }

func A_arbace_classes_lower_prim_sig_fn__1304000043_A_clinit() { A_arbace_classes_lower_prim_sig_fn__1304000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_293, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_prim_sig_fn__1304000043_A_class }

func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_prim_sig_fn__1304000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_prim_sig_fn__1304000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_prim_sig_fn__1304000043_A); return ok }

func A_arbace_classes_lower_prim_sig_fn__1304000043_A_Cast(x any) *A_arbace_classes_lower_prim_sig_fn__1304000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_prim_sig_fn__1304000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_prim_sig_fn__1304000043_A_class)) }; return v }



type A_arbace_classes_lower_prim_tag_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_lower_prim_tag_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_prim_tag_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_lower_prim_tag_QMARK__A_init jrt.ClassInit

func A_arbace_classes_lower_prim_tag_QMARK__A_Init() { if !A_arbace_classes_lower_prim_tag_QMARK__A_init.Done() { A_arbace_classes_lower_prim_tag_QMARK__A_init.Run(A_arbace_classes_lower_prim_tag_QMARK__A_clinit) } }

func A_arbace_classes_lower_prim_tag_QMARK__A_clinit() { A_arbace_classes_lower_prim_tag_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_294, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_prim_tag_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_prim_tag_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_prim_tag_QMARK__A_class }

func (t *A_arbace_classes_lower_prim_tag_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_prim_tag_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_prim_tag_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_prim_tag_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_prim_tag_QMARK__A); return ok }

func A_arbace_classes_lower_prim_tag_QMARK__A_Cast(x any) *A_arbace_classes_lower_prim_tag_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_prim_tag_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_prim_tag_QMARK__A_class)) }; return v }



type A_arbace_classes_lower_symbols_in_A struct{ jrt.Object }

func (t *A_arbace_classes_lower_symbols_in_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_symbols_in_A_fn_class *jrt.Class

var A_arbace_classes_lower_symbols_in_A_init jrt.ClassInit

func A_arbace_classes_lower_symbols_in_A_Init() { if !A_arbace_classes_lower_symbols_in_A_init.Done() { A_arbace_classes_lower_symbols_in_A_init.Run(A_arbace_classes_lower_symbols_in_A_clinit) } }

func A_arbace_classes_lower_symbols_in_A_clinit() { A_arbace_classes_lower_symbols_in_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_295, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_symbols_in_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_symbols_in_A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_symbols_in_A_class }

func (t *A_arbace_classes_lower_symbols_in_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_symbols_in_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_symbols_in_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_symbols_in_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_symbols_in_A); return ok }

func A_arbace_classes_lower_symbols_in_A_Cast(x any) *A_arbace_classes_lower_symbols_in_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_symbols_in_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_symbols_in_A_class)) }; return v }



type A_arbace_classes_lower_variadic_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_lower_variadic_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_lower_variadic_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_lower_variadic_QMARK__A_init jrt.ClassInit

func A_arbace_classes_lower_variadic_QMARK__A_Init() { if !A_arbace_classes_lower_variadic_QMARK__A_init.Done() { A_arbace_classes_lower_variadic_QMARK__A_init.Run(A_arbace_classes_lower_variadic_QMARK__A_clinit) } }

func A_arbace_classes_lower_variadic_QMARK__A_clinit() { A_arbace_classes_lower_variadic_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_296, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_lower_variadic_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_lower_variadic_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_lower_variadic_QMARK__A_class }

func (t *A_arbace_classes_lower_variadic_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_lower_variadic_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_lower_variadic_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_lower_variadic_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_lower_variadic_QMARK__A); return ok }

func A_arbace_classes_lower_variadic_QMARK__A_Cast(x any) *A_arbace_classes_lower_variadic_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_lower_variadic_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_lower_variadic_QMARK__A_class)) }; return v }
