//line j2g_strings.ae:1
package aot_arbace_classes_lower

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.corekn3,dockn4,namekn7,aritiesks6,arbace13,compile-erroryn1,&yn4,longyn6,doublekn4,elsekn3,tagyn15,arbace.lang.IFnyn4,let*yn5,loop*ks14,arbace.classes7,fn-bodyyn6,methodyn10,invokePrimkn6,publicyn6,invokeyn11,.invokePrimys14,arbace.lang.RT8,longCastys14,arbace.lang.RT10,doubleCastyn8,doInvokekn9,protectedyn16,getRequiredArityyn3,intkn4,linekn6,columnkn4,filekn6,rettagkn8,end-linekn10,end-columnyn18,arbace.lang.RestFnyn21,arbace.lang.AFunctionyn6,class*kn4,anonkn10,clojure-fnkn5,localkn5,finalkn7,extendskn10,implementsyn3,newys11,arbace.core9,with-metakn14,clojure-methodyn5,recuryn2,doyn26,arbace.lang.IPersistentMapkn12,clojure-typeyn16,arbace.lang.IObjyn5,fieldyn6,__metakn7,privateyn11,constructoryn4,set!yn8,.-__metayn4,metayn8,withMetayn5,this.yn5,quotekn10,reflectionkn7,clojurekn7,packagekn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn11,clojure-tagyn6,super.ys11,arbace.core3,intyn8,getBasiskn6,staticyn29,arbace.lang.IPersistentVectoryn6,createys19,arbace.lang.Keyword6,internyn1,.yn5,valAtyn7,withoutys11,arbace.core4,castys14,arbace.lang.RT9,seqOrElseyn3,fn*yn5,.-valyn15,arbace.lang.Boxys11,arbace.core11,bit-and-intys11,arbace.core19,bit-shift-right-intkn3,intkn13,hash-identityyn6,break*yn2,ifys11,arbace.core2,==ys16,arbace.lang.Util5,equivys11,arbace.core10,identical?yn7,switch*yn6,label*ys16,arbace.lang.Util4,hashys11,arbace.core13,unchecked-intys11,arbace.core9,instance?yn16,java.lang.Numberyn9,.intValueyn3,varyn8,bindRootyn7,setMetayn10,setDynamickn7,dynamicv11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn20,arbace.classes.lowerm2,R4,s1573,Clojure's special forms that the Java forms compiler compiles by rewriting them into class\n  forms and other forms it knows (SPEC §5.13, §9.5): fn*, reify*, deftype*, letfn*, case* and def. These\n  are pure form-to-form functions; arbace.classes.analyze analyzes their results.\n\n  - (fn* ...) becomes an anonymous subclass of arbace.lang.AFunction (or RestFn when it has a\n    variadic arity) with an invoke method per arity (doInvoke and getRequiredArity for the\n    variadic one), as arbace.lang.Compiler's fn classes have them. Its body has Clojure's\n    meaning: the parameters are Object, recur goes to the top of the arity, the fn's name is the\n    instance. `fn-methods` makes the members; arbace.classes.native uses them for the top-level\n    class of a fn that arbace.lang.Compiler hands over.\n  - (reify* [interfaces] methods) becomes a local class implementing them and IObj, its methods\n    choosing the interface method they implement as arbace.lang.Compiler does (`clojure-method`).\n  - (deftype* ...) gives the Java form of the deftype class (`deftype-class-form`), which\n    arbace.classes.native compiles when arbace.lang.Compiler hands a deftype over.\n  - (letfn* [f (fn* f ...) ...] body) binds boxes first, then the fns, whose bodies read the\n    others from their boxes, then fills the boxes.\n  - (case* ...) becomes a switch on the hash (or int value) inside a label, with the equality\n    test in each arm and the default after the switch, as arbace.lang.Compiler's CaseExpr.\n  - (def ...) becomes calls of the var's bindRoot, setMeta and setDynamic.v11,arbace.core6,symbolv20,arbace.classes.lower7,next-idv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core7,symbol?v11,arbace.core7,vector?R5,R6,v11,arbace.core4,mapvv11,arbace.core4,restv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core4,seq?v11,arbace.core7,ex-infov11,arbace.core6,pr-strm2,R7,Tv11,arbace.core10,chunk-restm2,R7,Tv11,arbace.core9,namespacev20,arbace.classes.lower9,prim-tagsv11,arbace.core4,someS1,R8,R9,R10,v20,arbace.classes.lower9,prim-tag?m2,R7,TR11,v20,arbace.classes.lower9,variadic?v11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core6,concatv11,arbace.core3,mapv20,arbace.classes.lower10,class-charR12,v11,arbace.core7,re-findp4,[LD]m2,R7,Tv11,arbace.core3,vecv11,arbace.core8,distinctv11,arbace.core12,chunk-bufferv20,arbace.classes.lower8,prim-sigv11,arbace.core12,chunk-appendR13,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core6,filterv11,arbace.core6,mapcatv11,arbace.core10,split-withv11,arbace.core4,not=R8,v20,arbace.classes.lower4,gsymv11,arbace.core9,vary-metav11,arbace.core6,dissocv11,arbace.core4,listv11,arbace.core4,compv20,arbace.classes.lower9,sig-typesv11,arbace.core7,butlastv11,arbace.core9,with-metaR14,v11,arbace.core5,list*R15,m2,R16,Tv11,arbace.core4,lastR17,R18,m2,R19,TR17,R20,m2,R19,TR21,R9,R10,R22,R23,R17,R24,R20,R25,R19,R17,R26,m2,R19,Tm2,R12,R27,v11,arbace.core10,take-whileR8,m2,R7,TR28,R29,R30,R31,R32,R33,v20,arbace.classes.lower8,fn-partsv11,arbace.core8,to-arrayR34,R35,v20,arbace.classes.lower15,prim-interfacesR36,R37,m2,R38,Tv20,arbace.classes.lower10,fn-methodsv20,arbace.classes.lower7,fn-metaR36,R39,m4,R38,TR40,TR41,R42,R43,R44,v11,arbace.core4,namem2,R7,Tm2,R7,Tm2,R7,TR17,v11,arbace.core5,mungev11,arbace.core5,assocR45,v11,arbace.core9,contains?v20,arbace.classes.lower10,symbols-inR46,R15,m2,R16,TR47,R48,R36,m6,R38,TR49,TR40,TR50,R51,R52,R40,R53,R54,m2,R19,TR55,R56,R17,R57,m2,R19,TR56,R17,R58,m2,R19,Tm2,R12,R50,R43,v20,arbace.classes.lower14,clojure-methodR43,v11,arbace.core4,intov11,arbace.core3,keyv11,arbace.core8,keyword?v11,arbace.core6,secondv11,arbace.core5,nnextv11,arbace.core4,subsl0,v20,arbace.classes.lower15,alt-ctor-fieldsv11,arbace.core4,rseqv11,arbace.core6,subvecR54,v11,arbace.core4,takem2,R19,TR59,R44,R60,R60,R60,v11,arbace.core5,mergev20,arbace.classes.lower15,annotation-metam10,R19,TR40,TR38,TR49,TR61,R62,R63,R51,R64,m2,R65,TR66,m4,R19,TR40,Tv11,arbace.core5,some?R67,m2,R65,Tm4,R19,TR40,TR54,m2,R19,TR68,R55,V4,nnML2,R69,l0,m4,R28,i259,R29,i34,ML2,R69,l0,m4,R28,i259,R29,i55,V2,ML2,R69,l0,m4,R28,i260,R29,i26,ML2,R69,l0,m4,R28,i260,R29,i47,R17,R70,m4,R19,TR71,Tm2,R12,R72,v11,arbace.core5,rangeR17,R73,m4,R19,TR71,Tm2,R12,R48,R14,R74,R75,R76,R75,R77,R43,R75,R78,v20,arbace.classes.lower5,boxesML2,R69,l0,m4,R28,i282,R29,i41,ML2,R69,l0,m4,R28,i282,R29,i62,R79,v11,arbace.core4,peekv11,arbace.core4,set?v11,arbace.core6,reducev11,arbace.core4,map?v11,arbace.core8,identityv11,arbace.core9,partitionl2,v11,arbace.core6,zipmapR80,m2,R7,Tv11,arbace.core6,removev11,arbace.core3,setR80,R81,R14,R14,R43,R82,R55,R81,v11,arbace.core7,keywordR83,R84,R85,R86,R87,R88,R89,R90,R60,R87,R88,R91,R60,R87,R88,R90,R60,R87,v11,arbace.core7,sort-byR92,R93,R94,R95,R88,R96,R97,R98,R78,R97,V3,nFnm2,R7,TR4,R14,R99,R75,R100,R75,R101,R75,R102,R103,")

var Lit_1 *jrt.String = jrt.Intern("L")

var Lit_2 *jrt.String = jrt.Intern("D")

var Lit_3 *jrt.String = jrt.Intern("Only long and double primitives are supported")

var Lit_4 *jrt.String = jrt.Intern("O")

var Lit_5 *jrt.String = jrt.Intern("Must supply at least one argument for 'this' in: ")

var Lit_6 *jrt.String = jrt.Intern("params must be Symbols")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.lower$clojure_method$fn__1304000105")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.lower$clojure_method$fn__1304000107")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000124")

var Lit_10 *jrt.String = jrt.Intern(".")

var Lit_11 *jrt.String = jrt.Intern("")

var Lit_12 *jrt.String = jrt.Intern("this")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000126")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fname__1304000128")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$ptag__1304000130")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$param__1304000132")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$ctor__1304000134")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000136__1304000140")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000146__1304000150")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000156__1304000160")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000166__1304000170")

var Lit_22 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000176__1304000180")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000186")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$fn__1304000188")

var Lit_25 *jrt.String = jrt.Intern("Value")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000136__1304000140$fn__1304000141")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000136__1304000140$fn__1304000141$fn__1304000142")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000146__1304000150$fn__1304000151")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000146__1304000150$fn__1304000151$fn__1304000152")

var Lit_30 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000156__1304000160$fn__1304000161")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000156__1304000160$fn__1304000161$fn__1304000162")

var Lit_32 *jrt.String = jrt.Intern(".-")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000166__1304000170$fn__1304000171")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000166__1304000170$fn__1304000171$fn__1304000172")

var Lit_35 *jrt.String = jrt.Intern("m")

var Lit_36 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000176__1304000180$fn__1304000181")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form$iter__1304000176__1304000180$fn__1304000181$fn__1304000182")

var Lit_38 *jrt.String = jrt.Intern("Can't have more than 1 variadic overload")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000061")

var Lit_40 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000086")

var Lit_41 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000061$fn__1304000071")

var Lit_42 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000061$fn__1304000073")

var Lit_43 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000061$fn__1304000075")

var Lit_44 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000061$typed__1304000077")

var Lit_45 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods$fn__1304000061$fn__1304000079")

var Lit_46 *jrt.String = jrt.Intern("p")

var Lit_47 *jrt.String = jrt.Intern("Bad fn form: ")

var Lit_48 *jrt.String = jrt.Intern("arbace.classes.lower$fn_parts$fn__1304000026")

var Lit_49 *jrt.String = jrt.Intern("__")

var Lit_50 *jrt.String = jrt.Intern("__auto__")

var Lit_51 *jrt.String = jrt.Intern("case")

var Lit_52 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case$sm__1304000246")

var Lit_53 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case$fn__1304000249")

var Lit_54 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case$sw__1304000257")

var Lit_55 *jrt.String = jrt.Intern("Too many arguments to def")

var Lit_56 *jrt.String = jrt.Intern("var")

var Lit_57 *jrt.String = jrt.Intern("fn")

var Lit_58 *jrt.String = jrt.Intern("Fn")

var Lit_59 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$fn__1304000197")

var Lit_60 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000199")

var Lit_61 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$fn__1304000223")

var Lit_62 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$fn__1304000226")

var Lit_63 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$iter__1304000231__1304000235")

var Lit_64 *jrt.String = jrt.Intern("box_")

var Lit_65 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$iter__1304000231__1304000235$fn__1304000236")

var Lit_66 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$iter__1304000231__1304000235$fn__1304000236$fn__1304000237")

var Lit_67 *jrt.String = jrt.Intern("letfn binding is not a fn: ")

var Lit_68 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000199$iter__1304000202__1304000206")

var Lit_69 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000199$iter__1304000202__1304000206$fn__1304000207")

var Lit_70 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000199$iter__1304000202__1304000206$fn__1304000207$fn__1304000208")

var Lit_71 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000199$iter__1304000202__1304000206$fn__1304000207$fn__1304000218")

var Lit_72 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn$with_others__1304000199$iter__1304000202__1304000206$fn__1304000207$fn__1304000208$fn__1304000212")

var Lit_73 *jrt.String = jrt.Intern("Reify")

var Lit_74 *jrt.String = jrt.Intern("meta")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces$iter__1304000047__1304000051")

var Lit_76 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces$iter__1304000047__1304000051$fn__1304000052")

var Lit_77 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces$iter__1304000047__1304000051$fn__1304000052$fn__1304000053")

var Lit_78 *jrt.String = jrt.Intern("$")

var Lit_79 *jrt.String = jrt.Intern("arbace.classes.lower$prim_sig$fn__1304000044")

var Lit_80 *jrt.String = jrt.Intern("fns taking primitives support only 4 or fewer args")

var Lit_81 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn4,linekn6,columnkn4,fileyn6,prefixyn1,_yn1,&yn4,morekn2,asyn4,formyn7,booleanyn4,charyn4,longyn6,doubleyn5,shortyn3,intyn5,floatyn4,byteyn1,xyn2,pvyn3,tagyn5,arityyn7,aritiesyn3,rcvyn2,nmyn5,bindskn8,declaredyn4,bodyyn6,ifacesyn7,methodsyn17,java.lang.Integeryn14,java.lang.Longyn15,java.lang.Floatyn16,java.lang.Doubleyn19,java.lang.Characteryn15,java.lang.Shortyn14,java.lang.Byteyn17,java.lang.Booleanyn1,myn8,_tagnameyn9,classnameyn6,fieldsyn8,bindingsyn6,expandyn2,geyn5,shiftyn4,maskyn7,defaultyn4,imapyn12,_switch-typeyn9,test-typeyn10,skip-checkyn9,prim-int?yn3,symyn4,fileyn4,lineyn6,columnv11,arbace.core5,in-nsMyn20,arbace.classes.lowerm2,R0,s1573,Clojure's special forms that the Java forms compiler compiles by rewriting them into class\n  forms and other forms it knows (SPEC §5.13, §9.5): fn*, reify*, deftype*, letfn*, case* and def. These\n  are pure form-to-form functions; arbace.classes.analyze analyzes their results.\n\n  - (fn* ...) becomes an anonymous subclass of arbace.lang.AFunction (or RestFn when it has a\n    variadic arity) with an invoke method per arity (doInvoke and getRequiredArity for the\n    variadic one), as arbace.lang.Compiler's fn classes have them. Its body has Clojure's\n    meaning: the parameters are Object, recur goes to the top of the arity, the fn's name is the\n    instance. `fn-methods` makes the members; arbace.classes.native uses them for the top-level\n    class of a fn that arbace.lang.Compiler hands over.\n  - (reify* [interfaces] methods) becomes a local class implementing them and IObj, its methods\n    choosing the interface method they implement as arbace.lang.Compiler does (`clojure-method`).\n  - (deftype* ...) gives the Java form of the deftype class (`deftype-class-form`), which\n    arbace.classes.native compiles when arbace.lang.Compiler hands a deftype over.\n  - (letfn* [f (fn* f ...) ...] body) binds boxes first, then the fns, whose bodies read the\n    others from their boxes, then fills the boxes.\n  - (case* ...) becomes a switch on the hash (or int value) inside a label, with the equality\n    test in each arm and the default after the switch, as arbace.lang.Compiler's CaseExpr.\n  - (def ...) becomes calls of the var's bindRoot, setMeta and setDynamic.m2,R0,s1573,Clojure's special forms that the Java forms compiler compiles by rewriting them into class\n  forms and other forms it knows (SPEC §5.13, §9.5): fn*, reify*, deftype*, letfn*, case* and def. These\n  are pure form-to-form functions; arbace.classes.analyze analyzes their results.\n\n  - (fn* ...) becomes an anonymous subclass of arbace.lang.AFunction (or RestFn when it has a\n    variadic arity) with an invoke method per arity (doInvoke and getRequiredArity for the\n    variadic one), as arbace.lang.Compiler's fn classes have them. Its body has Clojure's\n    meaning: the parameters are Object, recur goes to the top of the arity, the fn's name is the\n    instance. `fn-methods` makes the members; arbace.classes.native uses them for the top-level\n    class of a fn that arbace.lang.Compiler hands over.\n  - (reify* [interfaces] methods) becomes a local class implementing them and IObj, its methods\n    choosing the interface method they implement as arbace.lang.Compiler does (`clojure-method`).\n  - (deftype* ...) gives the Java form of the deftype class (`deftype-class-form`), which\n    arbace.classes.native compiles when arbace.lang.Compiler hands a deftype over.\n  - (letfn* [f (fn* f ...) ...] body) binds boxes first, then the fns, whose bodies read the\n    others from their boxes, then fills the boxes.\n  - (case* ...) becomes a switch on the hash (or int value) inside a label, with the equality\n    test in each arm and the default after the switch, as arbace.lang.Compiler's CaseExpr.\n  - (def ...) becomes calls of the var's bindRoot, setMeta and setDynamic.R1,v20,arbace.classes.lower7,next-idm10,R2,TR3,L1,V0,R4,i28,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower4,gsymm10,R2,TR3,L1,V1,R7,R4,i30,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower8,fn-partsm10,R3,L1,V1,V5,R8,R9,R10,R11,R12,R0,s92,(fn* name? [params] body*) or (fn* name? ([params] body*)+) as {:name :arities [[pv body]]}.R4,i35,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower9,prim-tagsS8,R13,R14,R15,R16,R17,R18,R19,R20,m8,R2,TR4,i45,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower9,prim-tag?m10,R2,TR3,L1,V1,R21,R4,i47,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower9,variadic?m8,R3,L1,V1,V2,R22,R8,R4,i49,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower10,class-charm12,R2,TR3,L1,V1,R23,R0,s87,Compiler.classChar: L for long, D for double, O for anything else that is no primitive.R4,i51,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower8,prim-sigm10,R3,L1,V1,V4,R22,R8,R11,R24,R0,s154,The primitive signature of a fixed arity (\"LO\" for ^long x returning Object), as\n  arbace.lang.Compiler's FnMethod.primInterface, or nil when it has none.R4,i60,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower15,prim-interfacesm10,R3,L1,V1,R25,R0,s66,The IFn$... interfaces of the primitive signatures of the arities.R4,i71,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower9,sig-typesm6,s1,LR15,s1,DR16,s1,Onm8,R2,TR4,i76,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower10,fn-methodsm10,R3,L1,V4,R26,R27,R25,R28,R0,s487,The members of the class of a fn: an invoke (or doInvoke) method per arity, and\n  getRequiredArity when variadic. `binds` are bindings [sym init ...] made at the start of every\n  arity, before the fn's name (bound to the instance) and the parameters (initializers may use\n  the receiver `rcv`). An arity with a primitive signature (prim-sig) has its body in invokePrim\n  of its IFn$... interface, and invoke converts the arguments and calls it, as\n  arbace.lang.Compiler's fn classes do.R4,i78,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower7,fn-metam10,R3,L1,V1,R12,R0,s86,The metadata of a fn* form that the fn object gets (without source positions), or nil.R4,i123,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower8,lower-fnm10,R3,L1,V1,R12,R0,s180,(fn* ...) in code compiled by the Java forms compiler: an anonymous AFunction or RestFn, or\n  with primitive signatures a local class that also implements their IFn$... interfaces.R4,i129,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower10,symbols-inm8,R29,TR4,i152,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower14,clojure-methodm10,R3,L1,V1,V4,R27,R22,R9,R30,R0,s372,A method (name [this params*] body*) of reify* or deftype* as a Java form method: public,\n  its name munged, marked :clojure-method so that arbace.classes.analyze picks the interface\n  method it implements as arbace.lang.Compiler does (by name and arity, then by the hints of the\n  parameters and of the name), with recur to the top of the method when its body uses recur.R4,i154,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower11,lower-reifym10,R3,L1,V1,V6,R8,R31,R9,R32,R11,R12,R0,s281,(reify* [interface*] (method [this params*] body*)*): a local class implementing the\n  interfaces and arbace.lang.IObj (its metadata in __meta, withMeta making a copy), its methods\n  `clojure-method`s. Evaluates to an instance with the form's metadata (without source\n  positions).R4,i176,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower15,alt-ctor-fieldsS4,s6,__hashs8,__hasheqs8,__extmaps6,__metam8,R2,TR4,i201,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower5,boxesm16,R18,R33,R15,R34,R19,R35,R16,R36,R14,R37,R17,R38,R20,R39,R13,R40,m8,R2,TR4,i203,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower15,annotation-metam10,R2,TR3,L1,V1,R41,R4,i207,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower18,deftype-class-formm10,R3,L1,V1,V6,R8,R42,R43,R44,R9,R10,R0,s709,The Java form (the rest of a defclass form) of (deftype* tagname classname [field*]\n  :implements [interface*] option* method*), with the shape arbace.lang.Compiler gives a\n  deftype (NewInstanceExpr): a public final class implementing the interfaces; a field per\n  field, public final, or volatile for ^:volatile-mutable, package-private for\n  ^:unsynchronized-mutable, primitive for a primitive hint and otherwise Object (a reference\n  hint stays a hint of the field, :clojure-tag); a constructor taking the fields; for records\n  (fields ending in __meta __extmap __hash __hasheq) the two shorter constructors and the\n  static create(IPersistentMap); the static getBasis(); the methods as `clojure-method`s.R4,i209,R5,i1,R6,s23,arbace/classes/lower.aem10,R3,L1,V1,R12,R0,s57,The unqualified symbols occurring in form (any position).R4,i288,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower11,lower-letfnm10,R3,L1,V2,V4,R8,R45,R9,R30,R46,R0,s156,(letfn* [f (fn f ...) ...] body*): each fn reads the others from boxes filled after all\n  are created. `expand` macroexpands an initializer to its fn* form.R4,i297,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower10,lower-casem10,R3,L1,V2,V9,R8,R47,R48,R49,R50,R51,R52,R53,R54,R55,R0,s411,(case* ge shift mask default imap switch-type test-type skip-check?), as CaseExpr compiles\n  it: the int value (test-type :int) or hash of ge, shifted and masked, selects an arm, which\n  tests ge against the arm's constant (= or, for :hash-identity, identical?) and on success\n  leaves the case with the arm's value; otherwise the default. `prim-int?` says whether ge is a\n  local of an integral primitive type.R4,i327,R5,i1,R6,s23,arbace/classes/lower.aev20,arbace.classes.lower9,lower-defm10,R3,L1,V4,V4,R8,R56,R9,R10,R57,R58,R59,R0,s243,(def sym), (def sym init), (def sym doc init) as calls on the var (already interned): binds\n  the root when there is an initializer, sets the metadata (with the source position and doc)\n  and the dynamic flag, as DefExpr does. Returns the var.R4,i367,R5,i1,R6,s23,arbace/classes/lower.ae")

var Lit_82 *jrt.String = jrt.Intern("arbace.classes.lower$eval1304000004$loading__1927001464__auto____1304000005")

var Lit_83 *jrt.String = jrt.Intern("arbace.classes.lower$eval1304000008$fn__1304000009")

var Lit_84 *jrt.String = jrt.Intern("arbace.classes.lower$next_id")

var Lit_85 *jrt.String = jrt.Intern("arbace.classes.lower$gsym")

var Lit_86 *jrt.String = jrt.Intern("arbace.classes.lower$fn_parts")

var Lit_87 *jrt.String = jrt.Intern("arbace.classes.lower$prim_tag_QMARK_")

var Lit_88 *jrt.String = jrt.Intern("arbace.classes.lower$variadic_QMARK_")

var Lit_89 *jrt.String = jrt.Intern("arbace.classes.lower$class_char")

var Lit_90 *jrt.String = jrt.Intern("arbace.classes.lower$prim_sig")

var Lit_91 *jrt.String = jrt.Intern("arbace.classes.lower$prim_interfaces")

var Lit_92 *jrt.String = jrt.Intern("arbace.classes.lower$fn_methods")

var Lit_93 *jrt.String = jrt.Intern("arbace.classes.lower$fn_meta")

var Lit_94 *jrt.String = jrt.Intern("arbace.classes.lower$lower_fn")

var Lit_95 *jrt.String = jrt.Intern("arbace.classes.lower$clojure_method")

var Lit_96 *jrt.String = jrt.Intern("arbace.classes.lower$lower_reify")

var Lit_97 *jrt.String = jrt.Intern("arbace.classes.lower$annotation_meta")

var Lit_98 *jrt.String = jrt.Intern("arbace.classes.lower$deftype_class_form")

var Lit_99 *jrt.String = jrt.Intern("arbace.classes.lower$symbols_in")

var Lit_100 *jrt.String = jrt.Intern("arbace.classes.lower$lower_letfn")

var Lit_101 *jrt.String = jrt.Intern("arbace.classes.lower$lower_case")

var Lit_102 *jrt.String = jrt.Intern("arbace.classes.lower$lower_def")
