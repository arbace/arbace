//line j2g_up.ae:1
package aot_arbace_classes_lower

import "arbace/lang"


func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_PersistentArrayMap_IPersistentMap(p *lang.PersistentArrayMap) lang.IPersistentMap { if p == nil { return nil }; return p }
