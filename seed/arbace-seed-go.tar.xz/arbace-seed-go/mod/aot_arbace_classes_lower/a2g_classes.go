//line a2g_classes.ae:1
package aot_arbace_classes_lower

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_lower_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_A_New()}; return nil }

var A_arbace_classes_lower_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_lower_A_new}

var A_arbace_classes_lower_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_A"})

func init() { i := A_arbace_classes_lower_A_class.Info(); i.IsInstance = A_arbace_classes_lower_A_InstanceOf; i.Init = A_arbace_classes_lower_A_Init; i.Table = A_arbace_classes_lower_A_members; jrt.RegisterGoType(A_arbace_classes_lower_A_class, reflect.TypeFor[A_arbace_classes_lower_A]()) }

func A_arbace_classes_lower_annotation_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_annotation_meta_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_annotation_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_annotation_meta_A_New()}; return nil }

func A_arbace_classes_lower_annotation_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_annotation_meta_A_fn_class)}; return nil }

var A_arbace_classes_lower_annotation_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_annotation_meta_A_invoke, New: A_arbace_classes_lower_annotation_meta_A_new, Get: A_arbace_classes_lower_annotation_meta_A_get}

var A_arbace_classes_lower_annotation_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$annotation_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "annotation_meta", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_annotation_meta_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_annotation_meta_A_class.Info(); i.IsInstance = A_arbace_classes_lower_annotation_meta_A_InstanceOf; i.Init = A_arbace_classes_lower_annotation_meta_A_Init; i.Table = A_arbace_classes_lower_annotation_meta_A_members; jrt.RegisterGoType(A_arbace_classes_lower_annotation_meta_A_class, reflect.TypeFor[A_arbace_classes_lower_annotation_meta_A]()) }

func A_arbace_classes_lower_class_char_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_class_char_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_class_char_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_class_char_A_New()}; return nil }

func A_arbace_classes_lower_class_char_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_class_char_A_fn_class)}; return nil }

var A_arbace_classes_lower_class_char_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_class_char_A_invoke, New: A_arbace_classes_lower_class_char_A_new, Get: A_arbace_classes_lower_class_char_A_get}

var A_arbace_classes_lower_class_char_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$class_char", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "class_char", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_class_char_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_class_char_A_class.Info(); i.IsInstance = A_arbace_classes_lower_class_char_A_InstanceOf; i.Init = A_arbace_classes_lower_class_char_A_Init; i.Table = A_arbace_classes_lower_class_char_A_members; jrt.RegisterGoType(A_arbace_classes_lower_class_char_A_class, reflect.TypeFor[A_arbace_classes_lower_class_char_A]()) }

func A_arbace_classes_lower_clojure_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_clojure_method_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_clojure_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_clojure_method_A_New()}; return nil }

func A_arbace_classes_lower_clojure_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_clojure_method_A_fn_class)}; return nil }

var A_arbace_classes_lower_clojure_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_clojure_method_A_invoke, New: A_arbace_classes_lower_clojure_method_A_new, Get: A_arbace_classes_lower_clojure_method_A_get}

var A_arbace_classes_lower_clojure_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$clojure_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "clojure_method", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_clojure_method_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_clojure_method_A_class.Info(); i.IsInstance = A_arbace_classes_lower_clojure_method_A_InstanceOf; i.Init = A_arbace_classes_lower_clojure_method_A_Init; i.Table = A_arbace_classes_lower_clojure_method_A_members; jrt.RegisterGoType(A_arbace_classes_lower_clojure_method_A_class, reflect.TypeFor[A_arbace_classes_lower_clojure_method_A]()) }

func A_arbace_classes_lower_clojure_method_fn__1304000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_clojure_method_fn__1304000104_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_clojure_method_fn__1304000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_clojure_method_fn__1304000104_A_New()}; return nil }

func A_arbace_classes_lower_clojure_method_fn__1304000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_clojure_method_fn__1304000104_A_fn_class)}; return nil }

var A_arbace_classes_lower_clojure_method_fn__1304000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_clojure_method_fn__1304000104_A_invoke, New: A_arbace_classes_lower_clojure_method_fn__1304000104_A_new, Get: A_arbace_classes_lower_clojure_method_fn__1304000104_A_get}

var A_arbace_classes_lower_clojure_method_fn__1304000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$clojure_method$fn__1304000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_clojure_method_A_class, Simple: "fn__1304000104", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_clojure_method_fn__1304000104_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_clojure_method_fn__1304000104_A_class.Info(); i.IsInstance = A_arbace_classes_lower_clojure_method_fn__1304000104_A_InstanceOf; i.Init = A_arbace_classes_lower_clojure_method_fn__1304000104_A_Init; i.Table = A_arbace_classes_lower_clojure_method_fn__1304000104_A_members; jrt.RegisterGoType(A_arbace_classes_lower_clojure_method_fn__1304000104_A_class, reflect.TypeFor[A_arbace_classes_lower_clojure_method_fn__1304000104_A]()) }

func A_arbace_classes_lower_clojure_method_fn__1304000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_clojure_method_fn__1304000106_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_clojure_method_fn__1304000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_clojure_method_fn__1304000106_A_New()}; return nil }

func A_arbace_classes_lower_clojure_method_fn__1304000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_clojure_method_fn__1304000106_A_fn_class)}; return nil }

var A_arbace_classes_lower_clojure_method_fn__1304000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_clojure_method_fn__1304000106_A_invoke, New: A_arbace_classes_lower_clojure_method_fn__1304000106_A_new, Get: A_arbace_classes_lower_clojure_method_fn__1304000106_A_get}

var A_arbace_classes_lower_clojure_method_fn__1304000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$clojure_method$fn__1304000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_clojure_method_A_class, Simple: "fn__1304000106", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_clojure_method_fn__1304000106_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_clojure_method_fn__1304000106_A_class.Info(); i.IsInstance = A_arbace_classes_lower_clojure_method_fn__1304000106_A_InstanceOf; i.Init = A_arbace_classes_lower_clojure_method_fn__1304000106_A_Init; i.Table = A_arbace_classes_lower_clojure_method_fn__1304000106_A_members; jrt.RegisterGoType(A_arbace_classes_lower_clojure_method_fn__1304000106_A_class, reflect.TypeFor[A_arbace_classes_lower_clojure_method_fn__1304000106_A]()) }

func A_arbace_classes_lower_deftype_class_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_A_New()}; return nil }

func A_arbace_classes_lower_deftype_class_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_A_invoke, New: A_arbace_classes_lower_deftype_class_form_A_new, Get: A_arbace_classes_lower_deftype_class_form_A_get}

var A_arbace_classes_lower_deftype_class_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "deftype_class_form", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_A]()) }

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_invoke, New: A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_new, Get: A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_get}

var A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$ctor__1304000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "ctor__1304000133", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_ctor__1304000133_A]()) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_fn__1304000123_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_invoke, New: A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_new, Get: A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_get}

var A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$fn__1304000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "fn__1304000123", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_fn__1304000123_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_fn__1304000123_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_fn__1304000123_A]()) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_fn__1304000125_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_New()}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_invoke, New: A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_new, Get: A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_get}

var A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$fn__1304000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "fn__1304000125", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_fn__1304000125_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_fn__1304000125_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_fn__1304000125_A]()) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_fn__1304000185_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_New()}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_invoke, New: A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_new, Get: A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_get}

var A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$fn__1304000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "fn__1304000185", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_fn__1304000185_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_fn__1304000185_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_fn__1304000185_A]()) }

func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_fn__1304000187_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_invoke, New: A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_new, Get: A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_get}

var A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$fn__1304000187", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "fn__1304000187", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_fn__1304000187_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_fn__1304000187_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_fn__1304000187_A]()) }

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_fname__1304000127_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_New()}; return nil }

func A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_invoke, New: A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_new, Get: A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_get}

var A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$fname__1304000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "fname__1304000127", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_fname__1304000127_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_fname__1304000127_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_fname__1304000127_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_New()}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000135__1304000139", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "iter__1304000135__1304000139", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000135__1304000139$fn__1304000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_A_class, Simple: "fn__1304000140", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000135__1304000139$fn__1304000140$fn__1304000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_A_class, Simple: "fn__1304000141", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000135__1304000139_fn__1304000140_fn__1304000141_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000145__1304000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "iter__1304000145__1304000149", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000145__1304000149$fn__1304000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_A_class, Simple: "fn__1304000150", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000145__1304000149$fn__1304000150$fn__1304000151", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_A_class, Simple: "fn__1304000151", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000145__1304000149_fn__1304000150_fn__1304000151_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000155__1304000159", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "iter__1304000155__1304000159", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000155__1304000159$fn__1304000160", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_A_class, Simple: "fn__1304000160", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000155__1304000159$fn__1304000160$fn__1304000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_A_class, Simple: "fn__1304000161", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000155__1304000159_fn__1304000160_fn__1304000161_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_New()}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000165__1304000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "iter__1304000165__1304000169", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000165__1304000169$fn__1304000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_A_class, Simple: "fn__1304000170", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000165__1304000169$fn__1304000170$fn__1304000171", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_A_class, Simple: "fn__1304000171", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000165__1304000169_fn__1304000170_fn__1304000171_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000175__1304000179", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "iter__1304000175__1304000179", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000175__1304000179$fn__1304000180", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_A_class, Simple: "fn__1304000180", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A]()) }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_invoke, New: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_new, Get: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_get}

var A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$iter__1304000175__1304000179$fn__1304000180$fn__1304000181", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_A_class, Simple: "fn__1304000181", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_iter__1304000175__1304000179_fn__1304000180_fn__1304000181_A]()) }

func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_param__1304000131_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_param__1304000131_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_param__1304000131_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_param__1304000131_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_param__1304000131_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_param__1304000131_A_invoke, New: A_arbace_classes_lower_deftype_class_form_param__1304000131_A_new, Get: A_arbace_classes_lower_deftype_class_form_param__1304000131_A_get}

var A_arbace_classes_lower_deftype_class_form_param__1304000131_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$param__1304000131", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "param__1304000131", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_param__1304000131_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_param__1304000131_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_param__1304000131_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_param__1304000131_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_param__1304000131_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_param__1304000131_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_param__1304000131_A]()) }

func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_New()}; return nil }

func A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_fn_class)}; return nil }

var A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_invoke, New: A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_new, Get: A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_get}

var A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$deftype_class_form$ptag__1304000129", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_deftype_class_form_A_class, Simple: "ptag__1304000129", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_class.Info(); i.IsInstance = A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_InstanceOf; i.Init = A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_Init; i.Table = A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_members; jrt.RegisterGoType(A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A_class, reflect.TypeFor[A_arbace_classes_lower_deftype_class_form_ptag__1304000129_A]()) }

func A_arbace_classes_lower_eval1304000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_eval1304000004_A_New()}; return nil }

var A_arbace_classes_lower_eval1304000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_lower_eval1304000004_A_new}

var A_arbace_classes_lower_eval1304000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$eval1304000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_lower_A_class, Simple: "eval1304000004", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_eval1304000004_A"})

func init() { i := A_arbace_classes_lower_eval1304000004_A_class.Info(); i.IsInstance = A_arbace_classes_lower_eval1304000004_A_InstanceOf; i.Table = A_arbace_classes_lower_eval1304000004_A_members; jrt.RegisterGoType(A_arbace_classes_lower_eval1304000004_A_class, reflect.TypeFor[A_arbace_classes_lower_eval1304000004_A]()) }

func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_New()}; return nil }

func A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_fn_class)}; return nil }

var A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_invoke, New: A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_new, Get: A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_get}

var A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$eval1304000004$loading__1927001464__auto____1304000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_eval1304000004_A_class, Simple: "loading__1927001464__auto____1304000005", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_class.Info(); i.IsInstance = A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_InstanceOf; i.Init = A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_Init; i.Table = A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_members; jrt.RegisterGoType(A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A_class, reflect.TypeFor[A_arbace_classes_lower_eval1304000004_loading__1927001464__auto____1304000005_A]()) }

func A_arbace_classes_lower_eval1304000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_eval1304000008_A_New()}; return nil }

var A_arbace_classes_lower_eval1304000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_lower_eval1304000008_A_new}

var A_arbace_classes_lower_eval1304000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$eval1304000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_lower_A_class, Simple: "eval1304000008", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_eval1304000008_A"})

func init() { i := A_arbace_classes_lower_eval1304000008_A_class.Info(); i.IsInstance = A_arbace_classes_lower_eval1304000008_A_InstanceOf; i.Table = A_arbace_classes_lower_eval1304000008_A_members; jrt.RegisterGoType(A_arbace_classes_lower_eval1304000008_A_class, reflect.TypeFor[A_arbace_classes_lower_eval1304000008_A]()) }

func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_eval1304000008_fn__1304000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_eval1304000008_fn__1304000009_A_New()}; return nil }

func A_arbace_classes_lower_eval1304000008_fn__1304000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_eval1304000008_fn__1304000009_A_fn_class)}; return nil }

var A_arbace_classes_lower_eval1304000008_fn__1304000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_eval1304000008_fn__1304000009_A_invoke, New: A_arbace_classes_lower_eval1304000008_fn__1304000009_A_new, Get: A_arbace_classes_lower_eval1304000008_fn__1304000009_A_get}

var A_arbace_classes_lower_eval1304000008_fn__1304000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$eval1304000008$fn__1304000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_eval1304000008_A_class, Simple: "fn__1304000009", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_eval1304000008_fn__1304000009_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_eval1304000008_fn__1304000009_A_class.Info(); i.IsInstance = A_arbace_classes_lower_eval1304000008_fn__1304000009_A_InstanceOf; i.Init = A_arbace_classes_lower_eval1304000008_fn__1304000009_A_Init; i.Table = A_arbace_classes_lower_eval1304000008_fn__1304000009_A_members; jrt.RegisterGoType(A_arbace_classes_lower_eval1304000008_fn__1304000009_A_class, reflect.TypeFor[A_arbace_classes_lower_eval1304000008_fn__1304000009_A]()) }

func A_arbace_classes_lower_fn_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_meta_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_fn_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_meta_A_New()}; return nil }

func A_arbace_classes_lower_fn_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_meta_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_meta_A_invoke, New: A_arbace_classes_lower_fn_meta_A_new, Get: A_arbace_classes_lower_fn_meta_A_get}

var A_arbace_classes_lower_fn_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "fn_meta", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_meta_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_meta_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_meta_A_Init; i.Table = A_arbace_classes_lower_fn_meta_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_meta_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_meta_A]()) }

func A_arbace_classes_lower_fn_methods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_lower_fn_methods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_A_New()}; return nil }

func A_arbace_classes_lower_fn_methods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_A_invoke, New: A_arbace_classes_lower_fn_methods_A_new, Get: A_arbace_classes_lower_fn_methods_A_get}

var A_arbace_classes_lower_fn_methods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "fn_methods", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_A_Init; i.Table = A_arbace_classes_lower_fn_methods_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_A]()) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_fn__1304000060_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_fn__1304000060_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_fn__1304000060_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_fn__1304000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_fn__1304000060_A_invoke, New: A_arbace_classes_lower_fn_methods_fn__1304000060_A_new, Get: A_arbace_classes_lower_fn_methods_fn__1304000060_A_get}

var A_arbace_classes_lower_fn_methods_fn__1304000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods$fn__1304000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_fn_methods_A_class, Simple: "fn__1304000060", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_fn__1304000060_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_fn__1304000060_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_fn__1304000060_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_fn__1304000060_A_Init; i.Table = A_arbace_classes_lower_fn_methods_fn__1304000060_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_fn__1304000060_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_fn__1304000060_A]()) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_New()}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_invoke, New: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_new, Get: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_get}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_fn_methods_fn__1304000060_A_class, Simple: "fn__1304000070", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_Init; i.Table = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000070_A]()) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_New()}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_invoke, New: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_new, Get: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_get}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_fn_methods_fn__1304000060_A_class, Simple: "fn__1304000072", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_Init; i.Table = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000072_A]()) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_invoke, New: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_new, Get: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_get}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_fn_methods_fn__1304000060_A_class, Simple: "fn__1304000074", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_Init; i.Table = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000074_A]()) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_New()}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_invoke, New: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_new, Get: A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_get}

var A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods$fn__1304000060$fn__1304000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_fn_methods_fn__1304000060_A_class, Simple: "fn__1304000078", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_Init; i.Table = A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_fn__1304000060_fn__1304000078_A]()) }

func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_New()}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_invoke, New: A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_new, Get: A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_get}

var A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods$fn__1304000060$typed__1304000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_fn_methods_fn__1304000060_A_class, Simple: "typed__1304000076", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_Init; i.Table = A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_fn__1304000060_typed__1304000076_A]()) }

func A_arbace_classes_lower_fn_methods_fn__1304000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_methods_fn__1304000085_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_methods_fn__1304000085_A_New()}; return nil }

func A_arbace_classes_lower_fn_methods_fn__1304000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_methods_fn__1304000085_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_methods_fn__1304000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_methods_fn__1304000085_A_invoke, New: A_arbace_classes_lower_fn_methods_fn__1304000085_A_new, Get: A_arbace_classes_lower_fn_methods_fn__1304000085_A_get}

var A_arbace_classes_lower_fn_methods_fn__1304000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_methods$fn__1304000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_fn_methods_A_class, Simple: "fn__1304000085", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_fn__1304000085_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_methods_fn__1304000085_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_methods_fn__1304000085_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_methods_fn__1304000085_A_Init; i.Table = A_arbace_classes_lower_fn_methods_fn__1304000085_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_methods_fn__1304000085_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_methods_fn__1304000085_A]()) }

func A_arbace_classes_lower_fn_parts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_parts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_fn_parts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_parts_A_New()}; return nil }

func A_arbace_classes_lower_fn_parts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_parts_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_parts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_parts_A_invoke, New: A_arbace_classes_lower_fn_parts_A_new, Get: A_arbace_classes_lower_fn_parts_A_get}

var A_arbace_classes_lower_fn_parts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_parts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "fn_parts", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_parts_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_parts_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_parts_A_Init; i.Table = A_arbace_classes_lower_fn_parts_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_parts_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_parts_A]()) }

func A_arbace_classes_lower_fn_parts_fn__1304000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_fn_parts_fn__1304000025_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_fn_parts_fn__1304000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_fn_parts_fn__1304000025_A_New()}; return nil }

func A_arbace_classes_lower_fn_parts_fn__1304000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_fn_parts_fn__1304000025_A_fn_class)}; return nil }

var A_arbace_classes_lower_fn_parts_fn__1304000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_fn_parts_fn__1304000025_A_invoke, New: A_arbace_classes_lower_fn_parts_fn__1304000025_A_new, Get: A_arbace_classes_lower_fn_parts_fn__1304000025_A_get}

var A_arbace_classes_lower_fn_parts_fn__1304000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$fn_parts$fn__1304000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_fn_parts_A_class, Simple: "fn__1304000025", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_fn__1304000025_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_fn_parts_fn__1304000025_A_class.Info(); i.IsInstance = A_arbace_classes_lower_fn_parts_fn__1304000025_A_InstanceOf; i.Init = A_arbace_classes_lower_fn_parts_fn__1304000025_A_Init; i.Table = A_arbace_classes_lower_fn_parts_fn__1304000025_A_members; jrt.RegisterGoType(A_arbace_classes_lower_fn_parts_fn__1304000025_A_class, reflect.TypeFor[A_arbace_classes_lower_fn_parts_fn__1304000025_A]()) }

func A_arbace_classes_lower_gsym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_gsym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_gsym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_gsym_A_New()}; return nil }

func A_arbace_classes_lower_gsym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_gsym_A_fn_class)}; return nil }

var A_arbace_classes_lower_gsym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_gsym_A_invoke, New: A_arbace_classes_lower_gsym_A_new, Get: A_arbace_classes_lower_gsym_A_get}

var A_arbace_classes_lower_gsym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$gsym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "gsym", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_gsym_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_gsym_A_class.Info(); i.IsInstance = A_arbace_classes_lower_gsym_A_InstanceOf; i.Init = A_arbace_classes_lower_gsym_A_Init; i.Table = A_arbace_classes_lower_gsym_A_members; jrt.RegisterGoType(A_arbace_classes_lower_gsym_A_class, reflect.TypeFor[A_arbace_classes_lower_gsym_A]()) }

func A_arbace_classes_lower_lower_case_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_case_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_lower_case_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_case_A_New()}; return nil }

func A_arbace_classes_lower_lower_case_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_case_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_case_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_case_A_invoke, New: A_arbace_classes_lower_lower_case_A_new, Get: A_arbace_classes_lower_lower_case_A_get}

var A_arbace_classes_lower_lower_case_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_case", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "lower_case", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_case_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_case_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_case_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_case_A_Init; i.Table = A_arbace_classes_lower_lower_case_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_case_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_case_A]()) }

func A_arbace_classes_lower_lower_case_fn__1304000248_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_case_fn__1304000248_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_case_fn__1304000248_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_case_fn__1304000248_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_lower_lower_case_fn__1304000248_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_case_fn__1304000248_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_case_fn__1304000248_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_case_fn__1304000248_A_invoke, New: A_arbace_classes_lower_lower_case_fn__1304000248_A_new, Get: A_arbace_classes_lower_lower_case_fn__1304000248_A_get}

var A_arbace_classes_lower_lower_case_fn__1304000248_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_case$fn__1304000248", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_case_A_class, Simple: "fn__1304000248", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_case_fn__1304000248_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_case_fn__1304000248_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_case_fn__1304000248_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_case_fn__1304000248_A_Init; i.Table = A_arbace_classes_lower_lower_case_fn__1304000248_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_case_fn__1304000248_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_case_fn__1304000248_A]()) }

func A_arbace_classes_lower_lower_case_sm__1304000245_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_case_sm__1304000245_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_case_sm__1304000245_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_case_sm__1304000245_A_New_I_I(args[0].(int32), args[1].(int32))}; return nil }

func A_arbace_classes_lower_lower_case_sm__1304000245_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_case_sm__1304000245_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_case_sm__1304000245_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (II)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_case_sm__1304000245_A_invoke, New: A_arbace_classes_lower_lower_case_sm__1304000245_A_new, Get: A_arbace_classes_lower_lower_case_sm__1304000245_A_get}

var A_arbace_classes_lower_lower_case_sm__1304000245_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_case$sm__1304000245", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_case_A_class, Simple: "sm__1304000245", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_case_sm__1304000245_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_case_sm__1304000245_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_case_sm__1304000245_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_case_sm__1304000245_A_Init; i.Table = A_arbace_classes_lower_lower_case_sm__1304000245_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_case_sm__1304000245_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_case_sm__1304000245_A]()) }

func A_arbace_classes_lower_lower_case_sw__1304000256_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_case_sw__1304000256_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_case_sw__1304000256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_case_sw__1304000256_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_lower_case_sw__1304000256_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_case_sw__1304000256_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_case_sw__1304000256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_case_sw__1304000256_A_invoke, New: A_arbace_classes_lower_lower_case_sw__1304000256_A_new, Get: A_arbace_classes_lower_lower_case_sw__1304000256_A_get}

var A_arbace_classes_lower_lower_case_sw__1304000256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_case$sw__1304000256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_case_A_class, Simple: "sw__1304000256", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_case_sw__1304000256_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_case_sw__1304000256_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_case_sw__1304000256_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_case_sw__1304000256_A_Init; i.Table = A_arbace_classes_lower_lower_case_sw__1304000256_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_case_sw__1304000256_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_case_sw__1304000256_A]()) }

func A_arbace_classes_lower_lower_def_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_def_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_lower_lower_def_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_def_A_New()}; return nil }

func A_arbace_classes_lower_lower_def_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_def_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_def_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_def_A_invoke, New: A_arbace_classes_lower_lower_def_A_new, Get: A_arbace_classes_lower_lower_def_A_get}

var A_arbace_classes_lower_lower_def_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_def", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "lower_def", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_def_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_def_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_def_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_def_A_Init; i.Table = A_arbace_classes_lower_lower_def_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_def_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_def_A]()) }

func A_arbace_classes_lower_lower_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_fn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_fn_A_New()}; return nil }

func A_arbace_classes_lower_lower_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_fn_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_fn_A_invoke, New: A_arbace_classes_lower_lower_fn_A_new, Get: A_arbace_classes_lower_lower_fn_A_get}

var A_arbace_classes_lower_lower_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "lower_fn", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_fn_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_fn_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_fn_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_fn_A_Init; i.Table = A_arbace_classes_lower_lower_fn_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_fn_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_fn_A]()) }

func A_arbace_classes_lower_lower_letfn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_lower_letfn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_A_New()}; return nil }

func A_arbace_classes_lower_lower_letfn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_A_invoke, New: A_arbace_classes_lower_lower_letfn_A_new, Get: A_arbace_classes_lower_lower_letfn_A_get}

var A_arbace_classes_lower_lower_letfn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "lower_letfn", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_A]()) }

func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_fn__1304000196_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_fn__1304000196_A_New()}; return nil }

func A_arbace_classes_lower_lower_letfn_fn__1304000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_fn__1304000196_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_fn__1304000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_fn__1304000196_A_invoke, New: A_arbace_classes_lower_lower_letfn_fn__1304000196_A_new, Get: A_arbace_classes_lower_lower_letfn_fn__1304000196_A_get}

var A_arbace_classes_lower_lower_letfn_fn__1304000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$fn__1304000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_letfn_A_class, Simple: "fn__1304000196", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_fn__1304000196_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_fn__1304000196_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_fn__1304000196_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_fn__1304000196_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_fn__1304000196_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_fn__1304000196_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_fn__1304000196_A]()) }

func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_fn__1304000222_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_fn__1304000222_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_fn__1304000222_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_fn__1304000222_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_fn__1304000222_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_fn__1304000222_A_invoke, New: A_arbace_classes_lower_lower_letfn_fn__1304000222_A_new, Get: A_arbace_classes_lower_lower_letfn_fn__1304000222_A_get}

var A_arbace_classes_lower_lower_letfn_fn__1304000222_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$fn__1304000222", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_letfn_A_class, Simple: "fn__1304000222", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_fn__1304000222_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_fn__1304000222_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_fn__1304000222_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_fn__1304000222_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_fn__1304000222_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_fn__1304000222_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_fn__1304000222_A]()) }

func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_fn__1304000225_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_fn__1304000225_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_fn__1304000225_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_fn__1304000225_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_fn__1304000225_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_fn__1304000225_A_invoke, New: A_arbace_classes_lower_lower_letfn_fn__1304000225_A_new, Get: A_arbace_classes_lower_lower_letfn_fn__1304000225_A_get}

var A_arbace_classes_lower_lower_letfn_fn__1304000225_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$fn__1304000225", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_letfn_A_class, Simple: "fn__1304000225", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_fn__1304000225_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_fn__1304000225_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_fn__1304000225_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_fn__1304000225_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_fn__1304000225_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_fn__1304000225_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_fn__1304000225_A]()) }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_invoke, New: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_new, Get: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_get}

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$iter__1304000230__1304000234", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_letfn_A_class, Simple: "iter__1304000230__1304000234", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A]()) }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_invoke, New: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_new, Get: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_get}

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$iter__1304000230__1304000234$fn__1304000235", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_A_class, Simple: "fn__1304000235", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A]()) }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_invoke, New: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_new, Get: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_get}

var A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$iter__1304000230__1304000234$fn__1304000235$fn__1304000236", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_A_class, Simple: "fn__1304000236", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_iter__1304000230__1304000234_fn__1304000235_fn__1304000236_A]()) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_invoke, New: A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_new, Get: A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_get}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$with_others__1304000198", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_lower_lower_letfn_A_class, Simple: "with_others__1304000198", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_with_others__1304000198_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_with_others__1304000198_A]()) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_invoke, New: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_new, Get: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_get}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_letfn_with_others__1304000198_A_class, Simple: "iter__1304000201__1304000205", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A]()) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_invoke, New: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_new, Get: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_get}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_A_class, Simple: "fn__1304000206", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A]()) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_invoke, New: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_new, Get: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_get}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206$fn__1304000207", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_class, Simple: "fn__1304000207", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A]()) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_invoke, New: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_new, Get: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_get}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206$fn__1304000207$fn__1304000211", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_A_class, Simple: "fn__1304000211", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000207_fn__1304000211_A]()) }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_New_O(args[0])}; return nil }

func A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_invoke, New: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_new, Get: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_get}

var A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_letfn$with_others__1304000198$iter__1304000201__1304000205$fn__1304000206$fn__1304000217", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_A_class, Simple: "fn__1304000217", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_Init; i.Table = A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_letfn_with_others__1304000198_iter__1304000201__1304000205_fn__1304000206_fn__1304000217_A]()) }

func A_arbace_classes_lower_lower_reify_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_lower_reify_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_lower_reify_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_lower_reify_A_New()}; return nil }

func A_arbace_classes_lower_lower_reify_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_lower_reify_A_fn_class)}; return nil }

var A_arbace_classes_lower_lower_reify_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_lower_reify_A_invoke, New: A_arbace_classes_lower_lower_reify_A_new, Get: A_arbace_classes_lower_lower_reify_A_get}

var A_arbace_classes_lower_lower_reify_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$lower_reify", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "lower_reify", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_lower_reify_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_lower_reify_A_class.Info(); i.IsInstance = A_arbace_classes_lower_lower_reify_A_InstanceOf; i.Init = A_arbace_classes_lower_lower_reify_A_Init; i.Table = A_arbace_classes_lower_lower_reify_A_members; jrt.RegisterGoType(A_arbace_classes_lower_lower_reify_A_class, reflect.TypeFor[A_arbace_classes_lower_lower_reify_A]()) }

func A_arbace_classes_lower_prim_interfaces_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_prim_interfaces_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_prim_interfaces_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_prim_interfaces_A_New()}; return nil }

func A_arbace_classes_lower_prim_interfaces_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_prim_interfaces_A_fn_class)}; return nil }

var A_arbace_classes_lower_prim_interfaces_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_prim_interfaces_A_invoke, New: A_arbace_classes_lower_prim_interfaces_A_new, Get: A_arbace_classes_lower_prim_interfaces_A_get}

var A_arbace_classes_lower_prim_interfaces_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$prim_interfaces", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "prim_interfaces", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_prim_interfaces_A_class.Info(); i.IsInstance = A_arbace_classes_lower_prim_interfaces_A_InstanceOf; i.Init = A_arbace_classes_lower_prim_interfaces_A_Init; i.Table = A_arbace_classes_lower_prim_interfaces_A_members; jrt.RegisterGoType(A_arbace_classes_lower_prim_interfaces_A_class, reflect.TypeFor[A_arbace_classes_lower_prim_interfaces_A]()) }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_New()}; return nil }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_fn_class)}; return nil }

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_invoke, New: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_new, Get: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_get}

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$prim_interfaces$iter__1304000046__1304000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_prim_interfaces_A_class, Simple: "iter__1304000046__1304000050", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_class.Info(); i.IsInstance = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_InstanceOf; i.Init = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_Init; i.Table = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_members; jrt.RegisterGoType(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_class, reflect.TypeFor[A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A]()) }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_fn_class)}; return nil }

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_invoke, New: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_new, Get: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_get}

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$prim_interfaces$iter__1304000046__1304000050$fn__1304000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_A_class, Simple: "fn__1304000051", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_class.Info(); i.IsInstance = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_InstanceOf; i.Init = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_Init; i.Table = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_members; jrt.RegisterGoType(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_class, reflect.TypeFor[A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A]()) }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_fn_class)}; return nil }

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_invoke, New: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_new, Get: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_get}

var A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$prim_interfaces$iter__1304000046__1304000050$fn__1304000051$fn__1304000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_A_class, Simple: "fn__1304000052", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_class.Info(); i.IsInstance = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_InstanceOf; i.Init = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_Init; i.Table = A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_members; jrt.RegisterGoType(A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A_class, reflect.TypeFor[A_arbace_classes_lower_prim_interfaces_iter__1304000046__1304000050_fn__1304000051_fn__1304000052_A]()) }

func A_arbace_classes_lower_prim_sig_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_prim_sig_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_prim_sig_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_prim_sig_A_New()}; return nil }

func A_arbace_classes_lower_prim_sig_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_prim_sig_A_fn_class)}; return nil }

var A_arbace_classes_lower_prim_sig_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_prim_sig_A_invoke, New: A_arbace_classes_lower_prim_sig_A_new, Get: A_arbace_classes_lower_prim_sig_A_get}

var A_arbace_classes_lower_prim_sig_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$prim_sig", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "prim_sig", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_prim_sig_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_prim_sig_A_class.Info(); i.IsInstance = A_arbace_classes_lower_prim_sig_A_InstanceOf; i.Init = A_arbace_classes_lower_prim_sig_A_Init; i.Table = A_arbace_classes_lower_prim_sig_A_members; jrt.RegisterGoType(A_arbace_classes_lower_prim_sig_A_class, reflect.TypeFor[A_arbace_classes_lower_prim_sig_A]()) }

func A_arbace_classes_lower_prim_sig_fn__1304000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_prim_sig_fn__1304000043_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_prim_sig_fn__1304000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_prim_sig_fn__1304000043_A_New()}; return nil }

func A_arbace_classes_lower_prim_sig_fn__1304000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_prim_sig_fn__1304000043_A_fn_class)}; return nil }

var A_arbace_classes_lower_prim_sig_fn__1304000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_prim_sig_fn__1304000043_A_invoke, New: A_arbace_classes_lower_prim_sig_fn__1304000043_A_new, Get: A_arbace_classes_lower_prim_sig_fn__1304000043_A_get}

var A_arbace_classes_lower_prim_sig_fn__1304000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$prim_sig$fn__1304000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_prim_sig_A_class, Simple: "fn__1304000043", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_prim_sig_fn__1304000043_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_prim_sig_fn__1304000043_A_class.Info(); i.IsInstance = A_arbace_classes_lower_prim_sig_fn__1304000043_A_InstanceOf; i.Init = A_arbace_classes_lower_prim_sig_fn__1304000043_A_Init; i.Table = A_arbace_classes_lower_prim_sig_fn__1304000043_A_members; jrt.RegisterGoType(A_arbace_classes_lower_prim_sig_fn__1304000043_A_class, reflect.TypeFor[A_arbace_classes_lower_prim_sig_fn__1304000043_A]()) }

func A_arbace_classes_lower_prim_tag_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_prim_tag_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_prim_tag_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_prim_tag_QMARK__A_New()}; return nil }

func A_arbace_classes_lower_prim_tag_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_prim_tag_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_lower_prim_tag_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_prim_tag_QMARK__A_invoke, New: A_arbace_classes_lower_prim_tag_QMARK__A_new, Get: A_arbace_classes_lower_prim_tag_QMARK__A_get}

var A_arbace_classes_lower_prim_tag_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$prim_tag_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "prim_tag_QMARK_", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_prim_tag_QMARK__A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_prim_tag_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_lower_prim_tag_QMARK__A_InstanceOf; i.Init = A_arbace_classes_lower_prim_tag_QMARK__A_Init; i.Table = A_arbace_classes_lower_prim_tag_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_lower_prim_tag_QMARK__A_class, reflect.TypeFor[A_arbace_classes_lower_prim_tag_QMARK__A]()) }

func A_arbace_classes_lower_symbols_in_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_symbols_in_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_symbols_in_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_symbols_in_A_New()}; return nil }

func A_arbace_classes_lower_symbols_in_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_symbols_in_A_fn_class)}; return nil }

var A_arbace_classes_lower_symbols_in_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_symbols_in_A_invoke, New: A_arbace_classes_lower_symbols_in_A_new, Get: A_arbace_classes_lower_symbols_in_A_get}

var A_arbace_classes_lower_symbols_in_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$symbols_in", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "symbols_in", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_symbols_in_A_class.Info(); i.IsInstance = A_arbace_classes_lower_symbols_in_A_InstanceOf; i.Init = A_arbace_classes_lower_symbols_in_A_Init; i.Table = A_arbace_classes_lower_symbols_in_A_members; jrt.RegisterGoType(A_arbace_classes_lower_symbols_in_A_class, reflect.TypeFor[A_arbace_classes_lower_symbols_in_A]()) }

func A_arbace_classes_lower_variadic_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_lower_variadic_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_lower_variadic_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower_variadic_QMARK__A_New()}; return nil }

func A_arbace_classes_lower_variadic_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_lower_variadic_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_lower_variadic_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_lower_variadic_QMARK__A_invoke, New: A_arbace_classes_lower_variadic_QMARK__A_new, Get: A_arbace_classes_lower_variadic_QMARK__A_get}

var A_arbace_classes_lower_variadic_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower$variadic_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_lower_A_class, Simple: "variadic_QMARK_", Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower_variadic_QMARK__A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower_variadic_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_lower_variadic_QMARK__A_InstanceOf; i.Init = A_arbace_classes_lower_variadic_QMARK__A_Init; i.Table = A_arbace_classes_lower_variadic_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_lower_variadic_QMARK__A_class, reflect.TypeFor[A_arbace_classes_lower_variadic_QMARK__A]()) }

func A_arbace_classes_lower__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_lower__init_A_Load__O(); case 1: return A_arbace_classes_lower__init_A_Unit0__O(); case 2: return A_arbace_classes_lower__init_A_Unit1__O(); case 3: return A_arbace_classes_lower__init_A_Unit10__O(); case 4: return A_arbace_classes_lower__init_A_Unit11__O(); case 5: return A_arbace_classes_lower__init_A_Unit12__O(); case 6: return A_arbace_classes_lower__init_A_Unit13__O(); case 7: return A_arbace_classes_lower__init_A_Unit14__O(); case 8: return A_arbace_classes_lower__init_A_Unit15__O(); case 9: return A_arbace_classes_lower__init_A_Unit16__O(); case 10: return A_arbace_classes_lower__init_A_Unit17__O(); case 11: return A_arbace_classes_lower__init_A_Unit18__O(); case 12: return A_arbace_classes_lower__init_A_Unit19__O(); case 13: return A_arbace_classes_lower__init_A_Unit2__O(); case 14: return A_arbace_classes_lower__init_A_Unit20__O(); case 15: return A_arbace_classes_lower__init_A_Unit21__O(); case 16: return A_arbace_classes_lower__init_A_Unit22__O(); case 17: return A_arbace_classes_lower__init_A_Unit23__O(); case 18: return A_arbace_classes_lower__init_A_Unit24__O(); case 19: return A_arbace_classes_lower__init_A_Unit25__O(); case 20: return A_arbace_classes_lower__init_A_Unit26__O(); case 21: return A_arbace_classes_lower__init_A_Unit27__O(); case 22: return A_arbace_classes_lower__init_A_Unit3__O(); case 23: return A_arbace_classes_lower__init_A_Unit4__O(); case 24: return A_arbace_classes_lower__init_A_Unit5__O(); case 25: return A_arbace_classes_lower__init_A_Unit6__O(); case 26: return A_arbace_classes_lower__init_A_Unit7__O(); case 27: return A_arbace_classes_lower__init_A_Unit8__O(); case 28: return A_arbace_classes_lower__init_A_Unit9__O()}; return nil }

func A_arbace_classes_lower__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_lower__init_A_New()}; return nil }

var A_arbace_classes_lower__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_lower__init_A_invoke, New: A_arbace_classes_lower__init_A_new}

var A_arbace_classes_lower__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.lower__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_lower.A_arbace_classes_lower__init_A", Source: "lower.ae"})

func init() { i := A_arbace_classes_lower__init_A_class.Info(); i.IsInstance = A_arbace_classes_lower__init_A_InstanceOf; i.Init = A_arbace_classes_lower__init_A_Init; i.Table = A_arbace_classes_lower__init_A_members; jrt.RegisterGoType(A_arbace_classes_lower__init_A_class, reflect.TypeFor[A_arbace_classes_lower__init_A]()) }
