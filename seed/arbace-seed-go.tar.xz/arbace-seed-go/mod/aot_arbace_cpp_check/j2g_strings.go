//line j2g_strings.ae:1
package aot_arbace_cpp_check

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.corekn3,dockn4,elsekn7,subjectkn9,referencekn4,leftkn7,differskn6,passeskn10,not-judgedkn15,oracle-rejectedkn2,irkn13,original-linkkn5,formskn6,objectkn8,loweringkn7,c-checkkn3,gcckn3,runkn4,passkn4,namekn7,outcomekn2,rtkn3,objkn5,lowerkn2,cikn10,ci-messagekn3,gxxkn11,orig-statuskn10,low-statuskn5,fileskn8,prefixeskn3,cx6kn5,matchkn2,idkn17,uncaught-cleanupskn21,native-callback-throwkn5,knownkn7,failingkn8,outcomeskn7,objectskn7,c-levelkn11,regressionskn13,recorded-listkn16,recorded-missingkn13,known-classeskn5,levelkn5,nameskn4,unitkn5,routekn5,unitskn6,routeskn9,libsupc++kn12,libstdc++expkn6,statuskn7,timeoutkn6,differkn2,o2kn6,stdoutkn6,stderrkn4,failkn4,selfkn5,judgeys12,arbace.c.run21,subset-record-refusalys12,arbace.c.run14,compare-recordys12,arbace.c.run13,report-recordyn12,arbace.c.runkn5,titlev11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.cpp.checkm2,R4,s479,The judges of bin/cppi (doc/cpp/LLVM.md §9, §10; doc/cpp/CPP-SURVEY.md, \"As built: CX6 (write-ahead)\", \"As built: CX7\n  (write-ahead)\", \"As built: review 007's fixes\"): `judge`, lower-check's verdict on each file of a list from the levels its\n  steps left in WORK, against the known file and the recorded results; `runtime-judge`, runtime-build's on each unit. Apart\n  from arbace.cpp.lower since review 007, so that a change of a judge does not change the lowered runtime's key.v13,arbace.string4,trimv11,arbace.core5,slurpv11,arbace.core7,re-findp50,(?m)^[^\\s:][^:\\n]*:[0-9]+:[0-9]+: (fatal )?error: v16,arbace.cpp.check6,slurp?v11,arbace.core10,re-matchesp6,[0-9]+v11,arbace.core4,not=l124,v11,arbace.core3,notv16,arbace.cpp.check11,same-bytes?R5,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR6,R7,v11,arbace.core3,setR8,v16,arbace.cpp.check11,run-verdictR9,R10,R11,v13,arbace.string5,splitp2,\\tv16,arbace.cpp.check17,oracle-rejection?R12,R13,R14,R15,v11,arbace.core9,contains?S2,s4,sames7,skippedR16,R17,R18,S2,s1,0s7,skippedR19,S3,s7,no-mains4,sames7,skippedR20,R21,R22,R23,R24,R25,R26,p2,\\tR27,R28,R29,R30,R31,v11,arbace.core11,read-stringR32,R33,v11,arbace.core4,intov11,arbace.core6,filterv11,arbace.core4,map?v11,arbace.core7,number?R34,v11,arbace.core4,somev13,arbace.string12,starts-with?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core4,keysp2,\\tv11,arbace.core6,empty?v11,arbace.core4,mapvv16,arbace.cpp.check11,file-resultv11,arbace.core7,keywordv11,arbace.core3,vecv11,arbace.core4,sortv11,arbace.core6,removeR35,R36,R37,S2,s14,stderr-differss7,differsR38,S2,s14,stderr-differss7,differsv11,arbace.core4,nameR39,R40,v13,arbace.string4,joinv11,arbace.core10,sorted-mapv11,arbace.core11,frequenciesv11,arbace.core3,mapR41,R42,R43,R44,R45,R46,R47,v11,arbace.core4,keepv11,arbace.core5,true?v11,arbace.core5,doallv16,arbace.cpp.check14,control-resultS2,R10,R11,v11,arbace.core7,printlnS2,R10,R11,R48,v13,arbace.string11,split-linesv11,arbace.core4,compv11,arbace.core4,spitv11,arbace.core6,pr-strv11,arbace.core4,takel8,v16,arbace.cpp.check5,judgev11,arbace.core10,sorted-setp57,^define (?!internal |private )[^@]*@(\\\"[^\\\"]+\\\"|[^ (]+)\\(p55,^@(\\\"[^\\\"]+\\\"|[^ ]+) = (?!external |private |internal )v13,arbace.string7,replacev11,arbace.core6,secondp7,^\\\"|\\\"$p2,\\tp2,\\tv16,arbace.cpp.check13,defined-namesS2,s4,sames7,skippedS2,s1,0s7,skippedR49,R50,R51,p2,\\tS2,s4,sames7,skippedS2,s1,0s7,skippedR52,R53,R54,R55,p2,\\tl-1,v13,arbace.string6,blank?v11,arbace.core4,readv11,arbace.core3,strp1, v11,arbace.core6,mapcatv11,arbace.core4,subsl7,p1,,p18,fault: .* in (\\S+)v13,arbace.string10,ends-with?R56,R57,R58,R59,p48,^(ci(run|aot): internal|fatal error: |runtime: )R60,R61,R62,v11,arbace.core8,keyword?R63,R64,p6,[\\t\\n]p5,errorp18,^\\S*/gcc-15\\.2\\.0/S1,s8,--recordv11,arbace.core10,drop-whilev11,arbace.core6,subvecl0,S2,s0,s8,--recordv11,arbace.core7,resolveR65,v11,arbace.core4,juxtv11,arbace.core8,identityv16,arbace.cpp.check14,read-all-formsv16,arbace.cpp.check3,tsvv16,arbace.cpp.check6,ir-rowv16,arbace.cpp.check10,run-resultv11,arbace.core6,concatR66,v11,arbace.core6,updatev11,arbace.core7,filtervp1,/S2,R10,R11,S2,R10,R11,R67,R68,V2,TTV2,FFV2,TFV2,FTv11,arbace.core7,sort-byp7,[0-9.]+v11,arbace.core3,keyv11,arbace.core6,formatv11,arbace.core1,-v11,arbace.core3,vall40,v11,arbace.core8,group-byR69,v16,arbace.cpp.check13,runtime-judgev16,arbace.cpp.check9,run-judgev16,arbace.cpp.check11,divergences")

var Lit_1 *jrt.String = jrt.Intern("runtime-judge")

var Lit_2 *jrt.String = jrt.Intern("run-judge")

var Lit_3 *jrt.String = jrt.Intern("judge")

var Lit_4 *jrt.String = jrt.Intern("divergences")

var Lit_5 *jrt.String = jrt.Intern("eval")

var Lit_6 *jrt.String = jrt.Intern("cppi check: judge or runtime-judge")

var Lit_7 *jrt.String = jrt.Intern("/files/")

var Lit_8 *jrt.String = jrt.Intern("/")

var Lit_9 *jrt.String = jrt.Intern("differs")

var Lit_10 *jrt.String = jrt.Intern("stderr-differs")

var Lit_11 *jrt.String = jrt.Intern("same")

var Lit_12 *jrt.String = jrt.Intern("no-original")

var Lit_13 *jrt.String = jrt.Intern("arbace.cpp.check$defined_names$iter__1316000139__1316000143")

var Lit_14 *jrt.String = jrt.Intern("arbace.cpp.check$defined_names$iter__1316000139__1316000143$fn__1316000144")

var Lit_15 *jrt.String = jrt.Intern("arbace.cpp.check$defined_names$iter__1316000139__1316000143$fn__1316000144$fn__1316000145")

var Lit_16 *jrt.String = jrt.Intern("")

var Lit_17 *jrt.String = jrt.Intern(".str")

var Lit_18 *jrt.String = jrt.Intern("llvm.")

var Lit_19 *jrt.String = jrt.Intern("_GLOBAL__sub_I")

var Lit_20 *jrt.String = jrt.Intern("__cxx_global_var_init")

var Lit_21 *jrt.String = jrt.Intern("aot")

var Lit_22 *jrt.String = jrt.Intern("test/cpp/check")

var Lit_23 *jrt.String = jrt.Intern("-linux-amd64.edn")

var Lit_24 *jrt.String = jrt.Intern("-aot")

var Lit_25 *jrt.String = jrt.Intern("-every-")

var Lit_26 *jrt.String = jrt.Intern("test/cpp/divergences-aot.edn")

var Lit_27 *jrt.String = jrt.Intern("test/cpp/divergences.edn")

var Lit_28 *jrt.String = jrt.Intern("arbace.cpp.check$divergences$klass__1316000424")

var Lit_29 *jrt.String = jrt.Intern("arbace.cpp.check$divergences$fn__1316000433")

var Lit_30 *jrt.String = jrt.Intern("programs,")

var Lit_31 *jrt.String = jrt.Intern("pass")

var Lit_32 *jrt.String = jrt.Intern("  %-24s %5d  %s")

var Lit_33 *jrt.String = jrt.Intern("UNCLASSED")

var Lit_34 *jrt.String = jrt.Intern(" ")

var Lit_35 *jrt.String = jrt.Intern("arbace.cpp.check$divergences$klass__1316000424$fn__1316000428")

var Lit_36 *jrt.String = jrt.Intern("arbace.cpp.check$divergences$klass__1316000424$fn__1316000428$fn__1316000429")

var Lit_37 *jrt.String = jrt.Intern("arbace.cpp.check$file_result$st__1316000026")

var Lit_38 *jrt.String = jrt.Intern("ir.status")

var Lit_39 *jrt.String = jrt.Intern("rt.status")

var Lit_40 *jrt.String = jrt.Intern("object")

var Lit_41 *jrt.String = jrt.Intern("none")

var Lit_42 *jrt.String = jrt.Intern("lower.refused")

var Lit_43 *jrt.String = jrt.Intern("gcc.status")

var Lit_44 *jrt.String = jrt.Intern("ci-check.status")

var Lit_45 *jrt.String = jrt.Intern("orig.status")

var Lit_46 *jrt.String = jrt.Intern("low.status")

var Lit_47 *jrt.String = jrt.Intern("gxx.status")

var Lit_48 *jrt.String = jrt.Intern("orig.out")

var Lit_49 *jrt.String = jrt.Intern("gxx.out")

var Lit_50 *jrt.String = jrt.Intern("agrees")

var Lit_51 *jrt.String = jrt.Intern("1")

var Lit_52 *jrt.String = jrt.Intern("no-main")

var Lit_53 *jrt.String = jrt.Intern("skipped")

var Lit_54 *jrt.String = jrt.Intern("0")

var Lit_55 *jrt.String = jrt.Intern("ir.log")

var Lit_56 *jrt.String = jrt.Intern("orig-link.status")

var Lit_57 *jrt.String = jrt.Intern("ok")

var Lit_58 *jrt.String = jrt.Intern("-")

var Lit_59 *jrt.String = jrt.Intern("ci-check.log")

var Lit_60 *jrt.String = jrt.Intern("gen.refused")

var Lit_61 *jrt.String = jrt.Intern("arbace.cpp.check$ir_row$first_error__1316000230")

var Lit_62 *jrt.String = jrt.Intern("ours-refused")

var Lit_63 *jrt.String = jrt.Intern("; clang rejects it too: ")

var Lit_64 *jrt.String = jrt.Intern("oracle-rejected")

var Lit_65 *jrt.String = jrt.Intern("ir-error")

var Lit_66 *jrt.String = jrt.Intern("status ")

var Lit_67 *jrt.String = jrt.Intern("arbace.cpp.check$ir_row$first_error__1316000230$fn__1316000231")

var Lit_68 *jrt.String = jrt.Intern("arbace.cpp.check$judge$fn__1316000040")

var Lit_69 *jrt.String = jrt.Intern("arbace.cpp.check$judge$claimed_QMARK___1316000045")

var Lit_70 *jrt.String = jrt.Intern("arbace.cpp.check$judge$group_of__1316000055")

var Lit_71 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000071__1316000075")

var Lit_72 *jrt.String = jrt.Intern("/list.tsv")

var Lit_73 *jrt.String = jrt.Intern("lower-check: the list has no file")

var Lit_74 *jrt.String = jrt.Intern("arbace.cpp.check$judge$fn__1316000081")

var Lit_75 *jrt.String = jrt.Intern("/list.key")

var Lit_76 *jrt.String = jrt.Intern("auto")

var Lit_77 *jrt.String = jrt.Intern("lower-check: no recorded list ")

var Lit_78 *jrt.String = jrt.Intern("arbace.cpp.check$judge$regression_QMARK___1316000083")

var Lit_79 *jrt.String = jrt.Intern("/divergences.edn")

var Lit_80 *jrt.String = jrt.Intern("arbace.cpp.check$judge$c_class__1316000085")

var Lit_81 *jrt.String = jrt.Intern("arbace.cpp.check$judge$fits_QMARK___1316000091")

var Lit_82 *jrt.String = jrt.Intern("arbace.cpp.check$judge$status__1316000094")

var Lit_83 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000096__1316000100")

var Lit_84 *jrt.String = jrt.Intern("arbace.cpp.check$judge$cnt__1316000106")

var Lit_85 *jrt.String = jrt.Intern("arbace.cpp.check$judge$by__1316000110")

var Lit_86 *jrt.String = jrt.Intern("arbace.cpp.check$judge$fn__1316000112")

var Lit_87 *jrt.String = jrt.Intern("arbace.cpp.check$judge$fn__1316000114")

var Lit_88 *jrt.String = jrt.Intern("arbace.cpp.check$judge$fn__1316000116")

var Lit_89 *jrt.String = jrt.Intern("/results.tsv")

var Lit_90 *jrt.String = jrt.Intern("name\tstatus\toutcome\tforms\tobject\tlowering\tgcc\trun\tgxx\torig\tlow\tclass\tc\n")

var Lit_91 *jrt.String = jrt.Intern("\n")

var Lit_92 *jrt.String = jrt.Intern("/summary.edn")

var Lit_93 *jrt.String = jrt.Intern("  failing:")

var Lit_94 *jrt.String = jrt.Intern(": ")

var Lit_95 *jrt.String = jrt.Intern("(recorded :pass)")

var Lit_96 *jrt.String = jrt.Intern("(known as ")

var Lit_97 *jrt.String = jrt.Intern(")")

var Lit_98 *jrt.String = jrt.Intern("/controls.edn")

var Lit_99 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000122__1316000126")

var Lit_100 *jrt.String = jrt.Intern("arbace.cpp.check$judge$c_class__1316000085$fn__1316000086")

var Lit_101 *jrt.String = jrt.Intern("arbace.cpp.check$judge$c_class__1316000085$fn__1316000086$fn__1316000087")

var Lit_102 *jrt.String = jrt.Intern("arbace.cpp.check$judge$claimed_QMARK___1316000045$fn__1316000047")

var Lit_103 *jrt.String = jrt.Intern("arbace.cpp.check$judge$claimed_QMARK___1316000045$fn__1316000047$fn__1316000051")

var Lit_104 *jrt.String = jrt.Intern("arbace.cpp.check$judge$cnt__1316000106$fn__1316000107")

var Lit_105 *jrt.String = jrt.Intern("arbace.cpp.check$judge$group_of__1316000055$iter__1316000056__1316000060")

var Lit_106 *jrt.String = jrt.Intern("arbace.cpp.check$judge$group_of__1316000055$iter__1316000056__1316000060$fn__1316000061")

var Lit_107 *jrt.String = jrt.Intern("arbace.cpp.check$judge$group_of__1316000055$iter__1316000056__1316000060$fn__1316000061$fn__1316000062")

var Lit_108 *jrt.String = jrt.Intern("arbace.cpp.check$judge$group_of__1316000055$iter__1316000056__1316000060$fn__1316000061$fn__1316000066")

var Lit_109 *jrt.String = jrt.Intern("arbace.cpp.check$judge$group_of__1316000055$iter__1316000056__1316000060$fn__1316000061$fn__1316000062$fn__1316000063")

var Lit_110 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000071__1316000075$fn__1316000076")

var Lit_111 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000071__1316000075$fn__1316000076$fn__1316000077")

var Lit_112 *jrt.String = jrt.Intern("#")

var Lit_113 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000096__1316000100$fn__1316000101")

var Lit_114 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000096__1316000100$fn__1316000101$fn__1316000102")

var Lit_115 *jrt.String = jrt.Intern("\t")

var Lit_116 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000122__1316000126$fn__1316000127")

var Lit_117 *jrt.String = jrt.Intern("arbace.cpp.check$judge$iter__1316000122__1316000126$fn__1316000127$fn__1316000128")

var Lit_118 *jrt.String = jrt.Intern("lower-check: control not judged: ")

var Lit_119 *jrt.String = jrt.Intern(" has no original run")

var Lit_120 *jrt.String = jrt.Intern("/gcc.status")

var Lit_121 *jrt.String = jrt.Intern("lower-check: control ")

var Lit_122 *jrt.String = jrt.Intern(": the lowered run is the oracle tier's (ORS27, cpp-lower-oracle); bin/cppi check's run control judges ci's run")

var Lit_123 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_124 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000250")

var Lit_125 *jrt.String = jrt.Intern("--sample")

var Lit_126 *jrt.String = jrt.Intern("-times-linux-amd64.edn")

var Lit_127 *jrt.String = jrt.Intern("cppi judge:")

var Lit_128 *jrt.String = jrt.Intern("CPPI_RUN_REF")

var Lit_129 *jrt.String = jrt.Intern("test/cpp/ref-gxx15.edn")

var Lit_130 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$klass__1316000253")

var Lit_131 *jrt.String = jrt.Intern("test/cpp/check-known.edn")

var Lit_132 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000262__1316000268")

var Lit_133 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000284__1316000288")

var Lit_134 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000308")

var Lit_135 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000310")

var Lit_136 *jrt.String = jrt.Intern("test/cpp/controls.edn")

var Lit_137 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000312__1316000316")

var Lit_138 *jrt.String = jrt.Intern("/results-")

var Lit_139 *jrt.String = jrt.Intern(".edn")

var Lit_140 *jrt.String = jrt.Intern("[\n")

var Lit_141 *jrt.String = jrt.Intern("\n]\n")

var Lit_142 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000336")

var Lit_143 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000338")

var Lit_144 *jrt.String = jrt.Intern("%-12s %5d programs: %s")

var Lit_145 *jrt.String = jrt.Intern(", ")

var Lit_146 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000341")

var Lit_147 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000346")

var Lit_148 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000348")

var Lit_149 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000351")

var Lit_150 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000356")

var Lit_151 *jrt.String = jrt.Intern("compiled against interpreted (the record):")

var Lit_152 *jrt.String = jrt.Intern("both pass,")

var Lit_153 *jrt.String = jrt.Intern("neither,")

var Lit_154 *jrt.String = jrt.Intern("compiled only,")

var Lit_155 *jrt.String = jrt.Intern("interpreted only")

var Lit_156 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$in_QMARK___1316000358")

var Lit_157 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000363")

var Lit_158 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000368__1316000374")

var Lit_159 *jrt.String = jrt.Intern("AOT check (bin/cppi check --aot")

var Lit_160 *jrt.String = jrt.Intern(" --record): each program of the run corpora compiled by cf2g")

var Lit_161 *jrt.String = jrt.Intern(" --sample ")

var Lit_162 *jrt.String = jrt.Intern("check (bin/cppi check")

var Lit_163 *jrt.String = jrt.Intern(" --record): each program of the run corpora run on ci")

var Lit_164 *jrt.String = jrt.Intern(",\n;; a sampling: every ")

var Lit_165 *jrt.String = jrt.Intern("th program of each corpus's list (bin/lib/cppi/lists.bash), not the whole corpora")

var Lit_166 *jrt.String = jrt.Intern("test/cpp/divergences-aot.edn, then ")

var Lit_167 *jrt.String = jrt.Intern(" --aot")

var Lit_168 *jrt.String = jrt.Intern("BUILD TRANSLATE RUN")

var Lit_169 *jrt.String = jrt.Intern("LOWER BUILD RUN")

var Lit_170 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000394__1316000398")

var Lit_171 *jrt.String = jrt.Intern("recorded")

var Lit_172 *jrt.String = jrt.Intern("and")

var Lit_173 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$fn__1316000410")

var Lit_174 *jrt.String = jrt.Intern("FAIL")

var Lit_175 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$in_QMARK___1316000358$fn__1316000359")

var Lit_176 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000262__1316000268$fn__1316000269")

var Lit_177 *jrt.String = jrt.Intern("/nodes.tsv")

var Lit_178 *jrt.String = jrt.Intern("/run.tsv")

var Lit_179 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000262__1316000268$fn__1316000269$iter__1316000264__1316000270")

var Lit_180 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000262__1316000268$fn__1316000269$iter__1316000264__1316000270$fn__1316000271")

var Lit_181 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000262__1316000268$fn__1316000269$iter__1316000264__1316000270$fn__1316000271$fn__1316000272")

var Lit_182 *jrt.String = jrt.Intern("ir-missing")

var Lit_183 *jrt.String = jrt.Intern("internal: ")

var Lit_184 *jrt.String = jrt.Intern("known ")

var Lit_185 *jrt.String = jrt.Intern(" (")

var Lit_186 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000284__1316000288$fn__1316000289")

var Lit_187 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000284__1316000288$fn__1316000289$fn__1316000290")

var Lit_188 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000284__1316000288$fn__1316000289$fn__1316000302")

var Lit_189 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000284__1316000288$fn__1316000289$fn__1316000290$fn__1316000294")

var Lit_190 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000312__1316000316$fn__1316000317")

var Lit_191 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000312__1316000316$fn__1316000317$fn__1316000318")

var Lit_192 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000312__1316000316$fn__1316000317$fn__1316000327")

var Lit_193 *jrt.String = jrt.Intern("not judged: no g++ run of the reference")

var Lit_194 *jrt.String = jrt.Intern("differs, as a control must (GTS81 (a))")

var Lit_195 *jrt.String = jrt.Intern("left (not in the run, not built or not run)")

var Lit_196 *jrt.String = jrt.Intern("PASSES: the judge passes what differs")

var Lit_197 *jrt.String = jrt.Intern("control ")

var Lit_198 *jrt.String = jrt.Intern(" (test/cpp/controls.edn)")

var Lit_199 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000312__1316000316$fn__1316000317$fn__1316000318$fn__1316000321")

var Lit_200 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000368__1316000374$fn__1316000375")

var Lit_201 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000368__1316000374$fn__1316000375$iter__1316000370__1316000376")

var Lit_202 *jrt.String = jrt.Intern("/times.tsv")

var Lit_203 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000368__1316000374$fn__1316000375$iter__1316000370__1316000376$fn__1316000377")

var Lit_204 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000368__1316000374$fn__1316000375$iter__1316000370__1316000376$fn__1316000377$fn__1316000378")

var Lit_205 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000368__1316000374$fn__1316000375$iter__1316000370__1316000376$fn__1316000377$fn__1316000388")

var Lit_206 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000368__1316000374$fn__1316000375$iter__1316000370__1316000376$fn__1316000377$fn__1316000378$fn__1316000382")

var Lit_207 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000394__1316000398$fn__1316000399")

var Lit_208 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$iter__1316000394__1316000398$fn__1316000399$fn__1316000400")

var Lit_209 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$klass__1316000253$fn__1316000257")

var Lit_210 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge$klass__1316000253$fn__1316000257$fn__1316000258")

var Lit_211 *jrt.String = jrt.Intern("long-double")

var Lit_212 *jrt.String = jrt.Intern(" uses-long-double")

var Lit_213 *jrt.String = jrt.Intern("arbace.cpp.check$run_result$fn__1316000213")

var Lit_214 *jrt.String = jrt.Intern("arbace.cpp.check$run_result$fn__1316000215")

var Lit_215 *jrt.String = jrt.Intern("arbace.cpp.check$run_result$va_fault_QMARK___1316000217")

var Lit_216 *jrt.String = jrt.Intern("arbace.cpp.check$run_result$with_ld__1316000222")

var Lit_217 *jrt.String = jrt.Intern("no g++ run recorded (bin/cppi record-ref)")

var Lit_218 *jrt.String = jrt.Intern("not built")

var Lit_219 *jrt.String = jrt.Intern("not run")

var Lit_220 *jrt.String = jrt.Intern("timeout")

var Lit_221 *jrt.String = jrt.Intern("differ status ")

var Lit_222 *jrt.String = jrt.Intern(" (its own verdict ")

var Lit_223 *jrt.String = jrt.Intern(" (g++ ")

var Lit_224 *jrt.String = jrt.Intern("differ stdout")

var Lit_225 *jrt.String = jrt.Intern("differ stderr")

var Lit_226 *jrt.String = jrt.Intern(" uses-va-arg")

var Lit_227 *jrt.String = jrt.Intern("va-arg=")

var Lit_228 *jrt.String = jrt.Intern("arbace.cpp.check$run_verdict$comparable_QMARK___1316000017")

var Lit_229 *jrt.String = jrt.Intern("orig.err")

var Lit_230 *jrt.String = jrt.Intern("low.out")

var Lit_231 *jrt.String = jrt.Intern("low.err")

var Lit_232 *jrt.String = jrt.Intern("not-comparable")

var Lit_233 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000154__1316000158")

var Lit_234 *jrt.String = jrt.Intern("/units.tsv")

var Lit_235 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000164__1316000168")

var Lit_236 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$by__1316000180")

var Lit_237 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$fn__1316000182")

var Lit_238 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$fn__1316000184")

var Lit_239 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$fn__1316000186")

var Lit_240 *jrt.String = jrt.Intern("unit\toutcome\tir\tforms\tobject\tlowering\tgcc\troute\tnames\n")

var Lit_241 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000188__1316000192")

var Lit_242 *jrt.String = jrt.Intern("runtime-build: ")

var Lit_243 *jrt.String = jrt.Intern(" units, ")

var Lit_244 *jrt.String = jrt.Intern(" pass")

var Lit_245 *jrt.String = jrt.Intern("ours")

var Lit_246 *jrt.String = jrt.Intern(" by our route")

var Lit_247 *jrt.String = jrt.Intern("libsupc++/")

var Lit_248 *jrt.String = jrt.Intern("exp/")

var Lit_249 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000154__1316000158$fn__1316000159")

var Lit_250 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000154__1316000158$fn__1316000159$fn__1316000160")

var Lit_251 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000164__1316000168$fn__1316000169")

var Lit_252 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000164__1316000168$fn__1316000169$fn__1316000170")

var Lit_253 *jrt.String = jrt.Intern("/units/")

var Lit_254 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000164__1316000168$fn__1316000169$st__1316000175")

var Lit_255 *jrt.String = jrt.Intern("route")

var Lit_256 *jrt.String = jrt.Intern("clang")

var Lit_257 *jrt.String = jrt.Intern("clang.ll")

var Lit_258 *jrt.String = jrt.Intern("x.ll")

var Lit_259 *jrt.String = jrt.Intern("names.txt")

var Lit_260 *jrt.String = jrt.Intern("missing\t")

var Lit_261 *jrt.String = jrt.Intern("\nmore\t")

var Lit_262 *jrt.String = jrt.Intern(" missing, ")

var Lit_263 *jrt.String = jrt.Intern(" more")

var Lit_264 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000164__1316000168$fn__1316000169$fn__1316000170$st__1316000171")

var Lit_265 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000188__1316000192$fn__1316000193")

var Lit_266 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge$iter__1316000188__1316000192$fn__1316000193$fn__1316000194")

var Lit_267 *jrt.String = jrt.Intern("arbace.cpp.check$tsv$fn__1316000204")

var Lit_268 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringkn4,linekn6,columnkn4,fileyn6,statusyn5,nameskn4,keysyn7,subjectyn9,referenceyn2,idyn3,refyn4,nodeyn3,runyn4,workyn5,levelyn1,&yn4,moreyn1,nyn4,verbyn4,argsv11,arbace.core5,in-nsMyn16,arbace.cpp.checkm2,R0,s479,The judges of bin/cppi (doc/cpp/LLVM.md §9, §10; doc/cpp/CPP-SURVEY.md, \"As built: CX6 (write-ahead)\", \"As built: CX7\n  (write-ahead)\", \"As built: review 007's fixes\"): `judge`, lower-check's verdict on each file of a list from the levels its\n  steps left in WORK, against the known file and the recorded results; `runtime-judge`, runtime-build's on each unit. Apart\n  from arbace.cpp.lower since review 007, so that a change of a judge does not change the lowered runtime's key.m2,R0,s479,The judges of bin/cppi (doc/cpp/LLVM.md §9, §10; doc/cpp/CPP-SURVEY.md, \"As built: CX6 (write-ahead)\", \"As built: CX7\n  (write-ahead)\", \"As built: review 007's fixes\"): `judge`, lower-check's verdict on each file of a list from the levels its\n  steps left in WORK, against the known file and the recorded results; `runtime-judge`, runtime-build's on each unit. Apart\n  from arbace.cpp.lower since review 007, so that a change of a judge does not change the lowered runtime's key.R1,v11,arbace.core20,*warn-on-reflection*v16,arbace.cpp.check6,slurp?m10,R2,TR3,L1,V1,Myn1,pm2,R4,R5,R6,i10,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check11,same-bytes?m10,R2,TR3,L1,V2,Myn1,am2,R4,R5,Myn1,bm2,R4,R5,R6,i11,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check17,oracle-rejection?m10,R3,L1,V2,R9,Myn3,logm2,R4,R5,R0,s396,Whether a compile's status and log are clang rejecting the source (review 007's finding 2): status 1 and one of clang's\n  own diagnostics (`FILE:LINE:COL: error:` or `fatal error:`) in the log. Any other failure (a timeout of ours, 124; a tool\n  missing, 126 or 127; a signal, 128 and up; a missing file or another driver error, `clang++: error: ...`) is not the\n  oracle's verdict on the source.R6,i16,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check11,run-verdictm10,R3,L1,V2,Myn2,odm2,R4,R5,Myn2,ldm2,R4,R5,R0,s273,The lowered run (LD's low.status, low.out, low.err) against the original's (OD's orig.*): no-original, none, not-comparable,\n  differs, stderr-differs or same. OD and LD are a file's directory (with its trailing /), the same one but for the negative\n  controls (GTS81 (a)).R6,i24,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check14,control-resultm10,R3,L1,V3,Myn4,workm2,R4,R5,R10,m2,R11,V2,R12,R13,R0,s242,A control judged: :differs, :passes (the run's comparison passes what differs), :not-judged (the reference in the run with\n  no original run), :left (the subject or the reference not in the run, the subject not run or its run not comparable).R6,i51,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check11,file-resultm10,R3,L1,V2,Myn4,workm2,R4,R5,Myn1,nm2,R4,R5,R0,s303,One file's levels and outcome: {:name :outcome :ir :rt :obj :lower :gcc :run :gxx}; outcome :pass, :oracle-rejected\n  (clang rejects the file with its own diagnostics: not a lowering's case), :ir (the IR was not made for another reason:\n  a failure of the check's), or the first level that did not hold.R6,i64,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check5,judgem10,R3,L3,V2,Myn4,workm2,R4,R5,Myn10,known-pathm2,R4,R5,V3,Myn4,workm2,R4,R5,Myn10,known-pathm2,R4,R5,Myn12,results-pathm2,R4,R5,V4,Myn4,workm2,R4,R5,Myn10,known-pathm2,R4,R5,Myn12,results-pathm2,R4,R5,Myn13,recorded-modem2,R4,R5,R0,s1317,WORK/results.tsv and WORK/summary.edn from the files' levels against the known file (NAME -> class): a non-pass is known\n  when its name is listed, else failing; and against the recorded results (test/cpp/lower-results.edn's :files, NAME ->\n  [status outcome]; review 007's finding 2): a file recorded :pass that does not pass is a regression, failing whatever\n  else holds (an oracle rejection or a known class included). A list with no file is refused.\n\n  A run of a recorded list is held to the whole list (review 018's R4): the record's summaries (:samples, :libstdcxx-every-15th:\n  top-level keys whose map has :files) each own the names of :files that start with one of its `:prefixes` (`{:samples\n  [\"samples/\" \"runtime/\"]}`; the one summary without prefixes owns the rest). RECORDED is a summary's key (\"samples\"): the run\n  is that list; \"none\": no list; else (nil, \"auto\") the list the header line `#list KEY` of the run's list names (WORK/list.key, which\n  bin/cppi lower-check writes from it; no header: no recorded list; a header key without a summary: refused, exit 2 (re-review 032's F6); review 018's CP132 (b), the heuristic\n  of more than half the names gone). A run of a recorded list\n  fails when a name recorded for it is missing from the run, or when the run's count is not the summary's :files.R6,i107,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check13,defined-namesm10,R3,L1,V1,Myn2,llm2,R4,R5,R0,s159,The external names an LLVM IR text defines (functions, variables, aliases; not internal or private ones, string\n  literals, llvm.* or the global constructors).R6,i201,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check13,runtime-judgem10,R3,L1,V1,Myn3,outm2,R4,R5,R0,s467,OUT/results.tsv and OUT/summary.edn of bin/cppi runtime-build: each unit's levels (the oracle's IR, the forms' round trip, the\n  objects, the lowering, gcc); every unit of test/cpp/runtime/units.edn is to pass them all. A unit by our route (CP240 (c),\n  OUT/units/U/route `ours`) has the names level too: the external names its IR defines are those the oracle's IR (clang.ll)\n  defines, none missing and none more (the other units and the programs link against them).R6,i214,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check3,tsvm10,R2,TR3,L1,V1,Myn1,fm2,R4,R5,R6,i252,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check14,read-all-formsm10,R2,TR3,L1,V1,Myn1,fm2,R4,R5,R6,i256,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check10,run-resultm10,R3,L1,V4,R14,R15,R16,R17,R0,s400,A program's result: [id result reason], result :pass, :fail or the build's status (:oracle-rejected, :ir-error,\n  :lower-refused, :read-error, :check-error, :refused, :build-error). node: [id status class message flags secs]; run:\n  [id status stdout-sum bytes fault stderr-sum secs]; ref: g++'s run. The status and stdout and stderr g++'s, or, when g++'s -O0\n  and -O2 runs differ, the status alone.R6,i260,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check6,ir-rowm12,R2,TR3,L1,V2,Myn4,workm2,R4,R5,R14,R0,s531,The build row of a program whose IR the oracle did not make: clang's rejection (its own diagnostics) or another failure.\n  CP263 (a) (the user, 2026-11-08): under CPPI_ROUTE=auto a program our route tried and refused (gen.refused beside, bin/lib/cppi/route.bash)\n  and clang then rejected is our route's gap, `ours-refused` (test/cpp/divergences.edn, deferred), its reason our refusal's; the\n  oracle-rejected class (by design) keeps the programs our route did not try (a program with dg-options under auto, every one under clang).R6,i294,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check9,run-judgem10,R3,L1,V1,V4,R18,R19,R20,R21,R0,s455,run-judge WORK LEVEL [--record] CORPUS...: LEVEL eval (bin/cppi check: WORK/CORPUS/nodes.tsv, run.tsv) or aot (check --aot:\n  the same, and the interpreted record beside); each program's result against g++'s run and the classes (test/cpp/divergences.edn;\n  aot: divergences-aot.edn first), the committed record (arbace.c.run/compare-record), the negative controls (test/cpp/controls.edn,\n  :level :run). --record rewrites the level's record and its times.R6,i309,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check11,divergencesm10,R3,L1,V3,R19,R20,V1,R22,R0,s226,divergences LEVEL [N]: the recorded check's non-passes (test/cpp/check-linux-amd64.edn, aot: check-aot-linux-amd64.edn; with N\n  the sampling's record, check[-aot]-every-N-linux-amd64.edn), each in a class or listed UNCLASSED.R6,i413,R7,i1,R8,s19,arbace/cpp/check.aev16,arbace.cpp.check5,-mainm10,R3,L1,V3,R23,R20,R24,R0,s127,bin/cppi's judges: judge WORK KNOWN [RESULTS], runtime-judge OUT, run-judge WORK LEVEL [--record] CORPUS..., divergences LEVEL.R6,i428,R7,i1,R8,s19,arbace/cpp/check.ae")

var Lit_269 *jrt.String = jrt.Intern("arbace.cpp.check$eval1316000004$loading__1927001464__auto____1316000005")

var Lit_270 *jrt.String = jrt.Intern("arbace.cpp.check$eval1316000008$fn__1316000009")

var Lit_271 *jrt.String = jrt.Intern("arbace.cpp.check$slurp_QMARK_")

var Lit_272 *jrt.String = jrt.Intern("arbace.cpp.check$same_bytes_QMARK_")

var Lit_273 *jrt.String = jrt.Intern("arbace.cpp.check$oracle_rejection_QMARK_")

var Lit_274 *jrt.String = jrt.Intern("arbace.cpp.check$run_verdict")

var Lit_275 *jrt.String = jrt.Intern("arbace.cpp.check$control_result")

var Lit_276 *jrt.String = jrt.Intern("arbace.cpp.check$file_result")

var Lit_277 *jrt.String = jrt.Intern("arbace.cpp.check$judge")

var Lit_278 *jrt.String = jrt.Intern("arbace.cpp.check$defined_names")

var Lit_279 *jrt.String = jrt.Intern("arbace.cpp.check$runtime_judge")

var Lit_280 *jrt.String = jrt.Intern("arbace.cpp.check$tsv")

var Lit_281 *jrt.String = jrt.Intern("arbace.cpp.check$read_all_forms")

var Lit_282 *jrt.String = jrt.Intern("arbace.cpp.check$run_result")

var Lit_283 *jrt.String = jrt.Intern("arbace.cpp.check$ir_row")

var Lit_284 *jrt.String = jrt.Intern("arbace.cpp.check$run_judge")

var Lit_285 *jrt.String = jrt.Intern("arbace.cpp.check$divergences")

var Lit_286 *jrt.String = jrt.Intern("arbace.cpp.check$_main")
