//line aot_arbace_cpp_check__init.ae:1
package aot_arbace_cpp_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_cpp_check__init_A_Unit0__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_cpp_check__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_check__init_A_const_1) }
//line :1:1
func A_arbace_cpp_check__init_A_Unit1__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_cpp_check__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_2)) }
//line :1:1
func A_arbace_cpp_check__init_A_Unit2__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_check_eval1316000004_loading__1927001464__auto____1316000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_check_eval1316000004_loading__1927001464__auto____1316000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_269, false, nil); A_arbace_cpp_check_eval1316000004_loading__1927001464__auto____1316000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_cpp_check__init_A_Unit3__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_cpp_check__init_A_const_1)).Equals_O__Z(A_arbace_cpp_check__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_check_eval1316000008_fn__1316000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_check_eval1316000008_fn__1316000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_270, false, nil); A_arbace_cpp_check_eval1316000008_fn__1316000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_cpp_check__init_A_Load__O() any { A_arbace_cpp_check__init_A_Init(); jrt.StartCheck(); A_arbace_cpp_check__init_A_Unit0__O(); A_arbace_cpp_check__init_A_Unit1__O(); A_arbace_cpp_check__init_A_Unit2__O(); A_arbace_cpp_check__init_A_Unit3__O(); A_arbace_cpp_check__init_A_Unit4__O(); A_arbace_cpp_check__init_A_Unit5__O(); A_arbace_cpp_check__init_A_Unit6__O(); A_arbace_cpp_check__init_A_Unit7__O(); A_arbace_cpp_check__init_A_Unit8__O(); A_arbace_cpp_check__init_A_Unit9__O(); A_arbace_cpp_check__init_A_Unit10__O(); A_arbace_cpp_check__init_A_Unit11__O(); A_arbace_cpp_check__init_A_Unit12__O(); A_arbace_cpp_check__init_A_Unit13__O(); A_arbace_cpp_check__init_A_Unit14__O(); A_arbace_cpp_check__init_A_Unit15__O(); A_arbace_cpp_check__init_A_Unit16__O(); A_arbace_cpp_check__init_A_Unit17__O(); A_arbace_cpp_check__init_A_Unit18__O(); A_arbace_cpp_check__init_A_Unit19__O(); A_arbace_cpp_check__init_A_Unit20__O(); return nil }


func A_arbace_cpp_check__init_A_Unit4__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(8, 1); return A_arbace_cpp_check__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_cpp_check__init_A_Unit5__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(10, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_5; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_check_slurp_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_check_slurp_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_271, false, nil); A_arbace_cpp_check_slurp_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_6)); return A_arbace_cpp_check__init_A_const_5 }
func A_arbace_cpp_check__init_A_Unit6__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_check_same_bytes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_check_same_bytes_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_272, false, nil); A_arbace_cpp_check_same_bytes_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_8)); return A_arbace_cpp_check__init_A_const_7 }




func A_arbace_cpp_check__init_A_Unit7__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_check_oracle_rejection_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_check_oracle_rejection_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_273, false, nil); A_arbace_cpp_check_oracle_rejection_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_10)); return A_arbace_cpp_check__init_A_const_9 }







func A_arbace_cpp_check__init_A_Unit8__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_check_run_verdict_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_check_run_verdict_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_274, false, nil); A_arbace_cpp_check_run_verdict_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_12)); return A_arbace_cpp_check__init_A_const_11 }


























func A_arbace_cpp_check__init_A_Unit9__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_check_control_result_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_check_control_result_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_275, false, nil); A_arbace_cpp_check_control_result_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_14)); return A_arbace_cpp_check__init_A_const_13 }












func A_arbace_cpp_check__init_A_Unit10__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_check_file_result_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_check_file_result_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_276, false, nil); A_arbace_cpp_check_file_result_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_16)); return A_arbace_cpp_check__init_A_const_15 }










































func A_arbace_cpp_check__init_A_Unit11__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_check_judge_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_check_judge_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_277, false, nil); A_arbace_cpp_check_judge_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_18)); return A_arbace_cpp_check__init_A_const_17 }





























































































func A_arbace_cpp_check__init_A_Unit12__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_check_defined_names_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_check_defined_names_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_278, false, nil); A_arbace_cpp_check_defined_names_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_20)); return A_arbace_cpp_check__init_A_const_19 }












func A_arbace_cpp_check__init_A_Unit13__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_check_runtime_judge_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_check_runtime_judge_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_279, false, nil); A_arbace_cpp_check_runtime_judge_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_22)); return A_arbace_cpp_check__init_A_const_21 }





































func A_arbace_cpp_check__init_A_Unit14__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(252, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_check_tsv_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_check_tsv_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_280, false, nil); A_arbace_cpp_check_tsv_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_24)); return A_arbace_cpp_check__init_A_const_23 }



func A_arbace_cpp_check__init_A_Unit15__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_check_read_all_forms_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_check_read_all_forms_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_281, false, nil); A_arbace_cpp_check_read_all_forms_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_26)); return A_arbace_cpp_check__init_A_const_25 }



func A_arbace_cpp_check__init_A_Unit16__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_check_run_result_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_check_run_result_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_282, false, nil); A_arbace_cpp_check_run_result_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_28)); return A_arbace_cpp_check__init_A_const_27 }

































func A_arbace_cpp_check__init_A_Unit17__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(294, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_check_ir_row_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_check_ir_row_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_283, false, nil); A_arbace_cpp_check_ir_row_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_30)); return A_arbace_cpp_check__init_A_const_29 }














func A_arbace_cpp_check__init_A_Unit18__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(309, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_check_run_judge_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_check_run_judge_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_284, false, nil); A_arbace_cpp_check_run_judge_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_32)); return A_arbace_cpp_check__init_A_const_31 }







































































































func A_arbace_cpp_check__init_A_Unit19__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_33; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__34 any = A_arbace_cpp_check_divergences_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_check_divergences_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_285, true, nil); A_arbace_cpp_check_divergences_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__34, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_34)); return A_arbace_cpp_check__init_A_const_33 }














func A_arbace_cpp_check__init_A_Unit20__O() any { A_arbace_cpp_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(428, 1); var tmp1 *lang.Var = A_arbace_cpp_check__init_A_const_35; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__36 any = A_arbace_cpp_check__main_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_check__main_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_286, true, nil); A_arbace_cpp_check__main_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__36, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_check__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_check__init_A_const_36)); return A_arbace_cpp_check__init_A_const_35 }



type A_arbace_cpp_check__init_A struct{ jrt.Object }

var A_arbace_cpp_check__init_A_const_pool *jrt.RefArray

var A_arbace_cpp_check__init_A_const_0 *lang.Var

var A_arbace_cpp_check__init_A_const_1 any

var A_arbace_cpp_check__init_A_const_2 any

var A_arbace_cpp_check__init_A_const_3 any

var A_arbace_cpp_check__init_A_const_4 *lang.Var

var A_arbace_cpp_check__init_A_const_5 *lang.Var

var A_arbace_cpp_check__init_A_const_6 any

var A_arbace_cpp_check__init_A_const_7 *lang.Var

var A_arbace_cpp_check__init_A_const_8 any

var A_arbace_cpp_check__init_A_const_9 *lang.Var

var A_arbace_cpp_check__init_A_const_10 any

var A_arbace_cpp_check__init_A_const_11 *lang.Var

var A_arbace_cpp_check__init_A_const_12 any

var A_arbace_cpp_check__init_A_const_13 *lang.Var

var A_arbace_cpp_check__init_A_const_14 any

var A_arbace_cpp_check__init_A_const_15 *lang.Var

var A_arbace_cpp_check__init_A_const_16 any

var A_arbace_cpp_check__init_A_const_17 *lang.Var

var A_arbace_cpp_check__init_A_const_18 any

var A_arbace_cpp_check__init_A_const_19 *lang.Var

var A_arbace_cpp_check__init_A_const_20 any

var A_arbace_cpp_check__init_A_const_21 *lang.Var

var A_arbace_cpp_check__init_A_const_22 any

var A_arbace_cpp_check__init_A_const_23 *lang.Var

var A_arbace_cpp_check__init_A_const_24 any

var A_arbace_cpp_check__init_A_const_25 *lang.Var

var A_arbace_cpp_check__init_A_const_26 any

var A_arbace_cpp_check__init_A_const_27 *lang.Var

var A_arbace_cpp_check__init_A_const_28 any

var A_arbace_cpp_check__init_A_const_29 *lang.Var

var A_arbace_cpp_check__init_A_const_30 any

var A_arbace_cpp_check__init_A_const_31 *lang.Var

var A_arbace_cpp_check__init_A_const_32 any

var A_arbace_cpp_check__init_A_const_33 *lang.Var

var A_arbace_cpp_check__init_A_const_34 any

var A_arbace_cpp_check__init_A_const_35 *lang.Var

var A_arbace_cpp_check__init_A_const_36 any

var A_arbace_cpp_check__init_A_init jrt.ClassInit

func A_arbace_cpp_check__init_A_Init() { if !A_arbace_cpp_check__init_A_init.Done() { A_arbace_cpp_check__init_A_init.Run(A_arbace_cpp_check__init_A_clinit) } }

func A_arbace_cpp_check__init_A_clinit() { A_arbace_cpp_check__init_A_clinit_p0(); A_arbace_cpp_check__init_A_clinit_p1(); A_arbace_cpp_check__init_A_clinit_p2() }

func A_arbace_cpp_check__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_check__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_268, 62); A_arbace_cpp_check__init_A_const_0 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[25]); A_arbace_cpp_check__init_A_const_1 = A_arbace_cpp_check__init_A_const_pool.A[26]; A_arbace_cpp_check__init_A_const_2 = A_arbace_cpp_check__init_A_const_pool.A[27]; A_arbace_cpp_check__init_A_const_3 = A_arbace_cpp_check__init_A_const_pool.A[28]; A_arbace_cpp_check__init_A_const_4 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[29]); A_arbace_cpp_check__init_A_const_5 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[30]); A_arbace_cpp_check__init_A_const_6 = A_arbace_cpp_check__init_A_const_pool.A[31]; A_arbace_cpp_check__init_A_const_7 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[32]); A_arbace_cpp_check__init_A_const_8 = A_arbace_cpp_check__init_A_const_pool.A[33]; A_arbace_cpp_check__init_A_const_9 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[34]); A_arbace_cpp_check__init_A_const_10 = A_arbace_cpp_check__init_A_const_pool.A[35]; A_arbace_cpp_check__init_A_const_11 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[36]); A_arbace_cpp_check__init_A_const_12 = A_arbace_cpp_check__init_A_const_pool.A[37] }

func A_arbace_cpp_check__init_A_clinit_p1() { A_arbace_cpp_check__init_A_const_13 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[38]); A_arbace_cpp_check__init_A_const_14 = A_arbace_cpp_check__init_A_const_pool.A[39]; A_arbace_cpp_check__init_A_const_15 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[40]); A_arbace_cpp_check__init_A_const_16 = A_arbace_cpp_check__init_A_const_pool.A[41]; A_arbace_cpp_check__init_A_const_17 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[42]); A_arbace_cpp_check__init_A_const_18 = A_arbace_cpp_check__init_A_const_pool.A[43]; A_arbace_cpp_check__init_A_const_19 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[44]); A_arbace_cpp_check__init_A_const_20 = A_arbace_cpp_check__init_A_const_pool.A[45]; A_arbace_cpp_check__init_A_const_21 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[46]); A_arbace_cpp_check__init_A_const_22 = A_arbace_cpp_check__init_A_const_pool.A[47]; A_arbace_cpp_check__init_A_const_23 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[48]); A_arbace_cpp_check__init_A_const_24 = A_arbace_cpp_check__init_A_const_pool.A[49]; A_arbace_cpp_check__init_A_const_25 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[50]) }

func A_arbace_cpp_check__init_A_clinit_p2() { A_arbace_cpp_check__init_A_const_26 = A_arbace_cpp_check__init_A_const_pool.A[51]; A_arbace_cpp_check__init_A_const_27 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[52]); A_arbace_cpp_check__init_A_const_28 = A_arbace_cpp_check__init_A_const_pool.A[53]; A_arbace_cpp_check__init_A_const_29 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[54]); A_arbace_cpp_check__init_A_const_30 = A_arbace_cpp_check__init_A_const_pool.A[55]; A_arbace_cpp_check__init_A_const_31 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[56]); A_arbace_cpp_check__init_A_const_32 = A_arbace_cpp_check__init_A_const_pool.A[57]; A_arbace_cpp_check__init_A_const_33 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[58]); A_arbace_cpp_check__init_A_const_34 = A_arbace_cpp_check__init_A_const_pool.A[59]; A_arbace_cpp_check__init_A_const_35 = lang.Var_Cast(A_arbace_cpp_check__init_A_const_pool.A[60]); A_arbace_cpp_check__init_A_const_36 = A_arbace_cpp_check__init_A_const_pool.A[61] }

func A_arbace_cpp_check__init_A_New() *A_arbace_cpp_check__init_A { A_arbace_cpp_check__init_A_Init(); t := &A_arbace_cpp_check__init_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_check__init_A) Ctor() {}

func (t *A_arbace_cpp_check__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_check__init_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_check__init_A_class }

func (t *A_arbace_cpp_check__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_check__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_check__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_check__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_check__init_A); return ok }

func A_arbace_cpp_check__init_A_Cast(x any) *A_arbace_cpp_check__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_check__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_check__init_A_class)) }; return v }
