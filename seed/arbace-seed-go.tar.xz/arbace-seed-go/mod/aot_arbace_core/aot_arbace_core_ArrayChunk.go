//line aot_arbace_core_ArrayChunk.ae:1
package aot_arbace_core

import (
	"arbace/jrt"
	"arbace/lang"
)






























func A_arbace_core_ArrayChunk_A_New_O_O_I_I(p0, p1 any, p2, p3 int32) *A_arbace_core_ArrayChunk_A { t := &A_arbace_core_ArrayChunk_A{}; t.Ctor_O_O_I_I(p0, p1, p2, p3); return t }
//line :37:1
func (t *A_arbace_core_ArrayChunk_A) Ctor_O_O_I_I(am, arr any, off, end int32) { t.F_am = am; t.F_arr = arr; t.F_off = off; t.F_end = end }
//line :37:1
func A_arbace_core_ArrayChunk_A_GetBasis__IPersistentVector() lang.IPersistentVector { return lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_675)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_676).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_678).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_679)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_676).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_680).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_681)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_676).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_680).Ref())))) }
//line :37:1
func (t *A_arbace_core_ArrayChunk_A) Reduce_IFn_O__O(f__1 lang.IFn, init__2 any) any { { var ret__3 any = init__2; var i__4 int64 = lang.RT_LongCast_I__J_NoInit(t.F_off); L1: for {














	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, int64(t.F_end)) { var ret__5 any; var tmp1 lang.IFn = f__1; var tmp2 any; var target_1 any = t.F_am; var tmp3 bool; var tmp4 bool
		tmp4 = !(target_1 == nil); if tmp4 { tmp4 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp3 = tmp4; if tmp3 { var tmp5 any = t.F_arr; tmp2 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_20, jrt.RefArrayOf(jrt.Object_class, tmp5, jrt.Long_ValueOf_J__Long_NoInit(i__4).Ref())) } else { var tmp6 A_arbace_core_ArrayManager_A = A_arbace_core_ArrayManager_A_Cast(target_1); var tmp7 any = t.F_arr; tmp2 = tmp6.Aget_O_I__O(tmp7, lang.RT_IntCast_J__I_NoInit(i__4)) }; ret__5 = tmp1.Invoke_O_O__O(ret__3, tmp2)
		if lang.RT_IsReduced_O__Z_NoInit(ret__5) { return ret__5 } else {

			ret__3, i__4 = ret__5, lang.Numbers_Inc_J__J_NoInit(i__4); continue L1 } } else {
//line :52:1
				return ret__3 } } }; /*line :37:1*/panic("j2g: unreachable") }
//line :37:1
func (t *A_arbace_core_ArrayChunk_A) DropFirst__IChunk() lang.IChunk { var tmp1 *A_arbace_core_ArrayChunk_A; if








	lang.Util_Equiv_J_J__Z_NoInit(int64(t.F_off), int64(t.F_end)) { panic(jrt.Thrown(jrt.IllegalStateException_New_String(Lit_682))) } else { var tmp2 any = t.F_am; var tmp3 any = t.F_arr; tmp1 = A_arbace_core_ArrayChunk_A_New_O_O_I_I(tmp2, tmp3, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(t.F_off))), t.F_end) }; return /*line :37:1*/ Up_A_arbace_core_ArrayChunk_A_IChunk(tmp1) }
//line :37:1
func (t *A_arbace_core_ArrayChunk_A) Count__I() int32 { return lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(t.F_end), int64(t.F_off))) }
//line :37:1
func (t *A_arbace_core_ArrayChunk_A) Nth_I__O(i__1 int32) any {


	var target_2 any = t.F_am; var tmp1 bool; var tmp2 bool; tmp2 = !(target_2 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_2) }; tmp1 = tmp2; if tmp1 { var tmp3 any = t.F_arr; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_20, jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(t.F_off), int64(i__1))).Ref())) } else { var tmp4 A_arbace_core_ArrayManager_A = A_arbace_core_ArrayManager_A_Cast(target_2); var tmp5 any = t.F_arr; return tmp4.Aget_O_I__O(tmp5, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(t.F_off), int64(i__1))))
	}
}










type A_arbace_core_ArrayChunk_A struct{ jrt.Object; F_am, F_arr any; F_off, F_end int32 }

func (t *A_arbace_core_ArrayChunk_A) Is_Indexed() {}

func (t *A_arbace_core_ArrayChunk_A) Is_IChunk() {}

func (t *A_arbace_core_ArrayChunk_A) Is_IType() {}

func (t *A_arbace_core_ArrayChunk_A) Is_Counted() {}

func (t *A_arbace_core_ArrayChunk_A) Nth_I_O__O(p0 int32, p1 any) any { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.core.ArrayChunk does not define or inherit an implementation of the resolved method 'abstract java.lang.Object nth(int, java.lang.Object)' of interface arbace.lang.Indexed."))) }

func (t *A_arbace_core_ArrayChunk_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_ArrayChunk_A) GetClass__Class() *jrt.Class { return A_arbace_core_ArrayChunk_A_class }

func (t *A_arbace_core_ArrayChunk_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_ArrayChunk_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_ArrayChunk_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_ArrayChunk_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_ArrayChunk_A); return ok }

func A_arbace_core_ArrayChunk_A_Cast(x any) *A_arbace_core_ArrayChunk_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_ArrayChunk_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_ArrayChunk_A_class)) }; return v }
