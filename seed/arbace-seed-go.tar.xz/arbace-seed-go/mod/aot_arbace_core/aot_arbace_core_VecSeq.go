//line aot_arbace_core_VecSeq.ae:1
package aot_arbace_core

import (
	"arbace/jrt"
	"arbace/lang"
)




















































func A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(p0, p1, p2 any, p3, p4 int32, p5 any) *A_arbace_core_VecSeq_A { A_arbace_core_VecSeq_A_Init(); t := &A_arbace_core_VecSeq_A{}; t.Ctor_O_O_O_I_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Ctor_O_O_O_I_I_O(am, vec, anode any, i, offset int32, _meta any) { t.F_am = am; t.F_vec = vec; t.F_anode = anode; t.F_i = i; t.F_offset = offset; t.F__meta = _meta }
//line :59:1
func A_arbace_core_VecSeq_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_core_VecSeq_A_Init(); return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_2558)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_927).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_35)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_2582).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_2583).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_2584)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_252).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_2585)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_252).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_2570)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_689).Ref())))) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Seq__ISeq() lang.ISeq { return t }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Hasheq__I() int32 {




































































































	return lang.Murmur3_HashOrdered_Iterable__I(t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) WithMeta_IPersistentMap__IObj(m__1 lang.IPersistentMap) lang.IObj { return A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(t.F_am, t.F_vec, t.F_anode, t.F_i, t.F_offset, m__1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedMore__ISeq() lang.ISeq { var tmp1 any; var s__1 any = t.ChunkedNext__ISeq(); var or__1927000174__auto____2 any = s__1; if


































































	jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { lang.PersistentList_Init(); tmp1 = lang.PersistentList_EMPTY.Ref() }; return /*line :59:1*/ lang.ISeq_Cast(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedNext__ISeq() lang.ISeq { var tmp1 *A_arbace_core_VecSeq_A; var nexti__1 int64; var tmp2 int64 = int64(t.F_i); var tmp3 int64; var target_1 any = t.F_am; var tmp4 bool; var tmp5 bool; tmp5 =





























































	!(target_1 == nil); if tmp5 { tmp5 = lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp4 = tmp5; if tmp4 { tmp3 = int64(lang.RT_IntCast_O__I(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_312, jrt.RefArrayOf(jrt.Object_class, t.F_anode)))) } else { tmp3 = int64(A_arbace_core_ArrayManager_A_Cast(target_1).Alength_O__I(t.F_anode)) }; nexti__1 = lang.Numbers_Add_J_J__J(tmp2, tmp3); if
	lang.Numbers_Lt_J_J__Z(nexti__1, int64(lang.RT_Count_O__I(t.F_vec))) { var tmp6 any = t.F_am; var tmp7 any = t.F_vec; var tmp8 any; var target_2 any = t.F_vec; var tmp9 bool; var tmp10 bool
		tmp10 = !(target_2 == nil); if tmp10 { tmp10 = lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp9 = tmp10; if tmp9 { tmp8 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_2573, jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(nexti__1).Ref())) } else { tmp8 = A_arbace_core_IVecImpl_A_Cast(target_2).ArrayFor_I__O(lang.RT_IntCast_J__I(nexti__1)) }
//line :122:1
		tmp1 = A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(tmp6, tmp7, tmp8, lang.RT_IntCast_J__I(nexti__1), lang.RT_IntCast_J__I(0), nil) } else { tmp1 = nil }; return /*line :59:1*/ Up_A_arbace_core_VecSeq_A_ISeq(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedFirst__IChunk() lang.IChunk { var tmp1 any = t.F_am; var tmp2 any = t.F_anode; var tmp3 int32 = t.F_offset; var tmp4 int32; var target_3 any = t.F_am; var tmp5 bool; var tmp6 bool; tmp6 =



























































	!(target_3 == nil); if tmp6 { tmp6 = lang.Compiler_AOT_IsDyn_O__Z(target_3) }; tmp5 = tmp6; if tmp5 { tmp4 = lang.RT_IntCast_O__I(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_3, Lit_312, jrt.RefArrayOf(jrt.Object_class, t.F_anode))) } else { tmp4 = A_arbace_core_ArrayManager_A_Cast(target_3).Alength_O__I(t.F_anode) }; return /*line :59:1*/ A_arbace_core_ArrayChunk_A_New_O_O_I_I(tmp1, tmp2, tmp3, tmp4) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Internal_reduce_O_O__O(f__1, val__2 any) any { { var result__3 any = val__2; var aidx__4 int64 = lang.Numbers_Add_J_J__J(int64(t.F_i), int64(t.F_offset)); L1: for {







	if lang.Numbers_Lt_J_J__Z(aidx__4, int64(lang.RT_Count_O__I(t.F_vec))) { var node__5 any; var target_4 any = t.F_vec; var tmp1 bool; var tmp2 bool
		tmp2 = !(target_4 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp1 = tmp2; if tmp1 { node__5 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_4, Lit_2573, jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(aidx__4).Ref())) } else { node__5 = A_arbace_core_IVecImpl_A_Cast(target_4).ArrayFor_I__O(lang.RT_IntCast_J__I(aidx__4)) }
//line :67:1
		var result__6 any; var tmp3 any = A_arbace_core_VecSeq_fn__57000031_A_New_O_O_J_O_O(f__1, t.F_am, aidx__4, result__3, node__5); var tmp4 *jrt.Class

		A_arbace_core_VecSeq_fn__57000031_A_Init(); tmp4 = A_arbace_core_VecSeq_fn__57000031_A_fn_class; result__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()







		if lang.RT_IsReduced_O__Z(result__6) { return lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_0).GetRawRoot__O()).Invoke_O__O(result__6) } else {

			result__3, aidx__4 = result__6, lang.Numbers_And_J_J__J(65504, lang.Numbers_Add_J_J__J(aidx__4, 32)); continue L1 } } else {
//line :67:1
				return result__3 } } }; /*line :59:1*/panic("a2g: unreachable") }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F__meta) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Iterator__Iterator() jrt.Iterator { return lang.SeqIterator_New_ISeq(t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Empty__IPersistentCollection() lang.IPersistentCollection { var tmp1 *lang.PersistentList_EmptyList; lang.PersistentList_Init(); tmp1 = lang.PersistentList_EMPTY; return Up_PersistentList_EmptyList_IPersistentCollection(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Equiv_O__Z(o__1 any) bool { var tmp1 *jrt.Boolean; if










































	lang.Util_Identical_O_O__Z(t, o__1) { jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE } else { var tmp2 bool; var or__1927000174__auto____2 bool = lang.Sequential_InstanceOf(o__1)

		if or__1927000174__auto____2 { tmp2 = or__1927000174__auto____2 } else { tmp2 = jrt.List_InstanceOf(o__1) }
//line :102:1
		if tmp2 { var me__2 any = t; var you__3 any = lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_1).GetRawRoot__O()).Invoke_O__O(o__1); L1: for {




			if lang.Util_Identical_O_O__Z(me__2, nil) {
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(you__3, nil)) } else {
//line :107:1
					var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_2).GetRawRoot__O()).Invoke_O__O(me__2), lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_2).GetRawRoot__O()).Invoke_O__O(you__3))

					if and__1927000168__auto____4 {
						me__2, you__3 = lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(me__2), lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(you__3); continue L1 } else {
//line :109:1
							tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4) } }
//line :102:1
			break L1 } } else { if A_arbace_core_VecSeq_A_const_3 != nil { jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE } else { tmp1 = nil } } }; return /*line :59:1*/ jrt.NN(tmp1).BooleanValue__Z() }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Count__I() int32 { var tmp1 int64; var i__1 int64 = 1; var s__2 any = lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(t); L1: for {




































	if jrt.A2g_Truth(s__2) {
		if lang.Counted_InstanceOf(s__2) {
			tmp1 = lang.Numbers_Add_J_J__J(i__1, int64(lang.IPersistentCollection_Cast(s__2).Count__I())) } else {
				i__1, s__2 = lang.Numbers_Inc_J__J(i__1), lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(s__2); continue L1 } } else {
//line :96:1
					tmp1 = i__1 }
//line :59:1
	break L1 }; return lang.RT_IntCast_J__I(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Cons_O__ISeq(o__1 any) lang.ISeq { return lang.Cons_New_O_ISeq(o__1, t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) More__ISeq() lang.ISeq { var tmp1 any; var s__1 any = t.Next__ISeq(); var or__1927000174__auto____2 any = s__1; if






























	jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { lang.PersistentList_Init(); tmp1 = lang.PersistentList_EMPTY.Ref() }; return /*line :59:1*/ lang.ISeq_Cast(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Next__ISeq() lang.ISeq { var tmp1 lang.ISeq; var tmp2 int64 = lang.Numbers_Inc_J__J(int64(t.F_offset)); var tmp3 int64; var target_7 any = t.F_am; var tmp4 bool; var tmp5 bool; tmp5 =

























	!(target_7 == nil); if tmp5 { tmp5 = lang.Compiler_AOT_IsDyn_O__Z(target_7) }; tmp4 = tmp5; if tmp4 { tmp3 = int64(lang.RT_IntCast_O__I(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_7, Lit_312, jrt.RefArrayOf(jrt.Object_class, t.F_anode)))) } else { tmp3 = int64(A_arbace_core_ArrayManager_A_Cast(target_7).Alength_O__I(t.F_anode)) }; if lang.Numbers_Lt_J_J__Z(tmp2, tmp3) { var tmp6 any = t.F_am; var tmp7 any = t.F_vec; var tmp8 any = t.F_anode; var tmp9 int32 = t.F_i; tmp1 = A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(tmp6, tmp7, tmp8, tmp9, lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(int64(t.F_offset))), nil) } else {

		tmp1 = t.ChunkedNext__ISeq() }; return tmp1 }
//line :59:1
func (t *A_arbace_core_VecSeq_A) First__O() any {























	var target_8 any = t.F_am; var tmp1 bool; var tmp2 bool; tmp2 = !(target_8 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_8) }; tmp1 = tmp2; if tmp1 { var tmp3 any = t.F_anode; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_8, Lit_314, jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Integer_ValueOf_I__Integer(t.F_offset).Ref())) } else { return A_arbace_core_ArrayManager_A_Cast(target_8).Aget_O_I__O(t.F_anode, t.F_offset) } }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Equals_O__Z(other__1 any) bool { var tmp1 *jrt.Boolean; if























































































	lang.Util_Identical_O_O__Z(t, other__1) { jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE } else { var tmp2 bool; var or__1927000174__auto____2 bool = lang.Sequential_InstanceOf(other__1)
		if or__1927000174__auto____2 { tmp2 = or__1927000174__auto____2 } else { tmp2 = jrt.List_InstanceOf(other__1) }
//line :147:1
		if tmp2 { var s__2 any = t; var os__3 any = lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_1).GetRawRoot__O()).Invoke_O__O(other__1); L1: for {



			if lang.Util_Identical_O_O__Z(s__2, nil) {
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(os__3, nil)) } else {
					if lang.Util_Equals_O_O__Z(lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_2).GetRawRoot__O()).Invoke_O__O(s__2), lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_2).GetRawRoot__O()).Invoke_O__O(os__3)) {
						s__2, os__3 = lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(s__2), lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(os__3); continue L1 } else {
//line :153:1
							jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE } }
//line :147:1
			break L1 } } else { if A_arbace_core_VecSeq_A_const_3 != nil { jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE } else { tmp1 = nil } } }; return /*line :59:1*/ jrt.NN(tmp1).BooleanValue__Z() }
//line :59:1
func (t *A_arbace_core_VecSeq_A) HashCode__I() int32 { var tmp1 int64; var hash__1 int64 = 1; var s__2 any = lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_1).GetRawRoot__O()).Invoke_O__O(t); L1: for {
















































































	if jrt.A2g_Truth(s__2) { var v__3 any = lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_2).GetRawRoot__O()).Invoke_O__O(s__2)

		if lang.Util_Identical_O_O__Z(v__3, nil) {
			hash__1, s__2 = int64(lang.Numbers_Unchecked_int_multiply_I_I__I(lang.RT_IntCast_J__I(31), lang.RT_IntCast_J__I(hash__1))), lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(s__2); continue L1 } else {
				hash__1, s__2 = int64(lang.Numbers_Unchecked_int_add_I_I__I(lang.Numbers_Unchecked_int_multiply_I_I__I(lang.RT_IntCast_J__I(31), lang.RT_IntCast_J__I(hash__1)), jrt.HashCode(v__3))), lang.IFn_Cast(jrt.NN(A_arbace_core_VecSeq_A_const_4).GetRawRoot__O()).Invoke_O__O(s__2); continue L1 } } else {
//line :140:1
					tmp1 = hash__1 }
//line :59:1
	break L1 }; return lang.RT_IntCast_J__I(tmp1) }









func A_arbace_core_VecSeq_fn__57000031_A_New_O_O_J_O_O(p0, p1 any, p2 int64, p3, p4 any) *A_arbace_core_VecSeq_fn__57000031_A { A_arbace_core_VecSeq_fn__57000031_A_Init(); t := &A_arbace_core_VecSeq_fn__57000031_A{}; t.Ctor_O_O_J_O_O(p0, p1, p2, p3, p4); return t }
//line :69:1
func (t *A_arbace_core_VecSeq_fn__57000031_A) Ctor_O_O_J_O_O(c__f, c__am any, c__aidx int64, c__result, c__node any) { t.F_f = c__f; t.F_am = c__am; t.F_aidx = c__aidx; t.F_result = c__result; t.F_node = c__node }
//line :69:1
func (t *A_arbace_core_VecSeq_fn__57000031_A) Invoke_O__O(self any) any { { var result__1 any; var t_ any = t.F_result; t.F_result = nil; result__1 = t_; var node_idx__2 int64 = lang.Numbers_And_J_J__J(31, t.F_aidx); L1: for {

	var tmp1 int64; var target_5 any = t.F_am; var tmp2 bool; var tmp3 bool; tmp3 = !(target_5 == nil); if tmp3 { tmp3 = lang.Compiler_AOT_IsDyn_O__Z(target_5) }; tmp2 = tmp3; if tmp2 { tmp1 = int64(lang.RT_IntCast_O__I(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_5, Lit_312, jrt.RefArrayOf(jrt.Object_class, t.F_node)))) } else { tmp1 = int64(A_arbace_core_ArrayManager_A_Cast(target_5).Alength_O__I(t.F_node)) }; if lang.Numbers_Lt_J_J__Z(node_idx__2, tmp1) { var result__3 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any; var target_6 any = t.F_am; var tmp6 bool; var tmp7 bool
		tmp7 = !(target_6 == nil); if tmp7 { tmp7 = lang.Compiler_AOT_IsDyn_O__Z(target_6) }; tmp6 = tmp7; if tmp6 { var tmp8 any = t.F_node; tmp5 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_6, Lit_314, jrt.RefArrayOf(jrt.Object_class, tmp8, jrt.Long_ValueOf_J__Long(node_idx__2).Ref())) } else { var tmp9 A_arbace_core_ArrayManager_A = A_arbace_core_ArrayManager_A_Cast(target_6); var tmp10 any = t.F_node; tmp5 = tmp9.Aget_O_I__O(tmp10, lang.RT_IntCast_J__I(node_idx__2)) }; result__3 = tmp4.Invoke_O_O__O(result__1, tmp5)
		if lang.RT_IsReduced_O__Z(result__3) { return result__3 } else {

			result__1, node_idx__2 = result__3, lang.Numbers_Inc_J__J(node_idx__2); continue L1 } } else {
//line :71:1
				return result__1 } } }; /*line :69:1*/panic("a2g: unreachable") }







































type A_arbace_core_VecSeq_A struct{ jrt.Object; F_am, F_vec, F_anode any; F_i, F_offset int32; F__meta any }

func (t *A_arbace_core_VecSeq_A) Is_ISeq() {}

func (t *A_arbace_core_VecSeq_A) Is_Iterable() {}

func (t *A_arbace_core_VecSeq_A) Is_IMeta() {}

func (t *A_arbace_core_VecSeq_A) Is_A_arbace_core_protocols_InternalReduce_A() {}

func (t *A_arbace_core_VecSeq_A) Is_IChunkedSeq() {}

func (t *A_arbace_core_VecSeq_A) Is_IObj() {}

func (t *A_arbace_core_VecSeq_A) Is_IHashEq() {}

func (t *A_arbace_core_VecSeq_A) Is_Seqable() {}

func (t *A_arbace_core_VecSeq_A) Is_IType() {}

func (t *A_arbace_core_VecSeq_A) Is_IPersistentCollection() {}

func (t *A_arbace_core_VecSeq_A) Is_Sequential() {}

var A_arbace_core_VecSeq_A_const_0 *lang.Var

var A_arbace_core_VecSeq_A_const_1 *lang.Var

var A_arbace_core_VecSeq_A_const_2 *lang.Var

var A_arbace_core_VecSeq_A_const_3 *lang.Keyword

var A_arbace_core_VecSeq_A_const_4 *lang.Var

var A_arbace_core_VecSeq_A_init jrt.ClassInit

func A_arbace_core_VecSeq_A_Init() { if !A_arbace_core_VecSeq_A_init.Done() { A_arbace_core_VecSeq_A_init.Run(A_arbace_core_VecSeq_A_clinit) } }

func A_arbace_core_VecSeq_A_clinit() { A_arbace_core_VecSeq_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_166); A_arbace_core_VecSeq_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_core_VecSeq_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_core_VecSeq_A_const_3 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_core_VecSeq_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6) }

func (t *A_arbace_core_VecSeq_A) Cons_O__IPersistentCollection(p0 any) lang.IPersistentCollection { return t.Cons_O__ISeq(p0) }

func (t *A_arbace_core_VecSeq_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_core_VecSeq_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_core_VecSeq_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_VecSeq_A) GetClass__Class() *jrt.Class { return A_arbace_core_VecSeq_A_class }

func (t *A_arbace_core_VecSeq_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_VecSeq_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_VecSeq_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_VecSeq_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_VecSeq_A); return ok }

func A_arbace_core_VecSeq_A_Cast(x any) *A_arbace_core_VecSeq_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_VecSeq_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_VecSeq_A_class)) }; return v }



type A_arbace_core_VecSeq_fn__57000031_A struct{ jrt.Object; F_f, F_am any; F_aidx int64; F_result, F_node any }

func (t *A_arbace_core_VecSeq_fn__57000031_A) Is_Compiler_AOTF0() {}

var A_arbace_core_VecSeq_fn__57000031_A_fn_class *jrt.Class

var A_arbace_core_VecSeq_fn__57000031_A_init jrt.ClassInit

func A_arbace_core_VecSeq_fn__57000031_A_Init() { if !A_arbace_core_VecSeq_fn__57000031_A_init.Done() { A_arbace_core_VecSeq_fn__57000031_A_init.Run(A_arbace_core_VecSeq_fn__57000031_A_clinit) } }

func A_arbace_core_VecSeq_fn__57000031_A_clinit() { A_arbace_core_VecSeq_fn__57000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_2586, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_VecSeq_fn__57000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_VecSeq_fn__57000031_A) GetClass__Class() *jrt.Class { return A_arbace_core_VecSeq_fn__57000031_A_class }

func (t *A_arbace_core_VecSeq_fn__57000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_VecSeq_fn__57000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_VecSeq_fn__57000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_VecSeq_fn__57000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_VecSeq_fn__57000031_A); return ok }

func A_arbace_core_VecSeq_fn__57000031_A_Cast(x any) *A_arbace_core_VecSeq_fn__57000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_VecSeq_fn__57000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_VecSeq_fn__57000031_A_class)) }; return v }
