//line aot_arbace_core_VecSeq.ae:1
package aot_arbace_core

import (
	"arbace/jrt"
	"arbace/lang"
)




















































func A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(p0, p1, p2 any, p3, p4 int32, p5 any) *A_arbace_core_VecSeq_A { A_arbace_core_VecSeq_A_Init(); t := &A_arbace_core_VecSeq_A{}; t.Ctor_O_O_O_I_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Ctor_O_O_O_I_I_O(am, vec, anode any, i, offset int32, _meta any) { t.F_am = am; t.F_vec = vec; t.F_anode = anode; t.F_i = i; t.F_offset = offset; t.F__meta = _meta }
//line :59:1
func A_arbace_core_VecSeq_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_core_VecSeq_A_Init(); return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_683)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_684).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_685).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_713)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_684).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_714).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_715).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_716)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_684).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_688).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_717)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_684).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_688).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_700)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_684).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_718).Ref())))) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Seq__ISeq() lang.ISeq { return t }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Hasheq__I() int32 {




































































































	return lang.Murmur3_HashOrdered_Iterable__I(t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) WithMeta_IPersistentMap__IObj(m__1 lang.IPersistentMap) lang.IObj { return A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(t.F_am, t.F_vec, t.F_anode, t.F_i, t.F_offset, m__1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedMore__ISeq() lang.ISeq { var tmp1 any; var s__1 any = t.ChunkedNext__ISeq(); var or__1927000174__auto____2 any = s__1; if


































































	jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.PersistentList_EMPTY.Ref() }; return /*line :59:1*/ lang.ISeq_Cast(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedNext__ISeq() lang.ISeq { var tmp1 *A_arbace_core_VecSeq_A; var nexti__1 int64; var tmp2 int64 = int64(t.F_i); var tmp3 int64; var target_1 any = t.F_am; var tmp4 bool; var tmp5 bool; tmp5 =





























































	!(target_1 == nil); if tmp5 { tmp5 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp4 = tmp5; if tmp4 { tmp3 = int64(lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_anode)))) } else { tmp3 = int64(A_arbace_core_ArrayManager_A_Cast(target_1).Alength_O__I(t.F_anode)) }; nexti__1 = lang.Numbers_Add_J_J__J_NoInit(tmp2, tmp3); if
	lang.Numbers_Lt_J_J__Z_NoInit(nexti__1, int64(lang.RT_Count_O__I_NoInit(t.F_vec))) { var tmp6 any = t.F_am; var tmp7 any = t.F_vec; var tmp8 any; var target_2 any = t.F_vec; var tmp9 bool; var tmp10 bool
		tmp10 = !(target_2 == nil); if tmp10 { tmp10 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_2) }; tmp9 = tmp10; if tmp9 { tmp8 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_703, jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long_NoInit(nexti__1).Ref())) } else { tmp8 = A_arbace_core_IVecImpl_A_Cast(target_2).ArrayFor_I__O(lang.RT_IntCast_J__I_NoInit(nexti__1)) }
//line :122:1
		tmp1 = A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(tmp6, tmp7, tmp8, lang.RT_IntCast_J__I_NoInit(nexti__1), lang.RT_IntCast_J__I_NoInit(0), nil) } else { tmp1 = nil }; return /*line :59:1*/ Up_A_arbace_core_VecSeq_A_ISeq(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedFirst__IChunk() lang.IChunk { var tmp1 any = t.F_am; var tmp2 any = t.F_anode; var tmp3 int32 = t.F_offset; var tmp4 int32; var target_3 any = t.F_am; var tmp5 bool; var tmp6 bool; tmp6 =



























































	!(target_3 == nil); if tmp6 { tmp6 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_3) }; tmp5 = tmp6; if tmp5 { tmp4 = lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_3, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_anode))) } else { tmp4 = A_arbace_core_ArrayManager_A_Cast(target_3).Alength_O__I(t.F_anode) }; return /*line :59:1*/ A_arbace_core_ArrayChunk_A_New_O_O_I_I(tmp1, tmp2, tmp3, tmp4) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Internal_reduce_O_O__O(f__1, val__2 any) any { { var result__3 any = val__2; var aidx__4 int64 = lang.Numbers_Add_J_J__J_NoInit(int64(t.F_i), int64(t.F_offset)); L1: for {







	if lang.Numbers_Lt_J_J__Z_NoInit(aidx__4, int64(lang.RT_Count_O__I_NoInit(t.F_vec))) { var node__5 any; var target_4 any = t.F_vec; var tmp1 bool; var tmp2 bool
		tmp2 = !(target_4 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_4) }; tmp1 = tmp2; if tmp1 { node__5 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_4, Lit_703, jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long_NoInit(aidx__4).Ref())) } else { node__5 = A_arbace_core_IVecImpl_A_Cast(target_4).ArrayFor_I__O(lang.RT_IntCast_J__I_NoInit(aidx__4)) }
//line :67:1
		var result__6 any; var tmp3 any = A_arbace_core_VecSeq_fn__57000031_A_New_O_O_J_O_O(f__1, t.F_am, aidx__4, result__3, node__5); var tmp4 *jrt.Class
		var fncls__7 /*line :67:1*/*jrt.Class = A_arbace_core_VecSeq_fn__57000031_A_fn_class

		if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_719, false); A_arbace_core_VecSeq_fn__57000031_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; result__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()







		if lang.RT_IsReduced_O__Z_NoInit(result__6) { var root_8 any = A_arbace_core_VecSeq_A_const_0.GetRawRoot__O(); var linked_9 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_8, A_arbace_core_deref_A_fn_class); var ifn_10 lang.IFn; if linked_9 == nil { ifn_10 = lang.IFn_Cast(root_8) } else { ifn_10 = nil }; var arg_11 any = result__6; if linked_9 == nil { return ifn_10.Invoke_O__O(arg_11) } else { return linked_9.(*A_arbace_core_deref_A).Invoke_O_O__O(root_8, arg_11) } } else {

			result__3, aidx__4 = result__6, lang.Numbers_And_J_J__J_NoInit(65504, lang.Numbers_Add_J_J__J_NoInit(aidx__4, 32)); continue L1 } } else {
//line :67:1
				return result__3 } } }; /*line :59:1*/panic("j2g: unreachable") }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F__meta) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Iterator__Iterator() jrt.Iterator { return lang.SeqIterator_New_ISeq(t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Empty__IPersistentCollection() lang.IPersistentCollection { return Up_PersistentList_EmptyList_IPersistentCollection(lang.PersistentList_EMPTY) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Equiv_O__Z(o__1 any) bool { var tmp1 *jrt.Boolean; if










































	lang.Util_Identical_O_O__Z_NoInit(t, o__1) { tmp1 = jrt.Boolean_TRUE } else { var tmp2 bool; var or__1927000174__auto____2 bool = lang.Sequential_InstanceOf(o__1)

		if or__1927000174__auto____2 { tmp2 = or__1927000174__auto____2 } else { tmp2 = jrt.List_InstanceOf(o__1) }
//line :102:1
		if tmp2 { var me__2 any = t; var you__3 any; var root_12 any = A_arbace_core_VecSeq_A_const_1.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, A_arbace_core_seq__1927000026_A_fn_class); var ifn_14 lang.IFn



			if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = o__1; if linked_13 == nil { you__3 = ifn_14.Invoke_O__O(arg_15) } else { you__3 = linked_13.(*A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_12, arg_15) }
//line :102:1
		L1: for {




			if lang.Util_Identical_O_O__Z_NoInit(me__2, nil) {
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(you__3, nil)) } else {
//line :107:1
					var and__1927000168__auto____4 bool; var tmp3 any; var root_16 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, A_arbace_core_first__1927000008_A_fn_class); var ifn_18 lang.IFn

					if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = me__2; if linked_17 == nil { tmp3 = ifn_18.Invoke_O__O(arg_19) } else { tmp3 = linked_17.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_16, arg_19) }; var tmp4 any = tmp3; var tmp5 any; var root_20 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, A_arbace_core_first__1927000008_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = you__3; if linked_21 == nil { tmp5 = ifn_22.Invoke_O__O(arg_23) } else { tmp5 = linked_21.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_20, arg_23) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4 {
						var tmp6 any; var root_24 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, A_arbace_core_next__1927000010_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = me__2; if linked_25 == nil { tmp6 = ifn_26.Invoke_O__O(arg_27) } else { tmp6 = linked_25.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_24, arg_27) }; var tmp7 any = tmp6; var tmp8 any; var root_28 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_core_next__1927000010_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = you__3; if linked_29 == nil { tmp8 = ifn_30.Invoke_O__O(arg_31) } else { tmp8 = linked_29.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_28, arg_31) }; me__2, you__3 = tmp7, tmp8; continue L1 } else {
//line :109:1
							tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4) } }
//line :102:1
			break L1 } } else { if A_arbace_core_VecSeq_A_const_3 != nil { tmp1 = jrt.Boolean_FALSE } else { tmp1 = nil } } }; return /*line :59:1*/ jrt.NN(tmp1).BooleanValue__Z() }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Count__I() int32 { var tmp1 int64; var i__1 int64 = 1; var s__2 any; var root_32 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, A_arbace_core_next__1927000010_A_fn_class); var ifn_34 lang.IFn; if



































	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = t; if linked_33 == nil { s__2 = ifn_34.Invoke_O__O(arg_35) } else { s__2 = linked_33.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_32, arg_35) }; L1:
//line :59:1
	for {




































		if jrt.J2g_Truth(s__2) {
			if lang.Counted_InstanceOf(s__2) {
				tmp1 = lang.Numbers_Add_J_J__J_NoInit(i__1, int64(lang.IPersistentCollection_Cast(s__2).Count__I())) } else {
					var tmp2 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp3 any; var root_36 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_core_next__1927000010_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = s__2; if linked_37 == nil { tmp3 = ifn_38.Invoke_O__O(arg_39) } else { tmp3 = linked_37.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_36, arg_39) }; i__1, s__2 = tmp2, tmp3; continue L1 } } else {
//line :96:1
						tmp1 = i__1 }
//line :59:1
		break L1 }; return lang.RT_IntCast_J__I_NoInit(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Cons_O__ISeq(o__1 any) lang.ISeq { return lang.Cons_New_O_ISeq(o__1, t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) More__ISeq() lang.ISeq { var tmp1 any; var s__1 any = t.Next__ISeq(); var or__1927000174__auto____2 any = s__1; if






























	jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.PersistentList_EMPTY.Ref() }; return /*line :59:1*/ lang.ISeq_Cast(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Next__ISeq() lang.ISeq { var tmp1 lang.ISeq; var tmp2 int64 = lang.Numbers_Inc_J__J_NoInit(int64(t.F_offset)); var tmp3 int64; var target_40 any = t.F_am; var tmp4 bool; var tmp5 bool; tmp5 =

























	!(target_40 == nil); if tmp5 { tmp5 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_40) }; tmp4 = tmp5; if tmp4 { tmp3 = int64(lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_40, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_anode)))) } else { tmp3 = int64(A_arbace_core_ArrayManager_A_Cast(target_40).Alength_O__I(t.F_anode)) }; if lang.Numbers_Lt_J_J__Z_NoInit(tmp2, tmp3) { var tmp6 any = t.F_am; var tmp7 any = t.F_vec; var tmp8 any = t.F_anode; var tmp9 int32 = t.F_i; tmp1 = A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(tmp6, tmp7, tmp8, tmp9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(t.F_offset))), nil) } else {

		tmp1 = t.ChunkedNext__ISeq() }; return tmp1 }
//line :59:1
func (t *A_arbace_core_VecSeq_A) First__O() any {























	var target_41 any = t.F_am; var tmp1 bool; var tmp2 bool; tmp2 = !(target_41 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_41) }; tmp1 = tmp2; if tmp1 { var tmp3 any = t.F_anode; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_41, Lit_20, jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Integer_ValueOf_I__Integer_NoInit(t.F_offset).Ref())) } else { return A_arbace_core_ArrayManager_A_Cast(target_41).Aget_O_I__O(t.F_anode, t.F_offset) } }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Equals_O__Z(other__1 any) bool { var tmp1 *jrt.Boolean; if























































































	lang.Util_Identical_O_O__Z_NoInit(t, other__1) { tmp1 = jrt.Boolean_TRUE } else { var tmp2 bool; var or__1927000174__auto____2 bool = lang.Sequential_InstanceOf(other__1)
		if or__1927000174__auto____2 { tmp2 = or__1927000174__auto____2 } else { tmp2 = jrt.List_InstanceOf(other__1) }
//line :147:1
		if tmp2 { var s__2 any = t; var os__3 any; var root_42 any = A_arbace_core_VecSeq_A_const_1.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, A_arbace_core_seq__1927000026_A_fn_class); var ifn_44 lang.IFn


			if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = other__1; if linked_43 == nil { os__3 = ifn_44.Invoke_O__O(arg_45) } else { os__3 = linked_43.(*A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_42, arg_45) }
//line :147:1
		L1: for {



			if lang.Util_Identical_O_O__Z_NoInit(s__2, nil) {
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(os__3, nil)) } else {
					var tmp3 any; var root_46 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, A_arbace_core_first__1927000008_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = s__2; if linked_47 == nil { tmp3 = ifn_48.Invoke_O__O(arg_49) } else { tmp3 = linked_47.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_46, arg_49) }; var tmp4 any = tmp3; var tmp5 any; var root_50 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_core_first__1927000008_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = os__3; if linked_51 == nil { tmp5 = ifn_52.Invoke_O__O(arg_53) } else { tmp5 = linked_51.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_50, arg_53) }; if lang.Util_Equals_O_O__Z_NoInit(tmp4, tmp5) {
						var tmp6 any; var root_54 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, A_arbace_core_next__1927000010_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = s__2; if linked_55 == nil { tmp6 = ifn_56.Invoke_O__O(arg_57) } else { tmp6 = linked_55.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_54, arg_57) }; var tmp7 any = tmp6; var tmp8 any; var root_58 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_core_next__1927000010_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = os__3; if linked_59 == nil { tmp8 = ifn_60.Invoke_O__O(arg_61) } else { tmp8 = linked_59.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_58, arg_61) }; s__2, os__3 = tmp7, tmp8; continue L1 } else {
//line :153:1
							tmp1 = jrt.Boolean_FALSE } }
//line :147:1
			break L1 } } else { if A_arbace_core_VecSeq_A_const_3 != nil { tmp1 = jrt.Boolean_FALSE } else { tmp1 = nil } } }; return /*line :59:1*/ jrt.NN(tmp1).BooleanValue__Z() }
//line :59:1
func (t *A_arbace_core_VecSeq_A) HashCode__I() int32 { var tmp1 int64; var hash__1 int64 = 1; var s__2 any; var root_62 any = A_arbace_core_VecSeq_A_const_1.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, A_arbace_core_seq__1927000026_A_fn_class); var ifn_64 lang.IFn; if















































































	linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = t; if linked_63 == nil { s__2 = ifn_64.Invoke_O__O(arg_65) } else { s__2 = linked_63.(*A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_62, arg_65) }; L1:
//line :59:1
	for {
















































































		if jrt.J2g_Truth(s__2) { var v__3 any; var root_66 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, A_arbace_core_first__1927000008_A_fn_class); var ifn_68 lang.IFn
			if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = s__2; if linked_67 == nil { v__3 = ifn_68.Invoke_O__O(arg_69) } else { v__3 = linked_67.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_66, arg_69) }
			if lang.Util_Identical_O_O__Z_NoInit(v__3, nil) {
				var tmp2 int64 = int64(lang.Numbers_Unchecked_int_multiply_I_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(31), lang.RT_IntCast_J__I_NoInit(hash__1))); var tmp3 any; var root_70 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, A_arbace_core_next__1927000010_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = s__2; if linked_71 == nil { tmp3 = ifn_72.Invoke_O__O(arg_73) } else { tmp3 = linked_71.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_70, arg_73) }; hash__1, s__2 = tmp2, tmp3; continue L1 } else {
					var tmp4 int64 = int64(lang.Numbers_Unchecked_int_add_I_I__I_NoInit(lang.Numbers_Unchecked_int_multiply_I_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(31), lang.RT_IntCast_J__I_NoInit(hash__1)), jrt.HashCode(v__3))); var tmp5 any; var root_74 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, A_arbace_core_next__1927000010_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = s__2; if linked_75 == nil { tmp5 = ifn_76.Invoke_O__O(arg_77) } else { tmp5 = linked_75.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_74, arg_77) }; hash__1, s__2 = tmp4, tmp5; continue L1 } } else {
//line :140:1
						tmp1 = hash__1 }
//line :59:1
		break L1 }; return lang.RT_IntCast_J__I_NoInit(tmp1) }









func A_arbace_core_VecSeq_fn__57000031_A_New_O_O_J_O_O(p0, p1 any, p2 int64, p3, p4 any) *A_arbace_core_VecSeq_fn__57000031_A { A_arbace_core_VecSeq_A_Init(); t := &A_arbace_core_VecSeq_fn__57000031_A{}; t.Ctor_O_O_J_O_O(p0, p1, p2, p3, p4); return t }
//line :69:1
func (t *A_arbace_core_VecSeq_fn__57000031_A) Ctor_O_O_J_O_O(c__f, c__am any, c__aidx int64, c__result, c__node any) { t.F_f = c__f; t.F_am = c__am; t.F_aidx = c__aidx; t.F_result = c__result; t.F_node = c__node }
//line :69:1
func (t *A_arbace_core_VecSeq_fn__57000031_A) Invoke_O__O(self any) any { { var result__1 any; var t_ any = t.F_result; t.F_result = nil; result__1 = t_; var node_idx__2 int64 = lang.Numbers_And_J_J__J_NoInit(31, t.F_aidx); L1: for {

	var tmp1 int64; var target_5 any = t.F_am; var tmp2 bool; var tmp3 bool; tmp3 = !(target_5 == nil); if tmp3 { tmp3 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_5) }; tmp2 = tmp3; if tmp2 { tmp1 = int64(lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_5, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_node)))) } else { tmp1 = int64(A_arbace_core_ArrayManager_A_Cast(target_5).Alength_O__I(t.F_node)) }; if lang.Numbers_Lt_J_J__Z_NoInit(node_idx__2, tmp1) { var result__3 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any; var target_6 any = t.F_am; var tmp6 bool; var tmp7 bool
		tmp7 = !(target_6 == nil); if tmp7 { tmp7 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_6) }; tmp6 = tmp7; if tmp6 { var tmp8 any = t.F_node; tmp5 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_6, Lit_20, jrt.RefArrayOf(jrt.Object_class, tmp8, jrt.Long_ValueOf_J__Long_NoInit(node_idx__2).Ref())) } else { var tmp9 A_arbace_core_ArrayManager_A = A_arbace_core_ArrayManager_A_Cast(target_6); var tmp10 any = t.F_node; tmp5 = tmp9.Aget_O_I__O(tmp10, lang.RT_IntCast_J__I_NoInit(node_idx__2)) }; result__3 = tmp4.Invoke_O_O__O(result__1, tmp5)
		if lang.RT_IsReduced_O__Z_NoInit(result__3) { return result__3 } else {

			result__1, node_idx__2 = result__3, lang.Numbers_Inc_J__J_NoInit(node_idx__2); continue L1 } } else {
//line :71:1
				return result__1 } } }; /*line :69:1*/panic("j2g: unreachable") }







































type A_arbace_core_VecSeq_A struct{ jrt.Object; F_am, F_vec, F_anode any; F_i, F_offset int32; F__meta any }

func (t *A_arbace_core_VecSeq_A) Is_ISeq() {}

func (t *A_arbace_core_VecSeq_A) Is_Iterable() {}

func (t *A_arbace_core_VecSeq_A) Is_IMeta() {}

func (t *A_arbace_core_VecSeq_A) Is_A_arbace_core_protocols_InternalReduce_A() {}

func (t *A_arbace_core_VecSeq_A) Is_IChunkedSeq() {}

func (t *A_arbace_core_VecSeq_A) Is_IObj() {}

func (t *A_arbace_core_VecSeq_A) Is_IHashEq() {}

func (t *A_arbace_core_VecSeq_A) Is_Seqable() {}

func (t *A_arbace_core_VecSeq_A) Is_IType() {}

func (t *A_arbace_core_VecSeq_A) Is_IPersistentCollection() {}

func (t *A_arbace_core_VecSeq_A) Is_Sequential() {}

var A_arbace_core_VecSeq_A_const_pool *jrt.RefArray

var A_arbace_core_VecSeq_A_const_0 *lang.Var

var A_arbace_core_VecSeq_A_const_1 *lang.Var

var A_arbace_core_VecSeq_A_const_2 *lang.Var

var A_arbace_core_VecSeq_A_const_3 *lang.Keyword

var A_arbace_core_VecSeq_A_const_4 *lang.Var

var A_arbace_core_VecSeq_A_init jrt.ClassInit

func A_arbace_core_VecSeq_A_Init() { if !A_arbace_core_VecSeq_A_init.Done() { A_arbace_core_VecSeq_A_init.Run(A_arbace_core_VecSeq_A_clinit) } }

func A_arbace_core_VecSeq_A_clinit() { jrt.StartCheck(); A_arbace_core_VecSeq_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_712, 6); A_arbace_core_VecSeq_A_const_0 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[1]); A_arbace_core_VecSeq_A_const_1 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[2]); A_arbace_core_VecSeq_A_const_2 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[3]); A_arbace_core_VecSeq_A_const_3 = lang.Keyword_Cast(A_arbace_core_VecSeq_A_const_pool.A[4]); A_arbace_core_VecSeq_A_const_4 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[5]) }

func (t *A_arbace_core_VecSeq_A) Cons_O__IPersistentCollection(p0 any) lang.IPersistentCollection { return t.Cons_O__ISeq(p0) }

func (t *A_arbace_core_VecSeq_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_core_VecSeq_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_core_VecSeq_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_VecSeq_A) GetClass__Class() *jrt.Class { return A_arbace_core_VecSeq_A_class }

func (t *A_arbace_core_VecSeq_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_VecSeq_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_VecSeq_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_VecSeq_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_VecSeq_A); return ok }

func A_arbace_core_VecSeq_A_Cast(x any) *A_arbace_core_VecSeq_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_VecSeq_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_VecSeq_A_class)) }; return v }



type A_arbace_core_VecSeq_fn__57000031_A struct{ j2g_header uint64; F_f, F_am any; F_aidx int64; F_result, F_node any }

var A_arbace_core_VecSeq_fn__57000031_A_fn_class *jrt.Class
