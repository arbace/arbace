//line aot_arbace_core_VecSeq.ae:1
package aot_arbace_core

import (
	"arbace/jrt"
	"arbace/lang"
)




















































func A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(p0, p1, p2 any, p3, p4 int32, p5 any) *A_arbace_core_VecSeq_A { A_arbace_core_VecSeq_A_Init(); t := &A_arbace_core_VecSeq_A{}; t.Ctor_O_O_O_I_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Ctor_O_O_O_I_I_O(am, vec, anode any, i, offset int32, _meta any) { t.F_am = am; t.F_vec = vec; t.F_anode = anode; t.F_i = i; t.F_offset = offset; t.F__meta = _meta }
//line :59:1
func A_arbace_core_VecSeq_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_core_VecSeq_A_Init(); return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_687)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_688).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_689).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_717)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_688).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_718).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_719).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_720)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_688).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_692).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_721)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_688).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_692).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_704)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_688).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_722).Ref())))) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Seq__ISeq() lang.ISeq { return t }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Hasheq__I() int32 {




































































































	return lang.Murmur3_HashOrdered_Iterable__I(t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) WithMeta_IPersistentMap__IObj(m__1 lang.IPersistentMap) lang.IObj { return A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(t.F_am, t.F_vec, t.F_anode, t.F_i, t.F_offset, m__1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedMore__ISeq() lang.ISeq { var tmp1 any; var s__1 any = t.ChunkedNext__ISeq(); var or__1927000174__auto____2 any = s__1; if


































































	jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.PersistentList_EMPTY.Ref() }; return /*line :59:1*/ lang.ISeq_Cast(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedNext__ISeq() lang.ISeq { var tmp1 *A_arbace_core_VecSeq_A; var nexti__1 int64; var tmp2 int64 = int64(t.F_i); var tmp3 int64; var target_1 any = t.F_am; var tmp4 bool; var tmp5 bool; tmp5 =





























































	!(target_1 == nil); if tmp5 { tmp5 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp4 = tmp5; if tmp4 { tmp3 = int64(lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_anode)))) } else { tmp3 = int64(A_arbace_core_ArrayManager_A_Cast(target_1).Alength_O__I(t.F_anode)) }; nexti__1 = lang.Numbers_Add_J_J__J_NoInit(tmp2, tmp3); if
	lang.Numbers_Lt_J_J__Z_NoInit(nexti__1, int64(lang.RT_Count_O__I_NoInit(t.F_vec))) { var tmp6 any = t.F_am; var tmp7 any = t.F_vec; var tmp8 any; var target_2 any = t.F_vec; var tmp9 bool; var tmp10 bool
		tmp10 = !(target_2 == nil); if tmp10 { tmp10 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_2) }; tmp9 = tmp10; if tmp9 { tmp8 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_707, jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long_NoInit(nexti__1).Ref())) } else { tmp8 = A_arbace_core_IVecImpl_A_Cast(target_2).ArrayFor_I__O(lang.RT_IntCast_J__I_NoInit(nexti__1)) }
//line :122:1
		tmp1 = A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(tmp6, tmp7, tmp8, lang.RT_IntCast_J__I_NoInit(nexti__1), lang.RT_IntCast_J__I_NoInit(0), nil) } else { tmp1 = nil }; return /*line :59:1*/ Up_A_arbace_core_VecSeq_A_ISeq(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) ChunkedFirst__IChunk() lang.IChunk { var tmp1 any = t.F_am; var tmp2 any = t.F_anode; var tmp3 int32 = t.F_offset; var tmp4 int32; var target_3 any = t.F_am; var tmp5 bool; var tmp6 bool; tmp6 =



























































	!(target_3 == nil); if tmp6 { tmp6 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_3) }; tmp5 = tmp6; if tmp5 { tmp4 = lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_3, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_anode))) } else { tmp4 = A_arbace_core_ArrayManager_A_Cast(target_3).Alength_O__I(t.F_anode) }; return /*line :59:1*/ A_arbace_core_ArrayChunk_A_New_O_O_I_I(tmp1, tmp2, tmp3, tmp4) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Internal_reduce_O_O__O(f__1, val__2 any) any { { var result__3 any = val__2; var aidx__4 int64 = lang.Numbers_Add_J_J__J_NoInit(int64(t.F_i), int64(t.F_offset)); L1: for {







	if lang.Numbers_Lt_J_J__Z_NoInit(aidx__4, int64(lang.RT_Count_O__I_NoInit(t.F_vec))) { var node__5 any; var target_4 any = t.F_vec; var tmp1 bool; var tmp2 bool
		tmp2 = !(target_4 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_4) }; tmp1 = tmp2; if tmp1 { node__5 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_4, Lit_707, jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long_NoInit(aidx__4).Ref())) } else { node__5 = A_arbace_core_IVecImpl_A_Cast(target_4).ArrayFor_I__O(lang.RT_IntCast_J__I_NoInit(aidx__4)) }
//line :67:1
		var result__6 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_core_VecSeq_fn__57000031_A_New_O_O_J_O_O(f__1, t.F_am, aidx__4, result__3, node__5); var tmp4 *jrt.Class
		var fncls__7 /*line :67:1*/*jrt.Class = A_arbace_core_VecSeq_fn__57000031_A_fn_class

		if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_723, false, fnbody__8); A_arbace_core_VecSeq_fn__57000031_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp4, nil); result__6 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()







		if lang.RT_IsReduced_O__Z_NoInit(result__6) { var root_9 any = A_arbace_core_VecSeq_A_const_0.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = result__6; if linked_10 == nil { return ifn_11.Invoke_O__O(arg_12) } else { return linked_10.(*A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) } } else {

			result__3, aidx__4 = result__6, lang.Numbers_And_J_J__J_NoInit(65504, lang.Numbers_Add_J_J__J_NoInit(aidx__4, 32)); continue L1 } } else {
//line :67:1
				return result__3 } } }; /*line :59:1*/panic("j2g: unreachable") }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F__meta) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Iterator__Iterator() jrt.Iterator { return lang.SeqIterator_New_ISeq(t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Empty__IPersistentCollection() lang.IPersistentCollection { return Up_PersistentList_EmptyList_IPersistentCollection(lang.PersistentList_EMPTY) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Equiv_O__Z(o__1 any) bool {










































	var tmp1 *jrt.Boolean; if lang.Util_Identical_O_O__Z_NoInit(t, o__1) { tmp1 = jrt.Boolean_TRUE } else { var tmp2 bool; var or__1927000174__auto____2 bool = lang.Sequential_InstanceOf(o__1)

		if or__1927000174__auto____2 { tmp2 = or__1927000174__auto____2 } else { tmp2 = jrt.List_InstanceOf(o__1) }
//line :102:1
		if tmp2 { var me__2 any = t; var you__3 any; var root_13 any = A_arbace_core_VecSeq_A_const_1.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, A_arbace_core_seq__1927000026_A_fn_class); var ifn_15 lang.IFn



			if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = o__1; if linked_14 == nil { you__3 = ifn_15.Invoke_O__O(arg_16) } else { you__3 = linked_14.(*A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_13, arg_16) }
//line :102:1
		L1: for {




			if lang.Util_Identical_O_O__Z_NoInit(me__2, nil) {
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(you__3, nil)) } else {
//line :107:1
					var and__1927000168__auto____4 bool; var tmp3 any; var root_17 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, A_arbace_core_first__1927000008_A_fn_class); var ifn_19 lang.IFn

					if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = me__2; if linked_18 == nil { tmp3 = ifn_19.Invoke_O__O(arg_20) } else { tmp3 = linked_18.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_17, arg_20) }; var tmp4 any = tmp3; var tmp5 any; var root_21 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, A_arbace_core_first__1927000008_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = you__3; if linked_22 == nil { tmp5 = ifn_23.Invoke_O__O(arg_24) } else { tmp5 = linked_22.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_21, arg_24) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4 {
						var tmp6 any; var root_25 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, A_arbace_core_next__1927000010_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = me__2; if linked_26 == nil { tmp6 = ifn_27.Invoke_O__O(arg_28) } else { tmp6 = linked_26.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_25, arg_28) }; var tmp7 any = tmp6; var tmp8 any; var root_29 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, A_arbace_core_next__1927000010_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = you__3; if linked_30 == nil { tmp8 = ifn_31.Invoke_O__O(arg_32) } else { tmp8 = linked_30.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_29, arg_32) }; me__2, you__3 = tmp7, tmp8; continue L1 } else {
//line :109:1
							tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4) } }
//line :102:1
			break L1 } } else { if A_arbace_core_VecSeq_A_const_3 != nil { tmp1 = jrt.Boolean_FALSE } else { tmp1 = nil } } }; return jrt.NN(tmp1).BooleanValue__Z() }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Count__I() int32 { var tmp1 int64; var i__1 int64 = 1; var s__2 any; var root_33 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_core_next__1927000010_A_fn_class); var ifn_35 lang.IFn; if



































	linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = t; if linked_34 == nil { s__2 = ifn_35.Invoke_O__O(arg_36) } else { s__2 = linked_34.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_33, arg_36) }; L1:
//line :59:1
	for {




































		if jrt.J2g_Truth(s__2) {
			if lang.Counted_InstanceOf(s__2) {
				tmp1 = lang.Numbers_Add_J_J__J_NoInit(i__1, int64(lang.IPersistentCollection_Cast(s__2).Count__I())) } else {
					var tmp2 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp3 any; var root_37 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_core_next__1927000010_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = s__2; if linked_38 == nil { tmp3 = ifn_39.Invoke_O__O(arg_40) } else { tmp3 = linked_38.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_37, arg_40) }; i__1, s__2 = tmp2, tmp3; continue L1 } } else {
//line :96:1
						tmp1 = i__1 }
//line :59:1
		break L1 }; return lang.RT_IntCast_J__I_NoInit(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Cons_O__ISeq(o__1 any) lang.ISeq { return lang.Cons_New_O_ISeq(o__1, t) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) More__ISeq() lang.ISeq { var tmp1 any; var s__1 any = t.Next__ISeq(); var or__1927000174__auto____2 any = s__1; if






























	jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.PersistentList_EMPTY.Ref() }; return /*line :59:1*/ lang.ISeq_Cast(tmp1) }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Next__ISeq() lang.ISeq { var tmp1 lang.ISeq; var tmp2 int64 = lang.Numbers_Inc_J__J_NoInit(int64(t.F_offset)); var tmp3 int64; var target_41 any = t.F_am; var tmp4 bool; var tmp5 bool; tmp5 =

























	!(target_41 == nil); if tmp5 { tmp5 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_41) }; tmp4 = tmp5; if tmp4 { tmp3 = int64(lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_41, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_anode)))) } else { tmp3 = int64(A_arbace_core_ArrayManager_A_Cast(target_41).Alength_O__I(t.F_anode)) }; if lang.Numbers_Lt_J_J__Z_NoInit(tmp2, tmp3) { var tmp6 any = t.F_am; var tmp7 any = t.F_vec; var tmp8 any = t.F_anode; var tmp9 int32 = t.F_i; tmp1 = A_arbace_core_VecSeq_A_New_O_O_O_I_I_O(tmp6, tmp7, tmp8, tmp9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(t.F_offset))), nil) } else {

		tmp1 = t.ChunkedNext__ISeq() }; return tmp1 }
//line :59:1
func (t *A_arbace_core_VecSeq_A) First__O() any {























	var target_42 any = t.F_am; var tmp1 bool; var tmp2 bool; tmp2 = !(target_42 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_42) }; tmp1 = tmp2; if tmp1 { var tmp3 any = t.F_anode; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_42, Lit_20, jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Integer_ValueOf_I__Integer_NoInit(t.F_offset).Ref())) } else { return A_arbace_core_ArrayManager_A_Cast(target_42).Aget_O_I__O(t.F_anode, t.F_offset) } }
//line :59:1
func (t *A_arbace_core_VecSeq_A) Equals_O__Z(other__1 any) bool {























































































	var tmp1 *jrt.Boolean; if lang.Util_Identical_O_O__Z_NoInit(t, other__1) { tmp1 = jrt.Boolean_TRUE } else { var tmp2 bool; var or__1927000174__auto____2 bool = lang.Sequential_InstanceOf(other__1)
		if or__1927000174__auto____2 { tmp2 = or__1927000174__auto____2 } else { tmp2 = jrt.List_InstanceOf(other__1) }
//line :147:1
		if tmp2 { var s__2 any = t; var os__3 any; var root_43 any = A_arbace_core_VecSeq_A_const_1.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, A_arbace_core_seq__1927000026_A_fn_class); var ifn_45 lang.IFn


			if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = other__1; if linked_44 == nil { os__3 = ifn_45.Invoke_O__O(arg_46) } else { os__3 = linked_44.(*A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_43, arg_46) }
//line :147:1
		L1: for {



			if lang.Util_Identical_O_O__Z_NoInit(s__2, nil) {
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(os__3, nil)) } else {
					var tmp3 any; var root_47 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, A_arbace_core_first__1927000008_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = s__2; if linked_48 == nil { tmp3 = ifn_49.Invoke_O__O(arg_50) } else { tmp3 = linked_48.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_47, arg_50) }; var tmp4 any = tmp3; var tmp5 any; var root_51 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_core_first__1927000008_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = os__3; if linked_52 == nil { tmp5 = ifn_53.Invoke_O__O(arg_54) } else { tmp5 = linked_52.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_51, arg_54) }; if lang.Util_Equals_O_O__Z_NoInit(tmp4, tmp5) {
						var tmp6 any; var root_55 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_core_next__1927000010_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = s__2; if linked_56 == nil { tmp6 = ifn_57.Invoke_O__O(arg_58) } else { tmp6 = linked_56.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_55, arg_58) }; var tmp7 any = tmp6; var tmp8 any; var root_59 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, A_arbace_core_next__1927000010_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = os__3; if linked_60 == nil { tmp8 = ifn_61.Invoke_O__O(arg_62) } else { tmp8 = linked_60.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_59, arg_62) }; s__2, os__3 = tmp7, tmp8; continue L1 } else {
//line :153:1
							tmp1 = jrt.Boolean_FALSE } }
//line :147:1
			break L1 } } else { if A_arbace_core_VecSeq_A_const_3 != nil { tmp1 = jrt.Boolean_FALSE } else { tmp1 = nil } } }; return jrt.NN(tmp1).BooleanValue__Z() }
//line :59:1
func (t *A_arbace_core_VecSeq_A) HashCode__I() int32 { var tmp1 int64; var hash__1 int64 = 1; var s__2 any; var root_63 any = A_arbace_core_VecSeq_A_const_1.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, A_arbace_core_seq__1927000026_A_fn_class); var ifn_65 lang.IFn; if















































































	linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = t; if linked_64 == nil { s__2 = ifn_65.Invoke_O__O(arg_66) } else { s__2 = linked_64.(*A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_63, arg_66) }; L1:
//line :59:1
	for {
















































































		if jrt.J2g_Truth(s__2) { var v__3 any; var root_67 any = A_arbace_core_VecSeq_A_const_2.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, A_arbace_core_first__1927000008_A_fn_class); var ifn_69 lang.IFn
			if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = s__2; if linked_68 == nil { v__3 = ifn_69.Invoke_O__O(arg_70) } else { v__3 = linked_68.(*A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_67, arg_70) }
			if lang.Util_Identical_O_O__Z_NoInit(v__3, nil) {
				var tmp2 int64 = int64(lang.Numbers_Unchecked_int_multiply_I_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(31), lang.RT_IntCast_J__I_NoInit(hash__1))); var tmp3 any; var root_71 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_core_next__1927000010_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = s__2; if linked_72 == nil { tmp3 = ifn_73.Invoke_O__O(arg_74) } else { tmp3 = linked_72.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_71, arg_74) }; hash__1, s__2 = tmp2, tmp3; continue L1 } else {
					var tmp4 int64 = int64(lang.Numbers_Unchecked_int_add_I_I__I_NoInit(lang.Numbers_Unchecked_int_multiply_I_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(31), lang.RT_IntCast_J__I_NoInit(hash__1)), jrt.HashCode(v__3))); var tmp5 any; var root_75 any = A_arbace_core_VecSeq_A_const_4.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_core_next__1927000010_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = s__2; if linked_76 == nil { tmp5 = ifn_77.Invoke_O__O(arg_78) } else { tmp5 = linked_76.(*A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_75, arg_78) }; hash__1, s__2 = tmp4, tmp5; continue L1 } } else {
//line :140:1
						tmp1 = hash__1 }
//line :59:1
		break L1 }; return lang.RT_IntCast_J__I_NoInit(tmp1) }









func A_arbace_core_VecSeq_fn__57000031_A_New_O_O_J_O_O(p0, p1 any, p2 int64, p3, p4 any) *A_arbace_core_VecSeq_fn__57000031_A { A_arbace_core_VecSeq_A_Init(); t := &A_arbace_core_VecSeq_fn__57000031_A{}; t.Ctor_O_O_J_O_O(p0, p1, p2, p3, p4); return t }
//line :69:1
func (t *A_arbace_core_VecSeq_fn__57000031_A) Ctor_O_O_J_O_O(c__f, c__am any, c__aidx int64, c__result, c__node any) { t.F_f = c__f; t.F_am = c__am; t.F_aidx = c__aidx; t.F_result = c__result; t.F_node = c__node }
//line :69:1
func (t *A_arbace_core_VecSeq_fn__57000031_A) Invoke_O__O(self any) any { { var result__1 any; var t_ any = t.F_result; t.F_result = nil; result__1 = t_; var node_idx__2 int64 = lang.Numbers_And_J_J__J_NoInit(31, t.F_aidx); L1: for {

	var tmp1 int64; var target_5 any = t.F_am; var tmp2 bool; var tmp3 bool; tmp3 = !(target_5 == nil); if tmp3 { tmp3 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_5) }; tmp2 = tmp3; if tmp2 { tmp1 = int64(lang.RT_IntCast_O__I_NoInit(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_5, Lit_16, jrt.RefArrayOf(jrt.Object_class, t.F_node)))) } else { tmp1 = int64(A_arbace_core_ArrayManager_A_Cast(target_5).Alength_O__I(t.F_node)) }; if lang.Numbers_Lt_J_J__Z_NoInit(node_idx__2, tmp1) { var result__3 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any; var target_6 any = t.F_am; var tmp6 bool; var tmp7 bool
		tmp7 = !(target_6 == nil); if tmp7 { tmp7 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_6) }; tmp6 = tmp7; if tmp6 { var tmp8 any = t.F_node; tmp5 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_6, Lit_20, jrt.RefArrayOf(jrt.Object_class, tmp8, jrt.Long_ValueOf_J__Long_NoInit(node_idx__2).Ref())) } else { var tmp9 A_arbace_core_ArrayManager_A = A_arbace_core_ArrayManager_A_Cast(target_6); var tmp10 any = t.F_node; tmp5 = tmp9.Aget_O_I__O(tmp10, lang.RT_IntCast_J__I_NoInit(node_idx__2)) }; result__3 = tmp4.Invoke_O_O__O(result__1, tmp5)
		if lang.RT_IsReduced_O__Z_NoInit(result__3) { return result__3 } else {

			result__1, node_idx__2 = result__3, lang.Numbers_Inc_J__J_NoInit(node_idx__2); continue L1 } } else {
//line :71:1
				return result__1 } } }; /*line :69:1*/panic("j2g: unreachable") }







































type A_arbace_core_VecSeq_A struct{ jrt.Object; F_am, F_vec, F_anode any; F_i, F_offset int32; F__meta any }

func (t *A_arbace_core_VecSeq_A) Is_ISeq() {}

func (t *A_arbace_core_VecSeq_A) Is_Iterable() {}

func (t *A_arbace_core_VecSeq_A) Is_IMeta() {}

func (t *A_arbace_core_VecSeq_A) Is_A_arbace_core_protocols_InternalReduce_A() {}

func (t *A_arbace_core_VecSeq_A) Is_IChunkedSeq() {}

func (t *A_arbace_core_VecSeq_A) Is_IObj() {}

func (t *A_arbace_core_VecSeq_A) Is_IHashEq() {}

func (t *A_arbace_core_VecSeq_A) Is_Seqable() {}

func (t *A_arbace_core_VecSeq_A) Is_IType() {}

func (t *A_arbace_core_VecSeq_A) Is_IPersistentCollection() {}

func (t *A_arbace_core_VecSeq_A) Is_Sequential() {}

var A_arbace_core_VecSeq_A_const_pool *jrt.RefArray

var A_arbace_core_VecSeq_A_const_0 *lang.Var

var A_arbace_core_VecSeq_A_const_1 *lang.Var

var A_arbace_core_VecSeq_A_const_2 *lang.Var

var A_arbace_core_VecSeq_A_const_3 *lang.Keyword

var A_arbace_core_VecSeq_A_const_4 *lang.Var

var A_arbace_core_VecSeq_A_init jrt.ClassInit

func A_arbace_core_VecSeq_A_Init() { if !A_arbace_core_VecSeq_A_init.Done() { A_arbace_core_VecSeq_A_init.Run(A_arbace_core_VecSeq_A_clinit) } }

func A_arbace_core_VecSeq_A_clinit() { jrt.StartCheck(); A_arbace_core_VecSeq_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_716, 6); A_arbace_core_VecSeq_A_const_0 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[1]); A_arbace_core_VecSeq_A_const_1 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[2]); A_arbace_core_VecSeq_A_const_2 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[3]); A_arbace_core_VecSeq_A_const_3 = lang.Keyword_Cast(A_arbace_core_VecSeq_A_const_pool.A[4]); A_arbace_core_VecSeq_A_const_4 = lang.Var_Cast(A_arbace_core_VecSeq_A_const_pool.A[5]) }

func (t *A_arbace_core_VecSeq_A) Cons_O__IPersistentCollection(p0 any) lang.IPersistentCollection { return t.Cons_O__ISeq(p0) }

func (t *A_arbace_core_VecSeq_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_core_VecSeq_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_core_VecSeq_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_VecSeq_A) GetClass__Class() *jrt.Class { return A_arbace_core_VecSeq_A_class }

func (t *A_arbace_core_VecSeq_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_VecSeq_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_VecSeq_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_VecSeq_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_VecSeq_A); return ok }

func A_arbace_core_VecSeq_A_Cast(x any) *A_arbace_core_VecSeq_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_VecSeq_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_VecSeq_A_class)) }; return v }



type A_arbace_core_VecSeq_fn__57000031_A struct{ j2g_header uint64; F_f, F_am any; F_aidx int64; F_result, F_node any }

var A_arbace_core_VecSeq_fn__57000031_A_fn_class *jrt.Class
