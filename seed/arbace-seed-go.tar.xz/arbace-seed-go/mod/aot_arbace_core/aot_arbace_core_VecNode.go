//line aot_arbace_core_VecNode.ae:1
package aot_arbace_core

import (
	"arbace/jrt"
	"arbace/lang"
)











func A_arbace_core_VecNode_A_New_O_O(p0, p1 any) *A_arbace_core_VecNode_A { t := &A_arbace_core_VecNode_A{}; t.Ctor_O_O(p0, p1); return t }
//line :18:1
func (t *A_arbace_core_VecNode_A) Ctor_O_O(edit, arr any) { t.F_edit = edit; t.F_arr = arr }
//line :18:1
func A_arbace_core_VecNode_A_GetBasis__IPersistentVector() lang.IPersistentVector { return lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_701).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_676).Ref()) }







type A_arbace_core_VecNode_A struct{ jrt.Object; F_edit, F_arr any }

func (t *A_arbace_core_VecNode_A) Is_IType() {}

func (t *A_arbace_core_VecNode_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_VecNode_A) GetClass__Class() *jrt.Class { return A_arbace_core_VecNode_A_class }

func (t *A_arbace_core_VecNode_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_VecNode_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_VecNode_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_VecNode_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_VecNode_A); return ok }

func A_arbace_core_VecNode_A_Cast(x any) *A_arbace_core_VecNode_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_VecNode_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_VecNode_A_class)) }; return v }
